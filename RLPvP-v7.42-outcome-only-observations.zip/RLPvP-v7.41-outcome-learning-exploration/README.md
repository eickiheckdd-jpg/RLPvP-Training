# RLPvP V10 — Network-aware Minecraft PvP simulator

V10 builds on the V9 combat-formula port and the selected V7.35 measured-combat merge. It adds a separate client/server duel model and a tick-driven, TCP-like network layer so the policy is trained against delayed server state rather than a single instantly shared player state.


## v7.38 architecture upgrade — compact 128-input recurrent PPO

This update changes the policy input from the previous explicit multi-lag stack to a compact recurrent input. The original 126-input compact layout has since been extended by two target-box aim observations. The default policy now receives **exactly 128 floats per tick** and uses a trainable **64-unit GRU** as its temporal memory. The mod target remains Minecraft Java **1.21.11**; the Minecraft 26.3 material remains reference-only for the standalone simulator.

The 128-input contract is: indices `0..50` are the current 51-feature observation frame; `51..114` are the 64 current GRU hidden-state values; `115..122` are eight opponent-habit features; `123` is normalized recent damage differential; `124` is a packed four-bit recent hit-type mask; `125` is measured reach margin; and `126..127` are normalized horizontal/vertical crosshair offsets relative to the projected target bounding box. Target angular velocity remains available through the existing motion-memory summary. These new inputs are observations only and never drive camera actions directly. The GRU reads 18 normalized fight-state signals and is trained with truncated backpropagation through time over 32 contiguous ticks, with windows stopped at episode boundaries. It is not a fixed hand-authored memory vector.

PPO was retuned around 1,024-tick rollouts, 128-sample minibatches, four epochs, `gamma=0.995`, `GAE lambda=0.97`, policy clip `0.15`, value clip `0.20`, actor learning rate `2.5e-4`, critic learning rate `5e-4`, and target KL `0.02`. The critic uses a clipped value objective with adaptive Huber scale; learning-rate scaling responds to measured rollout KL. GRU parameters use a separate Adam update (`3e-4`, max norm `0.5`) and are saved with Adam moments/step in the `GRU2` checkpoint trailer.

The v7.37 checkpoint migration is a **warm-start, not an exact recurrent-state conversion**: compatible current-frame and eight opponent-habit input columns are copied into the 128-input policy, with reach/damage context mapped where available. Explicit old lag columns and the previous small GRU trace are not semantically equivalent to the new 64-unit GRU and are not copied as if they were. The new GRU starts with its seeded initialization when loading a legacy checkpoint. New checkpoints save the complete GRU optimizer state; weights-only `GRU1` trailers remain readable.

Compatibility: `-Drlpvp.obs126=false` selects the old lag-stack layout for legacy regression/diagnostic use. The compact 128-input layout is the default; compact mode requires GRU shape `H=64`, `X=18`. Existing action semantics, outcome-first reward policy, combat formulas, and camera controller were not replaced by scripted combat behavior or hardcoded aim corrections in this architecture update.

## Important version boundary

- **Fabric mod target remains Minecraft Java 1.21.11** (Fabric Loader 0.18.4, Fabric API 0.141.3+1.21.11, Java 21).
- **Standalone simulator reference bundle:** the decompiled Minecraft 26.3 source files supplied for formula and protocol reference. They are copied under `reference/minecraft-26.3/network/` and are not compiled into the simulator.
- This project does not embed or run a Minecraft dedicated server, Netty, or a real Minecraft client.

## What's new in V10

- Independent client→server and server→client streams for both duel participants.
- Per-episode round-trip ping sampled from the existing lag curriculum (default 20–150 ms at the full-lag stage), with asymmetric one-way splits.
- Per-packet jitter, tick-boundary delivery, approximate bandwidth serialization, reliable ordered delivery, retransmission delay, and TCP-like head-of-line blocking.
- Client-side local movement prediction with changed-input packets, sprint-command packets, and position/rotation/status packets ordered on the same C2S stream as attack requests. A client-tick-end marker is also sent each tick to match the server handler's position-packet guard reset.
- Attack clicks travel through the same ordered client→server stream as movement and sprint state. The server checks its current player replicas and server-side attack cooldown/critical/knockback state when the packet arrives.
- Server knockback and corrective-position responses travel back over the victim's server→client stream.
- Changed server entity/player snapshots are now delivered through each client's actual modeled S2C stream; remote-entity interpolation happens only after packet arrival. Self health/hurt snapshots are delayed on that same stream.
- Network telemetry is appended to parallel-training log lines: sampled RTT, C2S/S2C averages, accepted move packets, attack packets, movement corrections, and TCP retransmission events.
- The V10 network simulator originally kept the prior observation layout. The v7.38 architecture upgrade described above changes that contract to 128 compact inputs and adds trained GRU temporal state; old checkpoint loading uses an explicit warm-start migration.

- Parallel training now shares one synchronized opponent-league ledger across environments; only the designated owner persists it, preventing stale last-writer-wins Elo resets and snapshot/ratings temp-file collisions.
- Parallel training now uses a checkpoint-specific `.league` sidecar and seeds a new output sidecar from the resumed checkpoint's league data when needed, rather than silently starting at the default 1200 Elo.
- PPO checkpoints, league ratings, and policy snapshots use unique temporary files and atomic replacement where supported.
- **Stage 9 competitive self-play:** open-ended PFSP league training against frozen learner snapshots and 11 fixed scripted styles; PFSP increases exposure to opponents that have repeatedly beaten the learner and modestly protects aggressive-specialist coverage.
- **Non-gating champion benchmark (offline parallel trainer):** Stage 9 skips progression probes and collapse-guard rollback. A separate evaluator benchmarks immutable checkpoint copies against every fixed bot style while `sim/train_parallel.sh` or `sim/run.sh` continues, and writes a separate `.champion.bin` only when its held-out composite score improves. The learner checkpoint is never replaced by the champion file. The live Fabric trainer uses the same Stage 9 league sampler and disables Stage 9 collapse rollback, but does not run this offline scripted benchmark.
- **Outcome-first reward balance and audit:** crit/sprint/jump technique labels no longer add standalone reward or generic jump penalties by default. Actual HP damage and episode outcomes remain primary; per-component reward mass, jump/falling/crit opportunities, client-labelled hit types, simulated-server-model confirmations, technique exchange results, and sprint-follow-up conversion are logged for controlled same-checkpoint A/B evaluation.
- **Continuous Minecraft yaw semantics:** player yaw is retained as an unwrapped absolute angle across ticks and movement packets; only target-minus-current angular errors use shortest-arc wrapping. This matches vanilla's unbounded yaw representation and avoids simulator-only modulo discontinuities at angle boundaries. Pitch remains clamped to its physical range.

## Run and test

```sh
sh sim/regression.sh
sh sim/run.sh 1026 /tmp/rlpvp-v10-smoke.bin 20261030 -
sh sim/train_parallel.sh 3000000 /path/to/v10-3m.bin 20261030 - 2 -
```

Network controls:

- `-Drlpvp.lagMinMs=20` and `-Drlpvp.lagMaxMs=150`: RTT range.
- `-Drlpvp.networkJitterStdMs=4`: per-packet Gaussian jitter standard deviation (ms), capped at 10 ms. The older `networkJitterMaxMs` property remains an alias.
- `-Drlpvp.tcpSegmentLoss=0.0005`: probability that a transport segment is delayed for retransmission (application packets are not silently dropped).
- `-Drlpvp.tcpRtoMs=200`: retransmission timeout.
- `-Drlpvp.networkBandwidthMbps=10`: approximate stream serialization rate.
- `-Drlpvp.serverAttackRange=3.0`: stand-alone server attack-distance guard, defaulted to the `3.0` argument used by the supplied server attack handler. It remains an AABB approximation because the full attack-range component implementation was not supplied.
- `-Dsim.latency=false`: disable randomized network delay. Fixed-lag evaluation is exposed through `PvpSim.fixedLag` in one-way game ticks.

## Validation status

- `sh sim/regression.sh`: PASS, including existing simulator/combat/league checks and the new exact-128-input, GRU2 optimizer-resume, PPO clipped-value, symmetry, and v7.37 checkpoint-migration checks.
- Compact simulator smoke: 4,096 ticks completed and a compact checkpoint was saved.
- `sh sim/run.sh 50 /tmp/v10-smoke.bin 123 - -`: baseline V10 smoke command documented above; the v7.38 compact smoke is recorded separately in the v7.38 implementation report.
- Legacy V9/V10 and v7.37 checkpoints require the explicit warm-start migration described in the v7.38 section; an unchanged-layout load is not claimed for the new 128-input policy.
- A full Fabric Gradle build, live Minecraft 1.21.11 differential trace, and full TCP/Netty parity are **not** claimed.
- For v7.38, `tests/run.sh` exceeded the available 120-second command window before the suite completed; the more targeted `sh sim/regression.sh` completed successfully. The Fabric Gradle build could not download Gradle 9.5.1 because the environment had no DNS/network access, so a full Fabric build remains unverified.
- The reward-audit changes pass the Minecraft-free reward, telemetry, discovery, SpamGuard, simulator, and parallel-trainer compile checks when the existing `GameplayRotationCheck` is skipped. The normal `sh tests/run.sh` still stops at four known `GameplayRotationCheck` failures (small-angle correction, 120° overshoot, stability, fine aiming); no reward-related failure was observed before that stop. A full Fabric Gradle build could not be run in the offline environment because the Gradle distribution host was unreachable.
- No training was started and no training checkpoint was modified for the reward-audit update.

See [`docs/REWARD_BALANCE_AUDIT.md`](docs/REWARD_BALANCE_AUDIT.md) for the root-cause review, changed reward defaults, audit CSV columns, limitations, and paired A/B protocol. See `NETWORK_SIMULATOR_GUIDE.md` for the model, exact source files used, approximations, and known gaps. See `VERSION_SEPARATION.md` for the 1.21.11 mod / 26.3 reference split.

See [`docs/STAGE9_COMPETITIVE_LEAGUE.md`](docs/STAGE9_COMPETITIVE_LEAGUE.md) for the Stage 9 competitive league and non-gating champion benchmark.

## Combo-lock / learned strafing patch (2026-11-04)

The v7.38 source now has a learned conditional hold-strafe action, a dedicated combo-pressure curriculum exposure, and incoming-combo/strafe-escape telemetry. Existing v8 policy weights warm-start into v9; retraining is required for the new action to become useful. See [`docs/COMBO_LOCK_STRAFE_FIX_2026-11-04.md`](docs/COMBO_LOCK_STRAFE_FIX_2026-11-04.md) for implementation details, validation, limitations, and the paired evaluation protocol.


## v7.39 target-box perception and trainer reward wiring

- Added two normalized aim observations: horizontal and vertical crosshair displacement measured against the target's projected bounding-box half extents. They are computed from the actual entity AABB in the mod and the matching simulated player box in `PvpSim`.
- Increased the default pitch action scale from 15 to 30 degrees-per-tick-equivalent (yaw remains 45). This raises vertical correction speed, acceleration and jerk authority through the existing physical camera controller; it does not add target-directed steering. The same config is used by live play and the simulator.
- Existing motion-memory target angular-velocity signals remain active; no scripted aim correction, forced rotation, or hardcoded pitch/yaw behaviour was added. The new box offsets only enter the learned observation vector.
- Existing 126-input compact checkpoints are migrated to 128 inputs by preserving the original 126 input columns and zero-initializing the two new input columns. New training is needed for the policy to learn to use them.
- Wired `CombatPositionReward` into `Trainer.java` in TRAIN mode, using the same stage gate, outcomes, and terms as the simulator. The reward is now added before `agent.addReward(reward)`, so it reaches PPO rather than only being logged.
- Added five per-term position reward audit columns and included the same terms in the reward summary.
- The pitch response and input semantics changed, so evaluation or continued training with the updated build is required before deploying an old checkpoint as final. No training run was started for this source update.

## v7.41 — outcome-only continual exploration (2026-11-05)

This update removes the remaining hand-set action-head priors and keeps discovery alive without paying for named techniques:

- **No technique reward:** `OUTCOME_ONLY_REWARDS=true`, `TECHNIQUE_REWARDS_ENABLED=false`, and `TECH_REWARD_SCALE=0.0` remain hard-off. Critical-hit and sprint-hit labels are telemetry only. PPO still learns from real damage differential, win/loss outcomes, and the existing general combat feedback.
- **No technique instructions:** there is no crit/sprint action prior, no conditional action bias, no forced jump/sprint/attack sequence, and no post-policy action rewrite in the default play path. Fresh action-head output biases are neutral. Existing checkpoint actor weights are preserved on resume; only genuinely new output heads in a legacy migration are initialized neutrally.
- **Continuous exploration:** jump and sprint have separate per-head entropy collapse floors of 0.35, with the existing 3x entropy recovery boost. The late-stage entropy taper is removed, so stage 8/9 training does not slowly shut down exploration. The attack head is not entropy-forced because random attacks mostly create whiffs.
- **Policy-only play by default:** `PLAY_STACK=0`, `PLAY_STOCHASTIC=true`, and `PLAY_TEMPERATURE=1.0`. The sampled policy action is applied directly. Optional planner/guard stacks remain available only via an explicit nonzero `-Drlpvp.stack` override.
- **Checkpoint compatibility:** observation size remains 128, action size remains 15, GRU shape and action semantics are unchanged. No new observation columns are added because current observations already include on-ground/sprinting state, own weapon charge, enemy weapon charge, falling/non-sprinting crit eligibility, reach, velocity, line of sight, and recent history. This avoids invalidating a current v7.39 128-input checkpoint.

The 0.35 entropy floors are an exploration safeguard, not a target technique frequency and not a reward. They do not identify a critical-hit or sprint-hit situation and do not choose a technique. State-dependent decisions remain the actor's learned policy, and performance is judged by combat outcomes.

### Continue training from a checkpoint

`sim/train_parallel.sh` takes a **cumulative target tick count**, not an additional-ticks count. For example, to continue a checkpoint saved at 9,000,000 ticks for another 9,000,000 ticks, set the target to 18,000,000:

```sh
JAVA_OPTS="-Dsim.kit=diamond_prot3 -Drlpvp.stack=0" \
  sh sim/train_parallel.sh 18000000 /workspaces/RLPvP/output/rush-punisher-v7.41.bin \
  20261105 /workspaces/RLPvP/checkpoints/latest.bin 3 -
```

Replace the resume path with the actual latest checkpoint and adjust the target to `checkpoint_ticks + desired_additional_ticks`. Keep the old checkpoint untouched so you can roll back. Three workers are retained in this example; use the worker count that fits the Codespaces CPU allocation.

No training run or checkpoint was started/modified while preparing this source update. The user must resume from their own latest `.bin` checkpoint after uploading this project into the workspace.
