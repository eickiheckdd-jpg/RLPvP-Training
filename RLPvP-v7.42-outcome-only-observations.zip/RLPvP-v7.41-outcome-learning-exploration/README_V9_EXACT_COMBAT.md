> **Current v7.41 behavior note (2026-11-05):** the historical v9 description below recorded `PLAY_STACK=2`. The current source defaults to `PLAY_STACK=0` (raw stochastic policy), neutral action-head initialization, no technique action prior, and persistent jump/sprint entropy exploration. See `README.md` and `IMPLEMENTATION_V7_41_OUTCOME_LEARNING_EXPLORATION.md`.

# RLPvP v9 — Minecraft Java 26.3 Exact Combat

RLPvP v9 upgrades the offline PvP training simulator's combat arithmetic to a float-precision port of the supplied Minecraft Java 26.3 reference methods. It retains the existing PPO agent, memory, curriculum, evaluation, and parallel-training pipeline.

## Target kit

- Unenchanted diamond sword
- Full diamond armor
- Protection III on all four armor pieces
- No shield, potions/effects, regeneration, or absorption
- Flat duel arena; no block/UHC simulation

## What's now implemented

- Exact attack cooldown delay and attack-strength scaling expressions.
- Exact 0.2 + strength² × 0.8 base-damage scaling and critical multiplier order.
- Exact critical-hit eligibility conditions for the supported duel.
- Armor/toughness, Resistance, Protection EPF, and absorption stage order.
- Hurt-window raw-damage comparison and excess-damage path.
- Knockback resistance, separate default damage knockback and sprint yaw-directed extra knockback.
- Float-based movement friction, input normalization, Mojang Mth trig lookup for movement, sprint-jump impulse, and sprint knockback, plus jump velocity.
- Separate client/server attack-strength tickers; charge is recalculated when the simulated server handles the attack packet.

## Quick start

Run the focused regression suite:

```sh
./sim/regression.sh
```

Run a headless 1,026-tick smoke training pass:

```sh
./sim/run.sh 1026 /tmp/rlpvp-v9-smoke.bin 20261030 -
```

Train four workers to 3,000,000 ticks:

```sh
./sim/train_parallel.sh 3000000 /path/to/rlpvp-v9-diamond-prot3-3m.bin 20261030 - 4 -
```

The default kit is `diamond_prot3`. Existing model/checkpoint compatibility is retained by the existing PpoAgent serialization format.

## Verification performed for this v9 package

- `sh sim/regression.sh` — PASS: 43 outcome checks, 12 sprint-follow-up checks, combat-observation memory, 25 movement/trig checks, kit/rules checks, 27 Diamond Prot III checks, and 34 exact-combat checks.
- Single-environment smoke training — PASS: 1,026 ticks, stage 1 checkpoint written.
- Two-environment parallel smoke training — PASS: 1,026 learner ticks, stage 1 checkpoint written.
- The broader legacy `tests/run.sh` suite is not fully clean: `GameplayRotationCheck` has four existing camera-control assertions failing. Those are separate from the focused combat regression suite.
- Fabric mod target restored to Minecraft 1.21.11, Fabric Loader 0.18.4, Fabric API 0.141.3+1.21.11, and Java 21. The standalone simulator still references Minecraft 26.3 formulas. A full Fabric/Gradle build remains unverified in this runtime.

## Fidelity honesty

This is an exact-formula port for the supported combat path, not the actual Minecraft server runtime. The offline world, full swept-AABB block collision, fluids/climbables, arbitrary components/enchantments, client raycast and complete packet processing are still simplified or incomplete. The current test environment also cannot build the Fabric mod because its installed JDK is 21 while the Minecraft 26.3 toolchain requires Java 25, and Gradle distribution download is unavailable in this network-restricted runtime. No live-server differential trace validation has yet been completed. See `docs/MINECRAFT_26_3_EXACT_PORT.md` for formula provenance, test scope, and known gaps.

## v7.35 measured intelligence merge

The v9 simulator retains the Minecraft 26.3 combat port; the playable Fabric mod target remains Minecraft 1.21.11. The default play configuration remains `PLAY_STACK=2`, `INTEL_OFF=127`: the policy and validated learned consequence-model candidate search remain active, persistent opponent memory is provided as existing policy inputs, and hand-authored strategic scoring, guidance and action enforcement are disabled. The reactive feasibility guard remains active only for non-finite/invalid actions, impossible current attacks, contradictory sprint combinations and boundary traps. This default avoids silently replacing the policy's combat choices with scripted rules. Use `-Drlpvp.intelOff=96` for the older enforcement-enabled configuration, or `=0` for full heuristic A/B tests. An opt-in `PLAY_STACK=3` learned-only mode also skips the intelligence-suite's strategic update path. Modes are `0=policy`, `1=heuristic planner`, `2=planner + measured intelligence`, `3=learned-only`; use `-Drlpvp.stack=0|1|2|3` and `-Drlpvp.intelOff=<mask>`. Persistent player profiles reuse the existing eight trained opponent-habit inputs; they do not add network dimensions or scripted actions. See `docs/AI_INTELLIGENCE_IMPLEMENTATION_2026-10-31.md` for the implementation and bug-review details, plus `MERGE_V7_35_MEASURED_INTO_V9.md` and `docs/combatbench_v7.35_result.txt` for prior provenance.

For a fresh run from random initialization, use `sh sim/train_fresh_3m.sh /path/to/fresh-3m.bin 20261030 2`. The script passes no resume checkpoint and pins the `diamond_prot3` kit.
