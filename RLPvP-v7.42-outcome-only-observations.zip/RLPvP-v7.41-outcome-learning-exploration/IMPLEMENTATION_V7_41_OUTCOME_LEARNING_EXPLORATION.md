# v7.41 implementation report — outcome-only continual exploration

Date: 2026-11-05

## Objective

Let the PPO actor independently discover when critical hits and sprint hits are useful, without named-technique rewards, technique-specific action rules, or post-policy action substitution.

## Changes

1. Kept the reward guard unchanged: outcome-only reward mode is active, technique rewards are disabled, and the technique reward scale is zero. `TechniqueDiscovery` and related hit-type instrumentation continue to measure events but contribute no PPO reward.
2. Replaced fresh-policy action-output priors with neutral action-head biases. Every discrete action-head output bias begins at zero; the network still has small random state-dependent weights, but no fixed intercept favors an action. Camera effort standard deviation initialization remains unchanged.
3. Changed checkpoint migration so action heads absent from an older checkpoint are initialized with neutral logits rather than a sneak/hold-strafe preference. Existing trained action weights are not overwritten when resuming a checkpoint of the current architecture.
4. Added an independent 0.35 entropy floor for both jump and sprint heads. When the running entropy of either head falls below its floor, PPO increases only that head's entropy regularization by the existing 3x boost. No state-specific logits are edited and no action is forced.
5. Removed the stage-8/9 entropy taper. The base entropy coefficient remains at its configured level during long-running self-play so exploration does not fade simply because more ticks elapsed.
6. Changed the default play stack to 0 (raw stochastic policy). The default no longer calls the optional planner, reactive feasibility guard, or hand-authored tactical rewrite path. The policy samples discrete choices at temperature 1.0.
7. Preserved the 128-input observation layout and 15-output action layout for checkpoint compatibility. Current-frame features already include on-ground state, sprint state, attack charge, enemy charge, crit eligibility, reach, and line-of-sight data.

## What this does not do

- It does not guarantee that every episode contains both techniques.
- It does not reward critical-hit or sprint-hit frequency.
- It does not hardcode when to jump, sprint, attack, or release either movement input.
- It does not automatically start training, locate an external checkpoint, or modify a checkpoint file.

The entropy floors preserve sampling variety, but the learned actor still decides how actions correlate with combat state. A technique will become more common only if PPO's outcome feedback supports it in the encountered states.

## Validation

`sim/regression.sh` includes the new `OutcomeLearningExplorationCheck`, which checks reward-off settings, persistent late-stage entropy, jump/sprint entropy floors, raw stochastic play mode, neutral fresh action-head biases, finite policy logits, and unchanged network dimensions. Existing technique reward policy checks continue to verify that technique telemetry never adds reward.
