package com.rlpvp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Random;

/**
 * Online PPO (actor-critic, clipped objective, GAE) that learns while the game runs.
 *
 * Every tick the trainer calls:
 *   addReward(r)      reward caused by the previous action
 *   actTrain(obs)     sample an action (also stores the transition)
 *   learnTick()       one minibatch gradient step if a finished rollout is waiting
 *
 * Experience goes into a double buffer: while the next ROLLOUT ticks are being collected, the
 * learner works through the previous rollout, one MINIBATCH-sized gradient step per tick, so the
 * game never stalls on a big update. Each stored transition keeps the log-prob of the policy that
 * acted, so PPO's ratio/clipping stays correct even though the policy keeps changing.
 *
 * The policy is factorised: 2 Gaussian heads (yaw delta, pitch delta = continuous mouse movement, each
 * a mean and a log-std), 2 categorical heads (forward, strafe), 4 Bernoulli heads (attack, jump, sprint, sneak),
 * plus a conditional Bernoulli hold-strafe branch. Action vector: {yaw, pitch, fwd, strafe, attack, jump, sprint, sneak, holdStrafe}.
 * Hold-strafe is sampled only when the strafe category is neutral; it continues the previous lateral direction if one exists.
 *
 * No Minecraft classes here, so it can be tested offline.
 */
final class PpoAgent {
    static final int N_ACT = 9; // yaw, pitch, fwd, strafe, attack, jump, sprint, sneak, conditional hold-strafe
    private static final int[] GAUSS_OFF = {Config.OFF_YAW, Config.OFF_PITCH};
    private static final int[] CAT_OFF = {Config.OFF_FWD, Config.OFF_STRAFE};
    private static final double HALF_LOG_2PI = 0.5 * Math.log(2 * Math.PI);
    private static final double LOG_2 = Math.log(2.0), LOG_3 = Math.log(3.0);
    private static final int[] BERN_IDX = {Config.OFF_ATTACK, Config.OFF_JUMP, Config.OFF_SPRINT, Config.OFF_SNEAK};

    private static final int MAGIC = 0x524C5050; // "RLPP"
    private static final int VERSION = 9; // adds a learned conditional hold-strafe action; v8 and older warm-start

    final Net actor;
    final Net critic;
    private final ConsequenceModel consequences;
    // Play-only hybrid situational layer. Training samples directly from PPO to preserve its likelihood ratios.
    private final SituationalCombatStack situational = new SituationalCombatStack();
    // ---- trainable GRU memory (GruCell / OpponentMemory): the cell, the per-tick context of the transition in flight and replay scratch ----
    private final GruCell gru = new GruCell();
    private final float[] cH = new float[GruCell.H], cX = new float[GruCell.X], pH = new float[GruCell.H], pX = new float[GruCell.X];
    private final float[] obsTmp = new float[Config.OBS_SIZE], gruGrad = new float[GruCell.H];
    private final float[] playObs = new float[Config.OBS_SIZE];

    // Optional exact GRU replay prefetch: a private forward-only cell prepares the next sample while
    // the learner computes the current sample's policy/value gradients and GRU backward pass.
    // The trainable GRU, its gradient accumulation order, and its optimizer remain on the learner thread.
    private GruCell replayGru;
    private final float[][] prefetchedObs = { new float[Config.OBS_SIZE], new float[Config.OBS_SIZE] };
    private final Object prefetchMonitor = new Object();
    private Thread prefetchThread;
    private boolean prefetchRequested, prefetchDone, prefetchShutdown;
    // Snapshot inputs on the learner thread so a dropped rollout can be recycled without
    // waiting for the forward-only worker to finish reading from it.
    private final float[] prefetchInitialH = new float[GruCell.H];
    private final float[][] prefetchInputs = new float[Config.GRU_BPTT][GruCell.X];
    private int prefetchSteps;
    private float[] prefetchOutput;
    private Throwable prefetchFailure;
    private boolean prefetchDisabled;
    private static final int GRU_TRAILER_MAGIC_V1 = 0x47525531; // "GRU1": historical weights-only trailer
    private static final int GRU_TRAILER_MAGIC = 0x47525532;    // "GRU2": weights + Adam moments/step
    private static final int SITUATIONAL_TRAILER_MAGIC = 0x53495431; // "SIT1": optional play-side memory after GRU
    private final Random rng;

    long totalTicks = 0;
    /** Curriculum progress, saved with the agent (see Curriculum.restore). */
    int stage = 1;
    long stageEnterTicks = 0;
    int updates = 0;       // finished rollouts that were fully trained on
    int skipped = 0;       // rollouts cut short (KL early stop) or dropped
    /** Technique-discovery annealing clock (training ticks with technique weight > 0). Saved in an optional trailer. */
    long techTicks = 0;
    private static final int TRAILER_MAGIC = 0x54454348; // "TECH": optional trailer after the consequence section
    private static final java.util.Set<Path> BACKED_UP = java.util.concurrent.ConcurrentHashMap.newKeySet();

    // ---- scratch ----
    private final float[] p = new float[Config.ACTION_SIZE];
    private final float[] ls = new float[Config.ACTION_SIZE];
    private final float[] gz = new float[Config.ACTION_SIZE];
    private final float[] dV = new float[1];
    private final float[] logitsCopy = new float[Config.ACTION_SIZE];
    private final float[] action = new float[N_ACT];
    private double lastEntropy;
    private final java.util.Random playRng = new java.util.Random(0x5eedL); // play-mode sampling must not disturb the training RNG stream
    // Per-head entropy floors keep forward/back, strafe, jump and sprint exploration alive.
    private final double[] headEntEma = new double[4];
    private final boolean[] headEmaInit = new boolean[4];
    private final float[] headBoost = {1f, 1f, 1f, 1f};
    private final double[] bernEnt = new double[BERN_IDX.length];
    private double lastRatio;
    private boolean lastClipped;

    // ---- curriculum hooks (temporary action locks + entropy boost) ----
    private int curMask = 0;      // ActionMask bits applied to new actions
    private int pMask = 0;        // mask that was active when the pending action was sampled
    private float entropyCoef = Config.ENTROPY_COEF;
    private final float[] zMasked = new float[Config.ACTION_SIZE];
    // symmetric policy: a second view of the actor for the mirrored observation (shares weights and gradients)
    private final Net twin;
    private final float[] zA = new float[Config.ACTION_SIZE];
    private final float[] obsM = new float[Config.OBS_SIZE];
    private final float[] gzA = new float[Config.ACTION_SIZE];
    private final float[] gzB = new float[Config.ACTION_SIZE];

    // One-step model-based action search used only in PLAY. Training continues to sample directly
    // from the PPO policy so its stored log-probabilities remain mathematically correct.
    private static final int PLAN_CANDIDATES = 12;
    private static final double PLAN_MIN_GAIN = 0.02; // avoid reranking on tiny model-score differences
    private final float[] planNextFrame = new float[Config.FRAME];
    private final float[] planFutureObs = new float[Config.OBS_SIZE];
    private final float[] planCandidate = new float[N_ACT];
    private final float[] planBest = new float[N_ACT];

    // ---- pending transition (state seen, action taken, waiting for its reward) ----
    private final float[] pObs = new float[Config.OBS_SIZE];
    private final float[] pAct = new float[N_ACT];
    private float pLogp, pVal, pRew;
    private boolean hasPending = false;

    // ---- double buffer ----
    private static final class Rollout {
        final float[][] obs = new float[Config.ROLLOUT][Config.OBS_SIZE];
        final float[][] act = new float[Config.ROLLOUT][N_ACT];
        final float[] logp = new float[Config.ROLLOUT];
        final float[] val = new float[Config.ROLLOUT];
        final float[] rew = new float[Config.ROLLOUT];
        final float[] boot = new float[Config.ROLLOUT];
        final boolean[] done = new boolean[Config.ROLLOUT];
        final float[] adv = new float[Config.ROLLOUT];
        final float[] ret = new float[Config.ROLLOUT];
        final int[] mask = new int[Config.ROLLOUT]; // lock mask the action was sampled under
        final float[][] hPrev = new float[Config.ROLLOUT][GruCell.H]; // GRU state BEFORE this tick's update, as acted
        final float[][] gx = new float[Config.ROLLOUT][GruCell.X];    // the GRU input of this tick
        int n = 0;
    }

    private Rollout fill = new Rollout();
    private Rollout train = new Rollout();
    private boolean trainReady = false;
    private final int[] perm = new int[Config.ROLLOUT];
    private int epoch = 0;
    private int mbIdx = 0;
    // A minibatch may be spread over several client frames. Gradients, sample order,
    // normalization count, and optimizer step remain one indivisible PPO minibatch.
    private int mbSampleOffset;
    private double mbKl, mbEnt, mbVloss;
    private int mbClipped;
    private boolean mbUsePrefetchBatch, mbInitialized;

    // ---- rolling stats (reset by takeStats) ----
    private int stSteps;
    private double stKl, stEnt, stClip, stVLoss, stGrad;
    private int stSamples;
    private double rolloutKlSum;
    private int rolloutKlBatches;

    PpoAgent(long seed) {
        this.rng = new Random(seed);
        this.actor = new Net(actorSizes(), 0.01f, rng);
        this.twin = actor.twin();
        this.critic = new Net(criticSizes(), 1.0f, rng);
        this.consequences = new ConsequenceModel(rng);
        applyNeutralActionInitialization(actor.w);
        if (gruTrainOn()) {
            int slot = OpponentMemory.slotStart();
            actor.trackInput(slot, GruCell.H); twin.trackInput(slot, GruCell.H); critic.trackInput(slot, GruCell.H);
        }
        for (int i = 0; i < perm.length; i++) perm[i] = i;
    }

    private static boolean gruTrainOn() { return Config.MEMORY && Config.GRU_TRAIN; }

    /** The GRU cell the environments should run (OpponentMemory.useCell): this agent's trained one. */
    GruCell gruCell() { return gru; }

    /** Call once per tick BEFORE actTrain: the GRU's hidden state before this tick's update and this tick's cell input. */
    void noteMemory(float[] hBefore, float[] x) {
        System.arraycopy(hBefore, 0, cH, 0, GruCell.H);
        System.arraycopy(x, 0, cX, 0, GruCell.X);
    }

    private static int[] actorSizes() {
        return sizes(Config.ACTION_SIZE);
    }

    private static int[] criticSizes() {
        return sizes(1);
    }

    private static int[] sizes(int out) {
        return sizes(out, Config.OBS_SIZE);
    }

    private static int[] sizes(int out, int obsSize) { return sizes(out, obsSize, Config.HIDDEN); }

    private static int[] sizes(int out, int obsSize, int[] hidden) {
        int[] s = new int[hidden.length + 2];
        s[0] = obsSize;
        System.arraycopy(hidden, 0, s, 1, hidden.length);
        s[s.length - 1] = out;
        return s;
    }

    /** Match the current or immediately previous policy-head width for older observation-layout migrations. */
    private static int matchingLegacyActionSize(int actorParams, int criticParams, int inputSize, int[] hidden) {
        for (int out : new int[]{Config.ACTION_SIZE, Config.ACTION_SIZE_PRE_HOLD_STRAFE}) {
            if (actorParams == Net.paramCount(sizes(out, inputSize, hidden))
                    && criticParams == Net.paramCount(sizes(1, inputSize, hidden))) return out;
        }
        return -1;
    }

    private static int[][] knownHiddenShapes() {
        java.util.ArrayList<int[]> shapes = new java.util.ArrayList<>();
        shapes.add(new int[]{128, 128}); shapes.add(new int[]{256, 256}); shapes.add(new int[]{256, 256, 128}); shapes.add(new int[]{960, 960}); shapes.add(new int[]{1024, 1024, 512});
        shapes.add(Config.HIDDEN.clone());
        if (Config.TRANSFER_FROM != null) shapes.add(Config.TRANSFER_FROM.clone());
        return shapes.toArray(new int[0][]);
    }
    private static boolean canWiden(int[] from, int[] to) {
        if (from.length != to.length) return false;
        for (int i = 0; i < from.length; i++) if (from[i] > to[i]) return false;
        return true;
    }

    private static int[] identityMap(int n) {
        int[] map = new int[n]; for (int i = 0; i < n; i++) map[i] = i; return map;
    }

    /**
     * Neutral policy initialization. Every action-head output bias starts at zero, so no fixed
     * logit offset preselects movement, attack, jump, sprint, sneak or continuation. The network
     * may still emit state-dependent logits from its small random weights; PPO learns their useful
     * state/action relationships from outcome feedback.
     */
    private static void applyNeutralActionInitialization(float[] w) {
        int ob = w.length - Config.ACTION_SIZE; // output biases are the last ACTION_SIZE floats
        // Camera means start neutral; retain the calibrated small hand-effort exploration std.
        w[ob + Config.OFF_YAW] = 0.0f;
        w[ob + Config.OFF_PITCH] = 0.0f;
        w[ob + Config.OFF_YAW + 1] = (float) Math.log(Config.LOOK_STD_INIT);
        w[ob + Config.OFF_PITCH + 1] = (float) Math.log(Config.LOOK_STD_INIT);
        for (int i = Config.OFF_FWD; i < Config.ACTION_SIZE; i++) w[ob + i] = 0.0f;
    }

    // ------------------------------------------------------------------ acting
    /** Sample an action and remember the transition. The returned array is reused: use it right away. */
    float[] actTrain(float[] obs) {
        policyLogits(obs, logitsCopy);
        ActionMask.apply(logitsCopy, curMask); // temporary curriculum locks: locked heads can only pick their neutral choice
        float v = critic.forward(obs)[0];
        sampleAction(logitsCopy, curMask, rng, action);
        float logp = (float) evalPolicy(logitsCopy, action, curMask, 0f, 0f, null);
        updateHeadEntropy();

        if (hasPending) {
            // The previous action's actual next frame is supervised feedback for the consequence model.
            consequences.observe(pObs, pAct, obs);
            commit(false, 0f, v);
        }
        System.arraycopy(obs, 0, pObs, 0, obs.length);
        System.arraycopy(cH, 0, pH, 0, GruCell.H);
        System.arraycopy(cX, 0, pX, 0, GruCell.X);
        System.arraycopy(action, 0, pAct, 0, N_ACT);
        pLogp = logp;
        pMask = curMask;
        pVal = v;
        pRew = 0f;
        hasPending = true;
        totalTicks++;
        return action;
    }

    /** Most likely action, no learning, nothing stored (for /rl play). */
    /** Tracks movement/jump/sprint entropy independently and boosts only a collapsed action head. */
    private void updateHeadEntropy() {
        // Keep the per-tick training path allocation-free. The old temporary now/max/lock arrays
        // allocated three objects on every action even though all four entries are fixed.
        for (int i = 0; i < 4; i++) {
            final double now;
            final double max;
            final int lock;
            switch (i) {
                case 0 -> { now = headEnt[0]; max = LOG_3; lock = ActionMask.LOCK_FWD; }
                case 1 -> { now = headEnt[1]; max = LOG_3; lock = ActionMask.LOCK_STRAFE; }
                case 2 -> { now = bernEnt[1]; max = LOG_2; lock = ActionMask.LOCK_JUMP; }
                default -> { now = bernEnt[2]; max = LOG_2; lock = ActionMask.LOCK_SPRINT; }
            }
            if ((curMask & lock) != 0) { headBoost[i] = 1f; headEmaInit[i] = false; continue; } // locked: nothing to explore
            headEntEma[i] = headEmaInit[i] ? 0.99 * headEntEma[i] + 0.01 * now : now;
            headEmaInit[i] = true;
            final double floor = switch (i) {
                case 1 -> Config.STRAFE_ENTROPY_FLOOR_FRAC;
                case 2 -> Config.JUMP_ENTROPY_FLOOR_FRAC;
                case 3 -> Config.SPRINT_ENTROPY_FLOOR_FRAC;
                default -> Config.HEAD_ENTROPY_FLOOR_FRAC;
            };
            headBoost[i] = headEntEma[i] < floor * max ? Config.HEAD_ENTROPY_BOOST : 1f;
        }
    }

    /** Multiplier currently applied to a head's entropy bonus (0 fwd/back, 1 strafe, 2 jump, 3 sprint). */
    float headBoost(int head) { return headBoost[head]; }

    /**
     * The policy as it is PLAYED (/rl play, the simulator's evaluation and probes): camera = mean (no sampling noise), discrete heads
     * sampled from the trained distribution at Config.PLAY_TEMPERATURE. actGreedy (argmax) can never choose a minority action, so it
     * reports one-sided strafing and zero jumps/back-steps/crits for a policy that actually mixes them. Uses its own RNG.
     */
    float[] actPlay(float[] obs) {
        float[] policyObs = obs;
        if (Config.PLAY_STACK > 0) {
            java.util.Arrays.fill(playObs, 0f);
            System.arraycopy(obs, 0, playObs, 0, Math.min(obs.length, playObs.length));
            // Update causal event memory and the persistent opponent profile BEFORE the actor sees
            // this frame, so the learned policy can adapt to named opponents across encounters.
            situational.beginTick(playObs);
            situational.applyOpponentHistory(playObs);
            policyObs = playObs;
        }
        float[] z;
        if (!Config.PLAY_STOCHASTIC) {
            actGreedy(policyObs);
            z = zMasked;
        } else {
            policyLogits(policyObs, zMasked);
            ActionMask.apply(zMasked, curMask);
            z = zMasked;
            final double t = Math.max(0.05, Config.PLAY_TEMPERATURE);
            action[0] = clampLook(z[Config.OFF_YAW] * (float) Math.exp(logStd(z[Config.OFF_YAW + 1])));
            action[1] = ActionMask.pitchLocked(curMask) ? 0f : clampLook(z[Config.OFF_PITCH] * (float) Math.exp(logStd(z[Config.OFF_PITCH + 1])));
            for (int h = 0; h < 2; h++) {
                int off = CAT_OFF[h];
                double max = Math.max(z[off], Math.max(z[off + 1], z[off + 2])) / t;
                double e0 = Math.exp(z[off] / t - max), e1 = Math.exp(z[off + 1] / t - max), e2 = Math.exp(z[off + 2] / t - max);
                double u = playRng.nextDouble() * (e0 + e1 + e2);
                action[2 + h] = u < e0 ? 0 : (u < e0 + e1 ? 1 : 2);
            }
            for (int b = 0; b < BERN_IDX.length; b++) {
                double pr = 1.0 / (1.0 + Math.exp(-z[BERN_IDX[b]] / t));
                action[4 + b] = playRng.nextDouble() < pr ? 1 : 0;
            }
            if (Math.round(action[3]) == 1 && !ActionMask.isStrafeLocked(curMask)) {
                double ph = 1.0 / (1.0 + Math.exp(-z[Config.OFF_HOLD_STRAFE] / t));
                action[8] = playRng.nextDouble() < ph ? 1f : 0f;
            } else action[8] = 0f;
        }

        // Stack=0 is a true policy-only baseline for controlled A/B evaluation.
        if (Config.PLAY_STACK <= 0) return action;

        // Stack 3 is the learned-only path: the policy chooses its own behavior, and only the
        // validated learned consequence model may rerank policy-sampled alternatives. All stack
        // modes retain the final feasibility guard; strategic action rewriting is opt-in by mask.
        if (consequences.planningReady()) planWithPredictedConsequences(policyObs, z, curMask, action);
        boolean heuristicCandidatePath = (Config.INTEL_OFF & (32 | 64)) != (32 | 64);
        if (Config.PLAY_STACK < 3 && heuristicCandidatePath)
            planWithSituationalContext(policyObs, z, curMask, action);
        float attackGate = attackStrengthGate();
        situational.enforce(action, curMask, attackGate);
        situational.finishTick(policyObs, action, curMask, attackGate);
        return action;
    }

    /**
     * Ranks a policy-sampled baseline and plausible alternatives using the learned outcome model (when validated),
     * the value critic's one-step score, context-sensitive combat estimates, and a small PPO-likelihood trust term.
     * This is play-only: PPO training transitions always retain the exact sampled action/log-probability.
     */
    static void preserveCameraCommand(float[] candidate, float[] baseline) {
        candidate[0] = baseline[0];
        candidate[1] = baseline[1];
    }

    private void planWithSituationalContext(float[] obs, float[] maskedLogits, int mask, float[] baseline) {
        System.arraycopy(baseline, 0, planBest, 0, N_ACT);
        double baseLogp = evalPolicy(maskedLogits, planBest, mask, 0f, 0f, null);
        double baseWorld = consequences.planningReady() ? scorePredictedAction(obs, planBest) : 0.0;
        double bestScore = situational.scoreCandidate(planBest, baseWorld);
        double bestTotal = bestScore;
        final int candidates = 10;
        for (int i = 0; i < candidates; i++) {
            sampleAction(maskedLogits, mask, playRng, planCandidate);
            planCandidate[0] = clampLook(planCandidate[0]);
            planCandidate[1] = ActionMask.pitchLocked(mask) ? 0f : clampLook(planCandidate[1]);
            mutateCandidate(mask);
            situational.guideCandidate(planCandidate, mask, playRng);
            // Camera rotation is continuous motor control, not a tactical branch. Candidate resampling
            // made the look direction jump between alternatives every tick (visible as left/right head shake).
            preserveCameraCommand(planCandidate, baseline);
            double lp = evalPolicy(maskedLogits, planCandidate, mask, 0f, 0f, null);
            double world = consequences.planningReady() ? scorePredictedAction(obs, planCandidate) : 0.0;
            double score = situational.scoreCandidate(planCandidate, world) + 0.075 * Math.max(-4.0, Math.min(2.0, lp - baseLogp));
            if (score > bestTotal + 0.075) {
                bestTotal = score;
                System.arraycopy(planCandidate, 0, planBest, 0, N_ACT);
            }
        }
        System.arraycopy(planBest, 0, baseline, 0, N_ACT);
    }

    /** Status and external context hooks used by Trainer; no effect on training action selection. */
    /** Reset only the play-time sampler for repeatable, isolated held-out evaluations. */
    void resetPlayRandom(long seed) { playRng.setSeed(seed); }

    void resetSituationalEpisode(String opponentKey) { situational.beginEpisode(opponentKey); }
    void notePlaySwingResult(boolean clickQueued, boolean targetOnRay) {
        situational.recordAppliedSwing(clickQueued, targetOnRay);
    }
    void setSituationalBoundary(float proximity, float inwardForward, float inwardRight) {
        situational.setBoundaryContext(proximity, inwardForward, inwardRight);
    }
    String situationalStatus() { return situational.status(); }
    String situationalIntent() { return situational.intentName(); }
    double situationalConfidence() { return situational.intentConfidence(); }
    long situationalInterventions() { return situational.safetyInterventions(); }
    long situationalRejectedAttacks() { return situational.rejectedAttacks(); }
    long situationalCorrectedSprints() { return situational.correctedSprints(); }
    long situationalBoundaryCorrections() { return situational.boundaryCorrections(); }

    /**
     * Evaluates a small pool of candidate actions with the learned one-step dynamics model. No move
     * type receives an intrinsic bonus; candidates are ranked by predicted combat outcomes plus the
     * critic's estimate of future return in the predicted next state.
     */
    private void planWithPredictedConsequences(float[] obs, float[] maskedLogits, int mask, float[] baseline) {
        System.arraycopy(baseline, 0, planBest, 0, N_ACT);
        double bestScore = scorePredictedAction(obs, planBest);
        for (int i = 0; i < PLAN_CANDIDATES; i++) {
            sampleAction(maskedLogits, mask, playRng, planCandidate);
            planCandidate[0] = clampLook(planCandidate[0]);
            planCandidate[1] = ActionMask.pitchLocked(mask) ? 0f : clampLook(planCandidate[1]);
            mutateCandidate(mask);
            // Keep the policy's camera command fixed while evaluating alternative discrete actions.
            preserveCameraCommand(planCandidate, baseline);
            double score = scorePredictedAction(obs, planCandidate);
            if (score > bestScore + PLAN_MIN_GAIN) {
                bestScore = score;
                System.arraycopy(planCandidate, 0, planBest, 0, N_ACT);
            }
        }
        System.arraycopy(planBest, 0, baseline, 0, N_ACT);
    }

    /** Mutates a generic action head, not a named combat technique; locked curriculum heads stay locked. */
    private void mutateCandidate(int mask) {
        if (playRng.nextDouble() < 0.65) {
            for (int attempt = 0; attempt < 6; attempt++) {
                int head = playRng.nextInt(6);
                switch (head) {
                    case 0:
                        if ((mask & ActionMask.LOCK_FWD) == 0) { planCandidate[2] = playRng.nextInt(3); return; }
                        break;
                    case 1:
                        if ((mask & ActionMask.LOCK_STRAFE) == 0) { planCandidate[3] = playRng.nextInt(3); return; }
                        break;
                    case 2:
                        if ((mask & ActionMask.LOCK_ATTACK) == 0) { planCandidate[4] = playRng.nextBoolean() ? 1f : 0f; return; }
                        break;
                    case 3:
                        if ((mask & ActionMask.LOCK_JUMP) == 0) { planCandidate[5] = playRng.nextBoolean() ? 1f : 0f; return; }
                        break;
                    case 4:
                        if ((mask & ActionMask.LOCK_SPRINT) == 0) { planCandidate[6] = playRng.nextBoolean() ? 1f : 0f; return; }
                        break;
                    case 5:
                        if ((mask & ActionMask.LOCK_SNEAK) == 0) { planCandidate[7] = playRng.nextBoolean() ? 1f : 0f; return; }
                        break;
                }
            }
        } else {
            // Continuous yaw/pitch are intentionally not mutated; only discrete movement/technique heads vary.
            // This prevents a planner candidate from injecting tick-to-tick left/right aim reversals.
        }
    }

    private float attackStrengthGate() {
        return stage >= Config.GATE_RELAX_STAGE ? Config.MIN_ATTACK_STRENGTH_LATE : Config.MIN_ATTACK_STRENGTH;
    }

    private double scorePredictedAction(float[] obs, float[] candidate) {
        consequences.predict(obs, candidate, planNextFrame);
        buildPredictedObservation(obs, planNextFrame, planFutureObs);

        // Generic outcome objective: predicted health advantage. No critical/sprint/combo/strafe labels.
        double immediate = Config.W_DAMAGE * ((obs[15] - planNextFrame[15]) - (obs[0] - planNextFrame[0]));
        boolean enemyDead = planNextFrame[15] <= 0.005f;
        boolean meDead = planNextFrame[0] <= 0.005f;
        if (enemyDead) immediate += Config.W_WIN;
        if (meDead) immediate -= Config.W_WIN;

        // Keep the existing direct, outcome-grounded pointless-swing penalty; never reward a technique identity.
        double dist = obs[12] * 6.0;
        double gate = attackStrengthGate();
        if (candidate[4] > 0.5f && obs[6] >= gate
                && Reward.isPointlessWhiff(dist, Math.abs(obs[13]), Math.abs(obs[14]))) {
            immediate -= Config.WHIFF_PENALTY;
        }

        double future = (enemyDead || meDead) ? 0.0 : critic.forward(planFutureObs)[0];
        return immediate * Config.REWARD_SCALE + Config.GAMMA * future;
    }

    /** Builds a plausible t+1 stack: predicted frame at lag 0, existing recent frames shifted back one slot. */
    private static void buildPredictedObservation(float[] current, float[] predictedFrame, float[] out) {
        System.arraycopy(current, 0, out, 0, Config.OBS_SIZE);
        System.arraycopy(predictedFrame, 0, out, 0, Config.FRAME);
        if (Config.COMPACT_126) return; // GRU/context slots are held constant for the one-step model prediction.
        for (int targetSlot = 1; targetSlot < Config.LAGS.length; targetSlot++) {
            int sourceSlot = targetSlot - 1;
            int targetOffset = ObsLayout.offset(Config.LAGS, targetSlot, Config.FRAME, Config.FAR_FEATURES.length);
            int sourceOffset = ObsLayout.offset(Config.LAGS, sourceSlot, Config.FRAME, Config.FAR_FEATURES.length);
            if (ObsLayout.near(Config.LAGS[targetSlot])) {
                System.arraycopy(current, sourceOffset, out, targetOffset, Config.FRAME);
            } else {
                for (int j = 0; j < Config.FAR_FEATURES.length; j++) {
                    int feature = Config.FAR_FEATURES[j];
                    int sourceIndex;
                    if (ObsLayout.near(Config.LAGS[sourceSlot])) sourceIndex = sourceOffset + feature;
                    else sourceIndex = sourceOffset + j;
                    out[targetOffset + j] = current[sourceIndex];
                }
            }
        }
        // Hit-memory summary is retained as the closest available estimate; it updates on the next real observation.
    }

    String consequenceStatus() {
        if (consequences.planningReady()) {
            return "planning=ON, world-model samples=" + consequences.transitions()
                + ", validation MAE=" + String.format(java.util.Locale.ROOT, "%.3f", consequences.validationMae());
        }
        String err = Double.isNaN(consequences.validationMae()) ? "n/a"
            : String.format(java.util.Locale.ROOT, "%.3f", consequences.validationMae());
        return "planning=warming up, world-model samples=" + consequences.transitions() + ", validation MAE=" + err;
    }

    /**
     * The actor's logits for one observation. With SYMMETRIC_POLICY they are the average of the plain pass and the mirrored pass
     * (see Symmetry), so the policy is exactly left/right symmetric; otherwise the plain network output.
     */
    private void policyLogits(float[] obs, float[] dest) {
        float[] z = actor.forward(obs);
        if (!Config.SYMMETRIC_POLICY) {
            System.arraycopy(z, 0, dest, 0, z.length);
            return;
        }
        System.arraycopy(z, 0, zA, 0, z.length);
        Symmetry.obs(obs, obsM);
        float[] zm = twin.forward(obsM);
        Symmetry.logits(zA, zm, dest);
    }

    /** Test hook: the logits the policy would act on for this observation (no locks applied). */
    float[] logitsFor(float[] obs) {
        float[] out = new float[Config.ACTION_SIZE];
        policyLogits(obs, out);
        return out;
    }


    /** Learning-rate multiplier. The collapse guard lowers it after each rollback so the same drift is less likely to repeat. */
    volatile float lrScale = 1f;
    /** Late-stage learning-rate taper set by the trainer (Config.stageLrScale); 1 = none. Independent of the KL-adaptive lrScale. */
    volatile float lateLrScale = 1f;
    /** Huber delta of the critic loss (adapts to the return scale, see finishRollout). */
    private float valueDelta = 1f;

    float[] actGreedy(float[] obs) {
        policyLogits(obs, zMasked);
        ActionMask.apply(zMasked, curMask);
        float[] z = zMasked;
        action[0] = clampLook(z[Config.OFF_YAW] * (float) Math.exp(logStd(z[Config.OFF_YAW + 1])));
        action[1] = ActionMask.pitchLocked(curMask) ? 0f : clampLook(z[Config.OFF_PITCH] * (float) Math.exp(logStd(z[Config.OFF_PITCH + 1])));
        for (int h = 0; h < 2; h++) {
            int best = 0;
            for (int i = 1; i < 3; i++) if (z[CAT_OFF[h] + i] > z[CAT_OFF[h] + best]) best = i;
            action[2 + h] = best;
        }
        for (int b = 0; b < BERN_IDX.length; b++) action[4 + b] = z[BERN_IDX[b]] > 0f ? 1 : 0;
        action[8] = Math.round(action[3]) == 1 && !ActionMask.isStrafeLocked(curMask) && z[Config.OFF_HOLD_STRAFE] > 0f ? 1f : 0f;
        return action;
    }

    private static float clampLook(float x) {
        return Math.max(-1f, Math.min(1f, x));
    }

    /** Copy of both networks' weights (actor, critic) for the best-checkpoint rollback. */
    float[][] exportWeights() {
        return new float[][] {actor.w.clone(), critic.w.clone()};
    }

    /**
     * Restores weights from exportWeights(). Adam moments are cleared and all not-yet-learned experience
     * (collected by the policy that is being rolled back) is thrown away.
     */
    void importWeights(float[][] s) {
        System.arraycopy(s[0], 0, actor.w, 0, actor.w.length);
        System.arraycopy(s[1], 0, critic.w, 0, critic.w.length);
        actor.resetAdam();
        critic.resetAdam();
        trainReady = false;
        fill.n = 0;
        hasPending = false;
    }

    /** Drops the in-flight transition without learning from it (used by offline evaluation). */
    void discardPending() {
        hasPending = false;
    }

    /** Sets the temporary action locks (ActionMask bits) used for the next sampled actions. */
    void setMask(int mask) {
        curMask = mask;
    }

    int mask() {
        return curMask;
    }

    /** Entropy bonus coefficient (the curriculum raises it briefly after a lock is lifted). */
    void setEntropyCoef(float c) {
        entropyCoef = c;
    }

    /** Adds (unscaled) reward for the most recent action. Safe to call several times per tick. */
    void addReward(double r) {
        if (hasPending) pRew += (float) (r * Config.REWARD_SCALE);
    }

    /**
     * Ends the current episode.
     * @param terminal true if someone died (no future reward); false for timeouts / opponent leaving,
     *                 where the critic's estimate of {@code finalObs} is used to bootstrap.
     * @param finalObs the observation after the last action, or null if not available.
     */
    void endEpisode(boolean terminal, float[] finalObs) {
        if (!hasPending) return;
        float boot = 0f;
        if (finalObs != null) consequences.observe(pObs, pAct, finalObs);
        if (!terminal) boot = finalObs != null ? critic.forward(finalObs)[0] : pVal;
        commit(true, boot, 0f);
    }

    // ------------------------------------------------------------------ buffer
    private void commit(boolean done, float boot, float nextValue) {
        Rollout r = fill;
        int i = r.n++;
        System.arraycopy(pObs, 0, r.obs[i], 0, pObs.length);
        System.arraycopy(pAct, 0, r.act[i], 0, N_ACT);
        r.logp[i] = pLogp;
        r.val[i] = pVal;
        r.mask[i] = pMask;
        System.arraycopy(pH, 0, r.hPrev[i], 0, GruCell.H);
        System.arraycopy(pX, 0, r.gx[i], 0, GruCell.X);
        r.rew[i] = pRew;
        r.done[i] = done;
        r.boot[i] = boot;
        hasPending = false;
        if (r.n == Config.ROLLOUT) finishRollout(done ? 0f : nextValue);
    }

    private void finishRollout(float lastValue) {
        Rollout r = fill;
        final int T = r.n;
        float gae = 0f;
        for (int t = T - 1; t >= 0; t--) {
            float nonTerm = r.done[t] ? 0f : 1f;
            float nextV = (t == T - 1) ? lastValue : r.val[t + 1];
            float delta = r.rew[t] + Config.GAMMA * nextV * nonTerm + Config.GAMMA * r.boot[t] - r.val[t];
            gae = delta + Config.GAMMA * Config.GAE_LAMBDA * nonTerm * gae;
            r.adv[t] = gae;
            r.ret[t] = gae + r.val[t];
        }
        // critic Huber delta from the scale of this rollout's returns (smoothed): returns of 10-20 against a fixed delta of 1 made the value loss plain L1
        double rm = 0, rv = 0;
        for (int t = 0; t < T; t++) rm += r.ret[t];
        rm /= T;
        for (int t = 0; t < T; t++) rv += (r.ret[t] - rm) * (r.ret[t] - rm);
        float dTarget = (float) Math.max(Config.VALUE_HUBER_MIN, Math.min(Config.VALUE_HUBER_MAX, Config.VALUE_HUBER_FRAC * Math.sqrt(rv / T)));
        if (Float.isFinite(dTarget)) valueDelta += 0.2f * (dTarget - valueDelta);
        // normalise advantages over this rollout (returns stay as they are for the critic)
        double mean = 0;
        for (int t = 0; t < T; t++) mean += r.adv[t];
        mean /= T;
        double var = 0;
        for (int t = 0; t < T; t++) var += (r.adv[t] - mean) * (r.adv[t] - mean);
        float std = (float) Math.sqrt(var / T) + 1e-6f;
        for (int t = 0; t < T; t++) r.adv[t] = (float) ((r.adv[t] - mean) / std);

        if (trainReady) {
            skipped++; // the learner did not finish the previous rollout in time
            discardPartialMinibatch();
        }
        Rollout tmp = train;
        train = fill;
        fill = tmp;
        fill.n = 0;
        trainReady = true;
        epoch = 0;
        mbIdx = 0;
        shuffle();
    }

    /** Drop a partial minibatch when the historical one-rollout queue overflows. */
    private void discardPartialMinibatch() {
        actor.zeroGrad();
        critic.zeroGrad();
        gru.clearGrad();
        mbSampleOffset = 0;
        mbUsePrefetchBatch = false;
        mbInitialized = false;
        mbKl = mbEnt = mbVloss = 0.0;
        mbClipped = 0;
        // Never stall the Minecraft client when its one-rollout learner queue overruns.
        // The worker owns a private snapshot (not the rollout arrays); if a task is still
        // running, discard its output and fall back to synchronous replay from now on.
        synchronized (prefetchMonitor) {
            if (prefetchOutput != null && !prefetchDone) {
                prefetchDisabled = true;
            } else if (prefetchDone) {
                prefetchOutput = null;
                prefetchFailure = null;
                prefetchDone = false;
            }
        }
    }

    private void shuffle() {
        for (int i = perm.length - 1; i > 0; i--) {
            int j = rng.nextInt(i + 1);
            int t = perm[i]; perm[i] = perm[j]; perm[j] = t;
        }
    }

    // ------------------------------------------------------------------ learning
    /** One complete minibatch gradient step if a rollout is waiting (offline simulator path). */
    boolean learnTick() {
        return learnTickBudgeted(Long.MAX_VALUE);
    }

    /**
     * Advances PPO by at most {@code budgetNanos} of foreground work. A minibatch is still
     * accumulated in its original sample order and applied with the original full-batch divisor;
     * only the wall-clock placement of those computations is sliced across client frames.
     * GRU replay is polled without blocking on the client path, so a slow prefetch cannot freeze
     * rendering. Passing Long.MAX_VALUE retains the historical synchronous simulator behavior.
     */
    boolean learnTickBudgeted(long budgetNanos) {
        if (!trainReady) return false;
        final long startedNanos = System.nanoTime();
        final boolean waitForPrefetch = budgetNanos == Long.MAX_VALUE;
        final long budget = waitForPrefetch ? Long.MAX_VALUE : Math.max(250_000L, budgetNanos);
        Rollout r = train;
        final int T = r.n;
        final int start = mbIdx * Config.MINIBATCH;
        final int end = Math.min(start + Config.MINIBATCH, T);
        final int count = end - start;
        if (count <= 0) {
            trainReady = false;
            mbSampleOffset = 0;
            return false;
        }

        final boolean gruOn = gruTrainOn();
        if (!mbInitialized) {
            mbInitialized = true;
            mbKl = mbEnt = mbVloss = 0.0;
            mbClipped = 0;
            mbUsePrefetchBatch = gruOn && !prefetchDisabled
                && Boolean.parseBoolean(System.getProperty("rlpvp.gruPrefetch", "true"));
            if (mbUsePrefetchBatch) {
                ensureGruPrefetchWorker();
                // Weights are constant throughout this minibatch. The worker only computes
                // forward replay caches; all gradients remain on this learner thread.
                replayGru.copyWeightsFrom(gru);
                requestGruPrefetch(r, perm[start], prefetchedObs[0]);
            }
        }

        boolean didWork = false;
        while (mbSampleOffset < count) {
            final int localIndex = mbSampleOffset;
            final int k = start + localIndex;
            final int i = perm[k];
            float[] obsI = r.obs[i];
            if (gruOn) {
                if (mbUsePrefetchBatch) {
                    int replayReady = takeGruPrefetch(waitForPrefetch);
                    if (replayReady == 0) return didWork; // keep the task in flight; never wait on a render frame
                    if (replayReady < 0) {
                        // The exact original synchronous replay remains the safe fallback.
                        obsI = replayObs(r, i);
                        mbUsePrefetchBatch = false;
                    } else {
                        gru.copyWindowFrom(replayGru);
                        obsI = prefetchedObs[localIndex & 1];
                        if (localIndex + 1 < count) {
                            int next = perm[k + 1];
                            requestGruPrefetch(r, next, prefetchedObs[(localIndex + 1) & 1]);
                        }
                    }
                } else {
                    obsI = replayObs(r, i);
                }
                actor.clearInputGrad(); twin.clearInputGrad(); critic.clearInputGrad();
            }

            policyLogits(obsI, zMasked);
            ActionMask.apply(zMasked, r.mask[i]);
            evalPolicy(zMasked, r.act[i], r.mask[i], r.logp[i], r.adv[i], gz);
            if (Config.SYMMETRIC_POLICY) {
                Symmetry.grads(gz, gzA, gzB);
                actor.backward(gzA);
                twin.backward(gzB);
            } else {
                actor.backward(gz);
            }
            mbKl += (lastRatio - 1.0) - Math.log(lastRatio);
            mbEnt += lastEntropy;
            if (lastClipped) mbClipped++;

            float v = critic.forward(obsI)[0];
            float oldV = r.val[i];
            float target = r.ret[i];
            final float dlt = valueDelta;
            mbVloss += clippedValueLoss(v, oldV, target, Config.VALUE_CLIP, dlt);
            dV[0] = clippedValueGradient(v, oldV, target, Config.VALUE_CLIP, dlt);
            critic.backward(dV);
            if (gruOn) {
                float[] ga = actor.inputGrad(), gb = twin.inputGrad(), gc = critic.inputGrad();
                for (int q = 0; q < GruCell.H; q++) gruGrad[q] = ga[q] + gb[q] + 0.5f * gc[q];
                gru.backWindow(gruGrad);
            }
            mbSampleOffset++;
            didWork = true;

            if (!waitForPrefetch && System.nanoTime() - startedNanos >= budget)
                return true;
        }

        // Apply exactly once per complete minibatch and divide by its full original sample count.
        final float lr = lrScale * lateLrScale;
        if (gruOn) gru.step(Config.LR_GRU * lr, Config.GRU_MAX_NORM, count);
        float gn = actor.step(Config.LR_ACTOR * lr, Config.MAX_GRAD_NORM, count);
        critic.step(Config.LR_CRITIC * lr, Config.MAX_GRAD_NORM, count);

        stSteps++;
        stSamples += count;
        stKl += mbKl; stEnt += mbEnt; stClip += mbClipped; stVLoss += mbVloss; stGrad += gn;

        double meanKl = mbKl / count;
        rolloutKlSum += meanKl;
        rolloutKlBatches++;
        mbSampleOffset = 0;
        mbUsePrefetchBatch = false;
        mbInitialized = false;
        mbKl = mbEnt = mbVloss = 0.0;
        mbClipped = 0;
        mbIdx++;
        if (mbIdx * Config.MINIBATCH >= T) {
            mbIdx = 0;
            epoch++;
            if (epoch >= Config.EPOCHS) {
                trainReady = false;
                updates++;
            } else {
                shuffle();
            }
        }
        if (trainReady && meanKl > 1.5 * Config.TARGET_KL) {
            trainReady = false;
            skipped++;
        }
        if (!trainReady && rolloutKlBatches > 0) {
            double rolloutKl = rolloutKlSum / rolloutKlBatches;
            if (rolloutKl > Config.TARGET_KL * Config.KL_ADAPT_UPPER) lrScale = Math.max(Config.LR_SCALE_MIN, lrScale * 0.7f);
            else if (rolloutKl < Config.TARGET_KL * Config.KL_ADAPT_LOWER) lrScale = Math.min(Config.LR_SCALE_MAX, lrScale * 1.05f);
            rolloutKlSum = 0; rolloutKlBatches = 0;
        }
        return true;
    }

    private void ensureGruPrefetchWorker() {
        if (prefetchThread != null) return;
        replayGru = new GruCell();
        prefetchThread = new Thread(this::gruPrefetchLoop, "rlpvp-gru-replay-prefetch");
        prefetchThread.setDaemon(true);
        prefetchThread.start();
    }

    private void requestGruPrefetch(Rollout r, int i, float[] output) {
        // Snapshot only the short recurrent window and observation before handing work off.
        // This keeps the background task independent of the double-buffered rollout lifetime.
        int start = i, n = 1;
        while (n < Config.GRU_BPTT && start > 0 && !r.done[start - 1]) { start--; n++; }
        System.arraycopy(r.hPrev[start], 0, prefetchInitialH, 0, GruCell.H);
        for (int t = 0; t < n; t++)
            System.arraycopy(r.gx[start + t], 0, prefetchInputs[t], 0, GruCell.X);
        System.arraycopy(r.obs[i], 0, output, 0, output.length);
        synchronized (prefetchMonitor) {
            if (prefetchRequested || (prefetchDone && prefetchOutput != null))
                throw new IllegalStateException("GRU prefetch request overlapped an unconsumed result");
            prefetchSteps = n;
            prefetchOutput = output;
            prefetchFailure = null;
            prefetchDone = false;
            prefetchRequested = true;
            prefetchMonitor.notifyAll();
        }
    }

    /** @return 1=ready, 0=still working, -1=failed (use the original synchronous replay). */
    private int takeGruPrefetch(boolean wait) {
        Throwable failure;
        synchronized (prefetchMonitor) {
            while (!prefetchDone) {
                if (!wait) return 0;
                try {
                    prefetchMonitor.wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    prefetchDisabled = true;
                    return -1;
                }
            }
            failure = prefetchFailure;
            prefetchOutput = null;
            prefetchFailure = null;
        }
        if (failure != null) {
            prefetchDisabled = true;
            System.err.println("[RLPvP] GRU prefetch disabled; using synchronous replay: " + failure);
            return -1;
        }
        return 1;
    }

    private void gruPrefetchLoop() {
        for (;;) {
            float[] output;
            int steps;
            synchronized (prefetchMonitor) {
                while (!prefetchRequested && !prefetchShutdown) {
                    try {
                        prefetchMonitor.wait();
                    } catch (InterruptedException e) {
                        if (prefetchShutdown) return;
                    }
                }
                if (prefetchShutdown) return;
                output = prefetchOutput;
                steps = prefetchSteps;
                prefetchRequested = false;
            }
            Throwable failure = null;
            try {
                replayGru.beginWindow(prefetchInitialH);
                for (int t = 0; t < steps; t++) replayGru.windowStep(prefetchInputs[t]);
                System.arraycopy(replayGru.windowH(), 0, output, OpponentMemory.slotStart(), GruCell.H);
            } catch (Throwable t) {
                failure = t;
            }
            synchronized (prefetchMonitor) {
                prefetchFailure = failure;
                prefetchDone = true;
                prefetchMonitor.notifyAll();
            }
        }
    }

    /**
     * The observation of sample i with its GRU slots recomputed by the current cell: replay up to Config.GRU_BPTT ticks of the rollout (never across
     * an episode end) from the hidden state stored at the window start. Leaves the window cached in the cell for backWindow().
     */
    private float[] replayObs(Rollout r, int i) {
        int s = i, n = 1;
        while (n < Config.GRU_BPTT && s > 0 && !r.done[s - 1]) { s--; n++; }
        gru.beginWindow(r.hPrev[s]);
        for (int t = s; t <= i; t++) gru.windowStep(r.gx[t]);
        System.arraycopy(r.obs[i], 0, obsTmp, 0, obsTmp.length);
        System.arraycopy(gru.windowH(), 0, obsTmp, OpponentMemory.slotStart(), GruCell.H);
        return obsTmp;
    }

    boolean learnerBusy() {
        return trainReady;
    }

    // ------------------------------------------------------------------ parallel training (sim/ParallelPvpTrain)
    /**
     * Moves this (acting-only) agent's finished rollout into {@code learner}, which then learns from it with learnTick(). The learner must be
     * idle. The data was collected by the weights this agent had; PPO's stored log-probs and clipping handle the small lag.
     * @return false if there was no finished rollout (or the learner was busy)
     */
    boolean handRolloutTo(PpoAgent learner) {
        if (!trainReady || learner.trainReady) return false;
        Rollout s = train, d = learner.train;
        final int n = s.n;
        for (int i = 0; i < n; i++) {
            System.arraycopy(s.obs[i], 0, d.obs[i], 0, s.obs[i].length);
            System.arraycopy(s.act[i], 0, d.act[i], 0, N_ACT);
        }
        System.arraycopy(s.logp, 0, d.logp, 0, n);
        System.arraycopy(s.val, 0, d.val, 0, n);
        System.arraycopy(s.rew, 0, d.rew, 0, n);
        System.arraycopy(s.boot, 0, d.boot, 0, n);
        System.arraycopy(s.done, 0, d.done, 0, n);
        System.arraycopy(s.adv, 0, d.adv, 0, n);
        System.arraycopy(s.ret, 0, d.ret, 0, n);
        System.arraycopy(s.mask, 0, d.mask, 0, n);
        for (int i = 0; i < n; i++) {
            System.arraycopy(s.hPrev[i], 0, d.hPrev[i], 0, GruCell.H);
            System.arraycopy(s.gx[i], 0, d.gx[i], 0, GruCell.X);
        }
        d.n = n;
        trainReady = false;
        learner.trainReady = true;
        learner.epoch = 0;
        learner.mbIdx = 0;
        learner.mbSampleOffset = 0;
        learner.mbInitialized = false;
        learner.mbUsePrefetchBatch = false;
        learner.shuffle();
        return true;
    }

    /** Copies the learned weights (and the stage / tick bookkeeping) of {@code m} into this acting copy. Adam state stays with the learner. */
    void adoptFrom(PpoAgent m) {
        System.arraycopy(m.actor.w, 0, actor.w, 0, actor.w.length);
        System.arraycopy(m.critic.w, 0, critic.w, 0, critic.w.length);
        gru.copyWeightsFrom(m.gru);
        totalTicks = m.totalTicks;
        stage = m.stage;
        stageEnterTicks = m.stageEnterTicks;
    }

    /** Takes over {@code w}'s consequence (world) model by serialising it, so the saved checkpoint carries one that was trained on real transitions. */
    void adoptConsequenceFrom(PpoAgent w) throws IOException {
        // Same persisted state as write/read, but without allocating and copying a large temporary byte array.
        consequences.copyPersistedStateFrom(w.consequences);
    }

    /** Averages since the last call: {steps, kl, entropy, clipFraction, valueLoss, gradNorm}. */
    double[] takeStats() {
        double n = Math.max(1, stSamples);
        double[] s = {stSteps, stKl / n, stEnt / n, stClip / n, stVLoss / n, stSteps == 0 ? 0 : stGrad / stSteps};
        stSteps = 0; stSamples = 0; stKl = 0; stEnt = 0; stClip = 0; stVLoss = 0; stGrad = 0;
        return s;
    }

    // ------------------------------------------------------------------ policy math
    private static float logStd(float raw) {
        return Math.max(Config.LOOK_LOGSTD_MIN, Math.min(Config.LOOK_LOGSTD_MAX, raw));
    }

    /** Samples the complete policy action, including the conditional hold-strafe branch. Static so FrozenPolicy shares it. Camera values are NOT clamped here (log-prob uses the raw sample). */
    static void sampleAction(float[] z, int mask, Random rng, float[] out) {
        for (int g = 0; g < 2; g++) {
            if (g == 1 && ActionMask.pitchLocked(mask)) { out[1] = 0f; continue; }
            int off = GAUSS_OFF[g];
            out[g] = (float) (Math.exp(logStd(z[off + 1])) * (z[off] + rng.nextGaussian())); // x = sigma * (m + eps)
        }
        for (int h = 0; h < 2; h++) {
            int off = CAT_OFF[h];
            float max = Math.max(z[off], Math.max(z[off + 1], z[off + 2]));
            double sum = 0;
            for (int i = 0; i < 3; i++) sum += Math.exp(z[off + i] - max);
            double u = rng.nextDouble() * sum, acc = 0;
            int pick = 2;
            for (int i = 0; i < 3; i++) {
                acc += Math.exp(z[off + i] - max);
                if (u < acc) { pick = i; break; }
            }
            out[2 + h] = pick;
        }
        for (int b = 0; b < BERN_IDX.length; b++) {
            double pr = 1.0 / (1.0 + Math.exp(-z[BERN_IDX[b]]));
            out[4 + b] = rng.nextDouble() < pr ? 1 : 0;
        }
        if (Math.round(out[3]) == 1 && !ActionMask.isStrafeLocked(mask)) {
            double ph = 1.0 / (1.0 + Math.exp(-z[Config.OFF_HOLD_STRAFE]));
            out[8] = rng.nextDouble() < ph ? 1f : 0f;
        } else out[8] = 0f;
    }

    private static double softplus(double x) {
        return x > 0 ? x + Math.log1p(Math.exp(-x)) : Math.log1p(Math.exp(x));
    }

    /**
     * Log-prob of action {@code a} under logits {@code z} (with the curriculum {@code mask}). If {@code grad} is
     * non-null it is filled with d(loss)/d(logits) for ONE sample of the PPO objective
     *   loss = -min(ratio*adv, clip(ratio)*adv) - entropyCoef * entropy.
     * Camera heads are parametrised as x = sigma * (m + eps), eps ~ N(0,1): the network outputs m (in std units) and
     * log-sigma. With a tiny sigma this keeps PPO's ratio well behaved (a plain mean parameter would make the
     * policy absurdly sensitive and the KL early stop would skip every rollout).
     * A locked pitch axis contributes nothing. lastEntropy covers the discrete + on/off heads only.
     */
    double evalPolicy(float[] z, float[] a, int mask, float oldLogp, float adv, float[] grad) {
        double logp = 0, ent = 0;
        // ---- camera (Gaussian) ----
        double[] zs2 = gaussZ2;
        for (int g = 0; g < 2; g++) {
            int off = GAUSS_OFF[g];
            if (g == 1 && ActionMask.pitchLocked(mask)) { zs2[g] = Double.NaN; continue; }
            float ls = logStd(z[off + 1]);
            double sigma = Math.exp(ls);
            double zsc = a[g] / sigma - z[off]; // (x - mean) / sigma with mean = m * sigma
            zs2[g] = zsc * zsc;
            logp += -0.5 * zs2[g] - ls - HALF_LOG_2PI;
        }
        // ---- categorical (forward, strafe) ----
        for (int h = 0; h < 2; h++) {
            int off = CAT_OFF[h];
            float max = Math.max(z[off], Math.max(z[off + 1], z[off + 2]));
            double sum = 0;
            for (int i = 0; i < 3; i++) sum += Math.exp(z[off + i] - max);
            double lse = max + Math.log(sum);
            double hEnt = 0;
            for (int i = 0; i < 3; i++) {
                double l = z[off + i] - lse;
                ls[off + i] = (float) l;
                p[off + i] = (float) Math.exp(l);
                hEnt -= p[off + i] * l;
            }
            logp += ls[off + Math.round(a[2 + h])];
            ent += hEnt;
            headEnt[h] = hEnt;
        }
        for (int b = 0; b < BERN_IDX.length; b++) {
            double zb = z[BERN_IDX[b]];
            double pb = 1.0 / (1.0 + Math.exp(-zb));
            boolean on = a[4 + b] > 0.5f;
            logp += on ? -softplus(-zb) : -softplus(zb);
            bernEnt[b] = pb * softplus(-zb) + (1 - pb) * softplus(zb);
            ent += bernEnt[b];
            bernP[b] = pb;
        }
        boolean holdEligible = Math.round(a[3]) == 1 && !ActionMask.isStrafeLocked(mask);
        double holdP = 0.0, holdZ = z[Config.OFF_HOLD_STRAFE];
        if (holdEligible) {
            holdP = 1.0 / (1.0 + Math.exp(-holdZ));
            boolean holdOn = a.length > 8 && a[8] > 0.5f;
            logp += holdOn ? -softplus(-holdZ) : -softplus(holdZ);
            ent += holdP * softplus(-holdZ) + (1.0 - holdP) * softplus(holdZ);
        }
        lastEntropy = ent;
        double ratio = Math.exp(Math.max(-20.0, Math.min(20.0, logp - oldLogp)));
        lastRatio = ratio;
        lastClipped = (adv >= 0 && ratio > 1 + Config.CLIP) || (adv < 0 && ratio < 1 - Config.CLIP);

        if (grad != null) {
            double coef = lastClipped ? 0.0 : -adv * ratio; // d(loss)/d(logp)
            for (int g = 0; g < 2; g++) {
                int off = GAUSS_OFF[g];
                if (Double.isNaN(zs2[g])) { grad[off] = 0f; grad[off + 1] = 0f; continue; }
                float rawLs = z[off + 1];
                double sigma = Math.exp(logStd(rawLs));
                double zsc = a[g] / sigma - z[off];
                boolean inRange = rawLs > Config.LOOK_LOGSTD_MIN && rawLs < Config.LOOK_LOGSTD_MAX;
                grad[off] = (float) (coef * zsc); // dlogp/dm
                if (inRange) grad[off + 1] = (float) (coef * (zsc * (zsc + z[off]) - 1.0) - entropyCoef * Config.LOOK_ENTROPY_SCALE);
                else grad[off + 1] = rawLs <= Config.LOOK_LOGSTD_MIN ? -Config.LOOK_CLAMP_RESTORE : Config.LOOK_CLAMP_RESTORE; // push back inside the limits
            }
            for (int h = 0; h < 2; h++) {
                int off = CAT_OFF[h];
                for (int i = 0; i < 3; i++) {
                    double dlogp = (i == Math.round(a[2 + h]) ? 1.0 : 0.0) - p[off + i];
                    double dEnt = -p[off + i] * (ls[off + i] + headEnt[h]);
                    grad[off + i] = (float) (coef * dlogp - entropyCoef * headBoost[h] * dEnt);
                }
            }
            for (int b = 0; b < BERN_IDX.length; b++) {
                double zb = z[BERN_IDX[b]], pb = bernP[b];
                double dlogp = (a[4 + b] > 0.5f ? 1.0 : 0.0) - pb;
                double dEnt = -zb * pb * (1 - pb);
                grad[BERN_IDX[b]] = (float) (coef * dlogp - entropyCoef * (b == 1 ? headBoost[2] : b == 2 ? headBoost[3] : 1f) * dEnt);
            }
            if (holdEligible) {
                double dlogp = (a.length > 8 && a[8] > 0.5f ? 1.0 : 0.0) - holdP;
                double dEnt = -holdZ * holdP * (1.0 - holdP);
                grad[Config.OFF_HOLD_STRAFE] = (float) (coef * dlogp - entropyCoef * dEnt);
            } else grad[Config.OFF_HOLD_STRAFE] = 0f;
        }
        return logp;
    }

    private final double[] headEnt = new double[2];
    private final double[] bernP = new double[BERN_IDX.length];
    private final double[] gaussZ2 = new double[2];

    /** Largest possible lastEntropy for the heads NOT locked by {@code mask} (locked heads contribute 0). */
    static double maxEntropy(int mask) {
        double e = 0.0;
        if ((mask & ActionMask.LOCK_ATTACK) == 0) e += Math.log(2.0);
        if ((mask & ActionMask.LOCK_FWD) == 0) e += Math.log(3.0);
        if ((mask & ActionMask.LOCK_STRAFE) == 0) e += Math.log(3.0) + Math.log(2.0); // conditional hold-strafe branch is available only with unlocked strafe
        if ((mask & ActionMask.LOCK_JUMP) == 0) e += Math.log(2.0);
        if ((mask & ActionMask.LOCK_SPRINT) == 0) e += Math.log(2.0);
        return e;
    }

    static float huberLoss(float error, float delta) {
        float d = Math.max(1e-6f, delta), a = Math.abs(error);
        return a <= d ? 0.5f * error * error : d * (a - 0.5f * d);
    }

    static float huberGradient(float error, float delta) {
        float d = Math.max(1e-6f, delta);
        return Math.max(-d, Math.min(d, error));
    }

    static float clippedValueLoss(float value, float oldValue, float target, float clip, float huberDelta) {
        float bound = Math.max(1e-6f, clip);
        float clipped = oldValue + Math.max(-bound, Math.min(bound, value - oldValue));
        return Math.max(huberLoss(value - target, huberDelta), huberLoss(clipped - target, huberDelta));
    }

    static float clippedValueGradient(float value, float oldValue, float target, float clip, float huberDelta) {
        float bound = Math.max(1e-6f, clip);
        float clipped = oldValue + Math.max(-bound, Math.min(bound, value - oldValue));
        float rawError = value - target, clippedError = clipped - target;
        float rawLoss = huberLoss(rawError, huberDelta);
        float clippedLoss = huberLoss(clippedError, huberDelta);
        if (clippedLoss > rawLoss) return Math.abs(value - oldValue) <= bound ? huberGradient(clippedError, huberDelta) : 0f;
        return huberGradient(rawError, huberDelta);
    }

    // test hooks
    double lastEntropy() { return lastEntropy; }
    double lastRatio() { return lastRatio; }

    // ------------------------------------------------------------------ persistence
    void save(Path file) throws IOException {
        Path target = file.toAbsolutePath();
        Path parent = target.getParent();
        if (parent != null) Files.createDirectories(parent);
        backupOnce(target);
        Path tmp = Files.createTempFile(parent, target.getFileName().toString() + ".", ".tmp");
        try {
            try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(tmp)))) {
                out.writeInt(MAGIC);
                out.writeInt(VERSION);
                out.writeInt(actor.w.length);
                out.writeInt(critic.w.length);
                out.writeLong(totalTicks);
                out.writeInt(updates);
                out.writeInt(stage);
                out.writeLong(stageEnterTicks);
                actor.write(out);
                critic.write(out);
                consequences.write(out);
                out.writeInt(TRAILER_MAGIC);   // older code stops reading before this: still loadable by older builds
                out.writeLong(techTicks);
                out.writeInt(GRU_TRAILER_MAGIC);   // optional GRU2: weights and Adam optimizer state
                gru.writeTrainingState(out);
                out.writeInt(SITUATIONAL_TRAILER_MAGIC); // optional, backwards-compatible play-side memory
                situational.write(out);
            }
            try { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (java.nio.file.AtomicMoveNotSupportedException ex) {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    /** Before the FIRST overwrite of an existing save in this JVM, keep a timestamped copy (never silently lose trained weights). */
    private static void backupOnce(Path file) {
        Path abs = file.toAbsolutePath().normalize();
        if (!Files.exists(abs) || !BACKED_UP.add(abs)) return;
        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        Path bak = abs.resolveSibling(abs.getFileName() + ".bak-" + ts);
        try {
            Files.copy(abs, bak, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("rlpvp: backed up existing checkpoint to " + bak);
        } catch (IOException e) {
            System.err.println("rlpvp: WARNING could not back up " + abs + " before overwriting: " + e.getMessage());
        }
    }

    static PpoAgent load(Path file, long seed) throws IOException {
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(file)))) {
            int magic = in.readInt();
            int version = in.readInt();
            if (magic != MAGIC || (version < 4 || version > VERSION)) {
                throw new IOException("not a compatible PPO state file (supported state versions: 4 through 9)");
            }
            int a = in.readInt(), c = in.readInt();
            // Detect the checkpoint's original architecture independently of the selected runtime model.
            // Width changes can be warm-started; depth changes are intentionally rejected by Net.readTransferred.
            int legacyFrame = 0, oldOut = Config.ACTION_SIZE, sourceObs = Config.OBS_SIZE;
            boolean legacy = false, preSneak = false, preSneakInput = false;
            int[] sourceHidden = null, inputMap = null;
            int preIn = ObsLayout.sizePreSneak();
            int baseObs = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, Config.SUMMARY_BASE);
            if (Config.COMPACT_126) {
                // v7.38's compact recurrent input contract. First recognise native compact checkpoints,
                // then migrate historical lag stacks by semantic meaning (current frame + stable habits).
                compactSearch: for (int[] hidden : knownHiddenShapes()) {
                    for (int out : new int[]{Config.ACTION_SIZE, Config.ACTION_SIZE_PRE_HOLD_STRAFE, Config.ACTION_SIZE_PRE_SNEAK}) {
                        if (a == Net.paramCount(sizes(out, Config.OBS_SIZE, hidden))
                                && c == Net.paramCount(sizes(1, Config.OBS_SIZE, hidden))) {
                            sourceHidden = hidden; sourceObs = Config.OBS_SIZE; oldOut = out;
                            preSneak = out == Config.ACTION_SIZE_PRE_SNEAK;
                            inputMap = identityMap(sourceObs);
                            break compactSearch;
                        }
                    }
                    // Previous compact contracts used 126 inputs (before target-box dx/dy) or 128 inputs
                    // (with target-box dx/dy). Keep every old column at the same index; the new 128..142
                    // temporal/physics/general-outcome inputs start with zero incoming weights.
                    boolean found = false;
                    for (int compactSource : new int[]{128, 126}) {
                        if (compactSource == Config.OBS_SIZE) continue;
                        for (int out : new int[]{Config.ACTION_SIZE, Config.ACTION_SIZE_PRE_HOLD_STRAFE, Config.ACTION_SIZE_PRE_SNEAK}) {
                            if (a == Net.paramCount(sizes(out, compactSource, hidden))
                                    && c == Net.paramCount(sizes(1, compactSource, hidden))) {
                                sourceHidden = hidden; sourceObs = compactSource; oldOut = out;
                                preSneak = out == Config.ACTION_SIZE_PRE_SNEAK;
                                inputMap = identityMap(compactSource);
                                found = true;
                                break;
                            }
                        }
                        if (found) break;
                    }
                    if (!found) for (int sourceFrame : new int[]{Config.FRAME, Config.FRAME_PRE_SNEAK}) {
                        for (int mask = 0; mask < 32 && !found; mask++) {
                            boolean srcV2 = (mask & 1) != 0;
                            boolean srcSprint = (mask & 2) != 0;
                            boolean srcMemory = (mask & 4) != 0;
                            boolean srcKb = (mask & 8) != 0;
                            boolean srcCombat = (mask & 16) != 0;
                            int[] sourceMemWidths = srcMemory ? new int[]{16, Config.MEMORY_FEATURES} : new int[]{0};
                            int[] sourceCombatWidths = srcCombat
                                ? new int[]{Config.COMBAT_FEATURES, Config.COMBAT_FEATURES - 1, Config.COMBAT_FEATURES - 2}
                                : new int[]{0};
                            for (int sourceMemWidth : sourceMemWidths) {
                                for (int sourceCombatWidth : sourceCombatWidths) {
                                    int sourceSummary = ObsLayout.summaryCount(srcV2, srcSprint, srcMemory, srcKb,
                                        srcCombat, sourceMemWidth, sourceCombatWidth);
                                    int sourceSize = ObsLayout.size(Config.LAGS, sourceFrame,
                                        Config.FAR_FEATURES.length, sourceSummary);
                                    for (int out : new int[]{Config.ACTION_SIZE, Config.ACTION_SIZE_PRE_HOLD_STRAFE, Config.ACTION_SIZE_PRE_SNEAK}) {
                                        if (a == Net.paramCount(sizes(out, sourceSize, hidden))
                                                && c == Net.paramCount(sizes(1, sourceSize, hidden))) {
                                            sourceHidden = hidden; sourceObs = sourceSize; oldOut = out;
                                            preSneak = sourceFrame < Config.FRAME || out == Config.ACTION_SIZE_PRE_SNEAK;
                                            preSneakInput = sourceFrame < Config.FRAME;
                                            inputMap = ObsLayout.compactSourceMap(sourceFrame, srcV2, srcSprint,
                                                srcMemory, srcKb, srcCombat, sourceMemWidth, sourceCombatWidth);
                                            found = true;
                                            break;
                                        }
                                    }
                                    if (found) break;
                                }
                                if (found) break;
                            }
                        }
                        if (found) break;
                    }
                    if (found) break compactSearch;
                    // Old 42/48-feature, four-lag checkpoints (no summary/context blocks).
                    for (int lf : Config.LEGACY_FRAMES) {
                        int oldIn = lf * Config.LEGACY_LAGS.length;
                        for (int out : new int[]{Config.ACTION_SIZE, Config.ACTION_SIZE_PRE_HOLD_STRAFE, Config.ACTION_SIZE_PRE_SNEAK}) {
                            if (a == Net.paramCount(sizes(out, oldIn, hidden))
                                    && c == Net.paramCount(sizes(1, oldIn, hidden))) {
                                sourceHidden = hidden; sourceObs = oldIn; oldOut = out; legacyFrame = lf;
                                legacy = true; preSneak = out == Config.ACTION_SIZE_PRE_SNEAK;
                                inputMap = ObsLayout.compactLegacyMap(legacyFrame, Config.LEGACY_LAGS);
                                break compactSearch;
                            }
                        }
                    }
                }
            } else {
            outer: for (int[] hidden : knownHiddenShapes()) {
                for (int out : new int[]{Config.ACTION_SIZE, Config.ACTION_SIZE_PRE_HOLD_STRAFE, Config.ACTION_SIZE_PRE_SNEAK}) {
                    if (a == Net.paramCount(sizes(out, Config.OBS_SIZE, hidden))
                            && c == Net.paramCount(sizes(1, Config.OBS_SIZE, hidden))) {
                        sourceHidden = hidden; sourceObs = Config.OBS_SIZE; oldOut = out;
                        preSneak = out == Config.ACTION_SIZE_PRE_SNEAK;
                        preSneakInput = preSneak;
                        inputMap = preSneak ? ObsLayout.preSneakMap() : identityMap(sourceObs);
                        break outer;
                    }
                }
                // Checkpoints from any prior combination of optional summary blocks (before/after OBS_V2,
                // sprint-follow-up, opponent memory, knockback timing, or combat observations) are migrated
                // by semantic block. Newly introduced inputs start with zero incoming weights.
                {
                    boolean foundSummaryLayout = false;
                    for (int mask = 0; mask < 32 && !foundSummaryLayout; mask++) {
                        boolean srcV2 = (mask & 1) != 0;
                        boolean srcSprint = (mask & 2) != 0;
                        boolean srcMemory = (mask & 4) != 0;
                        boolean srcKb = (mask & 8) != 0;
                        boolean srcCombat = (mask & 16) != 0;
                        int sourceSummary = ObsLayout.summaryCount(srcV2, srcSprint, srcMemory, srcKb, srcCombat);
                        if (sourceSummary == Config.SUMMARY) continue;
                        int sourceSize = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, sourceSummary);
                        int matchedOut = matchingLegacyActionSize(a, c, sourceSize, hidden);
                        if (matchedOut > 0) {
                            sourceHidden = hidden; sourceObs = sourceSize; oldOut = matchedOut;
                            inputMap = ObsLayout.summaryBlockMap(srcV2, srcSprint, srcMemory, srcKb, srcCombat);
                            foundSummaryLayout = true;
                        }
                    }
                    if (foundSummaryLayout) break outer;
                }
                // v7.25.1: checkpoints with the previous 11-feature combat block need semantic migration into the new 12-feature block.
                // The appended sprint-reset sensor has no source column, so its incoming weights remain zero for old checkpoints.
                if (Config.COMBAT_OBSERVATIONS) {
                    boolean foundOldCombatLayout = false;
                    for (int mask = 0; mask < 16 && !foundOldCombatLayout; mask++) {
                        boolean srcV2 = (mask & 1) != 0;
                        boolean srcSprint = (mask & 2) != 0;
                        boolean srcMemory = (mask & 4) != 0;
                        boolean srcKb = (mask & 8) != 0;
                        int sourceSummary = ObsLayout.summaryCount(srcV2, srcSprint, srcMemory, srcKb,
                            true, Config.COMBAT_FEATURES - 1);
                        int sourceSize = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, sourceSummary);
                        int matchedOut = matchingLegacyActionSize(a, c, sourceSize, hidden);
                        if (matchedOut > 0) {
                            sourceHidden = hidden; sourceObs = sourceSize; oldOut = matchedOut;
                            inputMap = ObsLayout.summaryBlockMap(srcV2, srcSprint, srcMemory, srcKb,
                                true, Config.COMBAT_FEATURES - 1);
                            foundOldCombatLayout = true;
                        }
                    }
                    if (foundOldCombatLayout) break outer;
                }
                // v7.22: checkpoints made before the knockback-timing block (the same layout minus the LAST KB_FEATURES summary inputs); the new inputs start at zero weight.
                if (Config.KB_TIMING) {
                    int preKbSummary = Config.SUMMARY - Config.KB_FEATURES;
                    int preKbObs = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, preKbSummary);
                    int matchedOut = matchingLegacyActionSize(a, c, preKbObs, hidden);
                    if (matchedOut > 0) {
                        sourceHidden = hidden; sourceObs = preKbObs; oldOut = matchedOut;
                        inputMap = ObsLayout.summaryMap(preKbSummary); break outer;
                    }
                }
                // v7.19: checkpoints made before the memory block (same layout minus MEMORY_FEATURES summary inputs); the new inputs start at zero weight.
                if (Config.MEMORY) {
                    int preMemSummary = Config.SUMMARY - (Config.KB_TIMING ? Config.KB_FEATURES : 0) - Config.MEMORY_FEATURES;
                    int preMemObs = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, preMemSummary);
                    int matchedOut = matchingLegacyActionSize(a, c, preMemObs, hidden);
                    if (matchedOut > 0) {
                        sourceHidden = hidden; sourceObs = preMemObs; oldOut = matchedOut;
                        inputMap = ObsLayout.summaryMap(preMemSummary); break outer;
                    }
                }
                // Checkpoints with the original 20 summary inputs remain loadable when optional summary memories are appended.
                if (Config.SUMMARY > Config.SUMMARY_BASE) {
                    int matchedOut = matchingLegacyActionSize(a, c, baseObs, hidden);
                    if (matchedOut > 0) {
                        sourceHidden = hidden; sourceObs = baseObs; oldOut = matchedOut;
                        inputMap = ObsLayout.baseSummaryMap(); break outer;
                    }
                }
                // Preserve older OBS_V2 checkpoints (20 base + 10 motion-memory inputs) when sprint memory is added.
                int oldV2Obs = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, Config.SUMMARY_BASE + Config.V2_FEATURES);
                if (Config.SPRINT_FOLLOWUP && Config.OBS_V2) {
                    int matchedOut = matchingLegacyActionSize(a, c, oldV2Obs, hidden);
                    if (matchedOut > 0) {
                        sourceHidden = hidden; sourceObs = oldV2Obs; oldOut = matchedOut;
                        inputMap = ObsLayout.summaryMap(Config.SUMMARY_BASE + Config.V2_FEATURES); break outer;
                    }
                }
                if (a == Net.paramCount(sizes(Config.ACTION_SIZE_PRE_SNEAK, preIn, hidden))
                        && c == Net.paramCount(sizes(1, preIn, hidden))) {
                    sourceHidden = hidden; sourceObs = preIn; oldOut = Config.ACTION_SIZE_PRE_SNEAK;
                    preSneak = true; preSneakInput = true; inputMap = ObsLayout.preSneakMap(); break outer;
                }
                for (int lf : Config.LEGACY_FRAMES) {
                    int oldIn = lf * Config.LEGACY_LAGS.length;
                    for (int out : new int[]{Config.ACTION_SIZE, Config.ACTION_SIZE_PRE_HOLD_STRAFE, Config.ACTION_SIZE_PRE_SNEAK}) {
                        if (a == Net.paramCount(sizes(out, oldIn, hidden))
                                && c == Net.paramCount(sizes(1, oldIn, hidden))) {
                            sourceHidden = hidden; sourceObs = oldIn; oldOut = out; legacyFrame = lf;
                            legacy = true; inputMap = ObsLayout.legacyMap(legacyFrame, Config.LEGACY_LAGS); break outer;
                        }
                    }
                }
            }
            }
            if (sourceHidden == null) {
                throw new IOException("unrecognized checkpoint network layout: " + a + "/" + c + " params (selected model " + Config.MODEL + ")");
            }
            if (sourceHidden.length != Config.HIDDEN.length) {
                throw new IOException("checkpoint has " + sourceHidden.length + " hidden layers but selected model has " + Config.HIDDEN.length
                    + "; depth changes are not transferable. Choose a target with the same number of layers or train the new depth from scratch.");
            }
            boolean widening = !java.util.Arrays.equals(sourceHidden, Config.HIDDEN)
                && canWiden(sourceHidden, Config.HIDDEN) && sourceObs == Config.OBS_SIZE && !legacy && !preSneak;
            PpoAgent agent = new PpoAgent(seed);
            // A v4 critic was trained against technique-identity bonuses. Keep the learned actor, but
            // reinitialise the critic so model-based look-ahead is trained on the new outcome objective.
            float[] freshCriticWeights = agent.critic.w.clone();
            agent.totalTicks = in.readLong();
            agent.updates = in.readInt();
            agent.stage = in.readInt();
            agent.stageEnterTicks = in.readLong();
            int oldIn = sourceObs;
            int[] oldActorSizes = sizes(oldOut, oldIn, sourceHidden);
            int[] oldCriticSizes = sizes(1, oldIn, sourceHidden);
            boolean sameArchitecture = java.util.Arrays.equals(oldActorSizes, actorSizes())
                && java.util.Arrays.equals(oldCriticSizes, criticSizes());
            if (sameArchitecture && !legacy && !preSneak) {
                agent.actor.read(in); agent.critic.read(in);
            } else if (widening) {
                Net oldActor = new Net(oldActorSizes, 0f, null);
                Net oldCritic = new Net(oldCriticSizes, 0f, null);
                oldActor.read(in); oldCritic.read(in);
                agent.actor.widenFrom(oldActor); agent.critic.widenFrom(oldCritic);
                System.out.println("rlpvp: function-preserving widening " + java.util.Arrays.toString(sourceHidden) + " -> "
                    + java.util.Arrays.toString(Config.HIDDEN) + "; Adam moments reset; curriculum/counters retained.");
            } else {
                agent.actor.readTransferred(in, oldActorSizes, inputMap);
                agent.critic.readTransferred(in, oldCriticSizes, inputMap);
                if (!java.util.Arrays.equals(sourceHidden, Config.HIDDEN))
                    System.out.println("rlpvp: warm-started " + Config.MODEL + " from checkpoint hidden shape " + java.util.Arrays.toString(sourceHidden));
            }
            // Newly introduced action heads are initialized neutrally during checkpoint migration.
            // Existing learned heads remain untouched; no behavior prior is injected on resume.
            if (oldOut < Config.ACTION_SIZE) {
                agent.actor.w[agent.actor.w.length - Config.ACTION_SIZE + Config.OFF_HOLD_STRAFE] = 0.0f;
            }
            if (oldOut <= Config.ACTION_SIZE_PRE_SNEAK || preSneak) {
                agent.actor.w[agent.actor.w.length - Config.ACTION_SIZE + Config.OFF_SNEAK] = 0.0f;
            }
            if (version >= 5) {
                if (preSneakInput && !legacy) agent.consequences.readDiscardingOldLayout(in, version, Config.COMPACT_126 ? sourceObs + 7 : preIn + 7, Config.FRAME_PRE_SNEAK);
                else if (legacy) throw new IOException("unsupported combination: legacy frame layout with a consequence section");
                else {
                    int oldActionCount = oldOut <= Config.ACTION_SIZE_PRE_SNEAK ? 7 : (version < 9 ? 8 : N_ACT);
                    if (sourceObs != Config.OBS_SIZE || oldActionCount != N_ACT)
                        agent.consequences.readDiscardingOldInputLayout(in, version, sourceObs, oldActionCount);
                    else agent.consequences.read(in, version);
                }
            } else {
                System.arraycopy(freshCriticWeights, 0, agent.critic.w, 0, freshCriticWeights.length);
                agent.critic.resetAdam();
                // The consequence model remains intentionally untrained. It only activates after it
                // has gathered and validated transitions in this runtime.
            }
            try {
                if (in.readInt() == TRAILER_MAGIC) agent.techTicks = Math.max(0L, in.readLong());
            } catch (EOFException e) {
                // save from before technique discovery: no trailer, annealing clock starts at 0
            }
            try {
                int gruMagic = in.readInt();
                if (gruMagic == GRU_TRAILER_MAGIC) agent.gru.readTrainingState(in);
                else if (gruMagic == GRU_TRAILER_MAGIC_V1) agent.gru.read(in);
                else throw new IOException("unrecognized GRU checkpoint trailer: 0x" + Integer.toHexString(gruMagic));
            } catch (EOFException e) {
                // save from before the trainable memory cell: the default cell is used (same behaviour as the old fixed memory)
            }
            try {
                if (in.readInt() == SITUATIONAL_TRAILER_MAGIC) agent.situational.read(in);
            } catch (EOFException e) {
                // Older checkpoints have no situational memory; it starts with a neutral prior.
            }
            return agent;
        }
    }
}