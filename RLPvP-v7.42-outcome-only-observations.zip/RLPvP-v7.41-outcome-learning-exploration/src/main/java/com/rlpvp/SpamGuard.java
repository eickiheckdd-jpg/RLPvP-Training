package com.rlpvp;

import java.util.Locale;

/**
 * Movement-regularity guard shared by Trainer and PvpSim. Jump usage is recorded for auditing but
 * has no intrinsic cost or refund by default (SPAM_JUMP_REWARD_SCALE=0). Direction reversals and
 * ordinary sprint/sneak use remain outcome-driven so W/S taps, dodges, strafes, and tactical movement
 * stay available. Only rapid sprint/sneak toggling while otherwise idle, sprint without forward input,
 * and movement stuck against an obstacle receive tiny bounded costs. Statistics are exposed by statsAndReset().
 */
final class SpamGuard {
    /** Per-tick input, filled by the caller from data it already has. */
    static final class In {
        boolean jumpFree, sneakFree;   // heads unlocked by the curriculum
        boolean jumpPressed, onGround; // the last jump action and whether I stood on the ground when it was chosen
        boolean sneaking;              // the last sneak action
        boolean realHit;               // a real, credited damaging hit landed this tick
        boolean tookHit;               // I took real damage this tick (knockback incoming): a jump soon after is a jump reset, not spam
        // ---- movement keys (W/A/S/D/sprint): the previous tick's applied action and the speed it produced ----
        boolean moveFree, sprintFree;  // forward/back or strafe head unlocked / sprint head unlocked
        int fwd, str;                  // -1 / 0 / +1 (S / none / W, A / none / D) as chosen last tick
        boolean sprintKey;             // sprint head pressed last tick
        double speed;                  // horizontal speed this tick, blocks per tick
        double enemyDist;              // distance to the opponent in blocks (0 = unknown: the far-range sneak cost is then skipped)
    }

    private static final int MAX_WINDOWS = 4;
    private final int[] age = new int[MAX_WINDOWS];
    private final boolean[] open = new boolean[MAX_WINDOWS], paid = new boolean[MAX_WINDOWS];
    private int cooldown, sinceTaken = 1000;
    private boolean prevSneak;
    private double unjustRate, sneakRate, sneakToggleRate;
    // window statistics (for the logs)
    private int resets, jumps, refunds, unjust, sneakTicks, toggles, ticks;
    private double paidNet;

    void reset() {
        java.util.Arrays.fill(open, false); java.util.Arrays.fill(paid, false); java.util.Arrays.fill(age, 0);
        cooldown = 0; sinceTaken = 1000; prevSneak = false; unjustRate = 0; sneakRate = 0; sneakToggleRate = 0;
        prevFwd = prevStr = flipCool = stuck = 0; sinceHit = 1000; prevSprint = false; flipRate = sprintToggleRate = 0; epMove = 0; flipTimerF = flipTimerS = 0;
    }

    /** @return reward for this tick; technique-like action patterns are telemetry-only. */
    private double lastJumpReward, lastMovementReward, lastOtherReward;
    double lastJumpReward() { return lastJumpReward; }
    double lastMovementReward() { return lastMovementReward; }
    double lastOtherReward() { return lastOtherReward; }

    double tick(In s) {
        double r = 0, jumpReward = 0, otherReward = 0;
        ticks++;
        final double alpha = 1.0 / Config.SPAM_EMA_TICKS;
        boolean unjustNow = false;
        sinceTaken = s.tookHit ? 0 : Math.min(sinceTaken + 1, 1000);
        if (s.jumpFree) {
            if (cooldown > 0) cooldown--;
            if (s.jumpPressed && s.onGround && cooldown == 0) {          // a jump starts (vanilla also has a 10-tick delay between jumps)
                cooldown = 10; jumps++;
                boolean reset = sinceTaken <= Config.SPAM_JR_WINDOW;          // jump reset: a justified reaction, free and never unjustified
                if (reset) resets++; else jumpReward -= Config.SPAM_JUMP_COST * Config.SPAM_JUMP_REWARD_SCALE;
                int slot = 0; // reuse a free slot, else the oldest
                for (int i = 0; i < MAX_WINDOWS; i++) { if (!open[i]) { slot = i; break; } if (age[i] > age[slot]) slot = i; }
                if (open[slot] && !paid[slot]) { unjust++; unjustNow = true; jumpReward -= Config.SPAM_JUMP_UNJUST * Config.SPAM_JUMP_REWARD_SCALE; }
                open[slot] = true; paid[slot] = reset; age[slot] = 0;
            }
            if (s.realHit) {                                               // mark the OLDEST open jump window productive for telemetry
                int best = -1;
                for (int i = 0; i < MAX_WINDOWS; i++) if (open[i] && !paid[i] && (best < 0 || age[i] > age[best])) best = i;
                if (best >= 0) { paid[best] = true; refunds++; jumpReward += Config.SPAM_JUMP_REFUND * Config.SPAM_JUMP_REWARD_SCALE; }
            }
            for (int i = 0; i < MAX_WINDOWS; i++) {
                if (!open[i]) continue;
                if (++age[i] >= Config.SPAM_JUMP_WINDOW) {
                    if (!paid[i]) { unjust++; unjustNow = true; jumpReward -= Config.SPAM_JUMP_UNJUST * Config.SPAM_JUMP_REWARD_SCALE; }
                    open[i] = false;
                }
            }
            unjustRate += alpha * ((unjustNow ? 1.0 : 0.0) - unjustRate);
            if (unjustRate > Config.SPAM_JUMP_OK) jumpReward -= Config.SPAM_RATE_W * Config.SPAM_JUMP_REWARD_SCALE * (unjustRate - Config.SPAM_JUMP_OK);
        }
        r += jumpReward;
        if (s.sneakFree) {
            if (s.sneaking) sneakTicks++;
            boolean sneakToggle = s.sneaking != prevSneak;
            if (sneakToggle) toggles++;
            sneakRate += alpha * ((s.sneaking ? 1.0 : 0.0) - sneakRate);
            sneakToggleRate += alpha * ((sneakToggle ? 1.0 : 0.0) - sneakToggleRate);
            // Sneak-toggle rate is telemetry here. The bounded penalty is applied in moveTick
            // only when the agent is otherwise idle, so tactical sneak use during movement/combat stays free.
        }
        r += otherReward;
        double movementReward = moveTick(s);
        r += movementReward;
        lastJumpReward = jumpReward; lastMovementReward = movementReward; lastOtherReward = otherReward;
        prevSneak = s.sneaking;
        paidNet += r;
        return r;
    }

    // ---- movement diagnostics plus two tiny generic waste guards; technique-like patterns are not scored ----
    private int prevFwd, prevStr, flipCool, stuck, sinceHit = 1000;
    private boolean prevSprint;
    private double flipRate, sprintToggleRate;
    private double epMove;                       // penalty paid this episode (capped by Config.SPAM_MOVE_EPISODE_CAP)
    private int flips, stuckTicks, sprintToggles, sprintNoFwd, farSneak;

    /**
     * Direction flips are counted but never penalized: they can be valid dodges, W/S-taps, sprint
     * resets, or adaptive strafing. Rapid sprint/sneak toggles are charged only while fully idle;
     * stuck movement and sprint without forward input remain tiny generic waste costs. All movement
     * guard costs are waived after combat success and bounded per tick/episode.
     */
    private double moveTick(In s) {
        double r = 0;
        final double alpha = 1.0 / Config.SPAM_EMA_TICKS;
        sinceHit = s.realHit ? 0 : Math.min(sinceHit + 1, 1000);
        boolean flip = false;
        if (s.moveFree) {
            if (flipCool > 0) flipCool--;
            boolean fwdFlip = s.fwd != 0 && prevFwd != 0 && s.fwd != prevFwd;
            boolean strFlip = s.str != 0 && prevStr != 0 && s.str != prevStr;
            if ((fwdFlip || strFlip) && flipCool == 0) { flip = true; flips++; }
            if (s.fwd != 0) prevFwd = s.fwd; else if (++flipTimerF > Config.SPAM_FLIP_WINDOW) prevFwd = 0;
            if (s.str != 0) prevStr = s.str; else if (++flipTimerS > Config.SPAM_FLIP_WINDOW) prevStr = 0;
            if (s.fwd != 0) flipTimerF = 0;
            if (s.str != 0) flipTimerS = 0;
            flipRate += alpha * ((flip ? 1.0 : 0.0) - flipRate); // telemetry only: no action-pattern penalty
            boolean pressing = s.fwd != 0 || s.str != 0;
            stuck = pressing && s.speed < Config.SPAM_STUCK_SPEED ? stuck + 1 : 0;
            if (stuck > Config.SPAM_STUCK_TICKS) { r -= Config.SPAM_STUCK_COST; stuckTicks++; }
        }
        if (s.sprintFree) {
            boolean toggle = s.sprintKey != prevSprint;
            if (toggle) sprintToggles++;
            sprintToggleRate += alpha * ((toggle ? 1.0 : 0.0) - sprintToggleRate);
            boolean idle = s.fwd == 0 && s.str == 0 && s.speed < Config.SPAM_STUCK_SPEED;
            if (idle && sinceHit >= Config.SPAM_HIT_GRACE && sinceTaken >= Config.SPAM_TAKEN_GRACE
                    && sprintToggleRate > Config.SPAM_SPRINT_TOGGLE_RATE_OK) {
                r -= Config.SPAM_TOGGLE_RATE_W * (sprintToggleRate - Config.SPAM_SPRINT_TOGGLE_RATE_OK);
            }
            if (s.sprintKey && s.fwd <= 0) { r -= Config.SPAM_SPRINT_NOFWD_COST; sprintNoFwd++; } // sprint without moving forward does nothing
        }
        prevSprint = s.sprintKey;
        boolean idle = s.fwd == 0 && s.str == 0 && s.speed < Config.SPAM_STUCK_SPEED;
        if (s.sneakFree && sinceHit >= Config.SPAM_HIT_GRACE && sinceTaken >= Config.SPAM_TAKEN_GRACE
                && sneakToggleRate > Config.SPAM_SNEAK_TOGGLE_RATE_OK) {
            // Rapid sneak flicking is charged while moving too (it looks like, and is, wasted input). Still a soft cost: no key is blocked,
            // and recovery right after a hit or taken damage is free. Holding sneak steadily is judged by the idle-only rule below.
            if (!idle) r -= Config.SPAM_SNEAK_TOGGLE + Config.SPAM_TOGGLE_RATE_W * (sneakToggleRate - Config.SPAM_SNEAK_TOGGLE_RATE_OK);
        }
        if (s.sneakFree && idle && sinceHit >= Config.SPAM_HIT_GRACE && sinceTaken >= Config.SPAM_TAKEN_GRACE) {
            // Idle crouch spam has no useful movement/combat outcome. A small duration cost
            // starts only after the EMA crosses its tolerance; active movement and post-hit
            // recovery are exempt so this cannot suppress tactical repositioning.
            if (s.sneaking && sneakRate > Config.SPAM_SNEAK_OK) {
                r -= Config.SPAM_SNEAK_RATE_W * (sneakRate - Config.SPAM_SNEAK_OK);
            }
            if (sneakToggleRate > Config.SPAM_SNEAK_TOGGLE_RATE_OK) {
                r -= Config.SPAM_SNEAK_TOGGLE + Config.SPAM_TOGGLE_RATE_W
                    * (sneakToggleRate - Config.SPAM_SNEAK_TOGGLE_RATE_OK);
            }
        }
        if (s.sneakFree && s.sneaking && !idle && s.enemyDist > Config.SPAM_FAR_SNEAK_DIST) {
            // Sneaking while closing on an enemy that is still far away only throws away speed (sneak = 30 % speed and cancels the sprint). Soft cost, same grace/caps.
            r -= Config.SPAM_FAR_SNEAK_COST; farSneak++;
        }
        if (sinceHit < Config.SPAM_HIT_GRACE || sinceTaken < Config.SPAM_TAKEN_GRACE) r = 0;                       // productive: a real hit just landed
        r = Math.max(r, -Config.SPAM_MOVE_TICK_CAP);                       // bounded per tick
        double room = Math.max(0.0, Config.SPAM_MOVE_EPISODE_CAP - epMove);
        r = -Math.min(-r, room);                                            // bounded per episode
        epMove += -r;
        return r;
    }
    private int flipTimerF, flipTimerS;

    /** One-line summary of guard observations (jump starts, productive/unproductive windows, sneak share, net reward), then clears it. */
    String statsAndReset() {
        String t = String.format(Locale.ROOT, "spam: jumps %d (reset %d, productive %d, unjustified %d) sneak %.1f%% toggles %d net %.2f", jumps, resets, refunds, unjust,
            ticks == 0 ? 0.0 : 100.0 * sneakTicks / ticks, toggles, paidNet);
        t += String.format(Locale.ROOT, " | move: flips %d stuck %d sprintToggles %d sprintNoFwd %d farSneak %d", flips, stuckTicks, sprintToggles, sprintNoFwd, farSneak);
        jumps = resets = refunds = unjust = sneakTicks = toggles = ticks = 0; paidNet = 0; flips = stuckTicks = sprintToggles = sprintNoFwd = farSneak = 0;
        return t;
    }
}
