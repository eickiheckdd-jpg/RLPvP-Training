package com.rlpvp;

/**
 * Layout of the network input. Recent lags carry the whole frame, far lags (older than Config.NEAR_LAG_MAX) only a
 * compact subset (Config.FAR_FEATURES), and the slowly changing summary (HitMemory) is appended once at the end:
 *
 *   [ lag0 frame | lag1 frame | ... | far lag0 subset | ... | summary ]
 *
 * No Minecraft classes.
 */
final class ObsLayout {
    private ObsLayout() {}

    static boolean near(int lag) {
        return lag <= Config.NEAR_LAG_MAX;
    }

    static int size(int[] lags, int frame, int farLen, int summary) {
        int n = summary;
        for (int lag : lags) n += near(lag) ? frame : farLen;
        return n;
    }

    /** First input index of lag slot {@code k}. */
    static int offset(int[] lags, int k, int frame, int farLen) {
        int o = 0;
        for (int i = 0; i < k; i++) o += near(lags[i]) ? frame : farLen;
        return o;
    }

    /** Input index of frame feature {@code f} at lag slot {@code k}, or -1 if that lag does not carry the feature. */
    static int position(int k, int f) {
        int off = offset(Config.LAGS, k, Config.FRAME, Config.FAR_FEATURES.length);
        if (near(Config.LAGS[k])) return f < Config.FRAME ? off + f : -1;
        for (int j = 0; j < Config.FAR_FEATURES.length; j++) if (Config.FAR_FEATURES[j] == f) return off + j;
        return -1;
    }

    /** Input count of the layout before sneak (48-feature frames; same lags, far features and summary). */
    static int sizePreSneak() {
        return size(Config.LAGS, Config.FRAME_PRE_SNEAK, Config.FAR_FEATURES.length, Config.SUMMARY_BASE);
    }

    /** Where each input of the pre-sneak layout (state versions 4-6 in the current lag layout) lives now: every kept input keeps its meaning. */
    static int[] preSneakMap() {
        int[] map = new int[sizePreSneak()];
        int o = 0;
        for (int k = 0; k < Config.LAGS.length; k++) {
            if (near(Config.LAGS[k])) { for (int f = 0; f < Config.FRAME_PRE_SNEAK; f++) map[o++] = position(k, f); }
            else { for (int j = 0; j < Config.FAR_FEATURES.length; j++) map[o++] = position(k, Config.FAR_FEATURES[j]); }
        }
        for (int s = 0; s < Config.SUMMARY_BASE; s++) map[o++] = summaryOffset() + s;
        return map;
    }

    /** Number of summary values in a source build with the given optional blocks. */
    static int summaryCount(boolean v2, boolean sprintFollowup, boolean memory, boolean kbTiming, boolean combat) {
        return summaryCount(v2, sprintFollowup, memory, kbTiming, combat, Config.COMBAT_FEATURES);
    }

    /** Source-layout helper for migrating checkpoints written before an appended combat observation was introduced. */
    static int summaryCount(boolean v2, boolean sprintFollowup, boolean memory, boolean kbTiming,
                            boolean combat, int sourceCombatFeatures) {
        return summaryCount(v2, sprintFollowup, memory, kbTiming, combat,
            Config.MEMORY_FEATURES, sourceCombatFeatures);
    }

    /** Source-layout helper for projects whose recurrent memory width differs from this build. */
    static int summaryCount(boolean v2, boolean sprintFollowup, boolean memory, boolean kbTiming,
                            boolean combat, int sourceMemoryFeatures, int sourceCombatFeatures) {
        return Config.SUMMARY_BASE
            + (v2 ? Config.V2_FEATURES : 0)
            + (sprintFollowup ? Config.SPRINT_FOLLOWUP_FEATURES : 0)
            + (memory ? sourceMemoryFeatures : 0)
            + (kbTiming ? Config.KB_FEATURES : 0)
            + (combat ? sourceCombatFeatures : 0);
    }

    /**
     * Best-effort migration from the historical lag-stack layout into the compact recurrent layout.
     * The newest 51-value frame and the eight stable opponent-habit features keep their coordinates.
     * Old explicit lag columns and the old 8-unit GRU trace are deliberately dropped: they are replaced
     * by the new 64-unit trainable recurrent state. A source value can map to -1 (discarded).
     */
    static int[] compactSourceMap(boolean sourceV2, boolean sourceSprintFollowup, boolean sourceMemory,
                                  boolean sourceKbTiming, boolean sourceCombat,
                                  int sourceMemoryFeatures, int sourceCombatFeatures) {
        return compactSourceMap(Config.FRAME, sourceV2, sourceSprintFollowup, sourceMemory,
            sourceKbTiming, sourceCombat, sourceMemoryFeatures, sourceCombatFeatures);
    }

    static int[] compactSourceMap(int sourceFrame, boolean sourceV2, boolean sourceSprintFollowup,
                                  boolean sourceMemory, boolean sourceKbTiming, boolean sourceCombat,
                                  int sourceMemoryFeatures, int sourceCombatFeatures) {
        int sourceSummary = summaryCount(sourceV2, sourceSprintFollowup, sourceMemory,
            sourceKbTiming, sourceCombat, sourceMemoryFeatures, sourceCombatFeatures);
        int sourceSize = size(Config.LAGS, sourceFrame, Config.FAR_FEATURES.length, sourceSummary);
        int[] map = new int[sourceSize];
        java.util.Arrays.fill(map, -1);

        // Preserve the current frame (lag zero) only. The GRU takes over temporal stacking.
        int firstFrame = 0; // lag zero is the first slot in the source layout
        for (int f = 0; f < Math.min(sourceFrame, Config.FRAME); f++) map[firstFrame + f] = f;

        int summaryOffset = sourceSize - sourceSummary;
        // Keep the recent damage-dealt signal as a warm-start approximation of the new damage differential.
        map[summaryOffset + 8] = ObsStack.DAMAGE_DIFF_SLOT;

        int src = summaryOffset + Config.SUMMARY_BASE;
        if (sourceV2) {
            // Motion observations now have dedicated compact policy columns.
            if (Config.OBS_V2) {
                for (int i = 0; i < ObsStack.MOTION_WIDTH; i++)
                    map[src + MotionMemory.POLICY_FEATURE_INDICES[i]] = ObsStack.MOTION_START + i;
            }
            src += Config.V2_FEATURES;
        }
        // SprintHitFollowupMemory is deliberately not mapped: it remains diagnostic-only.
        if (sourceSprintFollowup) src += Config.SPRINT_FOLLOWUP_FEATURES;

        if (sourceMemory && sourceMemoryFeatures >= OpponentMemory.HABITS) {
            for (int i = 0; i < OpponentMemory.HABITS; i++)
                map[src + i] = ObsStack.HABIT_START + i;
        }
        if (sourceMemory) src += sourceMemoryFeatures;

        if (sourceKbTiming) {
            if (Config.KB_TIMING) {
                for (int i = 0; i < ObsStack.KB_WIDTH; i++) map[src + i] = ObsStack.KB_START + i;
            }
            src += Config.KB_FEATURES;
        }

        if (sourceCombat) {
            int combatOffset = src;
            if (Config.COMBAT_OBSERVATIONS) {
                if (sourceCombatFeatures > CombatObservationMemory.REACH_MARGIN)
                    map[combatOffset + CombatObservationMemory.REACH_MARGIN] = ObsStack.REACH_MARGIN_SLOT;
                if (sourceCombatFeatures > CombatObservationMemory.CROSSHAIR_BOX_DX)
                    map[combatOffset + CombatObservationMemory.CROSSHAIR_BOX_DX] = ObsStack.BOX_DX_SLOT;
                if (sourceCombatFeatures > CombatObservationMemory.CROSSHAIR_BOX_DY)
                    map[combatOffset + CombatObservationMemory.CROSSHAIR_BOX_DY] = ObsStack.BOX_DY_SLOT;
                if (sourceCombatFeatures > CombatObservationMemory.DISTANCE_DELTA)
                    map[combatOffset + CombatObservationMemory.DISTANCE_DELTA] = ObsStack.DISTANCE_DELTA_SLOT;
                if (sourceCombatFeatures > CombatObservationMemory.INTERCEPT_ANGLE)
                    map[combatOffset + CombatObservationMemory.INTERCEPT_ANGLE] = ObsStack.INTERCEPT_ANGLE_SLOT;
                if (sourceCombatFeatures > CombatObservationMemory.CROSSHAIR_ON_BOX)
                    map[combatOffset + CombatObservationMemory.CROSSHAIR_ON_BOX] = ObsStack.CROSSHAIR_ON_BOX_SLOT;
                if (sourceCombatFeatures > CombatObservationMemory.MISS_TO_HIT_RATIO)
                    map[combatOffset + CombatObservationMemory.MISS_TO_HIT_RATIO] = ObsStack.MISS_TO_HIT_RATIO_SLOT;
            }
        }
        return map;
    }

    /** Maps an old no-summary frame stack to the current-frame portion of the compact recurrent input. */
    static int[] compactLegacyMap(int oldFrame, int[] oldLags) {
        int[] map = new int[oldFrame * oldLags.length];
        java.util.Arrays.fill(map, -1);
        for (int k = 0; k < oldLags.length; k++) {
            if (oldLags[k] == 0) {
                for (int f = 0; f < Math.min(oldFrame, Config.FRAME); f++) map[k * oldFrame + f] = f;
                break;
            }
        }
        return map;
    }

    /**
     * Maps source summary blocks by meaning instead of raw position. This is needed when optional blocks
     * were enabled/disabled between training runs; new target-only inputs receive zero-initialised weights.
     */
    static int[] summaryBlockMap(boolean sourceV2, boolean sourceSprintFollowup, boolean sourceMemory,
                                 boolean sourceKbTiming, boolean sourceCombat) {
        return summaryBlockMap(sourceV2, sourceSprintFollowup, sourceMemory, sourceKbTiming,
            sourceCombat, Config.COMBAT_FEATURES);
    }

    static int[] summaryBlockMap(boolean sourceV2, boolean sourceSprintFollowup, boolean sourceMemory,
                                 boolean sourceKbTiming, boolean sourceCombat, int sourceCombatFeatures) {
        int sourceSummary = summaryCount(sourceV2, sourceSprintFollowup, sourceMemory, sourceKbTiming,
            sourceCombat, sourceCombatFeatures);
        int sourceSize = size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, sourceSummary);
        int[] map = new int[sourceSize];
        java.util.Arrays.fill(map, -1);
        int sourceOffset = sourceSize - sourceSummary;
        int targetOffset = summaryOffset();
        for (int i = 0; i < sourceOffset; i++) map[i] = i;

        int src = sourceOffset;
        for (int i = 0; i < Config.SUMMARY_BASE; i++) map[src + i] = targetOffset + i;
        src += Config.SUMMARY_BASE;

        if (sourceV2) {
            if (Config.OBS_V2) for (int i = 0; i < Config.V2_FEATURES; i++) map[src + i] = targetOffset + Config.SUMMARY_BASE + i;
            src += Config.V2_FEATURES;
        }
        if (sourceSprintFollowup) {
            int targetBlock = targetOffset + Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0);
            if (Config.SPRINT_FOLLOWUP) for (int i = 0; i < Config.SPRINT_FOLLOWUP_FEATURES; i++) map[src + i] = targetBlock + i;
            src += Config.SPRINT_FOLLOWUP_FEATURES;
        }
        if (sourceMemory) {
            int targetBlock = targetOffset + Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0)
                + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0);
            if (Config.MEMORY) for (int i = 0; i < Config.MEMORY_FEATURES; i++) map[src + i] = targetBlock + i;
            src += Config.MEMORY_FEATURES;
        }
        if (sourceKbTiming) {
            int targetBlock = targetOffset + Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0)
                + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0)
                + (Config.MEMORY ? Config.MEMORY_FEATURES : 0);
            if (Config.KB_TIMING) for (int i = 0; i < Config.KB_FEATURES; i++) map[src + i] = targetBlock + i;
            src += Config.KB_FEATURES;
        }
        if (sourceCombat) {
            int targetBlock = targetOffset + Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0)
                + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0)
                + (Config.MEMORY ? Config.MEMORY_FEATURES : 0) + (Config.KB_TIMING ? Config.KB_FEATURES : 0);
            if (Config.COMBAT_OBSERVATIONS) {
                for (int i = 0; i < Math.min(sourceCombatFeatures, Config.COMBAT_FEATURES); i++) {
                    map[src + i] = targetBlock + i;
                }
            }
        }
        return map;
    }

    /** Maps an older checkpoint's summary block into the current appended-summary layout. */
    static int[] summaryMap(int oldSummaryCount) {
        int oldSize = size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, oldSummaryCount);
        int[] map = new int[oldSize];
        int oldSummaryOffset = oldSize - oldSummaryCount;
        for (int i = 0; i < oldSummaryOffset; i++) map[i] = i;
        int keep = Math.min(oldSummaryCount, Config.SUMMARY);
        for (int i = 0; i < keep; i++) map[oldSummaryOffset + i] = summaryOffset() + i;
        return map;
    }

    /** Maps a checkpoint using the original 20 summary inputs into the current layout. */
    static int[] baseSummaryMap() { return summaryMap(Config.SUMMARY_BASE); }

    /** Input index where the summary starts. */
    static int summaryOffset() {
        return Config.OBS_SIZE - Config.SUMMARY;
    }

    /**
     * Where each input of an OLD layout (frames of {@code oldFrame} floats at the lags {@code oldLags}, no summary) lives in
     * the current layout; -1 = the current layout has no such input (it is dropped).
     */
    static int[] legacyMap(int oldFrame, int[] oldLags) {
        int[] map = new int[oldFrame * oldLags.length];
        for (int ko = 0; ko < oldLags.length; ko++) {
            int kn = -1;
            for (int i = 0; i < Config.LAGS.length; i++) if (Config.LAGS[i] == oldLags[ko]) kn = i;
            for (int f = 0; f < oldFrame; f++) map[ko * oldFrame + f] = kn < 0 ? -1 : position(kn, f);
        }
        return map;
    }
}
