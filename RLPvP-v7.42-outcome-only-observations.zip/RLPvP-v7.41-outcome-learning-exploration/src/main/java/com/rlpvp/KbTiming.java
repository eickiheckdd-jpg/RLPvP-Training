package com.rlpvp;

/**
 * Knockback timing inputs (Config.KB_TIMING, default on). The policy used to see that it was hit (hurt timer, ticks since hit) but never WHEN the velocity
 * packet landed, and with lag that gap is exactly what jump-reset and w-tap timing depend on. Pure Java, shared by Trainer, PvpSim and the self-play bot.
 * Purely descriptive: it only reads what the agent already observes (its own velocity change and ground contact), nothing is scripted or rewarded here.
 *
 *   0 incoming   1 from the moment I took damage until the knockback arrives (or 8 ticks pass)
 *   1 pulse      horizontal velocity change this tick that my own keys cannot make (0 below 0.2 blocks/tick, 1 at 0.6)
 *   2 sincePulse ticks since the last pulse, 20 = none for a long time
 *   3 window     1 while knockback is incoming or arrived within 2 ticks AND I am on the ground (a diagnostic proxy for a jump-reset window)
 * The first three are general physical/timing observations. The fourth, technique-opportunity proxy is retained in telemetry
 * but deliberately excluded from policy input to preserve outcome-only strategy discovery. All are mirror-invariant.
 */
final class KbTiming {
    static final int FEATURES = 4;
    static final int POLICY_FEATURES = 3;
    static final int JUMP_WINDOW = 3;
    private static final double PULSE_LO = 0.20, PULSE_HI = 0.60, PULSE_SEEN = 0.30;
    private static final int WAIT_MAX = 8, SINCE_MAX = 20;

    private final float[] f = new float[FEATURES];
    private double pf, pr;
    private boolean have, waiting;
    private int waitTicks, sincePulse = SINCE_MAX;

    void reset() {
        have = waiting = false; waitTicks = 0; sincePulse = SINCE_MAX; pf = pr = 0;
        java.util.Arrays.fill(f, 0f);
        f[2] = 1f;
    }

    /**
     * @param frame   this tick's observation frame (frame[1] / frame[2] forward / right speed over 0.6, frame[4] on ground)
     * @param tookHit I lost HP this tick
     * @param selfJump my own jump started this tick (its boost is not knockback)
     */
    void tick(float[] frame, boolean tookHit, boolean selfJump) {
        double fwd = frame[1] * 0.6, right = frame[2] * 0.6;
        double dv = have ? Math.hypot(fwd - pf, right - pr) : 0.0;
        have = true; pf = fwd; pr = right;
        double pulse = selfJump ? 0.0 : Math.max(0.0, Math.min(1.0, (dv - PULSE_LO) / (PULSE_HI - PULSE_LO)));
        if (tookHit) { waiting = true; waitTicks = 0; }
        if (!selfJump && dv >= PULSE_SEEN) {                       // the knockback packet landed
            sincePulse = 0; waiting = false;
        } else {
            sincePulse = Math.min(SINCE_MAX, sincePulse + 1);
            if (waiting && ++waitTicks > WAIT_MAX) waiting = false;
        }
        boolean ground = frame[4] > 0.5f;
        f[0] = waiting ? 1f : 0f;
        f[1] = (float) pulse;
        f[2] = sincePulse / (float) SINCE_MAX;
        f[3] = (waiting || sincePulse <= 2) && ground ? 1f : 0f;
    }

    void fill(float[] summary) {
        if (!Config.KB_TIMING || summary.length < Config.SUMMARY) return;
        int offset = Config.SUMMARY - (Config.COMBAT_OBSERVATIONS ? Config.COMBAT_FEATURES : 0) - FEATURES;
        System.arraycopy(f, 0, summary, offset, FEATURES);
    }
}
