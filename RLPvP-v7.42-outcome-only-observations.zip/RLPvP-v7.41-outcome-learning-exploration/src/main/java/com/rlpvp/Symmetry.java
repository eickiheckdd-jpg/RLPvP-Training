package com.rlpvp;

/**
 * Left/right mirror symmetry of the policy. Pure maths, no Minecraft classes.
 *
 * The mirrored observation flips every input that carries a left/right sign (my sideways velocity, the enemy's sideways offset
 * and velocity, the yaw error and its sqrt copy, my last yaw step and last strafe) at EVERY lag slot that carries it. The
 * policy's outputs map back the same way: the yaw mean changes sign and the strafe logits swap sides.
 *
 *   logits(s) = 1/2 * ( f(s) + T f(T s) )      with T the mirror map
 *
 * is exactly equivariant: logits(T s) = T logits(s). grads() is its adjoint, used to push the gradient of the symmetric
 * logits back into the two network passes.
 */
final class Symmetry {
    private Symmetry() {}

    /** Frame features with a left/right sign (see Observation): 2, 10, 13, 17, 30, 40. */
    static final int[] LATERAL = {2, 10, 13, 17, 30, 40};

    private static final int[] POS = buildPositions();

    private static int[] buildPositions() {
        java.util.ArrayList<Integer> l = new java.util.ArrayList<>();
        if (Config.COMPACT_126) {
            for (int feature : LATERAL) l.add(feature);
            // Signed horizontal perception features must flip with the mirrored world.
            if (Config.COMBAT_OBSERVATIONS) l.add(ObsStack.BOX_DX_SLOT);
            if (Config.OBS_V2) {
                l.add(ObsStack.MOTION_START + 1); // signed strafe persistence
                l.add(ObsStack.MOTION_START + 6); // target yaw angular velocity (selected policy feature index)
            }
        } else {
            for (int k = 0; k < Config.LAGS.length; k++) {
                for (int f : LATERAL) {
                    int p = ObsLayout.position(k, f);
                    if (p >= 0) l.add(p);
                }
            }
            if (Config.OBS_V2) {
                int motionStart = ObsLayout.summaryOffset() + Config.SUMMARY_BASE;
                l.add(motionStart + 1); // signed strafe persistence
                l.add(motionStart + 5); // opponent lateral velocity
                l.add(motionStart + 8); // target yaw angular velocity
            }
            if (Config.COMBAT_OBSERVATIONS) {
                int combatStart = ObsLayout.summaryOffset() + Config.SUMMARY_BASE
                    + (Config.OBS_V2 ? Config.V2_FEATURES : 0)
                    + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0)
                    + (Config.MEMORY ? Config.MEMORY_FEATURES : 0)
                    + (Config.KB_TIMING ? Config.KB_FEATURES : 0);
                l.add(combatStart + CombatObservationMemory.CROSSHAIR_BOX_DX);
            }
        }
        int[] out = new int[l.size()];
        for (int i = 0; i < out.length; i++) out[i] = l.get(i);
        return out;
    }

    /** Input indices that change sign under the mirror. */
    static int[] positions() {
        return POS.clone();
    }

    /** The network input of the mirrored world. */
    static void obs(float[] in, float[] out) {
        if (out != in) System.arraycopy(in, 0, out, 0, in.length);
        for (int p : POS) out[p] = -in[p];
    }

    /** Combines the plain pass {@code z} and the mirrored pass {@code zm} into symmetric logits. */
    static void logits(float[] z, float[] zm, float[] out) {
        for (int i = 0; i < Config.ACTION_SIZE; i++) out[i] = 0.5f * (z[i] + zm[i]);
        out[Config.OFF_YAW] = 0.5f * (z[Config.OFF_YAW] - zm[Config.OFF_YAW]);
        int s = Config.OFF_STRAFE;
        out[s] = 0.5f * (z[s] + zm[s + 2]);
        out[s + 2] = 0.5f * (z[s + 2] + zm[s]);
    }

    /** Gradient on the symmetric logits {@code g} -> gradient for the plain pass {@code gA} and the mirrored pass {@code gB}. */
    static void grads(float[] g, float[] gA, float[] gB) {
        for (int i = 0; i < Config.ACTION_SIZE; i++) {
            gA[i] = 0.5f * g[i];
            gB[i] = 0.5f * g[i];
        }
        gB[Config.OFF_YAW] = -0.5f * g[Config.OFF_YAW];
        int s = Config.OFF_STRAFE;
        gB[s] = 0.5f * g[s + 2];
        gB[s + 2] = 0.5f * g[s];
    }
}
