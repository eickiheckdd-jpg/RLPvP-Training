package com.rlpvp;

/** Checks the v7.41 policy-only, reward-free exploration configuration. */
public final class OutcomeLearningExplorationCheck {
    private static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }

    public static void main(String[] args) {
        check("outcome-only rewards remain enabled", Config.OUTCOME_ONLY_REWARDS);
        check("technique-specific reward switch remains disabled", !Config.TECHNIQUE_REWARDS_ENABLED);
        check("critical/sprint technique identity rewards remain disabled", !Config.techniqueRewardsEnabled());
        check("technique reward scale remains exactly zero", Config.TECH_REWARD_SCALE == 0.0);
        // v7.42: the late-stage taper is back (entropy and learning rate settle toward their minimum after DECAY_TICKS); the per-head floors stay.
        check("late-stage entropy/learning rate settle to their minimum and no lower",
            Config.stageEntropyScale(9, 50_000_000L, 1L) == Config.LATE_STAGE_ENTROPY_SCALE
            && Config.stageLrScale(9, 50_000_000L, 1L) == Config.LATE_STAGE_LR_SCALE
            && Config.stageEntropyScale(9, 1L, 1L) == 1.0f && Config.stageEntropyScale(6, 50_000_000L, 1L) == 1.0f);
        check("jump and sprint have independent, nonzero exploration floors",
            Config.JUMP_ENTROPY_FLOOR_FRAC > 0.0 && Config.SPRINT_ENTROPY_FLOOR_FRAC > 0.0);
        check("play uses the learned stochastic policy (no planner stack), temperature in (0,1]",
            Config.PLAY_STACK == 0 && Config.PLAY_STOCHASTIC && Config.PLAY_TEMPERATURE > 0.0f && Config.PLAY_TEMPERATURE <= 1.0f);

        PpoAgent agent = new PpoAgent(741L);
        int outputBias = agent.actor.w.length - Config.ACTION_SIZE;
        boolean neutral = true;
        for (int i = Config.OFF_FWD; i < Config.ACTION_SIZE; i++)
            neutral &= agent.actor.w[outputBias + i] == 0.0f;
        check("fresh movement/attack/jump/sprint/sneak/hold action biases are neutral", neutral);

        float[] obs = new float[Config.OBS_SIZE];
        float[] policyLogits = agent.logitsFor(obs);
        check("policy logits are finite without any technique action prior", allFinite(policyLogits));
        check("expanded observation layout and unchanged action semantics are configured",
            Config.COMPACT_OBS_SIZE == 143 && Config.ACTION_SIZE == 15 && PpoAgent.N_ACT == 9);
        System.out.println("OutcomeLearningExplorationCheck: all checks passed");
    }

    private static boolean allFinite(float[] values) {
        if (values == null) return false;
        for (float value : values) if (!Float.isFinite(value)) return false;
        return true;
    }
}
