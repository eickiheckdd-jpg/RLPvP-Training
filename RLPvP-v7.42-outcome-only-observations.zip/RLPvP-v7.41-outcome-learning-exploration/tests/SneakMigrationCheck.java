package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;

/** Usage: SneakMigrationCheck <state.bin saved BEFORE sneak (state v4-6)>. The learned policy must survive the move to sneak (frame 48->51, output 13->14). */
public final class SneakMigrationCheck {
    static void check(String name, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + name); if (!ok) throw new AssertionError(name); }

    public static void main(String[] a) throws Exception {
        PpoAgent g = PpoAgent.load(Path.of(a[0]), 1);
        check("old save loads (ticks " + g.totalTicks + ", stage " + g.stage + ")", g.totalTicks > 0);
        int out = g.actor.w.length - Config.ACTION_SIZE;
        check("new sneak output starts with a neutral action bias", g.actor.w[out + Config.OFF_SNEAK] == 0.0f);
        double maxW = 0;
        for (int k = 0; k < Config.LAGS.length; k++) {
            for (int f = Config.FRAME_PRE_SNEAK; f < Config.FRAME; f++) {
                int pos = ObsLayout.position(k, f);
                if (pos < 0) continue;
                for (int r = 0; r < Config.HIDDEN[0]; r++) maxW = Math.max(maxW, Math.abs(g.actor.w[r * Config.OBS_SIZE + pos]));
            }
        }
        check("the 3 new sneak inputs start with weight 0 (max |w| = " + maxW + ")", maxW == 0.0);
        java.util.Random r = new java.util.Random(3);
        int same = 0, n = 50;
        for (int s = 0; s < n; s++) {
            float[] o = new float[Config.OBS_SIZE];
            for (int i = 0; i < o.length; i++) o[i] = r.nextFloat() * 2 - 1;
            for (int k = 0; k < Config.LAGS.length; k++) for (int f = Config.FRAME_PRE_SNEAK; f < Config.FRAME; f++) { int p = ObsLayout.position(k, f); if (p >= 0) o[p] = 0f; }
            float[] base = g.actGreedy(o).clone();
            for (int k = 0; k < Config.LAGS.length; k++) for (int f = Config.FRAME_PRE_SNEAK; f < Config.FRAME; f++) { int p = ObsLayout.position(k, f); if (p >= 0) o[p] = 1f; }
            float[] with = g.actGreedy(o);
            boolean eq = true;
            for (int i = 0; i < PpoAgent.N_ACT; i++) eq &= base[i] == with[i];
            if (eq) same++;
        }
        check("the migrated policy ignores the new sneak inputs until it is trained (" + same + "/" + n + " identical)", same == n);
        Path tmp = Files.createTempFile("rlpvp-sneak", ".bin");
        g.save(tmp);
        PpoAgent h = PpoAgent.load(tmp, 1);
        check("re-saved as the current state version and reloaded: identical actor", java.util.Arrays.equals(g.actor.w, h.actor.w) && h.totalTicks == g.totalTicks);
        Files.deleteIfExists(tmp);
        System.out.println("SneakMigrationCheck: all ok");
    }
}
