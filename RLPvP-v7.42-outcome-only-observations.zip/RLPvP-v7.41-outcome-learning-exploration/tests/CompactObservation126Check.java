package com.rlpvp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.file.Path;
import java.util.Arrays;

/** Expanded 143-input contract, outcome-only feature filtering, recurrent-state serialization, PPO clipping, and checkpoint transfer. */
public final class CompactObservation126Check {
    private static void check(String name, boolean ok) {
        System.out.println((ok ? "ok   " : "FAIL ") + name);
        if (!ok) throw new AssertionError(name);
    }
    private static boolean near(float a, float b) { return Math.abs(a - b) < 1e-5f; }

    public static void main(String[] args) throws Exception {
        check("compact mode enabled", Config.COMPACT_126);
        check("exact 143 observation dimensions", Config.OBS_SIZE == 143 && ObsStack.COMPACT_SIZE == 143);
        check("GRU dimensions are H=64, X=18", GruCell.H == 64 && GruCell.X == 18);
        check("BPTT window is recurrent", Config.GRU_BPTT >= 16);

        float[] frame = new float[Config.FRAME];
        for (int i = 0; i < frame.length; i++) frame[i] = (i - 20) / 100f;
        float[] summary = new float[Config.SUMMARY];
        summary[1] = 1f; summary[2] = 1f;
        summary[8] = 0.75f; summary[9] = 0.25f;
        for (int i = 0; i < MotionMemory.FEATURE_COUNT; i++)
            summary[Config.SUMMARY_BASE + i] = (i + 1) * 0.03f;
        int sprint = Config.SUMMARY_BASE + Config.V2_FEATURES;
        if (Config.SPRINT_FOLLOWUP) {
            for (int i = 0; i < Config.SPRINT_FOLLOWUP_FEATURES; i++) summary[sprint + i] = 0.91f;
        }
        int mem = sprint + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0);
        for (int i = 0; i < OpponentMemory.HABITS; i++) summary[mem + i] = (i + 1) / 20f;
        for (int i = 0; i < GruCell.H; i++) summary[mem + OpponentMemory.HABITS + i] = (i + 1) / 100f;
        int kb = mem + Config.MEMORY_FEATURES;
        for (int i = 0; i < KbTiming.FEATURES; i++) summary[kb + i] = (i + 1) * 0.11f;
        int combat = kb + Config.KB_FEATURES;
        summary[combat + CombatObservationMemory.DISTANCE_DELTA] = -0.22f;
        summary[combat + CombatObservationMemory.REACH_MARGIN] = -0.375f;
        summary[combat + CombatObservationMemory.INTERCEPT_ANGLE] = 0.44f;
        summary[combat + CombatObservationMemory.CROSSHAIR_ON_BOX] = 1f;
        summary[combat + CombatObservationMemory.MISS_TO_HIT_RATIO] = 0.77f;
        summary[combat + CombatObservationMemory.CROSSHAIR_BOX_DX] = 0.25f;
        summary[combat + CombatObservationMemory.CROSSHAIR_BOX_DY] = -0.5f;

        ObsStack stack = new ObsStack();
        float[] obs = stack.push(frame, summary);
        float[] reusable = stack.pushReusable(frame, summary);
        check("reusable compact observation exactly matches fresh output", Arrays.equals(obs, reusable));
        frame[0] += 0.125f; summary[8] = -0.25f; summary[9] = 0.5f;
        float[] secondFresh = stack.push(frame, summary);
        float[] secondReusable = stack.pushReusable(frame, summary);
        check("reusable compact observation clears stale slots between calls", Arrays.equals(secondFresh, secondReusable));
        frame[0] -= 0.125f; summary[8] = 0.75f; summary[9] = 0.25f;
        check("current frame occupies 0..50", Arrays.equals(Arrays.copyOf(obs, Config.FRAME), frame));
        check("all 64 GRU channels occupy 51..114", near(obs[ObsStack.GRU_START], 0.01f)
            && near(obs[ObsStack.GRU_START + 63], 0.64f));
        check("8 opponent habits occupy 115..122", near(obs[115], 0.05f) && near(obs[122], 0.4f));
        check("damage differential feature", near(obs[ObsStack.DAMAGE_DIFF_SLOT], 0.5f));
        check("packed hit type round-trips", ObsStack.decodeHitMask(obs[ObsStack.HIT_TYPE_SLOT]) == (HitMemory.CRIT | HitMemory.SPRINT));
        check("reach margin feature", near(obs[ObsStack.REACH_MARGIN_SLOT], -0.375f));
        check("normalized target-box dx/dy occupy their preserved compact slots",
            near(obs[ObsStack.BOX_DX_SLOT], 0.25f) && near(obs[ObsStack.BOX_DY_SLOT], -0.5f));
        boolean allMotion = true;
        for (int i = 0; i < MotionMemory.POLICY_FEATURES; i++) {
            int sourceFeature = MotionMemory.POLICY_FEATURE_INDICES[i];
            allMotion &= near(obs[ObsStack.MOTION_START + i], (sourceFeature + 1) * 0.03f);
        }
        check("all 8 non-duplicate general motion features are wired", allMotion);
        boolean allKnockback = true;
        for (int i = 0; i < KbTiming.POLICY_FEATURES; i++)
            allKnockback &= near(obs[ObsStack.KB_START + i], (i + 1) * 0.11f);
        check("all 3 general knockback-physics features are wired", allKnockback);
        check("policy exposes only the 3 technique-neutral knockback features",
            ObsStack.KB_WIDTH == 3 && ObsStack.COMBAT_START == ObsStack.KB_START + 3);
        float[] duplicateMotionChanged = summary.clone();
        duplicateMotionChanged[Config.SUMMARY_BASE + 5] = 0.97f; // exact copy of frame enemy-side velocity
        duplicateMotionChanged[Config.SUMMARY_BASE + 6] = -0.97f; // duplicate distance derivative
        check("raw lateral velocity and distance-derivative duplicates are not added again",
            Arrays.equals(obs, new ObsStack().push(frame, duplicateMotionChanged)));
        check("general combat geometry/outcome features are wired", near(obs[ObsStack.DISTANCE_DELTA_SLOT], -0.22f)
            && near(obs[ObsStack.INTERCEPT_ANGLE_SLOT], 0.44f)
            && near(obs[ObsStack.CROSSHAIR_ON_BOX_SLOT], 1f)
            && near(obs[ObsStack.MISS_TO_HIT_RATIO_SLOT], 0.77f));
        float[] summaryWithoutSprintFollowup = summary.clone();
        if (Config.SPRINT_FOLLOWUP) java.util.Arrays.fill(summaryWithoutSprintFollowup, sprint,
            sprint + Config.SPRINT_FOLLOWUP_FEATURES, 0f);
        check("SprintHitFollowupMemory is diagnostic-only and cannot change policy inputs",
            Arrays.equals(obs, new ObsStack().push(frame, summaryWithoutSprintFollowup)));
        float[] techniqueSignalsChanged = summary.clone();
        int excluded[] = { CombatObservationMemory.CRIT_EFFICIENCY_RATIO,
            CombatObservationMemory.SPRINT_HIT_EFFICIENCY_RATIO, CombatObservationMemory.DAMAGE_DIFFERENTIAL_TREND,
            CombatObservationMemory.SPRINT_MODIFIER_ACTIVE, CombatObservationMemory.TICKS_SINCE_SPRINT_INTERRUPTION,
            CombatObservationMemory.ATTACK_DURING_IFRAME, CombatObservationMemory.SPRINT_RESET_READY };
        for (int feature : excluded) techniqueSignalsChanged[combat + feature] = 0.99f;
        check("technique-labelled efficiency/state fields do not enter the compact policy input",
            Arrays.equals(obs, new ObsStack().push(frame, techniqueSignalsChanged)));
        float[] jumpWindowChanged = summary.clone();
        jumpWindowChanged[kb + KbTiming.JUMP_WINDOW] = 0.99f;
        check("jump-reset opportunity proxy does not enter the compact policy input",
            Arrays.equals(obs, new ObsStack().push(frame, jumpWindowChanged)));

        float[] mirrored = new float[Config.OBS_SIZE];
        Symmetry.obs(obs, mirrored);
        boolean symmetry = true;
        for (int i = 0; i < Config.OBS_SIZE; i++) {
            boolean lateral = false;
            for (int p : Symmetry.positions()) lateral |= i == p;
            symmetry &= near(mirrored[i], lateral ? -obs[i] : obs[i]);
        }
        check("mirror transform flips every signed motion/perception feature", symmetry);

        // Semantic conversion of a legacy summary layout into the new compact observation groups.
        int legacySummary = ObsLayout.summaryCount(true, true, true, true, true,
            OpponentMemory.FEATURES, CombatObservationMemory.FEATURES);
        int legacySize = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, legacySummary);
        int[] compactMap = ObsLayout.compactSourceMap(true, true, true, true, true,
            OpponentMemory.FEATURES, CombatObservationMemory.FEATURES);
        int legacySummaryOffset = legacySize - legacySummary;
        int sourceMotion = legacySummaryOffset + Config.SUMMARY_BASE;
        int sourceSprint = sourceMotion + Config.V2_FEATURES;
        int sourceMemory = sourceSprint + Config.SPRINT_FOLLOWUP_FEATURES;
        int sourceKb = sourceMemory + OpponentMemory.FEATURES;
        int sourceCombat = sourceKb + Config.KB_FEATURES;
        boolean selectedMotionMaps = true;
        for (int i = 0; i < MotionMemory.POLICY_FEATURES; i++) {
            int sourceFeature = MotionMemory.POLICY_FEATURE_INDICES[i];
            selectedMotionMaps &= compactMap[sourceMotion + sourceFeature] == ObsStack.MOTION_START + i;
        }
        check("semantic checkpoint map includes only selected motion observations", selectedMotionMaps
            && compactMap[sourceMotion + 5] == -1 && compactMap[sourceMotion + 6] == -1);
        check("semantic checkpoint map excludes sprint-follow-up observations",
            compactMap[sourceSprint] == -1 && compactMap[sourceSprint + Config.SPRINT_FOLLOWUP_FEATURES - 1] == -1);
        check("semantic checkpoint map includes knockback and general combat observations",
            compactMap[sourceKb] == ObsStack.KB_START
                && compactMap[sourceKb + KbTiming.POLICY_FEATURES - 1] == ObsStack.KB_START + KbTiming.POLICY_FEATURES - 1
                && compactMap[sourceKb + KbTiming.JUMP_WINDOW] == -1
                && compactMap[sourceCombat + CombatObservationMemory.MISS_TO_HIT_RATIO] == ObsStack.MISS_TO_HIT_RATIO_SLOT);

        // Trainable GRU serialization keeps weights AND Adam moments/step continuous.
        GruCell a = new GruCell();
        a.gradForTest()[0] = 0.25f;
        a.step(Config.LR_GRU, Config.GRU_MAX_NORM, 1);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) { a.writeTrainingState(out); }
        GruCell b = new GruCell();
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes.toByteArray()))) { b.readTrainingState(in); }
        check("GRU2 saves weights and Adam step", near(a.w[0], b.w[0]) && a.adamStepForTest() == 1 && b.adamStepForTest() == 1);
        a.gradForTest()[0] = 0.1f; b.gradForTest()[0] = 0.1f;
        a.step(Config.LR_GRU, Config.GRU_MAX_NORM, 1); b.step(Config.LR_GRU, Config.GRU_MAX_NORM, 1);
        check("GRU Adam state resumes deterministically", near(a.w[0], b.w[0]));

        float rawLoss = PpoAgent.huberLoss(1f - 0.9f, 1f);
        float clippedLoss = PpoAgent.clippedValueLoss(1f, 0f, 0.9f, 0.2f, 1f);
        check("PPO clipped value objective keeps the larger clipped loss", clippedLoss > rawLoss);
        check("clipped value gradient is zero outside the clip boundary when clipped loss dominates",
            near(PpoAgent.clippedValueGradient(1f, 0f, 0.9f, 0.2f, 1f), 0f));

        if (args.length > 0) {
            PpoAgent loaded = PpoAgent.load(Path.of(args[0]), 9L);
            check("v7.37 lag-stack checkpoint migrates into compact 143 policy", loaded.actor.sizes[0] == 143);
            check("current-frame input columns are retained", near(loaded.actor.w[0], 0.125f) && near(loaded.actor.w[1], -0.25f));
            check("stable opponent-habit inputs map to 115..122", near(loaded.actor.w[115], 0.75f) && near(loaded.actor.w[122], -0.5f));
            check("new GRU uses 64 hidden channels after legacy checkpoint load", GruCell.H == 64 && loaded.gruCell().w.length == GruCell.N);
        }
        System.out.println("CompactObservation126Check: all ok");
    }
}
