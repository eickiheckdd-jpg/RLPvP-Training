package com.rlpvp;

import java.io.DataOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Random;

/** Ensures original 126- and 128-input compact checkpoints retain their policy when widened to the 143-input observation contract. */
public final class Compact126CheckpointMigrationCheck {
    private static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }

    private static void migrateCompactSize(int oldInputs, float marker, long seed) throws Exception {
        int[] actorShape = new int[Config.HIDDEN.length + 2];
        int[] criticShape = new int[Config.HIDDEN.length + 2];
        actorShape[0] = criticShape[0] = oldInputs;
        System.arraycopy(Config.HIDDEN, 0, actorShape, 1, Config.HIDDEN.length);
        System.arraycopy(Config.HIDDEN, 0, criticShape, 1, Config.HIDDEN.length);
        actorShape[actorShape.length - 1] = Config.ACTION_SIZE;
        criticShape[criticShape.length - 1] = 1;

        Net oldActor = new Net(actorShape, 0.01f, new Random(seed));
        Net oldCritic = new Net(criticShape, 1.0f, new Random(seed + 1));
        oldActor.w[oldInputs - 1] = marker;
        Path checkpoint = Files.createTempFile("rlpvp-compact" + oldInputs + "-", ".bin");
        try {
            try (DataOutputStream out = new DataOutputStream(Files.newOutputStream(checkpoint))) {
                out.writeInt(0x524C5050); // RLPP
                out.writeInt(4);          // old checkpoint format: weights, no optional trailers
                out.writeInt(oldActor.w.length);
                out.writeInt(oldCritic.w.length);
                out.writeLong(12345L + oldInputs);
                out.writeInt(7);
                out.writeInt(5);
                out.writeLong(10000L);
                oldActor.write(out);
                oldCritic.write(out);
            }
            PpoAgent loaded = PpoAgent.load(checkpoint, seed + 2);
            check("" + oldInputs + "-input compact checkpoint loads into 143-input policy",
                loaded.actor.sizes[0] == 143);
            check("" + oldInputs + "-input checkpoint's final old column is preserved",
                Math.abs(loaded.actor.w[oldInputs - 1] - marker) < 1e-7f);
            boolean appendedZero = true;
            for (int i = oldInputs; i < Config.OBS_SIZE; i++)
                appendedZero &= loaded.actor.w[i] == 0f;
            check("" + oldInputs + "-input checkpoint initializes appended observation columns to zero",
                appendedZero);
            check("" + oldInputs + "-input checkpoint progress is retained",
                loaded.totalTicks == 12345L + oldInputs && loaded.stage == 5 && loaded.stageEnterTicks == 10000L);
        } finally {
            Files.deleteIfExists(checkpoint);
        }
    }

    public static void main(String[] args) throws Exception {
        check("target runtime is 143-input compact mode", Config.COMPACT_126 && Config.OBS_SIZE == 143);
        migrateCompactSize(126, 0.375f, 11L);
        migrateCompactSize(128, -0.625f, 21L);
        if (args.length > 0) {
            PpoAgent realCheckpoint = PpoAgent.load(Path.of(args[0]), 100L);
            check("real prior compact checkpoint migrates through its full current-format trailers",
                realCheckpoint.actor.sizes[0] == 143 && realCheckpoint.totalTicks > 0);
        }
    }
}
