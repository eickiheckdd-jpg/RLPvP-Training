package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;

/** Minecraft-free smoke test for the optional situational play stack and checkpoint trailer. */
public final class SituationalCombatStackCheck {
    private SituationalCombatStackCheck() {}

    private static float[] policyAction(float... values) {
        float[] action = new float[PpoAgent.N_ACT];
        System.arraycopy(values, 0, action, 0, Math.min(values.length, action.length));
        return action;
    }

    public static void main(String[] args) throws Exception {
        // This test is specifically for the optional guarded stack; v7.41 defaults to raw policy-only play.
        Config.PLAY_STACK = 3;
        PpoAgent agent = new PpoAgent(731);
        agent.resetSituationalEpisode("test-opponent");
        agent.setMask(0);
        float[] obs = new float[Config.OBS_SIZE];
        obs[0] = 0.9f; obs[6] = 1f; obs[12] = 0.40f; obs[13] = 0.02f; obs[14] = 0.02f;
        obs[15] = 0.9f; obs[20] = 0f; obs[21] = 0.6f; obs[26] = 1f; obs[34] = 0.5f;
        obs[42] = 1f; obs[44] = 1f; obs[45] = 1f; obs[47] = 0.1f;

        for (int t = 0; t < 100; t++) {
            // Synthetic frame changes exercise transitions, opponent features and reactive validation.
            obs[23] = (t % 19 < 3) ? 1f : 0f;
            obs[22] = (t % 7 < 2) ? 1f : 0f;
            obs[34] = Math.min(1f, (t % 19) / 20f);
            if (t % 17 == 0 && t > 0) {
                obs[15] = Math.max(0.1f, obs[15] - 0.01f); obs[20] = 1f;
            } else if (t % 17 != 1) obs[20] = 0f;
            float[] action = agent.actPlay(obs.clone());
            if (action.length != PpoAgent.N_ACT) throw new AssertionError("bad action length");
            for (float value : action) if (!Float.isFinite(value)) throw new AssertionError("nonfinite action");
            if (action[6] > 0.5f && (Math.round(action[2]) != 2 || action[7] > 0.5f))
                throw new AssertionError("invalid sprint-combo action survived reactive controller");
        }

        // The documented guidance-off mask must leave the policy-sampled candidate untouched.
        int oldIntelOff = Config.INTEL_OFF;
        int oldPlayStack = Config.PLAY_STACK;
        try {
            Config.PLAY_STACK = 2;
            Config.INTEL_OFF = 127;
            if (Config.INTEL_OFF != 127) throw new AssertionError("unexpected default intelligence ablation mask");
            SituationalCombatStack learnedDecisionCheck = new SituationalCombatStack();
            learnedDecisionCheck.beginEpisode("learned-decision-check");
            float[] pursueObs = new float[Config.OBS_SIZE];
            pursueObs[0] = 1f; pursueObs[6] = 1f; pursueObs[12] = 0.80f;
            pursueObs[15] = 1f; pursueObs[21] = 0f; pursueObs[23] = 0f; pursueObs[26] = 1f;
            pursueObs[34] = 1f; pursueObs[42] = 1f;
            learnedDecisionCheck.beginTick(pursueObs);
            if (!learnedDecisionCheck.status().contains("aim-independent ticks=0"))
                throw new AssertionError("default all-off mask still ran unused heuristic intelligence updates: " + learnedDecisionCheck.status());
            float[] policyChoice = policyAction(0f, 0f, 1f, 1f, 0f, 0f, 0f, 0f);
            float[] policyChoiceBefore = policyChoice.clone();
            learnedDecisionCheck.enforce(policyChoice, 0, Config.MIN_ATTACK_STRENGTH);
            if (!java.util.Arrays.equals(policyChoice, policyChoiceBefore))
                throw new AssertionError("default intelligence mask rewrote the policy's combat choices: " + java.util.Arrays.toString(policyChoice));

            float[] underchargedAttack = policyChoice.clone();
            underchargedAttack[4] = 1f;
            pursueObs[6] = 0.7f;
            learnedDecisionCheck.beginTick(pursueObs);
            ReactiveCombatController.Result gateResult = learnedDecisionCheck.enforce(underchargedAttack, 0, Config.MIN_ATTACK_STRENGTH);
            if (underchargedAttack[4] != 0f || gateResult.rejectedAttacks != 1)
                throw new AssertionError("reactive feasibility guard allowed an attack below the actual Minecraft charge gate");

            Config.INTEL_OFF = 96;
            SituationalCombatStack guideCheck = new SituationalCombatStack();
            guideCheck.beginEpisode("guide-gate-test");
            float[] farObs = new float[Config.OBS_SIZE];
            farObs[0] = 1f; farObs[6] = 1f; farObs[12] = 0.80f; // 4.8 blocks
            farObs[15] = 1f; farObs[21] = 0f; farObs[23] = 0f; farObs[26] = 1f;
            farObs[34] = 1f; farObs[42] = 1f;
            guideCheck.beginTick(farObs);
            float[] candidate = policyAction(0f, 0f, 1f, 1f, 0f, 0f, 0f, 0f);
            float[] original = candidate.clone();
            guideCheck.guideCandidate(candidate, 0, new java.util.Random(1));
            if (!java.util.Arrays.equals(candidate, original))
                throw new AssertionError("INTEL_OFF bit 64 did not disable planner candidate guidance: " + java.util.Arrays.toString(candidate));

            // The scoring-off bit must bypass the top-level heuristic evaluator too, preserving
            // the learned world-model score rather than silently adding hand-written action preferences.
            double learnedScore = 0.375;
            candidate = policyAction(0f, 0f, 2f, 1f, 1f, 0f, 1f, 0f);
            double disabledScore = guideCheck.scoreCandidate(candidate, learnedScore);
            if (Math.abs(disabledScore - learnedScore) > 1e-12)
                throw new AssertionError("INTEL_OFF bit 32 did not disable top-level candidate scoring: " + disabledScore);

            // When scoring/guidance bits are cleared, the legacy heuristic path remains available for A/B tests.
            Config.INTEL_OFF = 0;
            candidate = original.clone();
            guideCheck.guideCandidate(candidate, 0, new java.util.Random(1));
            if (java.util.Arrays.equals(candidate, original))
                throw new AssertionError("guidance-enabled planner path unexpectedly left the candidate unchanged");
            double enabledScore = guideCheck.scoreCandidate(policyAction(0f, 0f, 2f, 1f, 1f, 0f, 1f, 0f), learnedScore);
            if (Math.abs(enabledScore - learnedScore) < 1e-9)
                throw new AssertionError("scoring-enabled planner path unexpectedly added no contextual score");

            // Learned-only mode must not let the intelligence suite override policy choices or run
            // unused heuristic action-control updates on every tick.
            Config.PLAY_STACK = 3;
            candidate = original.clone();
            guideCheck.guideCandidate(candidate, 0, new java.util.Random(1));
            if (!java.util.Arrays.equals(candidate, original))
                throw new AssertionError("learned-only mode modified a policy candidate");
            SituationalCombatStack learnedOnlyCheck = new SituationalCombatStack();
            learnedOnlyCheck.beginEpisode("learned-only-test");
            learnedOnlyCheck.beginTick(farObs);
            if (!learnedOnlyCheck.status().contains("aim-independent ticks=0"))
                throw new AssertionError("learned-only mode still ran heuristic intelligence updates: " + learnedOnlyCheck.status());
            double learnedOnlyScore = learnedOnlyCheck.scoreCandidate(candidate, learnedScore);
            if (Math.abs(learnedOnlyScore - learnedScore) > 1e-12)
                throw new AssertionError("learned-only mode added a hand-authored candidate score: " + learnedOnlyScore);
        } finally {
            Config.INTEL_OFF = oldIntelOff;
            Config.PLAY_STACK = oldPlayStack;
        }

        // Exercise the actual PpoAgent play path in learned-only mode, not just the stack hooks.
        int savedStack = Config.PLAY_STACK;
        try {
            Config.PLAY_STACK = 3;
            PpoAgent learnedOnlyAgent = new PpoAgent(732);
            learnedOnlyAgent.resetSituationalEpisode("learned-only-agent-test");
            learnedOnlyAgent.setMask(0);
            for (int t = 0; t < 24; t++) {
                float[] action = learnedOnlyAgent.actPlay(obs.clone());
                if (action.length != PpoAgent.N_ACT) throw new AssertionError("learned-only returned bad action length");
                for (float value : action) if (!Float.isFinite(value)) throw new AssertionError("learned-only returned nonfinite action");
                if (action[6] > 0.5f && (Math.round(action[2]) != 2 || action[7] > 0.5f))
                    throw new AssertionError("learned-only allowed an invalid sprint combination");
            }
            if (!learnedOnlyAgent.situationalStatus().contains("aim-independent ticks=0"))
                throw new AssertionError("PpoAgent learned-only path ran the heuristic intelligence suite: " + learnedOnlyAgent.situationalStatus());
        } finally {
            Config.PLAY_STACK = savedStack;
        }

        String before = agent.situationalStatus();
        if (!before.contains("situational:") || !before.contains("intent=") || !before.contains("decision ticks=100"))
            throw new AssertionError("missing situational telemetry: " + before);
        Path checkpoint = Files.createTempFile("rlpvp-situational-check", ".bin");
        try {
            agent.save(checkpoint);
            PpoAgent loaded = PpoAgent.load(checkpoint, 4);
            String after = loaded.situationalStatus();
            if (!after.contains("situational:") || !after.contains("decision ticks=100"))
                throw new AssertionError("situational state did not survive checkpoint: " + after);
        } finally {
            Files.deleteIfExists(checkpoint);
        }
        System.out.println("PASS situational stack, reactive constraints and checkpoint trailer: " + before.replace('\n', ' '));
    }
}
