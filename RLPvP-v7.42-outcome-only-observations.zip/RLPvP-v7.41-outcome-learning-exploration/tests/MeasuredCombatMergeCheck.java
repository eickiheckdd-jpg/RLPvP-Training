package com.rlpvp;

/** Regression for the measured v7.35 fix: a legal fully charged trade remains tradeable under incoming threat. */
public final class MeasuredCombatMergeCheck {
    public static void main(String[] args) {
        float[] o = new float[Config.OBS_SIZE];
        o[0] = 1f; o[6] = 0.95f; o[12] = 2.2f / 6f;
        o[13] = 0f; o[14] = 0f; o[15] = 1f;
        o[20] = 0f; o[21] = 1f; o[22] = 0f; o[23] = 1f;
        o[26] = 1f; o[34] = 0f; o[42] = 1f; o[44] = 1f; o[45] = 1f;
        SituationalStateInterpreter interpreter = new SituationalStateInterpreter();
        SituationalStateInterpreter.State s = interpreter.interpret(o, 0f, 0f, 0f, false);
        require(s.incomingThreat, "fixture must represent an incoming swing");
        require(!s.attackOpportunity, "trade fixture must not be classified as a free punish window");
        require(s.tradeable, "full-charge, aimed, in-reach counter-hit must remain tradeable");

        o[6] = 0.89f;
        SituationalStateInterpreter.State weak = interpreter.interpret(o, 0f, 0f, 0f, false);
        require(!weak.tradeable, "undercharged swing must not qualify as a tradeable full-strength hit");
        require(Config.PLAY_STACK == 0, "default play stack should apply the raw sampled policy action");
        require((Config.INTEL_OFF & 96) == 96, "default measured ablation should disable scoring and guidance");
        System.out.println("MeasuredCombatMergeCheck: passed");
    }
    private static void require(boolean ok, String why) {
        if (!ok) throw new AssertionError(why);
    }
}
