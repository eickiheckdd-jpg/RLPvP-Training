# v7.42 — steadier policy that keeps using both jump-crits and sprint hits (nothing was run; sim sources compiled with javac)

Built on v7.41. No new reward terms.

- Late-stage settling (stage >= 8): over 4M ticks after entering the stage the entropy bonus falls linearly to 0.5x and the learning rate to 0.5x (Config.stageEntropyScale / stageLrScale, applied in Trainer, PvpSim and ParallelPvpTrain via PpoAgent.lateLrScale; independent of the KL-adaptive lrScale). The per-head entropy floors (jump 0.35, sprint now 0.25 (v7.41: 0.35), strafe 0.18, others 0.35) are NOT tapered, so a collapsing head is still lifted. Overrides: -Drlpvp.lateDecayTicks (0 = off), lateEntropyMin, lateLrMin.
- Resuming a checkpoint that is already deep in stage 9 jumps straight to the tapered value (progress = (ticks - stageEnterTicks) / decay), e.g. 3M ticks in = 0.625x.
- Play temperature 1.0 -> 0.8 (-Drlpvp.playTemp). Affects /rl play and sim probes/evals only, not training. Never argmax-only, so minority actions (crit jumps, sprint hits) are still sampled.
- tests/OutcomeLearningExplorationCheck updated for the above (not run).
- NOT done: weight averaging of checkpoints (PpoAgent.exportWeights excludes the GRU). Use the champion mechanism / sim/standing-eval.sh (50+ games per style, same seeds) to pick the best checkpoint instead.

## Far-range sneak cost
- SpamGuard: sneaking while moving (not idle) with the enemy further than 6 blocks (Config.SPAM_FAR_SNEAK_DIST, -Drlpvp.farSneakDist) costs 0.005 per tick (SPAM_FAR_SNEAK_COST, -Drlpvp.farSneakCost). Same waiver after a hit/damage, same per-tick (0.01) and per-episode (1.2) caps. SpamGuard.In gets enemyDist, filled in PvpSim and Trainer; the spam log line now shows farSneak ticks. Jump-spam penalty scale (SPAM_JUMP_REWARD_SCALE) was left at 0 on purpose: sprint-jumping to close distance is legitimate; being hit while airborne is already charged by the airborneHit term and by damage taken.
- Trainer.java parse-checked only. tests/MoveSpamCheck and SpamGuardCheck not run.
