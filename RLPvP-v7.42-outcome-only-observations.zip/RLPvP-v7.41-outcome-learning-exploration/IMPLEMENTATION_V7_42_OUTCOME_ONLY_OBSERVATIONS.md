# v7.42 — Outcome-only observation wiring

## Scope

This change exposes useful, technique-neutral information already calculated by the project to the default compact policy. It does not add technique-specific rewards, prescribe actions, or expose sprint-hit follow-up memory to the policy.

## Policy input contract

The default compact policy input changes from 128 to **143** values:

| Indices | Values | Source |
|---|---|---|
| 0–50 | Current combat frame | `Observation` |
| 51–114 | 64 recurrent GRU values | `OpponentMemory` / `GruCell` |
| 115–122 | 8 opponent-habit values | `OpponentMemory` |
| 123 | Recent damage differential | `HitMemory` summary |
| 124 | Encoded recent hit type | `HitMemory` summary |
| 125 | Reach margin | `CombatObservationMemory` |
| 126–127 | Target-box horizontal / vertical offset | `CombatObservationMemory` |
| 128–135 | 8 selected general motion / prediction features | `MotionMemory` |
| 136–138 | 3 general physical knockback / timing features | `KbTiming` |
| 139–142 | Distance change, intercept angle, crosshair-on-target-box, recent miss-to-hit ratio | `CombatObservationMemory` |

The eight selected motion features omit raw opponent lateral velocity (already in the frame) and the duplicate distance derivative (already represented by the combat-distance signal). The four appended combat features are general geometry or outcome/accuracy information. Technique-labelled efficiency and state fields are not copied into the compact policy input. `KbTiming` feature 3 (a jump-reset opportunity proxy) remains diagnostic-only; only its three general physical/timing features are exposed.

## Sprint-hit follow-up remains telemetry-only

`SprintHitFollowupMemory` is still calculated and can continue to support reports and evaluation metrics. Its eight-value block is deliberately omitted from the compact policy input and is not mapped during semantic checkpoint conversion. The legacy lag-stack/debug input path also leaves those columns zero while preserving their original coordinates.

The same legacy path filters the technique-labelled combat fields (critical-hit efficiency, sprint-hit efficiency, sprint modifier, sprint interruption age, attack-during-iframes, and sprint-reset readiness). It retains general geometry and accuracy features only.

## Reward behavior

No reward code or reward configuration was changed. The source continues to set:

- `OUTCOME_ONLY_REWARDS = true`
- `TECHNIQUE_REWARDS_ENABLED = false`
- `TECH_REWARD_SCALE = 0.0`

Technique discovery and technique-related statistics remain measurement-only under this configuration. No sprint-hit follow-up bonus or technique-specific PPO reward is introduced by this change.

## Checkpoint compatibility

The previous 126- and 128-input compact checkpoint layouts keep their existing columns at the same indices. New columns 128–142 are zero-initialized when loading those older compact checkpoints. Historical lag-stack checkpoints are semantically mapped into the 143-input layout; sprint-hit follow-up features are intentionally discarded. Action dimensions and action meanings are unchanged.

## Validation added

- Compact packer tests assert that all 8 selected motion, the 3 general knockback/timing, and the 4 general combat/outcome features reach their assigned policy indices; the jump-reset window proxy is excluded.
- Tests assert that changing sprint-hit follow-up telemetry does not change the compact policy input.
- Semantic checkpoint-map tests assert that sprint-hit follow-up values are discarded.
- Compact checkpoint migration tests cover both 126- and 128-input source policies.
- Legacy observation tests assert that sprint-follow-up and technique-labelled combat columns remain zero.
- Mirror-symmetry tests cover the signed motion and target-box features.

## Validation results

The focused Minecraft-free validation completed successfully on the final 143-input layout:

- The selected source set compiled with `javac`.
- `CompactObservation126Check` passed, including checks that the eight selected motion features and three general knockback/timing features reach the intended slots, sprint-follow-up and jump-window diagnostics do not affect policy input, and technique-labelled combat fields remain excluded.
- `Compact126CheckpointMigrationCheck` passed for both 126- and 128-input compact checkpoints. Existing columns were preserved and appended inputs were initialized to zero.
- `OutcomeLearningExplorationCheck` passed; outcome-only rewards remain enabled, technique-specific reward switch remains disabled, and technique reward scale remains zero.
- `PvpSimNetworkTest` passed (16 passed, 0 failed).
- Legacy `MemoryCheck` passed in three configurations: defaults, sprint-follow-up disabled, and combat observations disabled.

The full Gradle Minecraft build could not be completed because the Gradle wrapper could not resolve/download its distribution (`services.gradle.org` DNS failure); therefore, the Minecraft/Fabric source compilation is not verified here. The complete repository test runner was not completed. Its Stage 9 league check has a known baseline failure (`9348/20000` aggressive-specialist exposure), reproduced against the untouched uploaded archive, and a separate broad test attempt timed out later at `PpoTimeSliceCheck`.

No training run was started by this source change.
