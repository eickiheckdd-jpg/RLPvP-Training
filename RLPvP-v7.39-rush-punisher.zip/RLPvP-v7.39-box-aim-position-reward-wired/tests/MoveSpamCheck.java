package com.rlpvp;

/** Movement-key anti-spam (SpamGuard.moveTick): useful movement is free, wasteful repetition costs, penalties are bounded and recoverable. */
public final class MoveSpamCheck {
    static int fails;
    static void check(String n, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + n); if (!ok) fails++; }

    static SpamGuard.In in(int fwd, int str, boolean sprint, double speed) {
        SpamGuard.In s = new SpamGuard.In();
        s.moveFree = true; s.sprintFree = true; s.jumpFree = false; s.sneakFree = false;
        s.fwd = fwd; s.str = str; s.sprintKey = sprint; s.speed = speed; s.onGround = true;
        return s;
    }

    public static void main(String[] a) {
        SpamGuard g = new SpamGuard();
        double sum = 0;
        for (int t = 0; t < 600; t++) sum += g.tick(in(1, 0, true, 0.26));
        check("holding W + sprint while closing in costs nothing: " + sum, sum == 0);

        g = new SpamGuard(); sum = 0;
        for (int t = 0; t < 600; t++) sum += g.tick(in(1, (t / 15) % 2 == 0 ? 1 : -1, true, 0.2));
        check("strafing A/D with a switch every 15 ticks costs nothing: " + sum, sum == 0);

        g = new SpamGuard(); sum = 0; double worst = 0;
        for (int t = 0; t < 400; t++) { double r = g.tick(in(1, t % 2 == 0 ? 1 : -1, true, 0.2)); sum += r; worst = Math.min(worst, r); }
        check("A/D flipped EVERY tick remains available without an action-pattern penalty: " + sum, sum == 0.0);
        check("rapid directional changes do not create a hidden reward cost: " + worst, worst == 0.0);

        g = new SpamGuard(); sum = 0;
        for (int t = 0; t < 400; t++) { int fwd = t % 2 == 0 ? 1 : -1; sum += g.tick(in(fwd, 0, fwd > 0, 0.2)); }
        check("W/S reversals remain available for learned sprint resets: " + sum, sum == 0.0);

        g = new SpamGuard(); sum = 0;
        for (int t = 0; t < 5000; t++) sum += g.tick(in(t % 2 == 0 ? 1 : -1, t % 2 == 0 ? 1 : -1, t % 2 == 0, 0.0));
        check("the per-episode total is capped (" + sum + " >= -" + Config.SPAM_MOVE_EPISODE_CAP + ") and far below one win", sum >= -Config.SPAM_MOVE_EPISODE_CAP - 1e-9 && Config.SPAM_MOVE_EPISODE_CAP < 0.1 * Config.W_WIN);

        g = new SpamGuard(); sum = 0;
        for (int t = 0; t < 120; t++) sum += g.tick(in(1, 0, false, 0.0));
        check("holding W while not moving at all (stuck at a wall) is penalized: " + sum, sum < -0.05);

        g = new SpamGuard(); sum = 0;
        for (int t = 0; t < 40; t++) sum += g.tick(in(1, 0, false, 0.0));
        check("a short pause (under SPAM_STUCK_TICKS + 30) is nearly free: " + sum, sum > -0.1);

        g = new SpamGuard(); sum = 0;
        for (int t = 0; t < 400; t++) { SpamGuard.In s = in(1, t % 2 == 0 ? 1 : -1, true, 0.0); s.realHit = t % 10 == 0; sum += g.tick(s); }
        check("movement is free while real hits keep landing (grace): " + sum, sum == 0);

        g = new SpamGuard();
        for (int t = 0; t < 300; t++) g.tick(in(1, t % 2 == 0 ? 1 : -1, true, 0.2));
        double after = 0;
        for (int t = 0; t < 400; t++) after += g.tick(in(1, 0, true, 0.26));
        double late = 0;
        for (int t = 0; t < 100; t++) late += g.tick(in(1, 0, true, 0.26));
        check("recovery: after the habit stops the penalty fades to zero (last 100 ticks: " + late + ")", late == 0);

        g = new SpamGuard(); sum = 0;
        for (int t = 0; t < 400; t++) sum += g.tick(in(1, 0, t % 2 == 0, 0.2));
        check("sprint toggles remain available for learned W/S taps and sprint resets: " + sum, sum == 0.0);

        g = new SpamGuard(); sum = 0;
        for (int t = 0; t < 400; t++) sum += g.tick(in(0, 0, true, 0.0));
        check("sprint pressed without moving forward is (slightly) penalized: " + sum, sum < 0 && sum >= -Config.SPAM_MOVE_EPISODE_CAP - 1e-9);

        g = new SpamGuard(); sum = 0;
        for (int t = 0; t < 400; t++) sum += g.tick(in(0, 0, (t & 1) == 0, 0.0));
        check("idle sprint-button toggling is penalized: " + sum, sum < -0.05 && sum >= -Config.SPAM_MOVE_EPISODE_CAP - 1e-9);

        g = new SpamGuard(); sum = 0;
        for (int t = 0; t < 400; t++) { SpamGuard.In s = in(1, t % 2 == 0 ? 1 : -1, t % 2 == 0, 0.0); s.moveFree = false; s.sprintFree = false; sum += g.tick(s); }
        check("locked heads (curriculum) are never charged: " + sum, sum == 0);

        g = new SpamGuard(); sum = 0;
        for (int t = 0; t < 300; t++) { SpamGuard.In s = in(1, 0, true, 0.2); s.sneakFree = true; s.sneaking = t >= 100 && t < 140; sum += g.tick(s); }
        check("a 2-second sneak burst is telemetry-only, not a policy penalty: " + sum, sum == 0.0);

        g = new SpamGuard(); sum = 0;
        for (int t = 0; t < 400; t++) { SpamGuard.In s = in(0, 0, false, 0.0); s.sneakFree = true; s.sneaking = (t & 1) == 0; sum += g.tick(s); }
        check("rapid sneak toggling while idle is mildly penalized: " + sum, sum < -0.05 && sum >= -Config.SPAM_MOVE_EPISODE_CAP - 1e-9);

        System.out.println(fails == 0 ? "MoveSpamCheck OK" : "MoveSpamCheck FAILED " + fails);
        if (fails > 0) System.exit(1);
    }
}
