package com.rlpvp;

import java.util.Arrays;
import java.util.Locale;

/** Regression tests for consistent episode outcomes, timeout sizing and collapse handling. Run with sim/regression.sh. */
public final class OutcomeRegressionTest {
    private static int passed, failed;

    private static void check(boolean ok, String name) {
        if (ok) passed++;
        else { failed++; System.out.println("FAIL: " + name); }
    }

    public static void main(String[] args) {
        outcomes();
        rewards();
        episodeLength();
        curriculumReviewFlag();
        simulatorAccounting();
        deadAttackerAndDeadTarget();
        guardFailureClassification();
        guardEntryWeightsAndDemotion();
        System.out.printf(Locale.ROOT, "OutcomeRegressionTest: %d passed, %d failed%n", passed, failed);
        if (failed != 0) System.exit(1);
    }

    private static void outcomes() {
        check(EpisodeOutcome.classify(false, true, true, false) == EpisodeOutcome.WIN, "credited opponent death = win");
        check(EpisodeOutcome.classify(true, false, false, false) == EpisodeOutcome.LOSS, "player death = loss");
        EpisodeOutcome mutual = EpisodeOutcome.classify(true, true, true, false);
        check(mutual == EpisodeOutcome.MUTUAL_KO && !mutual.win() && !mutual.loss() && mutual.draw(), "mutual KO is a draw, not a win");
        check(EpisodeOutcome.classify(false, true, false, false) == EpisodeOutcome.OPP_DIED_UNCREDITED, "uncredited opponent death = no-contest");
        check(EpisodeOutcome.OPP_DIED_UNCREDITED.terminal(), "uncredited death is terminal for PPO");
        EpisodeOutcome timeout = EpisodeOutcome.classify(false, false, false, true);
        check(timeout == EpisodeOutcome.TIMEOUT && timeout.draw() && !timeout.terminal(), "timeout is a draw and bootstraps");
        check(EpisodeOutcome.classify(true, false, false, true) == EpisodeOutcome.LOSS, "death takes precedence over timeout");
        check(EpisodeOutcome.classify(false, false, false, false).noContest(), "abort is a no-contest");
    }

    private static void rewards() {
        check(Reward.terminal(EpisodeOutcome.WIN) == Config.W_WIN, "win terminal reward");
        check(Reward.terminal(EpisodeOutcome.LOSS) == -Config.W_WIN, "loss terminal reward");
        check(Reward.terminal(EpisodeOutcome.TIMEOUT) == 0.0, "timeout has no terminal bonus");
        check(Reward.terminal(EpisodeOutcome.MUTUAL_KO) == 0.0, "mutual KO terminal reward is zero");
        check(Reward.terminal(EpisodeOutcome.OPP_DIED_UNCREDITED) == 0.0, "no-contest terminal reward is zero");
        check(Reward.terminal(true, true) == 0.0 && Reward.terminal(true, false) == Config.W_WIN
                && Reward.terminal(false, true) == -Config.W_WIN, "legacy terminal overload remains compatible");
    }

    private static void episodeLength() {
        MinecraftRules.Kit p3 = MinecraftRules.DIAMOND_PROT3;
        double h = MinecraftRules.fullHitHp(p3, p3);
        check(Math.abs(h - 0.9828) < 1e-3, "Prot III full hit ~0.983 HP (" + h + ")");
        check(MinecraftRules.hitsToKill(p3, p3) == 21, "Prot III requires 21 full hits");
        check(MinecraftRules.perfectTicksToKill(p3, p3) == 240, "Prot III perfect time-to-kill 240 ticks");
        check(MinecraftRules.episodeTicks(p3, p3) == 480, "Prot III simulator timeout 480 ticks");
        check(MinecraftRules.episodeTicks(MinecraftRules.NAKED, MinecraftRules.NAKED) == 300, "naked-kit timeout remains 300 ticks");
        check(MinecraftRules.episodeTicks(MinecraftRules.DIAMOND, MinecraftRules.DIAMOND) == 300, "plain diamond stays at 300 ticks");
        check(MinecraftRules.episodeTicks(MinecraftRules.DIAMOND_PROT, MinecraftRules.DIAMOND_PROT) == 520, "Prot IV + Sharpness III timeout 520 ticks");
        check(MinecraftRules.episodeTicks(MinecraftRules.NETHERITE, MinecraftRules.NETHERITE) == 420, "netherite timeout 420 ticks");
        System.setProperty("sim.episodeTicks", "300");
        PvpSim overridden = new PvpSim(7, new PpoAgent(7));
        overridden.startEpisodeFor(Curriculum.Opponent.WALK);
        check(overridden.episodeTicks == 300, "-Dsim.episodeTicks override preserves old timeout for A/B runs");
        System.clearProperty("sim.episodeTicks");
    }

    private static void curriculumReviewFlag() {
        Curriculum c = new Curriculum();
        c.restore(6, 0);
        c.update(0);
        c.reportEpisode(false, true);
        check(c.episodesInStage() == 0, "review episode is excluded from gate using an explicit per-episode flag");
        c.reportEpisode(false, false);
        check(c.episodesInStage() == 1, "non-review episode reaches gate");
    }

    private static PvpSim newSim() {
        PvpSim sim = new PvpSim(3, new PpoAgent(3));
        sim.latency = false;
        sim.cur.force(5);
        sim.syncCurriculum();
        return sim;
    }

    private static void simulatorAccounting() {
        PvpSim s = newSim();
        s.startEpisodeFor(Curriculum.Opponent.STATIONARY);
        s.prevOppHp = 0.5f;
        s.lastHitTick = 0;
        s.creditUntil = 1000;
        s.serverBot.hp = -0.48f;
        PvpSim.EvalStats ev = new PvpSim.EvalStats();
        boolean keepGoing = s.step(false, ev);
        check(!keepGoing && s.lastOutcome == EpisodeOutcome.WIN, "credited kill ends episode as win");
        check(Math.abs(s.epDealt - 0.5f) < 1e-4, "overkill excluded from real damage metrics (" + s.epDealt + ")");
        check(ev.wins == 1 && ev.losses == 0, "kill metrics show win only");

        s.startEpisodeFor(Curriculum.Opponent.STATIONARY);
        s.lastHitTick = 0; s.creditUntil = -1; s.serverBot.hp = 0f;
        ev = new PvpSim.EvalStats();
        s.step(false, ev);
        check(s.lastOutcome == EpisodeOutcome.OPP_DIED_UNCREDITED && ev.noContest == 1 && ev.wins == 0, "uncredited death is a no-contest, not a win");

        s.startEpisodeFor(Curriculum.Opponent.STATIONARY);
        s.serverMe.hp = 0f;
        ev = new PvpSim.EvalStats();
        s.step(false, ev);
        check(s.lastOutcome == EpisodeOutcome.LOSS && ev.losses == 1 && ev.wins == 0, "player death appears as loss");

        s.startEpisodeFor(Curriculum.Opponent.STATIONARY);
        s.serverMe.hp = 0f; s.serverBot.hp = 0f;
        ev = new PvpSim.EvalStats();
        s.step(false, ev);
        check(s.lastOutcome == EpisodeOutcome.MUTUAL_KO && ev.draws == 1 && ev.wins + ev.losses == 0,
                "mutual KO is reported as a draw in simulator metrics");

        s.startEpisodeFor(Curriculum.Opponent.STATIONARY);
        s.episodeTicks = 3;
        ev = new PvpSim.EvalStats();
        while (s.step(false, ev)) { }
        check(s.lastOutcome == EpisodeOutcome.TIMEOUT && ev.draws == 1 && ev.wins + ev.losses == 0, "timeout appears as draw in evaluation metrics");

        s.startEpisodeFor(Curriculum.Opponent.STATIONARY);
        s.pendingSoft = 1.75f;
        s.step(false, new PvpSim.EvalStats());
        check(s.epDealt == 0f, "soft hit credit does not inflate real-damage metrics");
    }

    private static void deadAttackerAndDeadTarget() {
        PvpSim s = newSim();
        s.startEpisodeFor(Curriculum.Opponent.STATIONARY);
        s.me.x = 0; s.me.z = 0; s.bot.x = 1.5; s.bot.z = 0;
        s.serverMe.hp = 0f;
        float before = s.serverBot.hp;
        s.processClientPacket(true, new PvpSim.AttackMessage(true));
        check(s.serverBot.hp == before, "dead attacker's in-flight packet rejected");

        s.serverMe.hp = 20f; s.serverBot.hp = 0f;
        float myBefore = s.serverMe.hp;
        s.processClientPacket(false, new PvpSim.AttackMessage(true));
        check(s.serverMe.hp == myBefore, "attack against a dead target rejected");
    }

    private static void guardFailureClassification() {
        check(!CollapseGuard.failedWindow(10, 0, 0, 40, 40), "timeouts/even trades are not collapse by win rate alone");
        check(CollapseGuard.failedWindow(10, 0, 6, 40, 60), "loss-heavy window fails");
        check(CollapseGuard.failedWindow(10, 0, 0, 5, 5), "fleeing/no-engagement window fails");
        check(CollapseGuard.failedWindow(10, 1, 0, 20, 60), "clearly out-traded window fails");
        check(!CollapseGuard.failedWindow(10, 3, 7, 0, 100), "win rate above threshold prevents collapse classification");
    }

    private static void guardEntryWeightsAndDemotion() {
        PpoAgent agent = new PpoAgent(11);
        CollapseGuard guard = new CollapseGuard(0.5, 2, 2);
        float[][] entry = agent.exportWeights();
        guard.noteStage(6, agent);
        float[][] changed = agent.exportWeights();
        changed[0][0] += 5f;
        agent.importWeights(changed); // drift after stage entry, before first guard episode
        for (int window = 0; window < 5; window++) {
            for (int i = 0; i < Config.STATS_EVERY_EPISODES; i++) {
                guard.addEpisode(true, false, false, 0.2, 0.2, 6, agent); // failing no-damage windows must not become best
            }
        }
        check(Double.isNaN(guard.bestScore()), "failed windows are never stored as best at demotion stages");
        check(guard.takeDemotion(), "consecutive failed windows request demotion");
        check(Arrays.equals(agent.exportWeights()[0], entry[0]), "demotion restores the exact stage-entry weights");
    }
}
