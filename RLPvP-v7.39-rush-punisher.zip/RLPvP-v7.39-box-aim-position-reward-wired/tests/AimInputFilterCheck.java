package com.rlpvp;

/** Verifies the adaptive requested-degree-per-tick filter. Pure Java: no Minecraft client required. */
public final class AimInputFilterCheck {
    private static int failures;
    private static void check(String label, boolean ok) {
        System.out.println((ok ? "ok   " : "FAIL ") + label);
        if (!ok) failures++;
    }

    public static void main(String[] args) {
        AimInputFilter f = new AimInputFilter();
        double prev = f.step(45.0, 45.0);
        check("large command is filtered, not passed as a one-tick jump", prev > 0 && prev < 45.0);
        boolean monotone = true;
        for (int i = 0; i < 12; i++) {
            double next = f.step(45.0, 45.0);
            monotone &= next >= prev && next <= 45.0;
            prev = next;
        }
        check("steady request converges monotonically to requested angle effort", monotone && Math.abs(prev - 45.0) < 0.5);
        double beforeReverse = f.output();
        double reverse = f.step(-45.0, 45.0);
        check("direction reversal is slew-limited and avoids an instant sign flip", reverse > 0 && Math.abs(reverse - beforeReverse) <= 45 * Config.AIM_FILTER_MAX_STEP_FRAC + 1e-9);
        boolean finite = true;
        for (int i = 0; i < 100; i++) finite &= Double.isFinite(f.step(i % 2 == 0 ? 0.25 : -0.25, 45.0));
        check("micro-corrections and alternating inputs remain finite", finite);
        AimJitterSuppressor reversal = new AimJitterSuppressor();
        reversal.apply(6.0, 45.0, true);
        double firstReverse = reversal.apply(-6.0, 45.0, true);
        double confirmedReverse = reversal.apply(-6.0, 45.0, true);
        check("first medium reversal near target is damped, sustained reversal is then accepted",
            Math.abs(firstReverse) < 2.0 && Math.abs(confirmedReverse + 6.0) < 1e-9);
        f.reset();
        check("reset clears stored command state", f.output() == 0.0 && f.lastInput() == 0.0);
        f.step(Double.NaN, 45.0);
        check("non-finite requests are safely treated as zero", Double.isFinite(f.output()) && f.lastInput() == 0.0);
        System.out.println(failures == 0 ? "AimInputFilterCheck: ALL OK" : failures + " FAILED");
        if (failures > 0) System.exit(1);
    }
}
