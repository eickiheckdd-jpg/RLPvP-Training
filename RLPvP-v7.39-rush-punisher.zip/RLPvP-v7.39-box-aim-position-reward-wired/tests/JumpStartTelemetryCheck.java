package com.rlpvp;

/** The simulator must log jump STARTS (grounded jump command followed by airborne) in the reward audit, not only jump commands. */
public final class JumpStartTelemetryCheck {
    public static void main(String[] args) {
        int ticks = args.length > 0 ? Integer.parseInt(args[0]) : 12000;
        PpoAgent agent = new PpoAgent(3);
        PvpSim sim = new PvpSim(4, agent);
        sim.cur.force(6);
        boolean inEp = false;
        long n = 0;
        while (n < ticks) {
            sim.syncCurriculum();
            if (!inEp) { sim.startEpisode(); inEp = true; }
            inEp = sim.step(true, null);
            agent.learnTick();
            n++;
        }
        String[] h = Reward.Telemetry.csvHeader().split(",");
        String[] r = sim.rewardTelemetry.csvRow(n, 0).split(",");
        long cmds = 0, starts = 0;
        for (int i = 0; i < h.length; i++) { if (h[i].equals("jumpCommands")) cmds = Long.parseLong(r[i]); if (h[i].equals("jumpStarts")) starts = Long.parseLong(r[i]); }
        System.out.println("ticks " + n + " jumpCommands " + cmds + " jumpStarts " + starts);
        if (cmds == 0) throw new AssertionError("no jump commands issued: test is not exercising jumps");
        if (starts == 0) throw new AssertionError("jump commands logged but zero jump starts");
        System.out.println("PASS jump starts are logged");
    }
}
