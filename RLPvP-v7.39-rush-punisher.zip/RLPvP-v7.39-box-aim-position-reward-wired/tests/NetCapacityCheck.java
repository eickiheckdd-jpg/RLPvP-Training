package com.rlpvp;

import java.io.*;
import java.util.Random;

/** Model capacity: parameter counts, serialized sizes, finite outputs, gradient updates, save/load round trip, function-preserving widening, latency. */
public final class NetCapacityCheck {
    static int fails;
    static void check(String n, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + n); if (!ok) fails++; }
    static int[] sz(int in, int[] h, int out) { int[] s = new int[h.length + 2]; s[0] = in; System.arraycopy(h, 0, s, 1, h.length); s[s.length - 1] = out; return s; }

    public static void main(String[] x) throws Exception {
        int in = Config.OBS_SIZE, out = Config.ACTION_SIZE;
        int[][] hs = {{128, 128}, {512, 512}, {512, 512, 256}};
        long[] expectActor = {75534, 498702, 626446};
        for (int k = 0; k < hs.length; k++) {
            int[] s = sz(in, hs[k], out), c = sz(in, hs[k], 1);
            long pa = Net.paramCount(s), pc = Net.paramCount(c);
            check("param count " + java.util.Arrays.toString(hs[k]) + ": actor " + pa + " critic " + pc, pa == expectActor[k]);
            Net a = new Net(s, 0.01f, new Random(1));
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            a.write(new DataOutputStream(bo));
            long expect = 4L + 4L * 3 * pa;     // adamT + w + Adam m + Adam v
            check("serialized net size = 4 + 12*params (" + bo.size() + " bytes actor, " + String.format("%.2f", (bo.size() + 4.0 * 3 * pc + 4) / 1e6) + " MB actor+critic state)", bo.size() == expect);
            Net b = new Net(s, 0.01f, new Random(2));
            b.read(new DataInputStream(new ByteArrayInputStream(bo.toByteArray())));
            check("save/load round trip is exact", java.util.Arrays.equals(a.w, b.w));
            float[] xin = new float[in]; Random r = new Random(3); for (int i = 0; i < in; i++) xin[i] = (float) r.nextGaussian();
            float[] y = a.forward(xin);
            boolean fin = true; for (float v : y) fin &= Float.isFinite(v);
            check("forward output finite", fin);
            // gradient step changes parameters
            float[] before = a.w.clone();
            float[] d = new float[out]; for (int i = 0; i < out; i++) d[i] = 0.1f;
            a.forward(xin); a.backward(d); a.step(1e-3f, 5f, 1);
            double moved = 0; for (int i = 0; i < before.length; i++) moved += Math.abs(before[i] - a.w[i]);
            check("optimizer step changes parameters", moved > 0 && Float.isFinite((float) moved));
            long t0 = System.nanoTime(); int n = 300; for (int i = 0; i < n; i++) a.forward(xin);
            System.out.printf("info inference %s: %.1f us / forward (%d warm calls, not a benchmark)%n", java.util.Arrays.toString(hs[k]), (System.nanoTime() - t0) / 1e3 / n, n);
        }
        // function-preserving widening
        for (int[][] pair : new int[][][]{{{128, 128}, {512, 512}}, {{128, 128}, {256, 384}}, {{64, 64, 32}, {128, 128, 64}}}) {
            Net o = new Net(sz(in, pair[0], out), 0.5f, new Random(7));
            Net w = new Net(sz(in, pair[1], out), 0.5f, new Random(8));
            w.widenFrom(o);
            double maxd = 0; Random r = new Random(9);
            for (int t = 0; t < 20; t++) {
                float[] xin = new float[in]; for (int i = 0; i < in; i++) xin[i] = (float) r.nextGaussian();
                float[] a = o.forward(xin).clone(), b = w.forward(xin);
                for (int i = 0; i < out; i++) maxd = Math.max(maxd, Math.abs(a[i] - b[i]));
            }
            check("widen " + java.util.Arrays.toString(pair[0]) + " -> " + java.util.Arrays.toString(pair[1]) + " preserves the function (max diff " + maxd + ")", maxd < 1e-4);
            // the new units must be able to learn: a gradient step must move their outgoing weights
            float[] xin = new float[in]; for (int i = 0; i < in; i++) xin[i] = (float) r.nextGaussian();
            float[] snap = w.w.clone(); float[] d = new float[out]; for (int i = 0; i < out; i++) d[i] = 1f;
            w.forward(xin); w.backward(d); w.step(1e-2f, 100f, 1);
            int lastIn = pair[1][pair[1].length - 1], lastOld = pair[0][pair[0].length - 1];
            int offLast = Net.paramCount(sz(in, pair[1], out)) - (lastIn * out + out);
            boolean newMoved = false;
            for (int j = 0; j < out; j++) for (int i = lastOld; i < lastIn; i++) newMoved |= snap[offLast + j * lastIn + i] != w.w[offLast + j * lastIn + i];
            check("new units receive gradient (outgoing weights move after one step)", newMoved);
        }
        boolean threw = false;
        try { new Net(sz(in, new int[]{128, 128}, out), 0f, new Random(1)).widenFrom(new Net(sz(in, new int[]{256, 128}, out), 0f, new Random(1))); } catch (IllegalArgumentException e) { threw = true; }
        check("widening from a LARGER net is refused", threw);
        threw = false;
        try { new Net(sz(in, new int[]{256, 256}, out), 0f, new Random(1)).widenFrom(new Net(sz(in, new int[]{128}, out), 0f, new Random(1))); } catch (IllegalArgumentException e) { threw = true; }
        check("widening across a different depth is refused", threw);
        // PpoAgent state file round trip with the architecture selected by -Drlpvp.hidden
        PpoAgent ag = new PpoAgent(11);
        File f = File.createTempFile("rlpvp", ".bin"); f.deleteOnExit();
        ag.save(f.toPath());
        PpoAgent back = PpoAgent.load(f.toPath(), 12);
        check("PpoAgent save/load round trip (hidden " + java.util.Arrays.toString(Config.HIDDEN) + ", file " + f.length() + " bytes)", java.util.Arrays.equals(ag.actor.w, back.actor.w) && java.util.Arrays.equals(ag.critic.w, back.critic.w));
        System.out.println(fails == 0 ? "NetCapacityCheck OK" : "NetCapacityCheck FAILED " + fails);
        if (fails > 0) System.exit(1);
    }
}
