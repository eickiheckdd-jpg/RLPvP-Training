package com.rlpvp;

public final class CameraCandidateCheck {
    public static void main(String[] args) {
        float[] baseline = {0.72f, -0.21f, 1f, 2f, 1f, 0f, 1f, 0f, 0f};
        float[] candidate = {-0.91f, 0.83f, 0f, 1f, 0f, 1f, 0f, 1f, 0f};
        PpoAgent.preserveCameraCommand(candidate, baseline);
        if (candidate[0] != baseline[0] || candidate[1] != baseline[1]) throw new AssertionError("planner candidate changed camera command");
        if (candidate[2] != 0f || candidate[3] != 1f || candidate[4] != 0f) throw new AssertionError("planner candidate lost its discrete alternative");
        System.out.println("CameraCandidateCheck OK");
    }
}
