package com.rlpvp;
public final class MemoryCheck {
  static void eq(String what, float got, float want) { if (Math.abs(got - want) > 1e-5) throw new AssertionError(what + ": " + got + " != " + want); }
  public static void main(String[] a) {
    System.out.printf("lags=%d  OBS_SIZE=%d (near frames %d x %d, far %d x %d, summary %d), memory %.1f s%n", Config.LAGS.length, Config.OBS_SIZE,
      6, Config.FRAME, 5, Config.FAR_FEATURES.length, Config.SUMMARY, Config.MAX_LAG / 20.0);
    // ---- HitMemory
    HitMemory m = new HitMemory(); float[] s = new float[Config.SUMMARY];
    m.tick(0, 0, false, 0);
    m.swing(HitMemory.typeMask(true, true, false, false), true);         // full-charge falling swing = CRIT
    m.tick(8f, 0, false, 0);                                              // the hit lands next tick
    m.fill(s);
    eq("last dealt", s[0], 0.8f); eq("crit flag", s[1], 1f); eq("sprint flag", s[2], 0f); eq("sweep flag", s[3], 0f); eq("weak flag", s[4], 0f);
    eq("my hits", s[10], 1f / 6f); eq("my crits", s[12], 1f / 3f); eq("combo", s[18], 0.25f);
    m.swing(HitMemory.typeMask(false, false, false, true), true);        // uncharged swing = WEAK
    m.tick(2f, 0, false, 0); m.fill(s);
    eq("weak flag", s[4], 1f); eq("weak count", s[14], 1f / 3f); eq("combo 2", s[18], 0.5f); eq("window dealt", s[8], 10f / 20f);
    m.tick(0, 5f, true, HitMemory.SPRINT); m.fill(s);
    eq("last taken", s[5], 0.5f); eq("taken sprint flag", s[7], 1f); eq("their combo", s[19], 0.25f); eq("my combo reset", s[18], 0f); eq("enemy swings", s[15], 1f / 6f);
    m.swing(HitMemory.typeMask(true, false, false, true), false);        // whiff
    m.tick(0, 0, false, 0); m.fill(s); eq("whiffs", s[17], 1f / 6f);
    // everything falls out of the 96-tick window; "last hit" values stay until the next hit
    for (int i = 0; i < Config.MEMORY_WINDOW + 2; i++) m.tick(0, 0, false, 0);
    m.fill(s);
    eq("window dealt expired", s[8], 0f); eq("my hits expired", s[10], 0f); eq("their hits expired", s[11], 0f); eq("swings expired", s[15], 0f); eq("whiffs expired", s[17], 0f);
    eq("last dealt kept", s[0], 0.2f);
    // a hit with no swing in the credit window gets no type
    m.tick(3f, 0, false, 0); m.fill(s); eq("untyped hit: no crit flag", s[1], 0f);
    m.reset(); m.fill(s); for (float f : s) eq("reset", f, 0f);
    // ---- layout / stack
    float[] fr = new float[Config.FRAME]; for (int i = 0; i < fr.length; i++) fr[i] = i / 100f;
    ObsStack st = new ObsStack(); float[] sum = new float[Config.SUMMARY]; for (int i = 0; i < sum.length; i++) sum[i] = -0.01f * (i + 1);
    float[] out = st.push(fr, sum);
    if (out.length != Config.OBS_SIZE) throw new AssertionError("size");
    for (int k = 0; k < Config.LAGS.length; k++) for (int f = 0; f < Config.FRAME; f++) {
      int p = ObsLayout.position(k, f);
      if (p >= 0) eq("pos " + k + "/" + f, out[p], fr[f]);
    }
    for (int j = 0; j < Config.SUMMARY; j++) eq("summary " + j, out[ObsLayout.summaryOffset() + j], sum[j]);
    // far lags carry exactly FAR_FEATURES
    int far = 0; for (int k = 0; k < Config.LAGS.length; k++) { int n = 0; for (int f = 0; f < Config.FRAME; f++) if (ObsLayout.position(k, f) >= 0) n++; if (!ObsLayout.near(Config.LAGS[k])) { far++; if (n != Config.FAR_FEATURES.length) throw new AssertionError("far features"); } else if (n != Config.FRAME) throw new AssertionError("near features"); }
    // history really reaches 96 ticks back: push distinct frames and read the oldest lag
    st.reset(); float[] o = null;
    for (int t = 0; t <= 100; t++) { float[] f2 = new float[Config.FRAME]; f2[0] = t / 200f; o = st.push(f2, sum); }
    int oldest = Config.LAGS.length - 1; eq("lag 96 sees tick 4", o[ObsLayout.position(oldest, 0)], 4 / 200f); eq("lag 0 sees tick 100", o[ObsLayout.position(0, 0)], 100 / 200f);
    eq("lag 32 sees tick 68", o[ObsLayout.position(6, 0)], 68 / 200f);
    // no input index is used twice
    boolean[] used = new boolean[Config.OBS_SIZE];
    for (int k = 0; k < Config.LAGS.length; k++) for (int f = 0; f < Config.FRAME; f++) { int p = ObsLayout.position(k, f); if (p >= 0) { if (used[p]) throw new AssertionError("overlap " + p); used[p] = true; } }
    for (int j = 0; j < Config.SUMMARY; j++) { int p = ObsLayout.summaryOffset() + j; if (used[p]) throw new AssertionError("overlap summary"); used[p] = true; }
    for (boolean b : used) if (!b) throw new AssertionError("gap in the layout");
    System.out.println("far lags: " + far + " (14 features each), layout has no overlaps or gaps");
    System.out.println("MEMORY CHECKS OK");
  }}
