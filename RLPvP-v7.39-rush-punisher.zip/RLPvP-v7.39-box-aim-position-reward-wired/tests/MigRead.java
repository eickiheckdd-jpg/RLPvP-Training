package com.rlpvp;
import java.io.*; import java.nio.file.*;
/** Loads a save written by an older layout (args: state, ref, oldFrame) and checks the policy is unchanged. */
public final class MigRead { public static void main(String[] a) throws Exception {
  int oldFrame = Integer.parseInt(a[2]);
  int formatVersion;
  try (DataInputStream header = new DataInputStream(new FileInputStream(a[0]))) { header.readInt(); formatVersion = header.readInt(); }
  PpoAgent ag = PpoAgent.load(Paths.get(a[0]), 3);
  float[] oldObs, ya; float yc;
  try (DataInputStream in = new DataInputStream(new FileInputStream(a[1]))) { int n = in.readInt(); oldObs = new float[n]; for (int i=0;i<n;i++) oldObs[i]=in.readFloat(); int m = in.readInt(); ya = new float[m]; for (int i=0;i<m;i++) ya[i]=in.readFloat(); yc = in.readFloat(); }
  int[] map = ObsLayout.legacyMap(oldFrame, Config.LEGACY_LAGS);
  float[] obs = new float[Config.OBS_SIZE];
  int dropped = 0; for (int i = 0; i < oldObs.length; i++) { if (map[i] >= 0) obs[map[i]] = oldObs[i]; else dropped++; }
  float[] na = ag.actor.forward(obs); float nc = ag.critic.forward(obs)[0];
  double d = formatVersion >= 5 ? Math.abs(nc-yc) : 0.0; for (int i=0;i<ya.length;i++) d=Math.max(d, Math.abs(na[i]-ya[i]));
  System.out.println("format=" + formatVersion + " old frame " + oldFrame + " -> input " + oldObs.length + " -> " + Config.OBS_SIZE + ": ticks=" + ag.totalTicks + " stage=" + ag.stage + " dropped=" + dropped + " max policy/value diff=" + d);
  if (d > 1e-5 || ag.totalTicks != 12345 || ag.stage != 3 || dropped != 0) throw new AssertionError("migration changed the policy");
  Path p = Paths.get(a[0] + ".new"); ag.save(p); PpoAgent again = PpoAgent.load(p, 4); if (again.totalTicks != 12345) throw new AssertionError("re-load");
  System.out.println("MIGRATION OK (re-save/load of the new layout ok)");
}}
