package com.rlpvp;
import java.io.*; import java.nio.file.*; import java.util.Random;
public final class MigWrite { public static void main(String[] a) throws Exception {
  PpoAgent ag = new PpoAgent(1); ag.totalTicks = 12345; ag.stage = 3; ag.stageEnterTicks = 999;
  Random r = new Random(5); float[] obs = new float[Config.OBS_SIZE]; for (int i=0;i<obs.length;i++) obs[i]=r.nextFloat()*2-1;
  // give the nets non-trivial Adam state
  for (int i=0;i<ag.actor.w.length;i+=97) ag.actor.w[i]+=0.01f;
  float[] ya = ag.actor.forward(obs).clone(); float yc = ag.critic.forward(obs)[0];
  ag.save(Paths.get(a[0]));
  try (DataOutputStream o = new DataOutputStream(new FileOutputStream(a[1]))) { o.writeInt(Config.OBS_SIZE); for (float f: obs) o.writeFloat(f); o.writeInt(ya.length); for (float f: ya) o.writeFloat(f); o.writeFloat(yc); }
  System.out.println("old frame=" + Config.FRAME + " obs=" + Config.OBS_SIZE + " saved");
}}
