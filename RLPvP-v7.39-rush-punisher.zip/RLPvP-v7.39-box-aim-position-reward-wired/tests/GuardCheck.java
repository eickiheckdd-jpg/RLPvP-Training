package com.rlpvp;

/** Minecraft-free check of CollapseGuard: it must NOT roll back on noise or a stable run, and MUST roll back to the best weights on a real collapse. */
public class GuardCheck {
    static void window(CollapseGuard g, PpoAgent a, int stage, boolean good, boolean[] rolled) {
        for (int i = 0; i < Config.STATS_EVERY_EPISODES; i++) {
            boolean win = good, loss = !good;
            if (g.addEpisode(true, win, loss, good ? 20 : 3, good ? 3 : 20, stage, a)) rolled[0] = true;
        }
    }

    /** A fleeing window: no wins, no losses, no damage either way. */
    static void windowFlee(CollapseGuard g, PpoAgent a, int stage) {
        for (int i = 0; i < Config.STATS_EVERY_EPISODES; i++) g.addEpisode(true, false, false, 0, 0.3, stage, a);
    }

    public static void main(String[] x) {
        PpoAgent a = new PpoAgent(1);
        CollapseGuard g = new CollapseGuard();
        boolean[] rolled = {false};
        // a stable, good run: no rollback, a best checkpoint gets stored
        for (int w = 0; w < 12; w++) window(g, a, 5, true, rolled);
        boolean stable = !rolled[0] && !Double.isNaN(g.bestScore());
        System.out.println("stable run: no rollback, best stored: " + (stable ? "ok" : "FAIL"));
        // frozen self-play snapshots (benchmark = false) are never scored, even when they beat the agent
        for (int i = 0; i < 200; i++) g.addEpisode(false, false, true, 0, 20, 5, a);
        boolean ignored = !(g.rollbacks > 0);
        System.out.println("self-play episodes ignored: " + (ignored ? "ok" : "FAIL"));
        // the weights get damaged and the results collapse: it must go back to the stored best weights
        float[] before = a.actor.w.clone();
        for (int i = 0; i < a.actor.w.length; i++) a.actor.w[i] += 0.5f;
        for (int w = 0; w < 14 && !rolled[0]; w++) window(g, a, 5, false, rolled);
        boolean restored = rolled[0];
        double maxDiff = 0;
        for (int i = 0; i < before.length; i++) maxDiff = Math.max(maxDiff, Math.abs(before[i] - a.actor.w[i]));
        System.out.println("collapse -> rollback fired: " + (restored ? "ok" : "FAIL") + ", max weight difference to the best checkpoint: " + maxDiff);
        // a new stage resets the checkpoint (a different opponent is not comparable)
        boolean[] r2 = {false};
        window(g, a, 6, false, r2);
        boolean fresh = !r2[0] && Double.isNaN(g.bestScore());
        System.out.println("new stage starts clean: " + (fresh ? "ok" : "FAIL"));
        // stage collapse: the stage is entered with good weights, the policy then loses EVERY fight (or flees): restore the entry weights, ask for a demotion
        PpoAgent b = new PpoAgent(2);
        CollapseGuard c = new CollapseGuard();
        boolean[] rb = {false};
        window(c, b, 6, true, rb);                                  // stage 6 played well, weights W
        window(c, b, 7, true, rb);                                  // stage 7 entered: entry snapshot is taken here
        float[] entryW = b.actor.w.clone();
        for (int i = 0; i < b.actor.w.length; i++) b.actor.w[i] *= 0.2f; // the policy is wrecked
        boolean asked = false; int windows = 0;
        while (windows < 12 && !asked) { windowFlee(c, b, 7); windows++; asked = c.takeDemotion(); }
        double d2 = 0; for (int i = 0; i < entryW.length; i++) d2 = Math.max(d2, Math.abs(entryW[i] - b.actor.w[i]));
        boolean collapse = asked && windows <= Config.GUARD_FAIL_WINDOWS + Config.GUARD_PATIENCE + 1 && d2 < 1e-6;
        System.out.println("stage collapse (fleeing, no hits) -> entry weights restored + demotion requested after " + windows + " windows: " + (collapse ? "ok" : "FAIL (diff " + d2 + ")"));
        // a hard but not collapsed stage (20 % wins) must not be demoted
        CollapseGuard c2 = new CollapseGuard();
        window(c2, b, 7, true, rb);
        boolean wrong = false;
        for (int w = 0; w < 20; w++) { for (int i = 0; i < Config.STATS_EVERY_EPISODES; i++) c2.addEpisode(true, i < 2, i >= 2, 8, 14, 7, b); wrong |= c2.takeDemotion(); }
        System.out.println("20 % wins is hard but not a collapse (no demotion): " + (!wrong ? "ok" : "FAIL"));
        // aim stages are scored on aim, not wins: never demoted
        CollapseGuard c3 = new CollapseGuard();
        boolean aimWrong = false;
        for (int w = 0; w < 20; w++) { windowFlee(c3, b, 3); aimWrong |= c3.takeDemotion(); }
        System.out.println("aim stage (3) is never demoted on win rate: " + (!aimWrong ? "ok" : "FAIL"));
        // a collapsed window is never blessed as the best checkpoint
        CollapseGuard c4 = new CollapseGuard();
        for (int w = 0; w < 6; w++) window(c4, b, 7, false, rb);
        boolean noBless = Double.isNaN(c4.bestScore());
        System.out.println("collapsed windows are never stored as best: " + (noBless ? "ok" : "FAIL"));
        boolean all = stable && ignored && restored && maxDiff < 1e-6 && fresh && collapse && !wrong && !aimWrong && noBless;
        System.out.println(all ? "GuardCheck: all ok" : "GuardCheck: FAILED");
        if (!all) System.exit(1);
    }
}
