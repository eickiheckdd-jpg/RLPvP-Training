package com.rlpvp;

import java.util.Random;

/** Physical mouse model: hand effort, drag, velocity state, acceleration / jerk / speed limits. No simulation, no training. */
public final class CameraDynamicsCheck {
    static int fails;

    static void check(String name, boolean ok) {
        System.out.println((ok ? "ok   " : "FAIL ") + name);
        if (!ok) fails++;
    }

    public static void main(String[] args) {
        final double scale = Config.YAW_SCALE, accMax = Config.CAM_ACC_MAX_FRAC * scale, jerkMax = Config.CAM_JERK_MAX_FRAC * scale;
        System.out.printf("physical mouse %s: drag %.2f, acc limit %.1f deg/tick^2, jerk limit %.1f deg/tick^3, %d substeps%n",
            Config.CAMERA_DYNAMICS ? "ON" : "OFF", Config.CAM_MOUSE_DRAG, accMax, jerkMax, Config.CAM_SUBSTEPS);

        // 1) step response: full hand effort from rest
        CameraDynamics d = new CameraDynamics();
        double maxV = 0, maxA = 0, maxJ = 0, angle = 0;
        int t90 = -1, t99 = -1;
        boolean mono = true;
        double prev = 0;
        for (int t = 1; t <= 40; t++) {
            angle += d.step(scale, scale);
            if (d.vel() < prev - 1e-9) mono = false;
            prev = d.vel();
            maxV = Math.max(maxV, d.vel()); maxA = Math.max(maxA, Math.abs(d.acc())); maxJ = Math.max(maxJ, Math.abs(d.lastJerk()));
            if (t90 < 0 && d.vel() >= 0.9 * scale) t90 = t;
            if (t99 < 0 && d.vel() >= 0.99 * scale) t99 = t;
        }
        System.out.printf("full-speed step: 90%% after %d ticks (%d ms), 99%% after %d ticks; peak acc %.1f, peak jerk %.1f%n", t90, t90 * 50, t99, maxA, maxJ);
        check("full hand effort produces a monotonic start-up without exceeding the mouse speed limit", mono && maxV <= scale + 1e-9);
        // threshold updated 6 -> 10 ticks: Config was retuned to acc 0.30 / jerk 0.12 (9 ticks to 90%); the old 6-tick threshold belonged to the 0.7 / 1.0 constants and had been failing
        check("reaches 90% of maximum mouse speed within 10 ticks (500 ms)", t90 > 0 && t90 <= 10);
        check("acceleration and jerk stay inside their limits in the step response", maxA <= accMax + 1e-6 && maxJ <= jerkMax + 1e-6);

        // 2) limits under hostile commands (bang-bang, noise, saturated), both axes
        Random r = new Random(3);
        for (double sc : new double[]{Config.YAW_SCALE, Config.PITCH_SCALE}) {
            CameraDynamics e = new CameraDynamics();
            double mv = 0, ma = 0, mj = 0, aBound = sc * Config.CAM_ACC_MAX_FRAC, jBound = sc * Config.CAM_JERK_MAX_FRAC;
            for (int t = 0; t < 200000; t++) {
                double cmd = (t / 7) % 2 == 0 ? sc : -sc;                 // reverses every 7 ticks
                if (t % 3 == 0) cmd = (r.nextDouble() * 2 - 1) * sc;        // plus noise
                if (t % 11 == 0) cmd = 5 * sc;                              // beyond the limit
                e.step(cmd, sc);
                mv = Math.max(mv, Math.abs(e.vel())); ma = Math.max(ma, Math.abs(e.acc())); mj = Math.max(mj, Math.abs(e.lastJerk()));
            }
            check(String.format("scale %.0f: |v| <= scale, |a| <= %.1f, |jerk| <= %.1f over 200k hostile ticks (max %.2f / %.2f / %.2f)", sc, aBound, jBound, mv, ma, mj),
                mv <= sc + 1e-9 && ma <= aBound + 1e-6 && mj <= jBound + 1e-6);
        }

        // 3) a reversal cannot snap: push the mouse one way, then the other
        d = new CameraDynamics();
        for (int t = 0; t < 30; t++) d.step(scale, scale);
        int ticks = 0;
        double maxDelta = 0;
        while (d.vel() > -0.9 * scale && ticks < 50) { double dl = d.step(-scale, scale); ticks++; maxDelta = Math.max(maxDelta, Math.abs(dl)); }
        System.out.printf("full reversal takes %d ticks (%d ms)%n", ticks, ticks * 50);
        check("a full reversal takes at least 2 ticks (no instant flip)", ticks >= 2);

        // 4) odd symmetry (mirror training) and yaw/pitch consistency (same normalised response for different scales)
        CameraDynamics p = new CameraDynamics(), m = new CameraDynamics(), pitch = new CameraDynamics(), yaw = new CameraDynamics();
        double worstOdd = 0, worstScale = 0;
        for (int t = 0; t < 400; t++) {
            double cmd = Math.sin(t * 0.13) * 0.8 + (r.nextDouble() - 0.5) * 0.4;
            double a1 = p.step(cmd * scale, scale), a2 = m.step(-cmd * scale, scale);
            worstOdd = Math.max(worstOdd, Math.abs(a1 + a2));
            double ay = yaw.step(cmd * Config.YAW_SCALE, Config.YAW_SCALE) / Config.YAW_SCALE, ap = pitch.step(cmd * Config.PITCH_SCALE, Config.PITCH_SCALE) / Config.PITCH_SCALE;
            worstScale = Math.max(worstScale, Math.abs(ay - ap));
        }
        check("odd in mouse effort (mirror training stays valid), worst difference " + worstOdd, worstOdd < 1e-9);
        check("yaw and pitch respond identically in normalised units, worst difference " + worstScale, worstScale < 1e-9);

        // 5) releasing the mouse gradually stops its motion; it does not teleport to rest.
        d = new CameraDynamics();
        for (int t = 0; t < 20; t++) d.step(scale, scale);
        double vRelease = d.vel();
        double prevRelease = vRelease;
        boolean releaseSlows = true;
        for (int t = 0; t < 12; t++) {
            d.step(0.0, scale);
            if (d.vel() > prevRelease + 1e-8) releaseSlows = false;
            prevRelease = d.vel();
        }
        check("release input lets drag stop the mouse gradually (no extra acceleration)", releaseSlows && d.vel() < vRelease && d.vel() >= -1e-9);

        // 6) reset / halt / pass-through
        d = new CameraDynamics();
        for (int t = 0; t < 10; t++) d.step(scale, scale);
        d.halt();
        check("halt() zeroes velocity and acceleration", d.vel() == 0 && d.acc() == 0);
        for (int t = 0; t < 10; t++) d.step(scale, scale);
        d.reset();
        check("reset() gives a still camera", d.vel() == 0 && d.acc() == 0 && d.lastJerk() == 0);
        CameraDynamics off = new CameraDynamics(false, 0.7, 1.0, 0.7, 4);
        check("dynamics off = pass-through (velocity = clamped command)", off.step(10.0, scale) == 10.0 && off.vel() == 10.0 && Math.abs(off.step(500.0, scale)) == scale);

        // 7) a small effort moves the mouse gently (micro adjustment) for 20 ticks
        d = new CameraDynamics();
        double moved = 0;
        for (int t = 0; t < 20; t++) moved += d.step(0.2, scale);
        System.out.printf("small effort held 20 ticks: relative movement %.2f deg-equivalent%n", moved);
        check("small commands are followed (no dead zone)", moved > 3.0 && moved <= 4.0 + 1e-9);

        System.out.println(fails == 0 ? "ALL OK" : fails + " FAILED");
        if (fails > 0) System.exit(1);
    }
}
