package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;

/** Verifies one-time parsing preserves reward-tuning defaults, clamping, and immutable-process semantics. */
public final class RewardTuningCheck {
    public static void main(String[] args) throws Exception {
        Path p = Files.createTempFile("rlpvp-reward-tuning", ".properties");
        try {
            Files.writeString(p, "damage = 2.5\nfacing = -4\npitch = invalid\ncloseness = 12\ntime = 0.75\n");
            System.setProperty("rlpvp.rewards.path", p.toString());
            check(RewardTuning.get("damage") == 2.5, "configured multiplier parsed");
            check(RewardTuning.get("facing") == 0.0, "negative multiplier clamped");
            check(RewardTuning.get("pitch") == 1.0, "invalid multiplier falls back");
            check(RewardTuning.get("closeness") == 10.0, "large multiplier clamped");
            check(RewardTuning.get("missing") == 1.0, "missing multiplier defaults to one");
            Files.writeString(p, "damage=9.0\n");
            check(RewardTuning.get("damage") == 2.5, "values remain fixed after process startup");
            System.out.println("RewardTuningCheck: all ok");
        } finally { Files.deleteIfExists(p); }
    }
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
}
