package com.rlpvp;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.util.Arrays;
import java.util.Random;

/** Fast regression for direct consequence-model state adoption. */
public final class ConsequenceStateCopyCheck {
    public static void main(String[] args) throws Exception {
        ConsequenceModel source = new ConsequenceModel(new Random(314159));
        Random rng = new Random(271828);
        float[] obs = new float[Config.OBS_SIZE];
        float[] action = new float[PpoAgent.N_ACT];
        float[] next = new float[Config.FRAME];
        for (int n = 0; n < 64; n++) {
            for (int i = 0; i < obs.length; i++) obs[i] = rng.nextFloat() * 2f - 1f;
            for (int i = 0; i < action.length; i++) action[i] = rng.nextFloat() * 2f - 1f;
            for (int i = 0; i < next.length; i++) next[i] = rng.nextFloat() * 2f - 1f;
            source.observe(obs, action, next);
        }
        ConsequenceModel copy = new ConsequenceModel(new Random(7));
        copy.copyPersistedStateFrom(source);
        ByteArrayOutputStream a = new ByteArrayOutputStream();
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        source.write(new DataOutputStream(a));
        copy.write(new DataOutputStream(b));
        if (!Arrays.equals(a.toByteArray(), b.toByteArray()))
            throw new AssertionError("direct copy is not byte-identical to persisted source state");
        System.out.println("ConsequenceStateCopyCheck: byte-identical persisted state");
    }
}
