package com.rlpvp;

/** Proves stage progression depends on performance only: no timer can promote, a full winning window does. */
public final class CurriculumGateCheck {
    static void check(String name, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + name); if (!ok) throw new AssertionError(name); }

    private static boolean rejectsGate(int stage) {
        try { Curriculum.gateFor(stage, 0); return false; }
        catch (IllegalArgumentException expected) { return expected.getMessage().contains("no episode win-rate gate"); }
    }

    public static void main(String[] a) {
        Curriculum c = new Curriculum();
        c.restore(3, 0);
        long ticks = 0;
        c.update(ticks);
        // 1) a huge amount of time and losing episodes: never promoted
        for (int i = 0; i < 2000; i++) { c.reportEpisode(false); ticks += 1_000; c.update(ticks); }
        check("2000 losing episodes / 2M ticks do not promote (no max-tick timer)", c.autoStage() == 3);
        check("stalled stage is reported", c.describe().contains("STALLED"));
        // 2) a long stretch with NO episodes (pure time) does not promote either
        c.update(ticks + 50_000_000L);
        check("50M ticks without episodes do not promote", c.autoStage() == 3);
        // 3) winning needs a full window: 29 wins are not enough, the 30th (a full window at 100%) is
        Curriculum d = new Curriculum();
        d.restore(3, 0); d.update(0);
        for (int i = 0; i < Config.GATE_EPISODES - 1; i++) { d.reportEpisode(true); d.update(10L * i); }
        check("a partly filled window (29 wins) does not promote", d.autoStage() == 3);
        check("progress bar is below 1 while the window fills", d.progress(0) > 0.9 && d.progress(0) < 1.0);
        d.reportEpisode(true); d.update(1);
        check("a full winning window alone does NOT promote: it must be sustained", d.autoStage() == 3);
        for (int i = 0; i < Config.GATE_HOLD_EPISODES - 2; i++) { d.reportEpisode(true); d.update(2L + i); }
        check("still held one episode short of the sustain requirement", d.autoStage() == 3);
        d.reportEpisode(true); d.update(99);
        check("a full winning window held for GATE_HOLD_EPISODES more episodes promotes, regardless of elapsed ticks", d.autoStage() == 4);
        check("the new stage starts with an empty window", !d.windowFull() && d.progress(0) == 0.0);
        // a dip below the gate restarts the sustain count
        Curriculum h = new Curriculum(); h.restore(3, 0); h.update(0);
        for (int i = 0; i < Config.GATE_EPISODES; i++) h.reportEpisode(true);
        for (int i = 0; i < 20; i++) h.reportEpisode(true);
        for (int i = 0; i < 20; i++) h.reportEpisode(false); // window drops below the gate: sustain restarts
        for (int i = 0; i < 10; i++) { h.reportEpisode(true); h.update(500L + i); }
        check("a dip below the gate resets the sustain count", h.autoStage() == 3);
        // collapse of the next stage: demote, and the gate to leave the stage before it rises
        Curriculum k = new Curriculum(); k.restore(7, 0); k.update(0);
        check("demote goes back exactly one stage", k.demote(10) && k.autoStage() == 6);
        check("after a collapse the gate to leave that stage rises by GATE_BUMP_PER_COLLAPSE", Math.abs(Curriculum.gateFor(6, 1) - (Config.STAGE_GATE_WIN[5] + Config.GATE_BUMP_PER_COLLAPSE)) < 1e-6);
        check("the bump is capped", Curriculum.gateFor(6, 50) <= Config.STAGE_GATE_WIN[5] + Config.GATE_BUMP_MAX + 1e-6);
        check("the bumped gate is enforced", !Curriculum.mayAdvance(6, Config.STAGE_GATE_WIN[5] + 0.01, true, true, true, 1) && Curriculum.mayAdvance(6, Config.STAGE_GATE_WIN[5] + 0.06, true, true, true, 1));
        Curriculum one = new Curriculum(); one.restore(1, 0); one.update(0);
        check("stage 1 cannot be demoted further", !one.demote(0) && one.autoStage() == 1);
        // 4) exactly the gate rate over a full window promotes, one win fewer does not
        int need = (int) Math.ceil(Config.STAGE_GATE_WIN[3] * Config.GATE_EPISODES);
        Curriculum e = new Curriculum(); e.restore(4, 0); e.update(0);
        for (int i = 0; i < Config.GATE_EPISODES; i++) e.reportEpisode(i < need - 1);
        e.update(1);
        check("one win below the gate holds", e.autoStage() == 4);
        Curriculum f = new Curriculum(); f.restore(4, 0); f.update(0);
        for (int i = 0; i < Config.GATE_EPISODES; i++) f.reportEpisode(i < need);
        f.setGreedyResult(5.0, 20, 5);
        for (int i = 0; i < Config.GATE_HOLD_EPISODES - 1; i++) f.reportEpisode(i % Config.GATE_EPISODES < need);
        f.update(1);
        check("exactly the gate rate with greedy ok promotes", f.autoStage() == 5);
        // ---- adaptive hop level of the stationary bot (stage 2): performance driven, and required before leaving the stage
        Curriculum hp = new Curriculum(); hp.restore(2, 0); hp.update(0);
        check("hop level starts at 0 (no hops until the agent has learned the static aim)", hp.hopLevel() == 0.0);
        for (int i = 0; i < Config.BOT_HOP_WINDOW; i++) hp.reportEpisode(true);
        check("a successful window raises the hop level by one step", Math.abs(hp.hopLevel() - Config.BOT_HOP_STEP) < 1e-9);
        for (int i = 0; i < Config.BOT_HOP_WINDOW; i++) hp.reportEpisode(i < 6); // 60 %: between the thresholds
        check("a middling window leaves the hop level alone", Math.abs(hp.hopLevel() - Config.BOT_HOP_STEP) < 1e-9);
        for (int i = 0; i < Config.BOT_HOP_WINDOW; i++) hp.reportEpisode(false);
        check("a failed window lowers the hop level again (never below 0)", hp.hopLevel() == 0.0);
        for (int i = 0; i < Config.BOT_HOP_WINDOW; i++) hp.reportEpisode(false);
        check("hop level stays at 0 under continued failure", hp.hopLevel() == 0.0);
        for (int w = 0; w < 30; w++) for (int i = 0; i < Config.BOT_HOP_WINDOW; i++) hp.reportEpisode(true);
        check("hop level is capped at 1", hp.hopLevel() == 1.0);
        // promotion out of stage 2 needs the gate AND the hop level
        Curriculum g2 = new Curriculum(); g2.restore(2, 0); g2.update(0);
        for (int i = 0; i < 400; i++) { g2.reportEpisode(i % 10 < 7); g2.update(i); } // 70 %: above the 60 % gate, below the 75 % needed to raise the hop level
        check("stage 2 is NOT left while the hop level is below the required level, however long the gate is held (70 % success, hop " + g2.hopLevel() + ")", g2.autoStage() == 2 && g2.hopLevel() < Config.BOT_HOP_REQUIRED_LEVEL);
        for (int i = 0; i < 400 && g2.autoStage() == 2; i++) { g2.reportEpisode(true); g2.update(1000 + i); }
        check("with sustained high success the hop level reaches the required level and the stage is left", g2.autoStage() == 3);
        Curriculum no = new Curriculum(); no.restore(4, 0); no.update(0);
        for (int i = 0; i < Config.BOT_HOP_WINDOW * 3; i++) no.reportEpisode(true);
        check("no hop level outside the stationary-bot stage", no.hopLevel() == 0.0);
        // ---- review mixing: replays of earlier opponents never count toward the gate
        Curriculum five = new Curriculum(); five.restore(5, 0); five.update(0);
        check("no review mixing before stage " + Config.REVIEW_FROM_STAGE, five.reviewShare() == 0.0);
        Curriculum leagueStage = new Curriculum(); leagueStage.restore(7, 0); leagueStage.update(0);
        check("stage 7 is now PFSP league only, not legacy review sampling", leagueStage.reviewShare() == 0.0);
        Curriculum rv = new Curriculum(); rv.restore(6, 0); rv.update(0);
        java.util.Random rr = new java.util.Random(1);
        int reviews = 0, total = 4000; boolean onlyEarlier = true;
        for (int i = 0; i < total; i++) {
            Curriculum.Opponent o = rv.sampleOpponent(rr);
            if (rv.lastEpisodeWasReview()) { reviews++; onlyEarlier &= o != Curriculum.Opponent.AGGRESSIVE && o != Curriculum.Opponent.SELF_PLAY; rv.reportEpisode(true); }
        }
        check(String.format("stage 6 replays earlier opponents about %.0f %% of episodes (got %.1f %%)", 100 * Config.REVIEW_SHARE, 100.0 * reviews / total), Math.abs(reviews / (double) total - Config.REVIEW_SHARE) < 0.05);
        check("replays are only opponents of earlier stages", onlyEarlier);
        check("replayed episodes never fill the gate window", !rv.windowFull());

        // Stages 7-9 use league/Elo progression, never the episode win-gate table.
        check("stage 7 has no episode win-rate gate", !Curriculum.hasWinRateGate(7));
        check("stage 8 has no episode win-rate gate", !Curriculum.hasWinRateGate(8));
        check("stage 9 has no episode win-rate gate", !Curriculum.hasWinRateGate(9));
        check("normal gate API refuses stage 8 with a clear error", rejectsGate(8));
        check("normal gate API refuses stage 9 with a clear error", rejectsGate(9));
        check("league stages cannot be promoted by the normal win-rate API",
            !Curriculum.mayAdvance(7, 1.0, true) && !Curriculum.mayAdvance(8, 1.0, true)
                && !Curriculum.mayAdvance(9, 1.0, true));
        for (int stage = 7; stage <= 9; stage++) {
            Curriculum league = new Curriculum();
            league.restore(stage, 0); league.update(0);
            // The former Stage 8 bug fired on the 30th report, when this window first became full.
            for (int i = 0; i < Config.GATE_EPISODES; i++) league.reportEpisode(true);
            check("stage " + stage + " accepts a full episode window without indexing a win-gate array",
                league.windowFull() && league.autoStage() == stage);
            check("stage " + stage + " status/description/progress remain safe",
                league.status() != null && league.describe() != null && league.progress(0) >= 0.0);
        }
        // League-based promotions remain intact after guarding the normal gate path.
        Curriculum promotion = new Curriculum();
        promotion.restore(8, 0); promotion.update(0);
        promotion.setLeagueRating(OpponentLeague.ADVANCED_PROMOTION_RATING, OpponentLeague.ADVANCED_PROMOTION_GAMES);
        check("stage 8 still promotes to Stage 9 using its Elo/game requirements", promotion.update(1)
            && promotion.autoStage() == 9);
        System.out.println("CurriculumGateCheck: all ok");
    }
}
