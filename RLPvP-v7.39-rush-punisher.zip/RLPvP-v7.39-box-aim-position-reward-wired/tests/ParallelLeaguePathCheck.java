package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;

public final class ParallelLeaguePathCheck {
    public static void main(String[] args) throws Exception {
        Path root = Files.createTempDirectory("rlpvp-league-path-");
        Path resume = root.resolve("old/state.bin");
        Path resumeSidecar = root.resolve("old/state.bin.league");
        Path sourceSnapshots = resumeSidecar.resolve("snapshots");
        Files.createDirectories(sourceSnapshots);
        Files.writeString(resumeSidecar.resolve("ratings.csv"),
            "id,rating,games,wins,losses,draws\n\"current\",7905.746,9811,4472,2188,3151\n");
        for (int i = 1; i <= 12; i++) Files.writeString(sourceSnapshots.resolve("snapshot-" + i + ".bin"), "snapshot-" + i);

        Path out = root.resolve("new/intelligence.bin");
        Path configured = ParallelPvpTrain.configureLeagueStorage(out, resume);
        Path outputSidecar = root.resolve("new/intelligence.bin.league");
        check(configured.equals(outputSidecar.resolve("ratings.csv")), "parallel trainer did not choose output checkpoint sidecar");
        check(System.getProperty("sim.league.dir").equals(outputSidecar.toString()), "sim.league.dir was not configured");
        check(Files.readString(configured).contains("7905.746,9811"), "resume league ratings were not carried forward");
        try (var paths = Files.list(outputSidecar.resolve("snapshots"))) {
            var names = paths.map(p -> p.getFileName().toString()).sorted().toList();
            check(names.size() == Config.LEAGUE_POOL, "did not seed exactly the configured number of latest snapshots: " + names);
            check(names.contains("snapshot-5.bin") && names.contains("snapshot-12.bin")
                    && !names.contains("snapshot-1.bin") && !names.contains("snapshot-4.bin"),
                "seeded snapshots are not the newest entries: " + names);
        }
        System.clearProperty("sim.league.dir");
        System.clearProperty("sim.league.file");
        System.out.println("ParallelLeaguePathCheck OK");
    }
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
}
