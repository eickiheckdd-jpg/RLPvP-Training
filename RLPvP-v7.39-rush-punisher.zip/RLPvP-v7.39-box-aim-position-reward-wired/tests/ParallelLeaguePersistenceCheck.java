package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;

public final class ParallelLeaguePersistenceCheck {
    public static void main(String[] args) throws Exception {
        Path root = Files.createTempDirectory("rlpvp-parallel-league-");
        Path leagueDir = root.resolve("league");
        Path ratings = leagueDir.resolve("ratings.csv");
        System.setProperty("sim.league.dir", leagueDir.toString());
        System.setProperty("sim.league.file", ratings.toString());

        OpponentLeague shared = new OpponentLeague();
        shared.ensure("current");
        PpoAgent a = new PpoAgent(101), b = new PpoAgent(102);
        a.totalTicks = b.totalTicks = 5_000_000L;
        a.stage = b.stage = 8;
        a.stageEnterTicks = b.stageEnterTicks = 4_000_000L;
        PvpSim owner = new PvpSim(1, a, shared, true);
        PvpSim follower = new PvpSim(2, b, shared, false);
        Curriculum curriculum = new Curriculum();
        curriculum.restore(8, 4_000_000L);
        owner.cur = curriculum;
        follower.cur = curriculum;

        CountDownLatch start = new CountDownLatch(1);
        Thread first = new Thread(() -> sync(owner, start));
        Thread second = new Thread(() -> sync(follower, start));
        first.start(); second.start(); start.countDown();
        first.join(); second.join();

        Path snapshot = leagueDir.resolve("snapshots/snapshot-5000000.bin");
        check(Files.isRegularFile(snapshot), "owner did not persist the snapshot");
        PpoAgent loaded = PpoAgent.load(snapshot, 7);
        check(loaded.totalTicks == 5_000_000L, "saved snapshot has the wrong tick count");
        check(Files.isRegularFile(ratings), "owner did not persist the ratings ledger");
        String csv = Files.readString(ratings);
        check(csv.contains("snapshot:5000000"), "ratings ledger is missing the frozen snapshot row");
        try (var files = Files.walk(leagueDir)) {
            check(files.noneMatch(p -> p.getFileName().toString().endsWith(".tmp")), "temporary league files were left behind");
        }
        shared.result("current", "script:0", 1.0);
        shared.result("current", "script:1", 0.0);
        check(shared.games("current") == 2, "shared league did not retain results from both environments");
        System.out.println("ParallelLeaguePersistenceCheck OK");
    }

    private static void sync(PvpSim sim, CountDownLatch start) {
        try { start.await(); sim.syncCurriculum(); }
        catch (Exception ex) { throw new AssertionError(ex); }
    }
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
}
