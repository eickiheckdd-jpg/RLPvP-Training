package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;

/** Usage: CheckpointCompatCheck <existing state.bin>. Loads it, saves a v6 COPY elsewhere, reloads, proves actor/critic/ticks survive and the original is untouched. */
public final class CheckpointCompatCheck {
    static String sha(Path p) throws Exception { return java.util.HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(p))); }
    public static void main(String[] a) throws Exception {
        Path orig = Path.of(a[0]), copy = Files.createTempFile("rlpvp-compat", ".bin");
        String before = sha(orig);
        PpoAgent x = PpoAgent.load(orig, 1);
        x.save(copy);
        PpoAgent y = PpoAgent.load(copy, 1);
        if (!java.util.Arrays.equals(x.actor.w, y.actor.w)) throw new AssertionError("actor changed across save/load");
        if (x.totalTicks != y.totalTicks || x.stage != y.stage) throw new AssertionError("ticks/stage changed");
        if (!sha(orig).equals(before)) throw new AssertionError("original checkpoint was modified");
        System.out.println("CheckpointCompatCheck: " + a[0] + " (ticks " + x.totalTicks + ", stage " + x.stage + ") loads, re-saves as v6, reloads with identical actor; original unchanged");
    }
}
