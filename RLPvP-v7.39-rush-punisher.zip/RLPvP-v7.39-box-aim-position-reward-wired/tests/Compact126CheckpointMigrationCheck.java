package com.rlpvp;

import java.io.DataOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Random;

/** Ensures an original 126-input compact checkpoint retains its policy when widened to 128 inputs. */
public final class Compact126CheckpointMigrationCheck {
    private static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }

    public static void main(String[] args) throws Exception {
        check("target runtime is 128-input compact mode", Config.COMPACT_126 && Config.OBS_SIZE == 128);
        int[] actorShape = new int[Config.HIDDEN.length + 2];
        int[] criticShape = new int[Config.HIDDEN.length + 2];
        actorShape[0] = criticShape[0] = 126;
        System.arraycopy(Config.HIDDEN, 0, actorShape, 1, Config.HIDDEN.length);
        System.arraycopy(Config.HIDDEN, 0, criticShape, 1, Config.HIDDEN.length);
        actorShape[actorShape.length - 1] = Config.ACTION_SIZE;
        criticShape[criticShape.length - 1] = 1;

        Net oldActor = new Net(actorShape, 0.01f, new Random(11));
        Net oldCritic = new Net(criticShape, 1.0f, new Random(12));
        // Set distinct known weights for the final old feature and leave the new two columns absent.
        oldActor.w[125] = 0.375f;
        Path checkpoint = Files.createTempFile("rlpvp-compact126-", ".bin");
        try {
            try (DataOutputStream out = new DataOutputStream(Files.newOutputStream(checkpoint))) {
                out.writeInt(0x524C5050); // RLPP
                out.writeInt(4);          // old checkpoint format: weights, no optional trailers
                out.writeInt(oldActor.w.length);
                out.writeInt(oldCritic.w.length);
                out.writeLong(12345L);
                out.writeInt(7);
                out.writeInt(5);
                out.writeLong(10000L);
                oldActor.write(out);
                oldCritic.write(out);
            }
            PpoAgent loaded = PpoAgent.load(checkpoint, 99L);
            check("legacy final input column is preserved", Math.abs(loaded.actor.w[125] - 0.375f) < 1e-7f);
            check("new target-box dx/dy columns start at zero", loaded.actor.w[126] == 0f && loaded.actor.w[127] == 0f);
            check("old compact checkpoint ticks and curriculum stage are retained",
                loaded.totalTicks == 12345L && loaded.stage == 5 && loaded.stageEnterTicks == 10000L);
        } finally {
            Files.deleteIfExists(checkpoint);
        }
        if (args.length > 0) {
            PpoAgent realCheckpoint = PpoAgent.load(Path.of(args[0]), 100L);
            check("real prior compact checkpoint migrates through its full current-format trailers",
                realCheckpoint.actor.sizes[0] == 128 && realCheckpoint.totalTicks > 0);
            check("real checkpoint zero-initializes only the two new target-box input columns",
                realCheckpoint.actor.w[126] == 0f && realCheckpoint.actor.w[127] == 0f);
        }
    }
}
