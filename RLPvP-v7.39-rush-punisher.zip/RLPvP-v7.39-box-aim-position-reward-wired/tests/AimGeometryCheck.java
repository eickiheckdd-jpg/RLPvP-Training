package com.rlpvp;

/** Camera-relative bounding-box aim offsets are signed, normalized observations only. */
public final class AimGeometryCheck {
    private static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }

    public static void main(String[] args) {
        float[] narrow = new float[2];
        float[] wide = new float[2];
        // Yaw 0 faces +Z. In Minecraft's coordinate convention, -X is the player's right.
        AimGeometry.normalizedError(0, 0, 0, 0, 0,
            -1.3, -0.7, 0.5, 1.1, 4.7, 5.3, narrow, 0);
        check("target right of crosshair has positive horizontal offset", narrow[0] > 0f);
        check("target above crosshair has negative vertical offset", narrow[1] < 0f);

        AimGeometry.normalizedError(0, 0, 0, 0, 0,
            -1.8, -0.2, 0.5, 1.1, 4.7, 5.3, wide, 0);
        check("same centre offset is smaller relative to a wider target box", Math.abs(wide[0]) < Math.abs(narrow[0]));

        float[] centered = new float[2];
        AimGeometry.normalizedError(0, 0, 0, 0, 0,
            -0.3, 0.3, -0.3, 0.3, 4.7, 5.3, centered, 0);
        check("crosshair at target-box centre has near-zero dx and dy",
            Math.abs(centered[0]) < 1e-5f && Math.abs(centered[1]) < 1e-5f);

        AimGeometry.normalizedError(0, 0, 0, 0, 0,
            1.0, -1.0, 0.5, 1.1, 4.7, 5.3, centered, 0);
        check("invalid bounding box safely returns neutral offsets", centered[0] == 0f && centered[1] == 0f);
    }
}
