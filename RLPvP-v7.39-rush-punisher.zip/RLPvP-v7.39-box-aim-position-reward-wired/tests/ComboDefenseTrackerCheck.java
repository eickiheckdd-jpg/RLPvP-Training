package com.rlpvp;

public final class ComboDefenseTrackerCheck {
    public static void main(String[] args) {
        ComboDefenseTracker t = new ComboDefenseTracker();
        t.tick(true, 0.0, false);
        t.tick(false, 0.10, true);
        t.tick(true, 0.0, false);
        int event = 0;
        for (int i = 0; i < ComboDefenseTracker.GAP_TICKS + 1; i++) event = t.tick(false, 0.10, true);
        check((event & ComboDefenseTracker.CHAIN_COMPLETED) != 0, "two incoming hits should close as a combo");
        check((event & ComboDefenseTracker.STRAFE_ESCAPE) != 0, "sustained lateral movement should label a strafe-assisted escape");
        check(t.completedChains() == 1 && t.strafeEscapes() == 1, "combo counters should increment once");

        t.startEpisode();
        t.tick(true, 0.0, false);
        event = 0;
        for (int i = 0; i < ComboDefenseTracker.GAP_TICKS + 1; i++) event = t.tick(false, 0.5, false);
        check(event == 0, "single hit is not a combo and knockback-only movement is not a strafe escape");
        check(t.completedChains() == 1 && t.strafeEscapes() == 1, "single hits must not alter combo counters");

        t.startEpisode();
        t.tick(true, 0.0, false);
        t.tick(false, 0.12, true);
        t.tick(true, 0.0, false);
        event = 0;
        for (int i = 0; i < ComboDefenseTracker.GAP_TICKS + 1; i++) event = t.tick(false, 0.0, false);
        check((event & ComboDefenseTracker.CHAIN_COMPLETED) != 0, "incoming combo should be counted");
        check((event & ComboDefenseTracker.STRAFE_ESCAPE) == 0, "little/no lateral travel must not be labelled an escape");
        System.out.println("ComboDefenseTrackerCheck PASS");
    }
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
}
