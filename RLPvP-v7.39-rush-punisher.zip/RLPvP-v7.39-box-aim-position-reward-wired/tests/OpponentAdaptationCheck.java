package com.rlpvp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Arrays;

/** Focused tests for persistent, policy-facing per-opponent habit memory and save migration. */
public final class OpponentAdaptationCheck {
    private OpponentAdaptationCheck() {}

    public static void main(String[] args) throws Exception {
        SituationalStateInterpreter interpreter = new SituationalStateInterpreter();
        OpponentBehaviorModel model = new OpponentBehaviorModel();
        model.beginEpisode("Alice");

        float[] obs = new float[Config.OBS_SIZE];
        obs[0] = obs[15] = 1f;
        obs[12] = 0.5f; // three blocks
        obs[9] = 0.8f; obs[10] = 0f;
        obs[16] = -0.4f; obs[17] = 0f; // enemy radial motion is toward us
        SituationalStateInterpreter.State radial = interpreter.interpret(obs, 0f, 0f, 0f, false);
        model.observe(obs, radial);
        if (model.profile().approachPressure <= 0.1)
            throw new AssertionError("opponent radial approach was not recorded as positive pressure");

        OpponentMemory episodeMemory = new OpponentMemory();
        float[] radialFrame = new float[Config.FRAME];
        radialFrame[9] = 0.8f; radialFrame[10] = 0f;
        radialFrame[16] = -0.4f; radialFrame[17] = 0f;
        episodeMemory.tick(radialFrame, false, false);
        float[] summary = new float[Config.SUMMARY];
        episodeMemory.fillSummary(summary);
        int habitOffset = Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0)
            + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0);
        float localApproach = summary[habitOffset + 6];
        if (Math.abs(localApproach - OpponentMemory.encodeHabit(6, 0.4)) > 0.02f)
            throw new AssertionError("episode-local opponent memory did not use radial approach pressure: " + localApproach);

        for (int t = 0; t < 80; t++) {
            obs[17] = (t & 1) == 0 ? 0.35f : -0.35f;
            obs[22] = (t % 3 == 0) ? 1f : 0f;
            obs[19] = (t % 4 == 0) ? 0f : 1f; // airborne share
            obs[23] = (t % 8 == 0) ? 1f : 0f; // swing-start rate
            obs[12] = 0.5f;
            SituationalStateInterpreter.State state = interpreter.interpret(obs, 0f, 0f, 0f, false);
            model.observe(obs, state);
        }

        OpponentBehaviorModel.Profile p = model.profile();
        if (p.habitSamples < 80 || p.strafeActivity < 0.9 || p.strafeFlipRate < 0.8
                || p.sprintShare < 0.2 || p.sprintShare > 0.5 || p.airborneRate < 0.15
                || p.airborneRate > 0.4 || p.swingRate < 0.05 || p.preferredDistance < 0.45) {
            throw new AssertionError("unexpected learned opponent profile: " + describe(p));
        }

        float[] policyObs = new float[Config.OBS_SIZE];
        model.applyPolicyHistory(policyObs);
        int offset = OpponentMemory.habitSlotStart();
        double[] raw = {p.strafeActivity, p.strafeFlipRate, p.sprintShare, p.airborneRate,
            p.swingRate, p.preferredDistance, p.approachPressure, p.counterRate};
        for (int i = 0; i < OpponentMemory.HABITS; i++) {
            float expected = OpponentMemory.encodeHabit(i, raw[i]);
            if (Math.abs(policyObs[offset + i] - expected) > 1e-6)
                throw new AssertionError("policy habit slot " + i + " was not filled from opponent profile");
        }

        // OPM2 round trip keeps profiles available to the same named opponent.
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) { model.write(out); }
        OpponentBehaviorModel loaded = new OpponentBehaviorModel();
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes.toByteArray()))) { loaded.read(in); }
        loaded.beginEpisode("Alice");
        if (loaded.profile().habitSamples != p.habitSamples
                || Math.abs(loaded.profile().strafeFlipRate - p.strafeFlipRate) > 1e-9)
            throw new AssertionError("OPM2 opponent profile did not survive serialization");

        // A different name must not inherit Alice's behavior profile.
        loaded.beginEpisode("ALICE"); // scoreboard casing changes must resolve to the same identity key
        if (loaded.profile().habitSamples != p.habitSamples)
            throw new AssertionError("opponent profile key was not normalized case-insensitively");
        loaded.beginEpisode("Bob");
        if (loaded.profile().habitSamples != 0 || loaded.profile().strafeActivity != 0)
            throw new AssertionError("opponent profile leaked across names");

        // OPM1 legacy data is migrated, but old approximate fields must not be injected into
        // the actor until a sufficiently long fresh sample window has rebuilt the new definitions.
        ByteArrayOutputStream legacyBytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(legacyBytes)) {
            out.writeInt(0x4F504D31); // OPM1
            out.writeInt(1);
            out.writeUTF("LegacyOpponent");
            out.writeDouble(0.3); out.writeDouble(0.4); out.writeDouble(0.2);
            out.writeDouble(0.6); out.writeDouble(-0.2); out.writeDouble(0.7);
            out.writeLong(120);
        }
        OpponentBehaviorModel migrated = new OpponentBehaviorModel();
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(legacyBytes.toByteArray()))) { migrated.read(in); }
        migrated.beginEpisode("LegacyOpponent");
        if (migrated.profile().samples != 120 || migrated.profile().hasPolicyHistory())
            throw new AssertionError("legacy OPM1 profile migration is not conservative");
        float[] untouched = new float[Config.OBS_SIZE];
        Arrays.fill(untouched, 0.25f);
        migrated.applyPolicyHistory(untouched);
        if (untouched[offset] != 0.25f)
            throw new AssertionError("legacy profile overwrote policy history before fresh samples");
        for (int i = 0; i < 79; i++) migrated.observe(obs, interpreter.interpret(obs, 0f, 0f, 0f, false));
        if (migrated.profile().hasPolicyHistory())
            throw new AssertionError("legacy profile overlaid actor inputs before its confidence window");
        migrated.observe(obs, interpreter.interpret(obs, 0f, 0f, 0f, false));
        if (!migrated.profile().hasPolicyHistory())
            throw new AssertionError("legacy profile did not warm up after 80 fresh observations");

        // The bounded profile table behaves as an LRU cache: returning to Alice makes her
        // recent, so the next new opponent evicts the oldest other profile instead.
        OpponentBehaviorModel lru = new OpponentBehaviorModel();
        SituationalStateInterpreter.State neutralState = interpreter.interpret(obs, 0f, 0f, 0f, false);
        for (int n = 0; n < 16; n++) {
            lru.beginEpisode("player" + n);
            for (int t = 0; t < 80; t++) lru.observe(obs, neutralState);
        }
        lru.beginEpisode("player0"); // touch the oldest profile
        if (lru.profile().habitSamples != 80)
            throw new AssertionError("LRU cache failed to restore the touched opponent profile");
        lru.beginEpisode("player16");
        lru.beginEpisode("player17"); // persisting player16 creates the 17th profile and evicts player1
        lru.beginEpisode("player0");
        if (lru.profile().habitSamples != 80)
            throw new AssertionError("LRU eviction removed a recently used opponent profile");
        lru.beginEpisode("player1");
        if (lru.profile().habitSamples != 0)
            throw new AssertionError("LRU eviction did not remove the least-recently-used profile");

        System.out.println("PASS persistent opponent adaptation, radial pressure, policy input overlay, OPM2 round-trip, OPM1 migration and LRU isolation: " + describe(p));
    }

    private static String describe(OpponentBehaviorModel.Profile p) {
        return String.format(java.util.Locale.ROOT,
            "samples=%d strafe=%.2f flips=%.2f sprint=%.2f air=%.2f swing=%.2f distance=%.2f approach=%.2f",
            p.habitSamples, p.strafeActivity, p.strafeFlipRate, p.sprintShare, p.airborneRate,
            p.swingRate, p.preferredDistance, p.approachPressure);
    }
}
