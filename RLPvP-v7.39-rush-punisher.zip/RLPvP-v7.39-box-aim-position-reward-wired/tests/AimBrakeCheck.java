package com.rlpvp;

/** Closed-loop checks of AimBrake on the real CameraDynamics, with a deliberately bad "bang-bang" policy. Pure Java. */
public final class AimBrakeCheck {
    static void check(String name, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + name); if (!ok) throw new AssertionError(name); }

    /** Chaser: pol 0 = bang-bang (full effort toward the target every tick, the worst case), 1 = proportional. Returns {max overshoot deg, tick it settled (within 2 deg and slow), reversals}. */
    static double[] chase(boolean brake, int pol, double startErr) {
        CameraDynamics d = new CameraDynamics();
        double angle = 0, target = startErr, maxOver = 0, lastV = 0;
        int settle = -1, reversals = 0; double ss = 0;
        for (int t = 0; t < 200; t++) {
            double err = target - angle;
            double cmd = pol == 0 ? Math.signum(err) * Config.YAW_SCALE : Math.max(-Config.YAW_SCALE, Math.min(Config.YAW_SCALE, err * 2.0));
            if (brake) cmd = AimBrake.limit(cmd, d, err, Config.YAW_SCALE);
            angle += d.step(cmd, Config.YAW_SCALE);
            maxOver = Math.max(maxOver, angle - target);
            if (d.vel() * lastV < 0 && Math.abs(lastV) > 1 && Math.abs(err) > 2.0) reversals++; // real swings across the target; sub-2-degree micro hunting is bounded separately by the steady-state check
            lastV = d.vel();
            if (t >= 100) ss = Math.max(ss, Math.abs(target - angle)); // steady-state hunting amplitude
            if (settle < 0 && Math.abs(target - angle) < 2 && Math.abs(d.vel()) < 2) settle = t;
        }
        return new double[]{maxOver, settle, reversals, ss};
    }

    public static void main(String[] x) {
        for (double start : new double[]{5, 20, 90, 170}) {
            double[] rawB = chase(false, 0, start), brB = chase(true, 0, start), rawP = chase(false, 1, start), brP = chase(true, 1, start);
            check(String.format("start %3.0f deg, bang-bang: brake overshoots %.1f deg vs %.1f raw, and stays under 8", start, brB[0], rawB[0]), brB[0] < rawB[0] && brB[0] <= 8);
            check(String.format("start %3.0f deg, proportional: overshoot %.1f deg (raw %.1f), settles at tick %.0f, no swinging (%.0f reversals), steady-state error <= %.2f deg", start, brP[0], rawP[0], brP[1], brP[2], brP[3]), brP[0] <= 8 && brP[1] >= 0 && brP[1] < 40 && brP[2] <= 6 && brP[3] <= 1.5);
        }
        CameraDynamics rest = new CameraDynamics();
        check("far target: a push toward it is untouched", AimBrake.limit(10, rest, 120, Config.YAW_SCALE) == 10);
        check("pushing away from the target at rest: never limited", AimBrake.limit(-8, rest, 30, Config.YAW_SCALE) == -8);
        CameraDynamics fast = new CameraDynamics(); for (int i = 0; i < 12; i++) fast.step(45, 45);
        check("moving away from the target: never limited", AimBrake.limit(-20, fast, -30, Config.YAW_SCALE) == -20);
        check("too fast for the angle left: command becomes braking (opposite sign)", AimBrake.limit(20, fast, 3, Config.YAW_SCALE) < 0);
        check("zero-error crossing actively brakes residual positive motion", AimBrake.limit(0, fast, 0, Config.YAW_SCALE) < 0);
        CameraDynamics drift = new CameraDynamics(); for (int i = 0; i < 5; i++) drift.step(2, Config.YAW_SCALE);
        double da = 0; for (int i = 0; i < 80; i++) da += drift.step(AimBrake.limit(0, drift, 0, Config.YAW_SCALE), Config.YAW_SCALE);
        check(String.format("near-zero residual drift is arrested (travel %.2f deg, final speed %.2f)", da, drift.vel()), Math.abs(da) < 8.0 && Math.abs(drift.vel()) < 1.0);
        check("output is finite and within +-scale for extreme input", Math.abs(AimBrake.limit(1e9, fast, 1e-9, Config.YAW_SCALE)) <= Config.YAW_SCALE && AimBrake.limit(Double.NaN, fast, 5, 45) == 0.0);
        // a following target must still be trackable: a slowly drifting target keeps within a few degrees
        CameraDynamics d = new CameraDynamics(); double ang = 0, tgt = 0, worst = 0;
        for (int t = 0; t < 200; t++) { tgt += 2.0; double err = tgt - ang; double cmd = AimBrake.limit(Math.signum(err) * 0.4 * Config.YAW_SCALE, d, err, Config.YAW_SCALE); ang += d.step(cmd, Config.YAW_SCALE); if (t > 60) worst = Math.max(worst, Math.abs(tgt - ang)); }
        check("a target moving 2 deg/tick can still be followed (worst error " + String.format("%.1f", worst) + " deg)", worst < 12);
        System.out.println("AimBrakeCheck: all ok");
    }
}
