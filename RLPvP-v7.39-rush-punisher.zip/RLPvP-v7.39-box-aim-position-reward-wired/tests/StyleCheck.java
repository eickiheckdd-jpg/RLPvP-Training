package com.rlpvp;

/** Technique-exchange diagnostics remain available, while hit-style identity bonuses are disabled by default. */
public final class StyleCheck {
    static void check(String name, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + name); if (!ok) throw new AssertionError(name); }

    static TechniqueDiscovery.In base() {
        TechniqueDiscovery.In s = new TechniqueDiscovery.In();
        s.techW = 1.0; s.techTicks = 0; s.dist = 3.0; s.enemyFacing = 1.0; s.inTheirReach = true;
        return s;
    }

    /** hit at hitAt from distance hitDist; optional damage taken at tookAt; optional enemy swing started at baitAt from a spot outside its reach (dist 3.6). */
    static String run(int hitAt, double hitDist, int tookAt, int baitAt) {
        TechniqueDiscovery d = new TechniqueDiscovery(); TechniqueDiscovery.In s = base();
        for (int t = 0; t < 70; t++) {
            s.tick = t; s.realDealt = 0; s.taken = 0; s.newHit = false; s.oppSwingStart = false; s.hitDist = hitDist; s.hitGrounded = true;
            s.inTheirReach = true; s.dist = 3.0;
            if (t == baitAt) { s.oppSwingStart = true; s.inTheirReach = false; s.dist = 3.6; }
            if (t == hitAt) { s.realDealt = 6f; s.newHit = true; }
            if (t == tookAt) s.taken = 3f;
            d.tick(s);
        }
        d.endEpisode();
        return d.summary();
    }

    public static void main(String[] x) {
        String sp = run(10, 2.8, -1, -1);
        check("a clean hit from the edge of my reach is a counted spacing exchange: " + sp, sp.contains("spacing=1/1/0"));
        String sp2 = run(10, 2.8, 14, -1);
        check("the same hit followed by taking damage pays no spacing: " + sp2, sp2.contains("spacing=1/0/1"));
        String close = run(10, 1.5, -1, -1);
        check("a point-blank hit is not spacing: " + close, close.contains("spacing=0/0/0"));
        String bait = run(20, 1.5, -1, 12);
        check("a hit right after the enemy overcommitted at the edge is a bait counter: " + bait, bait.contains("bait=1/1/0"));
        String late = run(50, 1.5, -1, 12);
        check("a hit long after the enemy's swing is not: " + late, late.contains("bait=0/0/0"));
        String trade = run(20, 1.5, 22, 12);
        check("a bait counter that gets hit back pays no bait: " + trade, trade.contains("bait=1/0/1"));

        TechniqueDiscovery d = new TechniqueDiscovery(); TechniqueDiscovery.In s = base();
        for (int k = 0; k < 120; k++) {
            s.tick = k * 25; s.realDealt = 6f; s.taken = 0; s.newHit = true; s.hitSprint = true; s.hitGrounded = true; s.hitDist = 1.5; s.oppSwingStart = false;
            d.tick(s);
            s.newHit = false; s.tick++; s.realDealt = 0; d.tick(s);
        }
        double f = d.dominance(TechniqueDiscovery.SPRINT_HIT);
        check("legacy dominance diagnostic detects sprint-hit monoculture: factor " + f, f < 0.6 && f >= Config.TECH_DOMINANCE_MIN - 1e-9);
        check("legacy dominance diagnostic leaves other styles at neutral", d.dominance(TechniqueDiscovery.CRIT) == 1.0 && d.dominance(TechniqueDiscovery.JUMP_RESET) == 1.0 && d.dominance(TechniqueDiscovery.BAIT) == 1.0);
        TechniqueDiscovery c = new TechniqueDiscovery(); TechniqueDiscovery.In q = base();
        check("no crit dominance: crit damage paid in full", c.rewardDamage(6f, true, 0f) == 6f);
        for (int k = 0; k < 150; k++) {
            q.tick = k * 25; q.realDealt = 6f; q.taken = 0; q.newHit = true; q.hitCrit = true; q.hitSprint = false; q.hitGrounded = true; q.hitDist = 1.5; q.oppSwingStart = false;
            c.tick(q);
            q.newHit = false; q.tick++; q.realDealt = 0; c.tick(q);
        }
        float rd = c.rewardDamage(6f, true, 0f);
        check("crit monoculture never discounts real HP damage (" + rd + ")", rd == 6f);
        check("sprint hits are not discounted", c.rewardDamage(6f, false, 0f) == 6f);
        System.out.println("StyleCheck passed");
    }
}
