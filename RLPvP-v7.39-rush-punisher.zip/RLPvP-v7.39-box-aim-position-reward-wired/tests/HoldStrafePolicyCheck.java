package com.rlpvp;

public final class HoldStrafePolicyCheck {
    public static void main(String[] args) {
        check(PpoAgent.N_ACT == 9 && Config.ACTION_SIZE == 15, "policy/action dimensions must include hold-strafe");
        PpoAgent agent = new PpoAgent(17);
        float[] z = new float[Config.ACTION_SIZE];
        float[] a = new float[PpoAgent.N_ACT];
        float[] grad = new float[Config.ACTION_SIZE];
        a[3] = 1f; // neutral strafe category makes the conditional branch eligible
        a[8] = 1f;
        agent.evalPolicy(z, a, 0, 0f, 1f, grad);
        check(Math.abs(grad[Config.OFF_HOLD_STRAFE]) > 1e-7, "hold branch should receive PPO gradient when eligible");

        java.util.Arrays.fill(grad, 0f);
        a[3] = 2f; // explicit right action: hold branch is irrelevant
        agent.evalPolicy(z, a, 0, 0f, 1f, grad);
        check(grad[Config.OFF_HOLD_STRAFE] == 0f, "hold branch must have no gradient when strafe is explicitly selected");

        java.util.Arrays.fill(grad, 0f);
        a[3] = 1f;
        a[8] = 0f;
        ActionMask.apply(z, ActionMask.LOCK_STRAFE);
        agent.evalPolicy(z, a, ActionMask.LOCK_STRAFE, 0f, 1f, grad);
        check(grad[Config.OFF_HOLD_STRAFE] == 0f, "locked strafe must disable the continuation branch");
        System.out.println("HoldStrafePolicyCheck PASS");
    }
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
}
