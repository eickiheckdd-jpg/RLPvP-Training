package com.rlpvp;

/** High-value fixtures for the requested Java 26.3 diamond-sword/full-diamond-Protection-III kit. */
public final class DiamondProt3KitTest {
    private static int checks;

    private static void check(String name, boolean ok) {
        checks++;
        if (!ok) throw new AssertionError(name);
    }

    private static void near(String name, double actual, double expected, double eps) {
        check(name + " (actual=" + actual + ", expected=" + expected + ")",
            Double.isFinite(actual) && Math.abs(actual - expected) <= eps);
    }

    public static void main(String[] args) {
        MinecraftRules.Kit kit = MinecraftRules.DIAMOND_PROT3;
        MinecraftRules.EquipmentProfile gear = kit.equipment;
        check("default profile has explicit item data", gear != null);
        check("normal diamond sword item id", "minecraft:diamond_sword".equals(gear.weaponItemId));
        near("player base attack damage + sword modifier", gear.attackDamage(), 7.0, 1e-6);
        near("player base attack speed + sword modifier", gear.attackSpeed(), 1.6, 1e-6);
        near("sword fully-charged delay is 12.5 ticks", kit.attackCooldownTicks(), 12.5, 1e-6);
        near("full diamond armor total", gear.totalArmor(), 20.0, 1e-6);
        near("full diamond toughness total", gear.totalToughness(), 8.0, 1e-6);
        near("Protection III x4 contributes EPF 12 for melee", gear.genericMeleeProtectionEpf(), 12.0, 1e-6);
        check("four armor items in the target profile", gear.armorPieces().length == 4);

        near("full normal sword hit = 7 raw", MinecraftRules.attackDamage(kit, 1.0, false), 7.0, 1e-6);
        near("full sword crit = 10.5 raw", MinecraftRules.attackDamage(kit, 1.0, true), 10.5, 1e-6);
        near("half-charge raw damage = 2.8", MinecraftRules.attackDamage(kit, 0.5, false), 2.8, 1e-6);

        MinecraftRules.DamageBreakdown normal = MinecraftRules.damageBreakdown(kit, 7.0);
        near("7 raw -> 1.89 after diamond armor", normal.afterArmor, 1.89, 1e-6);
        near("armor result then Protection III x4 -> 0.9828 HP", normal.finalDamage, 0.9828, 1e-6);
        near("generic melee Protection EPF", normal.protectionEpf, 12.0, 1e-6);

        MinecraftRules.DamageBreakdown crit = MinecraftRules.damageBreakdown(kit, 10.5);
        near("full crit -> 3.2025 after armor", crit.afterArmor, 3.2025, 1e-6);
        near("full crit -> 1.6653 final HP damage", crit.finalDamage, 1.6653, 1e-6);

        MinecraftRules.DamageBreakdown partial = MinecraftRules.damageBreakdown(kit, 2.8);
        near("half-charge -> 0.6384 after armor", partial.afterArmor, 0.6384, 1e-6);
        near("half-charge -> 0.331968 final HP damage", partial.finalDamage, 0.331968, 1e-6);
        check("21 non-critical fully charged hits mathematically exceed 20 HP", MinecraftRules.hitsToKill(kit, kit) == 21);

        // Exercise the integrated PvpSim strike path, including the pre-armor hurt-cooldown comparison.
        PvpSim sim = new PvpSim(31L, new PpoAgent(31L));
        PvpSim.E attacker = new PvpSim.E();
        PvpSim.E defender = new PvpSim.E();
        attacker.kit = kit;
        defender.kit = kit;
        attacker.x = 0.0;
        defender.x = 1.0;
        int result = sim.strike(attacker, defender, 1.0, false, false);
        check("integrated full hit accepted", result == 2);
        near("integrated full hit applies exact target-kit HP damage", 20.0 - defender.hp, 0.9828, 1e-6);

        defender.hp = 20.0f;
        defender.invul = 20;
        defender.lastHurt = 7.0;
        result = sim.strike(attacker, defender, 0.5, false, false);
        check("weaker raw hit is rejected during cooldown", result == 0);
        near("weaker cooldown hit applies no damage", defender.hp, 20.0, 1e-6);

        result = sim.strike(attacker, defender, 1.0, true, false);
        check("stronger critical hit only applies excess raw damage during cooldown", result == 1);
        near("cooldown excess is defended as 3.5 raw damage", 20.0 - defender.hp,
            MinecraftRules.afterDefense(kit, 10.5 - 7.0), 1e-6);
        check("cooldown excess does not start a fresh hurt window", defender.invul > 10);

        System.out.println("DiamondProt3KitTest: " + checks + " passed");
        System.out.println("\n" + kit.profileDescription());
        System.out.printf(java.util.Locale.ROOT,
            "Reference damage: normal full hit %.6f HP; full critical %.6f HP; half-charge %.6f HP%n",
            normal.finalDamage, crit.finalDamage, partial.finalDamage);
    }
}
