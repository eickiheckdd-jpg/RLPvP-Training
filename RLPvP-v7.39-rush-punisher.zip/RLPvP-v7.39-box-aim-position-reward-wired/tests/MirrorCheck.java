package com.rlpvp;

import java.util.Locale;

/** The hand-written aim bot must do equally well in mirrored and normal worlds (proves the mirror transform is consistent). */
public final class MirrorCheck {
    public static void main(String[] a) {
        for (boolean mir : new boolean[]{false, true}) {
            PvpSim sim = new PvpSim(5, new PpoAgent(1));
            sim.mirrorOn = mir;
            sim.hand = fr -> PvpProbe.aimbot(fr, false, true);   // strafes with the keys it sends
            PvpSim.EvalStats ev = sim.evaluate(Curriculum.Opponent.WALK, 60);
            System.out.printf(Locale.ROOT, "mirrorOn=%-5b win %3.0f%% hits/ep %.1f whiff %3.0f%%%n", mir, 100.0 * ev.wins / ev.eps, ev.hits / (double) ev.eps, 100.0 * ev.whiffs / Math.max(1, ev.swings));
        }
    }
}
