package com.rlpvp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.file.Path;
import java.util.Arrays;

/** Expanded 128-input contract, recurrent-state serialization, PPO clipping, and old-checkpoint transfer. */
public final class CompactObservation126Check {
    private static void check(String name, boolean ok) {
        System.out.println((ok ? "ok   " : "FAIL ") + name);
        if (!ok) throw new AssertionError(name);
    }
    private static boolean near(float a, float b) { return Math.abs(a - b) < 1e-5f; }

    public static void main(String[] args) throws Exception {
        check("compact mode enabled", Config.COMPACT_126);
        check("exact 128 observation dimensions", Config.OBS_SIZE == 128 && ObsStack.COMPACT_SIZE == 128);
        check("GRU dimensions are H=64, X=18", GruCell.H == 64 && GruCell.X == 18);
        check("BPTT window is recurrent", Config.GRU_BPTT >= 16);

        float[] frame = new float[Config.FRAME];
        for (int i = 0; i < frame.length; i++) frame[i] = (i - 20) / 100f;
        float[] summary = new float[Config.SUMMARY];
        summary[1] = 1f; summary[2] = 1f;
        summary[8] = 0.75f; summary[9] = 0.25f;
        int mem = Config.SUMMARY_BASE + Config.V2_FEATURES + Config.SPRINT_FOLLOWUP_FEATURES;
        for (int i = 0; i < OpponentMemory.HABITS; i++) summary[mem + i] = (i + 1) / 20f;
        for (int i = 0; i < GruCell.H; i++) summary[mem + OpponentMemory.HABITS + i] = (i + 1) / 100f;
        int combat = Config.SUMMARY_BASE + Config.V2_FEATURES + Config.SPRINT_FOLLOWUP_FEATURES
            + Config.MEMORY_FEATURES + Config.KB_FEATURES;
        summary[combat + CombatObservationMemory.REACH_MARGIN] = -0.375f;
        summary[combat + CombatObservationMemory.CROSSHAIR_BOX_DX] = 0.25f;
        summary[combat + CombatObservationMemory.CROSSHAIR_BOX_DY] = -0.5f;

        ObsStack stack = new ObsStack();
        float[] obs = stack.push(frame, summary);
        float[] reusable = stack.pushReusable(frame, summary);
        check("reusable compact observation exactly matches fresh output", Arrays.equals(obs, reusable));
        frame[0] += 0.125f; summary[8] = -0.25f; summary[9] = 0.5f;
        float[] secondFresh = stack.push(frame, summary);
        float[] secondReusable = stack.pushReusable(frame, summary);
        check("reusable compact observation clears stale slots between calls", Arrays.equals(secondFresh, secondReusable));
        frame[0] -= 0.125f; summary[8] = 0.75f; summary[9] = 0.25f;
        check("current frame occupies 0..50", Arrays.equals(Arrays.copyOf(obs, Config.FRAME), frame));
        check("all 64 GRU channels occupy 51..114", near(obs[ObsStack.GRU_START], 0.01f)
            && near(obs[ObsStack.GRU_START + 63], 0.64f));
        check("8 opponent habits occupy 115..122", near(obs[115], 0.05f) && near(obs[122], 0.4f));
        check("damage differential feature", near(obs[ObsStack.DAMAGE_DIFF_SLOT], 0.5f));
        check("packed hit type round-trips", ObsStack.decodeHitMask(obs[ObsStack.HIT_TYPE_SLOT]) == (HitMemory.CRIT | HitMemory.SPRINT));
        check("reach margin feature", near(obs[ObsStack.REACH_MARGIN_SLOT], -0.375f));
        check("normalized target-box dx/dy occupy the appended compact slots",
            near(obs[ObsStack.BOX_DX_SLOT], 0.25f) && near(obs[ObsStack.BOX_DY_SLOT], -0.5f));

        float[] mirrored = new float[Config.OBS_SIZE];
        Symmetry.obs(obs, mirrored);
        boolean symmetry = true;
        for (int i = 0; i < Config.OBS_SIZE; i++) {
            boolean lateral = false;
            for (int p : Symmetry.LATERAL) lateral |= p == i;
            lateral |= i == ObsStack.BOX_DX_SLOT;
            symmetry &= near(mirrored[i], lateral ? -obs[i] : obs[i]);
        }
        check("mirror transform flips only lateral current-frame features", symmetry);

        // Trainable GRU serialization keeps weights AND Adam moments/step continuous.
        GruCell a = new GruCell();
        a.gradForTest()[0] = 0.25f;
        a.step(Config.LR_GRU, Config.GRU_MAX_NORM, 1);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) { a.writeTrainingState(out); }
        GruCell b = new GruCell();
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes.toByteArray()))) { b.readTrainingState(in); }
        check("GRU2 saves weights and Adam step", near(a.w[0], b.w[0]) && a.adamStepForTest() == 1 && b.adamStepForTest() == 1);
        a.gradForTest()[0] = 0.1f; b.gradForTest()[0] = 0.1f;
        a.step(Config.LR_GRU, Config.GRU_MAX_NORM, 1); b.step(Config.LR_GRU, Config.GRU_MAX_NORM, 1);
        check("GRU Adam state resumes deterministically", near(a.w[0], b.w[0]));

        float rawLoss = PpoAgent.huberLoss(1f - 0.9f, 1f);
        float clippedLoss = PpoAgent.clippedValueLoss(1f, 0f, 0.9f, 0.2f, 1f);
        check("PPO clipped value objective keeps the larger clipped loss", clippedLoss > rawLoss);
        check("clipped value gradient is zero outside the clip boundary when clipped loss dominates",
            near(PpoAgent.clippedValueGradient(1f, 0f, 0.9f, 0.2f, 1f), 0f));

        if (args.length > 0) {
            PpoAgent loaded = PpoAgent.load(Path.of(args[0]), 9L);
            check("v7.37 lag-stack checkpoint migrates into compact 128 policy", loaded.actor.sizes[0] == 128);
            check("current-frame input columns are retained", near(loaded.actor.w[0], 0.125f) && near(loaded.actor.w[1], -0.25f));
            check("stable opponent-habit inputs map to 115..122", near(loaded.actor.w[115], 0.75f) && near(loaded.actor.w[122], -0.5f));
            check("new GRU uses 64 hidden channels after legacy checkpoint load", GruCell.H == 64 && loaded.gruCell().w.length == GruCell.N);
        }
        System.out.println("CompactObservation126Check: all ok");
    }
}
