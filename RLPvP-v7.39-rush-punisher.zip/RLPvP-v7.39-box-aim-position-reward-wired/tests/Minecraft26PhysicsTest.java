package com.rlpvp;

public final class Minecraft26PhysicsTest {
    private static int checks;
    private static void near(String name, double actual, double expected, double eps) {
        checks++;
        if (!Double.isFinite(actual) || Math.abs(actual - expected) > eps) {
            throw new AssertionError(name + ": expected " + expected + ", got " + actual);
        }
    }
    private static void ok(String name, boolean value) {
        checks++;
        if (!value) throw new AssertionError(name);
    }
    public static void main(String[] args) {
        near("vanilla default modified friction", Minecraft26Physics.modifiedFriction(0.91, 1.0), 0.91, 1e-6);
        near("friction modifier zero removes drag", Minecraft26Physics.modifiedFriction(0.91, 0.0), 1.0, 1e-6);
        near("friction modifier two", Minecraft26Physics.modifiedFriction(0.91, 2.0), 0.82, 1e-6);
        near("normal block ground speed unchanged", Minecraft26Physics.frictionInfluencedSpeed(0.1, 0.6, true), 0.1, 1e-6);
        near("air speed not ground-friction adjusted", Minecraft26Physics.frictionInfluencedSpeed(0.02, 0.98, false), 0.02, 1e-6);
        near("ice ground speed adjustment", Minecraft26Physics.frictionInfluencedSpeed(0.1, 0.98, true), 0.21600002 / (0.98 * 0.98 * 0.98) * 0.1, 1e-6);
        near("ground horizontal drag", Minecraft26Physics.horizontalDrag(true, 0.6, 1.0), 0.546, 1e-6);
        near("air horizontal drag", Minecraft26Physics.horizontalDrag(false, 0.6, 1.0), 0.91, 1e-6);
        near("vertical drag", Minecraft26Physics.verticalDrag(1.0), 0.98, 1e-6);
        near("jump preserves stronger existing vertical velocity", Minecraft26Physics.jumpVelocity(0.6, 0.42), 0.6, 1e-6);
        near("jump raises weaker vertical velocity to jump power", Minecraft26Physics.jumpVelocity(0.1, 0.42), 0.42, 1e-6);
        near("sword cooldown from 1.6 attack speed", Minecraft26Physics.attackCooldownTicks(1.6), 12.5, 1e-6);
        near("default fist cooldown from 4 attack speed", Minecraft26Physics.attackCooldownTicks(4.0), 5.0, 1e-6);
        ok("zero attack speed is non-finite cooldown", Double.isInfinite(Minecraft26Physics.attackCooldownTicks(0.0)));
        double[] forward = new double[2];
        Minecraft26Physics.inputVector(0, 1, 0.1, 0, forward);
        near("forward at yaw zero x", forward[0], 0, 1e-6);
        near("forward at yaw zero z", forward[1], 0.1, 1e-6);
        double[] right = new double[2];
        Minecraft26Physics.inputVector(0, 1, 0.1, 90, right);
        near("forward at yaw 90 rotates to negative x", right[0], -0.1, 1e-6);
        float yaw90 = (float)(Math.PI / 2.0);
        near("Mth sine lookup at 90 degrees", Minecraft263Trig.sin(yaw90), 1.0, 1e-6);
        near("Mth cosine lookup at 90 degrees", Minecraft263Trig.cos(yaw90), 0.0, 1e-6);
        near("Mth trig lookup at zero degrees", Minecraft263Trig.cos(0.0), 1.0, 1e-6);
        double[] diagonal = new double[2];
        Minecraft26Physics.inputVector(1, 1, 0.1, 0, diagonal);
        near("diagonal input normalized", Math.hypot(diagonal[0], diagonal[1]), 0.1, 1e-6);
        double[] kb = new double[3];
        Minecraft26Physics.applyKnockback(0.2, 0.1, 0.0, 1, 0, 0.4, true, kb);
        near("knockback halves prior x velocity then pushes away", kb[0], -0.3, 1e-6);
        near("grounded knockback vertical cap", kb[1], 0.4, 1e-6);
        double[] airKb = new double[3];
        Minecraft26Physics.applyKnockback(0, 0.2, 0, 1, 0, 0.4, false, airKb);
        near("airborne knockback preserves vertical velocity", airKb[1], 0.2, 1e-6);
        MinecraftRules.Kit negativeResistance = new MinecraftRules.Kit("test-negative-kb", 7, 0, 0, 0, 0, -1, -0.5, 0f, 0);
        near("negative 26.3 knockback resistance increases knockback", MinecraftRules.knockbackStrength(0.4, negativeResistance), 0.6, 1e-6);
        System.out.println("Minecraft26PhysicsTest: " + checks + " passed");
    }
}
