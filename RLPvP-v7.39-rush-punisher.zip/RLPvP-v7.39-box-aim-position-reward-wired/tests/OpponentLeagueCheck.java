package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CountDownLatch;

public final class OpponentLeagueCheck {
    public static void main(String[] args) throws Exception {
        OpponentLeague league = new OpponentLeague();
        league.ensure("agent");
        league.ensure("close").rating = 1200;
        league.ensure("target").rating = 1320; // expected agent win ~33%, outside PFSP band
        league.ensure("too_easy").rating = 900; // expected agent win ~85%, outside PFSP band
        league.ensure("in_band").rating = 1130; // expected agent win ~60%
        for (int i = 0; i < 100; i++) {
            String id = league.sample("agent", List.of("target", "too_easy", "in_band"), new Random(i));
            check("in_band".equals(id), "PFSP did not prefer a 50-70% target opponent: " + id);
        }
        double beforeAgent = league.rating("agent"), beforeOpponent = league.rating("in_band");
        league.result("agent", "in_band", 1.0);
        check(league.rating("agent") > beforeAgent, "winner Elo did not rise");
        check(league.rating("in_band") < beforeOpponent, "loser Elo did not fall");
        check(Math.abs((league.rating("agent") - beforeAgent) + (league.rating("in_band") - beforeOpponent)) < 1e-6, "Elo update is not zero-sum");
        Path temp = Files.createTempFile("rlpvp-league", ".csv");
        league.save(temp);
        OpponentLeague copy = new OpponentLeague(); copy.load(temp);
        check(Math.abs(copy.rating("agent") - league.rating("agent")) < 0.001, "rating did not persist");
        Files.deleteIfExists(temp);

        // Shared league operations must remain lossless when multiple training environments report concurrently.
        OpponentLeague shared = new OpponentLeague();
        shared.ensure("agent"); shared.ensure("oppA"); shared.ensure("oppB");
        CountDownLatch start = new CountDownLatch(1);
        Thread t1 = new Thread(() -> runResults(shared, "oppA", 1.0, 1000, start));
        Thread t2 = new Thread(() -> runResults(shared, "oppB", 0.0, 1000, start));
        t1.start(); t2.start(); start.countDown(); t1.join(); t2.join();
        check(shared.games("agent") == 2000, "parallel league updates were lost");
        check(shared.ensure("agent").wins == 1000 && shared.ensure("agent").losses == 1000,
            "parallel win/loss accounting is incorrect");
        check(shared.snapshotIfAbsent("snapshot:1", "agent"), "first snapshot registration failed");
        double frozenRating = shared.rating("snapshot:1");
        shared.result("agent", "oppA", 1.0);
        check(!shared.snapshotIfAbsent("snapshot:1", "agent"), "duplicate snapshot registration replaced the frozen record");
        check(Math.abs(shared.rating("snapshot:1") - frozenRating) < 1e-9,
            "snapshot league rating changed after the snapshot was frozen");

        Curriculum c = new Curriculum(); c.restore(7, 0); c.update(0);
        c.setLeagueRating(1300, OpponentLeague.PROMOTION_GAMES - 1); c.update(1);
        check(c.autoStage() == 7, "stage 7 promoted before minimum league games");
        c.setLeagueRating(1300, OpponentLeague.PROMOTION_GAMES); c.update(2);
        check(c.autoStage() == 8, "stage 7 did not promote on Elo threshold");
        check(Curriculum.opponentFor(7) == Curriculum.Opponent.SELF_PLAY, "stage 7 is not the league stage");
        System.out.println("OpponentLeagueCheck OK");
    }
    private static void runResults(OpponentLeague league, String opponent, double score, int n, CountDownLatch start) {
        try { start.await(); }
        catch (InterruptedException ex) { Thread.currentThread().interrupt(); throw new AssertionError(ex); }
        for (int i = 0; i < n; i++) league.result("agent", opponent, score);
    }
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
}
