package com.rlpvp;

/** The attack mask must never remove a swing that can geometrically hit (static target, exact observation) and must remove swings that cannot. */
public final class AttackGateGeometryCheck {
    public static void main(String[] args) {
        int allowedHits = 0, maskedHits = 0, maskedMisses = 0, allowedMisses = 0;
        // box 0.6 wide centred on the target; eye at the same height; ray reach 3.0 to the box (PvpSim.crosshairOn)
        for (double d = 0.5; d <= 4.5; d += 0.05) {
            for (double yaw = 0; yaw <= 60; yaw += 0.25) {
                double yr = Math.toRadians(yaw);
                double ox = d * Math.sin(yr), oz = d * Math.cos(yr);      // target centre relative to the eye; ray along +z
                boolean hit = rayHits(ox, oz);
                boolean offered = (ActionMask.withAttackGate(0, d, yaw, 0.0) & ActionMask.LOCK_ATTACK) == 0;
                if (hit && offered) allowedHits++; else if (hit) { maskedHits++; System.out.printf("MASKED REAL HIT d=%.2f yaw=%.2f%n", d, yaw); }
                else if (offered) allowedMisses++; else maskedMisses++;
            }
        }
        System.out.printf("hit&offered %d | hit&MASKED %d | miss&masked %d | miss&offered %d%n", allowedHits, maskedHits, maskedMisses, allowedMisses);
        if (maskedHits > 0) throw new AssertionError("gate removed swings that can hit");
        if (maskedMisses == 0) throw new AssertionError("gate removed nothing");
        if ((ActionMask.withAttackGate(0, 3.9, 0, 0) & ActionMask.LOCK_ATTACK) == 0) throw new AssertionError("3.9 blocks must be masked");
        if ((ActionMask.withAttackGate(0, 3.0, 0, 0) & ActionMask.LOCK_ATTACK) != 0) throw new AssertionError("dead-on at 3.0 must be offered");
        System.out.println("PASS attack gate geometry");
    }

    private static boolean rayHits(double ox, double oz) {   // ray from origin along +z, box centre (ox, oz), half-width 0.3, reach 3.0
        double lo = ox - 0.3, hi = ox + 0.3;
        if (lo > 0 || hi < 0) return false;                      // ray x = 0 must cross the box in x
        double zNear = oz - 0.3;                                 // first z where the ray enters the box
        return Math.max(zNear, 0) <= Config.ATTACK_REACH && oz + 0.3 >= 0;
    }
}
