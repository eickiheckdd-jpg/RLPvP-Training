package com.rlpvp;

public final class StrafeActionCheck {
    public static void main(String[] args) {
        check(StrafeAction.resolve(1, true, -1) == -1, "neutral+hold must retain left");
        check(StrafeAction.resolve(1, true, 1) == 1, "neutral+hold must retain right");
        check(StrafeAction.resolve(1, false, -1) == 0, "neutral without hold must release");
        check(StrafeAction.resolve(2, true, -1) == 1, "explicit right must override prior left and hold");
        check(StrafeAction.resolve(0, true, 1) == -1, "explicit left must override prior right and hold");
        check(StrafeAction.resolve(1, true, 0) == 0, "hold with no prior direction remains neutral");
        System.out.println("StrafeActionCheck PASS");
    }
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
}
