package com.rlpvp;

import java.nio.file.Path;
import java.util.Random;

/**
 * Checks for the play-mode policy, the per-head entropy floors, the greedy stage gate and the 378-input .bin compatibility.
 * No simulation and no training. Usage: java PlayGateCheck [state.bin]
 */
public final class PlayGateCheck {
    static int fails;

    static void check(String name, boolean ok) {
        System.out.println((ok ? "ok   " : "FAIL ") + name);
        if (!ok) fails++;
    }

    static float[] obs(Random r) {
        float[] o = new float[Config.OBS_SIZE];
        for (int i = 0; i < o.length; i++) o[i] = (float) (r.nextGaussian() * 0.3);
        return o;
    }

    public static void main(String[] args) throws Exception {
        check("observation layout still 378 inputs", Config.OBS_SIZE == 378);
        Random r = new Random(5);

        // 1) fresh agent: argmax can never jump (prior p < 0.5), play mode does
        PpoAgent a = new PpoAgent(1);
        a.setMask(0);
        int gJump = 0, pJump = 0, gStrafeNone = 0, pStrafeNone = 0, n = 4000;
        for (int i = 0; i < n; i++) {
            float[] o = obs(r);
            if (a.actGreedy(o)[5] == 1) gJump++;
            if (a.actGreedy(o)[3] == 1) gStrafeNone++;
            if (a.actPlay(o)[5] == 1) pJump++;
            if (a.actPlay(o)[3] == 1) pStrafeNone++;
        }
        System.out.printf("fresh agent: jump greedy %d / play %d of %d; strafe-none greedy %d / play %d%n", gJump, pJump, n, gStrafeNone, pStrafeNone);
        check("argmax never jumps with the prior (the artifact that hid jumps/crits)", gJump == 0);
        check("play mode jumps sometimes", pJump > n / 10 && pJump < n / 2);

        // 2) locked heads stay neutral in play mode
        a.setMask(Curriculum.lockMaskFor(1));
        boolean neutral = true;
        for (int i = 0; i < 500; i++) {
            float[] o = a.actPlay(obs(r));
            neutral &= o[2] == 1 && o[3] == 1 && o[4] == 0 && o[5] == 0 && o[6] == 0;
        }
        check("play mode respects the curriculum locks", neutral);

        // 3) stage gate
        check("no timer: a full window with a 0% win rate never advances", !Curriculum.mayAdvance(3, 0.0, true, true));
        check("no timer: an unfilled window never advances, even at 100%", !Curriculum.mayAdvance(3, 1.0, false, true));
        check("win rate at the gate with a full window advances (stage 3)", Curriculum.mayAdvance(3, Config.STAGE_GATE_WIN[2], true, true));
        check("win rate just below the gate holds", !Curriculum.mayAdvance(3, Config.STAGE_GATE_WIN[2] - 0.01, true, true));
        check("win rate alone is not enough from stage 4 without greedy play", !Curriculum.mayAdvance(5, 1.0, true, false));
        check("win rate + greedy ok advances", Curriculum.mayAdvance(5, 1.0, true, true));
        check("the last stage never advances", !Curriculum.mayAdvance(Curriculum.STAGES, 1.0, true, true));
        Curriculum c = new Curriculum();
        c.setGreedyResult(1.0, 20, 5);
        check("probe with < 2 hits holds the gate", !c.greedyOk());
        c.setGreedyResult(5.0, 20, 5);
        check("probe with hits passes", c.greedyOk());

        // 4) per-head entropy floor: drive the strafe head to a one-key policy and see the boost switch on (training-time logic only, no env)
        PpoAgent t = new PpoAgent(2);
        t.setMask(0);
        float[] o = obs(r);
        for (int i = 0; i < 600; i++) t.actTrain(o);
        check("healthy prior: no head boost", t.headBoost(0) == 1f && t.headBoost(1) == 1f);
        PpoAgent d = new PpoAgent(3);
        d.setMask(0);
        int ob = d.actor.w.length - Config.ACTION_SIZE;
        // strafe head collapsed onto one key. A symmetric policy has no favourite side (a bias on "left" is averaged with the
        // mirrored pass), so it can only collapse onto "none"; the plain policy collapses onto "left".
        int hot = Config.SYMMETRIC_POLICY ? 1 : 0, cold = Config.SYMMETRIC_POLICY ? 0 : 1;
        d.actor.w[ob + Config.OFF_STRAFE + hot] = 9f;
        d.actor.w[ob + Config.OFF_STRAFE + cold] = 0f;
        for (int i = 0; i < 800; i++) d.actTrain(o);
        check("collapsed strafe head gets the entropy boost, other heads do not", d.headBoost(1) == Config.HEAD_ENTROPY_BOOST && d.headBoost(0) == 1f);

        // 5) .bin compatibility
        if (args.length > 0) {
            PpoAgent b = PpoAgent.load(Path.of(args[0]), 3);
            b.setMask(0);
            float[] act = b.actPlay(obs(r));
            check("existing .bin loads (ticks " + b.totalTicks + ", stage " + b.stage + ") and acts", act.length == 7);
        }
        System.out.println(fails == 0 ? "ALL OK" : fails + " FAILED");
        if (fails > 0) System.exit(1);
    }
}
