package com.rlpvp;

/** Checks the positioning/combo reward lifecycle used by both Trainer and PvpSim. */
public final class CombatPositionRewardCheck {
    private static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }

    private static double sum(double[] terms) {
        double s = 0;
        for (double term : terms) s += term;
        return s;
    }

    public static void main(String[] args) {
        CombatPositionReward reward = new CombatPositionReward();
        double preGate = reward.tick(CombatPositionReward.MIN_STAGE - 1, 2.7, 0, false, false, false, false);
        check("position shaping remains gated before its curriculum stage", preGate == 0.0 && sum(reward.lastTerms()) == 0.0);

        double spaceAndLook = reward.tick(CombatPositionReward.MIN_STAGE, 2.7, 45, false, false, false, false);
        check("space-band and close-range look-away terms are emitted separately",
            Math.abs(spaceAndLook - (CombatPositionReward.BAND_REWARD - CombatPositionReward.LOOK_AWAY_PENALTY)) < 1e-9
                && Math.abs(sum(reward.lastTerms()) - spaceAndLook) < 1e-9);

        reward.reset();
        reward.tick(CombatPositionReward.MIN_STAGE, 4.0, 0, true, false, false, false);
        double chainHit = reward.tick(CombatPositionReward.MIN_STAGE, 4.0, 0, true, true, false, false);
        check("second consecutive hit pays the chain and airborne-hit penalties",
            Math.abs(chainHit - (-CombatPositionReward.CONSEC_HIT_PENALTY - CombatPositionReward.AIRBORNE_HIT_PENALTY)) < 1e-9);
        double breakHit = reward.tick(CombatPositionReward.MIN_STAGE, 4.0, 0, false, false, true, true);
        check("landing a sprint-knockback hit breaks the chain once",
            Math.abs(breakHit - (CombatPositionReward.COMBO_BREAK_REWARD + CombatPositionReward.COMBO_BREAK_KNOCKBACK_BONUS)) < 1e-9);
        check("last-term decomposition always sums to the exact reward",
            Math.abs(sum(reward.lastTerms()) - breakHit) < 1e-9);
    }
}
