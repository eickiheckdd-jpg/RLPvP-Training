package com.rlpvp;

import java.util.Random;

/** Gameplay camera controller (GameplayRotation = CameraMap + AimBrake + CameraDynamics + wrap / pitch stop). Pure Java, no simulation. */
public final class GameplayRotationCheck {
    static int fails;
    static void check(String name, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + name); if (!ok) fails++; }
    static final double YS = Config.YAW_SCALE, PS = Config.PITCH_SCALE;

    /** Drive one axis toward `target` degrees from `start` with a proportional hand (gain g) through GameplayRotation. Returns {maxOvershoot, settleTick, reversals, finalErr, maxAbsAccel, maxAbsJerk, maxStep}. */
    static double[] chaseYaw(float start, float target, double g, boolean brake, int ticks) {
        GameplayRotation r = new GameplayRotation();
        float yaw = start; double over = 0, lastV = 0, maxA = 0, maxJ = 0, maxStep = 0; int settle = -1, rev = 0;
        double sign = Math.signum(GameplayRotation.shortestYawDelta(start, target));
        for (int t = 0; t < ticks; t++) {
            double err = GameplayRotation.shortestYawDelta(yaw, target);
            double eff = Math.max(-YS, Math.min(YS, err * g));
            r.stepEffort(eff, 0, yaw, 0f, err, 0, true, false, brake);
            yaw = r.newYaw;
            double e2 = GameplayRotation.shortestYawDelta(yaw, target);
            over = Math.max(over, -sign * e2);
            double v = r.yaw.vel();
            if (v * lastV < 0 && Math.abs(lastV) > 1) rev++;
            lastV = v;
            maxA = Math.max(maxA, Math.abs(r.yaw.acc())); maxJ = Math.max(maxJ, Math.abs(r.yaw.lastJerk())); maxStep = Math.max(maxStep, Math.abs(r.dYaw));
            if (settle < 0 && Math.abs(e2) < 1 && Math.abs(v) < 1) settle = t;
        }
        return new double[]{over, settle, rev, Math.abs(GameplayRotation.shortestYawDelta(yaw, target)), maxA, maxJ, maxStep};
    }

    public static void main(String[] x) {
        final double accMax = Config.CAM_ACC_MAX_FRAC * YS, jerkMax = Config.CAM_JERK_MAX_FRAC * YS;

        // TEST 1 large yaw change: no instantaneous jump
        GameplayRotation r = new GameplayRotation();
        r.step(1f, 0f, 0f, 0f, 0, 0, false, false, false);
        check("1 large command: first tick turns " + String.format("%.2f", r.dYaw) + " deg, far below the " + YS + " deg maximum (no snap)", r.dYaw > 0f && r.dYaw < 0.1 * YS);
        float prev = r.dYaw; boolean smooth = true; float yw = r.newYaw;
        for (int t = 0; t < 30; t++) { r.step(1f, 0f, yw, 0f, 0, 0, false, false, false); yw = r.newYaw; smooth &= Math.abs(r.dYaw - prev) <= jerkMax + accMax * 0 + 6.0; prev = r.dYaw; }
        // 2 small correction
        double[] c2 = chaseYaw(0f, 2f, 2.0, true, 80);
        check(String.format("2 small 2 deg correction: overshoot %.2f deg, final error %.2f deg", c2[0], c2[3]), c2[0] <= Config.AIM_BRAKE_SLACK_DEG + 0.5 && c2[3] < 1.0);
        // 3 pitch
        GameplayRotation rp = new GameplayRotation(); float pitch = 0f; float maxDp = 0; boolean limits = true;
        for (int t = 0; t < 200; t++) { rp.step(0f, 1f, 0f, pitch, 0, 0, false, false, false); pitch = rp.newPitch; maxDp = Math.max(maxDp, Math.abs(rp.dPitch)); limits &= pitch <= 90f && pitch >= -90f; }
        check("3 pitch: full-up command saturates exactly at +90, never beyond; max step " + String.format("%.2f", maxDp) + " <= " + PS, pitch == 90f && limits && maxDp <= PS + 1e-3);
        rp.step(0f, -1f, 0f, pitch, 0, 0, false, false, false);
        check("3b pitch wall stops the stored velocity (no wind-up): after the wall the first reverse tick is gentle", Math.abs(rp.dPitch) < 0.3 * PS);
        // 4 wrap
        double[] c4 = chaseYaw(175f, -175f, 2.0, true, 60);
        check(String.format("4 wrap: 175 -> -175 takes the 10 deg path (max single step %.1f deg, final error %.2f)", c4[6], c4[3]), c4[6] < 12 && c4[3] < 1.0);
        GameplayRotation rw = new GameplayRotation(); float w = 0f; boolean continuous = true;
        for (int i = 0; i < 1000; i++) {
            float old = w;
            rw.step(1f, 0f, w, 0f, 0, 0, false, false, false);
            w = rw.newYaw;
            // Compare the equivalent short change to avoid float-ULP noise after many accumulated revolutions.
            continuous &= Float.isFinite(w) && Math.abs(GameplayRotation.shortestYawDelta(old, w) - rw.dYaw) < 0.01f;
        }
        check("4b absolute yaw stays continuous through repeated 180/360-degree crossings (no modulo snap)", continuous && w > 360f);
        check("4c shortestYawDelta(170,-170)=+20, (-170,170)=-20, (0,180)=-180", GameplayRotation.shortestYawDelta(170f, -170f) == 20f && GameplayRotation.shortestYawDelta(-170f, 170f) == -20f && GameplayRotation.shortestYawDelta(0f, 180f) == -180f);
        GameplayRotation boundary = new GameplayRotation(); float boundaryYaw = 179f;
        for (int i = 0; i < 80; i++) {
            double boundaryErr = GameplayRotation.shortestYawDelta(boundaryYaw, 181f);
            boundary.stepEffort(Math.max(-YS, Math.min(YS, boundaryErr * 2.0)), 0.0, boundaryYaw, 0f, boundaryErr, 0.0, true, false, true);
            boundaryYaw = boundary.newYaw;
        }
        check(String.format("4d target at 181 degrees is reached through +180 without wrapping the absolute yaw (final %.3f)", boundaryYaw), boundaryYaw > 180f && Math.abs(GameplayRotation.shortestYawDelta(boundaryYaw, 181f)) < 2.0);
        // 5 acceleration limits (hostile random commands through the full pipeline, brake on)
        Random rnd = new Random(5); GameplayRotation rh = new GameplayRotation(); double mA = 0, mJ = 0, mV = 0; float yy = 0, pp = 0;
        for (int t = 0; t < 200000; t++) {
            rh.step((float) (rnd.nextGaussian() * 2), (float) (rnd.nextGaussian() * 2), yy, pp, (rnd.nextDouble() - 0.5) * 360, (rnd.nextDouble() - 0.5) * 90, rnd.nextInt(10) > 0, true, true);
            yy = rh.newYaw; pp = rh.newPitch; mA = Math.max(mA, Math.abs(rh.yaw.acc())); mJ = Math.max(mJ, Math.abs(rh.yaw.lastJerk())); mV = Math.max(mV, Math.abs(rh.yaw.vel()));
        }
        check(String.format("5 limits over 200k hostile ticks: |a| %.2f <= %.2f, |jerk| %.2f <= %.2f, |v| %.2f <= %.0f", mA, accMax, mJ, jerkMax, mV, YS), mA <= accMax + 1e-9 && mJ <= jerkMax + 1e-9 && mV <= YS + 1e-9);
        // 6 deceleration: releasing the command decays smoothly (monotone, no reversal)
        GameplayRotation rd = new GameplayRotation(); float a = 0;
        for (int t = 0; t < 20; t++) { rd.step(1f, 0f, a, 0f, 0, 0, false, false, false); a = rd.newYaw; }
        double v0 = rd.yaw.vel(); boolean mono = true, noRev = true; double lastV = v0; int stop = -1;
        for (int t = 0; t < 80; t++) { rd.step(0f, 0f, a, 0f, 0, 0, false, false, false); a = rd.newYaw; double v = rd.yaw.vel(); mono &= v <= lastV + 1e-9; noRev &= v >= -1e-9; lastV = v; if (stop < 0 && v < 0.05) stop = t; }
        check(String.format("6 release: speed %.1f -> 0 monotonically in %d ticks, no reversal", v0, stop), mono && noRev && stop > 1);
        // 7 overshoot prevention, 8 stability: far target at full speed, brake on vs off
        double[] on = chaseYaw(0f, 120f, 2.0, true, 120), off = chaseYaw(0f, 120f, 2.0, false, 120), onBang = chaseYaw(0f, 40f, 100.0, true, 120), offBang = chaseYaw(0f, 40f, 100.0, false, 120);
        check(String.format("7 overshoot toward 120 deg: brake on %.1f deg vs off %.1f deg; bang-bang toward 40: on %.1f vs off %.1f", on[0], off[0], onBang[0], offBang[0]), on[0] <= 3 && off[0] > 5 * Math.max(0.5, on[0]) && onBang[0] <= 4 && offBang[0] > 10);
        GameplayRotation rq = new GameplayRotation(); float qy = 0f; double tailErr = 0, tailV = 0; int tailRev = 0; double lv = 0;
        for (int t = 0; t < 300; t++) {
            double err = GameplayRotation.shortestYawDelta(qy, 120f);
            rq.stepEffort(Math.max(-YS, Math.min(YS, err * 2.0)), 0, qy, 0f, err, 0, true, false, true); qy = rq.newYaw;
            if (t >= 150) { tailErr = Math.max(tailErr, Math.abs(GameplayRotation.shortestYawDelta(qy, 120f))); tailV = Math.max(tailV, Math.abs(rq.yaw.vel())); if (rq.yaw.vel() * lv < 0 && Math.abs(lv) > 0.05) tailRev++; }
            lv = rq.yaw.vel();
        }
        check(String.format("8 stability: ticks 150-300 after a 120 deg turn: max error %.3f deg, max speed %.3f deg/tick, %d small direction reversals; the oscillation is bounded below the brake slack (%.1f deg) and ~1 vanilla mouse count, it is the proportional test hand + inertia, not a growing swing", tailErr, tailV, tailRev, Config.AIM_BRAKE_SLACK_DEG), tailErr < Config.AIM_BRAKE_SLACK_DEG && tailV < 0.5);
        // 9 zero input
        GameplayRotation rz = new GameplayRotation(); float zy = 37f, zp = -12f; for (int t = 0; t < 1000; t++) { rz.step(0f, 0f, zy, zp, 0, 0, false, false, true); zy = rz.newYaw; zp = rz.newPitch; }
        check("9 zero input from rest for 1000 ticks: no drift (yaw 37, pitch -12 exactly)", zy == 37f && zp == -12f);
        // 10 target change: target flips from +40 to -40 after settling; time to reverse
        GameplayRotation rt = new GameplayRotation(); float ty = 0f; int reach = -1; double tgt = 40;
        for (int t = 0; t < 120; t++) {
            if (t == 40) tgt = -40;
            double err = GameplayRotation.shortestYawDelta(ty, (float) tgt);
            rt.stepEffort(Math.max(-YS, Math.min(YS, err * 2.0)), 0, ty, 0f, err, 0, true, false, true); ty = rt.newYaw;
            if (t > 40 && reach < 0 && Math.abs(GameplayRotation.shortestYawDelta(ty, -40f)) < 3) reach = t - 40;
        }
        check("10 target flip 40 -> -40 deg (80 deg turn): on target within " + reach + " ticks (<= 22)", reach > 0 && reach <= 22);
        // 11 independent axes
        GameplayRotation ri = new GameplayRotation(); float iy = 0, ip = 0; for (int t = 0; t < 40; t++) { ri.step(1f, 0f, iy, ip, 0, 0, false, false, false); iy = ri.newYaw; ip = ri.newPitch; }
        check("11a yaw-only command leaves pitch untouched (pitch " + ip + ", pitch velocity " + ri.pitch.vel() + ")", ip == 0f && ri.pitch.vel() == 0.0);
        GameplayRotation rj = new GameplayRotation(); float jy = 0, jp = -60f; double worstDiff = 0, maxY = 0;
        // Compare both axes before the faster pitch axis can reach Minecraft's hard +90 degree pitch stop.
        for (int t = 0; t < 5; t++) { rj.step(1f, 1f, jy, jp, 0, 0, false, false, false); jy = rj.newYaw; jp = rj.newPitch; worstDiff = Math.max(worstDiff, Math.abs(rj.dYaw / YS - rj.dPitch / PS)); maxY = Math.max(maxY, Math.abs(rj.dYaw)); }
        check(String.format("11b full yaw+pitch before pitch stop: per-tick turn normalised by its axis scale is identical (worst diff %.2e), yaw scale %.0f / pitch scale %.0f used independently", worstDiff, YS, PS), worstDiff < (Config.MOUSE_QUANTIZE ? Config.MOUSE_DEG_PER_COUNT / PS + 1e-6 : 1e-6) && Math.abs(jy) > 1 && Math.abs(jp + 60f) > 0.1);
        // 12 initialisation / reset / hold
        GameplayRotation rr = new GameplayRotation(); for (int t = 0; t < 15; t++) rr.step(1f, 1f, 0f, 0f, 0, 0, false, false, false);
        rr.reset(); rr.step(0f, 0f, 10f, 5f, 0, 0, false, false, false);
        check("12a reset: next tick without command does not move the camera", rr.newYaw == 10f && rr.newPitch == 5f);
        GameplayRotation rs = new GameplayRotation(); float sy = 0; for (int t = 0; t < 15; t++) { rs.step(1f, 0f, sy, 0f, 0, 0, false, false, false); sy = rs.newYaw; }
        double before = rs.yaw.vel(); rs.hold(sy, 0f); double after = rs.yaw.vel();
        check(String.format("12b stale observation hold(): speed %.2f -> %.2f (brakes smoothly, no jump, no freeze)", before, after), after < before && after > 0.5 * before - 1e-9);
        GameplayRotation rn = new GameplayRotation(); rn.step(Float.NaN, Float.POSITIVE_INFINITY, 1f, 2f, Double.NaN, Double.NaN, true, true, true);
        check("12c NaN / inf outputs and NaN errors give a finite camera", Float.isFinite(rn.newYaw) && Float.isFinite(rn.newPitch));
        // fine aiming: 0.05 deg and 0.5 deg targets are reached (no artificial dead zone)
        double[] f1 = chaseYaw(0f, 0.5f, 2.0, true, 200), f2 = chaseYaw(0f, 0.1f, 2.0, true, 200);
        check(String.format("fine aiming: 0.5 deg target final error %.3f, 0.1 deg target final error %.3f (no dead zone, <= slack %.2f)", f1[3], f2[3], Config.AIM_BRAKE_SLACK_DEG), f1[3] <= Config.AIM_BRAKE_SLACK_DEG + Config.MOUSE_DEG_PER_COUNT && f2[3] <= Config.AIM_BRAKE_SLACK_DEG + Config.MOUSE_DEG_PER_COUNT);
        // 14 efficiency: cost of one tick
        GameplayRotation rb = new GameplayRotation(); float by = 0, bp = 0; Random q = new Random(9); float[] raw = new float[1024]; for (int i = 0; i < raw.length; i++) raw[i] = (float) (q.nextGaussian() * 0.3);
        for (int i = 0; i < 300000; i++) { rb.step(raw[i & 1023], raw[(i * 7) & 1023], by, bp, 20.0 * raw[i & 1023], 5.0, true, true, true); by = rb.newYaw; bp = rb.newPitch; }
        int N = 2_000_000; long t0 = System.nanoTime(); double sink = 0;
        for (int i = 0; i < N; i++) { rb.step(raw[i & 1023], raw[(i * 7) & 1023], by, bp, 20.0 * raw[i & 1023], 5.0, true, true, true); by = rb.newYaw; bp = rb.newPitch; sink += by; }
        double ns = (System.nanoTime() - t0) / (double) N;
        long t1 = System.nanoTime(); for (int i = 0; i < N; i++) { rb.step(raw[i & 1023], raw[(i * 7) & 1023], by, bp, 0, 0, false, false, false); by = rb.newYaw; bp = rb.newPitch; sink += by; }
        double nsNo = (System.nanoTime() - t1) / (double) N;
        System.out.printf("14 cost per tick (yaw+pitch, brake ON): %.0f ns; brake OFF: %.0f ns (a game tick is 50,000,000 ns); sink %.1f%n", ns, nsNo, sink);
        check("14 controller costs < 20 microseconds per tick (0.04% of a 50 ms tick)", ns < 20000);
        System.out.println(fails == 0 ? "GameplayRotationCheck: ALL OK" : fails + " FAILED");
        if (fails > 0) System.exit(1);
    }
}
