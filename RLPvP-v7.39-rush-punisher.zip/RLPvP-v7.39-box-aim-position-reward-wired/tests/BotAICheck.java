package com.rlpvp;

import java.util.Random;

/** Fairness invariants of BotAI over many random states: it must never act beyond what a fair fighter could. */
public class BotAICheck {
    static int fails = 0;
    static void check(String name, boolean ok) { System.out.printf("%-62s %s%n", name, ok ? "ok" : "FAIL"); if (!ok) fails++; }

    public static void main(String[] x) {
        Random r = new Random(3);
        BotAI ai = new BotAI(r);
        boolean chargeOk = true, reachOk = true, turnOk = true, sprintOk = true, finite = true;
        double maxTurn = 0, tx = 0, tz = 0;
        for (int ep = 0; ep < 200; ep++) {
            ai.reset();
            ai.newEpisode(ep % 2 == 0, r.nextDouble());
            double yaw = r.nextDouble() * 360 - 180, pitch = 0;
            for (int t = 0; t < 120; t++) {
                BotAI.In s = ai.in;
                s.bx = 0; s.by = 0; s.bz = 0; s.byaw = yaw; s.bpitch = pitch; s.eyeY = 1.62; s.bvy = r.nextBoolean() ? -0.1 : 0.2; s.bGround = r.nextBoolean();
                s.hurtTime = r.nextInt(11); s.bScale = r.nextDouble(); s.bHp = 1 + r.nextInt(20);
                // the target moves continuously (up to sprint speed), like a real player; it does not teleport between ticks
                if (t == 0) { double ang = r.nextDouble() * 6.283, d0 = 1.0 + r.nextDouble() * 6; tx = Math.cos(ang) * d0; tz = Math.sin(ang) * d0; }
                tx += (r.nextDouble() - 0.5) * 0.56; tz += (r.nextDouble() - 0.5) * 0.56;
                double d = Math.hypot(tx, tz);
                s.tx = tx; s.tz = tz; s.ty = 0; s.tScale = r.nextDouble(); s.tHp = 1 + r.nextInt(20);
                BotAI.Out o = ai.think(s);
                if (o.attack && s.bScale < Config.MIN_ATTACK_STRENGTH) chargeOk = false;
                if (o.attack && d > BotAI.REACH_CENTER + 0.9) reachOk = false; // the lead prediction may add a little, never a whole block
                double turn = Math.abs(BotAI.wrap(o.yaw - yaw));
                maxTurn = Math.max(maxTurn, turn);
                if (turn > Config.BOT_TURN_STRONG + 12.0) turnOk = false;       // turn cap + a few degrees of noise
                if (o.sprint && o.fwd <= 0) sprintOk = false;
                if (Double.isNaN(o.yaw) || Double.isNaN(o.pitch) || Math.abs(o.pitch) > 90.01) finite = false;
                yaw = o.yaw; pitch = o.pitch;
            }
        }
        check("never swings below the full-charge gate", chargeOk);
        check("never swings from far outside reach", reachOk);
        check("turn rate stays within the human-ish cap (+ noise); max seen " + String.format("%.1f", maxTurn) + " deg/tick", turnOk);
        check("never sprints without moving forward", sprintOk);
        check("yaw / pitch always finite and pitch within +-90", finite);
        ai.reset();
        ai.newEpisode(true, 0.5, BotAI.HUMAN);
        check("PFSP can instantiate the fixed HUMAN style with delayed, noisy, imperfect reactions",
            ai.skill().style == BotAI.HUMAN && ai.skill().reactionDelay >= 2 && ai.skill().reactionDelay <= 4
                && ai.skill().overshoot > 0.0 && ai.skill().pressureMistake > 0.0);
        BotDifficulty d = new BotDifficulty();
        for (int i = 0; i < 120; i++) d.report(true);
        boolean up = d.value() > BotDifficulty.START;
        for (int i = 0; i < 400; i++) d.report(false);
        check("difficulty rises when the agent wins and falls when it loses, within 0.15..1.0", up && d.value() >= BotDifficulty.MIN && d.value() < 0.5);
        System.out.println(fails == 0 ? "BotAICheck: all ok" : "BotAICheck: " + fails + " FAILED");
        if (fails != 0) System.exit(1);
    }
}
