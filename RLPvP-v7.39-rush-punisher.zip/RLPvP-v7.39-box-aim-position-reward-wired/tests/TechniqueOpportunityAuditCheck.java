package com.rlpvp;

/** Regression checks for opportunity -> policy choice -> swing -> HP-confirmation telemetry. */
public final class TechniqueOpportunityAuditCheck {
    public static void main(String[] args) {
        TechniqueOpportunityAudit a = new TechniqueOpportunityAudit();

        // A continuously available crit posture is one opportunity window, not one opportunity per tick.
        a.observeDecision(true, true, true, 1.0, true, false, 2.6, 3.0, 2.0, false);
        a.observeDecision(true, true, true, 1.0, true, false, 2.5, 2.0, 1.0, false);
        a.observeDecision(true, true, true, 1.0, true, false, 2.4, 1.0, 1.0, true);
        a.recordSwing(HitMemory.CRIT, true); // within the open crit opportunity
        a.observeDecision(true, true, false, 1.0, true, false, 3.2, 1.0, 1.0, false); // closes it
        a.recordSwing(HitMemory.CRIT, false); // typed attempt outside a valid opportunity

        // A sprint window that ends at an episode boundary is censored, not mislabeled as ignored.
        a.observeDecision(true, true, true, 1.0, false, true, 2.7, 4.0, 3.0, false);
        a.observeDecision(true, true, true, 1.0, false, true, 2.7, 4.0, 3.0, false);
        a.recordSwing(HitMemory.SPRINT, false); // within the censored sprint opportunity
        a.finishEpisode();

        a.recordSwing(HitMemory.WEAK, true);
        a.recordConfirmedHit(true, false, 1.4, false);
        a.recordConfirmedHit(false, true, 0.9, true);
        a.recordConfirmedHit(false, false, 0.5, true);

        String header = TechniqueOpportunityAudit.csvHeader();
        String row = a.csvRow(1234, 9);
        check(header.split(",", -1).length == row.split(",", -1).length,
            "opportunity audit CSV header and row have matching column counts");
        check(row.startsWith("1234,9,"), "ticks and stage lead the row");

        String[] cells = row.split(",", -1);
        // Category bucket width is 19; each starts with opportunity/window and then swing counters.
        check("1".equals(cells[2]), "crit availability is counted once per continuous window");
        check("1".equals(cells[3]), "crit attack selection is counted once");
        check("0".equals(cells[4]), "selected crit window is not counted as unselected");
        check("0".equals(cells[5]), "closed crit window is not censored");
        check("1".equals(cells[6]), "crit swings made inside the opportunity are attributed to that window");
        check("1".equals(cells[7]), "within-opportunity ray selection is tracked separately");
        check("2".equals(cells[8]), "all typed crit swing attempts are counted, including out-of-opportunity attempts");
        check("1".equals(cells[9]), "client target selection is separate from swing attempts");
        check("1".equals(cells[10]), "HP-confirmed crit hit is counted separately");
        check("0".equals(cells[11]) && "1".equals(cells[12]), "mod-side credited hits are distinguished from authoritative server hits");
        check("1.4000".equals(cells[13]), "confirmed crit damage is accumulated");

        int sprint = 2 + 19;
        check("1".equals(cells[sprint]), "sprint availability is counted once");
        check("0".equals(cells[sprint + 1]), "unselected sprint window remains unselected");
        check("0".equals(cells[sprint + 2]), "episode-censored window is not marked as a completed miss");
        check("1".equals(cells[sprint + 3]), "episode-censored sprint window is visible");
        check("1".equals(cells[sprint + 4]), "sprint swing attempt is attributed to the open opportunity");
        check("0".equals(cells[sprint + 5]), "sprint ray selection inside the window is separately counted");
        check("1".equals(cells[sprint + 6]), "sprint swing attempt is counted globally");
        check("1".equals(cells[sprint + 8]), "HP-confirmed sprint hit is counted");
        check("1".equals(cells[sprint + 9]), "server-resolved sprint hit is distinguished");
        check("0.9000".equals(cells[sprint + 11]), "confirmed sprint damage is accumulated");

        int other = 2 + 38;
        check("1".equals(cells[other + 6]), "non-crit/non-sprint attempts have a baseline bucket");
        check("1".equals(cells[other + 8]), "ordinary HP-confirmed hits have a baseline bucket");

        TechniqueOpportunityAudit merged = new TechniqueOpportunityAudit();
        merged.mergeWindow(a);
        String mergedRow = merged.csvRow(1234, 9);
        check("1".equals(mergedRow.split(",", -1)[2]), "parallel-window merge preserves opportunities");
        merged.clearWindow();
        String cleared = merged.csvRow(1235, 9);
        check("0".equals(cleared.split(",", -1)[2]), "clearWindow resets emitted counters");

        TechniqueOpportunityAudit invalid = new TechniqueOpportunityAudit();
        invalid.recordConfirmedHit(true, true, Double.NaN, true);
        invalid.recordSwing(HitMemory.CRIT | HitMemory.SPRINT, true);
        String[] invalidCells = invalid.csvRow(1, 9).split(",", -1);
        check("2".equals(invalidCells[58]), "ambiguous hit and swing labels are surfaced, not silently assigned");
        check("1".equals(invalidCells[46]), "ambiguous swing is retained in the ordinary diagnostic bucket");
        check("1".equals(invalidCells[47]), "ambiguous swing target selection is retained");
        check("0".equals(invalidCells[8]) && "0".equals(invalidCells[27]), "ambiguous swing is not double-counted as crit or sprint");
        check("0.0000".equals(invalidCells[51]), "non-finite damage is ignored");

        TechniqueOpportunityAudit boundary = new TechniqueOpportunityAudit();
        boundary.observeDecision(true, true, true, Config.FULL_CHARGE, true, false,
            2.0, 0.0, 0.0, true);
        boundary.recordSwing(HitMemory.typeMask(false, true, false, false), false);
        String[] boundaryCells = boundary.csvRow(2, 9).split(",", -1);
        check("0".equals(boundaryCells[2]), "exactly-full-threshold charge is not counted as a strict full-charge opportunity");
        check("0".equals(boundaryCells[8]), "strict-threshold falling swing is not mislabeled as a critical attempt");
        check("1".equals(boundaryCells[46]), "strict-threshold falling swing remains in the ordinary-attempt bucket");

        TechniqueOpportunityAudit selectedCensored = new TechniqueOpportunityAudit();
        selectedCensored.observeDecision(true, true, true, 1.0, true, false,
            2.0, 0.0, 0.0, true);
        selectedCensored.finishEpisode();
        String[] selectedCensoredCells = selectedCensored.csvRow(3, 9).split(",", -1);
        check("1".equals(selectedCensoredCells[3]) && "1".equals(selectedCensoredCells[5]),
            "a selected but episode-truncated opportunity retains both facts");
        check("0".equals(selectedCensoredCells[4]), "a censored selected opportunity is not mislabeled as a completed miss");
        System.out.println("TechniqueOpportunityAuditCheck: all checks passed");
    }

    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
        System.out.println("PASS " + message);
    }
}
