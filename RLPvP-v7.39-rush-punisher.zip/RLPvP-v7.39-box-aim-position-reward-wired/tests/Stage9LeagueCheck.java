package com.rlpvp;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Regression checks for the open-ended Stage 9 competitive league and weakness-aware PFSP. */
public final class Stage9LeagueCheck {
    public static void main(String[] args) {
        check(Curriculum.STAGES == 9, "curriculum exposes nine stages");
        check(Curriculum.opponentFor(9) == Curriculum.Opponent.SELF_PLAY, "Stage 9 is league self-play");
        check(Curriculum.lockMaskFor(9) == 0, "Stage 9 keeps all combat actions unlocked");

        Curriculum c = new Curriculum();
        c.restore(8, 0);
        c.update(0);
        c.setLeagueRating(OpponentLeague.ADVANCED_PROMOTION_RATING, OpponentLeague.ADVANCED_PROMOTION_GAMES - 1);
        c.update(1);
        check(c.autoStage() == 8, "Stage 8 waits for the full league match sample");
        c.setLeagueRating(OpponentLeague.ADVANCED_PROMOTION_RATING - 1.0, OpponentLeague.ADVANCED_PROMOTION_GAMES);
        c.update(2);
        check(c.autoStage() == 8, "Stage 8 also requires the qualifying league rating");
        c.setLeagueRating(OpponentLeague.ADVANCED_PROMOTION_RATING, OpponentLeague.ADVANCED_PROMOTION_GAMES);
        c.update(3);
        check(c.autoStage() == 9 && c.stage() == 9, "Stage 8 advances to Stage 9 on league evidence");
        c.setGreedyResult(0.0, 0.0, 20.0);
        c.update(4);
        check(c.autoStage() == 9, "a failed probe cannot block or demote Stage 9");
        check(c.status().contains("no probe gate"), "Stage 9 status makes non-gating progression explicit");
        check(c.reviewShare() == 0.0, "Stage 9 does not replay lower-stage review opponents");

        OpponentLeague league = new OpponentLeague();
        league.ensure("current").rating = 1200.0;
        for (int style = 0; style < BotAI.STYLES; style++) league.ensure("script:" + style).rating = 1200.0;
        List<String> candidates = new ArrayList<>();
        for (int style = 0; style < BotAI.STYLES; style++) candidates.add("script:" + style);
        int aggressive = 0, total = 20_000;
        Random rng = new Random(91);
        for (int i = 0; i < total; i++) {
            String id = league.sample("current", candidates, rng, true);
            int style = Integer.parseInt(id.substring("script:".length()));
            if (BotAI.isAggressiveSpecialist(style)) aggressive++;
        }
        check(aggressive > total * 0.49, "Stage 9 preserves meaningful exposure to aggressive specialists (got " + aggressive + "/" + total + ")");

        // Reset Elo to isolate the matchup weakness weight from rating changes.
        OpponentLeague weak = new OpponentLeague();
        weak.ensure("current").rating = 1200.0;
        weak.ensure("script:" + BotAI.PRESSURE).rating = 1200.0;
        weak.ensure("script:" + BotAI.COUNTER).rating = 1200.0;
        for (int i = 0; i < 12; i++) weak.result("current", "script:" + BotAI.PRESSURE, 0.0, 2.0, 12.0);
        weak.ensure("current").rating = 1200.0;
        weak.ensure("script:" + BotAI.PRESSURE).rating = 1200.0;
        weak.ensure("script:" + BotAI.COUNTER).rating = 1200.0;
        int pressure = 0;
        rng = new Random(17);
        for (int i = 0; i < total; i++) {
            String id = weak.sample("current", List.of("script:" + BotAI.PRESSURE, "script:" + BotAI.COUNTER), rng, true);
            if (id.equals("script:" + BotAI.PRESSURE)) pressure++;
        }
        check(pressure > total * 0.68, "PFSP upweights styles that repeatedly beat the learner (got " + pressure + "/" + total + ")");
        check(weak.weaknessSummary("current").contains("pressure"), "league exposes a weakest-opponent summary");

        // A proven bully opponent must not disappear just because its Elo moves outside the standard PFSP band.
        OpponentLeague challenge = new OpponentLeague();
        challenge.ensure("current").rating = 1200.0;
        challenge.ensure("script:" + BotAI.PRESSURE).rating = 1200.0;
        for (int i = 0; i < 5; i++) challenge.result("current", "script:" + BotAI.PRESSURE, 0.0, 1.0, 14.0);
        double learnerRating = challenge.rating("current");
        challenge.ensure("script:" + BotAI.COUNTER).rating = learnerRating - 40.0; // ordinary in-band opponent
        int pressureChallenges = 0;
        rng = new Random(313);
        for (int i = 0; i < total; i++) {
            String id = challenge.sample("current", List.of("script:" + BotAI.PRESSURE, "script:" + BotAI.COUNTER), rng, true);
            if (id.equals("script:" + BotAI.PRESSURE)) pressureChallenges++;
        }
        double challengeShare = pressureChallenges / (double) total;
        check(challengeShare > 0.15 && challengeShare < 0.25,
            "proven hard matchups keep a bounded corrective-play share outside the normal Elo band (got " + pressureChallenges + "/" + total + ")");
        System.out.println("Stage9LeagueCheck OK");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
