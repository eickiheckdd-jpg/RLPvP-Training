package com.rlpvp;

/**
 * Closed-loop check of CameraReward's STILL term. A mouse that matches a moving target's angular rate is TRACKING and must not be charged
 * for its speed; jitter and motion over a still target must still cost. Old behaviour is reproduced with -Drlpvp.trackingStill=false.
 */
public final class CameraTrackingRewardCheck {
    /** Runs n ticks; the target moves by targetRate deg/tick; the controller returns the turn (deg) chosen from the current error. Returns [sumStill, sumTotal]. */
    private static double[] run(double targetRate, java.util.function.DoubleBinaryOperator ctl, int n) {
        CameraReward c = new CameraReward();
        double err = 1.0, turn = 0;
        for (int t = 0; t < n; t++) {
            double u = Math.max(-Config.YAW_SCALE, Math.min(Config.YAW_SCALE, ctl.applyAsDouble(err, t)));
            c.onAction((float) (u / Config.YAW_SCALE), 0f);
            err = err - u + targetRate;          // positive turn reduces positive error (same convention as PvpSim / the aimbot)
            c.tick(err, 0.0, false, false, false, 0.0, 5);
        }
        return new double[]{c.termSum[CameraReward.T_STILL], c.termSum[CameraReward.T_JERK], c.termSum[CameraReward.T_PROGRESS] + c.termSum[CameraReward.T_OVERSHOOT]};
    }

    private static void check(String n, boolean ok, String detail) {
        if (!ok) throw new AssertionError(n + " :: " + detail);
        System.out.println("PASS " + n + "  (" + detail + ")");
    }

    public static void main(String[] args) {
        int n = 400;
        // ideal tracker: keeps the crosshair on a target strafing at 3 deg/tick (turn = rate + small P correction)
        double[] track = run(3.0, (e, t) -> 3.0 + 0.5 * e, n);
        // same speed but fixation on a STILL target: moving the mouse around for no reason, 3 deg/tick left/right every tick (jitter)
        double[] jitter = run(0.0, (e, t) -> (t % 2 == 0 ? 3.0 : -3.0) + 0.5 * e, n);
        boolean tracking = CameraReward.TRACKING_AWARE_STILL;
        System.out.printf("trackingStill=%b  tracker still=%.3f jerk=%.3f | jitter still=%.3f jerk=%.3f%n", tracking, track[0], track[1], jitter[0], jitter[1]);
        if (tracking) {
            check("tracking a moving target is not charged STILL", track[0] > -0.05, String.format("%.3f", track[0]));
            check("jitter over a still target is still charged (STILL+JERK)", jitter[0] + jitter[1] < -1.0, String.format("%.3f", jitter[0] + jitter[1]));
            check("jitter costs far more than tracking", jitter[0] + jitter[1] < 100 * (track[0] + track[1]) - 1.0, String.format("jitter %.3f vs track %.3f", jitter[0] + jitter[1], track[0] + track[1]));
        } else {
            check("legacy mode charges a perfect tracker", track[0] < -1.0, String.format("%.3f", track[0]));
        }
        check("tracker keeps positive/neutral progress", track[2] > -0.5, String.format("%.3f", track[2]));
    }
}
