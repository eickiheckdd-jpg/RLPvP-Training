package com.rlpvp;

import java.util.Random;

/**
 * Finite-difference check of GruCell.backWindow (truncated BPTT): the analytic gradient of L = sum(c . h_final) must match a numerical one for
 * every parameter, over a 6-tick window with random inputs. Also: the window forward equals the acting step, and the default weights give the old
 * multi-timescale memory. RUN THIS BEFORE TRAINING with the trainable cell (-Drlpvp.gruTrain=false disables training if it fails).
 */
public final class GruCellCheck {
    static void check(String n, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + n); if (!ok) throw new AssertionError(n); }

    static double loss(GruCell cell, float[] h0, float[][] xs, float[] c) {
        cell.beginWindow(h0);
        for (float[] x : xs) cell.windowStep(x);
        float[] h = cell.windowH();
        double l = 0; for (int j = 0; j < GruCell.H; j++) l += c[j] * h[j];
        return l;
    }

    public static void main(String[] args) {
        Random rng = new Random(5);
        GruCell cell = new GruCell();
        for (int i = 0; i < GruCell.N; i++) cell.w[i] += (float) (rng.nextGaussian() * 0.2);   // away from the default so every path is exercised
        float[] h0 = new float[GruCell.H];
        for (int j = 0; j < GruCell.H; j++) h0[j] = (float) (rng.nextGaussian() * 0.5);
        float[][] xs = new float[6][GruCell.X];
        for (float[] x : xs) for (int i = 0; i < GruCell.X; i++) x[i] = (float) rng.nextGaussian();
        float[] c = new float[GruCell.H];
        for (int j = 0; j < GruCell.H; j++) c[j] = (float) rng.nextGaussian();

        cell.clearGrad();
        loss(cell, h0, xs, c);
        cell.backWindow(c);
        float[] g = cell.gradForTest().clone();

        // A replay cache computed on a second core must be bit-identical when copied back for BPTT.
        GruCell copied = new GruCell();
        copied.copyWeightsFrom(cell);
        copied.copyWindowFrom(cell);
        boolean cacheSame = java.util.Arrays.equals(cell.windowH(), copied.windowH());
        copied.backWindow(c);
        check("copied GRU replay cache preserves the exact BPTT gradient", cacheSame
                && java.util.Arrays.equals(g, copied.gradForTest()));

        double worst = 0; int bad = 0;
        for (int i = 0; i < GruCell.N; i++) {
            float old = cell.w[i];
            double eps = 1e-2;
            cell.w[i] = (float) (old + eps); double lp = loss(cell, h0, xs, c);
            cell.w[i] = (float) (old - eps); double lm = loss(cell, h0, xs, c);
            cell.w[i] = old;
            double num = (lp - lm) / (2 * eps);
            double err = Math.abs(num - g[i]) / Math.max(1e-2, Math.abs(num) + Math.abs(g[i]));
            worst = Math.max(worst, err);
            if (err > 0.05) bad++;
        }
        System.out.printf("worst relative gradient error %.4f, %d of %d parameters above 5%%%n", worst, bad, GruCell.N);
        check("analytic BPTT gradient matches finite differences", bad == 0);

        // acting step == window step
        GruCell d = new GruCell();
        float[] h = new float[GruCell.H], out = new float[GruCell.H];
        d.beginWindow(h);
        d.windowStep(xs[0]);
        d.step(h, xs[0], out);
        boolean same = true;
        for (int j = 0; j < GruCell.H; j++) same &= Math.abs(h[j] - d.windowH()[j]) < 1e-6f;
        check("acting step equals the window step", same);
        System.out.println("GruCellCheck: all ok");
    }
}
