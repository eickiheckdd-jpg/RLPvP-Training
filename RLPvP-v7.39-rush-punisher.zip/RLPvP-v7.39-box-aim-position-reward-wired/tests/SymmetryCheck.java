package com.rlpvp;

import java.util.Random;

/**
 * Minecraft-free checks of the symmetric (left/right mirror) policy:
 *  - the observation mirror is an involution and flips exactly the lateral inputs
 *  - the policy is EQUIVARIANT: logits(mirror(obs)) == mirror(logits(obs)) for random weights
 *  - in a left/right symmetric situation the two strafe sides get identical logits and the yaw mean is 0
 *  - greedy strafe flips side when the situation is mirrored
 *  - the gradient routing (Symmetry.grads) is the exact adjoint of Symmetry.logits
 *  - a short training run through the symmetric passes keeps every weight finite and changes the weights
 */
public final class SymmetryCheck {
    static int fails = 0;

    static void check(String name, boolean ok) {
        System.out.println(name + ": " + (ok ? "ok" : "FAIL"));
        if (!ok) fails++;
    }

    static float[] mirrorLogits(float[] z) {
        float[] t = z.clone();
        t[Config.OFF_YAW] = -z[Config.OFF_YAW];
        t[Config.OFF_STRAFE] = z[Config.OFF_STRAFE + 2];
        t[Config.OFF_STRAFE + 2] = z[Config.OFF_STRAFE];
        return t;
    }

    static float[] randomObs(Random r) {
        float[] o = new float[Config.OBS_SIZE];
        for (int i = 0; i < o.length; i++) o[i] = (float) (r.nextDouble() * 2 - 1);
        return o;
    }

    public static void main(String[] args) {
        Random r = new Random(11);
        PpoAgent agent = new PpoAgent(3);
        for (int i = 0; i < agent.actor.w.length; i++) agent.actor.w[i] += (float) (r.nextGaussian() * 0.05); // make the weights non-trivial
        int[] pos = Symmetry.positions();
        System.out.println("symmetric policy on: " + Config.SYMMETRIC_POLICY + ", mirrored inputs: " + pos.length + " of " + Config.OBS_SIZE);

        // 1. observation mirror
        float[] o = randomObs(r), m = new float[o.length], mm = new float[o.length];
        Symmetry.obs(o, m);
        Symmetry.obs(m, mm);
        boolean inv = java.util.Arrays.equals(o, mm);
        int changed = 0;
        for (int i = 0; i < o.length; i++) if (o[i] != m[i]) changed++;
        check("observation mirror is an involution and flips exactly the lateral inputs (" + changed + ")", inv && changed == pos.length);

        // 2. equivariance of the logits
        double worst = 0;
        for (int n = 0; n < 100; n++) {
            float[] a = randomObs(r), am = new float[a.length];
            Symmetry.obs(a, am);
            float[] z = agent.logitsFor(a), zm = agent.logitsFor(am), exp = mirrorLogits(z);
            for (int i = 0; i < z.length; i++) worst = Math.max(worst, Math.abs(zm[i] - exp[i]));
        }
        check(String.format("logits(mirror(obs)) == mirror(logits(obs)), worst difference %.2e", worst), worst < 1e-4);

        // 3. a symmetric situation gives tied strafe sides and a zero yaw mean
        float[] sym = randomObs(r);
        for (int p : pos) sym[p] = 0f;
        float[] zs = agent.logitsFor(sym);
        check("symmetric situation: strafe left == strafe right and yaw mean == 0",
            Math.abs(zs[Config.OFF_STRAFE] - zs[Config.OFF_STRAFE + 2]) < 1e-6 && Math.abs(zs[Config.OFF_YAW]) < 1e-6);

        // 4. greedy strafe side flips with the mirror
        int flips = 0, tried = 0;
        for (int n = 0; n < 200; n++) {
            float[] a = randomObs(r), am = new float[a.length];
            Symmetry.obs(a, am);
            float[] z = agent.logitsFor(a);
            if (Math.abs(z[Config.OFF_STRAFE] - z[Config.OFF_STRAFE + 2]) < 1e-3) continue; // skip near ties
            int s1 = Math.round(agent.actGreedy(a)[3]);
            int s2 = Math.round(agent.actGreedy(am)[3]);
            tried++;
            if (s1 == 1 || s2 == 2 - s1) flips++; // "none" may win in both worlds
        }
        check("greedy strafe flips side in the mirrored situation (" + flips + "/" + tried + ")", tried > 20 && flips == tried);

        // 5. gradient routing is the adjoint of the logit combination
        double worstAdj = 0;
        for (int n = 0; n < 50; n++) {
            float[] z = new float[Config.ACTION_SIZE], zm = new float[Config.ACTION_SIZE], c = new float[Config.ACTION_SIZE];
            for (int i = 0; i < z.length; i++) { z[i] = (float) r.nextGaussian(); zm[i] = (float) r.nextGaussian(); c[i] = (float) r.nextGaussian(); }
            float[] out = new float[z.length], gA = new float[z.length], gB = new float[z.length];
            Symmetry.logits(z, zm, out);
            Symmetry.grads(c, gA, gB);
            double lhs = 0, rhs = 0;
            for (int i = 0; i < z.length; i++) { lhs += out[i] * c[i]; rhs += z[i] * gA[i] + zm[i] * gB[i]; }
            worstAdj = Math.max(worstAdj, Math.abs(lhs - rhs));
        }
        check(String.format("Symmetry.grads is the adjoint of Symmetry.logits (worst %.2e)", worstAdj), worstAdj < 1e-4);

        // 6. a short training run through the symmetric passes
        PpoAgent ag = new PpoAgent(4);
        float[] before = ag.actor.w.clone();
        PvpSim sim = new PvpSim(5, ag);
        for (int e = 0; e < 5; e++) {
            sim.mode = Curriculum.Opponent.WALK;
            sim.startEpisodeFor(Curriculum.Opponent.WALK);
            int guard = 0;
            while (sim.step(true, null) && guard++ < 320) ag.learnTick();
        }
        for (int i = 0; i < 3000; i++) ag.learnTick();
        boolean finite = true, moved = false;
        for (int i = 0; i < ag.actor.w.length; i++) {
            if (Float.isNaN(ag.actor.w[i]) || Float.isInfinite(ag.actor.w[i])) finite = false;
            if (ag.actor.w[i] != before[i]) moved = true;
        }
        check("training runs through both passes: weights finite (" + finite + ") and updated (" + moved + "), updates " + ag.updates, finite && moved);

        System.out.println(fails == 0 ? "ALL SYMMETRY CHECKS PASSED" : fails + " CHECK(S) FAILED");
        if (fails > 0) System.exit(1);
    }
}
