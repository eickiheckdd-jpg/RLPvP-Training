package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;

/** Verifies config-driven feature groups without changing observation dimensionality. */
public final class ObservationRegistryCheck {
    public static void main(String[] args) throws Exception {
        Path config = Files.createTempFile("rlpvp-observations", ".properties");
        Files.writeString(config, "observations.disable=own_health\nobservations.scale.own_velocity=0.25\n");
        System.setProperty("rlpvp.observations.path", config.toString());
        float[] frame = new float[Config.FRAME];
        frame[0] = 1.0f; frame[1] = 4.0f; frame[2] = -2.0f; frame[3] = 8.0f;
        int expected = frame.length;
        ObservationRegistry.apply(frame);
        if (frame.length != expected || frame[0] != 0.0f || frame[1] != 1.0f || frame[2] != -0.5f || frame[3] != 2.0f)
            throw new AssertionError("observation sidecar was not applied compatibly");
        Files.deleteIfExists(config);
        System.out.println("ObservationRegistryCheck OK");
    }
}
