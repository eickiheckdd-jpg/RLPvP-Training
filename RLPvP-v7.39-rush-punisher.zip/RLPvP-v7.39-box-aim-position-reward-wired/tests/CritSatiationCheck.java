package com.rlpvp;

/** Retired hit-identity rewards must remain zero; hit identity is now measured, not paid. */
public final class CritSatiationCheck {
    private static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }

    public static void main(String[] args) {
        check("crit bonus is retired", Reward.critSatiationBonus(true, true, false, 0, 0, 0) == 0.0);
        check("sprint bonus is retired", Reward.critSatiationBonus(true, false, true, 0, 0, 0) == 0.0);
        check("combined crit+sprint label cannot override the objective", Reward.critSatiationBonus(true, true, true, 4, 2, 2) == 0.0);
        check("legacy sprint-lane bonus is retired", Reward.sprintLane(1, 3, 0, true, 1, 1, 1, 1) == 0.0);
        check("reward identity scale defaults to telemetry-only", Config.TECH_REWARD_SCALE == 0.0);
        check("sprint lane opportunity is observable even without its former reward", Reward.sprintLaneEligible(1, 3, 0, true, 0));
        check("entropy remains unchanged before the late stage", Config.stageEntropyScale(7, 900_000, 600_000) == 1.0f);
        check("late-stage entropy taper begins at 1.0", Config.stageEntropyScale(8, 700_000, 700_000) == 1.0f);
        check("late-stage entropy linearly interpolates to configured 0.7 floor", Math.abs(Config.stageEntropyScale(8, 850_000, 700_000) - 0.85f) < 1e-6f);
        check("late-stage entropy reaches its configured floor after 300k ticks", Math.abs(Config.stageEntropyScale(9, 1_000_000, 700_000) - Config.LATE_STAGE_ENTROPY_SCALE) < 1e-6f);
    }
}
