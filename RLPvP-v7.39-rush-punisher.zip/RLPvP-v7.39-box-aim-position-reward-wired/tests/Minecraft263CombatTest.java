package com.rlpvp;

/** Formula-order and float-precision regression tests for the supported Minecraft 26.3 melee kit. */
public final class Minecraft263CombatTest {
    private static int checks;
    private static void ok(String name, boolean condition) {
        checks++;
        if (!condition) throw new AssertionError(name);
    }
    private static void near(String name, float actual, float expected, float epsilon) {
        checks++;
        if (!Float.isFinite(actual) || Math.abs(actual - expected) > epsilon)
            throw new AssertionError(name + ": expected " + expected + ", got " + actual);
    }
    private static void sameBits(String name, float actual, float expected) {
        checks++;
        if (Float.floatToIntBits(actual) != Float.floatToIntBits(expected))
            throw new AssertionError(name + ": expected exact float " + expected + ", got " + actual);
    }

    public static void main(String[] args) {
        // Player.getCurrentItemAttackStrengthDelay / getAttackStrengthScale.
        sameBits("diamond sword cooldown delay", Minecraft263Combat.attackCooldownDelay(1.6), 12.5F);
        sameBits("default attack speed cooldown", Minecraft263Combat.attackCooldownDelay(4.0), 5.0F);
        sameBits("attack charge is ticker plus partial tick divided by delay",
            Minecraft263Combat.attackStrengthScale(0, 0.5F, 12.5F), 0.04F);
        sameBits("attack charge clamps at one", Minecraft263Combat.attackStrengthScale(40, 0.5F, 12.5F), 1.0F);

        // Player.attack / baseDamageScaleFactor / critical multiplier order.
        float expectedHalf = 7.0F * (0.2F + 0.5F * 0.5F * 0.8F);
        sameBits("half-charge uses 0.2 + s*s*0.8", Minecraft263Combat.playerAttackDamage(7.0F, 0.5F,
            false, 7.0F, 0.0F), expectedHalf);
        sameBits("full normal sword hit", Minecraft263Combat.playerAttackDamage(7.0F, 1.0F,
            false, 7.0F, 0.0F), 7.0F);
        sameBits("full critical multiplies scaled base damage by 1.5", Minecraft263Combat.playerAttackDamage(7.0F,
            1.0F, true, 7.0F, 0.0F), 10.5F);
        float scaledCrit = 7.0F * (0.2F + 0.91F * 0.91F * 0.8F) * 1.5F;
        sameBits("crit uses the exact scaled base at strength 0.91", Minecraft263Combat.playerAttackDamage(7.0F,
            0.91F, true, 7.0F, 0.0F), scaledCrit);
        ok("full-strength attack is strictly greater than 0.9", 0.9F <= 0.9F && !(0.9F > 0.9F) && 0.9001F > 0.9F);

        ok("critical requires falling, airborne, unrestricted, non-sprinting living-target state",
            Minecraft263Combat.canCriticalAttack(true, 0.01F, false, false, false, false, false, true, false));
        ok("critical rejected while grounded", !Minecraft263Combat.canCriticalAttack(true, 1.0F, true,
            false, false, false, false, true, false));
        ok("critical rejected while sprinting", !Minecraft263Combat.canCriticalAttack(true, 1.0F, false,
            false, false, false, false, true, true));
        ok("critical rejected below full-strength threshold", !Minecraft263Combat.canCriticalAttack(false,
            1.0F, false, false, false, false, false, true, false));

        // CombatRules float math: armor/toughness, then Protection EPF.
        near("diamond armor stage", Minecraft263Combat.damageAfterArmorAbsorb(7.0F, 20.0F, 8.0F, false),
            1.89F, 1.0E-6F);
        near("Protection III x4 stage", Minecraft263Combat.damageAfterProtection(1.89F, 12.0F),
            0.9828F, 1.0E-6F);
        near("critical armor stage", Minecraft263Combat.damageAfterArmorAbsorb(10.5F, 20.0F, 8.0F, false),
            3.2025F, 1.0E-6F);
        near("armor bypass leaves incoming value unchanged",
            Minecraft263Combat.damageAfterArmorAbsorb(7.0F, 20.0F, 8.0F, true), 7.0F, 0.0F);
        near("Protection is capped at 20 EPF", Minecraft263Combat.damageAfterProtection(10.0F, 80.0F),
            10.0F * (1.0F - 20.0F / 25.0F), 0.0F);

        // LivingEntity.getDamageAfterMagicAbsorb() bypass ordering and Resistance.
        near("Resistance I reduces damage by 20 percent",
            Minecraft263Combat.applyResistance(10.0F, 0, false, false), 8.0F, 0.0F);
        near("Resistance II reduces damage by 40 percent",
            Minecraft263Combat.applyResistance(10.0F, 1, false, false), 6.0F, 0.0F);
        near("bypasses resistance tag skips Resistance only",
            Minecraft263Combat.applyResistance(10.0F, 0, false, true), 10.0F, 0.0F);
        near("bypasses effects tag skips Resistance and Protection",
            Minecraft263Combat.resolveDamage(10, 0, 0, 0, 20, 0,
                false, true, false, false).afterProtection, 10.0F, 0.0F);
        near("bypasses enchantments skips Protection but retains armor",
            Minecraft263Combat.resolveDamage(10, 0, 0, -1, 20, 0,
                false, false, false, true).afterProtection, 10.0F, 0.0F);

        Minecraft263Combat.DamageResult absorbed = Minecraft263Combat.resolveDamage(7.0F, 20.0F, 8.0F,
            -1, 12.0F, 0.5F, false, false, false, false);
        near("absorption is consumed after enchantment protection", absorbed.healthDamage,
            0.4828F, 1.0E-6F);
        near("absorption records the absorbed remainder", absorbed.absorbedDamage, 0.5F, 1.0E-6F);

        // LivingEntity.hurtServer compares raw incoming damage before mitigation.
        near("stronger hurt-window hit applies raw excess", Minecraft263Combat.invulnerableExcess(10.5F, 7.0F),
            3.5F, 0.0F);
        near("weaker hurt-window hit applies zero", Minecraft263Combat.invulnerableExcess(6.0F, 7.0F),
            0.0F, 0.0F);

        near("negative knockback resistance increases impulse", (float)Minecraft263Combat.knockbackPower(0.4, -0.5),
            0.6F, 1.0E-6F);
        near("positive knockback resistance reduces impulse", (float)Minecraft263Combat.knockbackPower(0.4, 0.4),
            0.24F, 1.0E-6F);
        near("full knockback resistance cancels impulse", (float)Minecraft263Combat.knockbackPower(0.4, 1.0),
            0.0F, 0.0F);

        // Integration through the training simulator's real strike path.
        PvpSim sim = new PvpSim(123L, new PpoAgent(123L));
        PvpSim.E attacker = new PvpSim.E();
        PvpSim.E defender = new PvpSim.E();
        attacker.kit = MinecraftRules.DIAMOND_PROT3;
        defender.kit = MinecraftRules.DIAMOND_PROT3;
        attacker.x = 0.0;
        defender.x = 1.0;
        int accepted = sim.strike(attacker, defender, 1.0F, false, false);
        ok("integrated normal hit accepted", accepted == 2);
        near("integrated exact kit health damage", 20.0F - defender.hp, 0.9828F, 2.0E-6F);

        // The server receives an attack packet later; it recalculates charge using its own ticker.
        PvpSim packetSim = new PvpSim(456L, new PpoAgent(456L));
        PvpSim.E packetAttacker = new PvpSim.E();
        PvpSim.E packetDefender = new PvpSim.E();
        packetAttacker.kit = MinecraftRules.DIAMOND_PROT3;
        packetDefender.kit = MinecraftRules.DIAMOND_PROT3;
        packetAttacker.x = 0.0;
        packetDefender.x = 1.0;
        packetAttacker.ticker = 0;          // client predicted a fresh swing
        packetAttacker.serverTicker = 4;    // server has not handled that attack packet yet
        packetSim.serverMe = packetAttacker;
        packetSim.serverBot = packetDefender;
        packetSim.processClientPacket(true, new PvpSim.AttackMessage(true));
        float serverStrength = Minecraft263Combat.attackStrengthScale(4, 0.5F, 12.5F);
        float packetRaw = Minecraft263Combat.playerAttackDamage(7.0F, serverStrength, false, 7.0F, 0.0F);
        near("server handles attack with server-side charge, not click-time client charge",
            20.0F - packetDefender.hp,
            (float)MinecraftRules.afterDefense(MinecraftRules.DIAMOND_PROT3, packetRaw), 2.0E-6F);
        ok("server cooldown ticker resets only when the packet is handled", packetAttacker.serverTicker == 0);

        System.out.println("Minecraft263CombatTest: " + checks + " passed");
    }
}
