package com.rlpvp;
public final class LeadDecisionCheck {
    public static void main(String[] a) {
        int f = 0;
        f += t("timeout with a clear HP lead counts for the gate", Config.leadDecision(true, 10, 3));
        f += t("timeout without engagement (dealt 2) does not", !Config.leadDecision(true, 2, 0));
        f += t("timeout while trading evenly does not", !Config.leadDecision(true, 10, 8));
        f += t("timeout while losing does not", !Config.leadDecision(true, 7, 14));
        f += t("a kill/loss is never a lead decision", !Config.leadDecision(false, 20, 0));
        System.out.println(f == 0 ? "LeadDecisionCheck OK" : "LeadDecisionCheck FAILED");
        if (f > 0) System.exit(1);
    }
    static int t(String n, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + n); return ok ? 0 : 1; }
}
