package com.rlpvp;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Random;

/** Focused regression checks for model transfer, parameter counting, and collapse statistics. */
public final class RlTests {
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) throws Exception {
        check(Net.paramCount(new int[]{377,128,128,14}) == 66702, "parameter count must include all biases");
        Random r = new Random(123);
        Net old = new Net(new int[]{4,3,3}, 0.2f, r);
        Net wide = new Net(new int[]{4,5,3}, 0.2f, new Random(456));
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) { old.write(out); }
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes.toByteArray()))) {
            wide.readTransferred(in, new int[]{4,3,3}, new int[]{0,1,2,3});
        }
        float[] x = {0.2f, -0.4f, 0.7f, 0.1f};
        float[] a = old.forward(x).clone(), b = wide.forward(x).clone();
        for (int i = 0; i < a.length; i++) check(Math.abs(a[i] - b[i]) < 1e-6, "widened net must preserve old output " + i);
        check(CollapseGuard.wilsonUpper(0, 10, 1.96) > 0.1, "10 zero-win episodes are too little evidence");
        check(CollapseGuard.wilsonUpper(0, 60, 1.96) < 0.1, "60 zero-win episodes should establish a low win rate");
        check(CollapseGuard.wilsonUpper(0, 10, Config.GUARD_WILSON_Z) > Config.GUARD_FAIL_WIN, "small sample confidence bound must prevent demotion");
        check(CollapseGuard.failedWindow(60, 0, 60, 0, 20), "large sample of losses/fleeing should classify collapse");
        Path dir = Files.createTempDirectory("rlpvp-roundtrip-"); Path state = dir.resolve("state.bin");
        PpoAgent source = new PpoAgent(789); float[] before = source.actor.w.clone(); source.totalTicks = 1234; source.save(state);
        PpoAgent loaded = PpoAgent.load(state, 790);
        check(loaded.totalTicks == 1234 && Arrays.equals(before, loaded.actor.w), "checkpoint roundtrip preserves tick count and actor weights");
        Files.deleteIfExists(state); Files.deleteIfExists(dir);
        System.out.println("RlTests: all checks passed");
    }
}
