package com.rlpvp;

/** Vanilla combat arithmetic (MinecraftRules). Pure Java. Written, not run in the session that added it. */
public final class MinecraftRulesCheck {
    static void check(String name, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + name); if (!ok) throw new AssertionError(name); }
    static boolean near(double a, double b, double e) { return Math.abs(a - b) <= e; }

    public static void main(String[] x) {
        MinecraftRules.Kit n = MinecraftRules.NAKED, d = MinecraftRules.DIAMOND;
        check("full-strength sword hit = 7", near(MinecraftRules.attackDamage(n, 1.0, false), 7.0, 1e-6));
        check("full-strength crit = 10.5", near(MinecraftRules.attackDamage(n, 1.0, true), 10.5, 1e-6));
        check("half-charged hit = 7 * (0.2 + 0.25 * 0.8) = 2.8", near(MinecraftRules.attackDamage(n, 0.5, false), 2.8, 1e-6));
        check("Sharpness V adds 3 at full strength and the crit multiplies only the base",
            near(MinecraftRules.attackDamage(MinecraftRules.NETHERITE, 1.0, false), 8 + 3.0, 1e-6) && near(MinecraftRules.attackDamage(MinecraftRules.NETHERITE, 1.0, true), 12 + 3.0, 1e-6));
        check("no armor: 7 stays 7", near(MinecraftRules.afterDefense(n, 7.0), 7.0, 1e-6));
        check("full diamond (20 armor, 8 toughness) turns 7 into about 1.89", near(MinecraftRules.afterDefense(d, 7.0), 7.0 * (1 - 18.25 / 25.0), 1e-6));
        check("armor never removes more than 80 %", MinecraftRules.afterDefense(new MinecraftRules.Kit("x", 7, 0, 20, 100, 0, -1, 0, 0f, 0), 1.0) >= 0.2 - 1e-6);
        check("Protection IV x4 (EPF 16) takes 64 % off what armor left", near(MinecraftRules.afterDefense(MinecraftRules.DIAMOND_PROT, 7.0), MinecraftRules.afterDefense(d, 7.0) * 0.36, 1e-6));
        check("a stronger hit inside the invulnerability window only adds the excess; a weaker one adds nothing",
            near(MinecraftRules.invulnerableExtra(10.5, 7.0), 3.5, 1e-6) && MinecraftRules.invulnerableExtra(5.0, 7.0) == 0.0);
        check("netherite knockback resistance 0.4 turns 0.4 into 0.24", near(MinecraftRules.knockbackStrength(0.4, MinecraftRules.NETHERITE), 0.24, 1e-6));
        check("kits by name / documented default", MinecraftRules.byName("diamond") == d && MinecraftRules.byName("nonsense") == MinecraftRules.DIAMOND_PROT3 && MinecraftRules.byName(null) == MinecraftRules.DIAMOND_PROT3);

        System.out.println("MinecraftRulesCheck: all ok");
    }
}
