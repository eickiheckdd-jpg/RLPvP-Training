package com.rlpvp;

import java.util.Arrays;

/** Integration tests proving that the local client and server player replicas are separated by packet travel time. */
public final class PvpSimNetworkTest {
    private static int passed;
    private static int failed;

    private static void check(boolean ok, String name) {
        if (ok) passed++;
        else { failed++; System.out.println("FAIL: " + name); }
    }

    public static void main(String[] args) {
        PvpSim sim = new PvpSim(7, new PpoAgent(8));
        sim.fixedLag = 2.0; // two ticks one-way, equivalent to 200 ms RTT
        sim.startEpisode();
        check(Math.abs(sim.meNetwork.profile.rttMs() - 200.0) < 1e-9, "fixed ping profile installed");
        double serverX = sim.serverMe.x;
        sim.me.x += 0.5;
        sim.sendClientMovement(sim.me, sim.meNetwork, sim.meSender, true);
        sim.tick = 2;
        sim.processServerPackets();
        check(Math.abs(sim.serverMe.x - serverX) < 1e-9, "server does not see client movement before arrival");
        sim.tick = 3;
        sim.processServerPackets();
        check(Math.abs(sim.serverMe.x - sim.me.x) < 1e-9, "server sees delayed movement packet after arrival");

        // Absolute player yaw is continuous across the +/-180 boundary in vanilla. The server replica must retain
        // the transmitted value rather than modulo-normalizing 183 back to -177.
        sim.startEpisode();
        sim.me.yaw = 179.0f; sim.serverMe.yaw = 179.0f; sim.meSender.reset(sim.me);
        sim.me.yaw = 183.0f;
        sim.sendClientMovement(sim.me, sim.meNetwork, sim.meSender, true);
        sim.tick = 3; sim.processServerPackets();
        check(Math.abs(sim.serverMe.yaw - 183.0f) < 1e-6, "server preserves continuous absolute yaw across the 180-degree boundary");

        sim.startEpisode();
        sim.serverMe.x = 0.0; sim.serverMe.y = 0.0; sim.serverMe.z = 0.0;
        sim.serverBot.x = 2.0; sim.serverBot.y = 0.0; sim.serverBot.z = 0.0;
        float startHp = sim.serverBot.hp;
        sim.meNetwork.clientToServer.send(0,
            new PvpSim.ClientPacket(true, new PvpSim.AttackMessage(true)), 4);
        sim.tick = 2; sim.processServerPackets();
        check(sim.serverBot.hp == startHp, "attack is not applied before C2S arrival");
        sim.tick = 3; sim.processServerPackets();
        check(sim.serverBot.hp < startHp, "server applies delayed attack authoritatively");
        check(sim.serverMe.serverTicker == 0, "server attack cooldown resets when accepted");

        sim.startEpisode();
        sim.me.fwd = 1; sim.me.sneak = true; sim.me.x += 0.5;
        sim.tick = 0;
        sim.sendClientMovement(sim.me, sim.meNetwork, sim.meSender, true);
        sim.sendClientTickEnd(sim.meNetwork, true);
        sim.tick = 2; sim.processServerPackets();
        check(sim.serverMe.clientInputMask == 0, "changed client input is not visible before C2S arrival");
        sim.tick = 3; sim.processServerPackets();
        check(sim.serverMe.clientInputMask == 17 && sim.serverMe.sneak, "changed player-input packet arrives before movement report");

        sim.startEpisode();
        long acceptedBeforeTickEndTest = sim.movementPackets;
        long duplicateBeforeTickEndTest = sim.movementDuplicateRejections;
        PvpSim.E firstMove = PvpSim.copy(sim.serverMe);
        firstMove.x += 0.1;
        sim.processClientPacket(true, new PvpSim.MoveMessage(firstMove, true, false));
        sim.processClientPacket(true, new PvpSim.ClientTickEndMessage());
        PvpSim.E secondMove = PvpSim.copy(sim.serverMe);
        secondMove.x += 0.1;
        sim.processClientPacket(true, new PvpSim.MoveMessage(secondMove, true, false));
        sim.processClientPacket(true, new PvpSim.ClientTickEndMessage());
        check(sim.movementDuplicateRejections == duplicateBeforeTickEndTest && sim.movementPackets == acceptedBeforeTickEndTest + 2,
            "ordered client-tick-end markers reset the server position-packet guard");

        sim.startEpisode();
        double initialRemoteX = sim.linkMe.other().x;
        PvpSim.E stableLinkLast = sim.linkMe.last;
        PvpSim.SnapshotMessage snapshotProbe = new PvpSim.SnapshotMessage(sim.serverBot, sim.serverMe);
        check(snapshotProbe.other.motionScratch.length == 0 && snapshotProbe.self.knockbackScratch.length == 0,
            "immutable network snapshots omit unused physics scratch arrays");
        sim.serverBot.x += 0.5;
        sim.tick = 0; sim.sendServerSnapshots();
        sim.tick = 2; sim.receiveClientboundPackets();
        check(Math.abs(sim.linkMe.tx - initialRemoteX) < 1e-9, "remote entity snapshot is not visible before S2C arrival");
        sim.tick = 3; sim.receiveClientboundPackets();
        check(Math.abs(sim.linkMe.tx - sim.serverBot.x) < 1e-9, "remote entity snapshot enters interpolation after S2C delivery");
        check(sim.linkMe.last == stableLinkLast, "link snapshot storage is reused after packet delivery");


        // Reused frame scratch must produce the exact same 51 raw observations as a fresh frame.
        PvpSim.E frameMe = new PvpSim.E(), frameOpp = new PvpSim.E();
        frameMe.x = 1.25; frameMe.y = 0.0; frameMe.z = -2.0; frameMe.yaw = 37.0f; frameMe.pitch = -11.0f;
        frameOpp.x = 2.75; frameOpp.y = 0.2; frameOpp.z = 1.0; frameOpp.yaw = -91.0f; frameOpp.pitch = 4.0f;
        frameOpp.sprint = true; frameOpp.swinging = true; frameOpp.hurtTime = 3;
        double[] frameMv = {0.03, -0.08, 0.11}, frameOv = {-0.02, 0.04, 0.07};
        float[] frameAction = new float[8], frameScratch = new float[Config.FRAME];
        frameAction[0] = 0.25f; frameAction[1] = -0.5f;
        float[] freshFrame = sim.frame(frameMe, frameOpp, frameMv, frameOv, 2, 3, frameAction, 4, 5, 0);
        float[] reusedFrame = sim.frameInto(frameMe, frameOpp, frameMv, frameOv, 2, 3, frameAction, 4, 5, 0, frameScratch);
        check(Arrays.equals(freshFrame, reusedFrame), "frameInto reproduces fresh-frame observation values exactly");
        frameOpp.x += 0.6; frameOpp.yaw += 21.0f; frameOpp.sprint = false; frameOpp.swinging = false;
        float[] secondFresh = sim.frame(frameMe, frameOpp, frameMv, frameOv, 7, 1, frameAction, 2, 8, 0);
        float[] secondReused = sim.frameInto(frameMe, frameOpp, frameMv, frameOv, 7, 1, frameAction, 2, 8, 0, frameScratch);
        check(Arrays.equals(secondFresh, secondReused), "frameInto fully resets reused scratch between frames");

        System.out.printf("PvpSimNetworkTest: %d passed, %d failed%n", passed, failed);
        if (failed != 0) System.exit(1);
    }
}
