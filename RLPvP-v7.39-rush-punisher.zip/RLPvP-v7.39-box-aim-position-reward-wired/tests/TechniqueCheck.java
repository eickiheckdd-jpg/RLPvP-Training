package com.rlpvp;

/** Checks that technique labels are not intrinsically rewarded in outcome-first mode. */
public final class TechniqueCheck {
    private static int failures;
    private static void check(String name, boolean ok, double got, double expected) {
        System.out.printf("%-58s %s (%.4f vs %.4f)%n", name, ok ? "ok" : "FAIL", got, expected);
        if (!ok) failures++;
    }

    public static void main(String[] args) {
        if (!Config.OUTCOME_ONLY_REWARDS || Config.techniqueRewardsEnabled()) throw new AssertionError("tests expect outcome-only, technique-reward-off mode");
        double plain = Reward.techBonus(true, false, false, 1, false, false, 1.0, false, false, false, 1.0);
        double crit = Reward.techBonus(true, true, false, 1, false, false, 1.0, true, false, false, 1.0);
        double sprint = Reward.techBonus(true, false, true, 4, true, false, 1.0, true, true, true, 1.0);
        check("critical-hit label adds no intrinsic reward", crit == plain, crit, plain);
        check("sprint/combo/reset labels add no intrinsic reward", sprint == plain, sprint, plain);

        TechniqueReward t = new TechniqueReward();
        TechniqueReward.In s = new TechniqueReward.In();
        s.techW = 1; s.realDealt = 7; s.hitCrit = true; s.hitSprint = true; s.dist = 2.8;
        double techniqueReward = t.tick(s);
        check("technique telemetry does not enter reward", techniqueReward == 0.0, techniqueReward, 0.0);
        check("swing-pattern bonus is disabled", t.onSwing(false, 1.0) == 0.0, t.onSwing(false, 1.0), 0.0);

        check("technique discovery defaults to diagnostic-only", Config.TECH_REWARD_SCALE == 0.0, Config.TECH_REWARD_SCALE, 0.0);
        check("crit and sprint base discovery weights are neutral", Config.TECH_CRIT == Config.TECH_SPRINT_HIT, Config.TECH_SPRINT_HIT, Config.TECH_CRIT);
        TechniqueDiscovery discovery = new TechniqueDiscovery();
        check("critical damage is never discounted by label", discovery.rewardDamage(1.25f, true, 1.0f) == 1.25f, discovery.rewardDamage(1.25f, true, 1.0f), 1.25);
        TechniqueDiscovery.In input = new TechniqueDiscovery.In();
        input.techW = 1.0; input.realDealt = 1.0f; input.newHit = true; input.hitCrit = true; input.hitGrounded = false; input.tick = 1;
        double discoveryTick = discovery.tick(input);
        input.realDealt = 0; input.newHit = false;
        for (int i = 2; i < 80; i++) { input.tick = i; discoveryTick += discovery.tick(input); }
        check("discovery records crit event but adds no bonus", discovery.summary().contains("crit") && Math.abs(discoveryTick) < 1e-9, discoveryTick, 0.0);

        double whiff = Reward.techBonus(false, false, false, 0, false, true, 1.0);
        double hit = Reward.techBonus(true, true, true, 3, true, false, 1.0);
        check("pointless whiff is telemetry-only and has no technique penalty", whiff == 0.0, whiff, 0.0);
        check("hit type alone receives no extra bonus", hit == 0.0, hit, 0.0);

        Curriculum.Weights w = new Curriculum.Weights(0, 0, 0, 0, 0, 0, 1, 1, 0);
        double goodTrade = Reward.tick(7, 0, 3, 3, 0, 0, 0, 0, w, 1, 1, 0, 0);
        double badTrade = Reward.tick(0, 7, 3, 3, 0, 0, 0, 0, w, 1, 1, 0, 0);
        check("outcome reward prefers dealing damage over taking it", goodTrade > badTrade, goodTrade, badTrade);

        CameraReward cameraWithCritWindow = new CameraReward();
        CameraReward cameraWithoutCritWindow = new CameraReward();
        double withCritWindow = 0, withoutCritWindow = 0;
        for (int i = 0; i < 20; i++) {
            withCritWindow += cameraWithCritWindow.tick(0, 0, true, true, true, 1, 8);
            withoutCritWindow += cameraWithoutCritWindow.tick(0, 0, true, false, false, 0, 8);
        }
        check("critical setup adds no intrinsic reward", Math.abs(withCritWindow - withoutCritWindow) < 1e-9,
            withCritWindow, withoutCritWindow);

        System.out.println(failures == 0 ? "TechniqueCheck: all ok" : "TechniqueCheck: " + failures + " FAILED");
        if (failures != 0) System.exit(1);
    }
}
