package com.rlpvp;

import java.nio.file.Path;

/** Creates a v7.37-shaped lag-stack checkpoint for the v7.38 compact observation migration test. */
public final class CompactCheckpointMigrationWrite {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("path required");
        if (Config.COMPACT_126 || GruCell.H != 8 || GruCell.X != 8)
            throw new AssertionError("run this fixture with compact=false and GRU 8x8");
        PpoAgent agent = new PpoAgent(1234L);
        int summaryOffset = ObsLayout.summaryOffset();
        int habitsOffset = summaryOffset + Config.SUMMARY_BASE + Config.V2_FEATURES + Config.SPRINT_FOLLOWUP_FEATURES;
        agent.actor.w[0] = 0.125f; // old current-frame feature 0
        agent.actor.w[1] = -0.25f; // old current-frame feature 1
        agent.actor.w[habitsOffset] = 0.75f; // old habit 0 -> compact input 115
        agent.actor.w[habitsOffset + 7] = -0.5f; // old habit 7 -> compact input 122
        agent.save(Path.of(args[0]));
        System.out.println("legacy checkpoint fixture created: obs=" + Config.OBS_SIZE + ", summary=" + Config.SUMMARY);
    }
}
