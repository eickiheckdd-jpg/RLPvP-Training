package com.rlpvp;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.util.Arrays;

/** Checks that frame-budgeted PPO slicing produces the same one-rollout parameter/Adam state. */
public final class PpoTimeSliceCheck {
    private static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }

    private static void collect(PpoAgent agent) {
        float[] obs = new float[Config.OBS_SIZE];
        float[] h = new float[GruCell.H];
        float[] x = new float[GruCell.X];
        for (int t = 0; t < Config.ROLLOUT; t++) {
            Arrays.fill(obs, 0f);
            for (int i = 0; i < obs.length; i++) obs[i] = (float) Math.sin((t + 1) * (i + 3) * 0.001);
            for (int i = 0; i < x.length; i++) x[i] = (float) Math.cos((t + 2) * (i + 1) * 0.017);
            for (int i = 0; i < h.length; i++) h[i] = (float) Math.sin((t + 4) * (i + 1) * 0.009);
            agent.noteMemory(h, x);
            agent.actTrain(obs);
            agent.addReward(Math.sin(t * 0.031) * 0.25);
        }
        agent.endEpisode(true, null);
    }

    private static byte[] gruState(PpoAgent agent) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) { agent.gruCell().writeTrainingState(out); }
        return bytes.toByteArray();
    }

    public static void main(String[] args) throws Exception {
        PpoAgent synchronous = new PpoAgent(0x739L);
        PpoAgent sliced = new PpoAgent(0x739L);
        collect(synchronous);
        collect(sliced);
        while (synchronous.learnerBusy()) synchronous.learnTick();

        long deadline = System.nanoTime() + 60_000_000_000L;
        while (sliced.learnerBusy() && System.nanoTime() < deadline) {
            sliced.learnTickBudgeted(500_000L);
            Thread.yield();
        }
        check("budgeted learner finishes the same rollout", !sliced.learnerBusy());
        check("actor weights are bit-identical", Arrays.equals(synchronous.exportWeights()[0], sliced.exportWeights()[0]));
        check("critic weights are bit-identical", Arrays.equals(synchronous.exportWeights()[1], sliced.exportWeights()[1]));
        check("GRU weights and Adam moments are bit-identical", Arrays.equals(gruState(synchronous), gruState(sliced)));
        check("update and skip counters match", synchronous.updates == sliced.updates && synchronous.skipped == sliced.skipped);
        System.out.println("PpoTimeSliceCheck: all checks passed");
    }
}
