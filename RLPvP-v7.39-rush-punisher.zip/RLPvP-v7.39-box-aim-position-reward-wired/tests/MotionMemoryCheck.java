package com.rlpvp;

/** Runs in a separate JVM with -Drlpvp.obsV2=true. */
public final class MotionMemoryCheck {
    public static void main(String[] args) {
        if (!Config.OBS_V2 || Config.SUMMARY != 30) throw new AssertionError("OBS_V2 must be enabled for this check");
        int oldSize = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, Config.SUMMARY_BASE);
        int[] map = ObsLayout.baseSummaryMap();
        if (map.length != oldSize) throw new AssertionError("old layout map size");
        for (int i = 0; i < Config.SUMMARY_BASE; i++)
            if (map[oldSize - Config.SUMMARY_BASE + i] != ObsLayout.summaryOffset() + i) throw new AssertionError("summary map " + i);
        MotionMemory m = new MotionMemory();
        float[] summary = new float[Config.SUMMARY], frame = new float[Config.FRAME], act = new float[7];
        frame[13] = 0.5f; frame[14] = 0.1f; frame[17] = -0.4f;
        act[2] = 1; act[3] = -1; act[6] = 1;
        m.tick(frame, act, 4.0); m.fill(summary);
        frame[13] = 0.2f; frame[17] = 0.4f;
        act[3] = 1;
        m.tick(frame, act, 3.5); m.fill(summary);
        for (int i = Config.SUMMARY_BASE; i < Config.SUMMARY; i++)
            if (Float.isNaN(summary[i]) || Float.isInfinite(summary[i])) throw new AssertionError("non-finite motion feature " + i);
        // target angular velocity = d(error) + own turn: a STATIONARY target seen while I turn must read 0, a moving one with no turn must read its motion
        MotionMemory v = new MotionMemory(); float[] sv = new float[Config.SUMMARY], fv = new float[Config.FRAME], av = new float[7];
        fv[13] = 20f / 180f; v.tick(fv, av, 4.0, 0, 0);
        fv[13] = 15f / 180f; v.tick(fv, av, 4.0, 5.0, 0); v.fill(sv);   // error fell by 5 because I turned 5 deg: the target did not move
        if (Math.abs(sv[Config.SUMMARY_BASE + 8]) > 1e-4) throw new AssertionError("stationary target must read zero velocity: " + sv[Config.SUMMARY_BASE + 8]);
        fv[13] = 18f / 180f; v.tick(fv, av, 4.0, 0, 0); v.fill(sv);     // error grew by 3 with no turn: the target moved 3 deg/tick
        if (Math.abs(sv[Config.SUMMARY_BASE + 8] - 0.3f) > 1e-3) throw new AssertionError("moving target velocity: " + sv[Config.SUMMARY_BASE + 8]);
        fv[13] = -179f / 180f; v.tick(fv, av, 4.0, 0, 0);
        fv[13] = 179f / 180f; v.tick(fv, av, 4.0, 0, 0); v.fill(sv);   // wraps across +-180: a 2 degree step, not 358
        if (Math.abs(sv[Config.SUMMARY_BASE + 8] + 0.2f) > 1e-3) throw new AssertionError("yaw wrap: " + sv[Config.SUMMARY_BASE + 8]);
        System.out.println("MotionMemoryCheck: OBS_V2 layout and finite features OK (obs=" + Config.OBS_SIZE + ")");
    }
}
