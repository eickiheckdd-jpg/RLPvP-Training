package com.rlpvp;

/** Reward decomposition and telemetry CSV regression checks. */
public final class RewardAuditCheck {
    static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }

    public static void main(String[] args) {
        Curriculum.Weights w = new Curriculum.Weights(1, 1, 1, 1, 1, 1, 1, 1, 1);
        Reward.Breakdown b = new Reward.Breakdown();
        double result = Reward.tick(3.0f, 1.0f, 2.8, 3.1, 0.02, 0.01, 1.0, 1.0, w,
            1.0, 1.0, -0.01, 0.1, 1.0, 1.0, b);
        check("base reward breakdown sums exactly to returned reward", Math.abs(result - b.total()) < 1e-9);

        Reward.Telemetry t = new Reward.Telemetry();
        t.setServerTelemetryAvailable(true);
        t.addBase(b);
        t.noteAction(true); t.noteAction(true); t.noteAction(false); t.noteAction(true);
        t.noteJumpStart();
        t.noteSwing(false, -0.1, true, false);
        t.noteServerAttack(true, false); t.noteServerResolvedHit(true, false, 1.25);
        t.noteServerAttack(false, true); t.noteServerResolvedHit(false, true, 0.9);
        t.noteSprintLaneOpportunity(true);
        t.noteClientLabelledHit(true, false, 1.25);
        t.noteClientLabelledHit(false, true, 0.9);
        t.addCamera(2.0); t.addCamera(-3.0); // ensure gross contributions survive net cancellation
        t.addPositionReward(new double[]{0.01, -0.02, 0.6, -0.25, -0.2});
        String header = Reward.Telemetry.csvHeader();
        String row = t.csvRow(100, 2);
        String[] h = header.split(",", -1), values = row.split(",", -1);
        check("reward audit CSV header and data have identical column counts", h.length == values.length);
        check("jump command rising edges are counted once per press", t.summaryAndReset().contains("jump cmd/start 2/1"));
        int pos = java.util.Arrays.asList(h).indexOf("positiveReward");
        int neg = java.util.Arrays.asList(h).indexOf("negativeRewardMagnitude");
        int total = java.util.Arrays.asList(h).indexOf("totalReward");
        check("gross positive/negative reward mass reconciles with net reward", Math.abs(
            Double.parseDouble(values[pos]) - Double.parseDouble(values[neg]) - Double.parseDouble(values[total])) < 1e-5);
        int critRate = java.util.Arrays.asList(h).indexOf("serverCritConversionRate");
        int sprintRate = java.util.Arrays.asList(h).indexOf("serverSprintKnockbackConversionRate");
        check("server-confirmed crit and sprint conversion rates are recorded", 
            Math.abs(Double.parseDouble(values[critRate]) - 1.0) < 1e-9 && Math.abs(Double.parseDouble(values[sprintRate]) - 1.0) < 1e-9);
        int band = java.util.Arrays.asList(h).indexOf("positionBandReward");
        int comboBreak = java.util.Arrays.asList(h).indexOf("positionComboBreakReward");
        check("position reward terms are present in the audit and sum to other reward",
            band >= 0 && comboBreak >= 0 && Math.abs(
                Double.parseDouble(values[band]) + Double.parseDouble(values[band + 1])
                + Double.parseDouble(values[band + 2]) + Double.parseDouble(values[band + 3])
                + Double.parseDouble(values[band + 4]) - 0.14) < 1e-6);

        TechniqueDiscovery td = new TechniqueDiscovery();
        TechniqueDiscovery.In in = new TechniqueDiscovery.In();
        in.techW = 1; in.tick = 1; in.newHit = true; in.realDealt = 1; in.hitSprint = true; in.hitGrounded = true;
        td.tick(in);
        in.newHit = false; in.realDealt = 0;
        for (int i = 2; i < 80; i++) { in.tick = i; td.tick(in); }
        String techHeader = TechniqueDiscovery.csvHeader();
        String techRow = td.csvRow(100, 9);
        check("per-technique exchange damage CSV is well formed", techHeader.split(",", -1).length == techRow.split(",", -1).length);
        check("technique payouts are disabled while outcome metrics remain",
            td.summary().contains("techRewards=OFF") && td.summary().contains("sprintHit=")
                && td.summary().contains("techniqueRewardPaid=0.0000"));
    }
}
