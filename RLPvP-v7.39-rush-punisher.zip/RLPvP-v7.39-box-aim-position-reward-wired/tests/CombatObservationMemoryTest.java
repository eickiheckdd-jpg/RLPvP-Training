package com.rlpvp;

/** Regression checks for the appended combat observations and semantic checkpoint block mapping. */
public final class CombatObservationMemoryTest {
    public static void main(String[] args) {
        check(Config.OBS_V2, "OBS_V2 should be enabled by default");
        check(Config.COMBAT_OBSERVATIONS, "combat observations should be enabled by default");
        check(Config.SUMMARY == Config.SUMMARY_BASE + Config.V2_FEATURES + Config.SPRINT_FOLLOWUP_FEATURES
                + Config.MEMORY_FEATURES + Config.KB_FEATURES + Config.COMBAT_FEATURES,
            "unexpected default summary size");
        check(Config.OBS_SIZE == ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, Config.SUMMARY),
            "observation size/layout mismatch");

        HitMemory hitMemory = new HitMemory();
        hitMemory.tick(0f, 0f, false, 0);
        hitMemory.swing(0, false); // one whiff, zero landed hits

        CombatObservationMemory memory = new CombatObservationMemory();
        float[] frame = new float[Config.FRAME];
        float[] lastAction = new float[7];
        frame[1] = 0.5f;  // forward velocity
        frame[5] = 1f;    // sprint active
        frame[16] = -0.5f; // opponent moving in the opposite direction
        lastAction[2] = 1f;
        lastAction[6] = 1f;

        memory.tick(frame, lastAction, 4.0, 0.5, true, hitMemory, 40, 0.35f, -0.6f);
        float[] summary = new float[Config.SUMMARY];
        memory.fillSummary(summary);
        int off = Config.SUMMARY - CombatObservationMemory.FEATURES;
        check(summary[off + CombatObservationMemory.CROSSHAIR_ON_BOX] == 1f, "crosshair hitbox flag lost");
        check(Math.abs(summary[off + CombatObservationMemory.CROSSHAIR_BOX_DX] - 0.35f) < 1e-6,
            "normalized target-box dx was not retained");
        check(Math.abs(summary[off + CombatObservationMemory.CROSSHAIR_BOX_DY] + 0.6f) < 1e-6,
            "normalized target-box dy was not retained");
        check(Math.abs(summary[off + CombatObservationMemory.INTERCEPT_ANGLE] + 1f) < 1e-6,
            "intercept cosine should be -1 for opposite forward motion");
        check(summary[off + CombatObservationMemory.MISS_TO_HIT_RATIO] == 1f, "miss-to-hit ratio should saturate at 1");
        check(summary[off + CombatObservationMemory.DISTANCE_DELTA] == 0f, "first distance delta should be neutral");
        check(summary[off + CombatObservationMemory.SPRINT_RESET_READY] == 1f,
            "sprint reset should start ready when there has been no recent hit");

        memory.noteAttack(false, true); // policy wanted to attack, but no click was queued
        memory.tick(frame, lastAction, 4.3, -0.5, false, hitMemory, 40);
        memory.fillSummary(summary);
        check(Math.abs(summary[off + CombatObservationMemory.DISTANCE_DELTA] - 0.5f) < 1e-6,
            "distance delta should be current minus previous, scaled by 0.6 blocks/tick");
        check(summary[off + CombatObservationMemory.ATTACK_DURING_IFRAME] == 0f,
            "suppressed policy attack intent must not be reported as an emitted iframe click");

        memory.noteAttack(true, true); // ActionApplier actually queued this click
        memory.tick(frame, lastAction, 4.3, -0.5, false, hitMemory, 40);
        memory.fillSummary(summary);
        check(summary[off + CombatObservationMemory.ATTACK_DURING_IFRAME] == 1f,
            "queued iframe click should be visible for one observation");
        memory.tick(frame, lastAction, 4.3, -0.5, false, hitMemory, 40);
        memory.fillSummary(summary);
        check(summary[off + CombatObservationMemory.ATTACK_DURING_IFRAME] == 0f,
            "iframe attack event should clear after one observation");

        // Knockback timing must occupy the block immediately before the new combat block,
        // never overwrite the appended combat observations.
        if (Config.KB_TIMING && Config.COMBAT_OBSERVATIONS) {
            java.util.Arrays.fill(summary, 0.25f);
            memory.fillSummary(summary);
            float[] combatTail = java.util.Arrays.copyOfRange(summary, off, summary.length);
            KbTiming kb = new KbTiming();
            kb.reset();
            kb.fill(summary);
            int kbOffset = Config.SUMMARY - Config.COMBAT_FEATURES - Config.KB_FEATURES;
            check(Math.abs(summary[kbOffset + 2] - 1.0f) < 1e-6,
                "knockback timing block is not at the expected pre-combat offset");
            check(java.util.Arrays.equals(combatTail,
                    java.util.Arrays.copyOfRange(summary, off, summary.length)),
                "knockback timing fill overwrote the appended combat observations");
        }

        // A prior default layout (no OBS_V2, with sprint follow-up, opponent memory and KB timing) must retain
        // the semantics of its old blocks even though OBS_V2 and combat observations now come on by default.
        int oldSummary = ObsLayout.summaryCount(false, true, true, true, false);
        int oldSize = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, oldSummary);
        int[] map = ObsLayout.summaryBlockMap(false, true, true, true, false);
        int oldOffset = oldSize - oldSummary;
        int newOffset = ObsLayout.summaryOffset();
        check(map[oldOffset] == newOffset, "base summary mapping failed");
        check(map[oldOffset + Config.SUMMARY_BASE] == newOffset + Config.SUMMARY_BASE + Config.V2_FEATURES,
            "sprint-followup block did not skip newly enabled OBS_V2 columns");
        check(map[oldOffset + Config.SUMMARY_BASE + Config.SPRINT_FOLLOWUP_FEATURES]
                == newOffset + Config.SUMMARY_BASE + Config.V2_FEATURES + Config.SPRINT_FOLLOWUP_FEATURES,
            "opponent-memory block mapping failed");
        check(map[oldOffset + Config.SUMMARY_BASE + Config.SPRINT_FOLLOWUP_FEATURES + Config.MEMORY_FEATURES]
                == newOffset + Config.SUMMARY_BASE + Config.V2_FEATURES + Config.SPRINT_FOLLOWUP_FEATURES + Config.MEMORY_FEATURES,
            "knockback-timing block mapping failed");

        int oldCombatSummary = ObsLayout.summaryCount(true, true, true, true, true, Config.COMBAT_FEATURES - 2);
        int oldCombatSize = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, oldCombatSummary);
        int[] oldCombatMap = ObsLayout.summaryBlockMap(true, true, true, true, true, Config.COMBAT_FEATURES - 2);
        int oldCombatOffset = oldCombatSize - oldCombatSummary + Config.SUMMARY_BASE + Config.V2_FEATURES
            + Config.SPRINT_FOLLOWUP_FEATURES + Config.MEMORY_FEATURES + Config.KB_FEATURES;
        int newCombatOffset = ObsLayout.summaryOffset() + Config.SUMMARY_BASE + Config.V2_FEATURES
            + Config.SPRINT_FOLLOWUP_FEATURES + Config.MEMORY_FEATURES + Config.KB_FEATURES;
        for (int i = 0; i < Config.COMBAT_FEATURES - 2; i++) {
            check(oldCombatMap[oldCombatOffset + i] == newCombatOffset + i,
                "old combat feature " + i + " did not keep its meaning");
        }

        System.out.println("CombatObservationMemoryTest: passed");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
