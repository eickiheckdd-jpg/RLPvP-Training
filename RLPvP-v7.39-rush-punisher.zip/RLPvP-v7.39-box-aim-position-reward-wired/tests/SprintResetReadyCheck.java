package com.rlpvp;

/** Checks sprint-reset readiness is observable only after hit-age threshold and a forward release. */
public final class SprintResetReadyCheck {
    private static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }

    private static float ready(CombatObservationMemory mem, float[] frame, float[] action, int sinceHit) {
        mem.tick(frame, action, 2.5, 0.5, true, new HitMemory(), sinceHit);
        float[] summary = new float[Config.SUMMARY];
        mem.fillSummary(summary);
        return summary[summary.length - Config.COMBAT_FEATURES + CombatObservationMemory.SPRINT_RESET_READY];
    }

    public static void main(String[] args) {
        float[] frame = new float[Config.FRAME];
        frame[5] = 1f; // sprinting
        float[] holdingForward = new float[] {0f, 0f, 1f, 0f, 0f, 0f, 1f};
        float[] releasedForward = new float[] {0f, 0f, 0f, 0f, 0f, 0f, 1f};
        CombatObservationMemory mem = new CombatObservationMemory();
        mem.reset();

        check("sprinting with no recent hit starts ready", ready(mem, frame, holdingForward, 40) == 1f);
        check("just-landed hit is not ready", ready(mem, frame, holdingForward, 0) == 0f);
        check("age threshold alone is not enough without forward release", ready(mem, frame, holdingForward, 11) == 0f);
        check("forward release after the threshold re-enables readiness", ready(mem, frame, releasedForward, 12) == 1f);

        frame[5] = 0f;
        check("must currently be sprinting", ready(mem, frame, holdingForward, 13) == 0f);
    }
}
