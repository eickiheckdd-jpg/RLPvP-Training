package com.rlpvp;

/** GlideCamera: same angles at the tick boundaries, continuous speed across ticks, exact for constant speed. Pure Java. */
public final class GlideCameraCheck {
    static void check(String name, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + name); if (!ok) throw new AssertionError(name); }

    public static void main(String[] x) {
        GlideCamera.reset();
        check("inactive before any tick", !GlideCamera.active());
        GlideCamera.push(3.0, 3.0, 0.5, 0.5);
        check("active after a tick", !Config.GLIDE_CAMERA || GlideCamera.active());
        GlideCamera.push(3.0, 3.0, 0.5, 0.5);
        double worst = 0;
        for (double t = 0; t <= 1.0001; t += 0.05) worst = Math.max(worst, Math.max(Math.abs(GlideCamera.yawOffset(t)), Math.abs(GlideCamera.pitchOffset(t))));
        check("constant speed: the curve IS the straight line (offset " + worst + ")", worst < 1e-9);
        java.util.Random r = new java.util.Random(7);
        for (int k = 0; k < 200; k++) {
            double d = r.nextGaussian() * 8, v0 = r.nextGaussian() * 8, v1 = r.nextGaussian() * 8;
            GlideCamera.push(d, v1, 0, 0);
            if (Math.abs(GlideCamera.yawOffset(0)) > 1e-9 || Math.abs(GlideCamera.yawOffset(1)) > 1e-9) throw new AssertionError("offset at the tick boundaries is not 0");
            double e = 1e-6;
            double slopeEnd = (GlideCamera.hermite(d, v0, v1, 1.0) - GlideCamera.hermite(d, v0, v1, 1.0 - e)) / e;
            double slopeStart = (GlideCamera.hermite(d, v0, v1, e) - GlideCamera.hermite(d, v0, v1, 0.0)) / e;
            if (Math.abs(slopeEnd - v1) > 1e-3 || Math.abs(slopeStart - v0) > 1e-3) throw new AssertionError("slopes at the ends are not the mouse velocities");
            if (Math.abs(GlideCamera.hermite(d, v0, v1, 0.0)) > 1e-12 || Math.abs(GlideCamera.hermite(d, v0, v1, 1.0) - d) > 1e-12) throw new AssertionError("endpoints moved");
        }
        check("200 random segments: boundary offset 0, end slopes = velocities, endpoints unchanged", true);
        GlideCamera.push(2.0, 1.0, 0, 0);
        GlideCamera.push(5.0, 4.0, 0, 0); // second segment starts with the first one's end velocity (1.0): no corner at the boundary
        double e = 1e-6;
        // offset slope = hermite slope - d (vanilla's own line has slope d), so the displayed slope at t=0 is yawOffset'(0) + d
        double shownStart = (GlideCamera.yawOffset(e) - GlideCamera.yawOffset(0)) / e + 5.0;
        check("speed is continuous across a tick boundary (start speed " + String.format("%.3f", shownStart) + " = previous end speed 1.0)", Math.abs(shownStart - 1.0) < 1e-3);
        GlideCamera.reset();
        check("inactive after reset", !GlideCamera.active() && GlideCamera.yawOffset(0.5) == 0.0);
        GlideCamera.push(Double.NaN, 0, 0, 0);
        check("NaN input never activates the glide", !GlideCamera.active());
        GlideCamera.reset();
        System.out.println("GlideCameraCheck: all ok");
    }
}
