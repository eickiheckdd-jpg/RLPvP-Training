package com.rlpvp;

import java.util.Random;

/** Mouse-effort response curve (CameraMap): shape, inverse and exploration std limits. No simulation, no training. */
public final class CameraMapCheck {
    static int fails;

    static void check(String name, boolean ok) {
        System.out.println((ok ? "ok   " : "FAIL ") + name);
        if (!ok) fails++;
    }

    public static void main(String[] args) {
        float p = Config.CAMERA_EXPONENT, mix = Config.CAMERA_LINEAR_MIX;
        System.out.println("exponent " + p + ", linear mix " + mix);
        check("apply(0) = 0 and apply(+-1) = +-1", CameraMap.apply(0f) == 0f && Math.abs(CameraMap.apply(1f) - 1f) < 1e-6 && Math.abs(CameraMap.apply(-1f) + 1f) < 1e-6);
        check("odd: apply(-a) = -apply(a) (mirror training stays valid)", Math.abs(CameraMap.apply(-0.37f) + CameraMap.apply(0.37f)) < 1e-7);
        check("input beyond +-1 is clamped", CameraMap.apply(3f) == CameraMap.apply(1f) && CameraMap.apply(-9f) == CameraMap.apply(-1f));
        boolean mono = true;
        for (float a = 0f; a < 0.999f; a += 0.001f) mono &= CameraMap.apply(a + 0.001f) >= CameraMap.apply(a);
        check("monotone increasing", mono);
        float worst = 0f;
        for (float y = -1f; y <= 1f; y += 0.01f) worst = Math.max(worst, Math.abs(CameraMap.apply(CameraMap.inverse(y)) - y));
        check("inverse(apply) round trip (max error " + worst + ")", worst < 1e-5f);
        if (p >= 2.5f && mix == 0f) {
            check("cubic: a = 0.5 applies 12.5% of maximum hand effort", Math.abs(CameraMap.apply(0.5f) - 0.125f) < 1e-6);
            check("cubic: a = 0.1 applies 0.1% of maximum hand effort", Math.abs(CameraMap.apply(0.1f) * Config.YAW_SCALE - 0.045f) < 1e-4);
        }
        // std limits: start effort noise same as linear mapping, largest effort noise judged at 2 sigma (cubic) / 1 sigma (linear)
        float sInit = (float) Math.exp(Math.log(Config.LOOK_STD_INIT)), sMax = (float) Math.exp(Config.LOOK_LOGSTD_MAX), sMin = (float) Math.exp(Config.LOOK_LOGSTD_MIN);
        check("std limits ordered", sMin < sInit && sInit < sMax);
        check("linear curve reproduces the old std constants", Math.abs(CameraMap.stdForMeanAbs(0.01f, 1f, 0f) - 0.01f) < 2e-4f && Math.abs(CameraMap.stdForTail(0.15f, 1f, 0f) - 0.15f) < 1e-5f && CameraMap.apply(0.3f, 1f, 0f) == 0.3f);
        float tailSigmas = p > 1f ? 2f : 1f;
        check("largest noise: applied effort at " + tailSigmas + " sigma = 0.15 of maximum hand effort", Math.abs(CameraMap.apply(tailSigmas * sMax) - 0.15f) < 2e-3f);

        Random r = new Random(1);
        int n = 200000;
        for (int pass = 0; pass < 3; pass++) {
            double[] sig = {0.01 / 0.01 * 0.01, sInit, sMax};
            String[] label = {"linear, std 0.01 (old start)", "configured curve at the start std", "configured curve at the LARGEST std"};
            double sum = 0; int big = 0, flick = 0;
            float[] t = new float[n];
            for (int i = 0; i < n; i++) {
                double eps = r.nextGaussian();
                float v = pass == 0 ? (float) (Math.abs(0.01 * eps) * Config.YAW_SCALE) : Math.abs(CameraMap.apply((float) (sig[pass] * eps))) * Config.YAW_SCALE;
                t[i] = v; sum += v; if (v > 5f) big++; if (v > 20f) flick++;
            }
            java.util.Arrays.sort(t);
            System.out.printf("%-38s yaw effort: mean %.2f scale-equivalent units, p99 %.2f, above 5 units %.2f%% of ticks, above 20 units %.3f%%%n", label[pass], sum / n, t[(int) (n * 0.99)], 100.0 * big / n, 100.0 * flick / n);
            if (pass == 1) check("start jitter mean within 0.7x-1.6x of the linear start", sum / n > 0.7 * 0.8 * 0.01 * Config.YAW_SCALE && sum / n < 1.6 * 0.8 * 0.01 * Config.YAW_SCALE);
            if (pass == 2) check("effort samples above 20 scale-equivalent units stay below 1% even at the largest std", 100.0 * flick / n < 1.0);
        }

        // Mapping sanity: applied effort value 0.1 / yaw scale, linear vs configured
        float rawLinear = 0.1f / Config.YAW_SCALE, rawMapped = CameraMap.inverse(0.1f / Config.YAW_SCALE);
        System.out.printf("raw output for an applied effort of 0.1 / yaw scale: linear %.4f, configured %.4f (%.0fx difference)%n", rawLinear, rawMapped, rawMapped / rawLinear);
        System.out.println(fails == 0 ? "ALL OK" : fails + " FAILED");
        if (fails > 0) System.exit(1);
    }
}
