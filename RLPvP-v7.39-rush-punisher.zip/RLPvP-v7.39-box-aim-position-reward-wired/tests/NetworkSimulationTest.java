package com.rlpvp;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Deterministic tests for RTT sampling, tick delivery, FIFO and reliable TCP-style retransmission. */
public final class NetworkSimulationTest {
    private static int passed;
    private static int failed;

    private static void check(boolean ok, String name) {
        if (ok) passed++;
        else { failed++; System.out.println("FAIL: " + name); }
    }

    public static void main(String[] args) {
        NetworkSimulation.Profile offline = NetworkSimulation.sample(new Random(1), true, 0.0, null);
        check(offline.rttMs() == 0.0 && offline.clientToServerMs() == 0.0, "stage zero is offline");

        NetworkSimulation.Profile fixed = NetworkSimulation.sample(new Random(2), true, 1.0, 200.0);
        check(fixed.rttMs() == 200.0, "fixed RTT retained");
        check(fixed.clientToServerMs() == 100.0 && fixed.serverToClientMs() == 100.0, "fixed RTT splits evenly");
        check(fixed.jitterMs() == 0.0 && fixed.tcpLossRate() == 0.0, "fixed-lag evaluation deterministic");

        boolean inRange = true, split = true, asymmetry = false;
        for (int i = 0; i < 500; i++) {
            NetworkSimulation.Profile p = NetworkSimulation.sample(new Random(i), true, 1.25, null);
            if (p.rttMs() != 0.0) {
                inRange &= p.rttMs() >= Config.LAG_MIN_MS && p.rttMs() <= Config.LAG_MAX_MS;
                split &= Math.abs(p.rttMs() - p.clientToServerMs() - p.serverToClientMs()) < 1e-9;
                asymmetry |= Math.abs(p.clientToServerMs() - p.serverToClientMs()) > 0.01;
            }
        }
        check(inRange, "sampled RTT remains inside configured range");
        check(split, "C2S plus S2C equals RTT");
        check(asymmetry, "sampled connections include asymmetric paths");

        NetworkSimulation.Channel channel = new NetworkSimulation.Channel(new Random(4), 10.0, 0.0, 0.0, 200.0, 10.0);
        channel.send(0, "packet", 4);
        check(channel.drain(0).isEmpty(), "packet not delivered before one-way delay");
        List<NetworkSimulation.Delivery> arrived = channel.drain(1);
        check(arrived.size() == 1 && "packet".equals(arrived.get(0).payload), "packet arrives at tick boundary");
        check(Math.abs(arrived.get(0).oneWayDelayMs() - 10.0352) < 0.02, "packet includes framing serialization and propagation");

        NetworkSimulation.Channel lossy = new NetworkSimulation.Channel(new Random(5), 0.0, 0.0, 1.0, 200.0, 10.0);
        lossy.send(0, "first", 10);
        lossy.send(1, "second", 10);
        check(lossy.drain(4).isEmpty(), "lost TCP segment is held for retransmission");
        List<NetworkSimulation.Delivery> recovered = lossy.drain(6);
        check(recovered.size() == 2, "TCP packets retransmit instead of disappearing");
        check("first".equals(recovered.get(0).payload) && "second".equals(recovered.get(1).payload), "TCP stream preserves FIFO order");
        check(recovered.get(0).retransmitted && recovered.get(1).retransmitted, "retransmission events counted");
        check(lossy.retransmissions() == 2, "retransmission counter");

        // The hot-loop append API must produce the same ordered deliveries/counters as drain().
        NetworkSimulation.Channel legacyDrain = new NetworkSimulation.Channel(new Random(91), 35.0, 2.0, 0.20, 200.0, 10.0);
        NetworkSimulation.Channel intoDrain = new NetworkSimulation.Channel(new Random(91), 35.0, 2.0, 0.20, 200.0, 10.0);
        for (int i = 0; i < 40; i++) {
            long at = i / 3;
            String payload = "p" + i;
            legacyDrain.send(at, payload, 12 + i);
            intoDrain.send(at, payload, 12 + i);
        }
        List<NetworkSimulation.Delivery> expectedFirst = legacyDrain.drain(10);
        List<NetworkSimulation.Delivery> actualFirst = new ArrayList<>();
        Object sentinel = new Object(); actualFirst.add(new NetworkSimulation.Delivery(sentinel, 0, 0, -1, false));
        intoDrain.drainInto(10, actualFirst);
        check(actualFirst.size() == expectedFirst.size() + 1 && actualFirst.get(0).payload == sentinel,
            "drainInto appends without clearing caller-owned entries");
        boolean sameFirst = actualFirst.size() == expectedFirst.size() + 1;
        for (int i = 0; sameFirst && i < expectedFirst.size(); i++) {
            NetworkSimulation.Delivery a = expectedFirst.get(i), b = actualFirst.get(i + 1);
            sameFirst = a.sequence == b.sequence && a.payload.equals(b.payload)
                && a.arrivedAtMs == b.arrivedAtMs && a.sentAtMs == b.sentAtMs
                && a.retransmitted == b.retransmitted;
        }
        check(sameFirst, "drainInto matches historical delivery order and packet metadata");
        List<NetworkSimulation.Delivery> expectedLater = legacyDrain.drain(100);
        int oldSize = actualFirst.size();
        intoDrain.drainInto(100, actualFirst);
        boolean sameLater = actualFirst.size() == oldSize + expectedLater.size();
        for (int i = 0; sameLater && i < expectedLater.size(); i++) {
            NetworkSimulation.Delivery a = expectedLater.get(i), b = actualFirst.get(oldSize + i);
            sameLater = a.sequence == b.sequence && a.payload.equals(b.payload)
                && a.arrivedAtMs == b.arrivedAtMs && a.sentAtMs == b.sentAtMs
                && a.retransmitted == b.retransmitted;
        }
        check(sameLater, "drainInto matches later drains after prior packets have been consumed");
        check(legacyDrain.retransmissions() == intoDrain.retransmissions()
            && legacyDrain.sentPackets() == intoDrain.sentPackets()
            && legacyDrain.pendingPackets() == intoDrain.pendingPackets(),
            "drainInto preserves channel counters and pending queue state");

        System.out.printf("NetworkSimulationTest: %d passed, %d failed%n", passed, failed);
        if (failed != 0) System.exit(1);
    }
}
