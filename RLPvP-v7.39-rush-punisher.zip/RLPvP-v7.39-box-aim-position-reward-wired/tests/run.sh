#!/bin/sh
# Minecraft-free checks (needs a JDK 21): memory / layout, plus migration of old saves.
# usage: tests/run.sh [OLD_CHECKOUT_42 [OLD_CHECKOUT_48]]   (old checkouts = earlier versions of this project, to prove saves migrate)
set -e
# Keep the pre-existing regression suite on its historical 8x8 GRU/lag-stack contract.
export JAVA_TOOL_OPTIONS="${JAVA_TOOL_OPTIONS:-} -Drlpvp.obs126=false -Drlpvp.gruHidden=8 -Drlpvp.gruInput=8"
cd "$(dirname "$0")/.."
S=src/main/java/com/rlpvp
OUT=$(mktemp -d)
javac -d "$OUT" $S/Net.java $S/Symmetry.java $S/ConsequenceModel.java $S/PpoAgent.java $S/SituationalStateInterpreter.java $S/OpponentBehaviorModel.java $S/EventDrivenCombatMemory.java $S/TacticalDecisionEngine.java $S/CounterfactualActionEvaluator.java $S/ReactiveCombatController.java $S/CombatIntelligenceSuite.java $S/SituationalCombatStack.java $S/GruCell.java $S/OpponentMemory.java $S/KbTiming.java $S/Config.java $S/TechniqueDiscovery.java $S/TechniqueOpportunityAudit.java $S/SpamGuard.java $S/Minecraft263Combat.java $S/Minecraft263Trig.java $S/Minecraft26Physics.java $S/MinecraftRules.java $S/CameraMap.java $S/CameraDynamics.java $S/AimBrake.java $S/AimJitterSuppressor.java $S/AimInputFilter.java $S/GameplayRotation.java $S/GlideCamera.java $S/GlideBridge.java $S/EpisodeOutcome.java $S/Reward.java $S/Curriculum.java $S/OpponentLeague.java $S/RewardTuning.java $S/ObservationRegistry.java $S/ActionMask.java $S/StrafeAction.java $S/ComboDefenseTracker.java $S/CombatPositionReward.java $S/AimGeometry.java $S/ObsStack.java $S/ObsLayout.java $S/HitMemory.java $S/MotionMemory.java $S/CombatObservationMemory.java $S/SprintHitFollowupMemory.java $S/FrozenPolicy.java $S/CameraReward.java $S/CollapseGuard.java $S/TechniqueReward.java $S/BotAI.java $S/BotDifficulty.java $S/ModelInfo.java $S/NetworkSimulation.java sim/com/rlpvp/PvpSim.java sim/com/rlpvp/ChampionEvaluator.java tests/NetworkSimulationTest.java tests/OpponentLeagueCheck.java tests/Stage9LeagueCheck.java tests/CameraCandidateCheck.java tests/ObservationRegistryCheck.java tests/PvpSimNetworkTest.java tests/RlTests.java tests/MotionMemoryCheck.java tests/SprintHitFollowupMemoryTest.java tests/OutcomeRegressionTest.java tests/BotAICheck.java tests/MemoryCheck.java tests/CameraMapCheck.java tests/CameraDynamicsCheck.java tests/AimInputFilterCheck.java tests/MigRead.java tests/TechniqueCheck.java tests/TechniqueOpportunityAuditCheck.java tests/TechniqueRewardPolicyCheck.java tests/RewardAuditCheck.java tests/CombatPositionRewardCheck.java tests/AimGeometryCheck.java tests/ConsequenceModelCheck.java tests/GuardCheck.java tests/CheckpointCompatCheck.java tests/CurriculumGateCheck.java tests/MinecraftRulesCheck.java tests/SpamGuardCheck.java tests/PpoTimeSliceCheck.java tests/JumpResetCheck.java tests/StyleCheck.java tests/GruCellCheck.java tests/GlideCameraCheck.java sim/com/rlpvp/GlideCameraSmoothingCheck.java tests/SneakMigrationCheck.java tests/AimBrakeCheck.java tests/GameplayRotationCheck.java tests/MoveSpamCheck.java tests/NetCapacityCheck.java tests/CritSatiationCheck.java tests/SprintResetReadyCheck.java tests/CombatObservationMemoryTest.java tests/SituationalCombatStackCheck.java tests/OpponentAdaptationCheck.java tests/EventDrivenCombatMemoryCheck.java tests/Minecraft26PhysicsTest.java tests/Minecraft263CombatTest.java tests/CameraTrackingRewardCheck.java tests/AttackGateGeometryCheck.java tests/JumpStartTelemetryCheck.java tests/CompactCheckpointMigrationWrite.java tests/CompactObservation126Check.java tests/Compact126CheckpointMigrationCheck.java tests/RewardTuningCheck.java tests/ConsequenceStateCopyCheck.java tests/StrafeActionCheck.java tests/ComboDefenseTrackerCheck.java tests/HoldStrafePolicyCheck.java
java -cp "$OUT" com.rlpvp.NetworkSimulationTest
java -cp "$OUT" com.rlpvp.OpponentLeagueCheck
java -cp "$OUT" com.rlpvp.Stage9LeagueCheck
java -cp "$OUT" com.rlpvp.CameraCandidateCheck
java -cp "$OUT" com.rlpvp.ObservationRegistryCheck
java -cp "$OUT" com.rlpvp.PvpSimNetworkTest
java -cp "$OUT" com.rlpvp.RlTests
java -cp "$OUT" com.rlpvp.StrafeActionCheck
java -cp "$OUT" com.rlpvp.ComboDefenseTrackerCheck
java -cp "$OUT" com.rlpvp.HoldStrafePolicyCheck
java -Drlpvp.obsV2=true -Drlpvp.sprintFollowup=false -Drlpvp.memory=false -Drlpvp.kbTiming=false -Drlpvp.combatObs=false -cp "$OUT" com.rlpvp.MotionMemoryCheck
java -cp "$OUT" com.rlpvp.SprintHitFollowupMemoryTest
java -cp "$OUT" com.rlpvp.OutcomeRegressionTest
java -cp "$OUT" com.rlpvp.CameraMapCheck
java -cp "$OUT" com.rlpvp.CameraDynamicsCheck
java -cp "$OUT" com.rlpvp.AimInputFilterCheck
java -cp "$OUT" com.rlpvp.MemoryCheck
java -cp "$OUT" com.rlpvp.TechniqueCheck
java -cp "$OUT" com.rlpvp.TechniqueOpportunityAuditCheck
java -cp "$OUT" com.rlpvp.TechniqueRewardPolicyCheck
java -cp "$OUT" com.rlpvp.RewardTuningCheck
java -cp "$OUT" com.rlpvp.RewardAuditCheck
java -cp "$OUT" com.rlpvp.CombatPositionRewardCheck
java -cp "$OUT" com.rlpvp.AimGeometryCheck
java -cp "$OUT" com.rlpvp.ConsequenceStateCopyCheck
java -cp "$OUT" com.rlpvp.ConsequenceModelCheck
java -cp "$OUT" com.rlpvp.GuardCheck
java -cp "$OUT" com.rlpvp.CurriculumGateCheck
java -cp "$OUT" com.rlpvp.MinecraftRulesCheck
java -cp "$OUT" com.rlpvp.SpamGuardCheck
java -cp "$OUT" com.rlpvp.MoveSpamCheck
java -cp "$OUT" com.rlpvp.PpoTimeSliceCheck
java -cp "$OUT" com.rlpvp.JumpResetCheck
java -cp "$OUT" com.rlpvp.StyleCheck
java -cp "$OUT" com.rlpvp.GruCellCheck
java -cp "$OUT" com.rlpvp.GlideCameraCheck
java -cp "$OUT" com.rlpvp.GlideCameraSmoothingCheck
[ -f training-results-v7.2/checkpoint-300000.bin ] && java -cp "$OUT" com.rlpvp.SneakMigrationCheck training-results-v7.2/checkpoint-300000.bin
java -cp "$OUT" com.rlpvp.AimBrakeCheck
java -cp "$OUT" com.rlpvp.GameplayRotationCheck
java -cp "$OUT" com.rlpvp.MoveSpamCheck
java -cp "$OUT" com.rlpvp.NetCapacityCheck
java -cp "$OUT" com.rlpvp.SituationalCombatStackCheck
java -cp "$OUT" com.rlpvp.OpponentAdaptationCheck
java -cp "$OUT" com.rlpvp.EventDrivenCombatMemoryCheck
java -cp "$OUT" com.rlpvp.CritSatiationCheck
java -cp "$OUT" com.rlpvp.SprintResetReadyCheck
java -cp "$OUT" com.rlpvp.CombatObservationMemoryTest
java -cp "$OUT" com.rlpvp.Minecraft26PhysicsTest
# End-to-end checkpoint transfer: create a small base checkpoint, then widen it without changing the initial policy function.
java -Drlpvp.hidden=128,128 -cp "$OUT" com.rlpvp.PvpSim 5 "$OUT/base-transfer.bin" 77 - -
java -Drlpvp.hidden=256,256 -Drlpvp.transferFrom=128,128 -cp "$OUT" com.rlpvp.PvpSim 5 "$OUT/wide-transfer.bin" 77 "$OUT/base-transfer.bin" -
for M in models/*.bin; do [ -f "$M" ] && java -cp "$OUT" com.rlpvp.CheckpointCompatCheck "$M"; done
java -cp "$OUT" com.rlpvp.BotAICheck
migrate() { # $1 = old checkout, $2 = its frame size
  OLD=$(mktemp -d); O="$1/src/main/java/com/rlpvp"
  javac -d "$OLD" $O/Net.java $O/PpoAgent.java $O/Config.java $O/Reward.java $O/Curriculum.java $O/ActionMask.java $O/ObsStack.java $O/FrozenPolicy.java tests/MigWrite.java
  java -cp "$OLD" com.rlpvp.MigWrite "$OLD/state.bin" "$OLD/ref.bin"
  java -cp "$OUT" com.rlpvp.MigRead "$OLD/state.bin" "$OLD/ref.bin" "$2"
}
[ -n "$1" ] && migrate "$1" 42
[ -n "$2" ] && migrate "$2" 48
true
java -cp "$OUT" com.rlpvp.CameraTrackingRewardCheck
java -cp "$OUT" com.rlpvp.AttackGateGeometryCheck
java -Xmx1g -cp "$OUT" com.rlpvp.JumpStartTelemetryCheck 6000

# Create an actual historical lag-stack checkpoint with the old 8x8 GRU, then load/migrate it in the new 128-input runtime.
java -cp "$OUT" com.rlpvp.CompactCheckpointMigrationWrite "$OUT/legacy-v737.bin"
java -Drlpvp.obs126=true -Drlpvp.gruHidden=64 -Drlpvp.gruInput=18 -cp "$OUT" com.rlpvp.CompactObservation126Check "$OUT/legacy-v737.bin"
java -Drlpvp.obs126=true -Drlpvp.gruHidden=64 -Drlpvp.gruInput=18 -cp "$OUT" com.rlpvp.Compact126CheckpointMigrationCheck
