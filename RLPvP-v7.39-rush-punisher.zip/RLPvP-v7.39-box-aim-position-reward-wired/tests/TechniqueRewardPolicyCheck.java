package com.rlpvp;

import java.util.HashMap;
import java.util.Map;

/** Verifies named techniques remain learnable/observable but cannot add or subtract PPO reward. */
public final class TechniqueRewardPolicyCheck {
    private static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }

    private static void quietTick(TechniqueDiscovery.In s, int tick) {
        s.tick = tick;
        s.realDealt = 0f;
        s.taken = 0f;
        s.newHit = false;
        s.hitCrit = false;
        s.hitSprint = false;
        s.hitPunish = false;
        s.oppSwingStart = false;
        s.jumpStart = false;
        s.airborne = false;
        s.hitGrounded = true;
        s.hitDist = 3.0;
        s.hitEnemyCharge = 0.4;
        s.fwd = 1;
        s.sprintKey = true;
        s.dist = 3.0;
        s.inTheirReach = true;
        s.enemyFacing = 1.0;
        s.mySpeed = 0.3;
    }

    public static void main(String[] args) {
        check("named technique rewards are hard-disabled", !Config.techniqueRewardsEnabled());
        check("near-miss pseudo-damage is also disabled in every stage", Reward.softHp(7.0) == 0.0f && Reward.softCapHp(7.0) == 0.0f);
        check("misses carry no separate fixed penalty", Config.MISS_COST == 0.0f && Config.WHIFF_PENALTY == 0.0f);

        check("crit/sprint/combo/first-hit/punish labels add no bonus",
            Reward.techBonus(true, true, true, 5, true, false, 1.0, true, true, true, 1.0) == 0.0);
        check("pointless and repeated whiffs are not assigned a technique penalty",
            Reward.techBonus(false, false, false, 0, false, true, 1.0) == 0.0);
        check("orbit/circle-strafe identity reward is retired",
            Reward.orbit(1.0, 0.0, 0.0, 1.0, 0.0, 2.5, false, 1.0, 1.0) == 0.0);

        Curriculum.Weights zero = new Curriculum.Weights(0, 0, 0, 0, 0, 0, 0, 0, 0);
        Reward.Breakdown breakdown = new Reward.Breakdown();
        double arbitraryLegacyTechniqueInput = Reward.tick(0f, 0f, 2.0, 2.0, 0, 0, 0, 0,
            zero, 1, 1, 99.0, 0, 1, 1, breakdown);
        check("Reward.tick blocks technique payouts even if a legacy caller supplies one",
            arbitraryLegacyTechniqueInput == 0.0 && breakdown.technique == 0.0);

        CameraReward camera = new CameraReward();
        camera.tick(0, 0, true, true, true, 1.0, 9);
        check("crit-window camera shaping is disabled while camera learning remains intact",
            camera.lastTerms[CameraReward.T_CRIT] == 0.0 && camera.lastTerms[CameraReward.T_HOLD] > 0.0);

        TechniqueReward legacy = new TechniqueReward();
        TechniqueReward.In legacyIn = new TechniqueReward.In();
        legacyIn.techW = 1.0; legacyIn.realDealt = 5.0f; legacyIn.hitCrit = true; legacyIn.hitSprint = true;
        check("legacy TechniqueReward tick is zero", legacy.tick(legacyIn) == 0.0);
        check("legacy TechniqueReward swing hook is zero", legacy.onSwing(false, 1.0) == 0.0);

        TechniqueDiscovery d = new TechniqueDiscovery();
        TechniqueDiscovery.In s = new TechniqueDiscovery.In();
        s.techW = 1.0; s.techTicks = 0; s.lateW = 1.0; s.airW = 1.0;
        s.hitGrounded = true; s.hitDist = 3.0; s.hitEnemyCharge = 0.4;
        s.dist = 3.0; s.inTheirReach = true; s.enemyFacing = 1.0; s.mySpeed = 0.3;
        double discoveryReward = 0.0;

        // Initial hit: crit, sprint-hit, first-hit, punish and spacing telemetry.
        quietTick(s, 1);
        s.newHit = true; s.realDealt = 3.0f; s.hitCrit = true; s.hitSprint = true; s.hitPunish = true;
        discoveryReward += d.tick(s);

        // A grounded W release/re-sprint records W-tap without a reward.
        quietTick(s, 2); s.fwd = 0; discoveryReward += d.tick(s);
        quietTick(s, 3); discoveryReward += d.tick(s);

        // A follow-up hit in the same exchange records knockback follow-up and combo.
        quietTick(s, 13); s.newHit = true; s.realDealt = 2.0f;
        discoveryReward += d.tick(s);

        // A grounded S tap followed by W+sprint is measured separately.
        quietTick(s, 14); s.fwd = -1; discoveryReward += d.tick(s);
        quietTick(s, 15); discoveryReward += d.tick(s);

        // Opponent overcommits outside reach; the next hit is tagged as a bait counter.
        quietTick(s, 20); s.oppSwingStart = true; s.inTheirReach = false; s.dist = 3.6;
        discoveryReward += d.tick(s);
        quietTick(s, 21); discoveryReward += d.tick(s);

        // Defensive movement that avoids an in-reach, facing swing is recorded as a dodge event.
        quietTick(s, 30); s.oppSwingStart = true; discoveryReward += d.tick(s);
        // The bait counter lands after the minimum event de-duplication interval.
        quietTick(s, 31); s.newHit = true; s.realDealt = 2.0f; s.hitDist = 3.6; s.dist = 3.6;
        discoveryReward += d.tick(s);
        for (int tick = 32; tick <= 36; tick++) { quietTick(s, tick); discoveryReward += d.tick(s); }

        // Jump shortly after taking knockback records a jump-reset event.
        quietTick(s, 40); s.taken = 1.0f; discoveryReward += d.tick(s);
        quietTick(s, 41); discoveryReward += d.tick(s);
        quietTick(s, 42); s.jumpStart = true; discoveryReward += d.tick(s);

        check("all technique event processing returns zero reward", Math.abs(discoveryReward) < 1e-12);
        check("episode settlement returns zero technique reward", d.endEpisode() == 0.0);

        // Telemetry is not stage-gated and is not limited by legacy per-episode technique caps.
        TechniqueDiscovery early = new TechniqueDiscovery();
        TechniqueDiscovery.In earlyIn = new TechniqueDiscovery.In();
        earlyIn.techW = 0.0; // deliberately before the curriculum unlocks technique shaping
        earlyIn.hitGrounded = true; earlyIn.hitDist = 3.0; earlyIn.hitEnemyCharge = 0.4;
        earlyIn.inTheirReach = true; earlyIn.enemyFacing = 1.0; earlyIn.mySpeed = 0.3;
        for (int tick = 1; tick <= 36; tick++) {
            quietTick(earlyIn, tick);
            earlyIn.techW = 0.0;
            earlyIn.oppSwingStart = (tick == 1 || tick == 8 || tick == 15 || tick == 22 || tick == 29);
            early.tick(earlyIn);
        }
        quietTick(earlyIn, 40); earlyIn.techW = 0.0; earlyIn.newHit = true; earlyIn.hitCrit = true; early.tick(earlyIn);
        quietTick(earlyIn, 44); earlyIn.techW = 0.0; earlyIn.newHit = true; earlyIn.hitCrit = true; early.tick(earlyIn);
        String[] earlyHeader = TechniqueDiscovery.csvHeader().split(",", -1);
        String[] earlyRow = early.csvRow(40, 0).split(",", -1);
        Map<String, String> earlyCells = new HashMap<>();
        for (int i = 0; i < earlyHeader.length; i++) earlyCells.put(earlyHeader[i], earlyRow[i]);
        check("technique telemetry starts before curriculum technique weights unlock",
            Long.parseLong(earlyCells.get("crit_events")) == 2L);
        check("dodge telemetry is not silently capped at the old payout limit",
            Long.parseLong(earlyCells.get("dodge_events")) == 5L);
        check("stage-zero technique detections still add exactly zero reward", early.endEpisode() == 0.0);

        // Misses remain measurable, but a repeat miss cannot create a negative reward.
        check("first miss returns zero", d.onSwing(false, 100, 1.0) == 0.0);
        check("repeat miss returns zero", d.onSwing(false, 101, 1.0) == 0.0);
        check("target-selected swing returns zero", d.onSwing(true, 102, 1.0) == 0.0);

        String header = TechniqueDiscovery.csvHeader();
        String row = d.csvRow(500, 9);
        String[] h = header.split(",", -1), v = row.split(",", -1);
        check("v2 technique audit CSV header and row align", h.length == v.length);
        Map<String, String> cells = new HashMap<>();
        for (int i = 0; i < h.length; i++) cells.put(h[i], v[i]);
        check("CSV explicitly records reward switch OFF and scale zero",
            "false".equals(cells.get("techniqueRewardsEnabled")) && "0.0000".equals(cells.get("techniqueRewardScale")));
        for (String technique : TechniqueDiscovery.NAMES) {
            check("CSV exposes " + technique + " event and payout columns",
                cells.containsKey(technique + "_events") && cells.containsKey(technique + "_paid"));
        }
        for (String technique : TechniqueDiscovery.NAMES) {
            check("no " + technique + " reward was paid",
                Math.abs(Double.parseDouble(cells.get(technique + "_paid"))) < 1e-12);
        }
        for (String technique : new String[]{"crit", "sprintHit", "kbFollowup", "combo", "firstHit", "punish",
                "dodge", "jumpReset", "spacing", "bait", "wTap", "sTap"}) {
            check("telemetry captured " + technique,
                Long.parseLong(cells.get(technique + "_events")) > 0);
        }
        check("swing telemetry distinguishes attempts, target selection and repeat whiffs",
            "3".equals(cells.get("swingAttempts")) && "1".equals(cells.get("targetSelected"))
                && "2".equals(cells.get("whiffs")) && "1".equals(cells.get("repeatedWhiffs")));
        check("total technique reward and whiff penalty remain zero",
            Math.abs(Double.parseDouble(cells.get("whiffStreakPenalty"))) < 1e-12
                && Math.abs(Double.parseDouble(cells.get("forfeited"))) < 1e-12);

        TechniqueDiscovery merged = new TechniqueDiscovery();
        merged.mergeWindow(d);
        String[] mergedValues = merged.csvRow(501, 9).split(",", -1);
        check("parallel audit merge preserves all technique and swing counters",
            mergedValues.length == h.length && mergedValues[0].equals("501"));
        merged.clearWindow();
        String[] cleared = merged.csvRow(502, 9).split(",", -1);
        check("audit clear resets technique events and swing counters",
            "0".equals(cleared[5]) && "0".equals(cleared[5 + TechniqueDiscovery.N * 7]));

        System.out.println("TechniqueRewardPolicyCheck: all checks passed");
    }
}
