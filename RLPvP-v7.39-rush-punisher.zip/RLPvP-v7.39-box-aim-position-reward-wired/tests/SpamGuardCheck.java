package com.rlpvp;

/** SpamGuard regression checks: technique-like movement patterns are telemetry-only. */
public final class SpamGuardCheck {
    static void check(String name, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + name); if (!ok) throw new AssertionError(name); }

    public static void main(String[] x) {
        SpamGuard g = new SpamGuard(); SpamGuard.In in = new SpamGuard.In();
        in.jumpFree = true; in.sneakFree = true; in.onGround = true;
        double net = 0;
        for (int t = 0; t < 300; t++) { in.jumpPressed = t % 11 == 0; in.realHit = false; net += g.tick(in); }
        check("jump-only use has no direct reward penalty", Math.abs(net) < 1e-9);
        check("jump usage remains counted", g.statsAndReset().contains("jumps "));

        g.reset(); net = 0;
        for (int t = 0; t < 300; t++) { in.jumpPressed = t % 13 == 0; in.realHit = t % 13 == 8; net += g.tick(in); }
        check("jump-to-hit does not receive a separate identity refund", Math.abs(net) < 1e-9);

        g.reset(); net = 0;
        for (int t = 0; t < 300; t++) { in.jumpPressed = t % 13 == 0; in.realHit = t % 13 == 8 && t < 100; net += g.tick(in); }
        double stopped = net;
        check("unproductive jumping is measured rather than penalized", Math.abs(stopped) < 1e-9);

        g.reset(); g.statsAndReset(); in.jumpPressed = false; in.realHit = false; net = 0;
        for (int t = 0; t < 200; t++) { in.sneaking = true; net += g.tick(in); }
        check("stationary idle sneak is mildly penalized after tolerance: net " + String.format("%.2f", net), net < -0.05 && net >= -Config.SPAM_MOVE_EPISODE_CAP - 1e-9);
        check("sneak usage remains present in telemetry", g.statsAndReset().contains("sneak 100.0%"));
        in.sneaking = false;

        g.reset(); net = 0;
        in.jumpPressed = true; in.onGround = true; in.realHit = false; net += g.tick(in);    // jump #1 opens a window
        in.jumpPressed = false;
        for (int t = 0; t < 12; t++) net += g.tick(in);
        in.jumpPressed = true; net += g.tick(in);                                              // jump #2 opens another one
        in.jumpPressed = false; in.realHit = true; double refund = g.tick(in);
        check("hit does not receive a standalone jump refund", Math.abs(refund) < 1e-9);

        SpamGuard h = new SpamGuard(); SpamGuard.In lk = new SpamGuard.In();
        lk.jumpFree = false; lk.sneakFree = false; lk.jumpPressed = true; lk.onGround = true; lk.sneaking = true;
        double lockedNet = 0;
        for (int t = 0; t < 100; t++) lockedNet += h.tick(lk);
        check("locked heads cost nothing", lockedNet == 0.0);

        System.out.println("SpamGuardCheck: all ok");
    }
}
