package com.rlpvp;

/** Causal event-memory tests: delayed hit credit, typed hits, follow-ups, combos and whiff timing. */
public final class EventDrivenCombatMemoryCheck {
    private EventDrivenCombatMemoryCheck() {}

    public static void main(String[] args) {
        suppressedClicksAreNotAttempts();
        typedHitsAndFollowups();
        overlappingAttackWindows();
        saturatedHitSummary();
        comboGapReset();
        delayedWhiffResolution();
        System.out.println("PASS applied-click accounting, causal combat memory, typed hits, overlapping swing windows, combo/follow-up conversion and delayed whiff resolution");
    }

    private static void suppressedClicksAreNotAttempts() {
        EventDrivenCombatMemory memory = new EventDrivenCombatMemory();
        memory.beginEpisode();
        float[] obs = frame();
        memory.observeTransition(obs);
        memory.recordChosen(obs, attack(), 0, Config.MIN_ATTACK_STRENGTH_LATE);
        memory.recordAppliedSwing(false, false); // ActionApplier suppressed the click.
        for (int i = 0; i < Config.HIT_CREDIT_TICKS + 3; i++) memory.observeTransition(obs.clone());
        if (!memory.status().contains("attacks=0") || memory.snapshot().whiffs != 0)
            throw new AssertionError("a policy attack intent with no queued click was counted as an attempt/whiff");

        obs[6] = 0.7f;
        memory.recordChosen(obs, attack(), 0, Config.MIN_ATTACK_STRENGTH);
        memory.recordAppliedSwing(true, true); // No candidate should exist below the true stage gate.
        if (!memory.status().contains("attacks=0"))
            throw new AssertionError("attempt accounting ignored the live stage attack threshold");
        obs[6] = 1f;
        memory.recordChosen(obs, attack(), 0, Config.MIN_ATTACK_STRENGTH);
        memory.recordAppliedSwing(true, true); // Actual target-ray click, but no damage was credited.
        for (int i = 0; i < Config.HIT_CREDIT_TICKS + 3; i++) memory.observeTransition(obs.clone());
        String status = memory.status();
        if (!status.contains("attacks=1") || !status.contains("whiffs=1")
                || !status.contains("range=0 aim=0"))
            throw new AssertionError("target-ray click without damage was incorrectly labelled a range/aim miss: " + status);
    }

    private static void typedHitsAndFollowups() {
        EventDrivenCombatMemory memory = new EventDrivenCombatMemory();
        memory.beginEpisode();
        float[] obs = frame();
        memory.observeTransition(obs);

        // Crit: the hit is observed one tick after the attack pulse, and the confirmed HitMemory
        // summary (not canCrit eligibility alone) supplies the type.
        memory.recordChosen(obs, attack(), 0, Config.MIN_ATTACK_STRENGTH_LATE);
        memory.recordAppliedSwing(true, true);
        float[] idle = obs.clone();
        memory.observeTransition(idle);
        float[] crit = withHit(idle, 0.95f, HitMemory.CRIT, 1);
        memory.observeTransition(crit);
        EventDrivenCombatMemory.Snapshot snap = memory.snapshot();
        require(snap.confirmedHits == 1 && snap.criticalHits == 1 && snap.sprintHits == 0,
            "confirmed critical hit was not classified from HitMemory");
        require(snap.whiffs == 0, "one-tick delayed hit was incorrectly counted as a whiff");

        // Sprint hit opens a follow-up opportunity. A later ordinary hit converts it and
        // extends the actual landed-hit combo without scripting the action sequence.
        float[] sprintReady = crit.clone();
        sprintReady[20] = 0f; sprintReady[5] = 1f; sprintReady[4] = 1f;
        memory.observeTransition(sprintReady);
        memory.recordChosen(sprintReady, attack(), 0, Config.MIN_ATTACK_STRENGTH_LATE);
        memory.recordAppliedSwing(true, true);
        float[] sprintHit = withHit(sprintReady, 0.90f, HitMemory.SPRINT, 2);
        memory.observeTransition(sprintHit);
        require(memory.snapshot().followupOpen && memory.snapshot().sprintHits == 1,
            "confirmed sprint hit did not open follow-up memory");

        float[] normalReady = sprintHit.clone();
        normalReady[20] = 0f; normalReady[5] = 0f;
        memory.observeTransition(normalReady);
        memory.recordChosen(normalReady, attack(), 0, Config.MIN_ATTACK_STRENGTH_LATE);
        memory.recordAppliedSwing(true, true);
        float[] normalHit = withHit(normalReady, 0.85f, 0, 3);
        memory.observeTransition(normalHit);
        snap = memory.snapshot();
        require(snap.confirmedHits == 3 && snap.criticalHits == 1 && snap.sprintHits == 1 && snap.normalHits == 1,
            "typed hit counters were incorrect after three distinct hit categories");
        require(snap.followupConversions == 1 && snap.maxCombo == 3 && snap.currentCombo == 3,
            "follow-up conversion or confirmed combo tracking failed");
    }

    private static void overlappingAttackWindows() {
        EventDrivenCombatMemory memory = new EventDrivenCombatMemory();
        memory.beginEpisode();
        float[] obs = frame();
        memory.observeTransition(obs);
        memory.recordChosen(obs, attack(), 0, Config.MIN_ATTACK_STRENGTH_LATE); // older attempt
        memory.recordAppliedSwing(true, false);

        // Bring the old attempt to the edge of its six-tick credit window.
        for (int i = 0; i < Config.HIT_CREDIT_TICKS; i++) memory.observeTransition(obs.clone());
        memory.recordChosen(obs, attack(), 0, Config.MIN_ATTACK_STRENGTH_LATE); // a newer pulse can overlap at the relaxed charge threshold
        memory.recordAppliedSwing(true, true);
        float[] hit = withHit(obs, 0.94f, HitMemory.SPRINT, 1);
        memory.observeTransition(hit);
        EventDrivenCombatMemory.Snapshot snap = memory.snapshot();
        require(snap.confirmedHits == 1 && snap.sprintHits == 1,
            "newest overlapping attack was not matched to the observed hit");
        require(snap.whiffs == 1,
            "older uncredited swing did not resolve separately after its credit window");
    }


    private static void saturatedHitSummary() {
        EventDrivenCombatMemory memory = new EventDrivenCombatMemory();
        memory.beginEpisode();
        float[] obs = frame();
        if (Config.MEMORY) {
            int off = ObsLayout.summaryOffset();
            obs[off + 10] = 1f; // six-hit rolling count already saturated
            obs[off + 2] = 1f; // last confirmed hit was a sprint hit
        }
        memory.observeTransition(obs);
        // Deliberately make the swing context look crit-eligible. The actual current
        // HitMemory summary must win even though its rolling hit counter cannot increase.
        obs[5] = 0f; obs[43] = 1f; obs[4] = 0f;
        memory.recordChosen(obs, attack(), 0, Config.MIN_ATTACK_STRENGTH_LATE);
        memory.recordAppliedSwing(true, true);
        float[] hit = obs.clone();
        hit[15] = 0.94f; hit[20] = 1f;
        if (Config.MEMORY) {
            int off = ObsLayout.summaryOffset();
            hit[off + 10] = 1f; // still saturated
            hit[off + 1] = 0f; hit[off + 2] = 1f; // same sprint type as previous event
            hit[off + 3] = 0f; hit[off + 4] = 0f;
        }
        memory.observeTransition(hit);
        require(memory.snapshot().sprintHits == 1 && memory.snapshot().criticalHits == 0,
            "saturated hit-memory counter caused a confirmed sprint hit to be misclassified");
    }


    private static void comboGapReset() {
        EventDrivenCombatMemory memory = new EventDrivenCombatMemory();
        memory.beginEpisode();
        float[] obs = frame();
        memory.observeTransition(obs);
        memory.recordChosen(obs, attack(), 0, Config.MIN_ATTACK_STRENGTH_LATE);
        memory.recordAppliedSwing(true, true);
        float[] idle = obs.clone();
        memory.observeTransition(idle);
        memory.observeTransition(withHit(idle, 0.95f, 0, 1));
        require(memory.snapshot().currentCombo == 1, "first landed hit did not start a combo");
        for (int i = 0; i < 21; i++) memory.observeTransition(idle.clone());
        require(memory.snapshot().currentCombo == 0,
            "combo stayed open indefinitely after the configured gap elapsed");
    }

    private static void delayedWhiffResolution() {
        EventDrivenCombatMemory memory = new EventDrivenCombatMemory();
        memory.beginEpisode();
        float[] obs = frame();
        obs[12] = 0.75f; // 4.5 blocks, outside normal reach
        obs[13] = 0.30f; // 54 degrees of aim error
        memory.observeTransition(obs);
        memory.recordChosen(obs, attack(), 0, Config.MIN_ATTACK_STRENGTH_LATE);
        memory.recordAppliedSwing(true, false);

        for (int i = 0; i < Config.HIT_CREDIT_TICKS; i++) memory.observeTransition(obs.clone());
        require(memory.snapshot().whiffs == 0,
            "attack was declared a whiff before the full hit-credit window elapsed");
        memory.observeTransition(obs.clone());
        EventDrivenCombatMemory.Snapshot snap = memory.snapshot();
        require(snap.whiffs == 1 && snap.whiffRate > 0.99 && snap.repeatedWhiffRisk == 0.25,
            "expired attack did not resolve as one whiff");
        String status = memory.status();
        require(status.contains("range=1") && status.contains("aim=1"),
            "whiff reason diagnostics were not recorded: " + status);
    }

    private static float[] frame() {
        float[] obs = new float[Config.OBS_SIZE];
        obs[0] = 1f; obs[6] = 1f; obs[12] = 0.25f;
        obs[13] = 0f; obs[14] = 0f; obs[15] = 1f;
        obs[20] = 0f; obs[26] = 1f; obs[43] = 1f;
        obs[44] = 1f; obs[45] = 1f;
        return obs;
    }

    private static float[] attack() {
        float[] action = new float[PpoAgent.N_ACT];
        action[2] = 1f; action[3] = 1f; action[4] = 1f;
        return action;
    }

    private static float[] withHit(float[] previous, float enemyHealth, int type, int count) {
        float[] hit = previous.clone();
        hit[15] = enemyHealth;
        hit[20] = 1f;
        if (Config.MEMORY) {
            int off = ObsLayout.summaryOffset();
            hit[off + 10] = Math.min(1f, count / 6f);
            hit[off + 1] = (type & HitMemory.CRIT) != 0 ? 1f : 0f;
            hit[off + 2] = (type & HitMemory.SPRINT) != 0 ? 1f : 0f;
            hit[off + 3] = (type & HitMemory.SWEEP) != 0 ? 1f : 0f;
            hit[off + 4] = (type & HitMemory.WEAK) != 0 ? 1f : 0f;
        }
        return hit;
    }

    private static void require(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
