package com.rlpvp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Random;
import java.util.Arrays;

/** Minecraft-free smoke test for online outcome prediction and persistence. */
public final class ConsequenceModelCheck {
    public static void main(String[] args) throws Exception {
        ConsequenceModel model = new ConsequenceModel(new Random(19));
        float[] obs = new float[Config.OBS_SIZE];
        float[] action = new float[PpoAgent.N_ACT];
        float[] next = new float[Config.FRAME];
        Random r = new Random(7);
        for (int n = 0; n < 120; n++) {
            for (int i = 0; i < obs.length; i++) obs[i] = r.nextFloat() * 2f - 1f;
            for (int i = 0; i < action.length; i++) action[i] = r.nextFloat() * 2f - 1f;
            for (int i = 0; i < next.length; i++) next[i] = r.nextFloat() * 2f - 1f;
            next[0] = r.nextFloat(); next[15] = r.nextFloat();
            model.observe(obs, action, next);
        }
        long expectedTrain = 0, expectedValidation = 0;
        for (int t = 1; t <= 120; t++) {
            if (t % 10 == 0) expectedValidation++; // held-out transitions are never trained on
            else if (Config.CONSEQUENCE_TRAIN_EVERY <= 1 || t % Config.CONSEQUENCE_TRAIN_EVERY == 0) expectedTrain++;
        }
        if (model.transitions() != 120 || model.trainedTransitions() != expectedTrain || model.validationTransitions() != expectedValidation)
            throw new AssertionError("incorrect online-model counters: trained=" + model.trainedTransitions() + "/" + expectedTrain
                + ", validation=" + model.validationTransitions() + "/" + expectedValidation);
        float[] predicted = new float[Config.FRAME];
        model.predict(obs, action, predicted);
        for (int i = 0; i < predicted.length; i++) {
            if (Float.isNaN(predicted[i]) || Float.isInfinite(predicted[i])) throw new AssertionError("non-finite prediction");
            if (predicted[i] < -1f || predicted[i] > 1f) throw new AssertionError("unbounded prediction at " + i);
        }
        if (model.planningReady()) throw new AssertionError("planner enabled before minimum data threshold");

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        model.write(new DataOutputStream(bytes));
        ConsequenceModel directCopy = new ConsequenceModel(new Random(23));
        directCopy.copyPersistedStateFrom(model);
        ByteArrayOutputStream directBytes = new ByteArrayOutputStream();
        directCopy.write(new DataOutputStream(directBytes));
        if (!Arrays.equals(bytes.toByteArray(), directBytes.toByteArray()))
            throw new AssertionError("direct consequence-state copy differs from serialized state");
        ConsequenceModel loaded = new ConsequenceModel(new Random(22));
        loaded.read(new DataInputStream(new ByteArrayInputStream(bytes.toByteArray())));
        if (loaded.transitions() != model.transitions()) throw new AssertionError("transition counter not persisted");
        float[] a = new float[Config.FRAME], b = new float[Config.FRAME];
        model.predict(obs, action, a); loaded.predict(obs, action, b);
        for (int i = 0; i < a.length; i++) if (Math.abs(a[i] - b[i]) > 1e-6) throw new AssertionError("prediction changed after reload");
        learnsActionDependentDamage();
        staticWorldNeverEnablesPlanning();
        v5StateMigrates(bytes.toByteArray());
        System.out.println("ConsequenceModelCheck: online training, bounds and persistence OK");
    }

    /** Synthetic world: a swing with the enemy in reach drops enemy health by 0.2, otherwise nothing changes. */
    static void learnsActionDependentDamage() {
        ConsequenceModel m = new ConsequenceModel(new Random(3));
        Random r = new Random(11);
        float[] o = new float[Config.OBS_SIZE], a = new float[PpoAgent.N_ACT], nx = new float[Config.FRAME];
        for (int n = 0; n < 40_000 * Math.max(1, Config.CONSEQUENCE_TRAIN_EVERY); n++) { // the model trains on every Nth transition
            for (int i = 0; i < 49; i++) o[i] = r.nextFloat();
            for (int i = 0; i < a.length; i++) a[i] = 0f;
            a[4] = r.nextInt(3) == 0 ? 1f : 0f;
            o[44] = r.nextBoolean() ? 1f : 0f;
            System.arraycopy(o, 0, nx, 0, Config.FRAME);
            if (a[4] > 0.5f && o[44] > 0.5f) nx[15] = Math.max(0f, o[15] - 0.2f);
            m.observe(o, a, nx);
        }
        float[] p = new float[Config.FRAME];
        double with = 0, without = 0; int k = 0;
        for (int n = 0; n < 500; n++) {
            for (int i = 0; i < 49; i++) o[i] = r.nextFloat();
            o[44] = 1f; o[15] = 0.8f;
            a[4] = 1f; m.predict(o, a, p); with += o[15] - p[15];
            a[4] = 0f; m.predict(o, a, p); without += o[15] - p[15];
            k++;
        }
        with /= k; without /= k;
        if (with < 0.12 || without > 0.05) throw new AssertionError("model did not learn that swinging in reach causes damage (with " + with + ", without " + without + ")");
        if (!m.planningReady()) throw new AssertionError("gate stayed closed for a model that clearly beats persistence (skill " + m.healthSkill() + ")");
    }

    /** If nothing ever changes, 'next = current' is unbeatable: the gate must not open however much data arrives. */
    static void staticWorldNeverEnablesPlanning() {
        ConsequenceModel m = new ConsequenceModel(new Random(4));
        Random r = new Random(12);
        float[] o = new float[Config.OBS_SIZE], a = new float[PpoAgent.N_ACT], nx = new float[Config.FRAME];
        for (int n = 0; n < 30_000; n++) {
            for (int i = 0; i < 49; i++) o[i] = r.nextFloat();
            System.arraycopy(o, 0, nx, 0, Config.FRAME);
            m.observe(o, a, nx);
        }
        if (m.planningReady()) throw new AssertionError("planner enabled for a model that cannot beat persistence");
    }

    /** A state-v5 consequence section (absolute-target weights) is consumed and discarded; the stream stays aligned. */
    static void v5StateMigrates(byte[] v6) throws Exception {
        int statsEnd = 3 * 8 + 1 + 8, extra = 8 + 8 + 4 * Config.FRAME;
        byte[] v5 = new byte[v6.length - extra];
        System.arraycopy(v6, 0, v5, 0, statsEnd);
        System.arraycopy(v6, statsEnd + extra, v5, statsEnd, v6.length - statsEnd - extra);
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(v5));
        ConsequenceModel m = new ConsequenceModel(new Random(5));
        m.read(in, 5);
        if (in.available() != 0) throw new AssertionError("v5 consequence section not fully consumed");
        if (m.transitions() != 0 || m.planningReady()) throw new AssertionError("v5 model must restart untrained");
    }
}
