package com.rlpvp;

public final class SprintHitFollowupMemoryTest {
    private static int passed;
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        passed++;
    }
    public static void main(String[] args) {
        SprintHitFollowupMemory m = new SprintHitFollowupMemory();
        check(m.tick(false, false, 2f, 0f, 0f, 0f) == SprintHitFollowupMemory.NONE, "idle event");
        check(m.tick(true, true, 2f, 0.1f, -0.2f, 0.3f) == SprintHitFollowupMemory.SPRINT_HIT, "sprint hit takes priority over same-tick follow-up");
        float[] summary = new float[Config.SUMMARY];
        m.fillSummary(summary);
        int offset = Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0);
        check(summary[offset] == 1f, "active feature set");
        check(m.tick(false, false, 2.5f, 0.2f, 0.1f, -0.1f) == SprintHitFollowupMemory.NONE, "active window continues");
        check(m.tick(false, true, 3f, 0.3f, 0f, 0f) == SprintHitFollowupMemory.FOLLOWUP_HIT, "follow-up hit credited");
        check(m.lastFollowupTicks() == 2, "follow-up delay tracked");
        m.fillSummary(summary);
        check(summary[offset + 6] == 1f, "conversion pulse visible");
        m.reset();
        m.tick(true, true, 2f, 0f, 0f, 0f);
        int chained = m.tick(true, true, 2.5f, 0.1f, 0f, 0f);
        check((chained & SprintHitFollowupMemory.FOLLOWUP_HIT) != 0, "a chained sprint hit converts the previous opportunity");
        check((chained & SprintHitFollowupMemory.SPRINT_HIT) != 0, "a chained sprint hit opens the next opportunity");
        m.reset();
        check(m.tick(true, false, 2f, 0f, 0f, 0f) == SprintHitFollowupMemory.SPRINT_HIT, "second opportunity starts");
        int result = SprintHitFollowupMemory.NONE;
        for (int i = 0; i < 20; i++) result = m.tick(false, false, 2f + i * 0.1f, 0f, 0f, 0f);
        check(result == SprintHitFollowupMemory.EXPIRED, "unconverted opportunity expires");
        m.fillSummary(summary);
        check(summary[offset + 7] == 1f, "expiry pulse visible");
        System.out.println("SprintHitFollowupMemoryTest: " + passed + " passed, 0 failed");
    }
}
