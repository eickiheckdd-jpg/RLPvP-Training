package com.rlpvp;

/** v7.21 checks: JUMP_RESET is outcome-settled, grounded techniques need a grounded swing, SpamGuard frees reactive jumps, payout factors are bounded. */
public final class JumpResetCheck {
    static void check(String name, boolean ok) { System.out.println((ok ? "ok   " : "FAIL ") + name); if (!ok) throw new AssertionError(name); }

    /** takes damage at tick 5; optionally jumps at tick jumpAt; optionally lands a hit at tick hitAt (a won exchange). @return the discovery summary */
    static String run(int jumpAt, int hitAt, boolean hitGrounded, boolean sprintHit) {
        TechniqueDiscovery d = new TechniqueDiscovery(); TechniqueDiscovery.In s = new TechniqueDiscovery.In();
        s.techW = 1.0; s.techTicks = 0; s.dist = 2.0;
        for (int t = 0; t < 60; t++) {
            s.tick = t; s.realDealt = 0; s.taken = 0; s.newHit = false; s.jumpStart = false; s.hitSprint = false; s.hitGrounded = false;
            s.dist = t >= 5 ? 2.5 : 2.0;
            if (t == 5) s.taken = 3f;
            if (t == jumpAt) s.jumpStart = true;
            if (t == hitAt) { s.realDealt = 6f; s.newHit = true; s.hitSprint = sprintHit; s.hitGrounded = hitGrounded; }
            d.tick(s);
        }
        d.endEpisode();
        return d.summary();
    }

    public static void main(String[] x) {
        String won = run(7, 20, true, false);
        check("jump reset followed by a won exchange is counted: " + won, won.contains("jumpReset=1/1/0"));
        String noHit = run(7, -1, true, false);
        check("jump reset with no follow-up hit pays nothing: " + noHit, noHit.contains("jumpReset=1/0/1"));
        String late = run(30, 40, true, false);
        check("a jump long after the hit is not a jump reset: " + late, late.contains("jumpReset=0/0/0"));
        String ground = run(-1, 20, true, true), air = run(-1, 20, false, true);
        check("grounded sprint hit counts as a sprint hit: " + ground, ground.contains("sprintHit=1/1/0"));
        check("airborne sprint hit earns no sprint-hit bonus: " + air, air.contains("sprintHit=0/0/0"));

        SpamGuard g = new SpamGuard(); SpamGuard.In in = new SpamGuard.In();
        in.jumpFree = true; in.onGround = true;
        double net = 0;
        for (int t = 0; t < 40; t++) { in.tookHit = t == 3; in.jumpPressed = t == 5; net += g.tick(in); }
        check("a jump right after taking damage is free: net " + net, Math.abs(net) < 1e-9);
        g.reset(); net = 0;
        for (int t = 0; t < 40; t++) { in.tookHit = false; in.jumpPressed = t == 5; net += g.tick(in); }
        check("the same jump without being hit is not penalized: net " + net, Math.abs(net) < 1e-9);

        check("separation factor: full when close, floor when far",
            TechniqueDiscovery.sepFactor(0.5) == 1.0 && Math.abs(TechniqueDiscovery.sepFactor(5.0) - Config.TECH_JR_MIN_FACTOR) < 1e-9
            && TechniqueDiscovery.sepFactor(2.0) < 1.0 && TechniqueDiscovery.sepFactor(2.0) > Config.TECH_JR_MIN_FACTOR);
        check("net payout factor is clamped", new TechniqueDiscovery().netFactor(0.1) == Config.TECH_NET_MIN && new TechniqueDiscovery().netFactor(99) == Config.TECH_NET_MAX
            && new TechniqueDiscovery().netFactor(Config.TECH_NET_HITS) == 1.0);
        System.out.println("JumpResetCheck passed");
    }
}
