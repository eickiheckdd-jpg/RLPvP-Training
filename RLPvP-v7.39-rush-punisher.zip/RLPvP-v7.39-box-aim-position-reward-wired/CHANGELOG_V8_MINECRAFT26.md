# v8.1 — Combat-first Diamond Protection III profile

- Added explicit equipment metadata for a normal diamond sword (player base damage 1 + sword modifier 6; player attack speed 4 + sword modifier -2.4) and four diamond armor pieces with Protection III.
- The target profile now derives its combat totals from the equipment definition: 7 attack damage, attack speed 1.6 / 12.5-tick full charge, 20 armor, 8 toughness, and melee Protection EPF 12.
- Added a damage-stage breakdown (raw, after armor, after Resistance, after Protection) that follows the order in the supplied Minecraft 26.3 reference methods.
- Hardened input clamping for attack strength, damage, armor/toughness, Protection EPF, and knockback strength.
- Added `tests/DiamondProt3KitTest.java` for normal/critical/partial-charge damage, explicit gear totals, cooldown behavior, and the integrated strike path.
- Added `sim/train_diamond_prot3.sh` to force the intended kit when training.
- No UHC blocks or voxel world were added.
- Accuracy is still scoped: the equations are independently implemented and source-referenced; a live vanilla 26.3 parity run is not claimed.
