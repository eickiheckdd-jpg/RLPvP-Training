package com.rlpvp;

/** Server-confirmed incoming-combo segmentation and outcome telemetry. No per-tick movement reward. */
final class ComboDefenseTracker {
    static final int CHAIN_COMPLETED = 1;
    static final int STRAFE_ESCAPE = 2;
    static final int GAP_TICKS = 12;
    static final double MIN_LATERAL_PATH = 0.35;
    static final int MIN_STRAFE_TICKS = 3;

    private boolean active;
    private int hits, ticksSinceHit, strafeTicks;
    private double lateralPath;
    private long completedChains, strafeEscapes, completedChainHits;
    private int maxIncomingChain;

    void reset() {
        startEpisode();
        clearWindow();
    }

    /** End a duel without discarding aggregate training-window statistics. */
    void startEpisode() {
        active = false;
        hits = ticksSinceHit = strafeTicks = 0;
        lateralPath = 0.0;
    }

    /** Clear aggregate counters after a training status line has been emitted. */
    void clearWindow() {
        completedChains = strafeEscapes = completedChainHits = 0;
        maxIncomingChain = 0;
    }

    /**
     * Call once per tick with server-confirmed damage and the client's sideways travel.
     * Travel is only accumulated while a lateral key command is active, to avoid counting
     * knockback-only displacement as successful learned strafing.
     */
    int tick(boolean tookServerDamage, double lateralDisplacement, boolean strafeInputActive) {
        if (tookServerDamage) {
            if (!active) {
                active = true;
                hits = 1;
                lateralPath = 0.0;
                strafeTicks = 0;
            } else {
                hits++;
            }
            ticksSinceHit = 0;
            maxIncomingChain = Math.max(maxIncomingChain, hits);
            return 0;
        }
        if (!active) return 0;
        if (strafeInputActive) {
            strafeTicks++;
            if (Double.isFinite(lateralDisplacement)) lateralPath += Math.max(0.0, Math.abs(lateralDisplacement));
        }
        ticksSinceHit++;
        if (ticksSinceHit <= GAP_TICKS) return 0;
        active = false;
        if (hits < 2) {
            hits = 0;
            lateralPath = 0.0;
            strafeTicks = 0;
            return 0;
        }
        completedChains++;
        completedChainHits += hits;
        boolean lateral = strafeTicks >= MIN_STRAFE_TICKS && lateralPath >= MIN_LATERAL_PATH;
        if (lateral) strafeEscapes++;
        hits = 0;
        lateralPath = 0.0;
        strafeTicks = 0;
        return CHAIN_COMPLETED | (lateral ? STRAFE_ESCAPE : 0);
    }

    long completedChains() { return completedChains; }
    long strafeEscapes() { return strafeEscapes; }
    long completedChainHits() { return completedChainHits; }
    int maxIncomingChain() { return maxIncomingChain; }
}
