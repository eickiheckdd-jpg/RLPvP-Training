package com.rlpvp;

import java.util.ArrayList;
import java.util.List;
import java.util.ArrayDeque;
import java.util.Random;

/**
 * Deterministic, tick-driven model of a Minecraft client's TCP connection.
 *
 * The simulated game runs at 20 Hz. Application packets are never silently
 * dropped: an underlying segment loss delays that packet and all later packets
 * on the same direction (TCP head-of-line blocking). Delivery is quantized to
 * server/client tick boundaries, just as Connection packets are handed to the
 * appropriate game-thread packet listener.
 *
 * This is not Netty or a byte-for-byte TCP implementation. It models the parts
 * that affect duel decisions: one-way propagation, asymmetry, jitter, FIFO
 * ordering, serialization, retransmission stalls, and packet delivery phase.
 */
public final class NetworkSimulation {
    public static final double TICK_MS = 50.0;

    private NetworkSimulation() {}

    public record Profile(double rttMs, double clientToServerMs, double serverToClientMs,
                          double jitterMs, double tcpLossRate, double retransmitTimeoutMs) {
        public static Profile offline() {
            return new Profile(0.0, 0.0, 0.0, 0.0, 0.0, 200.0);
        }

        public long clientToServerTicks() { return Math.max(0L, (long)Math.ceil(clientToServerMs / TICK_MS)); }
        public long serverToClientTicks() { return Math.max(0L, (long)Math.ceil(serverToClientMs / TICK_MS)); }
    }

    /** RTT is the player's displayed ping; one-way delays are split asymmetrically. */
    public static Profile sample(Random random, boolean enabled, double stageScale,
                                 Double fixedRttMs) {
        if (fixedRttMs != null) {
            // Fixed-lag evaluation mode is intentionally deterministic: symmetric path, no jitter/loss.
            double rtt = Math.max(0.0, fixedRttMs);
            return new Profile(rtt, rtt * 0.5, rtt * 0.5, 0.0, 0.0,
                positiveProperty("rlpvp.tcpRtoMs", 200.0));
        }
        if (!enabled || !Config.LAG_RANDOMIZE || stageScale <= 0.0) return Profile.offline();

        double min = positiveProperty("rlpvp.lagMinMs", Config.LAG_MIN_MS);
        double max = Math.max(min, positiveProperty("rlpvp.lagMaxMs", Config.LAG_MAX_MS));
        // latencyAlways means every episode receives a sampled RTT inside the configured bounds.
        // The usual curriculum retains its 10% lag-free episodes when the override is disabled.
        if (!Boolean.getBoolean("rlpvp.latencyAlways") && random.nextDouble() < Config.LAG_NONE_PROB)
            return Profile.offline();
        double hi = min + (max - min) * Math.min(1.0, stageScale / 1.25);
        // Log-uniform RTT: more low/medium ping episodes, while still exploring the full late-stage range.
        double rtt = min <= 0.0 ? hi * random.nextDouble()
            : min * Math.pow(Math.max(1.0, hi / min), random.nextDouble());
        double asymmetry = 0.5 + (random.nextDouble() - 0.5) * 0.16;
        double c2s = rtt * asymmetry;
        double s2c = rtt - c2s;
        double jitterDefault = 1.0 + rtt * 0.035;
        // New explicit name is standard deviation (sigma); retain the earlier option as an alias.
        double jitter = Math.min(10.0, System.getProperty("rlpvp.networkJitterStdMs") != null
            ? positiveProperty("rlpvp.networkJitterStdMs", jitterDefault)
            : positiveProperty("rlpvp.networkJitterMaxMs", jitterDefault));
        double loss = probabilityProperty("rlpvp.tcpSegmentLoss", 0.0005);
        double rto = positiveProperty("rlpvp.tcpRtoMs", 200.0);
        return new Profile(rtt, c2s, s2c, jitter, loss, rto);
    }

    private static double positiveProperty(String name, double fallback) {
        String raw = System.getProperty(name);
        if (raw == null) return fallback;
        try { return Math.max(0.0, Double.parseDouble(raw)); }
        catch (NumberFormatException ex) { throw new IllegalArgumentException("Invalid " + name + "=" + raw, ex); }
    }

    private static double probabilityProperty(String name, double fallback) {
        return Math.max(0.0, Math.min(1.0, positiveProperty(name, fallback)));
    }

    public static final class Delivery {
        public final Object payload;
        public final double sentAtMs;
        public final double arrivedAtMs;
        public final long sequence;
        public final boolean retransmitted;

        Delivery(Object payload, double sentAtMs, double arrivedAtMs, long sequence, boolean retransmitted) {
            this.payload = payload;
            this.sentAtMs = sentAtMs;
            this.arrivedAtMs = arrivedAtMs;
            this.sequence = sequence;
            this.retransmitted = retransmitted;
        }

        public double oneWayDelayMs() { return Math.max(0.0, arrivedAtMs - sentAtMs); }
    }

    /** One reliable, ordered TCP byte stream in one direction. */
    public static final class Channel {
        private final Random random;
        private final double oneWayMs;
        private final double jitterMs;
        private final double lossRate;
        private final double rtoMs;
        private final double bandwidthMbps;
        // A channel is a TCP-ordered stream. send() clamps every arrival to at least
        // lastArrivalMs + serializationMs, and serializationMs is strictly positive,
        // so arrival times are strictly increasing with sequence. A FIFO is therefore
        // equivalent to the old priority queue, without heap maintenance on every packet.
        private final ArrayDeque<Delivery> pending = new ArrayDeque<>();
        private long nextSequence;
        private double lastArrivalMs;
        private long retransmissions;
        private long sentPackets;
        private double totalDelayMs;
        private long deliveredPackets;
        private int maxQueueDepth;

        Channel(Random random, double oneWayMs, double jitterMs, double lossRate,
                double rtoMs, double bandwidthMbps) {
            this.random = random;
            this.oneWayMs = Math.max(0.0, oneWayMs);
            this.jitterMs = Math.max(0.0, jitterMs);
            this.lossRate = Math.max(0.0, Math.min(1.0, lossRate));
            this.rtoMs = Math.max(1.0, rtoMs);
            this.bandwidthMbps = Math.max(0.1, bandwidthMbps);
        }

        /** Send at the end of client tick; +1 ms preserves the server/client tick phase. */
        public void send(long tick, Object payload, int payloadBytes) {
            double sentAt = tick * TICK_MS + 1.0;
            double jitter = jitterMs == 0.0 ? 0.0 : random.nextGaussian() * jitterMs;
            double propagation = Math.max(0.0, oneWayMs + jitter);
            double bytes = Math.max(1, payloadBytes) + 40.0; // approximate TCP/IP framing overhead
            double serializationMs = bytes * 8.0 / (bandwidthMbps * 1000.0);
            double arrival = sentAt + propagation + serializationMs;
            boolean retransmitted = random.nextDouble() < lossRate;
            if (retransmitted) {
                // A lost TCP segment is retransmitted; later app packets wait behind it.
                arrival += rtoMs + random.nextDouble() * Math.min(50.0, rtoMs * 0.25);
                retransmissions++;
            }
            // TCP stream ordering prevents a later packet overtaking an earlier delayed/lost segment.
            arrival = Math.max(arrival, lastArrivalMs + serializationMs);
            lastArrivalMs = arrival;
            pending.addLast(new Delivery(payload, sentAt, arrival, nextSequence++, retransmitted));
            sentPackets++;
            maxQueueDepth = Math.max(maxQueueDepth, pending.size());
        }

        /** Drain all packets available at the start of this tick, preserving TCP order. */
        public List<Delivery> drain(long tick) {
            List<Delivery> out = new ArrayList<>();
            drainInto(tick, out);
            // Preserve the original public method's sequence-order contract. The simulator's
            // hot path uses drainInto() and performs one merged arrival/sequence sort itself.
            // FIFO arrival order is also monotonically increasing sequence order.
            return out;
        }

        /**
         * Allocation-free destination variant for hot simulator loops. Appends (does not clear)
         * packets to {@code out}. Within one TCP channel, arrival times are strictly increasing
         * because send() enforces head-of-line ordering, so the priority-queue order is already
         * sequence order, matching the historical sort in drain().
         */
        public void drainInto(long tick, List<Delivery> out) {
            if (out == null) throw new IllegalArgumentException("out must not be null");
            double now = tick * TICK_MS;
            while (!pending.isEmpty() && pending.peekFirst().arrivedAtMs <= now + 1.0e-9) {
                Delivery d = pending.removeFirst();
                out.add(d);
                deliveredPackets++;
                totalDelayMs += d.oneWayDelayMs();
            }
        }

        public long pendingPackets() { return pending.size(); }
        public long sentPackets() { return sentPackets; }
        public long retransmissions() { return retransmissions; }
        public int maxQueueDepth() { return maxQueueDepth; }
        public double meanDeliveredDelayMs() { return deliveredPackets == 0 ? 0.0 : totalDelayMs / deliveredPackets; }
        public double oneWayBaseMs() { return oneWayMs; }
    }

    public static final class Connection {
        public final Profile profile;
        public final Channel clientToServer;
        public final Channel serverToClient;

        public Connection(Profile profile, long seed) {
            this.profile = profile;
            Random r = new Random(seed);
            double bandwidth = positiveProperty("rlpvp.networkBandwidthMbps", 10.0);
            this.clientToServer = new Channel(new Random(r.nextLong()), profile.clientToServerMs,
                profile.jitterMs, profile.tcpLossRate, profile.retransmitTimeoutMs, bandwidth);
            this.serverToClient = new Channel(new Random(r.nextLong()), profile.serverToClientMs,
                profile.jitterMs, profile.tcpLossRate, profile.retransmitTimeoutMs, bandwidth);
        }
    }
}
