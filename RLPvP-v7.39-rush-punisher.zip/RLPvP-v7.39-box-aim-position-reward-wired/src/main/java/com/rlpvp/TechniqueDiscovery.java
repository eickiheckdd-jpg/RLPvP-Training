package com.rlpvp;

import java.util.Arrays;
import java.util.Locale;

/**
 * Technique event and exchange diagnostics shared by Trainer and PvpSim.
 *
 * The default configuration is measurement-only: TECHNIQUE_REWARDS_ENABLED is false and
 * TECH_REWARD_SCALE is zero, so technique labels, style frequency, sprint-lane opportunities,
 * and jump-reset events cannot add or subtract intrinsic PPO reward.
 * Real HP dealt/taken and episode outcomes remain the learning objective. This class still records
 * event counts, win/loss outcome for each event-associated exchange, damage differential, sprint
 * follow-up conversion, and knockback-separation observations. The exchange HP totals are associated
 * with the tagged exchange window; they are not a causal attribution of every HP point to one hit.
 *
 * If a future controlled experiment enables a nonzero technique scale, all hit-style base hints are
 * neutral, use the same exchange settlement rule, and are still capped/diminished. No sprint-only
 * charge multiplier, crit-damage discount, or rarity bonus is applied.
 */
final class TechniqueDiscovery {
    static final int CRIT = 0, SPRINT_HIT = 1, KB_FOLLOWUP = 2, COMBO = 3, FIRST_HIT = 4, PUNISH = 5, DODGE = 6, JUMP_RESET = 7, SPACING = 8, BAIT = 9, W_TAP = 10, S_TAP = 11, N = 12;
    static final String[] NAMES = {"crit", "sprintHit", "kbFollowup", "combo", "firstHit", "punish", "dodge", "jumpReset", "spacing", "bait", "wTap", "sTap"};
    /** Techniques that can turn into a habit; only these are slowed down by the dominance rule. */
    /** Risky pressure techniques pay a bit more when I am behind, safe lines a bit more when I am ahead (bounded by Config.TECH_ADV_GAIN). */
    private static final int PRESS_MASK = (1 << CRIT) | (1 << SPRINT_HIT) | (1 << KB_FOLLOWUP) | (1 << COMBO) | (1 << W_TAP);
    private static final int SAFE_MASK = (1 << SPACING) | (1 << BAIT) | (1 << DODGE) | (1 << PUNISH) | (1 << S_TAP);
    private static final int STYLE_MASK = (1 << CRIT) | (1 << SPRINT_HIT) | (1 << KB_FOLLOWUP) | (1 << SPACING);
    private static final int MAX_PENDING = 4;
    private static final int FAR_PAST = -1_000_000;

    /** Per-tick input, filled by the caller from data it already computes. */
    static final class In {
        double techW;            // curriculum technique weight (0 = technique stages not reached)
        long techTicks;          // annealing clock (PpoAgent.techTicks)
        int tick;                // tick in episode
        float realDealt, taken;  // real credited damage dealt / damage taken this tick
        boolean newHit;          // first real damage credited to the latest landed swing
        double hpLead;           // (my HP - enemy HP) / 20 now: decides which lines are worth a little more (Config.TECH_ADV_*)
        double hitDist;          // centre distance to the enemy when that swing was made
        boolean hitGrounded;     // I was standing on the ground when that swing was made
        boolean hitCrit, hitSprint, hitPunish; // state of the swing that landed (HitMemory type mask / punish window)
        int fwd;                 // forward key I last applied: -1 S, 0 none, +1 W (w-tap / s-tap detection)
        boolean sprintKey;       // sprint key I last applied
        boolean airborne;        // I was not on the ground when this tick's damage landed
        double airW;             // curriculum weight of the airborne-hit penalty (Weights.airPen)
        double sepRate;          // separation speed (blocks/tick) over the ticks BEFORE this one: > 0 = the enemy is moving away
        double lateW;            // curriculum weight of the timing / momentum rules (Weights.late)
        double hitEnemyCharge;   // estimated enemy weapon charge when that swing was made (frame[42])
        boolean oppSwingStart, inTheirReach;
        double enemyFacing, mySpeed; // frame[21]; my horizontal speed in blocks/tick
        boolean jumpStart;       // a grounded jump started this tick (jump key down while on the ground, jump delay over)
        double dist;             // distance to the enemy (blocks); tells a knockback follow-up (enemy was pushed away, I closed in) from a hit that never separated
    }

    // episode state
    private int lastEventTick, lastSprintHitTick, lastWhiffTick, combo, dodgeTimer;
    private boolean firstHitDone, tookSinceSprintHit;
    private final int[] epCount = new int[N];
    private double epPaid;
    private final boolean[] pActive = new boolean[MAX_PENDING];
    private final double[][] pAmt = new double[MAX_PENDING][N];
    private final int[] pFlags = new int[MAX_PENDING];
    private final int[] pLeft = new int[MAX_PENDING];
    private final double[] pNet = new double[MAX_PENDING];
    private final double[] pDealt = new double[MAX_PENDING], pTaken = new double[MAX_PENDING];
    private final boolean[] pHit = new boolean[MAX_PENDING];
    private final boolean[] pTook = new boolean[MAX_PENDING];  // I took damage while the exchange was open
    private double curSep;                                       // separation speed before my current swing (sprint-reset momentum rule)
    private double curCharge = 1.0;                              // enemy sword charge when my current swing was made
    private double wCritDiscount;                                // window total of crit damage removed from the reward (log only)
    private final double[] hw = new double[N];                   // slow average of each technique's share (long memory, anti-fade reference)
    private final double[] share = new double[N];               // running share of recent exchanges that used each technique (kept across episodes)
    private double curLead;
    private int baitLeft, tapSlot, tapHitTick, tapState, tapType, tapAt;   // w-tap / s-tap tracker (0 idle, 1 waiting for the release, 2 waiting for the re-sprint)
    private long wBaitArmed;   // I landed a real hit while the exchange was open

    // jump reset: knockback separation tracking (measurement + the amount factor of JUMP_RESET)
    private int sinceTaken, jrCool, sepLeft;
    private boolean jrPending, sepReset;
    private int jrSlot;
    private double sepBase, sepMax, jrSep, carry, jrBase, jrSepFinal;
    private boolean jrSepDone;
    private double emaHit = 1.0;   // running average damage per landed real hit (kept across episodes): the unit of net HP
    private long wSepRn, wSepNn;
    private double wSepR, wSepN;

    // sprint-hit chain tracking (measurement only under TECH_REWARD_SCALE=0)
    private boolean sprintPending, pendingConverted, chainActive;
    private int pendingTick, chainHits, chainLastTick;
    private double pendingDist, pendingMaxDist;
    private long wSprintHits, wConverted, wChains, wChainHitsSum, wChainMax, wInterrupted, wTimedOut, wPursuit, wUnresolved;

    // window statistics
    private final long[] wEvents = new long[N], wWon = new long[N], wLost = new long[N];
    private final double[] wPaid = new double[N], wDealt = new double[N], wTaken = new double[N];
    private long wDuplicates, wCapped;
    // Swing telemetry is separate from technique-hit events: a selected ray target is not a confirmed server hit.
    private long wSwingAttempts, wTargetSelected, wWhiffs, wRepeatedWhiffs;
    private double wForfeited, wWhiffPenalty;
    private double lastScale = 1.0;

    TechniqueDiscovery() { reset(); }

    /** New episode. Window statistics are kept. */
    void reset() {
        lastEventTick = lastSprintHitTick = lastWhiffTick = FAR_PAST;
        combo = 0; dodgeTimer = 0;
        firstHitDone = false; tookSinceSprintHit = true;
        Arrays.fill(epCount, 0);
        epPaid = 0;
        Arrays.fill(pActive, false);
        baitLeft = 0; tapState = 0;
        sinceTaken = FAR_PAST; jrCool = sepLeft = 0; jrPending = sepReset = false; jrSep = 0; carry = 0;
        closeChain(0);
    }

    /** Bonus scale from the annealing clock: cosine from 1 down to TECH_FLOOR, then held at the floor. */
    static double anneal(long techTicks) {
        double floor = Math.max(0.0, Math.min(1.0, Config.TECH_FLOOR));
        if (Config.TECH_ANNEAL_TICKS <= 0 || techTicks >= Config.TECH_ANNEAL_TICKS) return floor;
        double x = Math.max(0L, techTicks) / (double) Config.TECH_ANNEAL_TICKS;
        return floor + (1.0 - floor) * 0.5 * (1.0 + Math.cos(Math.PI * x));
    }

    /** Call once per training tick. @return discovery reward to add this tick (already weighted, unscaled like Reward.tick). */
    double tick(In s) {
        double r = 0;
        curLead = s.hpLead; curCharge = s.hitEnemyCharge; curSep = s.lateW > 0 ? s.sepRate : 0.0;
        boolean pursuit = chainStep(s);
        for (int p = 0; p < MAX_PENDING; p++) {          // 1. running exchanges
            if (!pActive[p]) continue;
            pNet[p] += s.realDealt - s.taken;
            pDealt[p] += Math.max(0.0, s.realDealt);
            pTaken[p] += Math.max(0.0, s.taken);
            if (s.realDealt > 0f) pHit[p] = true;
            if (s.taken > 0f) pTook[p] = true;
            if (--pLeft[p] <= 0) r += settle(p);
        }
        if (s.taken > 0f) { combo = 0; firstHitDone = true; tookSinceSprintHit = true; }
        lastScale = anneal(s.techTicks);
        // Event detection must not depend on curriculum stage or technique weights: log the same
        // technique opportunities from the first tick, even though their intrinsic reward is off.
        boolean on = Config.TECH_DISCOVERY;
        if (Config.techniqueRewardsEnabled() && on && s.taken > 0f && s.airborne && s.airW > 0)
            r -= Config.TECH_AIR_HIT_PENALTY * Config.TECH_REWARD_SCALE * s.airW * hitUnit();
        // Detection still runs when payouts are off; all event amounts are explicitly zero.
        double scale = on && Config.techniqueRewardsEnabled() ? lastScale * s.techW : 0.0;

        // 2. defensive movement: the enemy swung at me while I was in its reach and moving, and nothing landed
        if (dodgeTimer > 0) {
            if (s.taken > 0f) { dodgeTimer = 0; wLost[DODGE]++; }
            else if (--dodgeTimer == 0) {
                wWon[DODGE]++;
                double a = capped(Config.TECH_DODGE * scale * Config.TECH_REWARD_SCALE / (1 + epCount[DODGE]) * hitUnit());
                wPaid[DODGE] += a; r += a; epCount[DODGE]++;
            }
        } else if (on && s.taken <= 0f && s.oppSwingStart
                && s.inTheirReach && s.enemyFacing >= Config.TECH_DODGE_MIN_FACING
                && s.mySpeed >= Config.TECH_DODGE_MIN_SPEED) {
            dodgeTimer = Config.TECH_DODGE_WINDOW;
            wEvents[DODGE]++;
        }

        // 2b. bait: the enemy swung at me while I stood just outside its reach (it overcommitted); my hit in the next ticks is the counter
        if (baitLeft > 0) { baitLeft--; if (s.taken > 0f) baitLeft = 0; }
        if (on && s.oppSwingStart && !s.inTheirReach && s.taken <= 0f && s.dist <= Config.TECH_BAIT_MAX_DIST && s.enemyFacing >= Config.TECH_BAIT_MIN_FACING) { baitLeft = Config.TECH_BAIT_WINDOW; wBaitArmed++; }

        // 2c. w-tap / s-tap (sprint reset): after a GROUNDED hit I let go of W (w-tap) or tap S (s-tap) within TECH_TAP_RELEASE_MAX ticks and then press W + sprint again within
        //     TECH_TAP_RESPRINT_MAX ticks. The tap joins the exchange the hit opened, so it is only paid when that exchange is won (an s-tap also needs me to take nothing back).
        if (tapState != 0) {
            int age = s.tick - tapHitTick;
            if (!on || !pActive[tapSlot] || age > Config.TECH_TAP_RELEASE_MAX + Config.TECH_TAP_RESPRINT_MAX + 2) tapState = 0;
            else if (tapState == 1) {
                if (age >= 1 && s.fwd != 1) { tapState = 2; tapType = s.fwd < 0 ? S_TAP : W_TAP; tapAt = s.tick; }
                else if (age > Config.TECH_TAP_RELEASE_MAX) tapState = 0;
            } else if (s.fwd == 1 && s.sprintKey) {
                pFlags[tapSlot] |= note(tapType, tapType == S_TAP ? Config.TECH_S_TAP : Config.TECH_W_TAP, scale, pAmt[tapSlot]);
                tapState = 0;
            } else if (s.tick - tapAt > Config.TECH_TAP_RESPRINT_MAX) tapState = 0;
        }

        // 3. a new real hit: tag which techniques it used and open an exchange
        if (s.newHit) {
            if (on && s.lateW > 0 && s.realDealt > 0f && !s.hitGrounded && !s.hitCrit && !jrPending && sepLeft <= 0) r -= Config.TECH_MISTIMED_HIT * Config.TECH_REWARD_SCALE * hitUnit();
            if (s.realDealt > 0f) emaHit = Math.max(0.25, Math.min(20.0, emaHit + 0.05 * (s.realDealt - emaHit)));
            combo++;
            boolean first = !firstHitDone;
            firstHitDone = true;
            int sinceSprint = s.tick - lastSprintHitTick;
            boolean followup = ok(KB_FOLLOWUP, s) && !tookSinceSprintHit && sinceSprint >= Config.TECH_FOLLOWUP_MIN_TICKS && sinceSprint <= Config.TECH_FOLLOWUP_MAX_TICKS;
            if (Config.techniqueRewardsEnabled() && s.tick - lastEventTick < Config.TECH_MIN_EVENT_GAP_TICKS) {
                wDuplicates++;
            } else {
                int slot = -1, oldest = 0;
                for (int p = 0; p < MAX_PENDING; p++) {
                    if (!pActive[p]) { slot = p; break; }
                    if (pLeft[p] < pLeft[oldest]) oldest = p;
                }
                if (slot < 0) { r += settle(oldest); slot = oldest; }
                double[] amt = pAmt[slot];
                Arrays.fill(amt, 0.0);
                int flags = 0;
                if (s.hitCrit) flags |= note(CRIT, Config.TECH_CRIT, scale, amt);
                if (s.hitSprint && ok(SPRINT_HIT, s)) flags |= note(SPRINT_HIT, Config.TECH_SPRINT_HIT, scale, amt);
                if (followup) flags |= note(KB_FOLLOWUP, Config.TECH_KB_FOLLOWUP * (pursuit ? Config.TECH_PURSUIT_MULT : 1.0), scale, amt);
                if (combo >= 2) flags |= note(COMBO, Config.TECH_COMBO * Math.min(combo - 1, 3), scale, amt);
                if (first) flags |= note(FIRST_HIT, Config.TECH_FIRST_HIT, scale, amt);
                if (s.hitPunish && s.hitEnemyCharge <= Config.TECH_PUNISH_MAX_ENEMY_CHARGE) flags |= note(PUNISH, Config.TECH_PUNISH, scale, amt);
                if (s.hitDist >= Config.TECH_SPACING_MIN_DIST) flags |= note(SPACING, Config.TECH_SPACING, scale, amt);
                if (baitLeft > 0) { flags |= note(BAIT, Config.TECH_BAIT, scale, amt); baitLeft = 0; }
                if (on) for (int t = 0; t < N; t++) {
                    share[t] += Config.TECH_DOMINANCE_RATE * ((((flags >> t) & 1) != 0 ? 1.0 : 0.0) - share[t]);
                    hw[t] += Config.TECH_RETAIN_DECAY * ((((flags >> t) & 1) != 0 ? 1.0 : 0.0) - hw[t]);
                }
                if (flags != 0) {
                    pActive[slot] = true; pFlags[slot] = flags;
                    tapSlot = slot; tapHitTick = s.tick; tapState = on && s.hitGrounded ? 1 : 0;
                    pLeft[slot] = Math.max(1, Config.TECH_EXCHANGE_TICKS);
                    pNet[slot] = s.realDealt - s.taken; pDealt[slot] = Math.max(0.0, s.realDealt); pTaken[slot] = Math.max(0.0, s.taken);
            pHit[slot] = false; pTook[slot] = s.taken > 0f;
                }
            }
            lastEventTick = s.tick;
            if (s.hitSprint && ok(KB_FOLLOWUP, s)) { lastSprintHitTick = s.tick; tookSinceSprintHit = false; }
        }
        r += jumpReset(s, on, scale);
        return r;
    }

    /** Knockback separation tracking and the JUMP_RESET event. @return reward from an exchange settled while making room for it. */
    private double jumpReset(In s, boolean on, double scale) {
        carry = 0;
        sinceTaken = s.taken > 0f ? 0 : Math.min(sinceTaken + 1, 1000);
        if (s.taken > 0f && sepLeft <= 0) { sepLeft = Config.TECH_JR_SEP_TICKS; sepBase = s.dist; sepMax = s.dist; sepReset = false; }
        else if (sepLeft > 0) {
            sepMax = Math.max(sepMax, s.dist);
            if (--sepLeft == 0) {                         // the knockback has played out: how far apart did it get us?
                double sep = Math.max(0.0, sepMax - sepBase);
                if (sepReset) { wSepR += sep; wSepRn++; if (jrPending && !jrSepDone) { jrSepFinal = sep; jrSepDone = true; } } else { wSepN += sep; wSepNn++; }
            }
        }
        if (jrCool > 0) jrCool--;
        if (s.jumpStart && jrCool == 0) {
            jrCool = 10;                                  // vanilla jump delay
            if (sinceTaken <= Config.TECH_JR_WINDOW && sepLeft > 0) {
                sepReset = true;
                if (on && !jrPending) {
                    int slot = -1, oldest = 0;
                    for (int p = 0; p < MAX_PENDING; p++) {
                        if (!pActive[p]) { slot = p; break; }
                        if (pLeft[p] < pLeft[oldest]) oldest = p;
                    }
                    if (slot < 0) { carry += settle(oldest); slot = oldest; }
                    Arrays.fill(pAmt[slot], 0.0);
                    int flags = note(JUMP_RESET, Config.TECH_JUMP_RESET, scale, pAmt[slot]);
                    pActive[slot] = true; pFlags[slot] = flags; pLeft[slot] = Math.max(1, Config.TECH_JR_EXCHANGE);
                    pNet[slot] = s.realDealt - s.taken; pDealt[slot] = Math.max(0.0, s.realDealt); pTaken[slot] = Math.max(0.0, s.taken);
                    pHit[slot] = false; pTook[slot] = false;
                    jrPending = true; jrSlot = slot; jrBase = sepBase; jrSepDone = false;
                }
            }
        }
        return carry;
    }

    /** Kit-aware episode length retained for compatibility with controlled technique-reward experiments. */
    /** Running average real damage per landed hit (HP): the kit's typical hit. */
    void setEpisodeTicks(int ticks) { capScale = Math.max(1.0, Math.min(4.0, ticks / (double) Config.EPISODE_TICKS)); }
    private double capScale = 1.0;

    double typicalHit() { return emaHit; }

    /** The simulator knows the kit: HP a sword hit does to it (replaces the running average at the start of an episode). */
    void setTypicalHit(double hp) { if (hp > 0.0 && Double.isFinite(hp)) emaHit = Math.max(0.25, Math.min(20.0, hp)); }

    /** What one real hit is worth in reward for this kit (the damage term of Reward.tick): the unit all technique pays are fractions of. */
    double hitUnit() { return emaHit / 20.0 * Config.W_DAMAGE * Reward.damageScale(emaHit); }

    double kitScale() { return Math.max(Config.TECH_KIT_SCALE_MIN, Math.min(1.0, emaHit / Config.TECH_HIT_REF)); }

    /** Payout factor of a won exchange from the HP it won (net dealt - taken): the same for every technique, so none is a built-in style. */
    double netFactor(double net) {
        return Math.max(Config.TECH_NET_MIN, Math.min(Config.TECH_NET_MAX, net / Math.max(1e-6, Config.TECH_NET_HITS * emaHit)));
    }

    /** Diagnostic separation factor retained for compatibility; it has no effect while technique payout is disabled. */
    static double sepFactor(double sep) {
        double span = Math.max(1e-6, Config.TECH_JR_SEP_ZERO - Config.TECH_JR_SEP_FULL);
        double x = Math.max(0.0, Math.min(1.0, (sep - Config.TECH_JR_SEP_FULL) / span));
        return 1.0 - x * (1.0 - Config.TECH_JR_MIN_FACTOR);
    }

    /**
     * Chain metrics. A chain starts at a sprint hit and goes on while I keep landing hits without taking damage, each within
     * TECH_FOLLOWUP_MAX_TICKS of the previous one. A sprint hit is "converted" when a further real hit follows it inside that window
     * with nothing taken in between. A converted hit where the enemy was knocked apart (distance grew by TECH_PURSUIT_MIN_GAP) and I
     * closed in again is a pursuit follow-up. @return true if this tick's hit is such a pursuit follow-up.
     */
    private boolean chainStep(In s) {
        boolean pursuit = false;
        if (sprintPending) pendingMaxDist = Math.max(pendingMaxDist, s.dist);
        if (chainActive && s.taken > 0f) { wInterrupted++; resolvePending(false); closeChain(0); }
        else if (chainActive && s.tick - chainLastTick > Config.TECH_FOLLOWUP_MAX_TICKS) { wTimedOut++; resolvePending(false); closeChain(0); }
        if (s.newHit) {
            if (chainActive) {
                chainHits++; chainLastTick = s.tick;
                if (sprintPending && !pendingConverted) {
                    pendingConverted = true; wConverted++;
                    if (pendingMaxDist - pendingDist >= Config.TECH_PURSUIT_MIN_GAP && s.tick - pendingTick >= Config.TECH_FOLLOWUP_MIN_TICKS) { wPursuit++; pursuit = true; }
                }
            }
            if (s.hitSprint && ok(KB_FOLLOWUP, s)) {
                wSprintHits++;
                if (!chainActive) { chainActive = true; chainHits = 1; }
                sprintPending = true; pendingConverted = false; pendingTick = s.tick; pendingDist = s.dist; pendingMaxDist = s.dist; chainLastTick = s.tick;
            } else if (!chainActive) { /* an isolated normal hit: no chain */ }
        }
        return pursuit;
    }

    private void resolvePending(boolean ended) { sprintPending = false; }

    private void closeChain(int unused) {
        if (chainActive) {
            if (sprintPending && !pendingConverted) wUnresolved++;
            if (chainHits >= 2) { wChains++; wChainHitsSum += chainHits; wChainMax = Math.max(wChainMax, chainHits); }
        }
        chainActive = false; sprintPending = false; chainHits = 0;
    }

    /** Fraction of sprint hits that were followed by at least one more successful hit (no damage taken in between). NaN without sprint hits. */
    double comboConversion() { return wSprintHits == 0 ? Double.NaN : wConverted / (double) wSprintHits; }

    /** A technique that needs a grounded swing (Config.TECH_GROUNDED_MASK) only counts when the swing was made on the ground. */
    private static boolean ok(int t, In s) { return (Config.TECH_GROUNDED_MASK & (1 << t)) == 0 || s.hitGrounded; }

    /** Legacy diagnostic curve; not used to scale reward in outcome-first mode. */
    double dominance(int t) {
        if ((STYLE_MASK & (1 << t)) == 0 || share[t] <= Config.TECH_DOMINANCE_MAX) return 1.0;
        double x = (share[t] - Config.TECH_DOMINANCE_MAX) / Math.max(1e-6, 1.0 - Config.TECH_DOMINANCE_MAX);
        return Math.max(Config.TECH_DOMINANCE_MIN, 1.0 - x * (1.0 - Config.TECH_DOMINANCE_MIN));
    }

    /** Legacy diagnostic curve; not used to scale reward in outcome-first mode. */
    double retain(int t) {
        if (hw[t] < Config.TECH_RETAIN_MIN_HW) return 1.0;
        double drop = Math.max(0.0, Math.min(1.0, ((hw[t] - share[t]) / hw[t] - Config.TECH_RETAIN_DEADBAND) / (1.0 - Config.TECH_RETAIN_DEADBAND)));
        return 1.0 + (Config.TECH_RETAIN_MAX - 1.0) * drop;
    }

    /** Real damage is never altered by the technique label; retained as a compatibility hook. */
    float rewardDamage(float realDealt, boolean crit, float enemyCharge) {
        // Never discount server-credited HP damage based on a technique label. Crit strategy is measured
        // by actual exchange outcomes and damage, not by subtracting the crit's real damage.
        return realDealt;
    }

    /** Pay multiplier for the sprint-hit chain while crits dominate: the more crit-heavy I am, the more a won sprint-hit exchange is worth (up to TECH_COMPLEMENT_MAX). */
    private double complement(int t) {
        // No technique receives a frequency-, opponent-charge-, or style-complement multiplier.
        return 1.0;
    }

    double advantage(int t) {
        double lead = Math.max(-1.0, Math.min(1.0, curLead / Config.TECH_ADV_FULL));
        if ((PRESS_MASK & (1 << t)) != 0) return 1.0 - Config.TECH_ADV_GAIN * lead;
        if ((SAFE_MASK & (1 << t)) != 0) return 1.0 + Config.TECH_ADV_GAIN * lead;
        return 1.0;
    }

    private int note(int t, double base, double scale, double[] amt) {
        wEvents[t]++;
        // Equal, neutral event bookkeeping. TECH_REWARD_SCALE=0 by default means this is telemetry only.
        amt[t] = base * scale * Config.TECH_REWARD_SCALE / (1 + epCount[t]);
        epCount[t]++;
        return 1 << t;
    }

    private double settle(int p) {
        pActive[p] = false;
        boolean won = pNet[p] > 0;
        double paid = 0;
        for (int t = 0; t < N; t++) {
            if ((pFlags[p] & (1 << t)) == 0) continue;
            wDealt[t] += pDealt[p]; wTaken[t] += pTaken[p];
            boolean ok = won;
            if (t == SPACING || t == BAIT || t == S_TAP) ok = won && !pTook[p];   // hit and stay out of its reach / counter without taking a hit back
            double amt = pAmt[p][t] * netFactor(pNet[p]) * hitUnit();   // same rule for every technique: pay by what the exchange achieved
            if (t == JUMP_RESET) {                              // needs a follow-up hit of mine, scaled by how little the knockback separated us
                jrPending = false;
                ok = won && pHit[p];
                amt *= sepFactor(jrSepDone ? jrSepFinal : Math.max(0.0, sepMax - jrBase));
            }
            if (ok) { wWon[t]++; double a = capped(amt); wPaid[t] += a; paid += a; }
            else { wLost[t]++; wForfeited += amt; }
        }
        pFlags[p] = 0; Arrays.fill(pAmt[p], 0.0); pNet[p] = pDealt[p] = pTaken[p] = 0.0;
        pLeft[p] = 0; pHit[p] = pTook[p] = false;
        return paid;
    }

    private double capped(double a) {
        if (!Config.techniqueRewardsEnabled() || a <= 0) return 0;
        double x = Math.min(a, Math.max(0.0, Math.max((double) Config.TECH_EPISODE_CAP, Config.TECH_CAP_HITS * hitUnit()) * capScale - epPaid));
        if (x < a) wCapped++;
        epPaid += x;
        return x;
    }

    /** Episode end: open exchanges are settled with the result so far. @return reward to add to the final transition. */
    double endEpisode() {
        double r = 0;
        for (int p = 0; p < MAX_PENDING; p++) if (pActive[p]) r += settle(p);
        dodgeTimer = 0;
        closeChain(0);
        return Config.techniqueRewardsEnabled() ? r : 0.0;
    }

    /**
     * Record an attempted swing and whether the client selected a target for it.
     * This is not authoritative hit confirmation. Repeated whiffs are logged, never penalized.
     */
    double onSwing(boolean targetSelected, int tick, double techW) {
        if (!Config.TECH_DISCOVERY) return 0.0;
        wSwingAttempts++;
        if (targetSelected) {
            wTargetSelected++;
            lastWhiffTick = FAR_PAST;
            return 0.0;
        }
        wWhiffs++;
        if (tick - lastWhiffTick <= Config.WHIFF_STREAK_WINDOW) wRepeatedWhiffs++;
        lastWhiffTick = tick;
        // Keep the legacy column for audit continuity; its value is deliberately zero in this build.
        return 0.0;
    }

    double scale() { return lastScale; }

    /** One-line window summary. Every technique is named, including zero-count techniques. */
    String summary() {
        StringBuilder sb = new StringBuilder(String.format(Locale.ROOT,
            "techRewards=%s scale=%.3f tech[", Config.techniqueRewardsEnabled() ? "ON" : "OFF", Config.TECH_REWARD_SCALE));
        for (int t = 0; t < N; t++) {
            if (t > 0) sb.append(' ');
            sb.append(NAMES[t]).append('=').append(wEvents[t]).append('/').append(wWon[t]).append('/').append(wLost[t]);
        }
        sb.append(String.format(Locale.ROOT,
            "] swings=%d target=%d whiff=%d repeatWhiff=%d | sprintChain hits=%d converted=%d conv=%.1f%% chains=%d avgLen=%.1f max=%d interrupted=%d timeout=%d pursuit=%d unresolved=%d",
            wSwingAttempts, wTargetSelected, wWhiffs, wRepeatedWhiffs, wSprintHits, wConverted,
            100.0 * wConverted / Math.max(1L, wSprintHits), wChains,
            wChains == 0 ? 0.0 : wChainHitsSum / (double) wChains, wChainMax,
            wInterrupted, wTimedOut, wPursuit, wUnresolved));
        if (wSepRn + wSepNn > 0) sb.append(String.format(Locale.ROOT,
            " | kb-sep jumpReset=%.2f(n=%d) noReset=%.2f(n=%d)",
            wSepRn == 0 ? 0.0 : wSepR / wSepRn, wSepRn, wSepNn == 0 ? 0.0 : wSepN / wSepNn, wSepNn));
        sb.append(String.format(Locale.ROOT, " | techniqueRewardPaid=%.4f forfeited=%.4f", totalPaid(), wForfeited));
        if (wDuplicates > 0) sb.append(" dup ").append(wDuplicates);
        if (wCapped > 0) sb.append(" capped ").append(wCapped);
        return sb.toString();
    }

    private double totalPaid() {
        double total = 0.0;
        for (double value : wPaid) total += value;
        return total;
    }

    /** Versioned v2 audit: technique events/outcomes are retained while reward is hard-disabled. */
    static String csvHeader() {
        StringBuilder sb = new StringBuilder("ticks,stage,techniqueRewardsEnabled,techniqueRewardScale,annealScale");
        for (String n : NAMES) sb.append(',').append(n).append("_events,").append(n).append("_won,").append(n)
            .append("_lost,").append(n).append("_paid,").append(n).append("_dealtHp,").append(n)
            .append("_takenHp,").append(n).append("_netHp");
        return sb.append(",swingAttempts,targetSelected,whiffs,repeatedWhiffs,duplicates,capped,forfeited,whiffStreakPenalty,sprintHits,converted,comboConversion,chains,avgChainLen,maxChain,interrupted,timedOut,pursuit,unresolvedSprintChains,jrSepReset,jrSepNone,jrResetN,jrNoneN").toString();
    }

    String csvRow(long ticks, int stage) {
        StringBuilder sb = new StringBuilder(String.format(Locale.ROOT, "%d,%d,%s,%.4f,%.4f",
            ticks, stage, Config.techniqueRewardsEnabled(), Config.TECH_REWARD_SCALE, lastScale));
        for (int t = 0; t < N; t++) sb.append(String.format(Locale.ROOT, ",%d,%d,%d,%.4f,%.4f,%.4f,%.4f",
            wEvents[t], wWon[t], wLost[t], wPaid[t], wDealt[t], wTaken[t], wDealt[t] - wTaken[t]));
        sb.append(String.format(Locale.ROOT, ",%d,%d,%d,%d,%d,%d,%.4f,%.4f,%d,%d,%.4f,%d,%.3f,%d,%d,%d,%d,%d,%.3f,%.3f,%d,%d",
            wSwingAttempts, wTargetSelected, wWhiffs, wRepeatedWhiffs, wDuplicates, wCapped, wForfeited,
            wWhiffPenalty, wSprintHits, wConverted, wSprintHits == 0 ? 0.0 : wConverted / (double) wSprintHits,
            wChains, wChains == 0 ? 0.0 : wChainHitsSum / (double) wChains, wChainMax, wInterrupted, wTimedOut,
            wPursuit, wUnresolved, wSepRn == 0 ? 0.0 : wSepR / wSepRn,
            wSepNn == 0 ? 0.0 : wSepN / wSepNn, wSepRn, wSepNn));
        return sb.toString();
    }

    void mergeWindow(TechniqueDiscovery other) {
        if (other == null) return;
        for (int t = 0; t < N; t++) {
            wEvents[t] += other.wEvents[t]; wWon[t] += other.wWon[t]; wLost[t] += other.wLost[t];
            wPaid[t] += other.wPaid[t]; wDealt[t] += other.wDealt[t]; wTaken[t] += other.wTaken[t];
        }
        wDuplicates += other.wDuplicates; wCapped += other.wCapped; wForfeited += other.wForfeited; wWhiffPenalty += other.wWhiffPenalty;
        wSwingAttempts += other.wSwingAttempts; wTargetSelected += other.wTargetSelected;
        wWhiffs += other.wWhiffs; wRepeatedWhiffs += other.wRepeatedWhiffs;
        wSprintHits += other.wSprintHits; wConverted += other.wConverted; wChains += other.wChains; wChainHitsSum += other.wChainHitsSum;
        wChainMax = Math.max(wChainMax, other.wChainMax); wInterrupted += other.wInterrupted; wTimedOut += other.wTimedOut; wPursuit += other.wPursuit; wUnresolved += other.wUnresolved;
        wSepR += other.wSepR; wSepN += other.wSepN; wSepRn += other.wSepRn; wSepNn += other.wSepNn;
        wBaitArmed += other.wBaitArmed; wCritDiscount += other.wCritDiscount;
    }

    void clearWindow() {
        Arrays.fill(wEvents, 0); Arrays.fill(wWon, 0); Arrays.fill(wLost, 0); Arrays.fill(wPaid, 0); Arrays.fill(wDealt, 0); Arrays.fill(wTaken, 0);
        wDuplicates = wCapped = 0; wForfeited = wWhiffPenalty = 0;
        wSwingAttempts = wTargetSelected = wWhiffs = wRepeatedWhiffs = 0;
        wSprintHits = wConverted = wChains = wChainHitsSum = wChainMax = wInterrupted = wTimedOut = wPursuit = wUnresolved = 0;
        wSepR = wSepN = 0; wSepRn = wSepNn = 0; wBaitArmed = 0; wCritDiscount = 0;
    }
}
