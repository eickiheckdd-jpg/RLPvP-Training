package com.rlpvp;

/**
 * Camera-control reward, shared by the mod (Trainer) and the offline simulator. No Minecraft classes.
 *
 * Goal: acquire fast (big flicks are free while far from the target), then hold the crosshair steadily, and track a moving
 * target smoothly, without the mouse flicking back and forth. Nothing here tells the agent HOW to turn; it only scores the result:
 *  1. progress     potential-based: paid for reducing the aim error, so oscillating around the target nets zero
 *  2. jerk         changing the mouse delta from one tick to the next costs, weighted by how close the aim is
 *  3. overshoot    crossing over the target (error changes sign) costs, in proportion to how far past it you ended up
 *  4. still        mouse speed costs when the crosshair is already on target (cheap while tracking, expensive when flicking)
 *  5. hold         a small bonus for being on target with an almost still mouse
 *  6. Optional legacy crit-window shaping (disabled when techniqueRewardsEnabled() is false).
 * All terms are unscaled; the caller adds them to the other per-tick reward (PpoAgent.addReward applies REWARD_SCALE).
 */
final class CameraReward {
    static final double PROGRESS = 0.03;
    static final double JERK = 0.06;
    static final double OVERSHOOT = 0.02;
    static final double OVERSHOOT_MIN_DEG = 2.0;
    static final double STILL = 0.3;
    static final double HOLD = 0.004;
    static final double HOLD_ERR_DEG = 4.0;
    static final double HOLD_MAX_DELTA = 0.05; // normalised mouse delta (0.05 = 2.25 deg/tick)
    static final double CRIT_WINDOW = 0.004;
    static final int CRIT_WINDOW_CAP = 16;
    static final int CRIT_WINDOW_MIN_STAGE = 4;
    /** Only the speed beyond what the target's own motion requires is charged as STILL. -Drlpvp.trackingStill=false restores the old behaviour. */
    static final boolean TRACKING_AWARE_STILL = !"false".equalsIgnoreCase(System.getProperty("rlpvp.trackingStill", "true"));
    /** Fraction of the target-matching speed that is free (1.0 = tracking at exactly the target's rate costs nothing). */
    static final double TRACK_CREDIT = 1.0;

    private float a1y, a1p, a2y, a2p; // last two camera deltas (normalised, clamped): a1 = the most recent
    private double prevYaw, prevPitch;
    private boolean havePrev;
    private int critTicks;
    /** Cumulative per-term totals (signed, unscaled) so a reward audit can see WHICH camera term carries the penalty. */
    static final int T_PROGRESS = 0, T_OVERSHOOT = 1, T_JERK = 2, T_STILL = 3, T_HOLD = 4, T_CRIT = 5, TERMS = 6;
    static final String[] TERM_NAMES = {"progress", "overshoot", "jerk", "still", "hold", "critWindow"};
    final double[] termSum = new double[TERMS];
    /** This tick's term values (what Reward.Telemetry accumulates per window). */
    final double[] lastTerms = new double[TERMS];

    void reset() {
        a1y = a1p = a2y = a2p = 0f;
        prevYaw = prevPitch = 0;
        havePrev = false;
        critTicks = 0;
    }

    /** Call after the policy picked its action for this tick. */
    void onAction(float yaw, float pitch) {
        a2y = a1y;
        a2p = a1p;
        a1y = Math.max(-1f, Math.min(1f, yaw));
        a1p = Math.max(-1f, Math.min(1f, pitch));
    }

    /**
     * Reward for the previous tick's camera action, computed from the state it led to.
     * @param yawErrDeg   signed yaw error to the enemy now (+ = the enemy is on the side a positive delta turns toward)
     * @param pitchErrDeg signed pitch error now
     * @param pitchFree   false while the pitch head is locked (then pitch terms are skipped)
     */
    double tick(double yawErrDeg, double pitchErrDeg, boolean pitchFree, boolean canCrit, boolean inReach, double charge, int stage) {
        double r = 0;
        double ey = Math.abs(yawErrDeg), ep = Math.abs(pitchErrDeg);
        double near = Reward.aim(ey, Config.AIM_YAW_SCALE_DEG); // ~1 on target, ~0 far away
        double py = pitchFree ? 1.0 : 0.0;
        double tProg = 0, tOver = 0;
        // Speed the mouse needs just to stay on a MOVING target. err' = err - turn + targetMove, so targetMove = (err - prevErr) + turn
        // (the sign convention above: a positive delta turns toward a positive error). Matching it is tracking, not jitter.
        double turnY = a1y * Config.YAW_SCALE, turnP = a1p * Config.PITCH_SCALE;
        double needY = 0, needP = 0;
        if (havePrev) {
            tProg += PROGRESS * (near - Reward.aim(Math.abs(prevYaw), Config.AIM_YAW_SCALE_DEG));
            if (pitchFree) tProg += PROGRESS * (Reward.aim(ep, Config.AIM_PITCH_SCALE_DEG) - Reward.aim(Math.abs(prevPitch), Config.AIM_PITCH_SCALE_DEG));
            if (prevYaw * yawErrDeg < 0 && ey > OVERSHOOT_MIN_DEG && Math.abs(a1y) > 0.02) {
                tOver -= OVERSHOOT * Math.min(ey / 10.0, 1.0);
            }
            if (TRACKING_AWARE_STILL) {
                needY = (yawErrDeg - prevYaw) + turnY;
                needP = (pitchErrDeg - prevPitch) + turnP;
            }
        }
        double tJerk = -JERK * near * (Math.abs(a1y - a2y) + py * Math.abs(a1p - a2p));
        // STILL: speed costs when on target, but only the part that is NOT tracking the target (|turn| beyond what the target itself moved).
        // The old version charged the full speed, so a perfect tracker of a strafing enemy paid a steady penalty for doing its job.
        double exY = TRACKING_AWARE_STILL ? Math.max(0.0, Math.abs(turnY) - Math.abs(needY) * TRACK_CREDIT) / Config.YAW_SCALE : Math.abs(a1y);
        double exP = TRACKING_AWARE_STILL ? Math.max(0.0, Math.abs(turnP) - Math.abs(needP) * TRACK_CREDIT) / Config.PITCH_SCALE : Math.abs(a1p);
        double tStill = -STILL * near * near * (exY * exY + py * exP * exP);
        double tHold = 0;
        if (ey < HOLD_ERR_DEG && (!pitchFree || ep < HOLD_ERR_DEG) && Math.abs(a1y) < HOLD_MAX_DELTA && Math.abs(a1p) < HOLD_MAX_DELTA) tHold = HOLD;
        // Jump-crit setup is not intrinsically rewarded in outcome-first mode.
        double tCrit = 0;
        if (Config.techniqueRewardsEnabled() && stage >= CRIT_WINDOW_MIN_STAGE && canCrit && inReach && charge >= 0.9 && critTicks < CRIT_WINDOW_CAP) {
            tCrit = CRIT_WINDOW;
            critTicks++;
        }
        lastTerms[T_PROGRESS] = tProg; lastTerms[T_OVERSHOOT] = tOver; lastTerms[T_JERK] = tJerk; lastTerms[T_STILL] = tStill; lastTerms[T_HOLD] = tHold; lastTerms[T_CRIT] = tCrit;
        termSum[T_PROGRESS] += tProg; termSum[T_OVERSHOOT] += tOver; termSum[T_JERK] += tJerk; termSum[T_STILL] += tStill; termSum[T_HOLD] += tHold; termSum[T_CRIT] += tCrit;
        r = tProg + tOver + tJerk + tStill + tHold + tCrit;
        prevYaw = yawErrDeg;
        prevPitch = pitchErrDeg;
        havePrev = true;
        return r;
    }
}