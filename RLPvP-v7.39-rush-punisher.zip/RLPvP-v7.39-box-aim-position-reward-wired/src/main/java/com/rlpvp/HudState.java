package com.rlpvp;

/**
 * Per-frame HUD state that must survive between frames: smoothed bar values, the toast, and alert detection.
 * Render thread only. No Minecraft classes.
 */
final class HudState {
    // Reused alert slots: no ArrayList, record, uppercase String, or iterator per render frame.
    private final String[] alertText = new String[6];
    private final int[] alertColors = new int[6];
    private int alertCount;

    // ---- smoothed display values (so bars glide instead of jumping every 5 ticks)
    double myHp = 20, oppHp = 20, charge = 1, dist = 4, yawErr = 0, pitchErr = 0, entropy = 0, winRate = 0;
    private long lastNanos = 0;
    private boolean primed = false;

    // ---- toast
    private String toastText = "";
    private int toastColor = HudTheme.WHITE;
    private long toastUntilMs = 0;
    private int toastPriority = 0;

    // ---- change detection
    private int lastEpisodes = -1, lastStage = -1, lastRollbacks = -1;
    private long rollbackShownUntilMs = 0;

    /** Advances the smoothing by the real time since the last frame and feeds change detection. */
    void update(RlHud.Data d) {
        long now = System.nanoTime();
        double dt = lastNanos == 0 ? 0.016 : Math.min(0.1, (now - lastNanos) / 1e9);
        lastNanos = now;
        long ms = System.currentTimeMillis();

        if (!primed || !d.inEpisode()) { // snap while idle so a new episode does not start with stale numbers
            myHp = d.myHp(); oppHp = d.oppHp(); charge = d.charge(); dist = d.dist();
            yawErr = d.yawErrDeg(); pitchErr = d.pitchErrDeg();
            primed = true;
        } else {
            myHp = approach(myHp, d.myHp(), dt, 14);
            oppHp = approach(oppHp, d.oppHp(), dt, 14);
            charge = approach(charge, d.charge(), dt, 25);
            dist = approach(dist, d.dist(), dt, 18);
            yawErr = approach(yawErr, d.yawErrDeg(), dt, 22);
            pitchErr = approach(pitchErr, d.pitchErrDeg(), dt, 22);
        }
        entropy = approach(entropy, d.entropy(), dt, 4);
        winRate = approach(winRate, d.winRate(), dt, 4);

        if (lastStage != -1 && d.stage() != lastStage) {
            toast("STAGE " + d.stage() + "  //  " + d.opponent(), HudTheme.YELLOW, 3, ms, 4000);
        }
        if (lastEpisodes != -1 && d.episodes() > lastEpisodes && !d.lastResult().isBlank()) {
            int color = d.lastResult().toLowerCase(java.util.Locale.ROOT).contains("win") ? HudTheme.GREEN : HudTheme.CYAN;
            toast("EPISODE COMPLETE  //  " + d.lastResult(), color, 2, ms, 3200);
        }
        if (lastRollbacks != -1 && d.rollbacks() > lastRollbacks) {
            rollbackShownUntilMs = ms + 8000;
            toast("Collapse guard: rolled back to best weights", HudTheme.ORANGE, 4, ms, 5000);
        }
        lastStage = d.stage();
        lastEpisodes = d.episodes();
        lastRollbacks = d.rollbacks();
    }

    private static double approach(double cur, double target, double dt, double rate) {
        double k = 1 - Math.exp(-rate * dt);
        return cur + (target - cur) * k;
    }

    // ------------------------------------------------------------------ toast
    private void toast(String text, int color, int priority, long nowMs, long durationMs) {
        boolean showing = nowMs < toastUntilMs;
        if (showing && priority < toastPriority) return; // never let a routine result replace a warning
        toastText = text;
        toastColor = color;
        toastPriority = priority;
        toastUntilMs = nowMs + durationMs;
    }

    boolean toastActive() {
        return System.currentTimeMillis() < toastUntilMs && !toastText.isEmpty();
    }

    String toastText() { return toastText; }

    int toastColor() { return toastColor; }

    /** 0..255, fading out over the last 600 ms. */
    int toastAlpha() {
        long left = toastUntilMs - System.currentTimeMillis();
        return (int) Math.max(0, Math.min(255, left * 255 / 600));
    }

    // ------------------------------------------------------------------ alerts
    /** Conditions worth a warning colour. Training-only ones are skipped in play mode. */
    int updateAlerts(RlHud.Data d) {
        int n = 0;
        long ms = System.currentTimeMillis();
        if (d.inEpisode() && d.myHp() <= 4.0) { alertText[n] = "CRITICAL HEALTH"; alertColors[n++] = HudTheme.RED; }
        if (d.inEpisode() && !d.los()) { alertText[n] = "NO LINE OF SIGHT"; alertColors[n++] = HudTheme.RED; }
        if (d.hasStats() && d.whiffRate() >= 0.40) { alertText[n] = "WHIFF RATE ELEVATED"; alertColors[n++] = HudTheme.ORANGE; }
        if (!d.play() && d.entropy() > 0 && d.entropy() < Trainer.entropyFloorNow) {
            alertText[n] = "LOW ENTROPY"; alertColors[n++] = HudTheme.entropyColor(d.entropy());
        }
        if (!d.play() && ms < rollbackShownUntilMs) { alertText[n] = "ROLLED BACK"; alertColors[n++] = HudTheme.ORANGE; }
        if (!d.play() && d.inEpisode() && d.stage() >= 6 && d.idleScale() < 0.3) {
            alertText[n] = "STALLING: NO HIT"; alertColors[n++] = HudTheme.ORANGE;
        }
        if (n > alertText.length) n = alertText.length;
        alertCount = n;
        return n;
    }

    int alertCount() { return alertCount; }
    String alertText(int index) { return alertText[index]; }
    int alertColor(int index) { return alertColors[index]; }

    int alertColor(RlHud.Data d) {
        return updateAlerts(d) == 0 ? HudTheme.GREEN : alertColors[0];
    }
}