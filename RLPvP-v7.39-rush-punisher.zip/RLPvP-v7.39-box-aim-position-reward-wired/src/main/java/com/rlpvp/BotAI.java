package com.rlpvp;

import java.util.Random;

/**
 * Scripted fighter for the AGGRESSIVE and STRONG opponents. Minecraft-free, shared by the mod (BotBrain) and the simulator (PvpSim),
 * so both train against the same opponent. It is "fair": it only knows where the agent was a few ticks ago (reaction lag 1-2 ticks),
 * turns at a limited rate with aim noise, swings only at full charge and only when its own crosshair belief is on target, and can only
 * hit what its real ray hits within reach 3.0 (a miss costs it its cooldown).
 *
 * Why this beats a pure W+D orbit (the habit the old bots allowed): the old bots aimed at where the agent WAS 2 ticks ago and only swung
 * when that stale angle was within 12 degrees, so a fast sprint-orbit stayed outside the aim window and was almost never hit.
 *  - LEAD AIM      it extrapolates the agent's velocity (from its delayed observations) over the lag + 1 tick, so a steady orbit is tracked
 *  - SWING RULE    it swings when its predicted crosshair is within the hitbox angle, not when a stale angle is "close enough"
 *  - MIRROR STRAFE it strafes the same way the agent moves sideways (in its own frame), which cancels the agent's orbit speed relative to
 *                  the bot instead of letting the agent slide out of the crosshair; it re-evaluates every 2-5 ticks, so counter-strafes work
 *  - PURSUIT       it closes in (sprinting) when the agent circles wide or keeps away for 12+ ticks; it holds a spacing ring otherwise
 *  - PUNISH        when the agent's weapon is recharging (it just swung) the bot rushes in and swings
 *  - TECHNIQUE     w-tap after a swing, safe jump-crits while the agent recharges, disengage + re-peek when behind; the RESETTER style jumps the moment it is hit
 *                  (the knockback packet no longer clears onGround, so a jump on the arrival tick overwrites the lift, as in vanilla)
 * v7.24 repertoire (every style has some of each, scaled by difficulty): w-tap AND s-tap after a swing (sprint reset), forced SPRINT HITS, far-edge SPACING pokes, BAIT feints
 * (step out while the agent's sword is charged, then punish the whiff), HIT SELECT (only trade when the agent cannot hit back), COMBO chase (stay on a knocked-back agent), jump-crits, jump resets.
 * Ten styles (adds SPACER, SELECTOR, TECHNICIAN) are picked per episode (COUNTER, PRESSURE, BAITER, RUSHER, WTAPPER, CAMPER, RESETTER) so there is no single habit to beat: a rusher that never backs off, a w-tapper
 * chaining sprint hits, a camper that holds the edge of reach and punishes whoever steps in, a jump-resetter that jumps the moment it is hit. Everything scales with
 * difficulty 0..1 (see BotDifficulty), which adapts to how well the agent is doing against it.
 */
final class BotAI {
    static final int COUNTER = 0, PRESSURE = 1, BAITER = 2, RUSHER = 3, WTAPPER = 4, CAMPER = 5, RESETTER = 6, SPACER = 7, SELECTOR = 8, TECHNICIAN = 9, HUMAN = 10, AIR_PUNISHER = 11, RUSH_PUNISHER = 12;
    static final int STYLES = 13;

    /** Styles that deliberately apply sustained forward pressure or convert knockback into follow-up attacks. */
    static boolean isAggressiveSpecialist(int style) {
        return style == PRESSURE || style == RUSHER || style == WTAPPER || style == RESETTER || style == TECHNICIAN || style == RUSH_PUNISHER;
    }

    /** Human-readable fixed style names used by league diagnostics and the held-out benchmark. */
    static String styleName(int style) {
        return switch (style) {
            case COUNTER -> "counter"; case PRESSURE -> "pressure"; case BAITER -> "baiter";
            case RUSHER -> "rusher"; case WTAPPER -> "w-tapper"; case CAMPER -> "camper";
            case RESETTER -> "jump-resetter"; case SPACER -> "spacer"; case SELECTOR -> "hit-selector";
            case TECHNICIAN -> "technician"; case HUMAN -> "human-mix"; case AIR_PUNISHER -> "air-punisher"; case RUSH_PUNISHER -> "rush-punisher"; default -> "unknown-" + style;
        };
    }

    /** Reach is measured from the eye to the nearest face of the hitbox (3.0), which is about 3.3 between centers; swing a little inside that. */
    static final double REACH_CENTER = 3.2;
    /** Ticks without a swing or a hit before a waiting style commits to the fight. */
    static final int QUIET_COMMIT = 50;

    static final class Skill {
        double lead, noise, mirror, punish, fire, critProb, spacing, reset;
        /** technique repertoire (0..1 = how often the bot uses it WHEN its situation comes up): s-tap, bait feint, hit select, sprint-hit commit, far-edge hit, combo chase */
        double stap, bait, select, sprintHit, spaceHit, combo, antiJump;
        /** AIR_PUNISHER only (0 for every other style, which then draws no extra random numbers): chance per tick to strike FIRST, with a sprint hit, the moment an airborne agent is inside reach. */
        double airPunish;
        /** v7.30 human layer: adapt = how strongly the bot reads the agent's habits and runs fight phases; wobble = slow aim drift (deg); clickDelay = max extra ticks before it clicks a ready sword; sideBias = preferred strafe side. */
        double adapt, wobble; int clickDelay, sideBias;
        /** Humanisation controls: extra reaction delay, aim overshoot ratio, and pressure error probability. */
        int reactionDelay; double overshoot, pressureMistake;
        int lag, style, tapTicks, quietCommit;
        float turn;
        boolean disengage;
    }

    static final class In {
        double bx, by, bz, byaw, bpitch, eyeY, bvy, bScale, bHp;
        boolean bGround;
        int hurtTime;
        double tx, ty, tz, tScale, tHp;
        int tHurt; // the agent's hurt timer (10 right after it was hit, counts down): used for combo chasing and hit selection
    }

    static final class Out {
        float yaw, pitch;
        int fwd, str;
        boolean sprint, jump, attack;
    }

    final In in = new In();
    final Out out = new Out();
    private final Random rng;
    private Skill sk;
    private final double[][] hist = new double[6][3]; // newest first
    private int histN, strafe, strafeHold, wtap, critTicks, farTicks, quiet;
    // ---- human layer (v7.30): fight phases, streak tracking, habit reading, attention lapses, click timing ----
    private int phase, phaseLeft, takenStreak, landStreak, streakTimer, lapseLeft, readyAge, clickWait;   // phase: 0 neutral, 1 press (I am winning the exchange), 2 reset (regroup after being hit)
    private boolean prevHurt, prevTHurt;
    private double jumpRate, closeRate = 0.5, prevTScale = 1.0, drift;
    private int baitLeft, chase, stapLeft, jumpWatch, jumpCd;
    private int humanClickCooldown;
    private boolean wasAirborne, readJump;
    private double aimMomentum;
    private boolean critArm, retreating, stapMode;

    BotAI(Random rng) {
        this.rng = rng;
    }

    void reset() {
        sk = null;
        histN = strafe = strafeHold = wtap = critTicks = farTicks = quiet = 0;
        critArm = retreating = stapMode = false; baitLeft = chase = stapLeft = jumpWatch = jumpCd = 0; wasAirborne = readJump = false;
        phase = phaseLeft = takenStreak = landStreak = streakTimer = lapseLeft = readyAge = clickWait = 0; prevHurt = prevTHurt = false; jumpRate = 0.0; closeRate = 0.5; prevTScale = 1.0; drift = 0.0; aimMomentum = 0.0; humanClickCooldown = 0;
    }

    boolean ready() {
        return sk != null;
    }

    Skill skill() {
        return sk;
    }

    /** Picks this episode's style and strengths. strong = the league's STRONG fighter (else the AGGRESSIVE one). */
    void newEpisode(boolean strong, double difficulty) { newEpisode(strong, difficulty, -1); }

    /** Fixed style is used by the Elo league; -1 preserves the old per-episode random style mixture. */
    void newEpisode(boolean strong, double difficulty, int fixedStyle) {
        double d = Math.max(0.0, Math.min(1.0, difficulty));
        Skill s = new Skill();
        double r = rng.nextDouble();
        if (strong) s.style = r < 0.06 ? COUNTER : r < 0.12 ? PRESSURE : r < 0.18 ? BAITER : r < 0.23 ? RUSHER : r < 0.29 ? WTAPPER : r < 0.33 ? CAMPER : r < 0.38 ? RESETTER
                                  : r < 0.46 ? SPACER : r < 0.54 ? SELECTOR : r < 0.64 ? TECHNICIAN : r < 0.91 ? HUMAN : r < 0.95 ? AIR_PUNISHER : RUSH_PUNISHER;
        else s.style = r < 0.20 ? PRESSURE : r < 0.31 ? RUSHER : r < 0.43 ? COUNTER : r < 0.52 ? WTAPPER : r < 0.60 ? SPACER : r < 0.68 ? SELECTOR : r < 0.78 ? TECHNICIAN : r < 0.90 ? HUMAN : r < 0.95 ? AIR_PUNISHER : RUSH_PUNISHER;
        if (fixedStyle >= 0 && fixedStyle < STYLES) s.style = fixedStyle;
        // difficulty 0 is a bot a stage-6 agent can beat (the old floor 0.30 lead / 3 deg noise / 70 % fire crushed it: win 0 %, then the agent fled)
        s.lead = 0.75 * d; // full lead (1.0) over-predicts a curving orbit and made the strongest bot WORSE (measured with BotBench)
        s.noise = 6.0 - 5.0 * d;
        s.lag = (d >= 0.55 && rng.nextBoolean()) ? 1 : 2;
        s.turn = Math.min(Config.BOT_TURN_STRONG, (float) (9.0 + 21.0 * d));
        s.mirror = Math.min(0.80, 0.80 * d + (s.style == COUNTER ? 0.05 * d : 0.0));
        s.punish = 0.10 + 0.90 * d;
        s.fire = 0.30 + 0.65 * d;
        s.critProb = 0.01 + 0.04 * d;
        s.disengage = d >= 0.6;
        // BAITER / COUNTER / CAMPER wait at the edge of reach: whoever steps in gets hit first; RUSHER lives inside it
        s.spacing = s.style == COUNTER ? 3.3 : s.style == PRESSURE || s.style == WTAPPER ? 2.5 : s.style == BAITER ? 3.6 : s.style == RUSHER ? 2.1 : s.style == CAMPER ? 3.7 : s.style == SPACER ? 3.0 : s.style == SELECTOR ? 2.9 : s.style == TECHNICIAN ? 2.9 : s.style == HUMAN ? 3.0 : 3.0;
        s.tapTicks = s.style == WTAPPER ? 1 : 2;                                  // a one-tick tap re-sprints at once: chained sprint hits
        s.reset = s.style == RESETTER ? 0.35 + 0.6 * d : 0.0;                    // jump (sprint-jump toward the enemy) when hit, on the ground
        s.quietCommit = s.style == CAMPER ? 110 : QUIET_COMMIT;
        if (s.style == RUSHER || s.style == RUSH_PUNISHER) s.fire = Math.min(1.0, s.fire + 0.1);
        // ---- technique repertoire per style (every style has a little of everything, scaled by difficulty; the signature technique is strong) ----
        double bs = 0.15 + 0.35 * d;                                              // base chance of a technique whose situation comes up
        s.stap = bs; s.bait = 0.04 + 0.08 * d; s.select = 0.0; s.sprintHit = 0.35 + 0.35 * d; s.spaceHit = 0.0; s.combo = 0.30 + 0.5 * d;
        if (s.style == WTAPPER) { s.stap = 0.05; s.sprintHit = 0.95; s.combo = 0.9; }                       // sprint hits chained through w-taps
        if (s.style == RESETTER) s.reset = Math.max(s.reset, 0.5 + 0.4 * d);
        if (s.style == BAITER) s.bait = 0.30 + 0.30 * d;                                                    // feints in and out, then counters the whiff
        if (s.style == COUNTER) { s.bait = 0.12 + 0.15 * d; s.select = 0.5 + 0.3 * d; }
        if (s.style == SPACER) { s.spaceHit = 0.85 + 0.15 * d; s.stap = 0.6 + 0.35 * d; s.sprintHit = 0.1; s.bait = 0.1; } // pokes at the far edge, s-taps back out
        if (s.style == SELECTOR) { s.select = 0.7 + 0.3 * d; s.combo = 0.9; s.critProb += 0.03; }          // only trades when the agent cannot hit back, then chains
        if (s.style == TECHNICIAN) {                                                                         // situational mix: uses whichever fits the moment
            s.stap = 0.4 + 0.3 * d; s.bait = 0.10 + 0.15 * d; s.select = 0.4 + 0.3 * d; s.spaceHit = 0.4; s.sprintHit = 0.6; s.combo = 0.85;
            s.reset = Math.max(s.reset, 0.25 + 0.4 * d); s.critProb += 0.02;
        }
        // ANTI-JUMP (gamesense vs the jump-crit loop): the agent is committed for ~12 ticks once it jumps, so a bot that reads the jump steps out of reach, lets the falling crit whiff, then punishes the landing
        s.antiJump = s.style == RUSHER ? 0.0 : s.style == PRESSURE || s.style == WTAPPER || s.style == RESETTER ? 0.15 + 0.25 * d
                   : s.style == SPACER || s.style == COUNTER || s.style == SELECTOR || s.style == TECHNICIAN || s.style == BAITER ? 0.45 + 0.45 * d : 0.3 + 0.3 * d;
        // ---- human layer: every bot has a little of it, the HUMAN style is built around it ----
        boolean human = s.style == HUMAN;
        s.adapt = human ? 0.55 + 0.4 * d : 0.20 + 0.30 * d;
        s.wobble = (human ? 1.4 : 0.6) * (1.25 - d);
        // Humans do not react on the same simulation tick: they have a few extra ticks of perception delay,
        // occasional overcorrection, and more errors while under pressure. Script profiles retain shorter delays.
        s.reactionDelay = human ? 2 + rng.nextInt(3) : (strong ? 0 : 1);
        s.overshoot = human ? 0.08 + 0.12 * (1.0 - d) : 0.025 + 0.045 * (1.0 - d);
        s.pressureMistake = human ? 0.05 + 0.10 * (1.0 - d) : 0.015 + 0.025 * (1.0 - d);
        s.clickDelay = human ? (d < 0.6 ? 2 : 1) : (d < 0.4 ? 1 : 0);
        s.sideBias = rng.nextBoolean() ? 1 : -1;
        if (human) {                       // a well-rounded player: a bit of everything, chosen by the moment (phases + habit reading below), human reaction time
            s.lag = d >= 0.7 ? 2 : 3;
            s.stap = 0.45; s.bait = 0.12 + 0.18 * d; s.select = 0.45 + 0.3 * d; s.spaceHit = 0.35; s.sprintHit = 0.65; s.combo = 0.85; s.antiJump = 0.35 + 0.35 * d;
            s.reset = Math.max(s.reset, 0.3 + 0.4 * d); s.critProb += 0.02;
        }
        if (s.style == AIR_PUNISHER) {
            // ANTI-AERIAL (how players answer jump-crit spam): stay just outside crit-entry range, read the jump and step out so the falling crit whiffs,
            // rush the landing while the agent recharges (existing punish rule), and if the agent is airborne INSIDE reach anyway, hit it first with a
            // sprint hit: its knockback breaks the crit line and an airborne player cannot strafe or re-sprint. Fair like every BotAI style: same lag, aim and cooldown.
            s.airPunish = 0.55 + 0.40 * d;
            s.antiJump = 0.95;
            s.adapt = Math.max(s.adapt, 0.55 + 0.35 * d);
            s.spacing = 3.4;
            s.sprintHit = Math.max(s.sprintHit, 0.7); s.combo = Math.max(s.combo, 0.8); s.stap = Math.max(s.stap, 0.4);
        }
        if (s.style == RUSH_PUNISHER) {
            // RUSHER + AIR PUNISHER: lives inside reach like the rusher and NEVER backs off from a jump (antiJump 0), so the air-punish strike is always in range
            // the moment the agent leaves the ground; chases and sprint-hits like the rusher, w/s-taps to keep the chain going.
            s.airPunish = 0.70 + 0.30 * d;
            s.antiJump = 0.0;
            s.spacing = 2.3;
            s.sprintHit = Math.max(s.sprintHit, 0.8); s.combo = Math.max(s.combo, 0.8); s.stap = Math.max(s.stap, 0.3);
        }
        if (s.style != RESETTER && s.style != TECHNICIAN) s.reset = Math.max(s.reset, 0.05 + 0.2 * d);    // a small jump-reset habit everywhere
        sk = s;
    }

    /** Base per-episode style probabilities of newEpisode's random mix (keep in sync with the thresholds there); index = style id. */
    static double[] mixWeights(boolean strong) {
        double[] w = new double[STYLES];
        if (strong) {
            w[COUNTER] = .06; w[PRESSURE] = .06; w[BAITER] = .06; w[RUSHER] = .05; w[WTAPPER] = .06; w[CAMPER] = .04; w[RESETTER] = .05;
            w[SPACER] = .08; w[SELECTOR] = .08; w[TECHNICIAN] = .10; w[HUMAN] = .27; w[AIR_PUNISHER] = .04; w[RUSH_PUNISHER] = .05;
        } else {
            w[PRESSURE] = .20; w[RUSHER] = .11; w[COUNTER] = .12; w[WTAPPER] = .09; w[SPACER] = .08; w[SELECTOR] = .08; w[TECHNICIAN] = .10;
            w[HUMAN] = .12; w[AIR_PUNISHER] = .05; w[RUSH_PUNISHER] = .05;
        }
        return w;
    }

    static double wrap(double a) {
        a %= 360.0;
        if (a >= 180.0) a -= 360.0;
        if (a < -180.0) a += 360.0;
        return a;
    }

    Out think(In s) {
        Skill k = sk;
        // ---- perception: the agent's position a few ticks ago, plus a velocity estimate from those delayed samples ----
        if (histN == 0) for (double[] h : hist) { h[0] = s.tx; h[1] = s.ty; h[2] = s.tz; }
        else {
            for (int i = hist.length - 1; i > 0; i--) { hist[i][0] = hist[i - 1][0]; hist[i][1] = hist[i - 1][1]; hist[i][2] = hist[i - 1][2]; }
            hist[0][0] = s.tx; hist[0][1] = s.ty; hist[0][2] = s.tz;
        }
        histN++;
        // attention lapse: a person looks away for a few ticks now and then, so its picture of the agent is older (HUMAN style mostly)
        if (lapseLeft > 0) lapseLeft--;
        else if (rng.nextDouble() < (k.style == HUMAN ? 0.006 : 0.0015) * (1.3 - 0.6 * (k.adapt > 0.5 ? 1.0 : 0.0))) lapseLeft = 3 + rng.nextInt(5);
        if (humanClickCooldown > 0) humanClickCooldown--;
        final int lag = Math.min(hist.length - 2, k.lag + k.reactionDelay + (lapseLeft > 0 ? 2 : 0));
        double[] seen = hist[lag], older = hist[lag + 1];
        double vx = seen[0] - older[0], vy = seen[1] - older[1], vz = seen[2] - older[2];
        double horizon = (lag + 1.0) * k.lead;
        double px = seen[0] + vx * horizon, pz = seen[2] + vz * horizon, py = seen[1] + Math.max(-0.6, Math.min(0.6, vy * horizon * 0.5));

        drift = 0.92 * drift + rng.nextGaussian() * k.wobble * 0.18;   // slow aim drift: a hand never holds a line perfectly
        // ---- aim at the predicted position (turn-rate limited, noisy) ----
        double dx = px - s.bx, dz = pz - s.bz, horiz = Math.hypot(dx, dz);
        double dy = (py + 0.9) - s.eyeY;
        double wantYaw = Math.toDegrees(Math.atan2(-dx, dz));
        double wantPitch = -Math.toDegrees(Math.atan2(dy, Math.max(horiz, 1e-6)));
        double rawYawError = wrap(wantYaw - s.byaw);
        double overshoot = Math.signum(rawYawError) * Math.min(Math.abs(rawYawError), k.turn * k.overshoot);
        // Add a small momentum term: a person often carries the crosshair a little past the target, then corrects.
        double aimTargetYaw = wrap(wantYaw + overshoot + aimMomentum * (k.style == HUMAN ? 0.12 : 0.04));
        double dYaw = Math.max(-k.turn, Math.min(k.turn, wrap(aimTargetYaw - s.byaw))) + rng.nextGaussian() * k.noise + drift;
        aimMomentum = 0.72 * aimMomentum + 0.28 * dYaw;
        double dPitch = Math.max(-k.turn * 0.5, Math.min(k.turn * 0.5, wantPitch - s.bpitch)) + rng.nextGaussian() * k.noise * 0.5;
        // Preserve a continuous absolute yaw; `wrap` is for shortest differences, not the stored rotation.
        out.yaw = (float) (s.byaw + dYaw);
        out.pitch = (float) Math.max(-90.0, Math.min(90.0, s.bpitch + dPitch));
        double dist = Math.sqrt(horiz * horiz + (py - s.by) * (py - s.by));
        double tol = Math.toDegrees(Math.atan2(0.36, Math.max(dist, 0.6)));  // hitbox half width 0.3 + a little anticipation
        boolean onTarget = Math.abs(wrap(wantYaw - out.yaw)) <= tol && Math.abs(wantPitch - out.pitch) <= 14.0;
        boolean ready = s.bScale >= Config.MIN_ATTACK_STRENGTH;
        readyAge = ready ? readyAge + 1 : 0;
        if (readyAge == 1) clickWait = k.clickDelay > 0 ? rng.nextInt(k.clickDelay + 1) : 0;   // a person does not click on the exact tick the sword is ready
        boolean tRecharge = s.tScale < 0.55; // the agent just swung: its weapon is dead for a moment
        boolean tHurting = s.tHurt > 0;       // the agent is in its hurt frames / knockback: it cannot trade back right now
        if (s.tHurt >= 9 && rng.nextDouble() < k.combo) chase = 8;   // COMBO: I just landed a hit: stay on it
        else if (chase > 0) chase--;
        // ---- human layer: habit reading + fight phases ----
        boolean hurtNow = s.hurtTime >= 9, tHurtNow = s.tHurt >= 9;
        boolean hurtEdge = hurtNow && !prevHurt, tEdge = tHurtNow && !prevTHurt;
        prevHurt = hurtNow; prevTHurt = tHurtNow;
        if (k.style == HUMAN && (hurtEdge || tEdge) && rng.nextDouble() < k.pressureMistake) {
            lapseLeft = Math.max(lapseLeft, 1 + rng.nextInt(3));
        }
        boolean aAir = seen[1] > s.by + 0.25;
        jumpRate += 0.01 * ((aAir ? 1.0 : 0.0) - jumpRate);          // how much the agent jumps (the jump-crit habit)
        closeRate += 0.01 * ((dist < 2.6 ? 1.0 : 0.0) - closeRate);  // how much it lives in melee range
        prevTScale = s.tScale;
        if (hurtEdge) takenStreak++;
        if (tEdge) landStreak++;
        if (++streakTimer >= 70) { streakTimer = 0; takenStreak = Math.max(0, takenStreak - 1); landStreak = Math.max(0, landStreak - 1); }
        if (phaseLeft > 0) phaseLeft--;
        if (phaseLeft == 0) phase = 0;
        if (hurtEdge && takenStreak >= 2 && phase != 2 && rng.nextDouble() < k.adapt) { phase = 2; phaseLeft = 10 + rng.nextInt(14); takenStreak = 0; chase = 0; }   // took two hits: back off and regroup
        else if (tEdge && landStreak >= 2 && phase == 0 && rng.nextDouble() < k.adapt) { phase = 1; phaseLeft = 20 + rng.nextInt(20); landStreak = 0; }               // landed two: press the advantage
        // ---- reading the agent's jump: on the rising edge decide whether to dodge back out of reach for the length of the jump ----
        boolean airborne = seen[1] > s.by + 0.25;
        if (jumpCd > 0) jumpCd--;
        if (airborne && !wasAirborne && jumpCd == 0 && !retreating && dist < 4.2 && rng.nextDouble() < Math.min(0.95, k.antiJump + k.adapt * 0.9 * Math.max(0.0, jumpRate - 0.08))) { readJump = true; jumpWatch = 14; }
        wasAirborne = airborne;
        if (jumpWatch > 0 && (--jumpWatch == 0 || !airborne || dist > 4.6)) { if (readJump) jumpCd = 24; readJump = false; jumpWatch = 0; }

        // ---- movement: spacing ring, pursuit, punish, disengage ----
        int f;
        boolean sprint = false, jump = false, attack = false;
        // nothing has happened for a while (the agent is waiting at the edge too): stop waiting and take the fight to it
        quiet = (s.hurtTime > 0) ? 0 : quiet + 1;
        boolean pushes = k.style == PRESSURE || k.style == RUSHER || k.style == RUSH_PUNISHER || k.style == WTAPPER || phase == 1;
        boolean committed = quiet > k.quietCommit || (k.adapt > 0.4 && closeRate < 0.2 && quiet > 30);   // an agent that keeps its distance gets pursued
        double spacing = committed ? Math.min(k.spacing, 2.5) : k.spacing;
        boolean behind = k.disengage && s.bHp <= 7.0 && s.tHp >= s.bHp + 3.0;
        if (behind && !ready && dist < 4.5) retreating = true;
        if (retreating && (ready || dist > 5.0 || !behind)) retreating = false;
        if (retreating) f = -1;
        else if (dist > spacing + 0.4) { f = 1; sprint = dist > (k.style == RUSHER || k.style == RUSH_PUNISHER || k.style == WTAPPER ? 2.8 : 3.9); }
        else if (dist < spacing - 0.5) f = -1;
        else f = (pushes || committed || (tRecharge && rng.nextDouble() < k.punish)) ? 1 : 0;
        if ((pushes || committed) && dist < 1.6) f = -1;
        farTicks = dist > 3.8 ? farTicks + 1 : 0;
        if (!retreating && farTicks > 12) { f = 1; sprint = true; }          // the agent keeps away: commit and chase
        if (!retreating && tRecharge && ready && dist <= 4.8) { f = 1; sprint = dist > 2.6; } // punish: rush in while its weapon recharges
        // COMBO CHASE: the agent was just knocked back: close in sprinting so the next full-charge swing is a sprint hit again
        if (!retreating && chase > 0 && dist > 1.5) { f = 1; sprint = true; }
        if (phase == 2 && !tRecharge) { f = -1; sprint = false; }          // regroup: give ground until it swings (then the punish rule above rushes it)
        // an agent that lives in melee range: step back and re-engage on my terms instead of trading at point blank
        if (k.adapt > 0.4 && closeRate > 0.6 && dist < 2.3 && !committed && !retreating && chase == 0 && rng.nextDouble() < 0.15 * k.adapt) { f = -1; sprint = false; }
        // ANTI-JUMP: back off while the agent is in the air so its falling swing whiffs; the punish rule above rushes it as soon as it lands recharging
        if (readJump && !retreating && chase == 0) { f = -1; sprint = false; }
        // BAIT: step to the edge of its reach while its sword is charged, then back off the moment it commits; the punish rule above then rushes the whiff
        if (baitLeft > 0) { baitLeft--; if (tRecharge || chase > 0) baitLeft = 0; else { f = -1; sprint = false; } } // it swung and missed: stop backing off, punish
        else if (!retreating && chase == 0 && dist < 3.3 && dist > 2.2 && s.tScale >= 0.9 && rng.nextDouble() < k.bait * 0.25) baitLeft = 4 + rng.nextInt(3);
        // SPACING: a spacer pokes from the far edge: too close, step back first
        if (k.spaceHit > 0 && !committed && !retreating && chase == 0 && dist < 2.4 && rng.nextDouble() < k.spaceHit) { f = -1; sprint = false; }

        // ---- strafe: follow the agent's sideways motion in the bot's frame so an orbit cannot slide out of the crosshair ----
        if (--strafeHold <= 0) {
            double yr = Math.toRadians(s.byaw);
            double latV = vx * -Math.cos(yr) + vz * -Math.sin(yr); // + = the agent moves to the bot's right
            if (Math.abs(latV) > 0.04 && rng.nextDouble() < k.mirror) strafe = latV > 0 ? 1 : -1;
            else strafe = rng.nextDouble() < 0.15 ? 0 : (k.adapt > 0.4 && rng.nextDouble() < 0.6 ? k.sideBias : (rng.nextBoolean() ? -1 : 1));
            strafeHold = k.adapt > 0.4 ? 3 + rng.nextInt(7) : 2 + rng.nextInt(4);   // a person holds a strafe direction for a while, with a favourite side
        }

        // ---- attack / technique ----
        // jump-crit only from a safe spot (the agent is recharging and far enough that nothing can hit me first); never instead of a plain swing
        if (!critArm && s.bGround && ready && !retreating && dist > 3.0 && dist < 3.7 && s.tScale < 0.4 && rng.nextDouble() < 0.10 + k.critProb) {
            jump = true; critArm = true; critTicks = 12;
        }
        boolean falling = !s.bGround && s.bvy < 0;
        if (critArm) {
            sprint = false;
            // swing on the way down; but a plain swing is better than waiting once the agent's weapon is back or time runs short
            if (dist <= REACH_CENTER && ready && onTarget && (falling || s.tScale >= 0.8 || critTicks <= 5)) { attack = true; critArm = false; }
            if (--critTicks <= 0) critArm = false;
        } else if (k.airPunish > 0.0 && aAir && !retreating && wtap == 0 && dist <= REACH_CENTER && ready && onTarget && lapseLeft == 0 && rng.nextDouble() < k.airPunish) {
            // AIR PUNISH: the agent left the ground inside my reach: strike first and carry the hit with sprint knockback (skips the click delay / fire roll on purpose)
            attack = true;
            if (dist > 1.2) { f = 1; sprint = true; }
            stapMode = rng.nextDouble() < k.stap * (dist < 2.8 ? 1.0 : 0.6);
            wtap = stapMode ? Math.max(1, k.tapTicks) : k.tapTicks;
        } else if (wtap > 0) {
            wtap--;
            f = stapMode ? -1 : 0; sprint = false;   // w-tap (release forward) or s-tap (tap back): both reset the sprint, the s-tap also widens the gap
        } else if (!retreating && dist <= REACH_CENTER && ready && readyAge > clickWait && lapseLeft == 0
                && (k.style != HUMAN || humanClickCooldown == 0) && (phase != 2 || tRecharge || tHurting) && onTarget && rng.nextDouble() < k.fire
                && !(k.style == HUMAN && tHurtNow && rng.nextDouble() < k.pressureMistake)) {
            // HIT SELECT: a selecting bot only trades when the agent cannot hit back (recharging / in hurt frames) or it is clearly ahead
            boolean cannotRetaliate = tRecharge || tHurting || s.bHp >= s.tHp + 3.0;
            boolean holdBack = k.select > 0 && !committed && !cannotRetaliate && chase == 0 && rng.nextDouble() < k.select;
            // FAR-EDGE HIT: a spacer only swings from the outside of its reach
            boolean tooClose = k.spaceHit > 0 && !committed && dist < 2.5 && chase == 0 && rng.nextDouble() < k.spaceHit;
            if (holdBack) { f = 0; sprint = false; }
            else if (!tooClose) {
                attack = true;
                // Human click attempts are paced at 6.7–10 CPS (2–3 ticks between attempts); vanilla weapon cooldown
                // still governs actual damage cadence. These are plausible defaults, not calibrated player telemetry.
                if (k.style == HUMAN) humanClickCooldown = 2 + rng.nextInt(2);
                // SPRINT HIT: swing while sprinting so the hit carries knockback (a plain swing at close range would not)
                if (rng.nextDouble() < k.sprintHit && dist > 1.2) { f = 1; sprint = true; }
                stapMode = rng.nextDouble() < k.stap * (dist < 2.8 ? 1.0 : 0.6);
                wtap = stapMode ? Math.max(1, k.tapTicks) : k.tapTicks;
            }
        }
        // jump reset: hit just now (hurt timer fresh), still on the ground: jump and sprint toward the enemy so the knockback is cut
        if (k.reset > 0 && s.hurtTime >= 9 && s.bGround && !critArm && rng.nextDouble() < k.reset) { jump = true; if (!retreating) { f = 1; sprint = true; } }
        if (attack) quiet = 0;
        out.fwd = f;
        out.str = strafe;
        out.sprint = sprint && f > 0;
        out.jump = jump;
        out.attack = attack;
        return out;
    }
}
