package com.rlpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Bridges an AI attack request into vanilla's own target-picking and startAttack path.
 *
 * The policy rotates/queues its click at END_CLIENT_TICK, while vanilla consumes that key
 * pulse later. The cached Minecraft.hitResult can still describe an earlier render frame.
 * Re-run GameRenderer.pick immediately before queueing and again at startAttack time, then
 * let vanilla use that freshly computed result. This deliberately delegates ray length,
 * attack_range item components, entity hitboxes, block occlusion, and target selection to
 * Minecraft 1.21.11 rather than maintaining a second, slightly different raycast here.
 */
public final class AttackHitRegistrationBridge {
    private static final long PENDING_LIFETIME_NANOS = 300_000_000L;

    private static Entity pendingTarget;
    private static long pendingUntilNanos;

    private AttackHitRegistrationBridge() {}

    /**
     * Refresh the vanilla crosshair result at the current gameplay rotation and report whether
     * vanilla itself selected the intended target. Called before emitting an AI click pulse.
     */
    public static boolean currentVanillaTarget(Minecraft mc, LocalPlayer player, Entity target) {
        if (!validContext(mc, player, target)) return false;
        mc.gameRenderer.pick(1.0f);
        return isSelectedTarget(mc, target);
    }

    /** Queue exactly one target for the click pulse emitted by ActionApplier. Client-thread only. */
    public static void queue(Entity target) {
        pendingTarget = target;
        pendingUntilNanos = System.nanoTime() + PENDING_LIFETIME_NANOS;
    }

    /** Clear an unconsumed AI request when the policy releases or skips the attack. */
    public static void clear() {
        pendingTarget = null;
        pendingUntilNanos = 0L;
    }

    /** True only while an AI click is awaiting vanilla's startAttack input handler. */
    public static boolean hasPendingRequest() {
        return pendingTarget != null;
    }

    /**
     * Called at HEAD of Minecraft.startAttack. Recalculate the real vanilla pick result as late
     * as possible. Returning false means the intended target is no longer what vanilla would hit.
     */
    public static boolean refreshVanillaTarget(Minecraft mc) {
        Entity target = pendingTarget;
        long deadline = pendingUntilNanos;
        clear();

        LocalPlayer player = mc.player;
        if (target == null || System.nanoTime() > deadline || !validContext(mc, player, target)) {
            return false;
        }

        // This is the same picker GameRenderer normally uses to update Minecraft.hitResult.
        // It honors the active held item's attack_range component and all vanilla hit selection.
        mc.gameRenderer.pick(1.0f);
        return isSelectedTarget(mc, target);
    }

    private static boolean validContext(Minecraft mc, LocalPlayer player, Entity target) {
        return mc != null && mc.gameRenderer != null && mc.gameMode != null
            && mc.level != null && mc.screen == null
            && player != null && mc.player == player && player.isAlive()
            && target != null && target != player && !target.isRemoved()
            && target.isAlive() && target.isPickable() && target.level() == mc.level;
    }

    private static boolean isSelectedTarget(Minecraft mc, Entity target) {
        return mc.hitResult instanceof EntityHitResult entityHit
            && entityHit.getEntity() == target;
    }
}
