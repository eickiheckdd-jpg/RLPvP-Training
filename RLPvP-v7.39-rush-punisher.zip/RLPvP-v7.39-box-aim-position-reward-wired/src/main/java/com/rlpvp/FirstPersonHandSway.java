package com.rlpvp;

import net.minecraft.client.player.LocalPlayer;

/**
 * Keeps Minecraft's first-person hand-bob samples on the same rotation segment as the camera.
 * ItemInHandRenderer computes hand sway from (view rotation - interpolated xBob/yBob);
 * aligning these samples removes the extra half-tick lag while leaving camera smoothing,
 * attack timing, weapon swing, and movement bobbing untouched.
 */
final class FirstPersonHandSway {
    private FirstPersonHandSway() {}

    /** Align both endpoints with the exact authoritative turn used by GlideCamera. */
    static void syncToGlideSegment(LocalPlayer player, float turnYaw, float turnPitch) {
        float endYaw = player.getYRot();
        float endPitch = player.getXRot();
        player.yBobO = endYaw - turnYaw;
        player.yBob = endYaw;
        player.xBobO = endPitch - turnPitch;
        player.xBob = endPitch;
    }

    /** Real-rotation mode updates the actual camera per frame, so its hand samples must follow that exact frame angle. */
    static void syncToCurrentAngles(LocalPlayer player) {
        float yaw = player.getYRot();
        float pitch = player.getXRot();
        player.yBobO = yaw;
        player.yBob = yaw;
        player.xBobO = pitch;
        player.xBob = pitch;
    }
}
