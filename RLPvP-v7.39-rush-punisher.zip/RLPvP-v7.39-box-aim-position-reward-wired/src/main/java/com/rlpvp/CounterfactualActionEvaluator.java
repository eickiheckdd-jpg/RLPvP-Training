package com.rlpvp;

/**
 * Scores candidate actions by expected combat consequences (hit likelihood, counter-risk, range,
 * movement, follow-up feasibility and resource costs). The consequence-model score can be supplied
 * separately; this class adds context-sensitive estimates, not named-technique reward bonuses.
 */
final class CounterfactualActionEvaluator {
    double score(SituationalStateInterpreter.State s, TacticalDecisionEngine.Decision d,
                 OpponentBehaviorModel.Profile p, EventDrivenCombatMemory.Snapshot m,
                 double predictedThreat, float[] a, double worldModelScore) {
        if (s == null || a == null || a.length < 7) return worldModelScore;
        double score = worldModelScore;
        int fwd = categorical(a[2]) - 1;
        int side = categorical(a[3]) - 1;
        boolean attack = a[4] > 0.5f, jump = a[5] > 0.5f, sprint = a[6] > 0.5f;
        boolean sneak = a.length > 7 && a[7] > 0.5f;
        double yawErr = Math.abs(s.yawErrorDeg), pitchErr = Math.abs(s.pitchErrorDeg);
        double aim = Math.exp(-yawErr / 24.0 - pitchErr / 20.0);
        double rangeChance = s.enemyInMyReach > 0.5f ? 1.0 : clamp01((Config.ATTACK_REACH + 0.38 - s.distance) / 0.75);
        double charge = clamp01((s.ownCharge - Config.MIN_ATTACK_STRENGTH_LATE) / (1.0 - Config.MIN_ATTACK_STRENGTH_LATE));
        double sight = s.lineOfSight > 0.5f ? 1.0 : 0.0;
        double hitChance = rangeChance * aim * sight * (0.30 + 0.70 * charge);
        if (s.opponentRecovering) hitChance *= 1.12;
        if (s.enemyHurt > 0.65f) hitChance *= 0.72; // invulnerability frames lower the expected value of repeated attempts
        hitChance = clamp01(hitChance);

        if (attack) {
            score += 0.34 * hitChance;
            if (!s.enemyInRange() || sight < 0.5 || yawErr > 35 || pitchErr > 30) score -= 0.30;
            if (s.ownCharge < Config.MIN_ATTACK_STRENGTH_LATE) score -= 0.22;
            if (s.enemyHurt > 0.75f && !s.opponentRecovering) score -= 0.08;
            if (s.incomingThreat && s.meInEnemyReach > 0.5f) score -= 0.10 * predictedThreat;
            if (s.followupWindow && d.intent == TacticalDecisionEngine.Intent.COMBO_FOLLOWUP) score += 0.12 * hitChance;
        }

        // Position is evaluated relative to a useful engagement band, not rewarded as raw movement.
        if (s.distance > 3.0f) {
            if (fwd > 0) score += Math.min(0.22, (s.distance - 2.8) * 0.075);
            if (fwd < 0) score -= Math.min(0.16, (s.distance - 2.8) * 0.055);
        } else if (s.distance < 1.45f) {
            if (fwd < 0) score += 0.12;
            if (fwd > 0 && !s.followupWindow && !s.opponentRecovering) score -= 0.12;
        } else if (s.distance >= 1.6f && s.distance <= 2.8f && fwd == 0) score += 0.035;

        if (s.incomingThreat || predictedThreat > 0.5) {
            if (side != 0) score += 0.11 + 0.04 * p.confidence();
            if (side != 0 && Math.abs(p.sideBias) > 0.18 && Math.signum(side) * Math.signum(p.sideBias) > 0) score -= 0.06 * p.confidence();
            if (fwd < 0 && s.distance < 2.8f && !s.followupWindow) score += 0.055;
            if (attack && s.ownCharge < 0.75f) score -= 0.06;
        }

        if (d.intent == TacticalDecisionEngine.Intent.PUNISH || d.intent == TacticalDecisionEngine.Intent.COMBO_FOLLOWUP) {
            if (fwd > 0 && s.distance > 1.6f) score += 0.09 * d.confidence;
            if (sprint && fwd > 0 && s.distance > 2.5f && !sneak) score += 0.05 * d.confidence;
        } else if (d.intent == TacticalDecisionEngine.Intent.DEFEND) {
            if (side != 0) score += 0.06 * d.confidence;
            if (fwd < 0 && s.distance < 3.0f) score += 0.04 * d.confidence;
            if (attack && !s.attackOpportunity) score -= 0.09 * d.confidence;
        } else if (d.intent == TacticalDecisionEngine.Intent.PURSUE || d.intent == TacticalDecisionEngine.Intent.ENGAGE) {
            if (fwd > 0 && s.distance > 2.7f) score += 0.07 * d.confidence;
            if (sprint && fwd > 0 && s.distance > 3.5f && s.ownCharge > 0.30f && !sneak) score += 0.04;
        } else if (d.intent == TacticalDecisionEngine.Intent.REPOSITION) {
            if (side != 0) score += 0.08 * d.confidence;
            double yawNeed = s.yawErrorDeg * a[0];
            if (Math.abs(s.yawErrorDeg) > 5) score += 0.045 * Math.signum(yawNeed);
            if (s.lineOfSight < 0.5 && attack) score -= 0.15;
        } else if (d.intent == TacticalDecisionEngine.Intent.DISENGAGE) {
            if (fwd < 0 && s.distance < 3.2f) score += 0.10 * d.confidence;
            if (fwd > 0 && s.ownHealth < 0.35f && s.distance < 2.2f) score -= 0.10;
        } else if (d.intent == TacticalDecisionEngine.Intent.BAIT) {
            if (fwd == 0 && s.distance >= 2.3f) score += 0.04 * d.confidence;
            if (attack && !s.attackOpportunity) score -= 0.08;
        }

        // Candidate actions that repeat a recently failed swing from nearly the same situation are mildly disfavoured.
        if (attack && m != null && m.repeatedWhiffRisk > 0.0 && m.lastWhiffDistance >= 0
            && Math.abs(s.distance - m.lastWhiffDistance) < 0.32
            && Math.abs(s.yawErrorDeg - m.lastWhiffYaw) < 7 && Math.abs(s.pitchErrorDeg - m.lastWhiffPitch) < 7) {
            score -= 0.11 * m.repeatedWhiffRisk;
        }

        if (sprint) {
            if (fwd <= 0 || sneak) score -= 0.16;
            else if (s.distance < 1.8f) score -= 0.06;
            else if (s.distance > 2.4f && s.ownCharge > 0.35f) score += 0.035;
        }
        if (jump) {
            if (s.incomingThreat && s.ownGround > 0.5f && s.distance < 3.2f) score += 0.04;
            if (attack && s.ownGround > 0.5f && s.enemyInMyReach > 0.5f) score -= 0.035; // jump cannot create a falling crit before this tick's click
        }
        if (s.lastSneak > 0.5f && sprint) score -= 0.10;

        // When a world-border signal exists, reject moves that deepen the edge trap; unknown boundaries score neutral.
        if (s.boundaryProximity > 0.55f) {
            double inwardDot = fwd * s.inwardForward + side * s.inwardRight;
            score += (s.boundaryProximity - 0.55) * 0.40 * inwardDot;
        }
        return Double.isFinite(score) ? score : -1e6;
    }

    private static int categorical(float v) { return Math.max(0, Math.min(2, Math.round(v))); }
    private static double clamp01(double x) { return Math.max(0.0, Math.min(1.0, x)); }
}
