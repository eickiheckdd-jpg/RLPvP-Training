package com.rlpvp;

/**
 * Positioning and combo-pressure reward terms. Minecraft-free; shared by the in-mod Trainer and the offline PvpSim trainer.
 *
 *  1. SPACE BAND     small per-tick bonus while the opponent is 2.5..3.0 blocks away (the far edge of reach: you can hit, they must step in)
 *  2. LOOK AWAY      per-tick penalty while the opponent is inside 3.0 blocks and the crosshair is more than LOOK_AWAY_DEG off it (episode capped)
 *  3. COMBO BREAK    one payment per incoming chain when the agent lands a hit while it has taken 2+ consecutive hits (extra if it was a knockback/sprint hit)
 *  4. CONSECUTIVE    each further hit taken without hitting back inside CONSEC_WINDOW_TICKS costs more than the last (capped steps)
 *  5. AIRBORNE HIT   being hit while airborne in a chain costs extra (airborne victims slide farther: friction 0.91 vs 0.546 on the ground)
 *
 * No term rewards a key pattern: W-tap / S-tap / strafe / jump-reset remain free; only their consequences (distance, aim, hits taken) are scored.
 * All constants can be overridden with -Drlpvp.pos.* system properties; -Drlpvp.positionReward=false disables the whole class.
 */
final class CombatPositionReward {
    static final boolean ENABLED = !"false".equalsIgnoreCase(System.getProperty("rlpvp.positionReward", "true"));
    static final int MIN_STAGE = Integer.getInteger("rlpvp.pos.minStage", 5);
    static final double BAND_MIN = d("bandMin", 2.5), BAND_MAX = d("bandMax", 3.0), BAND_REWARD = d("band", 0.005);
    static final double LOOK_AWAY_DIST = d("lookDist", 3.0), LOOK_AWAY_DEG = d("lookDeg", 30.0), LOOK_AWAY_PENALTY = d("lookPenalty", 0.03);
    static final double LOOK_AWAY_EPISODE_CAP = d("lookCap", 1.5);
    static final double COMBO_BREAK_REWARD = d("breakReward", 0.6), COMBO_BREAK_KNOCKBACK_BONUS = d("breakKbBonus", 0.4);
    /** 0.5 s (10 ticks) is shorter than vanilla's hit-invulnerability gap, so chained hits are never that close; 20 ticks catches W-tap combos. */
    static final int CONSEC_WINDOW_TICKS = Integer.getInteger("rlpvp.pos.consecWindow", 20);
    static final double CONSEC_HIT_PENALTY = d("consecPenalty", 0.25);
    static final int CONSEC_HIT_STEPS = Integer.getInteger("rlpvp.pos.consecSteps", 3);
    static final double AIRBORNE_HIT_PENALTY = d("airbornePenalty", 0.2);

    private static double d(String key, double def) {
        try { return Double.parseDouble(System.getProperty("rlpvp.pos." + key, Double.toString(def))); }
        catch (NumberFormatException e) { return def; }
    }

    /** Own-hit quality: a WEAK hit is a swing before the weapon recharged (< FULL_CHARGE); a SWEEP-type hit is a full-charge grounded non-sprint non-crit hit. Both pay damage already; this takes part of it back. */
    static final double WEAK_HIT_PENALTY = d("weakPenalty", 0.30), SWEEP_HIT_PENALTY = d("sweepPenalty", 0.15), HIT_QUALITY_EPISODE_CAP = d("hitQualityCap", 2.0);
    static final int T_BAND = 0, T_LOOK = 1, T_BREAK = 2, T_CONSEC = 3, T_AIR = 4, T_WEAK = 5, T_SWEEP = 6, TERMS = 7;
    static final String[] TERM_NAMES = {"band", "lookAway", "comboBreak", "consecutiveHits", "airborneHit", "weakHit", "sweepHit"};
    private boolean pendingWeak, pendingSweep;
    private double qualityPaid;
    /** Call before tick() on a tick where the agent landed a real hit: classifies that hit (full charge flag, crit, sprint, grounded at swing). */
    void noteHitType(boolean fullCharge, boolean crit, boolean sprint, boolean groundedAtSwing) {
        pendingWeak = !fullCharge;
        pendingSweep = fullCharge && !crit && !sprint && groundedAtSwing;
    }
    /** Cumulative signed totals per term (for reward audits); cleared by clearTotals(). */
    final double[] totals = new double[TERMS];
    private final double[] last = new double[TERMS];
    private int takenStreak, sinceTaken = 1000, breaks, chainsHit;
    private boolean breakPaid;
    private double lookPaid;

    void reset() {
        takenStreak = 0; sinceTaken = 1000; breakPaid = false; lookPaid = 0.0; qualityPaid = 0.0; pendingWeak = pendingSweep = false;
    }

    void clearTotals() { java.util.Arrays.fill(totals, 0.0); breaks = chainsHit = 0; }
    double lastTerm(int i) { return last[i]; }
    int comboBreaks() { return breaks; }
    double[] lastTerms() { return last; }
    int consecutiveStreak() { return takenStreak; }

    /**
     * @param stage          current curriculum stage (terms apply from MIN_STAGE)
     * @param dist           centre-to-centre distance to the opponent (blocks)
     * @param yawErrDeg      absolute yaw error to the opponent (degrees)
     * @param tookHit        the agent took real server damage this tick
     * @param airborneAtHit  the agent was off the ground when it took that hit
     * @param dealtHit       the agent landed a real credited hit this tick
     * @param knockbackHit   that landed hit carried sprint knockback
     * @return reward for this tick (already signed)
     */
    double tick(int stage, double dist, double yawErrDeg, boolean tookHit, boolean airborneAtHit, boolean dealtHit, boolean knockbackHit) {
        java.util.Arrays.fill(last, 0.0);
        // chain bookkeeping runs at every stage so the state is right when the terms switch on
        sinceTaken = tookHit ? 0 : Math.min(sinceTaken + 1, 1000);
        if (!tookHit && sinceTaken > CONSEC_WINDOW_TICKS) takenStreak = 0;
        double r = 0.0;
        boolean active = ENABLED && stage >= MIN_STAGE;
        if (tookHit) {
            if (takenStreak == 0) breakPaid = false;
            takenStreak++;
            if (active && takenStreak >= 2) {
                int steps = Math.min(takenStreak - 1, Math.max(1, CONSEC_HIT_STEPS));
                last[T_CONSEC] = -CONSEC_HIT_PENALTY * steps;
                if (airborneAtHit) last[T_AIR] = -AIRBORNE_HIT_PENALTY;
                chainsHit++;
            }
        }
        if (dealtHit && active && (pendingWeak || pendingSweep) && qualityPaid < HIT_QUALITY_EPISODE_CAP) {
            double p = Math.min(pendingWeak ? WEAK_HIT_PENALTY : SWEEP_HIT_PENALTY, HIT_QUALITY_EPISODE_CAP - qualityPaid);
            last[pendingWeak ? T_WEAK : T_SWEEP] = -p; qualityPaid += p;
        }
        pendingWeak = pendingSweep = false;
        if (dealtHit) {
            if (active && takenStreak >= 2 && !breakPaid) {
                last[T_BREAK] = COMBO_BREAK_REWARD + (knockbackHit ? COMBO_BREAK_KNOCKBACK_BONUS : 0.0);
                breakPaid = true; breaks++;
            }
            takenStreak = 0;
        }
        if (active) {
            if (dist >= BAND_MIN && dist <= BAND_MAX) last[T_BAND] = BAND_REWARD;
            if (dist < LOOK_AWAY_DIST && yawErrDeg > LOOK_AWAY_DEG && lookPaid < LOOK_AWAY_EPISODE_CAP) {
                double p = Math.min(LOOK_AWAY_PENALTY, LOOK_AWAY_EPISODE_CAP - lookPaid);
                last[T_LOOK] = -p; lookPaid += p;
            }
        }
        for (int i = 0; i < TERMS; i++) { r += last[i]; totals[i] += last[i]; }
        return r;
    }
}
