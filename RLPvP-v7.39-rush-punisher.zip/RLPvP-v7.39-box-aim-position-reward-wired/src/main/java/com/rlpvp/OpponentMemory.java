package com.rlpvp;

/**
 * Longer-term memory features appended to the summary (Config.MEMORY, 16 inputs). Descriptive only: never selects an action.
 *
 * HABITS (8, running statistics of THIS episode's opponent, warmed up as a plain mean, then an EMA): strafe activity, strafe direction
 * flip rate, sprint share, airborne share, swing rate, preferred distance, opponent radial approach pressure, and how often it hits back within 20 ticks
 * after I hit it. The same eight meanings can be supplied by the persisted, per-opponent play profile after it has enough samples.
 *
 * RECURRENT (64 by default): the hidden state of a trainable GRU cell (GruCell) driven by 18 compact fight signals. With Config.GRU_TRAIN the agent trains the cell with
 * truncated backprop through time (see PpoAgent.learnTick); the cell it uses comes from useCell(agent.gruCell()). Without an agent cell it
 * uses the untrained default, which integrates over about 3 to 100 ticks. All 16 inputs are left/right mirror-invariant, so Symmetry (which only
 * flips lateral inputs) stays exactly equivariant.
 */
final class OpponentMemory {
    static final int HABITS = 8, H = GruCell.H, X = GruCell.X, FEATURES = HABITS + H;
    private static final double ALPHA = 1.0 / 150.0;
    private static final int COUNTER_WINDOW = 20;

    private GruCell cell = GruCell.DEFAULT;
    private final float[] h = new float[H], hBefore = new float[H], x = new float[X], out = new float[H];
    private final double[] hab = new double[HABITS];
    private final int[] habN = new int[HABITS];
    private int lastSide, counterLeft;
    private boolean prevSwing;

    OpponentMemory() { reset(); }

    /** Use this (trained) cell from the next tick on. Null = the shared default. */
    void useCell(GruCell c) { cell = c == null ? GruCell.DEFAULT : c; }

    void reset() {
        java.util.Arrays.fill(h, 0f);
        java.util.Arrays.fill(hBefore, 0f);
        java.util.Arrays.fill(hab, 0.0);
        java.util.Arrays.fill(habN, 0);
        hab[7] = 0.5; habN[7] = 2;           // hit-back rate starts undecided
        lastSide = 0; counterLeft = 0; prevSwing = false;
    }

    /** Hidden state before this tick's update and this tick's cell input (for PpoAgent.noteMemory). */
    float[] hBefore() { return hBefore; }
    float[] x() { return x; }

    /** First policy input occupied by the eight opponent-habit values. */
    static int habitSlotStart() {
        if (Config.COMPACT_126) return ObsStack.HABIT_START;
        return Config.OBS_SIZE - Config.SUMMARY + Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0)
            + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0);
    }

    /** Input index of the first recurrent output inside the network observation. */
    static int slotStart() { return Config.COMPACT_126 ? ObsStack.GRU_START : habitSlotStart() + HABITS; }

    /** Shared encoder so episode-local and persistent opponent profiles have identical semantics. */
    static float encodeHabit(int index, double value) {
        double v = Double.isFinite(value) ? value : 0.0;
        double encoded = switch (index) {
            case 0, 2, 3, 7 -> 2.0 * Math.max(0.0, Math.min(1.0, v)) - 1.0;
            case 1 -> Math.max(-1.0, Math.min(1.0, v * 5.0));
            case 4 -> Math.max(-1.0, Math.min(1.0, v * 10.0));
            case 5 -> Math.max(-1.0, Math.min(1.0, v));
            case 6 -> Math.max(-1.0, Math.min(1.0, v));
            default -> 0.0;
        };
        return (float) encoded;
    }

    private void ema(int k, double v, double alpha) {
        habN[k]++;
        double a = Math.max(alpha, 1.0 / habN[k]);
        hab[k] += a * (v - hab[k]);
    }

    private static float c(float v) { return !Float.isFinite(v) ? 0f : Math.max(-1f, Math.min(1f, v)); }

    /** Call once per tick after the frame is built. dealt / taken = confirmed damage this tick. */
    void tick(float[] fr, boolean dealt, boolean taken) {
        // ---- habits ----
        float side = c(fr[17]);
        int sd = Math.abs(side) > 0.02f ? (side > 0 ? 1 : -1) : 0;
        ema(0, sd != 0 ? 1.0 : 0.0, ALPHA);                            // strafe ACTIVITY (not direction): keeps every memory input mirror-invariant, see Symmetry
        if (sd != 0) { ema(1, lastSide != 0 && sd != lastSide ? 1.0 : 0.0, ALPHA * 2); lastSide = sd; }
        ema(2, fr[22] > 0.5f ? 1.0 : 0.0, ALPHA);
        ema(3, fr[19] > 0.5f ? 0.0 : 1.0, ALPHA);
        boolean swing = fr[23] > 0.5f;
        ema(4, swing && !prevSwing ? 1.0 : 0.0, ALPHA);
        prevSwing = swing;
        ema(5, c(fr[12]), ALPHA);
        double relLen = Math.hypot(fr[9], fr[10]);
        double approach = relLen > 1e-5 ? -(fr[16] * fr[9] + fr[17] * fr[10]) / relLen : 0.0;
        ema(6, c((float) approach), ALPHA);                            // opponent's radial velocity toward me (+) or away (-)
        if (taken && counterLeft > 0) { ema(7, 1.0, 0.2); counterLeft = 0; }
        else if (counterLeft > 0 && --counterLeft == 0) ema(7, 0.0, 0.2);
        if (dealt) counterLeft = COUNTER_WINDOW;

        // ---- recurrent cell ----
        // Keep all GRU channels mirror-invariant so the symmetric PPO policy sees the same memory from either side.
        x[0] = c(fr[12]);                         // range
        x[1] = c(fr[47]);                         // relative closing speed
        x[2] = c(fr[16]);                         // target forward velocity
        x[3] = Math.abs(c(fr[17]));               // target lateral velocity magnitude
        x[4] = c(fr[18]);                         // target vertical velocity
        x[5] = swing ? 1f : 0f;                   // opponent swing state
        x[6] = fr[22] > 0.5f ? 1f : 0f;          // opponent sprint
        x[7] = c(fr[21]);                         // opponent facing pressure
        if (X >= 18) {
            x[8] = c(fr[6]);                       // own attack cooldown
            x[9] = c(fr[7]);                       // own hurt state
            x[10] = c(fr[20]);                     // opponent hurt state
            x[11] = fr[4] > 0.5f ? 1f : 0f;       // own ground contact
            x[12] = fr[19] > 0.5f ? 1f : 0f;      // opponent ground contact
            x[13] = fr[43] > 0.5f ? 1f : 0f;      // own crit eligibility
            x[14] = dealt ? 1f : 0f;               // confirmed damage dealt
            x[15] = taken ? 1f : 0f;               // confirmed damage taken
            x[16] = fr[26] > 0.5f ? 1f : 0f;      // line of sight
            x[17] = fr[44] - fr[45];               // relative reach threat
        }
        System.arraycopy(h, 0, hBefore, 0, H);
        cell.step(h, x, out);
    }

    void fillSummary(float[] summary) {
        if (!Config.MEMORY) return;
        int off = Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0) + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0);
        if (summary.length < off + FEATURES) return;
        for (int k = 0; k < HABITS; k++) {
            summary[off + k] = encodeHabit(k, hab[k]);
        }
        for (int j = 0; j < H; j++) summary[off + HABITS + j] = h[j];
    }
}
