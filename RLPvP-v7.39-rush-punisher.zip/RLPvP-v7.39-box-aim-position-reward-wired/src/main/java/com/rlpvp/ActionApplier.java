package com.rlpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Applies the policy to the local player. Camera turns use the shared mouse-like rotation controller; movement inputs use the
 * actual Minecraft key bindings; attacks are emitted as KeyMapping click pulses for vanilla to consume on its normal input path.
 * The intended entity is rebound to Minecraft's live hit result immediately before vanilla handles that click, so stale
 * render-frame MISS/block results cannot silently turn a target attack into an empty swing.
 */
final class ActionApplier {
    static final int SWING_NONE = 0;
    static final int SWING_HIT_TARGET = 1;
    static final int SWING_HIT_OTHER = 2;
    static final int SWING_MISS = 3;

    private final GameplayRotation rot = new GameplayRotation();
    private double aimYawErr, aimPitchErr;
    private boolean aimPitchFree, aimErrKnown;
    private float lastYawDelta, lastPitchDelta;
    private long clicksQueued;
    private long lastClickMillis;
    private boolean attackKeyDown;
    private int lastSwingResult = SWING_NONE;
    private float lastAttackThreshold = Config.VANILLA_ATTACK_MIN_CHARGE;
    private int heldStrafeDirection; // -1 left, +1 right, reset by an explicit neutral command

    /** @return best-effort predicted result for the click queued this tick. Vanilla resolves the actual hit on its standard input path. */
    int apply(Minecraft mc, LocalPlayer me, float[] a, Entity target, float minCharge) {
        GlideReal.finish(me);
        // action = {yaw effort, pitch effort, fwd, strafe, attack, jump, sprint, sneak, conditional hold-strafe}
        int fwd = Math.round(a[2]) - 1;
        int strafe = StrafeAction.resolve(Math.round(a[3]), a.length > 8 && a[8] > 0.5f, heldStrafeDirection);
        heldStrafeDirection = strafe;
        a[3] = StrafeAction.category(strafe); // keep action-history features aligned with the input actually held
        boolean attack = a[4] == 1;
        boolean jump = a[5] == 1;
        boolean sprint = a[6] == 1;
        boolean sneak = a.length > 7 && a[7] == 1;

        Options o = mc.options;
        o.keyUp.setDown(fwd > 0);
        o.keyDown.setDown(fwd < 0);
        o.keyLeft.setDown(strafe < 0);
        o.keyRight.setDown(strafe > 0);
        o.keyJump.setDown(jump);
        o.keySprint.setDown(sprint && fwd > 0 && !sneak);
        o.keyShift.setDown(sneak);

        // Update the camera before queuing the click. The queued input is consumed by vanilla on its next ordinary input pass.
        // Live mouse-count quantization must match the player's actual Minecraft sensitivity.
        // The resulting deltas remain whole legal counts with fractional remainder carried by GameplayRotation.
        if (o.sensitivity() != null) rot.setMouseSensitivity(o.sensitivity().get());
        double cy = CameraMap.apply(GameplayRotation.sane(a[0])) * Config.YAW_SCALE;
        double cp = CameraMap.apply(GameplayRotation.sane(a[1])) * Config.PITCH_SCALE;
        float oldYaw = me.getYRot();
        float oldPitch = me.getXRot();
        // FIRST smooth the actual gameplay rotation (input filter + bounded physical mouse acceleration/jerk + predictive
        // stop brake). These deltas, not the raw policy action, are authoritative for hit rays, attacks and observations.
        rot.stepEffort(cy, cp, oldYaw, oldPitch, aimYawErr, aimPitchErr, aimErrKnown, aimPitchFree, Config.AIM_BRAKE);
        lastYawDelta = rot.dYaw;
        lastPitchDelta = rot.dPitch;
        // The display bridge receives only the rotation that actually got applied. It interpolates this tick's endpoints;
        // it must not invent a second velocity-driven camera path.
        GlideCamera.push(rot.dYaw, rot.yaw.vel(), rot.dPitch, rot.pitch.vel());
        me.setYRot(rot.newYaw);
        me.setXRot(rot.newPitch);
        GlideCamera.markReal(oldYaw, oldPitch, rot.newYaw, rot.newPitch);

        int result = SWING_NONE;
        lastAttackThreshold = Float.isFinite(minCharge) ? Math.max(0.0f, Math.min(1.0f, minCharge)) : Config.VANILLA_ATTACK_MIN_CHARGE;
        boolean chargeReady = me.getAttackStrengthScale(0.5f) >= lastAttackThreshold;
        boolean targetInRay = attack && chargeReady && target != null
            && AttackHitRegistrationBridge.currentVanillaTarget(mc, me, target);
        if (attack && chargeReady && mc.gameMode != null && targetInRay && mc.screen == null) {
            // Queue the intended entity for a fresh vanilla pick immediately before this click is
            // consumed. The cached hit result may otherwise still describe the previous render frame.
            AttackHitRegistrationBridge.queue(target);
            KeyMappingClick.pulse();
            clicksQueued++;
            lastClickMillis = System.currentTimeMillis();
            attackKeyDown = true;
            result = SWING_HIT_TARGET; // client-side target selection estimate, not server-confirmed damage
        } else {
            AttackHitRegistrationBridge.clear();
            KeyMappingClick.release();
            attackKeyDown = false;
        }
        lastSwingResult = result;
        return result;
    }

    /** Yaw / pitch error used to set the predictive camera braking envelope. */
    void setAimError(double yawErrDeg, double pitchErrDeg, boolean pitchFree) {
        aimYawErr = yawErrDeg;
        aimPitchErr = pitchErrDeg;
        aimPitchFree = pitchFree;
        aimErrKnown = true;
    }
    void noAimError() { aimErrKnown = false; }

    void holdCamera(LocalPlayer me) {
        GlideReal.finish(me);
        float oldYaw = me.getYRot(), oldPitch = me.getXRot();
        rot.hold(oldYaw, oldPitch);
        GlideCamera.push(rot.dYaw, rot.yaw.vel(), rot.dPitch, rot.pitch.vel());
        me.setYRot(rot.newYaw);
        me.setXRot(rot.newPitch);
        GlideCamera.markReal(oldYaw, oldPitch, rot.newYaw, rot.newPitch);
    }

    float velYawNorm() { return (float) (rot.yaw.vel() / Config.YAW_SCALE); }
    float velPitchNorm() { return (float) (rot.pitch.vel() / Config.PITCH_SCALE); }
    float yawDelta() { return lastYawDelta; }
    float pitchDelta() { return lastPitchDelta; }
    double rawYawCommandDpt() { return rot.requestedYawCommand(); }
    double rawPitchCommandDpt() { return rot.requestedPitchCommand(); }
    double filteredYawCommandDpt() { return rot.filteredYawCommand(); }
    double filteredPitchCommandDpt() { return rot.filteredPitchCommand(); }
    double yawVelocityDpt() { return rot.yaw.vel(); }
    double pitchVelocityDpt() { return rot.pitch.vel(); }
    double inputFilterAlpha() { return rot.inputFilterAlpha(); }
    boolean attackKeyDown() { return attackKeyDown; }
    long clicksQueued() { return clicksQueued; }
    long lastClickMillis() { return lastClickMillis; }
    int lastSwingResult() { return lastSwingResult; }
    float attackThreshold() { return lastAttackThreshold; }

    /** Release all held input and reset camera state when AI stops or an episode ends. */
    void release(Minecraft mc) {
        rot.reset();
        GlideCamera.reset();
        heldStrafeDirection = 0;
        aimErrKnown = false;
        attackKeyDown = false;
        lastSwingResult = SWING_NONE;
        AttackHitRegistrationBridge.clear();
        Options o = mc.options;
        if (o == null) return;
        o.keyUp.setDown(false);
        o.keyDown.setDown(false);
        o.keyLeft.setDown(false);
        o.keyRight.setDown(false);
        o.keyJump.setDown(false);
        o.keySprint.setDown(false);
        o.keyShift.setDown(false);
        KeyMappingClick.release();
    }

    /** Centralizes the vanilla KeyMapping pulse used by the AI. */
    private static final class KeyMappingClick {
        private static final com.mojang.blaze3d.platform.InputConstants.Key KEY =
            com.mojang.blaze3d.platform.InputConstants.Type.MOUSE.getOrCreate(0);
        private static void pulse() {
            net.minecraft.client.KeyMapping.set(KEY, true);
            net.minecraft.client.KeyMapping.click(KEY);
        }
        private static void release() { net.minecraft.client.KeyMapping.set(KEY, false); }
    }
}
