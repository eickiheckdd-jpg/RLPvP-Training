package com.rlpvp;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Builds the network input. One "frame" is 48 floats for the current tick, all relative to the
 * agent's own facing and clamped to [-1, 1]. The network input is stacked by ObsStack at the lags in
 * Config.LAGS (0, 1, 4, 16 ticks ago) = 192 floats.
 *
 * Frame layout:
 *   0  own health            1  own forward vel      2  own right vel       3  own vertical vel
 *   4  own on ground         5  own sprinting        6  own attack cooldown 7  own hurt timer
 *   8  own pitch
 *   9  enemy rel forward    10  enemy rel right     11  enemy rel up       12  distance
 *  13  yaw error to enemy   14  pitch error to enemy
 *  15  enemy health         16  enemy fwd vel       17  enemy right vel    18  enemy vertical vel
 *  19  enemy on ground      20  enemy hurt timer    21  enemy looking at me
 *  22  enemy sprinting      23  enemy swinging (1 while its attack animation plays)
 *  24  ticks since I hit    25  ticks since I was hit    26  line of sight (1 = clear)
 *  27  reserved camera slot (kept zero for checkpoint compatibility)
 *  28  reserved camera slot (kept zero for checkpoint compatibility)
 *  29  my last fwd/back    30  my last strafe
 *  31  my last attack       32  my last jump         33  my last sprint
 *  34  ticks since the enemy started a swing (0 = it just swung: its weapon is on cooldown now)
 *  40  yaw error, sign * sqrt(|err|/180)   41  pitch error, sign * sqrt(|err|/90)  (magnifies small aim errors)
 *  35..39  curriculum locks, 1 = this head is locked right now (pitch, fwd/back, strafe, jump, sprint)
 *  42  enemy weapon charge 0..1, estimated from the time since it last swung (its real cooldown is not synced to us)
 *  43  can crit: falling and not sprinting (a hit now is a jump-crit)
 *  44  enemy inside MY reach        45  I am inside THEIR reach (eye to hitbox, vanilla reach)
 *  46  ticks since MY last swing / 20
 *  47  closing speed along the line to the enemy (+1 = we approach each other fast, -1 = moving apart)
 */
final class Observation {
    /**
     * Encodes the last action into 7 floats in [-1, 1]. The two camera slots carry the camera's VELOCITY STATE after this tick's step
     * (CameraDynamics.vel() / axis scale), not the raw hand-effort command: the mouse controller has drag and velocity state, so the command alone does not describe actual movement.
     */
    static void encodeAction(float[] a, double velYawNorm, double velPitchNorm, float[] out) {
        out[0] = ssqrt((float) Math.max(-1.0, Math.min(1.0, velYawNorm)));  // normalised velocity, sqrt-compressed so tiny moves are visible
        out[1] = ssqrt((float) Math.max(-1.0, Math.min(1.0, velPitchNorm)));
        out[2] = a[2] - 1;
        out[3] = a[3] - 1;
        out[4] = a[4];
        out[5] = a[5];
        out[6] = a[6];
    }

    /**
     * @param lastAct        7 floats from encodeAction() for the action chosen on the previous tick (zeros at episode start)
     * @param sinceOppSwing  ticks since the enemy last started a swing (cap 40)
     * @param sinceMySwing   ticks since I last swung (cap 40)
     */
    static float[] frame(Player me, Player opp, Vec3 myVel, Vec3 oppVel,
                         int sinceDealt, int sinceTaken, float[] lastAct, int sinceOppSwing, int sinceMySwing, int lockMask) {
        float[] f = new float[Config.FRAME];
        double yawRad = Math.toRadians(me.getYRot());
        double fx = -Math.sin(yawRad), fz = Math.cos(yawRad);   // forward (x, z)
        double rx = -Math.cos(yawRad), rz = -Math.sin(yawRad);  // right (x, z)

        Vec3 d = opp.position().subtract(me.position());
        double horiz = Math.sqrt(d.x * d.x + d.z * d.z);
        double dist = d.length();

        int i = 0;
        f[i++] = c(me.getHealth() / 20.0);
        f[i++] = c((myVel.x * fx + myVel.z * fz) / 0.6);
        f[i++] = c((myVel.x * rx + myVel.z * rz) / 0.6);
        f[i++] = c(myVel.y / 0.8);
        f[i++] = me.onGround() ? 1f : 0f;
        f[i++] = me.isSprinting() ? 1f : 0f;
        f[i++] = c(me.getAttackStrengthScale(0.5f));
        f[i++] = c(me.hurtTime / 10.0);
        f[i++] = c(me.getXRot() / 90.0);

        f[i++] = c((d.x * fx + d.z * fz) / 6.0);
        f[i++] = c((d.x * rx + d.z * rz) / 6.0);
        f[i++] = c(d.y / 3.0);
        f[i++] = c(dist / 6.0);
        double desiredYaw = Math.toDegrees(Math.atan2(-d.x, d.z));
        f[i++] = c(Mth.wrapDegrees(desiredYaw - me.getYRot()) / 180.0);
        double dy = opp.getY(0.5) - me.getEyeY();
        double desiredPitch = -Math.toDegrees(Math.atan2(dy, Math.max(horiz, 1e-6)));
        f[i++] = c((desiredPitch - me.getXRot()) / 90.0);

        f[i++] = c(opp.getHealth() / 20.0);
        f[i++] = c((oppVel.x * fx + oppVel.z * fz) / 0.6);
        f[i++] = c((oppVel.x * rx + oppVel.z * rz) / 0.6);
        f[i++] = c(oppVel.y / 0.8);
        f[i++] = opp.onGround() ? 1f : 0f;
        f[i++] = c(opp.hurtTime / 10.0);
        Vec3 look = opp.getLookAngle();
        double facing = 0;
        if (dist > 1e-6) facing = (look.x * -d.x + look.y * -d.y + look.z * -d.z) / dist;
        f[i++] = c(facing);
        f[i++] = opp.isSprinting() ? 1f : 0f;
        f[i++] = opp.swinging ? 1f : 0f;

        f[i++] = c(sinceDealt / 40.0);
        f[i++] = c(sinceTaken / 40.0);
        f[i++] = me.hasLineOfSight(opp) ? 1f : 0f; // nothing solid between us (pillars / walls)
        for (int k = 0; k < 7; k++) f[i++] = c(lastAct[k]);
        f[27] = 0f; f[28] = 0f; // own last camera deltas are NOT shown: the policy used them to cancel its own sampling noise and oscillated when run without noise
        f[i++] = c(sinceOppSwing / 20.0);
        ActionMask.flags(lockMask, f, i);
        i += ActionMask.N_FLAGS;
        f[i++] = ssqrt(f[13]);
        f[i++] = ssqrt(f[14]);

        // ---- timing signals ----
        f[i++] = c((sinceOppSwing + 0.5) / Config.ENEMY_CHARGE_TICKS);
        f[i++] = (!me.onGround() && myVel.y < 0 && !me.isSprinting()) ? 1f : 0f;
        f[i++] = reachSq(me.getX(), me.getEyeY(), me.getZ(), opp) <= Config.ATTACK_REACH * Config.ATTACK_REACH ? 1f : 0f;
        f[i++] = reachSq(opp.getX(), opp.getEyeY(), opp.getZ(), me) <= Config.ATTACK_REACH * Config.ATTACK_REACH ? 1f : 0f;
        f[i++] = c(sinceMySwing / 20.0);
        double closing = 0;
        if (horiz > 1e-6) closing = ((myVel.x - oppVel.x) * d.x + (myVel.z - oppVel.z) * d.z) / horiz;
        f[i++] = c(closing / 0.6);
        f[i++] = me.isCrouching() ? 1f : 0f;                          // 48: I am sneaking
        f[i++] = opp.isCrouching() ? 1f : 0f;                         // 49: the enemy is sneaking
        f[i++] = (lockMask & ActionMask.LOCK_SNEAK) != 0 ? 1f : 0f;   // 50: my sneak head is locked
        return ObservationRegistry.apply(f);
    }

    /**
     * Signed attack-reach margin from the agent's eye to the closest point on the opponent hitbox.
     * Positive means the hitbox is within the configured reach; this is more faithful than using centre distance.
     */
    static double reachMargin(Player me, Player target) {
        double distance = Math.sqrt(reachSq(me.getX(), me.getEyeY(), me.getZ(), target));
        return Config.ATTACK_REACH - distance;
    }

    /**
     * Writes signed target-centre error normalized by the projected half-width/half-height of its
     * actual bounding box. These are perception features only; they do not steer the camera.
     */
    static void crosshairBoxError(Player me, Player target, float[] out) {
        if (me == null || target == null || out == null || out.length < 2) return;
        var box = target.getBoundingBox();
        AimGeometry.normalizedError(me.getX(), me.getEyeY(), me.getZ(), me.getYRot(), me.getXRot(),
            box.minX, box.maxX, box.minY, box.maxY, box.minZ, box.maxZ, out, 0);
    }

    /** True when the current look ray intersects the opponent hitbox within the normal attack reach. */
    static boolean crosshairOnTargetBox(Player me, Player target) {
        Vec3 start = me.getEyePosition();
        Vec3 end = start.add(me.getViewVector(1.0f).scale(Config.ATTACK_REACH));
        var box = target.getBoundingBox().inflate(target.getPickRadius());
        boolean onBox = box.contains(start) || box.clip(start, end).isPresent();
        return onBox && me.hasLineOfSight(target);
    }

    /** Squared distance from a point (an eye) to the nearest point of {@code target}'s hitbox (upright box, width / height from the entity). */
    private static double reachSq(double ex, double ey, double ez, Player target) {
        double hw = target.getBbWidth() * 0.5, h = target.getBbHeight();
        double dx = Math.max(Math.max(target.getX() - hw - ex, 0), ex - (target.getX() + hw));
        double dy = Math.max(Math.max(target.getY() - ey, 0), ey - (target.getY() + h));
        double dz = Math.max(Math.max(target.getZ() - hw - ez, 0), ez - (target.getZ() + hw));
        return dx * dx + dy * dy + dz * dz;
    }

    private static float ssqrt(float v) {
        return Math.signum(v) * (float) Math.sqrt(Math.abs(v));
    }

    private static float c(double v) {
        if (Double.isNaN(v)) return 0f;
        return (float) Math.max(-1.0, Math.min(1.0, v));
    }
}