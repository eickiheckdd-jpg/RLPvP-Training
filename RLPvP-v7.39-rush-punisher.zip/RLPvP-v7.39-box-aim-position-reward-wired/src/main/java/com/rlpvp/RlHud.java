package com.rlpvp;

import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/**
 * RLPvP combat HUD (v11 "Instrument Deck").
 *
 * <p>A set of independent chamfered instruments laid out in two edge columns, a crosshair assist and an alert strip.
 * Nothing here mutates gameplay: every value comes from the immutable {@link Data} snapshot built by {@code Trainer.hud()}.
 *
 * <h3>Structure of this file</h3>
 * <ol>
 *   <li>{@link Data} snapshot, {@link View} presets and {@link Settings} (visibility, opacity, per-widget toggles, side flip).</li>
 *   <li>{@link #render} entry point, view composition and the auto-stacking {@link Column} layout.</li>
 *   <li>{@link Anim}: frame-to-frame state (reveal, hit flashes, ghost HP, CPS, histories, radar trail, closing speed).</li>
 *   <li>Widgets: input stream, aim rate dials, aim pipeline, target lock, live signals, radar, combat intel, motion,
 *       training (full + compact), crosshair assist, alert strip, mini bar, toast.</li>
 *   <li>{@link Gfx}: shape and text primitives (chamfer facets, arcs, lines, gradients, chips, meters).</li>
 * </ol>
 * Layout is height-aware: a widget that would run into the hotbar area is skipped instead of overlapping, so the HUD
 * degrades gracefully on small GUI-scaled windows.
 */
final class RlHud {
    private RlHud() {}

    // ======================================================================================================== constants
    static final int KEY_W = 1, KEY_A = 1 << 1, KEY_S = 1 << 2, KEY_D = 1 << 3;
    static final int KEY_SHIFT = 1 << 4, KEY_SPRINT = 1 << 5, KEY_JUMP = 1 << 6;

    /** Widget ids (bit flags used by {@link Settings#widgets}). */
    static final int W_INPUT = 1, W_AIM = 1 << 1, W_PIPE = 1 << 2, W_TARGET = 1 << 3, W_SIGNALS = 1 << 4, W_RADAR = 1 << 5,
        W_INTEL = 1 << 6, W_MOTION = 1 << 7, W_TRAIN = 1 << 8, W_CROSS = 1 << 9, W_ALERTS = 1 << 10,
        W_ACCURACY = 1 << 11, W_TIMELINE = 1 << 12, W_FEED = 1 << 13, W_PERF = 1 << 14, W_LADDER = 1 << 15, W_TAPE = 1 << 16;
    private static final int W_ALL = (1 << 17) - 1;
    private static final String[] WIDGET_NAMES = {"input", "aim", "pipeline", "target", "signals", "radar", "intel", "motion", "training", "crosshair", "alerts", "accuracy", "timeline", "feed", "perf", "ladder", "tape"};

    private static final int MARGIN = 6, GAP = 4, BOTTOM_RESERVE = 26, RADAR_RANGE_M = 8;
    private static final int H_INPUT = 56, H_AIM = 58, H_PIPE = 78, H_TARGET = 84, H_SIGNALS = 92, H_RADAR = 94, H_INTEL = 76, H_MOTION = 54;
    private static final int H_TRAIN_COMPACT = 63, H_TRAIN_FULL = 178, H_ACCURACY = 92, H_TIMELINE = 76, H_PERF = 62;
    private static final int FEED_LINES = 6;
    private static final long FEED_LIFE_MS = 7000;
    private static final long KEY_HEAT_MS = 440, CLICK_FLASH_MS = 140, SWING_CHIP_MS = 1100;

    // ======================================================================================================== snapshot
    record Data(boolean active, boolean play, int stage, int stages, String opponent, String locks, int lockBits,
                long ticks, int updates, int episodes, double progress,
                double entropy, double ret, double winRate, double lossRate, double dealt, double taken, boolean hasStats,
                double whiffRate, double critShare, double sprintShare, int rollbacks, double shaping, double idleScale,
                boolean inEpisode, int epTick, int epTicks,
                double myHp, double oppHp, double dist, double charge, double attackThreshold, double yawErrDeg, double pitchErrDeg, boolean los,
                float[] retHist, byte[] resHist, float[] entHist, String lastResult,
                String target, String intent, double intentConfidence, long safetyInterventions,
                long rejectedAttacks, long correctedSprints, long boundaryCorrections,
                double yawRequestedDpt, double pitchRequestedDpt, double yawFilteredDpt, double pitchFilteredDpt,
                double yawActualDpt, double pitchActualDpt, double yawVelocityDpt, double pitchVelocityDpt,
                double filterAlpha, boolean attackKeyDown, long clicksQueued, long lastClickMillis, int lastSwingResult,
                double ownMotion, double enemyMotion, double currentEpisodeReturn,
                int inputMask, double mapRight, double mapForward) {
        static final Data OFF = new Data(false, false, 1, Curriculum.STAGES, "-", "none", 0,
            0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, false,
            0, 0, 0, 0, 1, 1,
            false, 0, Config.EPISODE_TICKS,
            20, 20, 0, 1, Config.VANILLA_ATTACK_MIN_CHARGE, 0, 0, true,
            new float[0], new byte[0], new float[0], "",
            "NO TARGET", "STANDBY", 0, 0,
            0, 0, 0,
            0, 0, 0, 0,
            0, 0, 0, 0, 1,
            false, 0, 0, ActionApplier.SWING_NONE,
            0, 0, 0,
            0, 0, 0);

        /** True while a target is tracked and the per-episode fields are meaningful. */
        boolean live() { return inEpisode; }
        /** Own health minus the opponent's, in hit points. */
        double hpLead() { return myHp - oppHp; }
        /** Fraction of the episode time budget already used (0..1). */
        double episodeFraction() { return epTicks <= 0 ? 0 : Math.max(0, Math.min(1, epTick / (double) epTicks)); }
        /** Win rate shown as a percentage, or -1 when there is no sample yet. */
        double winPct() { return hasStats ? winRate * 100.0 : -1; }
    }

    // ======================================================================================================== views & settings
    enum View {
        /** Combat instruments, plus a compact training widget while learning. */
        AUTO,
        /** Combat instruments only. */
        COMBAT,
        /** Training panel only. */
        TRAINING,
        /** Aim pipeline, motion and combat intelligence: the tuning view. */
        DIAG,
        /** Everything the screen can hold. */
        FULL,
        /** Review view: swing accuracy, duel timeline and session performance. */
        STATS,
        /** One slim status bar. */
        MINI
    }

    /** User-facing HUD settings; written by commands, read by the render thread. */
    static final class Settings {
        private Settings() {}
        static volatile boolean visible = true;
        static volatile View view = View.AUTO;
        static volatile int widgets = W_ALL;
        /** Panel background opacity multiplier, 0.25..1. Text and accents stay fully opaque. */
        static volatile double opacity = 1.0;
        /** Swaps the left and right columns (handy when another mod owns one edge). */
        static volatile boolean flipped = false;
        /** Colour theme applied to panel chrome (borders, headers). Data colours (health, ramps) never change. */
        static volatile Theme theme = Theme.DEFAULT;
        private static boolean loaded;
        static boolean on(int widget) { return (widgets & widget) != 0; }
        static void reset() { visible = true; view = View.AUTO; widgets = W_ALL; opacity = 1.0; flipped = false; theme = Theme.DEFAULT; save(); }

        private static java.nio.file.Path file() { return java.nio.file.Path.of("config", "rlpvp-hud.properties"); }

        /** Reads saved settings once; a missing or corrupt file silently keeps the defaults. */
        static void load() {
            if (loaded) return;
            loaded = true;
            try {
                java.nio.file.Path p = file();
                if (!java.nio.file.Files.isRegularFile(p)) return;
                java.util.Properties props = new java.util.Properties();
                try (java.io.InputStream in = java.nio.file.Files.newInputStream(p)) { props.load(in); }
                visible = Boolean.parseBoolean(props.getProperty("visible", "true"));
                try { view = View.valueOf(props.getProperty("view", "AUTO")); } catch (IllegalArgumentException ignored) { view = View.AUTO; }
                try { theme = Theme.valueOf(props.getProperty("theme", "DEFAULT")); } catch (IllegalArgumentException ignored) { theme = Theme.DEFAULT; }
                widgets = Integer.parseInt(props.getProperty("widgets", String.valueOf(W_ALL))) & W_ALL;
                opacity = clamp(Double.parseDouble(props.getProperty("opacity", "1.0")), 0.25, 1.0);
                flipped = Boolean.parseBoolean(props.getProperty("flipped", "false"));
            } catch (java.io.IOException | RuntimeException ignored) {
                // keep whatever was already set
            }
        }

        /** Best-effort save; the HUD must never fail because a config folder is read-only. */
        static void save() {
            try {
                java.util.Properties props = new java.util.Properties();
                props.setProperty("visible", String.valueOf(visible));
                props.setProperty("view", view.name());
                props.setProperty("theme", theme.name());
                props.setProperty("widgets", String.valueOf(widgets));
                props.setProperty("opacity", String.valueOf(opacity));
                props.setProperty("flipped", String.valueOf(flipped));
                java.nio.file.Path p = file();
                if (p.getParent() != null) java.nio.file.Files.createDirectories(p.getParent());
                try (java.io.OutputStream out = java.nio.file.Files.newOutputStream(p)) { props.store(out, "RLPvP HUD settings"); }
            } catch (java.io.IOException | RuntimeException ignored) {
                // best effort
            }
        }
    }

    /** Panel-chrome palettes. Each theme blends the widget accent toward a tint; DEFAULT leaves colours untouched. */
    enum Theme {
        DEFAULT(0, 0.0), ICE(0xFF8FD0FF, 0.62), EMBER(0xFFFF9F5A, 0.62), MONO(0xFFB4BCCB, 0.85), VIOLET(0xFFB7A0FF, 0.62), MINT(0xFF56F0B2, 0.6);
        final int tint; final double strength;
        Theme(int tint, double strength) { this.tint = tint; this.strength = strength; }
        int apply(int accent) { return strength <= 0 ? accent : HudTheme.lerp(accent, tint, strength); }
    }

    /** Backwards-compatible aliases for code that read the old fields. */
    static boolean isVisible() { return Settings.visible; }
    static View currentView() { return Settings.view; }

    private static final HudState STATE = new HudState();
    private static final Ctx CTX = new Ctx();

    /** Per-frame drawing context, reused to avoid allocation in the render loop. */
    private static final class Ctx {
        GuiGraphics g; Font f; Data d; long now; double charge; int sw, sh;
        double pulse() { return 0.5 + 0.5 * Math.sin(now / 130.0); }
    }

    // ======================================================================================================== commands
    static String command(String arg) { return command(arg, null); }

    /**
     * Handles {@code /rl hud <arg> [value]}. Returns the chat feedback, or null when the argument is not understood
     * (the caller then prints its usage line).
     */
    static String command(String arg, String value) {
        if (arg == null) { Settings.visible = !Settings.visible; Settings.save(); return "HUD " + (Settings.visible ? "enabled" : "hidden"); }
        String a = arg.toLowerCase(Locale.ROOT);
        switch (a) {
            case "on" -> { Settings.visible = true; Settings.save(); return "HUD enabled (" + viewName() + ")"; }
            case "off" -> { Settings.visible = false; Settings.save(); return "HUD hidden"; }
            case "auto", "compact", "deck" -> { return setView(View.AUTO, "automatic combat instruments + compact training"); }
            case "combat" -> { return setView(View.COMBAT, "combat instruments"); }
            case "training", "train" -> { return setView(View.TRAINING, "training panel"); }
            case "diag", "diagnostics", "tune" -> { return setView(View.DIAG, "diagnostics: aim pipeline, motion, intelligence"); }
            case "full", "all" -> { return setView(View.FULL, "everything"); }
            case "mini" -> { return setView(View.MINI, "mini bar"); }
            case "flip" -> { Settings.flipped = !Settings.flipped; Settings.save(); return "HUD columns " + (Settings.flipped ? "flipped" : "normal"); }
            case "reset" -> { Settings.reset(); return "HUD settings reset"; }
            case "stats", "review" -> { return setView(View.STATS, "stats: swing accuracy, duel timeline, session"); }
            case "theme" -> {
                if (value == null) return "Themes: " + themeNames() + " (now " + Settings.theme.name().toLowerCase(Locale.ROOT) + ")";
                for (Theme t : Theme.values()) {
                    if (t.name().equalsIgnoreCase(value)) { Settings.theme = t; Settings.save(); return "HUD theme " + t.name().toLowerCase(Locale.ROOT); }
                }
                return "Unknown theme '" + value + "'. Themes: " + themeNames();
            }
            case "layout" -> { return "HUD layout " + lastGeometry + ", view " + viewName() + (lastSkipped.isEmpty() ? ": every enabled widget fits" : ": no room for " + lastSkipped + " (lower GUI scale or use /rl hud toggle)"); }
            case "preset" -> {
                String p = value == null ? "" : value.toLowerCase(Locale.ROOT);
                switch (p) {
                    case "fps", "low" -> { Settings.view = View.MINI; Settings.widgets = 0; Settings.opacity = 0.68; }
                    case "lite" -> { Settings.view = View.COMBAT; Settings.widgets = W_INPUT | W_TARGET | W_AIM | W_SIGNALS | W_CROSS | W_ALERTS; Settings.opacity = 0.72; }
                    case "competitive", "pvp" -> { Settings.view = View.COMBAT; Settings.widgets = W_INPUT | W_TARGET | W_SIGNALS | W_RADAR | W_CROSS | W_ALERTS | W_TAPE | W_FEED; Settings.opacity = 0.8; }
                    case "tuning", "tune" -> { Settings.view = View.DIAG; Settings.widgets = W_ALL; Settings.opacity = 1.0; }
                    case "review" -> { Settings.view = View.STATS; Settings.widgets = W_ALL; Settings.opacity = 1.0; }
                    case "stream", "clean" -> { Settings.view = View.MINI; Settings.widgets = W_ALERTS | W_FEED; Settings.opacity = 0.6; }
                    case "training", "train" -> { Settings.view = View.TRAINING; Settings.widgets = W_ALL; Settings.opacity = 1.0; }
                    default -> { return "Presets: fps, lite, competitive, tuning, review, stream, training"; }
                }
                Settings.visible = true; Settings.save();
                return "HUD preset " + p + " (" + viewName() + ", opacity " + Math.round(Settings.opacity * 100) + "%)";
            }
            case "help", "?" -> { return USAGE + "  Widgets: " + String.join(", ", WIDGET_NAMES); }
            case "clear", "resetstats" -> { Anim.clearSession(); return "HUD session stats cleared"; }
            case "opacity" -> {
                if (value == null) return "HUD opacity is " + Math.round(Settings.opacity * 100) + "% (usage: /rl hud opacity 25-100)";
                try {
                    double v = Double.parseDouble(value.replace("%", ""));
                    Settings.opacity = clamp(v > 1.0 ? v / 100.0 : v, 0.25, 1.0);
                    Settings.save();
                    return "HUD opacity " + Math.round(Settings.opacity * 100) + "%";
                } catch (NumberFormatException e) { return "Opacity must be a number from 25 to 100"; }
            }
            case "toggle", "widget" -> {
                if (value == null) return "Widgets: " + String.join(", ", WIDGET_NAMES) + "  (usage: /rl hud toggle <name>)";
                for (int i = 0; i < WIDGET_NAMES.length; i++) {
                    if (WIDGET_NAMES[i].startsWith(value.toLowerCase(Locale.ROOT))) {
                        Settings.widgets ^= 1 << i;
                        Settings.save();
                        return WIDGET_NAMES[i] + " widget " + ((Settings.widgets & (1 << i)) != 0 ? "shown" : "hidden");
                    }
                }
                return "Unknown widget '" + value + "'. Widgets: " + String.join(", ", WIDGET_NAMES);
            }
            case "status" -> { return "HUD " + (Settings.visible ? "on" : "off") + ", view " + viewName() + ", opacity "
                + Math.round(Settings.opacity * 100) + "%" + (Settings.flipped ? ", flipped" : ""); }
            default -> { return null; }
        }
    }

    private static String setView(View v, String text) {
        Settings.visible = true; Settings.view = v; Settings.save();
        return "HUD: " + text;
    }

    private static String themeNames() {
        StringBuilder sb = new StringBuilder();
        for (Theme t : Theme.values()) sb.append(sb.length() == 0 ? "" : ", ").append(t.name().toLowerCase(Locale.ROOT));
        return sb.toString();
    }

    private static String viewName() { return Settings.view.name().toLowerCase(Locale.ROOT); }

    static final String USAGE = "Usage: /rl hud [on|off|auto|combat|training|diag|stats|full|mini|flip|reset|status|clear|opacity <25-100>|theme <name>|preset <fps|lite|competitive|tuning|review|stream|training>|layout|toggle <widget>]";

    // ======================================================================================================== render entry
    static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        Data d = RlPvpClient.TRAINER.hud();
        Settings.load();
        if (!Settings.visible || !d.active() || mc.player == null || mc.options.hideGui) { Anim.idle(); return; }
        double charge = clamp(mc.player.getAttackStrengthScale(1.0f), 0.0, 1.0);
        frame(g, mc.font, d, mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight(), charge, System.currentTimeMillis());
    }

    /** Draws one HUD frame. Package-private so the layout can be exercised headlessly. */
    static void frame(GuiGraphics g, Font f, Data d, int sw, int sh, double liveCharge, long now) {
        Ctx c = CTX;
        c.g = g; c.f = f; c.d = d; c.now = now; c.charge = liveCharge; c.sw = sw; c.sh = sh;
        STATE.update(d);
        Anim.update(d, now, liveCharge);
        View v = Settings.view;
        SKIPPED.setLength(0);
        if (!lastGeometry.startsWith(sw + "x" + sh + " ")) lastGeometry = sw + "x" + sh + " (GUI-scaled)";
        if (v == View.MINI) { drawMini(c); drawToast(c); lastSkipped = ""; return; }

        int colW = Math.max(118, Math.min(148, (sw - 24) / 2));
        int bottom = sh - BOTTOM_RESERVE;
        double slide = 1.0 - Anim.revealEase();           // 1 -> 0 while the HUD slides in from the edges
        int off = (int) Math.round(slide * (colW + 14));
        boolean flip = Settings.flipped;
        int leftX = (flip ? sw - colW - MARGIN + off : MARGIN - off);
        int rightX = (flip ? MARGIN - off : sw - colW - MARGIN + off);
        Column left = LEFT_COLUMN, right = RIGHT_COLUMN;
        left.set(leftX, 7, colW, bottom);
        right.set(rightX, 7, colW, bottom);

        switch (v) {
            case COMBAT -> { combatLeft(c, left); combatRight(c, right, false); }
            case DIAG -> {
                place(c, left, W_PIPE, H_PIPE, RlHud::drawPipeline);
                place(c, left, W_MOTION, H_MOTION, RlHud::drawMotion);
                place(c, left, W_INTEL, H_INTEL, RlHud::drawIntel);
                place(c, left, W_PERF, H_PERF, RlHud::drawPerf);
                place(c, right, W_SIGNALS, H_SIGNALS, RlHud::drawSignals);
                place(c, right, W_RADAR, H_RADAR, RlHud::drawRadar);
                place(c, right, W_ACCURACY, H_ACCURACY, RlHud::drawAccuracy);
                place(c, right, W_TIMELINE, H_TIMELINE, RlHud::drawTimeline);
            }
            case STATS -> {
                place(c, left, W_ACCURACY, H_ACCURACY, RlHud::drawAccuracy);
                place(c, left, W_TIMELINE, H_TIMELINE, RlHud::drawTimeline);
                place(c, left, W_PERF, H_PERF, RlHud::drawPerf);
                place(c, right, W_TARGET, H_TARGET, RlHud::drawTarget);
                place(c, right, W_SIGNALS, H_SIGNALS, RlHud::drawSignals);
            }
            case TRAINING -> { /* training panel only, drawn below */ }
            case FULL -> {
                combatLeft(c, left);
                place(c, left, W_PIPE, H_PIPE, RlHud::drawPipeline);
                combatRight(c, right, true);
                place(c, right, W_MOTION, H_MOTION, RlHud::drawMotion);
                place(c, right, W_TIMELINE, H_TIMELINE, RlHud::drawTimeline);
                place(c, left, W_ACCURACY, H_ACCURACY, RlHud::drawAccuracy);
                place(c, left, W_PERF, H_PERF, RlHud::drawPerf);
            }
            default -> { combatLeft(c, left); combatRight(c, right, false); } // AUTO
        }

        if (Settings.on(W_TRAIN)) {
            if (v == View.TRAINING || v == View.FULL) {
                int tw = Math.min(176, Math.max(150, colW + 24));
                int centre = (sw - tw) / 2;
                boolean room = centre >= MARGIN + colW + GAP && sw - centre - tw >= MARGIN + colW + GAP && 7 + H_TRAIN_FULL <= sh / 2 - 44;
                if (v == View.TRAINING || room) drawTrainingFull(c, centre, v == View.TRAINING ? 12 : 7, tw);
                if (v == View.TRAINING && Settings.on(W_LADDER)) {
                    int lw = 128, lx = centre - lw - GAP - 2;
                    if (lx >= MARGIN) drawLadder(c, lx, 12, lw);
                    else if (centre + tw + GAP + lw + MARGIN <= sw) drawLadder(c, centre + tw + GAP + 2, 12, lw);
                }
                else if (right.fits(H_TRAIN_COMPACT)) drawTrainingCompact(c, right.x, right.take(H_TRAIN_COMPACT), right.w);
            } else if (v == View.AUTO && !d.play()) {
                Column home = right.fits(H_TRAIN_COMPACT) ? right : left.fits(H_TRAIN_COMPACT) ? left : null;
                if (home != null) drawTrainingCompact(c, home.x, home.take(H_TRAIN_COMPACT), home.w);
            }
        }
        if (v != View.TRAINING && Settings.on(W_CROSS)) { drawHitFx(c); drawCrosshairAssist(c); }
        if (v != View.TRAINING && Settings.on(W_TAPE)) drawBearingTape(c);
        String skippedNow = SKIPPED.toString();
        if (!skippedNow.equals(lastSkipped)) lastSkipped = skippedNow;
        if (Settings.on(W_ALERTS)) drawAlerts(c);
        if (Settings.on(W_FEED) && v != View.TRAINING && v != View.FULL) drawFeed(c);
        drawToast(c);
    }

    private static void combatLeft(Ctx c, Column col) {
        place(c, col, W_INPUT, H_INPUT, RlHud::drawInput);
        place(c, col, W_TARGET, H_TARGET, RlHud::drawTarget);
        place(c, col, W_AIM, H_AIM, RlHud::drawAimDials);
    }

    private static void combatRight(Ctx c, Column col, boolean withIntel) {
        place(c, col, W_SIGNALS, H_SIGNALS, RlHud::drawSignals);
        place(c, col, W_RADAR, H_RADAR, RlHud::drawRadar);
        if (withIntel || (c.d.play() && Settings.view != View.COMBAT)) place(c, col, W_INTEL, H_INTEL, RlHud::drawIntel);
    }

    // ======================================================================================================== layout helpers
    /** Draws one widget callback. */
    @FunctionalInterface private interface Widget { void draw(Ctx c, int x, int y, int w); }

    /** Vertical stack of widgets that stops accepting items when they would run past {@code bottom}. */
    private static final class Column {
        int x, w, bottom, y;
        Column() {}
        void set(int x, int y, int w, int bottom) { this.x = x; this.y = y; this.w = w; this.bottom = bottom; }
        boolean fits(int h) { return y + h <= bottom; }
        int take(int h) { int t = y; y += h + GAP; return t; }
    }

    /** Names of widgets enabled but dropped for lack of height in the last frame (reported by /rl hud layout). */
    private static final StringBuilder SKIPPED = new StringBuilder(96);
    private static volatile String lastSkipped = "";
    private static final Column LEFT_COLUMN = new Column();
    private static final Column RIGHT_COLUMN = new Column();
    private static volatile String lastGeometry = "";

    private static void place(Ctx c, Column col, int id, int h, Widget w) {
        if (!Settings.on(id)) return;
        if (!col.fits(h)) {
            if (SKIPPED.length() > 0) SKIPPED.append(", ");
            SKIPPED.append(WIDGET_NAMES[Integer.numberOfTrailingZeros(id)]);
            return;
        }
        w.draw(c, col.x, col.take(h), col.w);
    }

    // ======================================================================================================== frame-to-frame state
    /**
     * Everything that must persist between frames and is purely presentational. Render thread only.
     * Values are time-based (not frame-based) so the HUD looks identical at 30 and 240 FPS.
     */
    private static final class Anim {
        private Anim() {}

        // slide-in / fade-in when the HUD becomes active
        static double reveal = 0.0;
        // ghost health: lags behind the true value so recent damage stays visible as a pale trail
        static double myGhost = 20, oppGhost = 20, prevMy = 20, prevOpp = 20;
        // 0..1 flashes triggered by a health drop
        static double myHit = 0, oppHit = 0;
        // key heat
        static final long[] keyUntil = new long[8];
        static int prevMask;
        static long prevClick;
        // click timeline for CPS
        static final long[] clicks = new long[48];
        static int clickN;
        // swing result chip
        static int chipResult = ActionApplier.SWING_NONE;
        static long chipUntil;
        // yaw/pitch velocity history (sampled every SAMPLE_MS)
        static final int HIST = 72;
        static final float[] yawHist = new float[HIST], pitchHist = new float[HIST], reqHist = new float[HIST];
        static int histHead;
        static long lastSample;
        // radar trail (enemy position in the player's heading frame)
        static final int TRAIL = 22;
        static final float[] trailX = new float[TRAIL], trailY = new float[TRAIL];
        static int trailHead, trailN;
        static long lastTrail;
        // closing speed (m/s, positive = enemy approaching), smoothed
        static double closing, lastDist = Double.NaN;
        // motion auto-scale
        static double motionPeak = 0.05;
        // intent change flash
        static String lastIntent = "";
        static long intentChangedAt;
        // idle detection so reveal restarts after the HUD was hidden
        static long lastFrame;
        static boolean wasLive;
        // frame time
        private static long lastNanos;
        static double dt = 0.016;
        static double fps = 60;

        // ---- session statistics (swings are counted when the click event arrives)
        static int swings, swingHits, swingMisses, swingWrong, earlySwings;
        static final int CHARGE_BINS = 10;
        static final int[] chargeBins = new int[CHARGE_BINS];
        static double chargeSum;
        static int hitStreak, bestStreak, missStreak;
        static double dealtTotal, takenTotal;

        // ---- event feed (newest last)
        record Event(String text, int color, long at) {}
        static final Event[] feed = new Event[FEED_LINES];
        static int feedN;

        // ---- duel timeline: both health values sampled every TL_MS while a fight is live
        static final int TL = 80;
        static final long TL_MS = 250;
        static final float[] tlMy = new float[TL], tlOpp = new float[TL];
        static int tlN;
        static long lastTl;

        // ---- training throughput / ETA
        static long lastTickSample, lastTickCount;
        static double ticksPerSec, progressRate, lastProgress = -1;
        static int lastStageSeen = -1;
        static long lastPerfSample;

        // ---- win-rate trend from the recent results strip (+1 = improving)
        static double trend;

        static void pushFeed(String text, int color, long now) {
            // identical events in quick succession collapse into "TEXT x3" instead of flooding the feed
            if (feedN > 0) {
                Event last = feed[feedN - 1];
                String base = last.text().replaceAll(" x\\d+$", "");
                if (base.equals(text) && now - last.at() < 2500 && last.color() == color) {
                    java.util.regex.Matcher m = java.util.regex.Pattern.compile(" x(\\d+)$").matcher(last.text());
                    int count = m.find() ? Integer.parseInt(m.group(1)) + 1 : 2;
                    feed[feedN - 1] = new Event(base + " x" + count, color, now);
                    return;
                }
            }
            if (feedN == FEED_LINES) { System.arraycopy(feed, 1, feed, 0, FEED_LINES - 1); feedN--; }
            feed[feedN++] = new Event(text, color, now);
        }

        static void clearSession() {
            swings = swingHits = swingMisses = swingWrong = earlySwings = 0;
            java.util.Arrays.fill(chargeBins, 0);
            chargeSum = 0; hitStreak = bestStreak = missStreak = 0; dealtTotal = takenTotal = 0;
            feedN = 0; tlN = 0;
        }

        static void idle() { reveal = 0.0; lastFrame = 0; lastNanos = 0; }

        static double revealEase() { double t = clamp(reveal, 0, 1); return 1 - (1 - t) * (1 - t) * (1 - t); }

        static void update(Data d, long nowMs, double liveCharge) {
            long nanos = System.nanoTime();
            dt = lastNanos == 0 ? 0.016 : Math.min(0.1, (nanos - lastNanos) / 1e9);
            lastNanos = nanos;
            fps += (clamp(1.0 / Math.max(dt, 1e-4), 1, 999) - fps) * 0.05;
            if (nowMs - lastFrame > 1500) reveal = 0.0;
            lastFrame = nowMs;
            reveal = Math.min(1.0, reveal + dt * 3.2);

            if (!d.live()) { // between episodes: snap everything so the next fight starts clean
                myGhost = prevMy = d.myHp(); oppGhost = prevOpp = d.oppHp(); myHit = oppHit = 0;
                lastDist = Double.NaN; closing = 0; trailN = 0;
                if (wasLive) pushFeed("FIGHT END", HudTheme.DIM, nowMs);
                wasLive = false;
            } else {
                if (!wasLive) {
                    prevMy = d.myHp(); prevOpp = d.oppHp(); myGhost = prevMy; oppGhost = prevOpp; trailN = 0; lastDist = Double.NaN; wasLive = true;
                    tlN = 0; pushFeed("FIGHT START  //  " + safe(d.target(), d.opponent()), HudTheme.CYAN, nowMs);
                }
                if (d.myHp() < prevMy - 0.05) {
                    myHit = 1.0; takenTotal += prevMy - d.myHp();
                    pushFeed(String.format(Locale.ROOT, "TOOK %.1f", prevMy - d.myHp()), HudTheme.RED, nowMs);
                }
                if (d.oppHp() < prevOpp - 0.05) {
                    oppHit = 1.0; dealtTotal += prevOpp - d.oppHp();
                    pushFeed(String.format(Locale.ROOT, "HIT %.1f", prevOpp - d.oppHp()), HudTheme.GREEN, nowMs);
                }
                if (nowMs - lastTl >= TL_MS) {
                    lastTl = nowMs;
                    if (tlN == TL) { System.arraycopy(tlMy, 1, tlMy, 0, TL - 1); System.arraycopy(tlOpp, 1, tlOpp, 0, TL - 1); tlN--; }
                    tlMy[tlN] = (float) d.myHp(); tlOpp[tlN] = (float) d.oppHp(); tlN++;
                }
                prevMy = d.myHp(); prevOpp = d.oppHp();
                myGhost = Math.max(d.myHp(), myGhost - 5.5 * dt);
                oppGhost = Math.max(d.oppHp(), oppGhost - 5.5 * dt);
                if (d.myHp() > myGhost) myGhost = d.myHp();
                if (d.oppHp() > oppGhost) oppGhost = d.oppHp();
                myHit = Math.max(0, myHit - dt * 3.0); oppHit = Math.max(0, oppHit - dt * 3.0);

                if (!Double.isNaN(lastDist)) {
                    double raw = (lastDist - d.dist()) / dt;              // blocks/s toward the enemy
                    closing += (clamp(raw, -25, 25) - closing) * (1 - Math.exp(-6.0 * dt));
                }
                lastDist = d.dist();
                if (nowMs - lastTrail >= 90) {
                    lastTrail = nowMs;
                    trailX[trailHead] = (float) d.mapRight(); trailY[trailHead] = (float) d.mapForward();
                    trailHead = (trailHead + 1) % TRAIL; trailN = Math.min(TRAIL, trailN + 1);
                }
            }

            // key heat + click events
            int mask = d.inputMask();
            for (int i = 0; i < 7; i++) {
                int bit = 1 << i;
                if ((mask & bit) != 0 && (prevMask & bit) == 0) keyUntil[i] = nowMs + KEY_HEAT_MS;
                if ((mask & bit) != 0) keyUntil[i] = Math.max(keyUntil[i], nowMs + 100);
            }
            prevMask = mask;
            if (d.lastClickMillis() > 0 && d.lastClickMillis() != prevClick) {
                prevClick = d.lastClickMillis();
                clicks[clickN++ % clicks.length] = nowMs;
                keyUntil[7] = nowMs + KEY_HEAT_MS;
                chipResult = d.lastSwingResult(); chipUntil = nowMs + SWING_CHIP_MS;
                recordSwing(d, liveCharge, nowMs);
            }

            // histories
            if (nowMs - lastSample >= 50) {
                lastSample = nowMs;
                yawHist[histHead] = (float) d.yawVelocityDpt(); pitchHist[histHead] = (float) d.pitchVelocityDpt();
                reqHist[histHead] = (float) d.yawRequestedDpt();
                histHead = (histHead + 1) % HIST;
            }
            double m = Math.max(d.ownMotion(), d.enemyMotion());
            motionPeak = Math.max(0.05, Math.max(m, motionPeak - 0.02 * dt));

            String intent = d.intent() == null ? "" : d.intent();
            if (!intent.equals(lastIntent)) {
                if (d.play() && d.live() && !lastIntent.isEmpty() && !intent.equals("STANDBY")) pushFeed("INTENT " + intent.replace('_', ' '), intentColor(intent), nowMs);
                lastIntent = intent; intentChangedAt = nowMs;
            }
            samplePerf(d, nowMs);
        }

        private static void recordSwing(Data d, double charge, long now) {
            swings++;
            chargeSum += charge;
            chargeBins[(int) Math.min(CHARGE_BINS - 1, Math.floor(clamp(charge, 0, 0.9999) * CHARGE_BINS))]++;
            if (charge < d.attackThreshold()) earlySwings++;
            switch (d.lastSwingResult()) {
                case ActionApplier.SWING_HIT_TARGET -> {
                    swingHits++; hitStreak++; missStreak = 0; bestStreak = Math.max(bestStreak, hitStreak);
                }
                case ActionApplier.SWING_HIT_OTHER -> { swingWrong++; hitStreak = 0; pushFeed("WRONG ENTITY", HudTheme.ORANGE, now); }
                case ActionApplier.SWING_MISS -> {
                    swingMisses++; hitStreak = 0; missStreak++;
                    pushFeed("MISS", HudTheme.YELLOW, now);
                }
                default -> { }
            }
        }

        /** Perf, ETA and trend sampling at 1 Hz (called from update). */
        static void samplePerf(Data d, long now) {
            if (now - lastPerfSample < 1000) return;
            double secs = lastPerfSample == 0 ? 1.0 : (now - lastPerfSample) / 1000.0;
            lastPerfSample = now;
            if (lastTickCount > 0 && d.ticks() >= lastTickCount) {
                double inst = (d.ticks() - lastTickCount) / secs;
                ticksPerSec += (inst - ticksPerSec) * 0.35;
            }
            lastTickCount = d.ticks();
            if (d.stage() != lastStageSeen) { lastStageSeen = d.stage(); lastProgress = -1; progressRate = 0; }
            if (lastProgress >= 0) progressRate += (Math.max(0, d.progress() - lastProgress) / secs - progressRate) * 0.25;
            lastProgress = d.progress();
            byte[] r = d.resHist();
            if (r != null && r.length >= 8) {
                int half = r.length / 2, a = 0, b = 0;
                for (int i = 0; i < half; i++) if (r[i] > 0) a++;
                for (int i = half; i < r.length; i++) if (r[i] > 0) b++;
                trend = clamp(b / (double) (r.length - half) - a / (double) half, -1, 1);
            }
        }

        static double heat(int key, boolean down, long now) {
            if (down) return 1.0;
            return clamp((keyUntil[key] - now) / (double) KEY_HEAT_MS, 0.0, 1.0);
        }

        /** Clicks per second over the last second. */
        static double cps(long now) {
            int n = 0;
            for (long t : clicks) if (t > 0 && now - t <= 1000) n++;
            return n;
        }

    }

    // ======================================================================================================== INPUT STREAM
    private static void drawInput(Ctx c, int x, int y, int w) {
        Data d = c.d; GuiGraphics g = c.g; Font f = c.f;
        int accent = d.play() ? HudTheme.CYAN : HudTheme.PURPLE;
        Gfx.facet(g, x, y, w, H_INPUT, accent);
        Gfx.title(c, "INPUT STREAM", d.play() ? "AUTONOMY" : "POLICY", x, y, w, accent);

        int mask = d.inputMask();
        int keyY = y + 17, base = x + 8;
        keyCap(c, base + 22, keyY, 18, 12, "W", KEY_W, mask, 0);
        keyCap(c, base + 2, keyY + 13, 18, 12, "A", KEY_A, mask, 1);
        keyCap(c, base + 22, keyY + 13, 18, 12, "S", KEY_S, mask, 2);
        keyCap(c, base + 42, keyY + 13, 18, 12, "D", KEY_D, mask, 3);

        int rx = x + Math.max(70, w - 75);
        int rw = Math.max(28, (x + w - 7 - rx - 2) / 2);
        keyCap(c, rx, keyY, rw, 12, "SHFT", KEY_SHIFT, mask, 4);
        boolean clicked = d.lastClickMillis() > 0 && c.now - d.lastClickMillis() < 420;
        keyCapRaw(c, rx + rw + 2, keyY, rw, 12, "LMB", d.attackKeyDown(), clicked, 7);
        keyCap(c, rx, keyY + 13, rw, 12, "RUN", KEY_SPRINT, mask, 5);
        keyCap(c, rx + rw + 2, keyY + 13, rw, 12, "JMP", KEY_JUMP, mask, 6);

        // footer: clicks per second, and the outcome of the latest swing as a fading chip
        double cps = Anim.cps(c.now);
        Gfx.text(c, "CPS " + (int) cps, x + 8, y + H_INPUT - 10, cps >= 9 ? HudTheme.ORANGE : HudTheme.DIM);
        if (c.now < Anim.chipUntil && Anim.chipResult != ActionApplier.SWING_NONE) {
            double fade = clamp((Anim.chipUntil - c.now) / (double) SWING_CHIP_MS, 0, 1);
            String t = swingLabel(Anim.chipResult);
            int col = swingColor(Anim.chipResult);
            int tw = f.width(t) + 8, tx = x + w - tw - 8;
            g.fill(tx, y + H_INPUT - 12, tx + tw, y + H_INPUT - 2, HudTheme.alpha(col, (int) (0x55 * fade + 0x10)));
            Gfx.textC(c, t, tx + tw / 2, y + H_INPUT - 11, HudTheme.alpha(col, (int) (255 * Math.max(0.35, fade))));
        } else {
            Gfx.textR(c, "YELLOW = EVENT", x + w - 8, y + H_INPUT - 10, HudTheme.FAINT);
        }
    }

    private static String swingLabel(int result) {
        return switch (result) {
            case ActionApplier.SWING_HIT_TARGET -> "HIT";
            case ActionApplier.SWING_HIT_OTHER -> "WRONG ENTITY";
            case ActionApplier.SWING_MISS -> "MISS";
            default -> "";
        };
    }

    private static int swingColor(int result) {
        return switch (result) {
            case ActionApplier.SWING_HIT_TARGET -> HudTheme.GREEN;
            case ActionApplier.SWING_HIT_OTHER -> HudTheme.ORANGE;
            case ActionApplier.SWING_MISS -> HudTheme.RED;
            default -> HudTheme.DIM;
        };
    }

    private static void keyCap(Ctx c, int x, int y, int w, int h, String label, int bit, int mask, int index) {
        keyCapRaw(c, x, y, w, h, label, (mask & bit) != 0, false, index);
    }

    private static void keyCapRaw(Ctx c, int x, int y, int w, int h, String label, boolean down, boolean event, int index) {
        if (event) Anim.keyUntil[index] = Math.max(Anim.keyUntil[index], c.now + 120);
        double heat = Anim.heat(index, down, c.now);
        int color = HudTheme.lerp(HudTheme.BLUE, HudTheme.YELLOW, heat);
        Gfx.facet(c.g, x, y, w, h, color, Gfx.bg(0x091321, 0xEA), 2);
        if (heat > 0.05) c.g.fill(x + 2, y + h - 3, x + w - 2, y + h - 2, HudTheme.alpha(HudTheme.YELLOW, (int) (heat * 160)));
        Gfx.textC(c, label, x + w / 2, y + (h - c.f.lineHeight) / 2 + 1, heat > 0.02 ? HudTheme.WHITE : HudTheme.BLUE);
    }

    // ======================================================================================================== AIM RATE DIALS
    private static void drawAimDials(Ctx c, int x, int y, int w) {
        int gap = 5, dw = (w - gap) / 2;
        dial(c, x, y, dw, H_AIM, "YAW RATE", c.d.yawVelocityDpt(), 45.0, HudTheme.CYAN);
        dial(c, x + dw + gap, y, dw, H_AIM, "PITCH RATE", c.d.pitchVelocityDpt(), 15.0, HudTheme.PURPLE);
    }

    private static void dial(Ctx c, int x, int y, int w, int h, String label, double value, double range, int accent) {
        GuiGraphics g = c.g;
        Gfx.facet(g, x, y, w, h, accent);
        Gfx.textC(c, label, x + w / 2, y + 3, accent);
        int cx = x + w / 2, cy = y + 31, r = Math.min(17, Math.max(13, w / 4));
        double v = clamp(value / range, -1.0, 1.0);
        int col = HudTheme.ramp(1.0 - Math.abs(v));
        Gfx.arc(g, cx, cy, r, 135, 405, HudTheme.alpha(HudTheme.BLUE, 0x70), 3);
        // lit sweep from the centre mark to the needle: shows direction and magnitude at a glance
        int from = 270, to = (int) Math.round(135 + (v + 1.0) * 135.0);
        Gfx.arc(g, cx, cy, r, Math.min(from, to), Math.max(from, to), HudTheme.alpha(col, 0xD0), 3);
        for (int i = 0; i <= 6; i++) {
            double a = Math.toRadians(135 + i * 45.0);
            boolean major = i == 0 || i == 3 || i == 6;
            int r1 = r - (major ? 3 : 1), r2 = r + (major ? 3 : 2);
            Gfx.line(g, cx + (int) Math.round(Math.cos(a) * r1), cy + (int) Math.round(Math.sin(a) * r1),
                cx + (int) Math.round(Math.cos(a) * r2), cy + (int) Math.round(Math.sin(a) * r2), major ? HudTheme.DIM : HudTheme.FAINT, 1);
        }
        double angle = Math.toRadians(135 + (v + 1.0) * 135.0);
        Gfx.line(g, cx, cy, cx + (int) Math.round(Math.cos(angle) * (r - 5)), cy + (int) Math.round(Math.sin(angle) * (r - 5)), col, 2);
        g.fill(cx - 2, cy - 2, cx + 3, cy + 3, HudTheme.WHITE);
        Gfx.textC(c, String.format(Locale.ROOT, "%+.1f°", value), cx, y + h - 10, col);
    }

    // ======================================================================================================== AIM PIPELINE
    /**
     * Shows each stage of the look pipeline per axis: what the policy asked for, what the input filter let through and what the
     * camera actually turned. A big gap between the first two means the filter is smoothing hard; a gap between the last two
     * means the rotation limiter (accel / jerk / quantisation) is the bottleneck.
     */
    private static void drawPipeline(Ctx c, int x, int y, int w) {
        Data d = c.d; GuiGraphics g = c.g;
        Gfx.facet(g, x, y, w, H_PIPE, HudTheme.BLUE);
        Gfx.title(c, "AIM PIPELINE", String.format(Locale.ROOT, "α %.2f", d.filterAlpha()), x, y, w, HudTheme.BLUE);
        int bx = x + 28, bw = w - 38, ry = y + 17;
        pipeRow(c, "REQ", d.yawRequestedDpt(), 45.0, bx, ry, bw, HudTheme.CYAN, x);
        pipeRow(c, "FLT", d.yawFilteredDpt(), 45.0, bx, ry + 9, bw, HudTheme.LIME, x);
        pipeRow(c, "ACT", d.yawActualDpt(), 45.0, bx, ry + 18, bw, HudTheme.GREEN, x);
        pipeRow(c, "REQ", d.pitchRequestedDpt(), 15.0, bx, ry + 29, bw, HudTheme.PURPLE, x);
        pipeRow(c, "ACT", d.pitchActualDpt(), 15.0, bx, ry + 38, bw, HudTheme.PURPLE, x);
        // yaw velocity trace: requested (dim) behind actual (bright). A jittery trace is a jittery camera.
        int gy = y + H_PIPE - 14;
        Gfx.traceRing(g, x + 8, gy, w - 16, 10, Anim.reqHist, Anim.histHead, 60.0, HudTheme.alpha(HudTheme.CYAN, 0x60));
        Gfx.traceRing(g, x + 8, gy, w - 16, 10, Anim.yawHist, Anim.histHead, 60.0, HudTheme.GREEN);
        double lag = Math.abs(d.yawRequestedDpt()) < 0.5 ? 0 : 1.0 - Math.abs(d.yawActualDpt()) / Math.abs(d.yawRequestedDpt());
        String s = Math.abs(d.yawRequestedDpt()) < 0.5 ? "IDLE" : String.format(Locale.ROOT, "LAG %.0f%%", Math.max(0, lag) * 100);
        Gfx.textR(c, s, x + w - 8, y + H_PIPE - 24, Math.abs(lag) < 0.35 ? HudTheme.GREEN : HudTheme.YELLOW);
    }

    private static void pipeRow(Ctx c, String label, double value, double range, int bx, int y, int bw, int color, int panelX) {
        Gfx.text(c, label, panelX + 8, y - 1, HudTheme.DIM);
        Gfx.centeredBar(c.g, bx, y + 1, bw, 4, clamp(value / range, -1, 1), color);
    }

    // ======================================================================================================== TARGET LOCK
    private static void drawTarget(Ctx c, int x, int y, int w) {
        Data d = c.d; GuiGraphics g = c.g;
        boolean live = d.live();
        int accent = live ? HudTheme.ORANGE : HudTheme.DIM;
        Gfx.facet(g, x, y, w, H_TARGET, accent);
        if (live && Anim.myHit > 0.01) g.fill(x + 3, y + 1, x + w - 3, y + 2, HudTheme.alpha(HudTheme.RED, (int) (Anim.myHit * 220)));
        if (live && Anim.oppHit > 0.01) g.fill(x + 3, y + H_TARGET - 2, x + w - 3, y + H_TARGET - 1, HudTheme.alpha(HudTheme.GREEN, (int) (Anim.oppHit * 220)));
        String lock = live ? (d.los() ? "TRACK" : "NO LOS") : "SEARCH";
        Gfx.title(c, "TARGET LOCK", lock, x, y, w, live ? (d.los() ? HudTheme.GREEN : HudTheme.RED) : HudTheme.DIM);
        String name = live ? safe(d.target(), d.opponent()) : "NO CONTACT";
        Gfx.text(c, Gfx.fit(c.f, name, w - 16), x + 8, y + 17, live ? HudTheme.WHITE : HudTheme.DIM);

        int barX = x + 31, barW = w - 74;
        healthRow(c, "FOE", HudTheme.RED, STATE.oppHp, Anim.oppGhost, d.oppHp(), live, x, y + 29, barW, barX, Anim.oppHit);
        healthRow(c, "YOU", HudTheme.GREEN, STATE.myHp, Anim.myGhost, d.myHp(), live, x, y + 40, barW, barX, Anim.myHit);

        // HP lead chip + aim box
        double lead = d.hpLead();
        String leadText = live ? String.format(Locale.ROOT, "LEAD %+.0f", lead) : "LEAD --";
        Gfx.text(c, leadText, x + 8, y + 53, !live ? HudTheme.DIM : lead > 0.5 ? HudTheme.GREEN : lead < -0.5 ? HudTheme.RED : HudTheme.YELLOW);
        String aim = live ? String.format(Locale.ROOT, "Y%+.1f° P%+.1f°", STATE.yawErr, STATE.pitchErr) : "AIM --";
        Gfx.text(c, Gfx.fit(c.f, aim, w - 52), x + 8, y + 64, live ? HudTheme.aimColor(d.yawErrDeg(), d.pitchErrDeg()) : HudTheme.DIM);
        int bxw = 34, bxh = 26, bx = x + w - bxw - 8, by = y + 50;
        g.fill(bx, by, bx + bxw, by + bxh, HudTheme.GRAPH_BG);
        Gfx.outline(g, bx, by, bxw, bxh, HudTheme.alpha(accent, 0x90));
        g.fill(bx + bxw / 2, by + 2, bx + bxw / 2 + 1, by + bxh - 2, HudTheme.alpha(HudTheme.FAINT, 0xA0));
        g.fill(bx + 2, by + bxh / 2, bx + bxw - 2, by + bxh / 2 + 1, HudTheme.alpha(HudTheme.FAINT, 0xA0));
        if (live) HudDraw.aimDot(g, STATE.yawErr, STATE.pitchErr, d.los(), bx + bxw / 2, by + bxh / 2, 9);
        // bottom micro-bar: share of the episode clock used
        if (live) Gfx.bar(g, x + 8, y + H_TARGET - 6, w - 16, 2, d.episodeFraction(), HudTheme.alpha(HudTheme.ORANGE, 0xB0));
    }

    private static void healthRow(Ctx c, String label, int tag, double smooth, double ghost, double raw, boolean live,
                                  int x, int y, int barW, int barX, double flash) {
        GuiGraphics g = c.g;
        Gfx.text(c, label, x + 8, y - 1, tag);
        double s = live ? clamp(smooth / 20.0, 0, 1) : 0, gh = live ? clamp(ghost / 20.0, 0, 1) : 0;
        g.fill(barX, y + 1, barX + barW, y + 5, HudTheme.TRACK);
        int gw = (int) Math.round(barW * gh), sw = (int) Math.round(barW * s);
        if (gw > sw) g.fill(barX + sw, y + 1, barX + gw, y + 5, HudTheme.alpha(HudTheme.WHITE, 0x70));
        int fill = HudTheme.hpColor(s);
        if (flash > 0.01) fill = HudTheme.lerp(fill, HudTheme.WHITE, flash * 0.8);
        if (sw > 0) g.fill(barX, y + 1, barX + sw, y + 5, fill);
        boolean low = live && raw <= 4.0;
        int numCol = low ? HudTheme.lerp(HudTheme.RED, HudTheme.WHITE, c.pulse()) : HudTheme.TEXT;
        Gfx.textR(c, live ? String.format(Locale.ROOT, "%.0f", raw) : "--", x + barW + 66, y - 1, numCol);
    }

    // ======================================================================================================== LIVE SIGNALS
    private static void drawSignals(Ctx c, int x, int y, int w) {
        Data d = c.d; GuiGraphics g = c.g;
        boolean live = d.live();
        Gfx.facet(g, x, y, w, H_SIGNALS, HudTheme.CYAN);
        Gfx.title(c, "LIVE SIGNALS", live ? "TRACKING" : "IDLE", x, y, w, live ? HudTheme.GREEN : HudTheme.DIM);

        // range with the spacing window and reach tick drawn behind the marker
        Gfx.text(c, "RANGE", x + 8, y + 17, HudTheme.DIM);
        Gfx.textR(c, live ? String.format(Locale.ROOT, "%.2fm", STATE.dist) : "--", x + w - 8, y + 17, live ? HudTheme.distColor(d.dist()) : HudTheme.DIM);
        if (live) HudDraw.distance(g, x + 8, y + 28, w - 16, 4, STATE.dist, 6.0);
        else Gfx.bar(g, x + 8, y + 28, w - 16, 4, 0, HudTheme.CYAN);
        String band = !live ? "" : d.dist() <= Config.ATTACK_REACH ? "IN REACH" : d.dist() <= Config.SPACING_MAX ? "EDGE" : d.dist() <= Config.RETREAT_MAX ? "CLOSE UP" : "FAR";
        Gfx.text(c, band, x + 8, y + 35, HudTheme.DIM);
        double cl = Anim.closing;
        if (live && Math.abs(cl) > 0.4) Gfx.textR(c, String.format(Locale.ROOT, "%s %.1f m/s", cl > 0 ? "CLOSING" : "OPENING", Math.abs(cl)), x + w - 8, y + 35, cl > 0 ? HudTheme.ORANGE : HudTheme.CYAN);

        // attack cooldown: threshold marker plus a READY blink the tick the swing becomes legal
        int pct = (int) Math.round(c.charge * 100.0);
        boolean ready = c.charge >= d.attackThreshold();
        Gfx.text(c, "ATTACK CD", x + 8, y + 49, HudTheme.DIM);
        int cdCol = ready ? HudTheme.LIME : HudTheme.YELLOW;
        Gfx.textR(c, ready ? "READY" : String.format(Locale.ROOT, "%3d%%", pct), x + w - 8, y + 49, ready ? HudTheme.lerp(HudTheme.LIME, HudTheme.WHITE, c.pulse() * 0.5) : cdCol);
        HudDraw.barMarked(g, x + 8, y + 60, w - 16, 5, c.charge, cdCol, d.attackThreshold());

        // camera + episode clock
        Gfx.text(c, "CAMERA", x + 8, y + 71, HudTheme.DIM);
        Gfx.textR(c, Gfx.fit(c.f, String.format(Locale.ROOT, "Y%+.1f P%+.1f°/t", d.yawVelocityDpt(), d.pitchVelocityDpt()), w - 56), x + w - 8, y + 71, HudTheme.CYAN);
        if (live) {
            Gfx.text(c, "EP CLOCK", x + 8, y + 82, HudTheme.DIM);
            Gfx.textR(c, String.format(Locale.ROOT, "%.1fs left", Math.max(0, (d.epTicks() - d.epTick()) / 20.0)), x + w - 8, y + 82, d.episodeFraction() > 0.85 ? HudTheme.ORANGE : HudTheme.TEXT);
        } else {
            Gfx.text(c, "EP CLOCK", x + 8, y + 82, HudTheme.DIM);
            Gfx.textR(c, "--", x + w - 8, y + 82, HudTheme.DIM);
        }
        if (d.lastClickMillis() > 0 && c.now - d.lastClickMillis() < CLICK_FLASH_MS) g.fill(x + w - 12, y + 3, x + w - 9, y + 6, HudTheme.YELLOW);
    }

    // ======================================================================================================== RADAR
    private static void drawRadar(Ctx c, int x, int y, int w) {
        Data d = c.d; GuiGraphics g = c.g;
        Gfx.facet(g, x, y, w, H_RADAR, HudTheme.BLUE);
        Gfx.title(c, "LOCAL RADAR", RADAR_RANGE_M + "M", x, y, w, HudTheme.DIM);
        int cx = x + w / 2, cy = y + 48, r = Math.min(31, Math.max(26, w / 2 - 10));
        double scale = r / (double) RADAR_RANGE_M;
        // range rings every 2 m, reach ring highlighted, cross-hairs and a 70° view cone
        for (int m = 2; m <= RADAR_RANGE_M; m += 2) Gfx.arc(g, cx, cy, (int) Math.round(m * scale), 0, 360, HudTheme.alpha(HudTheme.BLUE, m == RADAR_RANGE_M ? 0x90 : 0x38), m == RADAR_RANGE_M ? 4 : 6);
        Gfx.arc(g, cx, cy, (int) Math.round(Config.ATTACK_REACH * scale), 0, 360, HudTheme.alpha(HudTheme.GREEN, 0x70), 8);
        Gfx.line(g, cx - r, cy, cx + r, cy, HudTheme.alpha(HudTheme.BLUE, 0x30), 1);
        Gfx.line(g, cx, cy - r, cx, cy + r, HudTheme.alpha(HudTheme.BLUE, 0x30), 1);
        double half = Math.toRadians(35);
        Gfx.line(g, cx, cy, cx + (int) Math.round(Math.sin(-half) * r), cy - (int) Math.round(Math.cos(half) * r), HudTheme.alpha(HudTheme.CYAN, 0x45), 1);
        Gfx.line(g, cx, cy, cx + (int) Math.round(Math.sin(half) * r), cy - (int) Math.round(Math.cos(half) * r), HudTheme.alpha(HudTheme.CYAN, 0x45), 1);
        g.fill(cx - 1, cy - r - 2, cx + 2, cy - r + 3, HudTheme.CYAN);
        Gfx.diamond(g, cx, cy, 4, HudTheme.CYAN);
        if (!d.live()) { Gfx.textC(c, "NO TARGET", cx, y + H_RADAR - 11, HudTheme.DIM); return; }

        // fading trail of the enemy's recent relative positions
        for (int i = 0; i < Anim.trailN; i++) {
            int idx = (Anim.trailHead - 1 - i + Anim.TRAIL) % Anim.TRAIL;
            int px = cx + (int) Math.round(clamp(Anim.trailX[idx] * scale, -r, r));
            int py = cy + (int) Math.round(clamp(-Anim.trailY[idx] * scale, -r, r));
            int a = (int) (0x70 * (1.0 - i / (double) Anim.TRAIL));
            g.fill(px, py, px + 2, py + 2, HudTheme.alpha(HudTheme.ORANGE, a));
        }
        double ex = d.mapRight() * scale, ey = -d.mapForward() * scale;
        double len = Math.hypot(ex, ey);
        boolean clipped = len > r;
        if (clipped) { ex = ex / len * r; ey = ey / len * r; }
        int tx = cx + (int) Math.round(ex), ty = cy + (int) Math.round(ey);
        boolean inReach = d.dist() <= Config.ATTACK_REACH;
        int tcol = inReach ? HudTheme.RED : HudTheme.ORANGE;
        Gfx.line(g, cx, cy, tx, ty, HudTheme.alpha(tcol, 0x85), 1);
        Gfx.diamond(g, tx, ty, clipped ? 3 : 5, tcol);
        double bearing = Math.toDegrees(Math.atan2(d.mapRight(), d.mapForward()));
        Gfx.textC(c, String.format(Locale.ROOT, "%.1fm  %s%.0f°", d.dist(), bearing >= 0 ? "R" : "L", Math.abs(bearing)), cx, y + H_RADAR - 11, inReach ? HudTheme.RED : HudTheme.TEXT);
    }

    // ======================================================================================================== COMBAT INTEL
    private static void drawIntel(Ctx c, int x, int y, int w) {
        Data d = c.d; GuiGraphics g = c.g;
        boolean play = d.play();
        Gfx.facet(g, x, y, w, H_INTEL, play ? HudTheme.LIME : HudTheme.DIM);
        Gfx.title(c, "COMBAT INTEL", play ? "ONLINE" : "STANDBY", x, y, w, play ? HudTheme.LIME : HudTheme.DIM);
        String intent = d.intent() == null || d.intent().isBlank() ? "STANDBY" : d.intent();
        double since = (c.now - Anim.intentChangedAt) / 1000.0;
        int icol = intentColor(intent);
        if (since < 0.6) icol = HudTheme.lerp(HudTheme.WHITE, icol, since / 0.6);
        Gfx.text(c, Gfx.fit(c.f, intent.replace('_', ' '), w - 16), x + 8, y + 17, icol);
        Gfx.text(c, "CONF", x + 8, y + 29, HudTheme.DIM);
        Gfx.segmented(g, x + 36, y + 30, w - 44 - 24, 5, 10, d.intentConfidence(), HudTheme.ramp(d.intentConfidence()));
        Gfx.textR(c, String.format(Locale.ROOT, "%.0f%%", d.intentConfidence() * 100), x + w - 8, y + 29, HudTheme.TEXT);
        int half = (w - 16) / 2;
        counter(c, "SAFETY", d.safetyInterventions(), x + 8, y + 42, half, HudTheme.CYAN);
        counter(c, "ATK REJ", d.rejectedAttacks(), x + 8 + half, y + 42, half, HudTheme.ORANGE);
        counter(c, "SPR FIX", d.correctedSprints(), x + 8, y + 58, half, HudTheme.YELLOW);
        counter(c, "BOUND", d.boundaryCorrections(), x + 8 + half, y + 58, half, HudTheme.PURPLE);
    }

    private static void counter(Ctx c, String label, long value, int x, int y, int w, int color) {
        Gfx.text(c, label, x, y, HudTheme.DIM);
        Gfx.text(c, compactNumber(value), x, y + 8, value > 0 ? color : HudTheme.FAINT);
    }

    private static int intentColor(String intent) {
        String s = intent.toUpperCase(Locale.ROOT);
        if (s.contains("PUNISH") || s.contains("COMBO") || s.contains("FOLLOW")) return HudTheme.LIME;
        if (s.contains("DEFEND") || s.contains("DISENGAGE")) return HudTheme.RED;
        if (s.contains("BAIT") || s.contains("REPOSITION")) return HudTheme.YELLOW;
        if (s.contains("PURSUE") || s.contains("ENGAGE")) return HudTheme.ORANGE;
        if (s.contains("TRAIN")) return HudTheme.PURPLE;
        return HudTheme.DIM;
    }

    // ======================================================================================================== MOTION
    private static void drawMotion(Ctx c, int x, int y, int w) {
        Data d = c.d; GuiGraphics g = c.g;
        Gfx.facet(g, x, y, w, H_MOTION, HudTheme.ORANGE);
        Gfx.title(c, "MOTION", d.live() ? "LIVE" : "IDLE", x, y, w, d.live() ? HudTheme.GREEN : HudTheme.DIM);
        double own = d.live() ? d.ownMotion() : 0, foe = d.live() ? d.enemyMotion() : 0;
        motionRow(c, "YOU", own, x, y + 17, w, HudTheme.CYAN);
        motionRow(c, "FOE", foe, x, y + 29, w, HudTheme.ORANGE);
        // relative speed: positive when I move faster than the enemy
        String rel = !d.live() ? "--" : own > foe * 1.25 ? "ADVANTAGE" : foe > own * 1.25 ? "PRESSURED" : "EVEN";
        int rc = !d.live() ? HudTheme.DIM : own > foe * 1.25 ? HudTheme.GREEN : foe > own * 1.25 ? HudTheme.RED : HudTheme.YELLOW;
        Gfx.textR(c, rel, x + w - 8, y + 42, rc);
        Gfx.text(c, "PACE", x + 8, y + 42, HudTheme.DIM);
    }

    private static void motionRow(Ctx c, String label, double v, int x, int y, int w, int color) {
        Gfx.text(c, label, x + 8, y - 1, HudTheme.DIM);
        Gfx.bar(c.g, x + 32, y + 1, w - 40, 4, clamp(v / Anim.motionPeak, 0, 1), color);
    }

    // ======================================================================================================== TRAINING
    private static void drawTrainingCompact(Ctx c, int x, int y, int w) {
        Data d = c.d; GuiGraphics g = c.g;
        Gfx.facet(g, x, y, w, H_TRAIN_COMPACT, HudTheme.PURPLE);
        Gfx.text(c, "TRAINING / PPO", x + 8, y + 5, HudTheme.WHITE);
        Gfx.textR(c, "STAGE " + d.stage() + "/" + d.stages(), x + w - 8, y + 5, HudTheme.PURPLE);
        Gfx.text(c, compactNumber(d.ticks()) + " TICKS", x + 8, y + 18, HudTheme.TEXT);
        Gfx.textR(c, compactNumber(d.updates()) + " UPD", x + w - 8, y + 18, HudTheme.DIM);
        Gfx.bar(g, x + 8, y + 30, w - 16, 4, d.progress(), HudTheme.PURPLE);
        Gfx.text(c, "WIN " + (d.hasStats() ? String.format(Locale.ROOT, "%.0f%%", STATE.winRate * 100) : "--"), x + 8, y + 39, HudTheme.GREEN);
        Gfx.textC(c, "ENT " + String.format(Locale.ROOT, "%.2f", STATE.entropy), x + w / 2 + 6, y + 39, HudTheme.entropyColor(STATE.entropy));
        Gfx.textR(c, "EP " + d.episodes(), x + w - 8, y + 39, HudTheme.TEXT);
        Gfx.text(c, "RETURN " + String.format(Locale.ROOT, "%+.1f", d.ret()), x + 8, y + 51, HudTheme.DIM);
        Gfx.textR(c, d.play() ? "INFERENCE" : "LEARNING", x + w - 8, y + 51, d.play() ? HudTheme.CYAN : HudTheme.PURPLE);
    }

    private static void drawTrainingFull(Ctx c, int x, int y, int w) {
        Data d = c.d; GuiGraphics g = c.g;
        Gfx.facet(g, x, y, w, H_TRAIN_FULL, d.play() ? HudTheme.CYAN : HudTheme.PURPLE);
        Gfx.title(c, "TRAINING / PPO", d.play() ? "INFERENCE" : "LEARNING", x, y, w, d.play() ? HudTheme.CYAN : HudTheme.PURPLE);
        int ix = x + 8, iw = w - 16;

        // curriculum: chip track, opponent label and lock summary
        HudDraw.stageTrack(g, ix, y + 18, iw, 5, d.stage(), d.stages());
        Gfx.text(c, "STAGE " + d.stage() + "/" + d.stages(), ix, y + 27, HudTheme.WHITE);
        Gfx.textR(c, Gfx.fit(c.f, safe(d.opponent(), "-"), iw - 54), x + w - 8, y + 27, HudTheme.PURPLE);
        Gfx.text(c, "LOCKS " + Gfx.fit(c.f, safe(d.locks(), "none"), iw - 84), ix, y + 37, HudTheme.DIM);
        Gfx.textR(c, d.episodes() + " EP", x + w - 8, y + 37, HudTheme.TEXT);
        Gfx.bar(g, ix, y + 48, iw, 4, d.progress(), HudTheme.PURPLE);
        Gfx.text(c, compactNumber(d.ticks()) + " TICKS", ix, y + 55, HudTheme.TEXT);
        Gfx.textR(c, compactNumber(d.updates()) + " UPD", x + w - 8, y + 55, HudTheme.DIM);

        // outcomes: split win/loss bar, then damage race
        double win = d.hasStats() ? clamp(d.winRate(), 0, 1) : 0, loss = d.hasStats() ? clamp(d.lossRate(), 0, 1 - win) : 0;
        g.fill(ix, y + 68, ix + iw, y + 73, HudTheme.TRACK);
        int ww = (int) Math.round(iw * win), lw = (int) Math.round(iw * loss);
        if (ww > 0) g.fill(ix, y + 68, ix + ww, y + 73, HudTheme.GREEN);
        if (lw > 0) g.fill(ix + iw - lw, y + 68, ix + iw, y + 73, HudTheme.RED);
        Gfx.text(c, d.hasStats() ? String.format(Locale.ROOT, "WIN %.0f%%", win * 100) : "WIN --", ix, y + 76, HudTheme.GREEN);
        Gfx.textR(c, d.hasStats() ? String.format(Locale.ROOT, "LOSS %.0f%%", loss * 100) : "LOSS --", x + w - 8, y + 76, HudTheme.RED);
        Gfx.text(c, d.hasStats() ? String.format(Locale.ROOT, "DEALT %.1f", d.dealt()) : "DEALT --", ix, y + 86, HudTheme.TEXT);
        Gfx.textR(c, d.hasStats() ? String.format(Locale.ROOT, "TAKEN %.1f", d.taken()) : "TAKEN --", x + w - 8, y + 86, HudTheme.TEXT);

        // technique shares as three mini meters
        int third = (iw - 8) / 3;
        share(c, "WHIFF", d.whiffRate(), ix, y + 96, third, d.whiffRate() >= 0.40 ? HudTheme.ORANGE : HudTheme.YELLOW, d.hasStats());
        share(c, "CRIT", d.critShare(), ix + third + 4, y + 96, third, HudTheme.CYAN, d.hasStats());
        share(c, "SPRINT", d.sprintShare(), ix + 2 * (third + 4), y + 96, third, HudTheme.LIME, d.hasStats());

        // graphs: episode returns (columns) and entropy against its anti-collapse floor
        Gfx.text(c, "RETURNS", ix, y + 124, HudTheme.DIM);
        Gfx.textR(c, String.format(Locale.ROOT, "AVG %+.1f", d.ret()), x + w - 8, y + 124, d.ret() >= 0 ? HudTheme.GREEN : HudTheme.RED);
        HudDraw.sparkline(g, ix, y + 133, iw, 14, d.retHist(), HudTheme.CYAN, true);
        Gfx.text(c, "ENTROPY", ix, y + 150, HudTheme.DIM);
        Gfx.textR(c, String.format(Locale.ROOT, "%.2f / floor %.2f", STATE.entropy, Trainer.entropyFloorNow), x + w - 8, y + 150, HudTheme.entropyColor(STATE.entropy));
        double hi = Math.max(1.0, entropyMax(d.entHist()));
        HudDraw.lineGraph(g, ix, y + 160, iw - 66, 12, d.entHist(), 0, hi, HudTheme.entropyColor(STATE.entropy), Trainer.entropyFloorNow);
        // last results, newest on the right
        HudDraw.results(g, ix + iw - 62, y + 160, 62, 12, d.resHist());
    }

    private static double entropyMax(float[] v) {
        double m = 0;
        if (v != null) for (float e : v) m = Math.max(m, e);
        return m * 1.1;
    }

    private static void share(Ctx c, String label, double frac, int x, int y, int w, int color, boolean has) {
        Gfx.text(c, label, x, y, HudTheme.DIM);
        Gfx.bar(c.g, x, y + 9, w, 3, has ? clamp(frac, 0, 1) : 0, color);
        Gfx.text(c, has ? String.format(Locale.ROOT, "%.0f%%", frac * 100) : "--", x, y + 13, has ? HudTheme.TEXT : HudTheme.DIM);
    }

    // ======================================================================================================== CROSSHAIR ASSIST
    /**
     * Thin charge meter under the crosshair with the legal-swing notch, plus a dot that drifts toward the enemy so the
     * off-axis direction is readable without looking at the side panels. Drawn only while a target is tracked.
     */
    private static void drawCrosshairAssist(Ctx c) {
        Data d = c.d; GuiGraphics g = c.g;
        if (!d.live()) return;
        int cx = c.sw / 2, cy = c.sh / 2;
        int w = 30, x = cx - w / 2, y = cy + 14;
        boolean ready = c.charge >= d.attackThreshold();
        g.fill(x - 1, y - 1, x + w + 1, y + 4, HudTheme.alpha(0x050A12, 0x90));
        Gfx.bar(g, x, y, w, 2, c.charge, ready ? HudTheme.LIME : HudTheme.YELLOW);
        int notch = x + (int) Math.round(w * d.attackThreshold());
        g.fill(notch, y - 1, notch + 1, y + 3, HudTheme.WHITE);
        if (ready && d.dist() <= Config.ATTACK_REACH + 0.3) g.fill(cx - 1, y + 5, cx + 2, y + 6, HudTheme.alpha(HudTheme.LIME, (int) (140 + 100 * c.pulse())));
        // off-axis pointer: hidden while the crosshair is on target
        double ex = d.yawErrDeg(), ey = d.pitchErrDeg();
        if (Math.abs(ex) > 3.0 || Math.abs(ey) > 3.0) {
            double ang = Math.atan2(ey, -ex), mag = clamp(Math.hypot(ex / 45.0, ey / 30.0), 0, 1);
            int rad = 10 + (int) Math.round(mag * 10);
            int px = cx + (int) Math.round(Math.cos(ang) * rad), py = cy + (int) Math.round(Math.sin(ang) * rad);
            int col = HudTheme.aimColor(ex, ey);
            g.fill(px - 1, py - 1, px + 2, py + 2, col);
            g.fill(px, py - 2, px + 1, py - 1, HudTheme.alpha(col, 0x80));
        }
    }

    // ======================================================================================================== ALERTS / MINI / TOAST
    private static void drawAlerts(Ctx c) {
        int n = STATE.updateAlerts(c.d);
        if (n == 0) return;
        int y = 6, total = 0;
        for (int i = 0; i < n; i++) total += c.f.width(STATE.alertText(i)) + 16;
        int x = (c.sw - total) / 2;
        for (int i = 0; i < n; i++) {
            String t = STATE.alertText(i); // stored uppercase constants; no per-frame conversion
            int color = STATE.alertColor(i);
            int tw = c.f.width(t) + 12;
            int accent = color == HudTheme.RED ? HudTheme.lerp(HudTheme.RED, HudTheme.WHITE, c.pulse() * 0.35) : color;
            Gfx.facet(c.g, x, y, tw, c.f.lineHeight + 8, accent, Gfx.bg(0x1A0A10, 0xD8), 3);
            Gfx.text(c, t, x + 6, y + 5, accent);
            x += tw + 4;
        }
    }

    private static void drawMini(Ctx c) {
        Data d = c.d; GuiGraphics g = c.g;
        int w = Math.min(232, c.sw - 12), h = c.f.lineHeight + 17, x = MARGIN, y = MARGIN;
        int accent = d.play() ? HudTheme.CYAN : HudTheme.PURPLE;
        Gfx.facet(g, x, y, w, h, accent);
        String head = (d.play() ? "LIVE" : "TRAIN") + "  S" + d.stage() + "  " + (d.live() ? Gfx.fit(c.f, safe(d.target(), d.opponent()), w - 100) : "STANDBY");
        Gfx.text(c, head, x + 8, y + 5, HudTheme.TEXT);
        Gfx.textR(c, d.live() ? String.format(Locale.ROOT, "%.1fm", d.dist()) : (int) Math.round(c.charge * 100) + "%", x + w - 8, y + 5, d.live() ? HudTheme.distColor(d.dist()) : HudTheme.LIME);
        int by = y + h - 7, half = (w - 20) / 2;
        Gfx.bar(g, x + 8, by, half, 2, d.live() ? clamp(STATE.myHp / 20.0, 0, 1) : 0, HudTheme.hpColor(STATE.myHp / 20.0));
        Gfx.bar(g, x + 12 + half, by, half, 2, d.live() ? clamp(STATE.oppHp / 20.0, 0, 1) : 0, HudTheme.RED);
        if (d.play() && d.live() && d.intent() != null && !d.intent().isBlank()) {
            String t = d.intent().replace('_', ' ');
            Gfx.textR(c, Gfx.fit(c.f, t, 90), x + w - 8, y + h + 3, intentColor(d.intent()));
        }
        // swing-ready pip: lit when a full-damage hit is legal right now
        boolean ready = c.charge >= d.attackThreshold();
        g.fill(x + w - 6, y + 3, x + w - 3, y + 6, ready ? HudTheme.LIME : HudTheme.alpha(HudTheme.YELLOW, 0x80));
    }

    private static void drawToast(Ctx c) {
        if (!STATE.toastActive()) return;
        int a = STATE.toastAlpha();
        String t = STATE.toastText();
        int w = Math.min(c.sw - 12, c.f.width(t) + 22), x = (c.sw - w) / 2, y = c.sh - 62;
        int col = STATE.toastColor();
        Gfx.facet(c.g, x, y, w, c.f.lineHeight + 11, col, HudTheme.alpha(0x090D18, Math.min((int) (0xD0 * Settings.opacity), a)), 4);
        Gfx.text(c, Gfx.fit(c.f, t, w - 16), x + 9, y + 5, HudTheme.alpha(col, Math.max(a, 0x20)));
    }

    // ======================================================================================================== SWING ACCURACY
    /**
     * Session swing statistics. The charge histogram shows how charged the cooldown was when each click went out: a healthy fighter
     * piles up in the top bins (at or after the white threshold tick); a lot of mass on the left means early, low-damage swings.
     */
    private static void drawAccuracy(Ctx c, int x, int y, int w) {
        GuiGraphics g = c.g;
        int n = Anim.swings;
        double acc = n == 0 ? 0 : Anim.swingHits / (double) n;
        Gfx.facet(g, x, y, w, H_ACCURACY, HudTheme.LIME);
        Gfx.title(c, "SWING ACCURACY", n == 0 ? "--" : String.format(Locale.ROOT, "%.0f%%", acc * 100), x, y, w, n == 0 ? HudTheme.DIM : HudTheme.rateColor(acc));
        int half = (w - 16) / 2;
        Gfx.text(c, "SWINGS", x + 8, y + 17, HudTheme.DIM);
        Gfx.text(c, String.valueOf(n), x + 8, y + 26, HudTheme.TEXT);
        Gfx.text(c, "HITS", x + 8 + half, y + 17, HudTheme.DIM);
        Gfx.text(c, String.valueOf(Anim.swingHits), x + 8 + half, y + 26, HudTheme.GREEN);
        // hit / miss / wrong-entity proportion bar
        int bx = x + 8, bw = w - 16, by = y + 38;
        g.fill(bx, by, bx + bw, by + 4, HudTheme.TRACK);
        if (n > 0) {
            int hw = (int) Math.round(bw * Anim.swingHits / (double) n), mw = (int) Math.round(bw * Anim.swingMisses / (double) n);
            g.fill(bx, by, bx + hw, by + 4, HudTheme.GREEN);
            g.fill(bx + hw, by, Math.min(bx + bw, bx + hw + mw), by + 4, HudTheme.RED);
            if (hw + mw < bw) g.fill(bx + hw + mw, by, bx + bw, by + 4, HudTheme.ORANGE);
        }
        Gfx.text(c, "STREAK " + Anim.hitStreak + " (BEST " + Anim.bestStreak + ")", x + 8, y + 46, Anim.hitStreak >= 3 ? HudTheme.LIME : HudTheme.DIM);

        // charge-at-swing histogram
        int hx = x + 8, hy = y + 57, hw = w - 16, hh = 18;
        g.fill(hx, hy, hx + hw, hy + hh, HudTheme.GRAPH_BG);
        int peak = 1;
        for (int v : Anim.chargeBins) peak = Math.max(peak, v);
        int cell = Math.max(2, hw / Anim.CHARGE_BINS);
        double thr = c.d.attackThreshold();
        for (int i = 0; i < Anim.CHARGE_BINS; i++) {
            int bh = (int) Math.round((hh - 2) * Anim.chargeBins[i] / (double) peak);
            boolean late = (i + 1) / (double) Anim.CHARGE_BINS > thr - 1e-9;
            g.fill(hx + i * cell, hy + hh - 1 - bh, hx + i * cell + cell - 1, hy + hh - 1, late ? HudTheme.alpha(HudTheme.GREEN, 0xD0) : HudTheme.alpha(HudTheme.ORANGE, 0xD0));
        }
        int tx = hx + (int) Math.round(Math.min(hw, cell * Anim.CHARGE_BINS) * thr);
        g.fill(tx, hy - 1, tx + 1, hy + hh + 1, HudTheme.WHITE);
        double avg = n == 0 ? 0 : Anim.chargeSum / n;
        Gfx.text(c, n == 0 ? "AVG CHARGE --" : String.format(Locale.ROOT, "AVG CHARGE %.0f%%", avg * 100), x + 8, y + H_ACCURACY - 14, n == 0 ? HudTheme.DIM : avg >= thr ? HudTheme.GREEN : HudTheme.YELLOW);
        Gfx.textR(c, n == 0 ? "" : String.format(Locale.ROOT, "EARLY %.0f%%", 100.0 * Anim.earlySwings / n), x + w - 8, y + H_ACCURACY - 14, Anim.earlySwings * 4 > n ? HudTheme.ORANGE : HudTheme.DIM);
    }

    // ======================================================================================================== DUEL TIMELINE
    /** Both health values over the current fight (about 20 s of history) with the running lead underneath. */
    private static void drawTimeline(Ctx c, int x, int y, int w) {
        Data d = c.d; GuiGraphics g = c.g;
        boolean live = d.live();
        Gfx.facet(g, x, y, w, H_TIMELINE, live ? HudTheme.RED : HudTheme.DIM);
        Gfx.title(c, "DUEL TIMELINE", live ? String.format(Locale.ROOT, "%+.0f HP", d.hpLead()) : "--", x, y, w, !live ? HudTheme.DIM : d.hpLead() > 0.5 ? HudTheme.GREEN : d.hpLead() < -0.5 ? HudTheme.RED : HudTheme.YELLOW);
        int gx = x + 8, gy = y + 17, gw = w - 16, gh = 34;
        g.fill(gx, gy, gx + gw, gy + gh, HudTheme.GRAPH_BG);
        for (int hp = 5; hp < 20; hp += 5) g.fill(gx, gy + gh - 1 - (int) Math.round(hp / 20.0 * (gh - 2)), gx + gw, gy + gh - (int) Math.round(hp / 20.0 * (gh - 2)), HudTheme.alpha(HudTheme.FAINT, 0x70));
        Gfx.series(g, gx, gy, gw, gh, Anim.tlOpp, Anim.tlN, 20f, HudTheme.RED);
        Gfx.series(g, gx, gy, gw, gh, Anim.tlMy, Anim.tlN, 20f, HudTheme.GREEN);
        // lead bar: green to the right when I am ahead
        Gfx.text(c, "LEAD", x + 8, y + 55, HudTheme.DIM);
        double lead = live ? clamp(d.hpLead() / 20.0, -1, 1) : 0;
        int lx = x + 36, lw = w - 44;
        Gfx.centeredBar(g, lx, y + 57, lw, 4, lead, lead >= 0 ? HudTheme.GREEN : HudTheme.RED);
        Gfx.text(c, String.format(Locale.ROOT, "DEALT %.0f", Anim.dealtTotal), x + 8, y + H_TIMELINE - 11, HudTheme.GREEN);
        Gfx.textR(c, String.format(Locale.ROOT, "TAKEN %.0f", Anim.takenTotal), x + w - 8, y + H_TIMELINE - 11, HudTheme.RED);
    }

    // ======================================================================================================== SESSION / PERFORMANCE
    private static void drawPerf(Ctx c, int x, int y, int w) {
        Data d = c.d; GuiGraphics g = c.g;
        Gfx.facet(g, x, y, w, H_PERF, HudTheme.BLUE);
        Gfx.title(c, "SESSION", String.format(Locale.ROOT, "%.0f FPS", Anim.fps), x, y, w, Anim.fps >= 50 ? HudTheme.GREEN : Anim.fps >= 30 ? HudTheme.YELLOW : HudTheme.RED);
        Gfx.text(c, "TICKS/S", x + 8, y + 17, HudTheme.DIM);
        Gfx.textR(c, Anim.ticksPerSec < 1 ? "--" : String.format(Locale.ROOT, "%.1f", Anim.ticksPerSec), x + w - 8, y + 17, HudTheme.TEXT);
        String eta = "--";
        if (!d.play() && Anim.progressRate > 1e-7 && d.progress() < 1.0) eta = formatDuration((1.0 - d.progress()) / Anim.progressRate);
        else if (d.progress() >= 1.0) eta = "DONE";
        Gfx.text(c, "NEXT STAGE", x + 8, y + 28, HudTheme.DIM);
        Gfx.textR(c, eta, x + w - 8, y + 28, HudTheme.TEXT);
        Gfx.text(c, "WIN TREND", x + 8, y + 39, HudTheme.DIM);
        double t = Anim.trend;
        String arrow = !d.hasStats() ? "--" : t > 0.12 ? "RISING" : t < -0.12 ? "FALLING" : "FLAT";
        Gfx.textR(c, arrow, x + w - 8, y + 39, !d.hasStats() ? HudTheme.DIM : t > 0.12 ? HudTheme.GREEN : t < -0.12 ? HudTheme.RED : HudTheme.YELLOW);
        Gfx.text(c, "BEST STREAK", x + 8, y + 50, HudTheme.DIM);
        Gfx.textR(c, String.valueOf(Anim.bestStreak), x + w - 8, y + 50, Anim.bestStreak >= 3 ? HudTheme.LIME : HudTheme.TEXT);
    }

    private static String formatDuration(double seconds) {
        if (!Double.isFinite(seconds) || seconds < 0) return "--";
        long s = (long) seconds;
        if (s >= 86400) return String.format(Locale.ROOT, "%dd %dh", s / 86400, (s % 86400) / 3600);
        if (s >= 3600) return String.format(Locale.ROOT, "%dh %02dm", s / 3600, (s % 3600) / 60);
        if (s >= 60) return String.format(Locale.ROOT, "%dm %02ds", s / 60, s % 60);
        return s + "s";
    }

    // ======================================================================================================== EVENT FEED
    /** Short-lived combat log centred under the alert strip: hits, damage taken, misses, intent changes. Newest line on top. */
    private static void drawFeed(Ctx c) {
        if (Anim.feedN == 0) return;
        int w = 150, x = (c.sw - w) / 2, y = 24, row = c.f.lineHeight + 2;
        int shown = 0;
        for (int i = Anim.feedN - 1; i >= 0; i--) {
            Anim.Event e = Anim.feed[i];
            long age = c.now - e.at();
            if (age > FEED_LIFE_MS) continue;
            double fade = age < FEED_LIFE_MS - 1200 ? 1.0 : clamp((FEED_LIFE_MS - age) / 1200.0, 0, 1);
            int a = (int) (255 * fade);
            int ty = y + shown * row;
            c.g.fill(x, ty - 1, x + w, ty + row - 1, HudTheme.alpha(0x050A12, (int) (0x78 * fade * Settings.opacity)));
            c.g.fill(x, ty - 1, x + 2, ty + row - 1, HudTheme.alpha(e.color(), a));
            Gfx.text(c, Gfx.fit(c.f, e.text(), w - 12), x + 6, ty, HudTheme.alpha(e.color(), Math.max(a, 0x30)));
            if (++shown >= FEED_LINES) break;
        }
    }

    // ======================================================================================================== STAGE LADDER
    /** All curriculum stages with the current one highlighted: finished stages are ticked, the active one shows live progress. */
    private static void drawLadder(Ctx c, int x, int y, int w) {
        Data d = c.d; GuiGraphics g = c.g;
        int rows = Math.max(1, d.stages()), rowH = 14, h = 20 + rows * rowH + 4;
        Gfx.facet(g, x, y, w, h, HudTheme.PURPLE);
        Gfx.title(c, "CURRICULUM", d.stage() + "/" + rows, x, y, w, HudTheme.PURPLE);
        for (int s = 1; s <= rows; s++) {
            int ry = y + 18 + (s - 1) * rowH;
            boolean done = s < d.stage(), cur = s == d.stage();
            int col = done ? HudTheme.GREEN : cur ? HudTheme.WHITE : HudTheme.DIM;
            if (cur) {
                g.fill(x + 4, ry - 2, x + w - 4, ry + rowH - 3, HudTheme.alpha(HudTheme.PURPLE, 0x30));
                g.fill(x + 4, ry - 2, x + 6, ry + rowH - 3, HudTheme.PURPLE);
            }
            Gfx.text(c, done ? "+" : cur ? ">" : String.valueOf(s), x + 9, ry, col);
            String label = stageLabel(s);
            Gfx.text(c, Gfx.fit(c.f, label, w - 30), x + 20, ry, col);
            if (cur) Gfx.bar(g, x + 20, ry + 9, w - 30, 1, d.progress(), HudTheme.PURPLE);
        }
    }

    private static String stageLabel(int stage) {
        try {
            String l = Curriculum.opponentFor(stage).label;
            return l == null || l.isBlank() ? "Stage " + stage : l;
        } catch (RuntimeException e) {
            return "Stage " + stage;
        }
    }

    // ======================================================================================================== BEARING TAPE
    /**
     * Compass-style tape above the crosshair. The caret is where you are looking; the diamond is the enemy. Anything beyond the tape
     * range pins to the edge with an arrow, so "which way do I turn" is readable at a glance even when the enemy is behind you.
     */
    private static void drawBearingTape(Ctx c) {
        Data d = c.d; GuiGraphics g = c.g;
        if (!d.live()) return;
        int w = 124, x = (c.sw - w) / 2, y = c.sh / 2 - 38, h = 11, range = 60;
        g.fill(x, y, x + w, y + h, Gfx.bg(0x050A12, 0x98));
        Gfx.outline(g, x, y, w, h, HudTheme.alpha(HudTheme.BLUE, 0x60));
        for (int deg = -range; deg <= range; deg += 15) {
            int tx = x + w / 2 + (int) Math.round(deg / (double) range * (w / 2 - 3));
            boolean major = deg % 30 == 0;
            g.fill(tx, y + (major ? 6 : 8), tx + 1, y + h - 1, major ? HudTheme.DIM : HudTheme.FAINT);
        }
        g.fill(x + w / 2 - 1, y + 1, x + w / 2 + 2, y + 3, HudTheme.CYAN);
        double bearing = Math.toDegrees(Math.atan2(d.mapRight(), d.mapForward()));   // + = enemy to the right
        boolean beyond = Math.abs(bearing) > range;
        double shown = clamp(bearing, -range, range);
        int mx = x + w / 2 + (int) Math.round(shown / range * (w / 2 - 3));
        int col = Math.abs(bearing) <= 8 ? HudTheme.GREEN : Math.abs(bearing) <= 30 ? HudTheme.YELLOW : HudTheme.RED;
        Gfx.diamond(g, mx, y + 6, beyond ? 2 : 3, col);
        if (beyond) Gfx.text(c, bearing > 0 ? ">" : "<", bearing > 0 ? x + w + 3 : x - 8, y + 1, col);
    }

    // ======================================================================================================== HIT FEEDBACK
    /**
     * Screen-space feedback that needs no panel: a hit marker around the crosshair when the enemy takes damage, a red edge flash
     * when we do, and a slow edge pulse while health is critical. All driven by {@link Anim} flashes, so it is purely cosmetic.
     */
    private static void drawHitFx(Ctx c) {
        Data d = c.d; GuiGraphics g = c.g;
        if (!d.live()) return;
        int cx = c.sw / 2, cy = c.sh / 2;
        if (Anim.oppHit > 0.02) {
            int r = 5 + (int) Math.round((1.0 - Anim.oppHit) * 6), a = (int) (Anim.oppHit * 230), col = HudTheme.alpha(HudTheme.WHITE, a);
            for (int k = 0; k < 4; k++) {
                int sx = (k & 1) == 0 ? -1 : 1, sy = (k & 2) == 0 ? -1 : 1;
                for (int i = 0; i < 3; i++) g.fill(cx + sx * (r + i), cy + sy * (r + i), cx + sx * (r + i) + 1, cy + sy * (r + i) + 1, col);
            }
        }
        double edge = Anim.myHit * 0.9;
        if (d.myHp() <= 6.0) edge = Math.max(edge, (0.25 + 0.2 * c.pulse()) * (1.0 - d.myHp() / 7.0));
        if (edge > 0.02) {
            int a = (int) Math.min(0x90, edge * 0x90), col = HudTheme.alpha(HudTheme.RED, a), t = 3;
            g.fill(0, 0, c.sw, t, col); g.fill(0, c.sh - t, c.sw, c.sh, col);
            g.fill(0, 0, t, c.sh, col); g.fill(c.sw - t, 0, c.sw, c.sh, col);
        }
    }

    // ======================================================================================================== small utilities
    static String compactNumber(long n) {
        if (n >= 1_000_000) return String.format(Locale.ROOT, "%.2fM", n / 1_000_000.0);
        if (n >= 10_000) return String.format(Locale.ROOT, "%.1fk", n / 1000.0);
        return String.valueOf(n);
    }

    private static String safe(String s, String fallback) { return s == null || s.isBlank() ? fallback : s; }
    private static double clamp(double value, double lo, double hi) { return Math.max(lo, Math.min(hi, value)); }

    // ======================================================================================================== DRAWING PRIMITIVES
    /** Shape and text helpers. Only {@code GuiGraphics.fill} / {@code drawString} are used so a Minecraft version bump rarely breaks them. */
    private static final class Gfx {
        private Gfx() {}
        private static final int[] COS_DEG = new int[360];
        private static final int[] SIN_DEG = new int[360];
        static {
            for (int i = 0; i < 360; i++) {
                COS_DEG[i] = (int) Math.round(Math.cos(Math.toRadians(i)) * 1_000_000.0);
                SIN_DEG[i] = (int) Math.round(Math.sin(Math.toRadians(i)) * 1_000_000.0);
            }
        }

        /** Panel background with the user's opacity applied. */
        static int bg(int rgb, int alpha) { return HudTheme.alpha(rgb, (int) Math.round(alpha * Settings.opacity)); }

        static void facet(GuiGraphics g, int x, int y, int w, int h, int accent) { facet(g, x, y, w, h, chrome(accent), bg(0x07111E, 0xD8), 5); }

        /** Applies the active theme to a chrome colour. */
        static int chrome(int accent) { return Settings.theme.apply(accent); }

        /** Chamfered panel: stepped corners, a bright top edge, dimmer side/bottom edges and two corner glints. */
        static void facet(GuiGraphics g, int x, int y, int w, int h, int accent, int background, int cut) {
            if (w <= 2 || h <= 2) return;
            int c = Math.max(1, Math.min(cut, Math.min(w / 4, h / 3)));
            // Batch the full-width middle into one fill; keep the stepped corner rows pixel-identical.
            for (int row = 0; row < c; row++) {
                int inset = c - row;
                g.fill(x + inset, y + row, x + w - inset, y + row + 1, background);
            }
            int middleTop = y + c, middleBottom = y + h - c;
            if (middleBottom > middleTop) g.fill(x, middleTop, x + w, middleBottom, background);
            for (int row = 0; row < c; row++) {
                int inset = row + 1;
                int yy = y + h - c + row;
                g.fill(x + inset, yy, x + w - inset, yy + 1, background);
            }
            g.fill(x + c, y, x + w - c, y + 1, accent);
            g.fill(x + 1, y + c, x + 2, y + h - c, HudTheme.alpha(accent, 0x90));
            g.fill(x + w - 2, y + c, x + w - 1, y + h - c, HudTheme.alpha(accent, 0x60));
            g.fill(x + c, y + h - 1, x + w - c, y + h, HudTheme.alpha(accent, 0x70));
            g.fill(x + 2, y + c - 1, x + c + 1, y + c, HudTheme.alpha(accent, 0x90));
            g.fill(x + w - c - 1, y + h - c, x + w - 2, y + h - c + 1, HudTheme.alpha(accent, 0x70));
        }

        /** Header row: bold title on the left, state label on the right. */
        static void title(Ctx c, String left, String right, int x, int y, int w, int rightColor) {
            text(c, left, x + 8, y + 5, HudTheme.TEXT);
            textR(c, right, x + w - 8, y + 5, rightColor);
        }

        static void text(Ctx c, String s, int x, int y, int color) { HudDraw.text(c.g, c.f, s, x, y, color); }
        static void textR(Ctx c, String s, int xRight, int y, int color) { HudDraw.textR(c.g, c.f, s, xRight, y, color); }
        static void textC(Ctx c, String s, int xCentre, int y, int color) { HudDraw.textC(c.g, c.f, s, xCentre, y, color); }
        static String fit(Font f, String s, int maxW) { return HudDraw.fit(f, s, Math.max(8, maxW)); }

        static void bar(GuiGraphics g, int x, int y, int w, int h, double frac, int color) { HudDraw.bar(g, x, y, w, h, frac, color); }
        static void outline(GuiGraphics g, int x, int y, int w, int h, int color) { HudDraw.outline(g, x, y, w, h, color); }
        static void segmented(GuiGraphics g, int x, int y, int w, int h, int cells, double frac, int color) { HudDraw.segmented(g, x, y, w, h, cells, frac, color); }

        /** Bar from the centre outwards, value -1..1, the same colour on both sides (direction is shown by the side). */
        static void centeredBar(GuiGraphics g, int x, int y, int w, int h, double v, int color) {
            g.fill(x, y, x + w, y + h, HudTheme.TRACK);
            int mid = x + w / 2, n = (int) Math.round(Math.abs(v) * (w / 2));
            if (v >= 0) g.fill(mid, y, mid + n, y + h, color); else g.fill(mid - n, y, mid, y + h, color);
            g.fill(mid, y - 1, mid + 1, y + h + 1, HudTheme.FAINT);
        }

        /** Dotted arc, angles in degrees (0 = east, clockwise on screen). */
        private static int roundMillion(long value) {
            // Java integer division truncates toward zero; handle negative sine/cosine values symmetrically.
            return value >= 0 ? (int) ((value + 500_000L) / 1_000_000L)
                              : (int) -((-value + 500_000L) / 1_000_000L);
        }

        static void arc(GuiGraphics g, int cx, int cy, int r, int start, int end, int color, int step) {
            int s = Math.max(1, step);
            for (int deg = start; deg <= end; deg += s) {
                int a = Math.floorMod(deg, 360);
                int px = cx + roundMillion((long) COS_DEG[a] * r);
                int py = cy + roundMillion((long) SIN_DEG[a] * r);
                g.fill(px, py, px + 2, py + 2, color);
            }
        }

        /** Bresenham line made of {@code width}-pixel squares. */
        static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int color, int width) {
            int dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
            int dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
            int err = dx + dy, w = Math.max(1, width);
            for (int guard = 0; guard < 4096; guard++) {
                g.fill(x0 - w / 2, y0 - w / 2, x0 - w / 2 + w, y0 - w / 2 + w, color);
                if (x0 == x1 && y0 == y1) break;
                int e2 = 2 * err;
                if (e2 >= dy) { err += dy; x0 += sx; }
                if (e2 <= dx) { err += dx; y0 += sy; }
            }
        }

        static void diamond(GuiGraphics g, int cx, int cy, int r, int color) {
            line(g, cx, cy - r, cx + r, cy, color, 2);
            line(g, cx + r, cy, cx, cy + r, color, 2);
            line(g, cx, cy + r, cx - r, cy, color, 2);
            line(g, cx - r, cy, cx, cy - r, color, 2);
            g.fill(cx - 1, cy - 1, cx + 2, cy + 2, color);
        }

        /** Polyline of the first {@code n} samples of {@code v}, scaled 0..max over the box; draws a vertical step between neighbours. */
        static void series(GuiGraphics g, int x, int y, int w, int h, float[] v, int n, float max, int color) {
            if (v == null || n < 1) return;
            int prev = Integer.MIN_VALUE;
            for (int i = 0; i < n; i++) {
                int px = x + (n == 1 ? 0 : (int) Math.round((double) i / (n - 1) * (w - 1)));
                int py = y + h - 1 - (int) Math.round(clamp(v[i] / max, 0, 1) * (h - 2));
                if (prev == Integer.MIN_VALUE) g.fill(px, py, px + 1, py + 1, color);
                else g.fill(px, Math.min(py, prev), px + 1, Math.max(py, prev) + 1, color);
                prev = py;
            }
        }

        /** Signed trace directly from a ring buffer; avoids per-frame array allocations and copies. */
        static void traceRing(GuiGraphics g, int x, int y, int w, int h, float[] ring, int head, double range, int color) {
            if (ring == null || ring.length < 2) return;
            int mid = y + h / 2, prev = Integer.MIN_VALUE, n = ring.length;
            for (int i = 0; i < n; i++) {
                float value = ring[(head + i) % n];
                int px = x + (int) Math.round((double) i / (n - 1) * (w - 1));
                int py = mid - (int) Math.round(clamp(value / range, -1, 1) * (h / 2.0));
                if (prev == Integer.MIN_VALUE) g.fill(px, py, px + 1, py + 1, color);
                else g.fill(px, Math.min(py, prev), px + 1, Math.max(py, prev) + 1, color);
                prev = py;
            }
        }

        /** Signed line trace centred on zero; {@code range} is the value that touches the top/bottom edge. */
        static void trace(GuiGraphics g, int x, int y, int w, int h, float[] v, double range, int color) {
            if (v == null || v.length < 2) return;
            int mid = y + h / 2, prev = Integer.MIN_VALUE;
            for (int i = 0; i < v.length; i++) {
                int px = x + (int) Math.round((double) i / (v.length - 1) * (w - 1));
                int py = mid - (int) Math.round(clamp(v[i] / range, -1, 1) * (h / 2.0));
                if (prev == Integer.MIN_VALUE) g.fill(px, py, px + 1, py + 1, color);
                else g.fill(px, Math.min(py, prev), px + 1, Math.max(py, prev) + 1, color);
                prev = py;
            }
        }
    }
}
