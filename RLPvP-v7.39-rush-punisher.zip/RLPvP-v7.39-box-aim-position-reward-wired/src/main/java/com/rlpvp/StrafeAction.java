package com.rlpvp;

/** Resolves the policy's conditional strafe action. Neutral + hold continues the previous lateral input;
 * a sampled left/right decision always overrides it. This is a learned action branch, not a fixed-duration script. */
final class StrafeAction {
    private StrafeAction() {}
    static int resolve(int sampledCategory, boolean hold, int previousDirection) {
        int requested = Math.max(0, Math.min(2, sampledCategory)) - 1;
        int previous = Math.max(-1, Math.min(1, previousDirection));
        return requested == 0 && hold ? previous : requested;
    }
    static int category(int resolvedDirection) { return Math.max(0, Math.min(2, resolvedDirection + 1)); }
}
