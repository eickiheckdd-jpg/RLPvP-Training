package com.rlpvp;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Confidence-aware opponent model. The legacy descriptive signals remain available to the optional
 * tactical diagnostics, while the eight habit features are kept semantically aligned with
 * OpponentMemory so a learned policy can use persistent opponent history without an action script.
 *
 * Profiles are keyed by opponent name, bounded, and serialized in the situational checkpoint
 * trailer. The model never chooses an action.
 */
final class OpponentBehaviorModel {
    private static final int MAGIC_V1 = 0x4F504D31; // OPM1, legacy profile layout
    private static final int MAGIC_V2 = 0x4F504D32; // OPM2, persistent policy-habit features
    private static final int MAX_PROFILES = 16;
    // Four seconds at 20 TPS before a newly encountered opponent's noisy local habits replace
    // the actor's current-episode memory. Existing profiles remain available immediately.
    private static final long MIN_POLICY_HISTORY_SAMPLES = 80;
    private static final double ALPHA = 0.035;
    private static final int COUNTER_WINDOW = 20;

    static final class Profile {
        // Legacy descriptive fields retained for compatibility with the optional tactical suite.
        double attackRate = 0.08, sprintRate = 0.25, jumpRate = 0.15;
        double retreatRate = 0.25, sideBias = 0.0, counterRate = 0.5;

        // Features mirror OpponentMemory.HABITS and are consumed by the trained actor.
        double strafeActivity, strafeFlipRate, sprintShare, airborneRate, swingRate, preferredDistance, approachPressure;
        long samples;
        long habitSamples;
        long flipSamples;

        Profile copy() {
            Profile p = new Profile();
            p.attackRate = attackRate; p.sprintRate = sprintRate; p.jumpRate = jumpRate;
            p.retreatRate = retreatRate; p.sideBias = sideBias; p.counterRate = counterRate;
            p.strafeActivity = strafeActivity; p.strafeFlipRate = strafeFlipRate;
            p.sprintShare = sprintShare; p.airborneRate = airborneRate; p.swingRate = swingRate;
            p.preferredDistance = preferredDistance;
            p.approachPressure = approachPressure; p.samples = samples; p.habitSamples = habitSamples;
            p.flipSamples = flipSamples;
            return p;
        }
        double confidence() { return Math.min(1.0, samples / 80.0); }
        boolean hasPolicyHistory() { return habitSamples >= MIN_POLICY_HISTORY_SAMPLES; }
    }

    private final LinkedHashMap<String, Profile> profiles = new LinkedHashMap<>();
    private String key = "unknown";
    private Profile active = new Profile();
    private boolean prevSwing, prevAir;
    private int previousSide, counterLeft;
    private double prevEnemyHp = -1, prevOwnHp = -1;
    private long episodeSamples;
    private double latestThreat;

    void beginEpisode(String opponentKey) {
        persistActive();
        key = sanitise(opponentKey);
        Profile prior = profiles.remove(key); // touch the key in insertion order (bounded LRU)
        active = prior == null ? new Profile() : prior.copy();
        if (prior != null) profiles.put(key, prior);
        resetTransient();
        trimProfiles();
    }

    void resetTransient() {
        prevSwing = prevAir = false;
        previousSide = 0;
        counterLeft = 0;
        prevEnemyHp = prevOwnHp = -1;
        episodeSamples = 0;
        latestThreat = 0;
    }

    void observe(float[] obs, SituationalStateInterpreter.State s) {
        if (obs == null || obs.length < Config.FRAME || s == null) return;

        boolean swing = s.enemySwing > 0.5f;
        boolean air = s.enemyGround < 0.5f;
        boolean swingEdge = swing && !prevSwing;
        boolean airEdge = air && !prevAir;

        // Legacy diagnostics: keep the existing intent classifier's semantics stable.
        emaLegacy("attack", swingEdge ? 1.0 : 0.0, ALPHA);
        emaLegacy("sprint", s.enemySprint > 0.5f ? 1.0 : 0.0, ALPHA);
        emaLegacy("jump", airEdge ? 1.0 : 0.0, ALPHA);

        double approach = opponentApproach(s);
        emaLegacy("retreat", approach < -0.08 ? 1.0 : 0.0, ALPHA);
        if (Math.abs(s.enemySideVelocity) > 0.04f)
            emaLegacy("side", Math.signum(s.enemySideVelocity), ALPHA);

        // Policy habits use the same activity threshold as OpponentMemory (0.02). Keep the
        // older 0.04 threshold above only for legacy tactical diagnostics.
        int side = Math.abs(s.enemySideVelocity) > 0.02f ? (s.enemySideVelocity > 0 ? 1 : -1) : 0;
        emaHabit("strafeActivity", side != 0 ? 1.0 : 0.0);
        if (side != 0) {
            emaHabit("strafeFlipRate", previousSide != 0 && side != previousSide ? 1.0 : 0.0,
                active.flipSamples + 1);
            active.flipSamples++;
            previousSide = side;
        }
        emaHabit("sprintRate", s.enemySprint > 0.5f ? 1.0 : 0.0);
        emaHabit("airborneRate", air ? 1.0 : 0.0);
        emaHabit("swingRate", swingEdge ? 1.0 : 0.0);
        emaHabit("preferredDistance", clamp01(s.distance / 6.0));
        emaHabit("approachPressure", approach);

        if (prevEnemyHp >= 0 && prevOwnHp >= 0) {
            boolean enemyHit = s.enemyHealth < prevEnemyHp - 0.005;
            boolean selfHit = s.ownHealth < prevOwnHp - 0.005;
            if (selfHit && counterLeft > 0) {
                emaLegacy("counter", 1.0, 0.20);
                counterLeft = 0;
            } else if (counterLeft > 0 && --counterLeft == 0) {
                emaLegacy("counter", 0.0, 0.20);
            }
            if (enemyHit) counterLeft = COUNTER_WINDOW;
        }

        prevSwing = swing;
        prevAir = air;
        prevEnemyHp = s.enemyHealth;
        prevOwnHp = s.ownHealth;
        episodeSamples++;
        active.samples++;
        active.habitSamples++;
        latestThreat = clamp01((s.enemySwing > 0.5f ? 0.60 : 0.0)
            + (s.enemyCharge < 0.22f && s.meInEnemyReach > 0.5f ? 0.22 : 0.0)
            + (s.enemyFacing > 0.45f && s.distance < 3.4f ? 0.18 : 0.0));
    }

    private void emaLegacy(String field, double value, double alpha) {
        switch (field) {
            case "attack" -> active.attackRate += alpha * (value - active.attackRate);
            case "sprint" -> active.sprintRate += alpha * (value - active.sprintRate);
            case "jump" -> active.jumpRate += alpha * (value - active.jumpRate);
            case "retreat" -> active.retreatRate += alpha * (value - active.retreatRate);
            case "side" -> active.sideBias += alpha * (value - active.sideBias);
            case "counter" -> active.counterRate += alpha * (value - active.counterRate);
            default -> { }
        }
    }

    private void emaHabit(String field, double value) {
        emaHabit(field, value, active.habitSamples + 1);
    }

    private void emaHabit(String field, double value, long sampleCount) {
        double current;
        switch (field) {
            case "strafeActivity" -> current = active.strafeActivity;
            case "strafeFlipRate" -> current = active.strafeFlipRate;
            case "sprintRate" -> current = active.sprintShare;
            case "airborneRate" -> current = active.airborneRate;
            case "swingRate" -> current = active.swingRate;
            case "preferredDistance" -> current = active.preferredDistance;
            case "approachPressure" -> current = active.approachPressure;
            default -> { return; }
        }
        // Match OpponentMemory's warm-up running mean, then transition to a stable EMA.
        double baseAlpha = "strafeFlipRate".equals(field) ? ALPHA * 2.0 : ALPHA;
        double a = Math.max(baseAlpha, 1.0 / Math.max(1L, sampleCount));
        double next = current + a * (value - current);
        switch (field) {
            case "strafeActivity" -> active.strafeActivity = clamp01(next);
            case "strafeFlipRate" -> active.strafeFlipRate = clamp01(next);
            case "sprintRate" -> active.sprintShare = clamp01(next);
            case "airborneRate" -> active.airborneRate = clamp01(next);
            case "swingRate" -> active.swingRate = clamp01(next);
            case "preferredDistance" -> active.preferredDistance = clamp01(next);
            case "approachPressure" -> active.approachPressure = clampSigned(next);
            default -> { }
        }
    }

    /** Positive means the opponent's own movement is closing the gap; negative means retreating. */
    private static double opponentApproach(SituationalStateInterpreter.State s) {
        double rf = s.enemyRelativeForward, rs = s.enemyRelativeSide;
        double length = Math.hypot(rf, rs);
        if (length < 1e-5) return 0.0;
        double toward = -(s.enemyForwardVelocity * rf + s.enemySideVelocity * rs) / length;
        return clampSigned(toward);
    }

    Profile profile() { return active.copy(); }
    /** Read-only view for the per-tick combat stack; avoids allocating a copy every tick. */
    Profile profileView() { return active; }
    double confidence() { return active.confidence(); }
    double predictedThreat() { return latestThreat; }
    long samples() { return active.samples; }
    long episodeSamples() { return episodeSamples; }
    String opponentKey() { return key; }

    /**
     * Reuses the policy's existing eight habit inputs. No network dimensions or checkpoint actor
     * weights change. Until a migrated legacy profile has enough fresh samples, the live
     * episode-local OpponentMemory values are left intact.
     */
    void applyPolicyHistory(float[] obs) {
        if (obs == null || !Config.MEMORY || !active.hasPolicyHistory()) return;
        int offset = OpponentMemory.habitSlotStart();
        if (obs.length < offset + OpponentMemory.HABITS) return;
        obs[offset] = OpponentMemory.encodeHabit(0, active.strafeActivity);
        obs[offset + 1] = OpponentMemory.encodeHabit(1, active.strafeFlipRate);
        obs[offset + 2] = OpponentMemory.encodeHabit(2, active.sprintShare);
        obs[offset + 3] = OpponentMemory.encodeHabit(3, active.airborneRate);
        obs[offset + 4] = OpponentMemory.encodeHabit(4, active.swingRate);
        obs[offset + 5] = OpponentMemory.encodeHabit(5, active.preferredDistance);
        obs[offset + 6] = OpponentMemory.encodeHabit(6, active.approachPressure);
        obs[offset + 7] = OpponentMemory.encodeHabit(7, active.counterRate);
    }

    void write(DataOutput out) throws IOException {
        persistActive();
        out.writeInt(MAGIC_V2);
        out.writeInt(profiles.size());
        for (Map.Entry<String, Profile> e : profiles.entrySet()) {
            Profile p = e.getValue();
            out.writeUTF(e.getKey());
            out.writeDouble(p.attackRate); out.writeDouble(p.sprintRate); out.writeDouble(p.jumpRate);
            out.writeDouble(p.retreatRate); out.writeDouble(p.sideBias); out.writeDouble(p.counterRate);
            out.writeDouble(p.strafeActivity); out.writeDouble(p.strafeFlipRate); out.writeDouble(p.sprintShare);
            out.writeDouble(p.airborneRate); out.writeDouble(p.swingRate); out.writeDouble(p.preferredDistance);
            out.writeDouble(p.approachPressure);
            out.writeLong(p.samples); out.writeLong(p.habitSamples); out.writeLong(p.flipSamples);
        }
    }

    void read(DataInput in) throws IOException {
        int magic = in.readInt();
        if (magic != MAGIC_V1 && magic != MAGIC_V2) return;
        int n = Math.max(0, Math.min(MAX_PROFILES, in.readInt()));
        profiles.clear();
        for (int i = 0; i < n; i++) {
            String k = sanitise(in.readUTF());
            Profile p = new Profile();
            p.attackRate = finite(in.readDouble(), 0.08, 0, 1);
            p.sprintRate = finite(in.readDouble(), 0.25, 0, 1);
            p.jumpRate = finite(in.readDouble(), 0.15, 0, 1);
            p.retreatRate = finite(in.readDouble(), 0.25, 0, 1);
            p.sideBias = finite(in.readDouble(), 0, -1, 1);
            p.counterRate = finite(in.readDouble(), 0.5, 0, 1);
            if (magic == MAGIC_V2) {
                p.strafeActivity = finite(in.readDouble(), 0, 0, 1);
                p.strafeFlipRate = finite(in.readDouble(), 0, 0, 1);
                p.sprintShare = finite(in.readDouble(), 0, 0, 1);
                p.airborneRate = finite(in.readDouble(), 0, 0, 1);
                p.swingRate = finite(in.readDouble(), 0, 0, 1);
                p.preferredDistance = finite(in.readDouble(), 0, 0, 1);
                p.approachPressure = finite(in.readDouble(), 0, -1, 1);
                p.samples = Math.max(0, in.readLong());
                p.habitSamples = Math.max(0, in.readLong());
                p.flipSamples = Math.max(0, in.readLong());
            } else {
                // Migrate the former six-field profile. Keep the historical tactical values, but
                // don't feed approximate old fields to the learned habit inputs until fresh data
                // has rebuilt their definitions.
                p.samples = Math.max(0, in.readLong());
                p.habitSamples = 0;
                p.flipSamples = 0;
                // The old profile did not contain these policy features with matching
                // definitions. Start their new statistics neutral rather than leaking
                // approximate legacy values into the actor after only a few samples.
                p.strafeActivity = 0;
                p.strafeFlipRate = 0;
                p.sprintShare = 0;
                p.airborneRate = 0;
                p.swingRate = 0;
                p.preferredDistance = 0;
                p.approachPressure = 0;
            }
            profiles.put(k, p);
        }
        Profile p = profiles.get(key);
        if (p != null) active = p.copy();
        trimProfiles();
    }

    private void persistActive() {
        profiles.remove(key);
        profiles.put(key, active.copy());
        trimProfiles();
    }

    private void trimProfiles() {
        while (profiles.size() > MAX_PROFILES) {
            String first = profiles.keySet().iterator().next();
            if (first.equals(key) && profiles.size() > 1) {
                Profile saved = profiles.remove(first);
                profiles.put(first, saved);
                continue;
            }
            profiles.remove(first);
        }
    }

    private static String sanitise(String s) {
        if (s == null || s.isBlank()) return "unknown";
        String v = s.trim().replaceAll("[^A-Za-z0-9_ .'-]", "_")
            .toLowerCase(java.util.Locale.ROOT);
        return v.length() > 64 ? v.substring(0, 64) : v;
    }

    private static double finite(double x, double fallback, double lo, double hi) {
        return Double.isFinite(x) ? Math.max(lo, Math.min(hi, x)) : fallback;
    }
    private static double clamp01(double x) { return Math.max(0, Math.min(1, x)); }
    private static double clampSigned(double x) { return Math.max(-1, Math.min(1, x)); }
}
