package com.rlpvp;

/**
 * Display interpolation for the AI camera. Gameplay yaw/pitch is smoothed first by GameplayRotation (adaptive input filtering,
 * bounded acceleration/jerk/drag, mouse-count quantization and predictive braking). The LocalPlayer view hook then linearly interpolates
 * between the exact authoritative yaw/pitch endpoints for the tick. It must not add a separate velocity-driven trajectory: that can
 * make the shown crosshair disagree with the actual aim and look like overshoot or drift.
 *
 * Hermite maths and its tangent bookkeeping remain for simulator experiments and the explicit legacy diagnostic mode only; the normal
 * rendered view does not use them. Zero applied displacement therefore remains visually zero even if the physical model retains sub-count
 * velocity. Gameplay, packet and attack state stay on the authoritative tick-end angles.
 *
 * Usage: push() once per tick after gameplay rotation is applied; viewYaw/viewPitch return the interpolated local-player view angle.
 * EntityViewMixin hooks LocalPlayer's actual view-rotation overrides. Pure Java, no allocation. When the AI is not driving the camera,
 * active() is false and vanilla view behavior is untouched.
 */
final class GlideCamera {
    private GlideCamera() {}

    private static volatile boolean enabled = true;
    private static boolean valid;
    private static double dYaw, v0Yaw, v1Yaw, dPitch, v0Pitch, v1Pitch;
    private static final double[] YAW_SLOPES = new double[2], PITCH_SLOPES = new double[2];
    private static long lastPushNanos;

    // ---- REAL rotation mode (Config.GLIDE_REAL_ROTATION): the player's actual yRot/xRot follow the curve every FRAME, like a real mouse ----
    private static boolean realOn;
    private static double sYaw, sPitch, eYaw, ePitch;
    /**
     * Frame-rate independence: the curve is played over (almost) the whole MEASURED tick interval (not a fixed 42.5 ms), so it ends on the tick's angle just
     * before the next tick whatever the tick rate, and it is sampled where the frame will actually be SHOWN (half a measured frame time ahead of the frame
     * start). With 20-50 fps that removes the "snap at the end of the curve" and the half-frame lag that read as stutter.
     */
    private static double tickNanos = 50_000_000.0, frameNanos = 16_000_000.0;
    private static long lastFrameNanos;
    private static double realNanos() { return Math.max(40_000_000.0, Math.min(60_000_000.0, tickNanos * 0.97)); }

    /** The AI stopped / started: forget the motion so the first segment does not use stale velocities. */
    static synchronized void reset() { realOn = false; valid = false; dYaw = v0Yaw = v1Yaw = dPitch = v0Pitch = v1Pitch = 0; lastPushNanos = 0; lastFrameNanos = 0; }

    /** Master switch (Config.GLIDE_CAMERA), also turned off by the mixin if anything ever goes wrong. */
    static void setEnabled(boolean on) { enabled = on; }

    static boolean active() { return enabled && Config.GLIDE_CAMERA && valid && System.nanoTime() - lastPushNanos < 200_000_000L; }

    /**
     * Shape-preserving Hermite tangents. The curve must end exactly at the tick's authoritative rotation and must not
     * invent a tiny loop when the applied displacement was quantized to zero. Tangents are clipped to the displacement
     * direction, then Fritsch-Carlson's norm bound is applied to prevent a cubic from overshooting between tick endpoints.
     * The accepted end slope is carried forward as the next segment's start-slope candidate; it is bounded again if the next segment is too small or reverses.
     */
    private static void boundedSlopes(double displacement, double startVelocity, double endVelocity, double[] out) {
        double d = displacement;
        if (!Double.isFinite(d) || Math.abs(d) < 1.0e-7) { out[0] = out[1] = 0.0; return; }
        double dir = Math.signum(d), cap = 3.0 * Math.abs(d);
        double m0 = tangent(startVelocity, dir, cap);
        double m1 = tangent(endVelocity, dir, cap);
        double alpha = m0 / d, beta = m1 / d;
        double norm = alpha * alpha + beta * beta;
        if (norm > 9.0) {
            double tau = 3.0 / Math.sqrt(norm);
            m0 *= tau;
            m1 *= tau;
        }
        out[0] = m0;
        out[1] = m1;
    }

    private static double tangent(double velocity, double direction, double cap) {
        if (!Double.isFinite(velocity) || velocity * direction <= 0.0) return 0.0;
        return direction * Math.min(Math.abs(velocity), cap);
    }

    /**
     * @param turnYaw,turnPitch degrees turned during this tick (the displacement vanilla will interpolate over the next 50 ms)
     * @param endVelYaw,endVelPitch the mouse's velocity at the end of the tick, deg/tick
     */
    static synchronized void push(double turnYaw, double endVelYaw, double turnPitch, double endVelPitch) {
        // Invalid telemetry must not create an active interpolation segment. Treat it as a reset, not a zero-sized valid segment.
        if (!Double.isFinite(turnYaw) || !Double.isFinite(endVelYaw) || !Double.isFinite(turnPitch) || !Double.isFinite(endVelPitch)) {
            reset();
            return;
        }
        // Do not render a velocity that the authoritative tick-end rotation did not actually travel. In particular,
        // mouse-count quantization can make turnYaw == 0 while CameraDynamics still has a small hidden velocity; using
        // that velocity as a Hermite tangent creates a visible out-and-back wiggle (and can look like aim drift).
        double startYaw = valid ? v1Yaw : 0.0;
        double startPitch = valid ? v1Pitch : 0.0;
        dYaw = Double.isFinite(turnYaw) ? turnYaw : 0.0;
        dPitch = Double.isFinite(turnPitch) ? turnPitch : 0.0;
        boundedSlopes(dYaw, startYaw, endVelYaw, YAW_SLOPES);
        boundedSlopes(dPitch, startPitch, endVelPitch, PITCH_SLOPES);
        v0Yaw = YAW_SLOPES[0]; v1Yaw = YAW_SLOPES[1];
        v0Pitch = PITCH_SLOPES[0]; v1Pitch = PITCH_SLOPES[1];
        valid = Double.isFinite(dYaw + v0Yaw + v1Yaw + dPitch + v0Pitch + v1Pitch);
        long now = System.nanoTime();
        if (lastPushNanos != 0) { double dt = now - lastPushNanos; if (dt > 30_000_000.0 && dt < 100_000_000.0) tickNanos += 0.1 * (dt - tickNanos); }
        lastPushNanos = now;
    }

    /**
     * Real-rotation mode: call right after push(). The authoritative angles of the tick are start -> end (what GameplayRotation computed). From now
     * until the next tick the mixin sets the player's real yaw / pitch from frame() so they move along the Hermite curve; at the end they sit exactly
     * on end. Also used when the pitch was clamped (end already contains the clamp).
     */
    static synchronized void markReal(double startYaw, double startPitch, double endYaw, double endPitch) {
        if (!(enabled && Config.GLIDE_REAL_ROTATION) || !valid || !Double.isFinite(startYaw + startPitch + endYaw + endPitch)) { realOn = false; return; }
        sYaw = startYaw; sPitch = startPitch; eYaw = endYaw; ePitch = endPitch; realOn = true;
    }

    /** The previous segment has to be complete before the next tick reads the angles (also with catch-up ticks): returns false if nothing is pending. */
    static synchronized boolean finishReal(double[] out) {
        if (!realOn) return false;
        realOn = false;
        out[0] = eYaw; out[1] = ePitch;
        return true;
    }

    /**
     * Per-frame angles for the real rotation. @return false when nothing is to be written (inactive / done). out = {yaw, pitch} in degrees; yaw remains continuous.
     * After the curve has finished the end angles are written once more and the mode switches itself off, so nothing else is fought with.
     */
    static synchronized boolean frame(double[] out) {
        if (!(enabled && Config.GLIDE_REAL_ROTATION) || !realOn) return false;
        long now = System.nanoTime();
        if (lastFrameNanos != 0) { double dt = now - lastFrameNanos; if (dt > 1_000_000.0 && dt < 100_000_000.0) frameNanos += 0.2 * (dt - frameNanos); }
        lastFrameNanos = now;
        double lead = Math.min(25_000_000.0, 0.5 * frameNanos); // the frame is shown about half a frame after it starts
        double t = (now + lead - lastPushNanos) / realNanos();
        if (!(t < 1.0)) { out[0] = eYaw; out[1] = ePitch; realOn = false; return true; }
        if (t < 0) t = 0;
        out[0] = sYaw + hermite(dYaw, v0Yaw, v1Yaw, t);
        out[1] = Math.max(-90.0, Math.min(90.0, sPitch + hermite(dPitch, v0Pitch, v1Pitch, t)));
        return true;
    }

    private static double wrap(double d) { d %= 360.0; if (d >= 180.0) d -= 360.0; if (d < -180.0) d += 360.0; return d; }

    /** Cubic Hermite position at t in [0,1] for a segment of displacement d from start velocity v0 to end velocity v1 (deg, deg/tick). */
    static double hermite(double d, double v0, double v1, double t) {
        double t2 = t * t, t3 = t2 * t;
        return (t3 - 2 * t2 + t) * v0 + (-2 * t3 + 3 * t2) * d + (t3 - t2) * v1;
    }

    /** Speed (deg/tick) of the Hermite curve at t in [0,1]: v0 at t=0, v1 at t=1 (derivative of hermite()). Used by the simulator's frame model. */
    static double hermiteSpeed(double d, double v0, double v1, double t) {
        double t2 = t * t;
        return (3 * t2 - 4 * t + 1) * v0 + (-6 * t2 + 6 * t) * d + (3 * t2 - 2 * t) * v1;
    }

    /**
     * Absolute view yaw at a render partial tick.
     *
     * IMPORTANT: gameplay rotation is smoothed first by GameplayRotation/CameraDynamics. The render path only interpolates
     * between the two actual authoritative tick samples. Do not apply a second velocity/Hermite smoother here: it would make
     * the visible crosshair follow a different trajectory from the gameplay aim and can reintroduce apparent drift/overshoot.
     * The signed displacement is the exact turn that ActionApplier applied to the real player for this tick. Absolute yaw
     * is kept continuous; only target-angle differences are wrapped elsewhere.
     */
    static synchronized double viewYaw(double endYaw, double t) {
        if (!valid) return endYaw;
        double startYaw = endYaw - dYaw;
        return startYaw + dYaw * clamp01(t);
    }

    /** Pitch uses the same single-stage policy: interpolate only the applied gameplay delta, with no extra camera dynamics. */
    static synchronized double viewPitch(double endPitch, double t) {
        if (!valid) return Math.max(-90.0, Math.min(90.0, endPitch));
        double startPitch = endPitch - dPitch;
        return Math.max(-90.0, Math.min(90.0, startPitch + dPitch * clamp01(t)));
    }

    /** Legacy offsets for integrations that already interpolate previous/current angles themselves. */
    static synchronized double yawOffset(double t) { return valid ? hermite(dYaw, v0Yaw, v1Yaw, clamp01(t)) - clamp01(t) * dYaw : 0.0; }

    static synchronized double pitchOffset(double t) { return valid ? hermite(dPitch, v0Pitch, v1Pitch, clamp01(t)) - clamp01(t) * dPitch : 0.0; }

    private static double clamp01(double t) { return t < 0 ? 0 : (t > 1 ? 1 : t); }
}
