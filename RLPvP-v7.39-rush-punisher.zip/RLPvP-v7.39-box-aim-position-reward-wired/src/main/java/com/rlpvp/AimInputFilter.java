package com.rlpvp;

/** Adaptive, allocation-free filter for mouse-like aim effort in degrees per game tick. */
final class AimInputFilter {
    private final AimJitterSuppressor jitter = new AimJitterSuppressor();
    private double output;
    private double lastAlpha = 1.0;
    private double lastInput;
    private double lastSign;

    double step(double requestedDegPerTick, double axisScale) {
        return step(requestedDegPerTick, axisScale, false);
    }

    /** Precision tracking remains filtered; AimBrake is a second feedback controller, not a reason to bypass jitter filtering. */
    double step(double requestedDegPerTick, double axisScale, boolean precisionTrack) {
        if (!Double.isFinite(requestedDegPerTick)) requestedDegPerTick = 0.0;
        if (!Double.isFinite(axisScale) || axisScale <= 0.0) axisScale = 1.0;
        requestedDegPerTick = clamp(requestedDegPerTick, -axisScale, axisScale);
        lastInput = requestedDegPerTick;
        if (!Config.AIM_INPUT_FILTER) {
            output = requestedDegPerTick;
            lastAlpha = 1.0;
            return output;
        }

        requestedDegPerTick = jitter.apply(requestedDegPerTick, axisScale, precisionTrack);
        // Keep a very small, sensitivity-scaled dead zone. The old larger threshold could erase slow tracking corrections.
        double deadband = axisScale * (precisionTrack ? 0.0012 : 0.0018);
        if (Math.abs(requestedDegPerTick) < deadband) requestedDegPerTick = 0.0;

        double sign = Math.signum(requestedDegPerTick);
        boolean reversing = sign != 0.0 && lastSign != 0.0 && sign != lastSign;
        double error = requestedDegPerTick - output;
        double fastAt = Math.max(1e-6, axisScale * (precisionTrack ? 0.18 : 0.24));
        double urgency = clamp(Math.abs(error) / fastAt, 0.0, 1.0);
        double slow = precisionTrack ? 0.22 : 0.30;
        double fast = precisionTrack ? 0.58 : 0.76;
        lastAlpha = slow + (fast - slow) * urgency;
        if (reversing && Math.abs(error) < axisScale * (precisionTrack ? 0.32 : 0.35)) lastAlpha *= 0.48;

        double delta = error * lastAlpha;
        double maxStep = axisScale * (precisionTrack ? 0.18 : 0.28);
        delta = clamp(delta, -maxStep, maxStep);
        output = clamp(output + delta, -axisScale, axisScale);
        if (sign != 0.0) lastSign = sign;

        // Avoid the last sub-count of residual effort from creating persistent drift.
        if (requestedDegPerTick == 0.0 && Math.abs(output) < axisScale * 0.0015) {
            output = 0.0;
            lastSign = 0.0;
        }
        return output;
    }

    double passthrough(double requestedDegPerTick, double axisScale) {
        if (!Double.isFinite(requestedDegPerTick)) requestedDegPerTick = 0.0;
        if (!Double.isFinite(axisScale) || axisScale <= 0.0) axisScale = 1.0;
        lastInput = clamp(requestedDegPerTick, -axisScale, axisScale);
        output = lastInput;
        lastAlpha = 1.0;
        return output;
    }

    void reset() {
        output = 0.0; lastInput = 0.0; lastAlpha = 1.0; lastSign = 0.0; jitter.reset();
    }
    double output() { return output; }
    double lastInput() { return lastInput; }
    double alpha() { return lastAlpha; }
    private static double clamp(double x, double lo, double hi) { return Math.max(lo, Math.min(hi, x)); }
}
