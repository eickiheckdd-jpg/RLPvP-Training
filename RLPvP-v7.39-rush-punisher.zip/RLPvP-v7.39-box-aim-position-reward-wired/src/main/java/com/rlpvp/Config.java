package com.rlpvp;

/** Every tunable number lives here. */
final class Config {
    private Config() {}

    // ---------------- observation ----------------
    /** Floats per tick (see Observation.frame for the exact layout). */
    /**
     * 48 original features + 3 appended for SNEAK (appended, so no existing index moved): 48 = I am sneaking, 49 = the enemy is sneaking,
     * 50 = my sneak head is locked by the curriculum. FRAME_PRE_SNEAK is the layout of older saves (migrated on load, see PpoAgent.load).
     */
    static final int FRAME = 51;
    /** Enable the compact recurrent input contract (the historical system-property name is retained for compatibility). */
    static final boolean COMPACT_126 = Boolean.parseBoolean(System.getProperty("rlpvp.obs126", "true"));
    static final int COMPACT_OBS_SIZE = 128;
    static final int FRAME_PRE_SNEAK = 48;
    /** Frame sizes of older saves (all used the lags LEGACY_LAGS and no summary): they are migrated on load, see PpoAgent.load. */
    static final int[] LEGACY_FRAMES = {42, 48};
    static final int[] LEGACY_LAGS = {0, 1, 4, 16};
    /**
     * Which past ticks are fed to the network: 0 = now, 1 = last tick (shows knockback / hit onset), ... up to 96 ticks
     * (4.8 s) back. Lags up to NEAR_LAG_MAX carry the whole frame, older ones only FAR_FEATURES (keeps the network small).
     */
    static final int[] LAGS = {0, 1, 2, 4, 8, 16, 32, 48, 64, 80, 96};
    /** Must equal the largest value in LAGS. */
    static final int MAX_LAG = 96;
    static final int NEAR_LAG_MAX = 16;
    /** Frame features kept for the far lags: own health / velocity / sprint / hurt, enemy position, distance, aim, enemy health / hurt / swing, hit timers. */
    static final int[] FAR_FEATURES = {0, 1, 2, 5, 7, 9, 10, 12, 13, 15, 20, 23, 24, 25};
    /** Ticks the HitMemory summary looks back (96 = 4.8 s). */
    static final int MEMORY_WINDOW = 96;
    /** Floats from HitMemory, appended once to the network input. */
    static final int SUMMARY_BASE = 20;
    /** Motion-memory observations are enabled by default; pass -Drlpvp.obsV2=false to opt out. Checkpoint input columns are migrated on load. */
    static final boolean OBS_V2 = Boolean.parseBoolean(System.getProperty("rlpvp.obsV2", "true"));
    /** Optional OBS_V2 inputs: 8 movement-memory features + 2 target angular velocities (yaw, pitch; see MotionMemory). */
    static final int V2_FEATURES = 10;
    /** Relational spacing, combat-efficiency and mechanic-state observations appended after all existing summary blocks. */
    static final boolean COMBAT_OBSERVATIONS = Boolean.parseBoolean(System.getProperty("rlpvp.combatObs", "true"));
    static final int COMBAT_FEATURES = 14;
    /** Sprint-hit follow-up memory is descriptive only; enabled by default for new training. Set false to run the legacy input layout. */
    static final boolean SPRINT_FOLLOWUP = Boolean.parseBoolean(System.getProperty("rlpvp.sprintFollowup", "true"));
    static final int SPRINT_FOLLOWUP_FEATURES = SprintHitFollowupMemory.FEATURES;
    /** Opponent context: 8 behavior statistics + 8 recurrent GRU traces. New input columns are migrated as zero-weight for older checkpoints. */
    static final boolean MEMORY = Boolean.parseBoolean(System.getProperty("rlpvp.memory", "true"));
    static final int MEMORY_FEATURES = OpponentMemory.FEATURES;
    /** Train the opponent-memory GRU by truncated backpropagation through time inside PPO. */
    static final boolean GRU_TRAIN = Boolean.parseBoolean(System.getProperty("rlpvp.gruTrain", "true"));
    /** Recurrent memory is a trainable GRU, replayed with truncated BPTT over contiguous history. */
    static final int GRU_BPTT = 32;
    static final float LR_GRU = 3e-4f, GRU_MAX_NORM = 0.5f;
    /** Knockback timing (v7.22, see KbTiming): 4 inputs, the LAST block of the summary. -Drlpvp.kbTiming=false restores the previous layout. Checkpoints without it load with zero weights on the new inputs. */
    static final boolean KB_TIMING = Boolean.parseBoolean(System.getProperty("rlpvp.kbTiming", "true"));
    static final int KB_FEATURES = KbTiming.FEATURES;
    static final int SUMMARY = SUMMARY_BASE + (OBS_V2 ? V2_FEATURES : 0) + (SPRINT_FOLLOWUP ? SPRINT_FOLLOWUP_FEATURES : 0) + (MEMORY ? MEMORY_FEATURES : 0) + (KB_TIMING ? KB_FEATURES : 0) + (COMBAT_OBSERVATIONS ? COMBAT_FEATURES : 0);
    /** Total network inputs: compact recurrent contract by default; old lag-stack remains available for compatibility tests. */
    static final int OBS_SIZE = COMPACT_126 ? COMPACT_OBS_SIZE
        : ObsLayout.size(LAGS, FRAME, FAR_FEATURES.length, SUMMARY);

    // ---------------- network ----------------
    /** Select a preset with -Drlpvp.model=base|m10|m15, or provide custom layers with -Drlpvp.hidden=512,512[,256]. */
    static final String MODEL = System.getProperty("rlpvp.model", "base").trim().toLowerCase(java.util.Locale.ROOT);
    static final int[] HIDDEN = parseHidden(System.getProperty("rlpvp.hidden"), MODEL);
    /** Optional source shape for a custom-width checkpoint transfer: -Drlpvp.transferFrom=128,128. */
    static final int[] TRANSFER_FROM = parseLayerList(System.getProperty("rlpvp.transferFrom"), null);
    private static int[] parseHidden(String custom, String model) {
        if (custom != null && !custom.isBlank()) return parseLayerList(custom, null);
        return switch (model) {
            case "base" -> new int[]{128, 128};
            case "m10" -> new int[]{960, 960};
            case "m15" -> new int[]{1024, 1024, 512};
            default -> throw new IllegalArgumentException("Unknown -Drlpvp.model=" + model + " (expected base, m10, m15) or set -Drlpvp.hidden=512,512");
        };
    }
    static int[] parseLayerList(String value, int[] fallback) {
        if (value == null || value.isBlank()) return fallback;
        String[] pieces = value.trim().split("\\s*,\\s*");
        if (pieces.length < 1 || pieces.length > 8) throw new IllegalArgumentException("hidden layer list must have 1..8 layers");
        int[] layers = new int[pieces.length];
        for (int i = 0; i < pieces.length; i++) {
            layers[i] = Integer.parseInt(pieces[i]);
            if (layers[i] < 8 || layers[i] > 4096) throw new IllegalArgumentException("hidden layer size out of range 8..4096: " + layers[i]);
        }
        return layers;
    }

    // ---------------- actions ----------------
    /**
     * Camera = continuous relative mouse control (no buckets). The actor outputs a Gaussian (mean, log-std) per axis in
     * NORMALISED hand-effort units; samples are clamped to [-1, 1] and then passed through CameraMap and CameraDynamics.
     * The physical controller converts effort into acceleration, mouse velocity and relative displacement.
     */
    /**
     * Optional low-pass filter on mouse-hand effort (1.0 = off). Physical movement is already generated by CameraDynamics; this extra
     * filter only adds delay, so leave it off unless a controlled evaluation shows a benefit. Smaller values make the input command laggier.
     * The policy must be trained with the same filter setting used during play; the simulator uses this value too.
     */
    // Degree-per-tick command filter shared by live play, self-play and the simulator. The physical CameraDynamics stage
    // still handles acceleration/drag/jerk; this adaptive input filter only takes the edge off abrupt command changes.
    static final boolean AIM_INPUT_FILTER = true;
    static final double AIM_FILTER_SLOW_ALPHA = 0.68; // micro-corrections: stronger low-pass
    static final double AIM_FILTER_FAST_ALPHA = 0.92; // large turns: stay responsive
    static final double AIM_FILTER_FAST_ERROR_FRAC = 0.20; // error as fraction of axis scale where fast alpha is reached
    static final double AIM_FILTER_MAX_STEP_FRAC = 0.62; // hard bound on input change per tick
    static final double AIM_FILTER_PRECISION_ZONE_DEG = 28.0; // use the lower-latency adaptive filter in the near-target zone

    // Legacy low-pass is retained for source/checkpoint configuration compatibility; GameplayRotation uses AIM_INPUT_FILTER instead.
    static final float LOOK_SMOOTH = 1.0f;
    static final int LOOK_SMOOTH_POLES = 2;
    /**
     * Response curve for the camera head's mouse-hand effort (see CameraMap): applied = sign(a) * (mix*|a| + (1-mix)*|a|^p). 3 = cubic, so
     * the policy can apply tiny hand force for micro-adjustments and strong force for faster mouse movement.
     * 1 = linear hand effort. Changing this curve changes the learned controller, so retrain when changing it.
     * The std limits below are given in APPLIED effort units and converted to raw units (CameraMap.stdForMeanAbs / stdForTail). These describe
     * the policy's hand-effort exploration, not camera displacement; actual movement is determined by the physical mouse controller.
     */
    static final float CAMERA_EXPONENT = 3f;
    /** Share of the linear term kept in the curve (0 = pure power). Raise to 0.15-0.3 if the aim does not form in stages 1-2. */
    static final float CAMERA_LINEAR_MIX = 0f;
    /**
     * Physical mouse dynamics (see CameraDynamics). The camera head represents hand effort applied to a mouse, not an instant rotation:
     * effort creates acceleration, mouse/hand drag opposes existing movement, and acceleration changes are jerk-limited. The two camera
     * observation inputs continue to carry actual mouse velocity after integration. `false` is a diagnostic bypass, not a training mode.
     * This changes action semantics from the v9 spring/damper version, so train a fresh checkpoint with these settings.
     */
    static final boolean CAMERA_DYNAMICS = true;
    /** Maximum acceleration as a fraction of the maximum camera-equivalent mouse speed per tick^2 (yaw: 13.5 deg/tick^2). Was 0.7 (31.5): the camera could go from rest to 31 deg/tick in ONE tick, and since the game shows the camera at 20 Hz that is a visible jolt. */
    static final float CAM_ACC_MAX_FRAC = 0.30f;
    /** Maximum change of acceleration per tick, as a fraction of the axis speed scale (yaw: 5.4 deg/tick^3). Was 1.0 (45): acceleration could switch on at full strength in a single tick. */
    static final float CAM_JERK_MAX_FRAC = 0.12f;
    /** Velocity drag per tick when the hand is not pushing; matching the acceleration fraction makes full input balance at top speed. */
    static final float CAM_MOUSE_DRAG = 0.30f; // = CAM_ACC_MAX_FRAC, so a full push still balances at the full axis speed; a lower drag lets a flick coast and stop gently

    // ---------------- pitch practice (stages 2-3): the stationary bot hops, ADAPTIVELY ----------------
    /**
     * The stationary bot hops now and then (it is never teleported). A bot that stands on the same spot gives a constant pitch error, so there is
     * nothing to learn on the pitch axis once the first correction is done; a hop moves the target up and down by about 1.25 blocks (roughly +-13 degrees
     * at 2.6 blocks), so the agent has to TRACK it with pitch. Applies to the stationary bot only, in the stages below.
     *
     * The hop frequency is a performance-driven LEVEL (Curriculum.hopLevel, 0..1), not a constant. A fixed hop every 12-30 ticks (airborne about half
     * of the time) made the stage-2 aim gate unreachable for a fresh policy: the gate read 0 % for 1,000,000 ticks (the same run with no hops
     * read 73 % within 84 episodes), and with the stage timers gone the run never left stage 2. Now the level starts at 0 (no hops), rises by
     * BOT_HOP_STEP after each BOT_HOP_WINDOW episodes whose success rate is >= BOT_HOP_RAISE_AT, falls when it is < BOT_HOP_LOWER_AT, and stage 2
     * is only left once the gate is held at level >= BOT_HOP_REQUIRED_LEVEL (so pitch tracking really is learned before attacks unlock).
     * At level 1 a grounded bot waits BOT_HOP_MIN_TICKS..MAX_TICKS between hops (about 25 % of the time airborne); lower levels wait proportionally longer.
     */
    static final boolean BOT_HOP = true;
    static final int BOT_HOP_MIN_STAGE = 2;
    static final int BOT_HOP_MAX_STAGE = 3;
    static final int BOT_HOP_MIN_TICKS = 18;   // v7.27: was 30-60 (airborne only ~25 % of the time at level 1): the target now changes height about 40 % of the time
    static final int BOT_HOP_MAX_TICKS = 40;
    /**
     * v7.27 PITCH KICKS (simulator only: the mod never forces the agent's camera): in stage 2 a random vertical push of the agent's own camera every KICK_MIN..KICK_MAX ticks, spread over 4 ticks,
     * amplitude KICK_MIN_DEG + KICK_RANGE_DEG * hop level. A stationary target at a fixed height needs ONE constant pitch, which the policy learns as a bias; with kicks (and the hopping bot)
     * the pitch error keeps coming back at random sizes and the only way to keep the crosshair on the bot is to read the observed pitch error and correct it.
     */
    static final boolean PITCH_KICK = true;
    static final int PITCH_KICK_STAGE = 2, PITCH_KICK_MIN_TICKS = 40, PITCH_KICK_MAX_TICKS = 90, PITCH_KICK_WARMUP = 30;
    static final double PITCH_KICK_MIN_DEG = 6.0, PITCH_KICK_RANGE_DEG = 20.0;
    static final double BOT_HOP_STEP = 0.1;
    static final int BOT_HOP_WINDOW = 10;
    static final double BOT_HOP_RAISE_AT = 0.75;
    static final double BOT_HOP_LOWER_AT = 0.50;
    static final double BOT_HOP_REQUIRED_LEVEL = 0.7;
    /**
     * AimBrake (see AimBrake): braking envelope near the target so the camera cannot overshoot and hunt. Part of the mouse physics:
     * train and play with the same value. Decel fraction = share of the mouse's max acceleration assumed available for braking (kept
     * below 1 because acceleration is jerk-limited); track fraction = speed always allowed so a strafing enemy can be followed.
     */
    static final boolean AIM_BRAKE = true;
    /** Display-only: draw the AI's camera between ticks on a smooth curve (GlideCamera) instead of vanilla's straight lines. Off = vanilla interpolation. */
    static final boolean GLIDE_CAMERA = true;
    /**
     * Legacy experimental mode: mutate the player's authoritative yaw/pitch every render frame. This can fight with the
     * tick-driven controller because ActionApplier has already written the tick-end rotation before the next render frame.
     * Default OFF: render a smooth view-only curve from LocalPlayer.getViewYRot/getViewXRot while gameplay, raycasts and
     * policy observations retain the exact tick-end angles. Set -Drlpvp.glideRealRotation=true only for diagnosis.
     */
    static final boolean GLIDE_REAL_ROTATION = Boolean.getBoolean("rlpvp.glideRealRotation");
    static final float AIM_BRAKE_DECEL_FRAC = 0.35f;
    static final float AIM_BRAKE_TRACK_FRAC = 0.02f;
    static final float AIM_BRAKE_GAIN = 0.8f;
    /** Max push toward the target per degree of remaining error (hand-effort deg/tick per degree); a target moving 2 deg/tick needs ~1 deg of error. */
    static final float AIM_BRAKE_PUSH_GAIN = 2.0f;
    /** Ticks of own motion assumed before the brake takes effect (one policy tick + jerk-limited ramp). */
    static final float AIM_BRAKE_LOOKAHEAD = 0.5f;
    /** Overshoot (deg) the predictive brake tolerates so that fine corrections do not stall. */
    static final float AIM_BRAKE_SLACK_DEG = 0.25f;
    /** Ticks of the target's own estimated motion (away from the camera) added to the brake's room; 0 = target assumed still. */
    static final float AIM_BRAKE_TRACK_TICKS = 3f;
    /** Brake model used to predict the stopping travel: hand effort = -gain * velocity (deg/tick per deg/tick). */
    static final float CAM_STOP_GAIN = 3.0f;
    /** Integration sub-steps per game tick. */
    static final int CAM_SUBSTEPS = 4;
    // KINEMATIC FILTER (v7.22). (1) EASE-IN: when the hand starts pushing from (near) rest, the first AIM_EASE_TICKS ticks of the command are scaled by smoothstep(age / ticks), so a large turn starts slowly,
    // accelerates in the middle and (with the AimBrake taper below) decelerates at the end, instead of a snap. A push that continues an already moving mouse is not slowed (tracking stays quick).
    // 0 disables. (2) LEGAL MOUSE STEP: the camera turn of every tick is a whole number of mouse counts (MOUSE_DEG_PER_COUNT degrees each, vanilla: 1.2 * (0.6 * sens + 0.2)^3, 0.15 at 50 % sensitivity),
    // the sub-count remainder is carried to the next tick like real mouse hardware. -Drlpvp.mouseQuantize=false turns it off.
    static final int AIM_EASE_TICKS = Integer.getInteger("rlpvp.aimEaseTicks", 0);
    static final double AIM_EASE_REST_FRAC = 0.15;
    /** Only BIG flicks (command >= this share of the axis speed) are eased: eased tracking corrections cost on-target time (measured on a sinusoidal strafe: 75 % -> 59 % with a 3-tick ease on every push). */
    static final double AIM_EASE_MIN_FRAC = Double.parseDouble(System.getProperty("rlpvp.aimEaseMinFrac", "0.5"));
    static final boolean MOUSE_QUANTIZE = Boolean.parseBoolean(System.getProperty("rlpvp.mouseQuantize", "true"));
    static final double MOUSE_DEG_PER_COUNT = Double.parseDouble(System.getProperty("rlpvp.mouseDegPerCount", "0.15"));
    // PLAYSTYLE BY ADVANTAGE (v7.22): exchange pay of risky pressure techniques (sprint hit, follow-up, combo, crit) is multiplied by 1 - g * lead and of safe ones (spacing, bait, dodge, punish)
    // by 1 + g * lead, lead = clamp((my HP - enemy HP) / 20 / TECH_ADV_FULL, -1, 1): ahead -> the safe lines pay a bit more, behind -> pressure does. Bounded (+-g), so the outcome still decides.
    static final double TECH_ADV_GAIN = 0.0, TECH_ADV_FULL = 0.35; // no auxiliary reward bias based on current HP lead
    /**
     * OPT-IN hand shake (-Drlpvp.camShake=true, default OFF), applied inside CameraDynamics (the physical hand), never to the policy's action, so the
     * policy cannot learn to cancel its own noise. The hand offset is a seeded, smoothly varying (AR(1)) random angle with standard deviation
     * CAM_SHAKE_TREMOR_DEG at rest, plus CAM_SHAKE_SPEED_GAIN * |mouse speed in deg/tick| while turning, hard-capped at CAM_SHAKE_MAX_DEG
     * (well below ON_TARGET_DEG). The camera turns by the CHANGE of that offset each tick, so it wobbles but never drifts. Same noise stream in
     * training, evaluation and play (seed CAM_SHAKE_SEED, -Drlpvp.camShakeSeed). CAM_SHAKE_CORR is the per-tick correlation (0 = white, 1 = frozen).
     */
    static final boolean CAM_SHAKE = Boolean.parseBoolean(System.getProperty("rlpvp.camShake", "false"));
    static final long CAM_SHAKE_SEED = Long.getLong("rlpvp.camShakeSeed", 20260101L);
    static final double CAM_SHAKE_TREMOR_DEG = 0.10, CAM_SHAKE_SPEED_GAIN = 0.02, CAM_SHAKE_MAX_DEG = 0.30, CAM_SHAKE_CORR = 0.6;
    static final float YAW_SCALE = 45f;
    // Give vertical corrections enough authority to reacquire airborne targets; still below yaw's full-turn scale.
    // This is controller sensitivity, not a target-directed correction. The simulator uses the same value.
    static final float PITCH_SCALE = 30f;
    /** Starting std whose mean applied hand effort matches the old linear 0.01 control noise. */
    static final float LOOK_STD_INIT = CameraMap.stdForMeanAbs(0.01f, CAMERA_EXPONENT, CAMERA_LINEAR_MIX);
    static final float LOOK_LOGSTD_MIN = (float) Math.log(CameraMap.stdForMeanAbs(0.003f, CAMERA_EXPONENT, CAMERA_LINEAR_MIX));
    /** Largest raw std: 2-sigma (cubic) / 1-sigma (linear) applied hand effort is at most 15% of max effort. */
    static final float LOOK_LOGSTD_MAX = (float) Math.log(CameraMap.stdForTail(0.15f, CAMERA_EXPONENT, CAMERA_LINEAR_MIX));
    /** Entropy bonus on the camera std, relative to ENTROPY_COEF (small, so the std can shrink once aim is good). */
    static final float LOOK_ENTROPY_SCALE = 0.25f; // applied to the BASE entropy coef (never boosted by the anti-collapse floor)
    /** Gradient that pushes the camera log-std back inside its limits (without it a std stuck at a limit could never recover). */
    static final float LOOK_CLAMP_RESTORE = 0.01f;

    static final int OFF_YAW = 0;                                // mean, then log-std at +1
    static final int OFF_PITCH = OFF_YAW + 2;                    // 2   mean, log-std at +1
    static final int OFF_FWD = OFF_PITCH + 2;                    // 4   (back / none / forward)
    static final int OFF_STRAFE = OFF_FWD + 3;                   // 7   (left / none / right)
    static final int OFF_ATTACK = OFF_STRAFE + 3;                // 10
    static final int OFF_JUMP = OFF_ATTACK + 1;                  // 11
    static final int OFF_SPRINT = OFF_JUMP + 1;                  // 12
    static final int OFF_SNEAK = OFF_SPRINT + 1;                 // 13  (on / off; sneaking slows to 30 %, stops sprinting, lowers eyes to 1.27 and the hitbox to 1.5)
    static final int OFF_HOLD_STRAFE = OFF_SNEAK + 1;            // 14  (conditional: neutral strafe means continue the previous side)
    static final int ACTION_SIZE = OFF_HOLD_STRAFE + 1;           // 15
    static final int ACTION_SIZE_PRE_HOLD_STRAFE = 14;            // older checkpoints with sneak but without learned hold
    static final int ACTION_SIZE_PRE_SNEAK = 13;                  // output size of older saves

    // ---------------- PPO (online, learns while you play) ----------------
    /** Ticks of experience collected before a batch is handed to the learner (was 128: far too noisy for GAE + advantage normalisation). */
    static final int ROLLOUT = 2048; // was 1024 (~3 episodes): doubled so GAE/advantage normalisation sees ~7 episodes; same samples-per-update-step, so no extra stall per tick
    /** Larger batches reduce high-variance updates while keeping a fixed number of optimizer passes. */
    static final int MINIBATCH = 128;
    static final int EPOCHS = 4;
    static final float GAMMA = 0.995f;
    static final float GAE_LAMBDA = 0.97f;
    static final float CLIP = 0.15f;
    static final float VALUE_CLIP = 0.20f;
    static final float LR_ACTOR = 2.5e-4f;
    static final float LR_CRITIC = 5e-4f;
    /** Bonus for keeping the policy random enough to explore. */
    static final float ENTROPY_COEF = 0.004f;
    /** Lower late-curriculum exploration after the policy has learned the basic movement/combat repertoire. */
    static final int LATE_STAGE_ENTROPY_FROM_STAGE = 8; // this checkout's curriculum has 8 stages; also applies to any future stage 9+
    static final long LATE_STAGE_ENTROPY_DECAY_TICKS = 300_000L;
    static final float LATE_STAGE_ENTROPY_SCALE = 0.7f; // v7.26: was 0.4; a low entropy locks the crit habit in before sprint hits are explored (the per-stage notes recommend MORE entropy against fixed styles), so a gentle taper // 0.004 -> 0.0016 after the gradual taper, before the anti-collapse floor boost
    static float stageEntropyScale(int stage, long ticks, long stageEnterTicks) {
        if (stage < LATE_STAGE_ENTROPY_FROM_STAGE) return 1.0f;
        double progress = Math.max(0.0, Math.min(1.0,
            (ticks - stageEnterTicks) / (double) LATE_STAGE_ENTROPY_DECAY_TICKS));
        return (float) (1.0 + (LATE_STAGE_ENTROPY_SCALE - 1.0) * progress);
    }
    static final float MAX_GRAD_NORM = 0.5f;
    /** If the policy moves further than 1.5x this within one rollout, the rest of that rollout is skipped. */
    static final float TARGET_KL = 0.02f;
    /** Adaptive PPO step-size bounds; adjustment occurs once per completed rollout. */
    static final float LR_SCALE_MIN = 0.20f, LR_SCALE_MAX = 1.50f;
    static final float KL_ADAPT_UPPER = 1.5f, KL_ADAPT_LOWER = 0.5f;
    /** Rewards are multiplied by this before learning so values stay near O(1). */
    static final float REWARD_SCALE = 0.2f;
    /** One-shot outcome bonus after a multi-hit incoming chain is broken with meaningful lateral displacement. */
    static final double COMBO_ESCAPE_REWARD = 0.04;
    /** If the (summed over heads) policy entropy falls under this, the entropy bonus is multiplied (anti-collapse). */
    static final double ENTROPY_FLOOR_FRAC = 0.3; // fraction of the maximum entropy of the UNLOCKED discrete / on-off heads
    static final float ENTROPY_FLOOR_BOOST = 3f;
    static final int AUTOSAVE_EVERY_TICKS = 6000; // 5 minutes at 20 TPS
    /** Autosave interval while the curriculum is still in stage 1-3 (early progress is cheap to lose). */
    static final int AUTOSAVE_EARLY_TICKS = 2000;
    static final int STATS_EVERY_EPISODES = 10;

    // ---------------- episode ----------------
    /** Default live-mod episode limit in ticks (20 ticks = 1 second). The simulator sizes its limit to the selected kit. */
    static final int EPISODE_TICKS = 300;
    /**
     * STAGE-GATE decision at the time limit. Against diamond armor + Protection III a kill needs ~21 full hits (0.98 HP each), so a clearly
     * winning duel often has not ended when time is up, and a gate that counts only kills reads 0 % for a policy that out-fights the bot
     * (measured: dealt 9.5 HP vs a stationary bot, 100 % timeouts, 0 % wins). A timeout counts as a gate SUCCESS when the agent dealt at least
     * LEAD_MIN_DEALT_HP and out-damaged the enemy by at least LEAD_MARGIN_HP. Gate only: the terminal reward stays 0 for a timeout, wins/losses in
     * the logs stay kills, and the guard's collapse rule is unchanged. OFF by default (opt in with -Drlpvp.leadDecision=true): in a 500k-tick from-scratch A/B it promoted the agent faster but ended in a passive policy.
     */
    static final boolean LEAD_DECISION = "true".equals(System.getProperty("rlpvp.leadDecision")); // OFF by default: see docs/CHANGELOG_V7_19.md
    static final double LEAD_MIN_DEALT_HP = 6.0, LEAD_MARGIN_HP = 5.0;
    static boolean leadDecision(boolean timedOut, double dealtHp, double takenHp) {
        return LEAD_DECISION && timedOut && dealtHp >= LEAD_MIN_DEALT_HP && dealtHp - takenHp >= LEAD_MARGIN_HP;
    }
    /** Simulator gives a full-charge, always-landed kill about twice its theoretical minimum time; override with -Dsim.episodeTicks=N for A/B. */
    static final double EPISODE_KILL_TIME_FACTOR = 2.0;
    /** Hard safety cap for simulator episode lengths. */
    static final int EPISODE_TICKS_MAX = 1200;
    /**
     * A player must be this close (blocks) to be picked as the opponent. 48 = the usual player tracking distance on servers (a player farther away
     * is not even loaded on the client). NOTE: the distance input saturates at 6 blocks (dist / 6), so beyond that the policy sees "far" and relies on
     * the yaw/pitch error to turn and approach; it was trained at 3-6 blocks.
     */
    static final double TARGET_RANGE = 96.0;
    /** The current opponent is dropped (episode ends) when it gets farther than this. */
    static final double TARGET_LOSE_RANGE = 112.0;

    // ---------------- combat bookkeeping ----------------
    /** Health lost by the opponent only counts as "my damage" this many ticks after my swing. */
    static final int HIT_CREDIT_TICKS = 6;
    /** Attack only fires when the weapon cooldown is at least this charged (0..1). */
    static final float MIN_ATTACK_STRENGTH = 0.9f;
    /** Vanilla's ordinary client attack-key path does not land a hit until this charge threshold is reached. */
    static final float VANILLA_ATTACK_MIN_CHARGE = 0.9f;
    /**
     * From this stage on the agent may swing before the weapon is fully charged (gate lowered to MIN_ATTACK_STRENGTH_LATE),
     * so it can LEARN to wait for a full charge (FULL_CHARGE_HIT_BONUS) instead of being forced to. Earlier stages keep the hard gate.
     */
    static final int GATE_RELAX_STAGE = 99; // relaxing the gate at stage 6 made the simulated agent spam swings and flee; keep the hard 0.9 gate (set to 6 to experiment)
    static final float MIN_ATTACK_STRENGTH_LATE = 0.5f;
    /**
     * For servers that hide or fake bot health: count a hit from the opponent's hurt animation
     * instead of a health drop. Leave off unless your bots' health never changes on your screen.
     */
    static final boolean HURT_FALLBACK = false;
    /** HP credited per hit when HURT_FALLBACK is on (about a diamond sword hit). */
    static final float FALLBACK_HIT_HP = 7f;
    /** Click "Respawn" automatically when the agent dies. */
    static final boolean AUTO_RESPAWN = true;

    // ---------------- reward ----------------
    /** Reward for dealing all 20 HP of damage (and penalty for taking it). */
    static final float W_DAMAGE = 12f;   // 9 made the simulated agent flee as soon as the enemy started hitting back (stage 5); raise tech weights, not this
    static final float W_WIN = 15f;
    /** Dense shaping (facing + closeness) fades from 1.0 down to SHAPING_MIN as training ticks pass. */
    static final float SHAPING_MIN = 0.15f; // was 0.35: facing/closeness are only a bootstrap; a permanent floor pays for hovering without hitting
    static final float SHAPING_TAU_TICKS = 400_000f;   // was 100k: with 378 inputs the agent learns slower and the aim shaping was gone before it could aim
    static final float FACING_REWARD = 0.01f;      // per tick at full shaping
    static final float CLOSENESS_REWARD = 0.0025f; // per tick at full shaping

    // ---------------- reward objective ----------------
    /** Default to outcome-first learning: do not assign intrinsic value to named combat techniques. */
    static final boolean OUTCOME_ONLY_REWARDS = true;
    static boolean outcomeOnlyRewards() { return OUTCOME_ONLY_REWARDS; }

    // ---------------- technique discovery and reward policy ----------------
    /** Technique event detection and logging stay enabled even when all technique-specific payouts are disabled. */
    static final boolean TECH_DISCOVERY = true;
    /** Hard-off switch: no named technique can add or subtract PPO reward in this build. */
    static final boolean TECHNIQUE_REWARDS_ENABLED = false;
    /** Kept at zero as a second guard and for old checkpoint/config compatibility. */
    static final double TECH_REWARD_SCALE = 0.0;
    static boolean techniqueRewardsEnabled() {
        return TECHNIQUE_REWARDS_ENABLED && !OUTCOME_ONLY_REWARDS && TECH_REWARD_SCALE > 0.0;
    }
    /** Base bonuses (before curriculum tech weight, annealing and per-episode diminishing). A 7 HP hit is worth 4.2 via W_DAMAGE. */
    // Technique identity is telemetry only by default. The equal base values below are retained for compatibility
    // and isolated experiments, but TECH_REWARD_SCALE=0 keeps them out of PPO returns. This ensures the primary
    // objective remains real damage differential and episode outcome, not a chosen hit label.
    // Historical per-hit crit/sprint satiation bonuses are retired; the constants remain for source compatibility.
    /** Retired per-hit identity bonus; kept only for source/save compatibility. */
    static final double SATIATION_REF_UNIT = 4.2, SATIATION_SCALE = 0.0;
    /** Retired circle-strafe reward coefficients; orbiting is judged by real exchange and episode outcomes only. */
    static final double ORBIT_W = 0.012, ORBIT_REF_RATE = 0.06, ORBIT_MIN_DIST = 1.5, ORBIT_MAX_DIST = 5.0, ORBIT_MAX_YAW_ERR_DEG = 20.0;
    /** Being hit while airborne (a jump-crit that went wrong) costs this many typical hits extra, weighted per stage (Weights.airPen). */
    static final double TECH_AIR_HIT_PENALTY = 0.0; // telemetry only; no generic airborne penalty against jump exploration
    /** Legacy diagnostic coefficient for separating sprint-hit exchanges; no active reward multiplier uses it. */
    static final double TECH_FLEE_CUT = 0.5, TECH_FLEE_REF = 0.25;
    // Equal neutral values are retained for compatibility if a future experiment explicitly enables TECH_REWARD_SCALE.
    static final float TECH_CRIT = 0.05f;
    static final float TECH_SPRINT_HIT = 0.05f;
    /** No extra sprint-only charge multiplier; server knockback's real downstream outcome is already measured. */
    static final double TECH_SPRINT_CHARGE_BONUS = 0.0, TECH_CRIT_CHARGE_CUT = 0.0, TECH_CAP_HITS = 0.25;
    // net HP is measured in units of a TYPICAL HIT of this kit (running average of the real damage per landed hit): in full diamond + protection 3 one hit is only ~1 HP,
    // so a fixed HP reference would have clamped every exchange to the minimum and erased the situational signal.
    static final double TECH_NET_HITS = 1.0, TECH_NET_MIN = 0.25, TECH_NET_MAX = 1.5;
    // The damage reward is a fraction of the HP bar (W_DAMAGE / 20 per HP), so a hit is worth ~4.2 unarmored but only ~0.6 in diamond + prot 3. The technique bonuses and the
    // pointless-whiff / whiff-streak penalties were tuned against the unarmored size; unscaled they became ~7x larger RELATIVE to a hit and could outweigh the damage signal
    // (or, for the penalties, push toward not swinging). They are now multiplied by clamp(typical hit HP / TECH_HIT_REF, TECH_KIT_SCALE_MIN, 1).
    static final double TECH_HIT_REF = 7.0, TECH_KIT_SCALE_MIN = 0.35;
    // DAMAGE reward normalised by kit (v7.22): the damage term is a fraction of the HP bar, so one hit is ~4.2 unarmored but ~0.6 in diamond + prot 3 next to dense shaping worth ~7 per 300-tick
    // episode. It is multiplied by clamp((TECH_HIT_REF / typical hit)^DMG_SCALE_EXP, 1, DMG_SCALE_MAX) (typical hit = running average of real damage per landed hit), and the dense
    // shaping by clamp(EPISODE_TICKS / this episode's length, DENSE_SCALE_MIN, 1): kit-aware episodes are up to 4x longer, which made the per-episode shaping total grow 4x.
    // Gentle on purpose (sqrt, capped 2x): full normalisation would make a fight's damage total exceed the win bonus.
    static final double DMG_SCALE_EXP = 0.5, DMG_SCALE_MAX = 2.0, DENSE_SCALE_MIN = 0.25;
    // CRITIC: Huber delta follows the return scale (0.5 x std of this rollout's returns, smoothed, clamped). A fixed delta of 1 turned the value loss into plain L1 for
    // returns of 10-20 (W_WIN 15), so value learning crawled. Adam keeps the step size, so only the loss shape changes.
    static final double VALUE_HUBER_FRAC = 0.5, VALUE_HUBER_MIN = 1.0, VALUE_HUBER_MAX = 8.0;
    // SPACING exchange classification retained for telemetry. It no longer pays a technique-identity bonus by default.
    static final float TECH_SPACING = 0.35f;
    static final double TECH_SPACING_MIN_DIST = 2.5;
    // BAIT event classification retained for telemetry: opponent overcommits outside reach and is counter-hit inside the window.
    static final float TECH_BAIT = 0.40f;
    static final int TECH_BAIT_WINDOW = 14;
    static final double TECH_BAIT_MAX_DIST = 4.2, TECH_BAIT_MIN_FACING = 0.5;
    // Retained style-share diagnostics for historical compatibility. They do not scale rewards while TECH_REWARD_SCALE=0.
    static final double TECH_DOMINANCE_MAX = 0.5, TECH_DOMINANCE_MIN = 0.2, TECH_DOMINANCE_RATE = 0.02;
    // NETWORK domain randomisation (sim only; the real Fabric client naturally uses its real connection). LAG_MIN_MS/LAG_MAX_MS are RTT ping.
    // Each episode splits RTT into asymmetric C2S/S2C paths. Transport-level jitter, ordered
    // delivery, retransmission delay and head-of-line blocking are modeled in NetworkSimulation.
    static final boolean LAG_RANDOMIZE = Boolean.parseBoolean(System.getProperty("rlpvp.lagRandomize", "true"));
    static final double LAG_MIN_MS = Double.parseDouble(System.getProperty("rlpvp.lagMinMs", "20")), LAG_MAX_MS = Double.parseDouble(System.getProperty("rlpvp.lagMaxMs", "150"));
    static final double LAG_NONE_PROB = 0.1;
    // Technique coefficients remain for serialized/config compatibility and controlled diagnostics only; TECH_REWARD_SCALE=0 removes them from PPO returns.
    static final float TECH_KB_FOLLOWUP = 0.05f;
    static final float TECH_COMBO = 0.20f;
    static final float TECH_FIRST_HIT = 0.15f;
    static final float TECH_PUNISH = 0.30f;
    static final float TECH_DODGE = 0.30f;
    static final float TECH_PUNISH_MAX_ENEMY_CHARGE = 0.6f;
    /** Legacy diagnostic multiplier retained for compatibility; follow-up exchange outcomes are measured, not paid. */
    static final double TECH_PURSUIT_MULT = 1.6;
    static final double TECH_PURSUIT_MIN_GAP = 0.8;
    static final int TECH_FOLLOWUP_MIN_TICKS = 6;
    static final int TECH_FOLLOWUP_MAX_TICKS = 30;
    static final int TECH_DODGE_WINDOW = 6;
    static final int TECH_DODGE_CAP = 3;
    static final double TECH_DODGE_MIN_SPEED = 0.08;   // blocks/tick
    static final double TECH_DODGE_MIN_FACING = 0.8;
    /** Event de-duplication interval (vanilla hurt-invulnerability is 10); affects telemetry tags, not rewards. */
    static final int TECH_MIN_EVENT_GAP_TICKS = 10;
    /** Window used to associate technique tags with subsequent exchange HP outcomes. */
    static final int TECH_EXCHANGE_TICKS = 20;
    // JUMP_RESET / W-TAP / S-TAP event windows retained for measurement and compatibility. They do not independently pay the policy.
    static final float TECH_W_TAP = 0.30f, TECH_S_TAP = 0.35f;
    static final int TECH_TAP_RELEASE_MAX = 5, TECH_TAP_RESPRINT_MAX = 8;
    // v7.31 SPRINT LANE + MISTIMED JUMP HIT (from the sprint diagnostic: only ~25 % of swings were made while sprinting; ~40 % were plain, mostly airborne and rising, and S was held on 40-56 % of swings).
    /** Sprint-lane opportunity definition used by audit telemetry only; no dense reward is paid for satisfying it. */
    static final double SPRINT_LANE_W = 0.0, SPRINT_LANE_MIN = 2.0, SPRINT_LANE_MAX = 4.4, SPRINT_LANE_YAW_DEG = 15.0; // opportunity telemetry only
    /** Retained compatibility coefficient; generic airborne/mistimed-hit identity penalties are disabled. */
    static final double TECH_MISTIMED_HIT = 0.0; // no action-identity penalty; judge the resulting damage/trade
    static final float TECH_JUMP_RESET = 0.40f;   // same neutral base as crit / sprint hit / follow-up
    // Grounded-state mask is used only when classifying technique telemetry; hit damage and knockback remain governed by simulator rules.
    static final int TECH_GROUNDED_MASK = (1 << TechniqueDiscovery.SPRINT_HIT) | (1 << TechniqueDiscovery.KB_FOLLOWUP);
    /** Legacy grounded-only flag retained for compatibility; no plain per-hit identity bonuses are active. */
    static final boolean GROUNDED_TAP_ONLY = true;
    static final int TECH_JR_WINDOW = 8, TECH_JR_EXCHANGE = 30, TECH_JR_SEP_TICKS = 10, TECH_JR_CAP = 6; // measurement slots per episode
    static final double TECH_JR_SEP_FULL = 1.2, TECH_JR_SEP_ZERO = 3.0, TECH_JR_MIN_FACTOR = 0.3;
    /** Hard cap on technique bonus per episode (W_WIN is 15). */
    static final float TECH_EPISODE_CAP = 0.25f; // inactive while TECH_REWARD_SCALE=0; conservative guard if explicitly re-enabled
    /** Legacy technique-clock duration retained for compatibility; no technique bonuses are paid by default. */
    static final long TECH_ANNEAL_TICKS = 1_500_000L;
    /** Compatibility settings for retired crit/sprint identity shaping. */
    static final boolean TECH_CRIT_EXCESS_DISCOUNT = false; // never discount actual server-confirmed crit damage
    static final double TECH_COMPLEMENT_MAX = 1.0; // no inverse-crit bonus that pumps sprint-hit identity reward
    /** Legacy multiplier cap retained for compatibility; no technique multiplier affects reward by default. */
    static final double TECH_MULT_CAP = 2.5;
    static final float TECH_FLOOR = 1.0f; // telemetry clock only while technique payout is disabled
    /** Retained diagnostic state only; high-water share is no longer used to alter technique reward. */
    static final double TECH_RETAIN_MAX = 1.6, TECH_RETAIN_MIN_HW = 0.06, TECH_RETAIN_DECAY = 5e-4, TECH_RETAIN_DEADBAND = 0.25; // slow-average rate per exchange; drops under 25% are noise and pay nothing extra
    /** Preserved miss penalty (not annealed): a miss within this many ticks of the previous miss. */
    static final float WHIFF_STREAK_PENALTY = 0.08f;
    static final int WHIFF_STREAK_WINDOW = 12;

    // ---------------- reward additions (curriculum) ----------------
    /** Pitch-facing term. Multiplied by the curriculum pitch weight (0 in stage 1, ramps to 1 from stage 2). */
    static final float PITCH_FACING_REWARD = 0.01f; // = FACING_REWARD: pitch is rewarded like yaw
    /** Small per-tick cost so the agent does not stall. Scaled by the curriculum time weight. */
    static final float TIME_PENALTY = -0.001f;
    /** Reward per block of distance closed, only while the enemy was farther than PROGRESS_MIN_PREV_DIST. */
    static final float PROGRESS_REWARD = 0.02f;
    static final double PROGRESS_MIN_PREV_DIST = 3.5;
    /** Per-tick bonus for standing at sword range (stage 7+). */
    static final float SPACING_REWARD = 0.004f;
    static final double SPACING_MIN = 2.0;
    static final double SPACING_MAX = 3.2;

    // ---------------- retired legacy technique bonuses (OUTCOME_ONLY_REWARDS is fixed true in this build) ----------------
    /** Real reach used by ActionApplier's own crosshair ray (vanilla survival entity reach). */
    static final double ATTACK_REACH = 3.0;
    /** Retired label bonuses; actual crit damage is already represented by real credited HP damage. */
    static final float CRIT_BONUS = 0.0f;
    /** Retired sprint identity bonus; evaluate sprint knockback through actual follow-up and exchange outcomes. */
    static final float SPRINT_HIT_BONUS = 0.0f;
    /** Retired hit-count bonus; combos are evaluated by real damage and episode outcomes. */
    static final float COMBO_BONUS = 0.0f;
    /** Retired opening-hit bonus; first-hit advantage is measured through the exchange. */
    static final float FIRST_HIT_BONUS = 0.0f;
    /** Retired whiff-identity penalty; unsuccessful attacks are judged by the actual match/damage outcomes. */
    static final float WHIFF_PENALTY = 0.0f;
    /**
     * Cost of EVERY missed swing (a miss spends the 12-tick attack cooldown, and the 6.3-degree 'pointless' cone above never charged a swing
     * that was merely a little off). Measured: the v7.2 checkpoint misses 81-93 % of its swings in evaluation. Small next to a hit (7 HP = 4.2),
     * applied in training only. DEFAULT 0 (off): an 80k-tick A/B from the v7.2 checkpoint with 0.12 did NOT lower the whiff rate (81 % vs 75 % without it) and that run fell back to stage 6, so it is unproven. -Drlpvp.missCost=0.12 re-enables it for experiments.
     */
    /**
     * ATTACK GATE (invalid-action masking, like masking an illegal move): a swing is only offered to the policy when it could possibly connect, i.e. the
     * enemy is within ATTACK_GATE_DIST blocks and the crosshair is within ATTACK_GATE_YAW / ATTACK_GATE_PITCH degrees of it (the policy's own, delayed
     * observation). The masks are far wider than the hit cone (hitbox half-angle ~6 degrees at 3 blocks), so WHEN to swing inside the cone, and
     * whether to correct aim first, is still learned; only swings that cannot hit are removed (the evaluated policy had 75-93 % misses).
     * The mask is stored with every transition (PPO log-probs stay exact) and the head's entropy is excluded while masked.
     * -Drlpvp.attackGate=false turns it off (A/B runs, old behaviour).
     */
    static final boolean ATTACK_GATE = !"false".equalsIgnoreCase(System.getProperty("rlpvp.attackGate", "true"));
    /**
     * Distance cap: ray reach is 3.0 to the hitbox, so the farthest possible hit is ~3.0 + 0.42 (box diagonal) = 3.42 between centres. The old 4.0
     * offered swings that could never connect (the whiff split's "far" bucket starts at WHIFF_FAR_DIST = 3.6). 3.7 keeps ~0.3 blocks for the
     * delayed observation. YAW is now range-dependent: a box of half-width ~0.42 + ATTACK_GATE_MARGIN blocks subtends atan((0.42+m)/max(dist,0.6)), so
     * the mask is looser up close (where the hitbox is a wide target; the old flat 20 deg masked real hits at <1.2 blocks) and tighter at range
     * (about 15 deg at 3.4 blocks versus the old 20). Clamped to [ATTACK_GATE_YAW_MIN, ATTACK_GATE_YAW]. -Drlpvp.attackGateLegacy=true restores 4.0 / 20 flat.
     */
    static final boolean ATTACK_GATE_LEGACY = "true".equalsIgnoreCase(System.getProperty("rlpvp.attackGateLegacy", "false"));
    static final double ATTACK_GATE_DIST = ATTACK_GATE_LEGACY ? 4.0 : 3.7, ATTACK_GATE_PITCH = 30.0;
    static final double ATTACK_GATE_YAW = ATTACK_GATE_LEGACY ? 20.0 : 45.0, ATTACK_GATE_YAW_MIN = ATTACK_GATE_LEGACY ? 20.0 : 10.0;
    static final double ATTACK_GATE_MARGIN = 0.5;
    /** No separate miss cost: a miss is already reflected by lost attack time and the match outcome. */
    static final float MISS_COST = 0.0f;
    static final double WHIFF_FAR_DIST = 3.6;
    static final double WHIFF_OFFAIM_YAW = 0.035; // |yaw err| / 180 = 6.3 degrees, about the hitbox half-angle at 3 blocks: a swing that is not on the enemy costs something
    static final double WHIFF_OFFAIM_PITCH = 0.06; // |pitch err| / 90 = 5.4 degrees (the pitch axis counts too)
    /** While the weapon recharges (<50%), standing just outside enemy reach is worth this fraction of SPACING_REWARD. */
    static final double RETREAT_MAX = 4.3;
    static final float RETREAT_FRACTION = 0.8f;

    // ---------------- timing bonuses (stage 6+, paid only together with a REAL hit, scaled by Weights.late) ----------------
    /** A weapon is "fully charged" at this cooldown value. */
    static final float FULL_CHARGE = 0.9f;
    /** Hit that was swung with a fully charged weapon (only meaningful once the hard gate is lowered, GATE_RELAX_STAGE). */
    static final float FULL_CHARGE_HIT_BONUS = 0.3f;
    /** Weak W-tap / reset signal: the hit's swing came this many ticks after my previous swing. */
    static final int RESET_GAP_MIN = 8;
    static final int RESET_GAP_MAX = 13;
    static final float RESET_HIT_BONUS = 0.15f;
    /** Hit whose swing started within this many ticks after the ENEMY started a swing (its weapon was recharging). */
    static final int PUNISH_WINDOW_TICKS = 6;
    static final float PUNISH_HIT_BONUS = 0.35f;
    /** Per tick while my HP is above the enemy's (scaled by the lead and by anti-stalling, stage 7+ only). */
    static final float HP_ADVANTAGE_REWARD = 0.004f;
    /** The enemy's weapon is assumed to need this many ticks to recharge (a sword; its real cooldown is not synced to remote clients). */
    static final float ENEMY_CHARGE_TICKS = 12.5f;

    /** Aim reward shape 1/(1+(err/scale)^2): ~1 on target, 0.5 at this many degrees off, so small improvements matter. */
    static final double AIM_YAW_SCALE_DEG = 10.0;
    static final double AIM_PITCH_SCALE_DEG = 10.0; // = AIM_YAW_SCALE_DEG

    // ---------------- retired soft near-miss credit ----------------
    /** Soft near-miss HP credit is retired; only server-confirmed HP damage enters the damage reward. */
    static final float SOFT_HIT_FRACTION = 0.0f;
    /** Legacy cutoff retained for compatibility; soft near-miss credit is disabled in every stage. */
    static final int SOFT_MAX_STAGE = 0;
    /** Legacy cap retained at zero so a near miss can never generate pseudo-damage reward. */
    static final float SOFT_EPISODE_CAP_HP = 0.0f;
    /** Legacy reference HP; the soft-credit path is disabled and this value is not used for reward. */
    static final float SOFT_HIT_HP = 7f;
    static final double SOFT_HIT_REACH = 3.0;
    /** |yaw error| / 180 at or below this (0.06 is about 11 degrees). */
    static final double SOFT_YAW_ERR = 0.06;
    /** |pitch error| / 90 at or below this (0.10 is about 9 degrees). */
    static final double SOFT_PITCH_ERR = 0.10;

    // ---------------- anti-stalling ----------------
    /** Dense shaping stays at full strength this many ticks into an episode with no real hit landed... */
    static final int IDLE_FREE_TICKS = 60;
    /** ...then fades linearly to 0 over this many ticks, so standing at spacing without fighting stops paying. */
    static final int IDLE_FADE_TICKS = 120;

    // ---------------- policy prior ----------------

    // ---------------- curriculum ----------------
    // No STAGE_MIN_TICKS / STAGE_MAX_TICKS: progression is purely performance based (see Curriculum). The evidence minimum is GATE_EPISODES.
    /** Recent success rate required to leave stages 1..6. Stages 7-9 use PFSP/Elo league promotion instead. */
    static final float[] STAGE_GATE_WIN = {0.60f, 0.60f, 0.60f, 0.60f, 0.60f, 0.55f};
    /** Stages 1..AIM_GATE_MAX_STAGE count an episode as a success if it was won OR the agent was on target this fraction of the time (the bot is no longer placed, so a kill may be out of reach). */
    static final int AIM_GATE_MAX_STAGE = 4;
    static final double AIM_GATE_ON_TARGET = 0.6;
    /** Aim-stage stall relief (see docs/CAMERA_DYNAMICS.md): first AIM_GATE_GRACE_TICKS of an episode are ignored; every AIM_GATE_RELIEF_EPISODES episodes in the stage lower the on-target share by AIM_GATE_RELIEF_STEP down to AIM_GATE_FLOOR. */
    static final int AIM_GATE_GRACE_TICKS = 15;
    static final int AIM_GATE_RELIEF_EPISODES = 90;
    static final double AIM_GATE_RELIEF_STEP = 0.05;
    static final double AIM_GATE_FLOOR = 0.30;
    static final double ON_TARGET_DEG = 6.0;
    /** Win rate is measured over this many most recent episodes of the stage. */
    static final int GATE_EPISODES = 30;
    // ---------------- SpamGuard: technique-like movement patterns are measured, not rewarded or penalized.
    static final int SPAM_EMA_TICKS = 100;
    /** Maximum synchronous PPO work per Minecraft client tick; the learner yields between samples. */
    static final long CLIENT_LEARN_BUDGET_NANOS = Math.max(250_000L,
        Long.getLong("rlpvp.clientLearnBudgetNanos", 2_000_000L));
    static final int SPAM_JUMP_WINDOW = 30;            // measurement window used to label jump attempts productive/unproductive
    /** Jump-spam terms are disabled pending outcome-based evidence; jump starts remain counted in telemetry. */
    static final double SPAM_JUMP_REWARD_SCALE = 0.0;
    static final double SPAM_JUMP_COST = 0.006, SPAM_JUMP_REFUND = 0.02, SPAM_JUMP_UNJUST = 0.01;
    static final double SPAM_JUMP_OK = 0.03;
    static final double SPAM_RATE_W = 0.3;
    // Small outcome-neutrality guard: charge only unproductive, idle sneak/sprint churn.
    // Moving W/S taps, strafing, combat resets, and post-hit recovery remain exempt.
    static final double SPAM_SNEAK_TICK = 0.0015, SPAM_SNEAK_TOGGLE = 0.002;
    static final double SPAM_SNEAK_OK = 0.20, SPAM_SNEAK_RATE_W = 0.012; // was 0.003: too small to change behaviour
    static final double SPAM_FLIP_RATE_OK = 0.32, SPAM_SPRINT_TOGGLE_RATE_OK = 0.20;
    static final double SPAM_SNEAK_TOGGLE_RATE_OK = 0.16, SPAM_TOGGLE_RATE_W = 0.02; // was 0.0045
    static final double SPAM_MOVE_STAGNATION = 0.0015, SPAM_MOVE_OVERLAP = 0.004;
    static final double SPAM_MOVE_REVERSAL = 0.0, SPAM_MOVE_SPRINT_TOGGLE = 0.0;
    static final double SPAM_MOVE_BAD_STRAFE = 0.0, SPAM_MOVE_EP_CAP = 0.35;
    // Event-rate thresholds remain only as historical diagnostics; action switching no longer affects reward.
    static final int SPAM_FLIP_WINDOW = 3;
    static final double SPAM_FLIP_OK = 1.0, SPAM_SPRINT_TOGGLE_OK = 1.0, SPAM_FLIP_W = 0.0;
    static final double SPAM_STUCK_SPEED = 0.02;
    static final int SPAM_STUCK_TICKS = 10, SPAM_HIT_GRACE = 20;
    static final int SPAM_JR_WINDOW = 8;               // a grounded jump this soon after I TOOK damage is a justified reaction (jump reset): free, never "unjustified"
    static final int SPAM_TAKEN_GRACE = 6;             // ...and movement-key flips / sprint toggles right after taking damage (re-sprint, recover) are free
    static final double SPAM_STUCK_COST = 0.002, SPAM_SPRINT_NOFWD_COST = 0.0012;
    static final double SPAM_MOVE_TICK_CAP = 0.01, SPAM_MOVE_EPISODE_CAP = 1.2; // episode cap still < 0.1 * W_WIN
    /** The consequence model trains on every Nth transition (validation samples are unaffected): about half its per-tick cost at 2. */
    static final int CONSEQUENCE_TRAIN_EVERY = 2;
    /**
     * REVIEW MIXING: from REVIEW_FROM_STAGE on, a share of the training episodes is played against opponents of EARLIER stages (3..stage-1, the
     * nearest ones most often). It keeps the agent from forgetting how to beat them, and gives a learning signal while the current stage is too hard
     * (a stage-7 run sat at 16-21 % wins for 1,400 episodes). Review episodes never count toward the gate, the hop level or the collapse guard.
     * A stalled stage (no gate after STALL_EPISODES episodes and under half of the needed rate) doubles the share.
     */
    static final int REVIEW_FROM_STAGE = 6;
    static final int REVIEW_MIN_STAGE = 3;
    static final double REVIEW_SHARE = 0.20;
    static final double REVIEW_SHARE_STALLED = 0.40;
    static final int STALL_EPISODES = 20 * GATE_EPISODES;
    /**
     * A stage is only left after the window has stayed at the gate for this many consecutive episodes (counting the one that filled it: one extra full window): a single lucky
     * window of 30 episodes is not enough evidence (a fresh run reached stage 7 after 100k ticks on 53 % wins and collapsed there).
     */
    static final int GATE_HOLD_EPISODES = 30;
    /** Every time stage s+1 collapsed and the agent was sent back, the gate for leaving stage s rises by this much (max GATE_BUMP_MAX). */
    static final float GATE_BUMP_PER_COLLAPSE = 0.05f;
    static final float GATE_BUMP_MAX = 0.15f;
    /** Ticks over which the pitch reward weight ramps from 0 to 1 after leaving stage 1. */
    static final long PITCH_RAMP_TICKS = 6000;
    /** Entropy coefficient multiplier right after a lock is lifted, decaying back to 1 over ENTROPY_BOOST_TICKS. */
    static final float ENTROPY_BOOST = 3f;
    static final long ENTROPY_BOOST_TICKS = 6000;

    // ---------------- opponent bot (Carpet, singleplayer only) ----------------
    // The bot is NEVER teleported. Between episodes it is only healed in place.
    /** Heal the bot and the agent (health + food) at the start of each episode. Nobody is moved. */
    static final boolean HEAL_AGENT = true;
    /** Ticks to wait after healing so the new health has reached the client before the episode starts. */
    static final int HEAL_WARMUP_TICKS = 3;
    /** If a Carpet bot dies and is removed, respawn it where it died (/player <n> spawn at ...). */
    static final boolean RESPAWN_BOT = true;
    /** Stage 7: how often the frozen self-play opponent is refreshed from the learning policy. */
    static final long SELF_PLAY_SNAPSHOT_TICKS = 25_000;
    /** Stage 7 is a league: past snapshots + scripted opponents. Max frozen snapshots kept. */
    static final int LEAGUE_POOL = 8;
    /** Stage 7 opponent mix per episode: P(snapshot), P(strong scripted), rest = aggressive scripted. */
    static final double LEAGUE_P_SNAPSHOT = 0.5;
    static final double LEAGUE_P_STRONG = 0.3;
    /** Scripted bots turn at a limited speed (degrees/tick) instead of snapping to the agent. */
    static final float BOT_TURN_WALK = 40f;
    static final float BOT_TURN_AGGRESSIVE = 35f;
    static final float BOT_TURN_STRONG = 30f;

    // ---------------- play policy / per-head exploration ----------------
    /**
     * /rl play and the simulator's evaluation use PpoAgent.actPlay: camera = mean (no noise), discrete heads SAMPLED at this temperature.
     * Pure argmax (actGreedy) can never pick a minority action: jump (low prior probability) and "no strafe"/"back" are never the plurality, so a
     * greedy evaluation showed 100% one-sided strafe, 0 jumps, 0 crits even when the trained policy mixes them. 1.0 = exactly the trained policy.
     */
    static final boolean PLAY_STOCHASTIC = true;
    static final float PLAY_TEMPERATURE = 1.0f;
    /**
     * Play-time stack: 0=raw policy; 1=heuristic situational planner; 2=planner + measured intelligence
     * constraints; 3=learned-only (policy + validated consequence-model search + feasibility guard). The default disables hand-authored strategic controls through the INTEL_OFF mask; mode 3 is an optional
     * learned-only path that skips the intelligence-suite update work.
     * Mode 3 does not override tactical choices with hand-authored strategy rules.
     */
    static volatile int PLAY_STACK = Integer.getInteger("rlpvp.stack", 2);
    /** Ablation bits: 1 attack gate, 2 movement, 4 spacing, 8 combo escape, 16 resources, 32 scoring, 64 guidance. */
    // Default policy play uses opponent-memory inputs and learned model search, but leaves all
    // hand-authored strategic scoring/guidance/enforcement disabled. The reactive feasibility
    // guard remains always-on. Set -Drlpvp.intelOff=96 to restore the measured optional stack-2
    // strategic enforcement profile, or 0 to enable all heuristic layers for controlled A/B tests.
    static volatile int INTEL_OFF = Integer.getInteger("rlpvp.intelOff", 127);
    /**
     * Per-head entropy floors. The old floor was on the SUM of the discrete heads, which the attack/sprint heads can satisfy while
     * strafe collapses to one key. A head (forward/back, strafe, jump) whose own entropy EMA falls below this fraction of its maximum
     * gets its entropy bonus multiplied. The attack and sprint heads are deliberately excluded (a random attack head just whiffs).
     */
    static final double HEAD_ENTROPY_FLOOR_FRAC = 0.35;
    static final float HEAD_ENTROPY_BOOST = 3f;
    /** v7.24: the sprint head also gets a (lower) floor so it cannot collapse to never-sprint/always-sprint, which kills sprint hits and w-taps. */
    static final double SPRINT_ENTROPY_FLOOR_FRAC = 0.2;
    /** League sampling favours opponents the agent is weak against (W/L/D matchup record + damage deficit, smoothed by sample size, weight capped at 2x, 20 % share) from this stage on. Was stage 9 only; stages 7-8 already use the league sampler. -Drlpvp.weaknessFromStage=99 turns it off. */
    /** Stages from here up to the league stages pick the scripted bot style per episode at random; with this on, styles the agent is weak against (matchup record) are drawn more often (never less often than the base mix, weight capped at 2x). 99 = off. */
    static final int STYLE_WEAKNESS_FROM_STAGE = Integer.getInteger("rlpvp.styleWeaknessFromStage", 3);
    static final int WEAKNESS_FROM_STAGE = Integer.getInteger("rlpvp.weaknessFromStage", 7);
    /** The strafe head's own floor (was the shared 0.35 = about 0.38 nats of 1.10, i.e. roughly 10-15 % off-direction picks EVERY tick, which looks like a quick A/D tap before each change of direction). Lower still keeps it from collapsing to one key; -Drlpvp.strafeFloor overrides. */
    static final double STRAFE_ENTROPY_FLOOR_FRAC = Double.parseDouble(System.getProperty("rlpvp.strafeFloor", "0.18"));

    // ---------------- greedy gate (the offline simulator probes the shipped policy; the mod never sets it, so nothing changes there) ----------------
    /** From this stage on, leaving a stage needs the play-mode probe to land hits. */
    static final int GREEDY_GATE_FROM_STAGE = 4;
    /** Entering this stage or later can NOT be forced by the max-tick timer. */
    static final int GREEDY_HARD_FROM_STAGE = 6;
    static final double GREEDY_GATE_HITS = 2.0;
    /** From stage 6 the probe must also not lose the damage race by more than this ratio (dealt >= ratio * taken). */
    static final double GREEDY_GATE_DAMAGE_RATIO = 0.5;
    static final long GREEDY_PROBE_TICKS = 15_000;
    static final int GREEDY_PROBE_EPISODES = 10;

    // ---------------- collapse guard (best-checkpoint rollback, see CollapseGuard) ----------------
    /** Rollback only if the smoothed score is this far below the best smoothed score of the stage... */
    static final double GUARD_DROP = 0.6;
    /** ...for this many windows in a row (a window = STATS_EVERY_EPISODES benchmark episodes). */
    static final int GUARD_PATIENCE = 4;
    /** Windows to wait after a rollback before another is allowed (lets learning resume). */
    static final int GUARD_COOLDOWN_WINDOWS = 12;
    /** Hard cap per stage, so a bad best-snapshot can never freeze training. */
    static final int GUARD_MAX_PER_STAGE = 3;
    static final double GUARD_EMA_ALPHA = 0.2;
    /** A window (STATS_EVERY_EPISODES benchmark episodes) must be at or below this win rate to be eligible for failure classification. */
    static final double GUARD_FAIL_WIN = 0.10;
    /** Eligible non-winning windows are failures only if at least this fraction of episodes are losses, or the policy is not fighting/out-traded. */
    static final double GUARD_FAIL_LOSS = 0.50;
    /** Minimum average real HP damage per episode; below this, the policy is considered to be fleeing/not engaging. */
    static final double GUARD_FAIL_MIN_DEALT = 1.0;
    /** If dealt HP is below this multiple of taken HP, the policy is clearly out-traded. */
    static final double GUARD_FAIL_TRADE = 0.50;
    /** ...this many failed windows in a row = the stage has collapsed: restore the weights it was entered with and go back one stage. */
    static final int GUARD_FAIL_WINDOWS = 5;
    /** Wilson upper bound: only demote when even the 95% upper confidence bound is below this win-rate gate. */
    static final double GUARD_WILSON_Z = 1.96;
    static final int GUARD_MIN_EVIDENCE_EPISODES = 30;
    static final int GUARD_EVIDENCE_WINDOW = 60;
    /** Collapse detection only where a win is meaningful (stages 1..AIM_GATE_MAX_STAGE are scored on aim). */
    static final int GUARD_DEMOTE_FROM_STAGE = AIM_GATE_MAX_STAGE + 1;
    /** A window scoring below this is never stored as the "best" checkpoint (it used to bless an already collapsed policy). */
    static final double GUARD_BEST_FLOOR = -0.5;
    /** Windows in a stage before a best snapshot may be stored. */
    static final int GUARD_MIN_WINDOWS = 3;

    // ---------------- symmetric policy ----------------
    /**
     * The policy is made exactly left/right symmetric: the network is run on the observation AND on its mirror image, and the
     * two answers are averaged (strafe sides swapped, yaw sign flipped). The agent can then no longer have a built-in favourite
     * side. Mirrored training episodes only make the world symmetric; they cannot stop the agent from always picking "left"
     * in its own frame. This can.
     */
    static final boolean SYMMETRIC_POLICY = true;

    // ---------------- HUD ----------------
    static final int HUD_EVERY_TICKS = 1;
}