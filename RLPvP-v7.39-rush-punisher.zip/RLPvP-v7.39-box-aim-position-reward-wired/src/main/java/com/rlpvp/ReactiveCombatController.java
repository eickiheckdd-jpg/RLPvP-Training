package com.rlpvp;

/** Last-mile feasibility and safety checks. Only removes impossible/contradictory choices or prevents edge traps. */
final class ReactiveCombatController {
    static final class Result {
        int rejectedAttacks, correctedSprint, boundaryCorrections;
        boolean changed() { return rejectedAttacks + correctedSprint + boundaryCorrections > 0; }
    }

    Result apply(SituationalStateInterpreter.State s, float[] action, int mask, float attackGate) {
        Result r = new Result();
        if (action == null || action.length < PpoAgent.N_ACT) return r;
        for (int i = 0; i < action.length; i++) if (!Float.isFinite(action[i])) action[i] = 0f;
        action[0] = clamp(action[0]); action[1] = clamp(action[1]);
        action[2] = categorical(action[2]); action[3] = categorical(action[3]);
        for (int i = 4; i < Math.min(action.length, PpoAgent.N_ACT); i++) action[i] = action[i] > 0.5f ? 1f : 0f;

        boolean attackLocked = (mask & ActionMask.LOCK_ATTACK) != 0;
        float gate = Float.isFinite(attackGate) ? Math.max(0f, Math.min(1f, attackGate)) : Config.MIN_ATTACK_STRENGTH;
        boolean chargeReady = s.ownCharge >= gate;
        boolean cannotConnectNow = s.lineOfSight < 0.5f
            || (s.enemyInMyReach < 0.5f && s.distance > Config.ATTACK_REACH + 0.40f)
            || Math.abs(s.yawErrorDeg) > 38f || Math.abs(s.pitchErrorDeg) > 32f;
        // Attack is checked before this tick's camera/movement update in the environment. Do not spend cooldown on an impossible current ray.
        if (action[4] > 0.5f && (attackLocked || !chargeReady || cannotConnectNow)) {
            action[4] = 0f; r.rejectedAttacks++;
        }
        if (action[6] > 0.5f && (Math.round(action[2]) != 2 || action[7] > 0.5f)) {
            action[6] = 0f; r.correctedSprint++;
        }

        if (s.boundaryProximity > 0.88f && (mask & ActionMask.LOCK_MOVEMENT) != ActionMask.LOCK_MOVEMENT) {
            int fwd = Math.round(action[2]) - 1, side = Math.round(action[3]) - 1;
            double inward = fwd * s.inwardForward + side * s.inwardRight;
            if (inward < -0.25) {
                boolean fwdFree = (mask & ActionMask.LOCK_FWD) == 0;
                boolean sideFree = (mask & ActionMask.LOCK_STRAFE) == 0;
                if (fwdFree && Math.abs(s.inwardForward) >= Math.abs(s.inwardRight)) action[2] = s.inwardForward >= 0 ? 2f : 0f;
                else if (sideFree) action[3] = s.inwardRight >= 0 ? 2f : 0f;
                else if (fwdFree) action[2] = s.inwardForward >= 0 ? 2f : 0f;
                action[6] = 0f; r.boundaryCorrections++;
            }
        }
        return r;
    }

    private static int categorical(float v) { return Math.max(0, Math.min(2, Math.round(v))); }
    private static float clamp(float v) { return Math.max(-1f, Math.min(1f, v)); }
}
