package com.rlpvp;

/**
 * Appended combat-state observations. These are descriptive inputs only: they never modify actions.
 * Ratios and distances are normalised to finite [-1, 1] values so they are safe for PPO inputs.
 */
final class CombatObservationMemory {
    static final int FEATURES = Config.COMBAT_FEATURES;

    static final int DISTANCE_DELTA = 0;
    static final int REACH_MARGIN = 1;
    static final int INTERCEPT_ANGLE = 2;
    static final int CROSSHAIR_ON_BOX = 3;
    static final int MISS_TO_HIT_RATIO = 4;
    static final int CRIT_EFFICIENCY_RATIO = 5;
    static final int SPRINT_HIT_EFFICIENCY_RATIO = 6;
    static final int DAMAGE_DIFFERENTIAL_TREND = 7;
    static final int SPRINT_MODIFIER_ACTIVE = 8;
    static final int TICKS_SINCE_SPRINT_INTERRUPTION = 9;
    static final int ATTACK_DURING_IFRAME = 10;
    static final int SPRINT_RESET_READY = 11;
    static final int CROSSHAIR_BOX_DX = 12;
    static final int CROSSHAIR_BOX_DY = 13;

    private static final int SPRINT_INTERRUPTION_CAP = 40;
    private double previousDistance = Double.NaN;
    private boolean previousForwardSprint;
    private int ticksSinceSprintInterruption = SPRINT_INTERRUPTION_CAP;
    private boolean attackDuringIFramePulse;
    private boolean forwardReleasedSinceMyHit = true;
    private int previousTicksSinceMyHit = Integer.MIN_VALUE;
    private final float[] features = new float[FEATURES];

    void reset() {
        previousDistance = Double.NaN;
        previousForwardSprint = false;
        ticksSinceSprintInterruption = SPRINT_INTERRUPTION_CAP;
        attackDuringIFramePulse = false;
        forwardReleasedSinceMyHit = true;
        previousTicksSinceMyHit = Integer.MIN_VALUE;
        java.util.Arrays.fill(features, 0f);
        features[TICKS_SINCE_SPRINT_INTERRUPTION] = 1f;
    }

    /**
     * Updates one tick of observations. {@code reachMargin} is attack reach minus the distance from the
     * agent's eye to the nearest point on the target hitbox (positive means the hitbox is in reach).
     * Velocity inputs in {@code frame} are expressed in the agent's forward/right coordinate system.
     */
    void tick(float[] frame, float[] lastAction, double distance, double reachMargin,
              boolean crosshairOnTargetBox, HitMemory hitMemory, int ticksSinceMyHit) {
        tick(frame, lastAction, distance, reachMargin, crosshairOnTargetBox, hitMemory, ticksSinceMyHit, 0f, 0f);
    }

    void tick(float[] frame, float[] lastAction, double distance, double reachMargin,
              boolean crosshairOnTargetBox, HitMemory hitMemory, int ticksSinceMyHit,
              float normalizedBoxDx, float normalizedBoxDy) {
        if (!Config.COMBAT_OBSERVATIONS || frame == null || frame.length < Config.FRAME || hitMemory == null) return;

        double delta = Double.isFinite(previousDistance) ? distance - previousDistance : 0.0;
        features[DISTANCE_DELTA] = c(delta / 0.6); // requested current_distance - previous_distance; positive = gap widening
        features[REACH_MARGIN] = c(reachMargin / 1.5);
        features[INTERCEPT_ANGLE] = cosine(frame[1], frame[2], frame[16], frame[17]);
        features[CROSSHAIR_ON_BOX] = crosshairOnTargetBox ? 1f : 0f;
        features[CROSSHAIR_BOX_DX] = c(normalizedBoxDx);
        features[CROSSHAIR_BOX_DY] = c(normalizedBoxDy);

        double missHit = hitMemory.recentMyWhiffs() / (double) (hitMemory.recentMyHits() + 1);
        features[MISS_TO_HIT_RATIO] = c(missHit);
        features[CRIT_EFFICIENCY_RATIO] = c(hitMemory.recentMyCriticals() / (double) (hitMemory.recentMySwings() + 1));
        features[SPRINT_HIT_EFFICIENCY_RATIO] = c(hitMemory.recentMySprintHits() / (double) (hitMemory.recentMySwings() + 1));
        features[DAMAGE_DIFFERENTIAL_TREND] = c(hitMemory.recentDamageDifferential() / 20.0);

        boolean forwardInput = lastAction != null && lastAction.length > 2 && lastAction[2] > 0.5f;
        boolean sprintInput = lastAction != null && lastAction.length > 6 && lastAction[6] > 0.5f;
        boolean sprintForward = frame[5] > 0.5f && forwardInput && sprintInput && frame[1] > 0.05f;
        if (previousForwardSprint && !sprintForward) {
            ticksSinceSprintInterruption = 0;
        } else {
            ticksSinceSprintInterruption = Math.min(SPRINT_INTERRUPTION_CAP, ticksSinceSprintInterruption + 1);
        }
        // Minecraft doesn't expose a separate "sprint knockback primed" flag. This is a conservative,
        // observable proxy: sprint is actually active, the previous command held forward+sprint, and forward
        // movement is still present. It is not a guarantee that the next hit receives bonus knockback.
        features[SPRINT_MODIFIER_ACTIVE] = sprintForward ? 1f : 0f;
        features[TICKS_SINCE_SPRINT_INTERRUPTION] = ticksSinceSprintInterruption / (float) SPRINT_INTERRUPTION_CAP;
        features[ATTACK_DURING_IFRAME] = attackDuringIFramePulse ? 1f : 0f;

        // A fresh landed hit invalidates the reset until forward has actually been released. The age gate
        // mirrors the requested >10-tick hurt/invulnerability window, while the release latch tells the
        // policy it must re-prime sprinting (release W / tap S, then sprint again). This is an observation
        // proxy, not a guarantee that Minecraft will grant sprint knockback on the next hit.
        if (ticksSinceMyHit == 0 && previousTicksSinceMyHit != 0) forwardReleasedSinceMyHit = false;
        boolean forwardHeld = lastAction != null && lastAction.length > 2 && lastAction[2] > 0.5f;
        if (!forwardHeld) forwardReleasedSinceMyHit = true;
        boolean hitAgeReady = ticksSinceMyHit == -1 || ticksSinceMyHit > 10;
        features[SPRINT_RESET_READY] = frame[5] > 0.5f && hitAgeReady && forwardReleasedSinceMyHit ? 1f : 0f;
        previousTicksSinceMyHit = ticksSinceMyHit;

        previousDistance = Double.isFinite(distance) ? distance : previousDistance;
        previousForwardSprint = sprintForward;
    }

    /**
     * Called after the action application path. Only a click that was actually queued is an
     * emitted attack; a policy attack intent blocked by cooldown, UI, or ray checks is not.
     * The event is exposed in the next observation.
     */
    void noteAttack(boolean clickQueued, boolean opponentInHurtWindow) {
        if (Config.COMBAT_OBSERVATIONS) attackDuringIFramePulse = clickQueued && opponentInHurtWindow;
    }

    /** Appends the new features after all pre-existing summary blocks; existing summary indices do not move. */
    void fillSummary(float[] summary) {
        if (!Config.COMBAT_OBSERVATIONS || summary == null || summary.length < FEATURES) return;
        int offset = summary.length - FEATURES;
        System.arraycopy(features, 0, summary, offset, FEATURES);
        // This event pulse is delivered exactly once (the action is noted after the current observation is built).
        attackDuringIFramePulse = false;
    }

    private static float cosine(double ax, double ay, double bx, double by) {
        double an = Math.hypot(ax, ay), bn = Math.hypot(bx, by);
        if (an < 1e-6 || bn < 1e-6) return 0f;
        return c((ax * bx + ay * by) / (an * bn));
    }

    private static float c(double value) {
        if (!Double.isFinite(value)) return 0f;
        return (float) Math.max(-1.0, Math.min(1.0, value));
    }
}
