package com.rlpvp;

/**
 * Small, stateful hysteresis stage for noisy aim commands. It only damps low-amplitude reversals;
 * large intentional turns are passed through to the main adaptive filter. No randomness or allocations.
 */
final class AimJitterSuppressor {
    private double lastRaw;
    private int reversalCandidateSign;
    private int reversalCandidateTicks;

    double apply(double input, double axisScale, boolean precisionTrack) {
        if (!Double.isFinite(input)) input = 0.0;
        if (!Double.isFinite(axisScale) || axisScale <= 0.0) axisScale = 1.0;
        // During target tracking, treat a somewhat larger one-tick reversal as policy chatter.
        // Two consecutive samples still confirm an intentional reversal, so real target changes remain responsive.
        double smallTurn = axisScale * (precisionTrack ? 0.18 : 0.045);
        double lastSign = Math.signum(lastRaw), sign = Math.signum(input);
        if (sign != 0.0 && lastSign != 0.0 && sign != lastSign
                && Math.abs(input) < smallTurn && Math.abs(lastRaw) < smallTurn) {
            if (reversalCandidateSign == (int) sign) reversalCandidateTicks++;
            else { reversalCandidateSign = (int) sign; reversalCandidateTicks = 1; }
            // A single tiny sign flip is usually policy chatter; two consecutive samples confirm a true reversal.
            if (reversalCandidateTicks < 2) input *= 0.22;
        } else {
            reversalCandidateSign = 0;
            reversalCandidateTicks = 0;
        }
        lastRaw = input;
        return input;
    }

    void reset() { lastRaw = 0.0; reversalCandidateSign = 0; reversalCandidateTicks = 0; }
}
