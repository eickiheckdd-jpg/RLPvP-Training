package com.rlpvp.mixin;

import com.rlpvp.AttackHitRegistrationBridge;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Revalidates an AI click against the current gameplay ray before vanilla resolves its attack target. */
@Mixin(Minecraft.class)
abstract class AttackHitRegistrationMixin {
    @Inject(method = "startAttack", at = @At("HEAD"), cancellable = true, require = 1)
    private void rlpvp$refreshAiAttackTarget(CallbackInfoReturnable<Boolean> cir) {
        Minecraft client = (Minecraft) (Object) this;
        if (AttackHitRegistrationBridge.hasPendingRequest()
                && !AttackHitRegistrationBridge.refreshVanillaTarget(client)) {
            // A queued AI click whose target moved off the gameplay ray is cancelled. This prevents
            // vanilla from treating the stale MISS/block/other-entity result as a usable attack.
            cir.setReturnValue(false);
        }
    }
}
