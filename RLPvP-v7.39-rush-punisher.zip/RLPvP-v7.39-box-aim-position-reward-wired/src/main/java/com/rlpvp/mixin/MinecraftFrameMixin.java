package com.rlpvp.mixin;

import com.rlpvp.GlideReal;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Legacy opt-in path only (-Drlpvp.glideRealRotation=true): once per frame, before client ticks, move the player's authoritative yaw/pitch along
 * the glide curve. The default mode is display-only and does not need this hook. require = 0 keeps the mod compatible if this method mapping changes.
 */
@Mixin(Minecraft.class)
abstract class MinecraftFrameMixin {
    @Inject(method = "runTick", at = @At("HEAD"), require = 0)
    private void rlpvp$frame(boolean renderLevel, CallbackInfo ci) {
        GlideReal.frame(((Minecraft) (Object) this).player);
    }
}
