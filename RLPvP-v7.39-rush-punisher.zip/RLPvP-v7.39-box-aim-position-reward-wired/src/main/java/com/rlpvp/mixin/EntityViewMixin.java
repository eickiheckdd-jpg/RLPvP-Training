package com.rlpvp.mixin;

import com.rlpvp.GlideBridge;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Smooth-render the local AI-driven view without mutating authoritative player rotation on every frame.
 * LocalPlayer overrides Entity's view-rotation methods in current Minecraft, so the mixin must target LocalPlayer
 * directly; injecting only into Entity misses those overrides. Gameplay rotation, policy observations and attack
 * raycasts remain on the exact tick-end angles.
 */
@Mixin(LocalPlayer.class)
abstract class EntityViewMixin {
    @Inject(method = "getViewYRot", at = @At("RETURN"), cancellable = true, require = 0)
    private void rlpvp$glideYaw(float partialTick, CallbackInfoReturnable<Float> cir) {
        LocalPlayer player = (LocalPlayer) (Object) this;
        if (!player.isPassenger()) {
            Float r = GlideBridge.yaw(cir.getReturnValue(), partialTick);
            if (r != null) cir.setReturnValue(r);
        }
    }

    @Inject(method = "getViewXRot", at = @At("RETURN"), cancellable = true, require = 0)
    private void rlpvp$glidePitch(float partialTick, CallbackInfoReturnable<Float> cir) {
        LocalPlayer player = (LocalPlayer) (Object) this;
        if (!player.isPassenger()) {
            Float r = GlideBridge.pitch(cir.getReturnValue(), partialTick);
            if (r != null) cir.setReturnValue(r);
        }
    }
}
