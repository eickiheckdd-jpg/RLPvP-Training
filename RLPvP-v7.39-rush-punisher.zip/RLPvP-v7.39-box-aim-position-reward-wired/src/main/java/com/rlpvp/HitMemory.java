package com.rlpvp;

/**
 * Remembers the last few seconds of the fight and turns them into a fixed set of summary inputs: how hard and with what
 * kind of hit each side landed last, and rolling counts over the last Config.MEMORY_WINDOW ticks (4.8 s). It is plain
 * counting (no learning), so the network gets long-term context without any recurrent layer. No Minecraft classes.
 *
 * Hit types (decided when the swing is made, like vanilla decides them when the hit lands):
 *   CRIT   full charge, falling, not sprinting (+50 % damage)        SPRINT  full charge while sprinting (extra knockback)
 *   SWEEP  full charge on the ground, not sprinting (sweep-attack conditions; hits only the target in a 1v1)
 *   WEAK   weapon not fully charged (reduced damage, no crit / sprint / sweep)
 */
final class HitMemory {
    static final int CRIT = 1, SPRINT = 2, SWEEP = 4, WEAK = 8;

    static int typeMask(boolean fullCharge, boolean fallingCrit, boolean sprinting, boolean onGround) {
        if (!fullCharge) return WEAK;
        int m = 0;
        if (fallingCrit) m |= CRIT;
        if (sprinting) m |= SPRINT;
        if (onGround && !sprinting) m |= SWEEP;
        return m;
    }

    private static final int W = Config.MEMORY_WINDOW;

    // per-tick slots of the sliding window
    private final float[] sDealt = new float[W], sTaken = new float[W];
    private final int[] sMyHit = new int[W];       // -1 = no hit that tick, else the type mask
    private final boolean[] sTheirHit = new boolean[W], sEnemySwing = new boolean[W], sMySwing = new boolean[W], sMyWhiff = new boolean[W];
    private int head = -1;
    private int filled;

    // running sums over the window
    private float sumDealt, sumTaken;
    private int myHits, theirHits, myCrits, mySprints, myWeaks, enemySwings, mySwings, myWhiffs;

    // last events and combos
    private float lastDealt, lastTaken;
    private int lastMask, lastTakenMask, myCombo, theirCombo;
    private int pendingMask = -1, pendingAge = 99;

    HitMemory() {
        reset();
    }

    void reset() {
        java.util.Arrays.fill(sDealt, 0f);
        java.util.Arrays.fill(sTaken, 0f);
        java.util.Arrays.fill(sMyHit, -1);
        java.util.Arrays.fill(sTheirHit, false);
        java.util.Arrays.fill(sEnemySwing, false);
        java.util.Arrays.fill(sMySwing, false);
        java.util.Arrays.fill(sMyWhiff, false);
        head = -1;
        filled = 0;
        sumDealt = sumTaken = 0f;
        myHits = theirHits = myCrits = mySprints = myWeaks = enemySwings = mySwings = myWhiffs = 0;
        lastDealt = lastTaken = 0f;
        lastMask = lastTakenMask = 0;
        myCombo = theirCombo = 0;
        pendingMask = -1;
        pendingAge = 99;
    }

    private void advance() {
        head = (head + 1) % W;
        if (filled == W) { // the slot being reused falls out of the window
            sumDealt -= sDealt[head];
            sumTaken -= sTaken[head];
            int h = sMyHit[head];
            if (h >= 0) {
                myHits--;
                if ((h & CRIT) != 0) myCrits--;
                if ((h & SPRINT) != 0) mySprints--;
                if ((h & WEAK) != 0) myWeaks--;
            }
            if (sTheirHit[head]) theirHits--;
            if (sEnemySwing[head]) enemySwings--;
            if (sMySwing[head]) mySwings--;
            if (sMyWhiff[head]) myWhiffs--;
        } else {
            filled++;
        }
        sDealt[head] = 0f;
        sTaken[head] = 0f;
        sMyHit[head] = -1;
        sTheirHit[head] = false;
        sEnemySwing[head] = false;
        sMySwing[head] = false;
        sMyWhiff[head] = false;
    }

    /**
     * One call per tick, before the observation is built.
     *
     * @param dealt           HP I really took off the enemy this tick
     * @param taken           HP the enemy took off me this tick
     * @param enemySwingStart the enemy started a swing this tick
     * @param takenMask       CRIT / SPRINT bits describing the enemy's state when it hit me (inferred from what I could see)
     */
    void tick(float dealt, float taken, boolean enemySwingStart, int takenMask) {
        advance();
        if (dealt > 0f) {
            int m = (pendingMask >= 0 && pendingAge <= Config.HIT_CREDIT_TICKS) ? pendingMask : 0;
            pendingMask = -1;
            sDealt[head] = dealt;
            sumDealt += dealt;
            sMyHit[head] = m;
            myHits++;
            if ((m & CRIT) != 0) myCrits++;
            if ((m & SPRINT) != 0) mySprints++;
            if ((m & WEAK) != 0) myWeaks++;
            lastDealt = dealt;
            lastMask = m;
            myCombo++;
            theirCombo = 0;
        }
        if (taken > 0f) {
            sTaken[head] = taken;
            sumTaken += taken;
            sTheirHit[head] = true;
            theirHits++;
            lastTaken = taken;
            lastTakenMask = takenMask;
            theirCombo++;
            myCombo = 0;
        }
        if (enemySwingStart) {
            sEnemySwing[head] = true;
            enemySwings++;
        }
        if (pendingAge < 99) pendingAge++;
    }

    /** Call when I swing (after tick()). {@code onTarget}: the crosshair was on the enemy, so a hit is expected. */
    void swing(int typeMask, boolean onTarget) {
        if (head < 0) return;
        sMySwing[head] = true;
        mySwings++;
        if (onTarget) {
            pendingMask = typeMask;
            pendingAge = 0;
        } else {
            sMyWhiff[head] = true;
            myWhiffs++;
        }
    }

    int recentMyHits() { return myHits; }
    int recentMyWhiffs() { return myWhiffs; }
    int recentMyCriticals() { return myCrits; }
    int recentMySprintHits() { return mySprints; }
    int recentMySwings() { return mySwings; }
    float recentDamageDifferential() { return sumDealt - sumTaken; }

    /** Writes the Config.SUMMARY_BASE summary inputs into {@code out}. */
    void fill(float[] out) {
        int i = 0;
        out[i++] = c(lastDealt / 10f);
        out[i++] = (lastMask & CRIT) != 0 ? 1f : 0f;
        out[i++] = (lastMask & SPRINT) != 0 ? 1f : 0f;
        out[i++] = (lastMask & SWEEP) != 0 ? 1f : 0f;
        out[i++] = (lastMask & WEAK) != 0 ? 1f : 0f;
        out[i++] = c(lastTaken / 10f);
        out[i++] = (lastTakenMask & CRIT) != 0 ? 1f : 0f;
        out[i++] = (lastTakenMask & SPRINT) != 0 ? 1f : 0f;
        out[i++] = c(sumDealt / 20f);
        out[i++] = c(sumTaken / 20f);
        out[i++] = c(myHits / 6f);
        out[i++] = c(theirHits / 6f);
        out[i++] = c(myCrits / 3f);
        out[i++] = c(mySprints / 3f);
        out[i++] = c(myWeaks / 3f);
        out[i++] = c(enemySwings / 6f);
        out[i++] = c(mySwings / 8f);
        out[i++] = c(myWhiffs / 6f);
        out[i++] = c(myCombo / 4f);
        out[i++] = c(theirCombo / 4f);
    }

    private static float c(float v) {
        return Math.max(-1f, Math.min(1f, v));
    }
}
