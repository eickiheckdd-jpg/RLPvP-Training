package com.rlpvp;

import java.util.Locale;

/**
 * Measurement-only audit of technique choice. It separates a mechanically plausible
 * opportunity from the policy selecting an attack, an actual swing, a client-side target
 * selection, and HP-confirmed damage. It never changes actions, masks, rewards, or PPO state.
 *
 * A window is opened only when the existing attack mask allows attacking, line of sight is
 * clear, the target hitbox is inside normal reach, and charge is strictly above the same
 * FULL_CHARGE threshold used by the simulator's server-side full-strength check. Crit windows
 * additionally require the observation's falling/not-sprinting posture; sprint windows require
 * the player to be sprinting. Other vanilla crit restrictions are not represented by every
 * caller, so these are deliberately named opportunity windows rather than a guarantee that the
 * server will accept the technique.
 *
 * Completed windows are assigned to the audit interval in which they close. Windows still open
 * at an episode boundary are marked censored, not counted as unselected. This avoids falsely
 * treating episode truncation as a policy decision.
 */
final class TechniqueOpportunityAudit {
    private static final int CRIT = 0, SPRINT = 1, OTHER = 2, TYPES = 3;
    private static final String[] NAMES = {"crit", "sprint", "other"};

    private static final class Window {
        boolean open;
        boolean selected;
        long swingAttempts, targetSelected;
        double distance, yawAbs, pitchAbs;
    }

    private static final class Counts {
        long opportunities, selected, notSelected, censored;
        long opportunityAttempts, opportunityTargetSelected;
        long attempts, targetSelected, confirmed, serverResolved, clientCredited, ambiguousLabels;
        double damageHp;
        double distanceSum, yawSum, pitchSum;

        void merge(Counts x) {
            opportunities += x.opportunities; selected += x.selected; notSelected += x.notSelected;
            censored += x.censored; opportunityAttempts += x.opportunityAttempts;
            opportunityTargetSelected += x.opportunityTargetSelected;
            attempts += x.attempts; targetSelected += x.targetSelected;
            confirmed += x.confirmed; serverResolved += x.serverResolved; clientCredited += x.clientCredited;
            ambiguousLabels += x.ambiguousLabels; damageHp += x.damageHp;
            distanceSum += x.distanceSum; yawSum += x.yawSum; pitchSum += x.pitchSum;
        }

        void clear() {
            opportunities = selected = notSelected = censored = 0;
            opportunityAttempts = opportunityTargetSelected = attempts = targetSelected = confirmed = 0;
            serverResolved = clientCredited = ambiguousLabels = 0;
            damageHp = distanceSum = yawSum = pitchSum = 0.0;
        }
    }

    private final Window[] windows = {new Window(), new Window()};
    private final Counts[] counts = {new Counts(), new Counts(), new Counts()};

    /**
     * Observe one state/action decision. The supplied state is the pre-action state; attackSelected
     * is the policy's sampled attack head after the normal action mask has been applied.
     */
    void observeDecision(boolean attackUnlocked, boolean lineOfSight, boolean targetInReach,
                         double attackCharge, boolean canCritPosture, boolean sprinting,
                         double distance, double yawErrorDeg, double pitchErrorDeg,
                         boolean attackSelected) {
        boolean common = attackUnlocked && lineOfSight && targetInReach
            && Double.isFinite(attackCharge) && attackCharge > Config.FULL_CHARGE;
        update(CRIT, common && canCritPosture && !sprinting,
            attackSelected, distance, yawErrorDeg, pitchErrorDeg);
        update(SPRINT, common && sprinting,
            attackSelected, distance, yawErrorDeg, pitchErrorDeg);
    }

    private void update(int type, boolean available, boolean attackSelected,
                        double distance, double yawErrorDeg, double pitchErrorDeg) {
        Window w = windows[type];
        if (available) {
            if (!w.open) {
                w.open = true;
                w.selected = false;
                w.swingAttempts = w.targetSelected = 0;
                w.distance = finiteNonnegative(distance);
                w.yawAbs = finiteAbs(yawErrorDeg);
                w.pitchAbs = finiteAbs(pitchErrorDeg);
            }
            if (attackSelected) w.selected = true;
        } else if (w.open) {
            close(type, false);
        }
    }

    private void close(int type, boolean censored) {
        Window w = windows[type];
        if (!w.open) return;
        Counts c = counts[type];
        c.opportunities++;
        if (w.selected) c.selected++;
        if (censored) c.censored++;
        else if (!w.selected) c.notSelected++;
        c.opportunityAttempts += w.swingAttempts;
        c.opportunityTargetSelected += w.targetSelected;
        c.distanceSum += w.distance;
        c.yawSum += w.yawAbs;
        c.pitchSum += w.pitchAbs;
        w.open = false;
        w.selected = false;
    }

    /** Record a real attempted swing; typeMask is the pre-hit Minecraft-style swing label. */
    void recordSwing(int typeMask, boolean targetSelected) {
        boolean critical = (typeMask & HitMemory.CRIT) != 0;
        boolean sprint = (typeMask & HitMemory.SPRINT) != 0;
        int type;
        if (critical && sprint) {
            // CRIT and sprint-knockback are mutually exclusive in the supported mechanics.
            // Do not silently prefer one label if a caller ever supplies an impossible combination.
            counts[OTHER].ambiguousLabels++;
            type = OTHER;
        } else {
            type = critical ? CRIT : sprint ? SPRINT : OTHER;
        }
        Counts c = counts[type];
        c.attempts++;
        if (targetSelected) c.targetSelected++;
        // Attribute the swing to the active opportunity window as well as the global type
        // bucket. This avoids confusing an out-of-range/blocked typed swing with a conversion
        // attempt made while a valid opportunity was actually open.
        if (type <= SPRINT && windows[type].open) {
            windows[type].swingAttempts++;
            if (targetSelected) windows[type].targetSelected++;
        }
    }

    /** Record a successful hit using authoritative server resolution or client-credited HP telemetry. */
    void recordConfirmedHit(boolean critical, boolean sprintKnockback, double damageHp, boolean serverResolved) {
        int type;
        if (critical && sprintKnockback) {
            // These classifications are mutually exclusive in the supported combat rules.
            // Preserve the event in an explicit diagnostic bucket rather than double counting it.
            counts[OTHER].ambiguousLabels++;
            type = OTHER;
        } else {
            type = critical ? CRIT : sprintKnockback ? SPRINT : OTHER;
        }
        Counts c = counts[type];
        c.confirmed++;
        if (serverResolved) c.serverResolved++; else c.clientCredited++;
        if (Double.isFinite(damageHp) && damageHp > 0.0) c.damageHp += damageHp;
    }

    /** Close episode-local windows without treating an incomplete opportunity as a missed choice. */
    void finishEpisode() {
        close(CRIT, true);
        close(SPRINT, true);
    }

    void mergeWindow(TechniqueOpportunityAudit other) {
        if (other == null) return;
        for (int i = 0; i < TYPES; i++) counts[i].merge(other.counts[i]);
    }

    /** Clears emitted counters but deliberately preserves windows spanning a log interval. */
    void clearWindow() {
        for (Counts c : counts) c.clear();
    }

    static String csvHeader() {
        StringBuilder b = new StringBuilder("ticks,stage");
        for (String n : NAMES) {
            b.append(',').append(n).append("_opportunities,")
                .append(n).append("_selected,").append(n).append("_notSelected,").append(n).append("_censored,")
                .append(n).append("_opportunitySwingAttempts,").append(n).append("_opportunityTargetSelected,")
                .append(n).append("_swingAttempts,").append(n).append("_targetSelected,").append(n).append("_confirmedHits,")
                .append(n).append("_serverResolvedHits,").append(n).append("_clientCreditedHits,").append(n).append("_damageHp,").append(n).append("_selectionRate,").append(n).append("_targetRate,")
                .append(n).append("_hitRate,").append(n).append("_meanOpportunityDistance,")
                .append(n).append("_meanOpportunityYawError,").append(n).append("_meanOpportunityPitchError,")
                .append(n).append("_ambiguousLabels");
        }
        return b.toString();
    }

    String csvRow(long ticks, int stage) {
        StringBuilder b = new StringBuilder(String.format(Locale.ROOT, "%d,%d", ticks, stage));
        for (Counts c : counts) {
            b.append(String.format(Locale.ROOT,
                ",%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%.4f,%.5f,%.5f,%.5f,%.4f,%.4f,%.4f,%d",
                c.opportunities, c.selected, c.notSelected, c.censored,
                c.opportunityAttempts, c.opportunityTargetSelected,
                c.attempts, c.targetSelected, c.confirmed, c.serverResolved, c.clientCredited, c.damageHp,
                c.selected / (double) Math.max(1L, c.opportunities),
                c.targetSelected / (double) Math.max(1L, c.attempts),
                c.confirmed / (double) Math.max(1L, c.attempts),
                c.distanceSum / Math.max(1L, c.opportunities),
                c.yawSum / Math.max(1L, c.opportunities),
                c.pitchSum / Math.max(1L, c.opportunities), c.ambiguousLabels));
        }
        return b.toString();
    }

    String summary() {
        StringBuilder b = new StringBuilder("tech-choice");
        for (int i = 0; i < TYPES; i++) {
            Counts c = counts[i];
            if (c.opportunities == 0 && c.attempts == 0 && c.confirmed == 0) continue;
            b.append(String.format(Locale.ROOT,
                " %s opp=%d selected=%d notSelected=%d censored=%d oppSwings=%d/%d swings=%d ray=%d confirmed=%d (server=%d/client=%d) hp=%.2f",
                NAMES[i], c.opportunities, c.selected, c.notSelected, c.censored,
                c.opportunityAttempts, c.opportunityTargetSelected, c.attempts, c.targetSelected,
                c.confirmed, c.serverResolved, c.clientCredited, c.damageHp));
        }
        return b.toString();
    }

    private static double finiteNonnegative(double v) { return Double.isFinite(v) ? Math.max(0.0, v) : 0.0; }
    private static double finiteAbs(double v) { return Double.isFinite(v) ? Math.abs(v) : 0.0; }
}
