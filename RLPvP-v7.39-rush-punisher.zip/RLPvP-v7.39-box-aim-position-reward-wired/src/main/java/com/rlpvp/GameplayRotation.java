package com.rlpvp;

/**
 * The gameplay camera controller: the ONE implementation of "policy action -> actual yaw / pitch change", shared by the live mod
 * (ActionApplier), the self-play bot (BotBrain) and the simulator (PvpSim). Pure Java, primitives only, no allocation per tick.
 *
 *   raw policy output a (hand effort, relative, NOT a target angle)
 *     -> sanitize (NaN/inf -> 0, clamp [-1,1])  -> CameraMap response curve  -> x axis scale (deg/tick of hand effort)
 *     -> [optional] AimBrake: predictive braking from the observed target error and the TRUE camera velocity/acceleration
 *     -> CameraDynamics: force - drag, acceleration limit, jerk limit, 4 sub-steps  -> relative camera displacement (deg)
 *     -> pitch clamped to +-90 (hard stop zeroes the pitch velocity), yaw wrapped to [-180, 180).
 * Yaw and pitch have independent controllers and independent limits (YAW_SCALE / PITCH_SCALE). No rendering code is involved: the
 * result is the authoritative rotation used for ray casts, attacks and observations.
 */
final class GameplayRotation {
    final CameraDynamics yaw = new CameraDynamics().withShakeSeed(1), pitch = new CameraDynamics().withShakeSeed(2);

    /** Smoothstep ease-in of a push that starts from rest (Config.AIM_EASE_TICKS): slow start, then full command. One per axis. */
    private static final class Ease {
        int age, dir; boolean skip;
        void reset() { age = 0; dir = 0; skip = false; }
        double apply(double cmd, double scale, double vel) {
            int n = Config.AIM_EASE_TICKS;
            double a = scale > 0 ? Math.abs(cmd) / scale : 0.0;
            if (n <= 0 || a < Config.AIM_EASE_MIN_FRAC) { age = 0; dir = 0; return cmd; } // hand at rest, or a small tracking correction: never slowed
            int sgn = cmd > 0 ? 1 : -1;
            if (sgn != dir) { dir = sgn; age = 0; skip = vel * sgn > Config.AIM_EASE_REST_FRAC * scale; } // a new push; a mouse already moving that way is not slowed
            age++;
            if (skip || age >= n) return cmd;
            double x = age / (double) n;
            return cmd * x * x * (3.0 - 2.0 * x);                                 // smoothstep
        }
    }
    private final Ease easeYaw = new Ease(), easePitch = new Ease();
    private final AimInputFilter inputYaw = new AimInputFilter(), inputPitch = new AimInputFilter();
    private double remYaw, remPitch;   // sub-count remainders of the legal mouse step
    private double mouseDegPerCount = Config.MOUSE_DEG_PER_COUNT;

    /** Set from the live client's sensitivity so each applied turn corresponds to a legal integer mouse count. */
    void setMouseSensitivity(double sensitivity) {
        if (!Double.isFinite(sensitivity)) return;
        double s = Math.max(0.0, Math.min(1.0, sensitivity));
        // Vanilla's mouse response: 1.2 * (0.6 * sensitivity + 0.2)^3 degrees per mouse count.
        double q = 1.2 * Math.pow(0.6 * s + 0.2, 3.0);
        if (Double.isFinite(q) && q > 1e-6) mouseDegPerCount = q;
    }

    /** Quantize to whole mouse counts while carrying sub-count remainder forward. */
    private double legalStep(double turn, int idx) {
        double q = mouseDegPerCount;
        if (!Config.MOUSE_QUANTIZE || !(q > 0.0)) return turn;
        double prior = idx == 0 ? remYaw : remPitch;
        double acc = prior + turn;
        double out = Math.rint(acc / q) * q;
        double remainder = acc - out;
        if (idx == 0) remYaw = remainder; else remPitch = remainder;
        return out;
    }

    /** Outputs of the last step(): angles after the update and the degrees actually turned (pitch after the clamp). */
    float newYaw, newPitch, dYaw, dPitch;

    // target angular speed estimate per axis (deg/tick): d(target) = d(error) + own turn of the previous tick; smoothed, clamped, reset with the fight
    private boolean haveErr;
    private double prevErrYaw, prevErrPitch, vtYaw, vtPitch;
    private static final double VT_SMOOTH = 0.5;

    private static double estimate(double vt, double err, double prevErr, double ownTurn, double scale) {
        double d = err - prevErr;
        if (!Double.isFinite(d) || Math.abs(d) > 90.0) return 0.0; // wrap / target switch: no estimate
        double raw = Math.max(-0.25 * scale, Math.min(0.25 * scale, d + ownTurn));
        return vt + VT_SMOOTH * (raw - vt);
    }

    /** New fight / AI activated / deactivated / respawn: the mouse starts at rest, no stored velocity or acceleration. */
    void reset() { yaw.reset(); pitch.reset(); dYaw = dPitch = 0f; haveErr = false; vtYaw = vtPitch = 0.0; easeYaw.reset(); easePitch.reset(); inputYaw.reset(); inputPitch.reset(); remYaw = remPitch = 0.0; }

    /** Observation missing or stale: no new hand effort; drag and the jerk limit bring the mouse to rest smoothly (no jump, no freeze). */
    void hold(float curYaw, float curPitch) { step(0f, 0f, curYaw, curPitch, 0.0, 0.0, false, false, false); }

    static float sane(float a) { return Float.isFinite(a) ? Math.max(-1f, Math.min(1f, a)) : 0f; }

    static float wrapDegrees(float d) {
        d %= 360f;
        if (d >= 180f) d -= 360f;
        if (d < -180f) d += 360f;
        return d;
    }

    /**
     * Shortest signed yaw difference to - from, in [-180, 180). Use this for errors and target deltas only.
     * Do not wrap the accumulated absolute player yaw: vanilla sends/stores a continuous angle and accepts values
     * outside [-180, 180] (including values outside [-360, 360]).
     */
    static float shortestYawDelta(float from, float to) { return wrapDegrees(to - from); }

    /**
     * @param rawYaw,rawPitch policy camera outputs (raw, before CameraMap)
     * @param curYaw,curPitch current authoritative angles (deg)
     * @param errYaw,errPitch observed error to the enemy in degrees (positive = enemy is in the positive turning direction); used by AimBrake only
     * @param errKnown        false when there is no valid target/observation: no braking envelope, the policy's command is used as it is
     * @param pitchFree       false while the pitch is locked/ignored by the curriculum: no pitch braking
     * @param brake           AimBrake on/off (Config.AIM_BRAKE)
     */
    GameplayRotation step(float rawYaw, float rawPitch, float curYaw, float curPitch, double errYaw, double errPitch, boolean errKnown, boolean pitchFree, boolean brake) {
        return stepEffort(CameraMap.apply(sane(rawYaw)) * Config.YAW_SCALE, CameraMap.apply(sane(rawPitch)) * Config.PITCH_SCALE,
                curYaw, curPitch, errYaw, errPitch, errKnown, pitchFree, brake);
    }

    /** Same as step() but takes hand effort in deg/tick (after CameraMap), used by the simulator which adds its own sensitivity / noise first. */
    GameplayRotation stepEffort(double cmdYaw, double cmdPitch, float curYaw, float curPitch, double errYaw, double errPitch, boolean errKnown, boolean pitchFree, boolean brake) {
        // Always filter the command, including in the precision zone. Previously the near-target
        // bypass sent noisy policy corrections straight to the camera, which is the exact situation
        // where tracking jitter is most visible. The precision mode uses a lighter, lower-latency filter.
        boolean precisionTrack = brake && errKnown
            && Math.max(Math.abs(errYaw), pitchFree ? Math.abs(errPitch) : 0.0) <= Config.AIM_FILTER_PRECISION_ZONE_DEG;
        cmdYaw = inputYaw.step(cmdYaw, Config.YAW_SCALE, precisionTrack);
        cmdPitch = inputPitch.step(cmdPitch, Config.PITCH_SCALE, precisionTrack);
        cmdYaw = easeYaw.apply(cmdYaw, Config.YAW_SCALE, yaw.vel());
        cmdPitch = easePitch.apply(cmdPitch, Config.PITCH_SCALE, pitch.vel());
        if (brake && errKnown) {
            if (haveErr) { // dYaw / dPitch still hold last tick's applied turn here
                vtYaw = estimate(vtYaw, errYaw, prevErrYaw, dYaw, Config.YAW_SCALE);
                vtPitch = pitchFree ? estimate(vtPitch, errPitch, prevErrPitch, dPitch, Config.PITCH_SCALE) : 0.0;
            }
            prevErrYaw = errYaw; prevErrPitch = errPitch; haveErr = true;
            cmdYaw = AimBrake.limit(cmdYaw, yaw, errYaw, Config.YAW_SCALE, vtYaw);
            if (pitchFree) cmdPitch = AimBrake.limit(cmdPitch, pitch, errPitch, Config.PITCH_SCALE, vtPitch);
        } else {
            haveErr = false; vtYaw = vtPitch = 0.0;
        }
        float dy = (float) legalStep(yaw.step(cmdYaw, Config.YAW_SCALE), 0);
        float dp = (float) legalStep(pitch.step(cmdPitch, Config.PITCH_SCALE), 1);
        float np = Math.max(-90f, Math.min(90f, curPitch + dp));
        if (np != curPitch + dp) pitch.halt(); // hit the pitch stop: no wind-up against it
        dYaw = dy;
        dPitch = np - curPitch;
        newPitch = np;
        // Keep absolute yaw continuous. Wrapping this value at +/-180 or 360 makes the next absolute rotation
        // packet look like a ~360-degree snap even though the intended mouse turn was only `dy`.
        // Minecraft's vanilla yaw is not clamped to a 360-degree interval.
        newYaw = curYaw + dy;
        return this;
    }

    double filteredYawCommand() { return inputYaw.output(); }
    double filteredPitchCommand() { return inputPitch.output(); }
    double requestedYawCommand() { return inputYaw.lastInput(); }
    double requestedPitchCommand() { return inputPitch.lastInput(); }
    double inputFilterAlpha() { return Math.min(inputYaw.alpha(), inputPitch.alpha()); }
}
