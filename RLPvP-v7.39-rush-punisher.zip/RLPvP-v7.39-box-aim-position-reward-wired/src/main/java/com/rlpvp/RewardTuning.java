package com.rlpvp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.HashMap;
import java.util.Map;

/** Sidecar reward multipliers. Defaults are 1.0, preserving the existing reward function exactly. */
final class RewardTuning {
    // Reward tuning is immutable for a training process. Parse the properties once instead of
    // doing Properties lookup + String.trim + Double.parseDouble on every simulated tick.
    private static final Map<String, Double> VALUES = load();
    private RewardTuning() {}
    static double get(String key) { return VALUES.getOrDefault(key, 1.0); }
    static String source() { return System.getProperty("rlpvp.rewards.path", "config/rlpvp-rewards.properties"); }
    private static Map<String, Double> load() {
        Properties p = new Properties();
        Path path = Path.of(source());
        if (Files.isRegularFile(path)) try (var in = Files.newInputStream(path)) { p.load(in); }
        catch (IOException ignored) { /* defaults remain active */ }
        Map<String, Double> parsed = new HashMap<>();
        for (String key : p.stringPropertyNames()) {
            String raw = p.getProperty(key, "1.0");
            double value;
            try { value = Math.max(0.0, Math.min(10.0, Double.parseDouble(raw.trim()))); }
            catch (RuntimeException ex) { value = 1.0; }
            parsed.put(key, value);
        }
        return Map.copyOf(parsed);
    }
}
