package com.rlpvp;

/** High-level combat intent selection from the interpreted state and adaptive opponent/event memory. */
final class TacticalDecisionEngine {
    enum Intent { ENGAGE, PURSUE, PUNISH, DEFEND, REPOSITION, COMBO_FOLLOWUP, BAIT, DISENGAGE }
    static final class Decision {
        final Intent intent;
        final double confidence;
        final double[] scores;
        Decision(Intent intent, double confidence, double[] scores) { this.intent = intent; this.confidence = confidence; this.scores = scores; }
        double score(Intent i) { return scores[i.ordinal()]; }
    }

    Decision choose(SituationalStateInterpreter.State s, OpponentBehaviorModel.Profile p,
                    EventDrivenCombatMemory.Snapshot memory, double predictedThreat) {
        double[] v = new double[Intent.values().length];
        double confidence = p.confidence();
        boolean far = s.distance > 3.0;
        boolean close = s.distance < 2.0;
        boolean clearAim = s.aimedEnough();
        boolean urgentThreat = s.incomingThreat || predictedThreat > 0.58;

        v[Intent.ENGAGE.ordinal()] = far ? 0.45 + Math.min(0.25, (s.distance - 3.0) * 0.08) : 0.18;
        v[Intent.PURSUE.ordinal()] = far ? 0.48 + p.retreatRate * 0.20 * confidence : 0.05;
        v[Intent.PUNISH.ordinal()] = (s.opponentRecovering && s.ownCharge > 0.55f && s.distance < 4.2f ? 0.66 : 0.0)
            + (s.attackOpportunity ? 0.20 : 0.0);
        v[Intent.DEFEND.ordinal()] = urgentThreat ? 0.50 + (s.meInEnemyReach > 0.5f ? 0.24 : 0.0) : 0.08;
        v[Intent.REPOSITION.ordinal()] = (!clearAim ? 0.30 : 0.0) + (s.lineOfSight < 0.5f ? 0.38 : 0.0)
            + (close ? 0.18 : 0.0) + (Math.abs(s.enemySideVelocity) > 0.2f ? 0.10 : 0.0);
        v[Intent.COMBO_FOLLOWUP.ordinal()] = s.followupWindow ? 0.64 + (s.distance < 3.8f ? 0.14 : 0.0) : 0.0;
        v[Intent.BAIT.ordinal()] = (!urgentThreat && !s.opponentRecovering && s.distance >= 2.4f && s.distance <= 4.0f
            && p.attackRate < 0.10 && confidence > 0.30 ? 0.35 + confidence * 0.10 : 0.0);
        v[Intent.DISENGAGE.ordinal()] = (s.lowHealthDisadvantage && s.ownHealth < 0.45f ? 0.70 : 0.0)
            + (s.ownHurt > 0.65f && s.distance < 2.4f ? 0.28 : 0.0)
            + (s.boundaryProximity > 0.8f ? 0.10 : 0.0);

        // High-confidence local threat/recovery events dominate long-term habit estimates.
        if (urgentThreat && s.ownHurt > 0.55f && s.ownCharge < 0.5f) v[Intent.DEFEND.ordinal()] += 0.14;
        if (s.followupWindow && !urgentThreat) v[Intent.COMBO_FOLLOWUP.ordinal()] += 0.08;
        if (s.boundaryProximity > 0.78f) v[Intent.REPOSITION.ordinal()] += 0.12;

        int best = 0; double bestV = -Double.MAX_VALUE, second = -Double.MAX_VALUE;
        for (int i = 0; i < v.length; i++) {
            if (v[i] > bestV) { second = bestV; bestV = v[i]; best = i; }
            else if (v[i] > second) second = v[i];
        }
        double margin = bestV - Math.max(0.0, second);
        double certainty = Math.max(0.0, Math.min(1.0, 0.45 * margin + 0.45 * (urgentThreat || s.followupWindow || s.opponentRecovering ? 1.0 : confidence)));
        return new Decision(Intent.values()[best], certainty, v);
    }
}
