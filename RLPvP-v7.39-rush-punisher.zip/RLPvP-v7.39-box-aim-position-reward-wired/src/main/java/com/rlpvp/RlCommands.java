package com.rlpvp;

/**
 * Client-side "/rl" commands. They are intercepted before the chat command is sent, so the
 * server never sees them and you do not need op or any server plugin.
 */
final class RlCommands {
    private RlCommands() {}

    private static final String HELP =
        "/rl start [fresh] | play | stop | save | load | status | target <name|auto> | target select <on|off> | hud [on|off|auto|combat|training|diag|full|mini|flip|opacity|toggle] | stage <1-8|auto>";

    /** @return true if the command was an /rl command (and was handled here). */
    static boolean intercept(String command) {
        String[] a = command.trim().split("\\s+");
        if (a.length == 0 || !a[0].equalsIgnoreCase("rl")) return false;

        Trainer t = RlPvpClient.TRAINER;
        String sub = a.length > 1 ? a[1].toLowerCase() : "help";
        switch (sub) {
            case "start" -> Trainer.say(t.start(a.length > 2 && a[2].equalsIgnoreCase("fresh")));
            case "play" -> Trainer.say(t.play());
            case "stop" -> Trainer.say(t.stop());
            case "save" -> Trainer.say(t.save());
            case "load" -> Trainer.say(t.load());
            case "status" -> Trainer.say(t.status());
            case "target" -> {
                if (a.length >= 3 && a[2].equalsIgnoreCase("select")) {
                    if (a.length < 4 || !(a[3].equalsIgnoreCase("on") || a[3].equalsIgnoreCase("off"))) {
                        Trainer.say("Usage: /rl target select <on|off>");
                    } else if (a[3].equalsIgnoreCase("on")) {
                        Trainer.say(t.targetSelectOn());
                    } else {
                        Trainer.say(t.targetSelectOff());
                    }
                } else if (a.length < 3) {
                    Trainer.say("Usage: /rl target <player name | auto> OR /rl target select <on|off>");
                } else if (a[2].equalsIgnoreCase("auto")) {
                    t.targetName = null;
                    Trainer.say("Opponent: nearest other player (auto).");
                } else {
                    t.targetName = a[2];
                    Trainer.say("Opponent locked to player " + a[2] + ".");
                }
            }
            case "hud" -> {
                String msg = RlHud.command(a.length > 2 ? a[2] : null, a.length > 3 ? a[3] : null);
                Trainer.say(msg != null ? msg : RlHud.USAGE);
            }
            case "stage" -> {
                if (a.length < 3) {
                    Trainer.say("Usage: /rl stage <1-8|auto>. Now: " + t.curriculum.describe());
                } else if (a[2].equalsIgnoreCase("auto")) {
                    t.curriculum.force(0);
                    Trainer.say("Curriculum stage is automatic again (by learned ticks).");
                } else {
                    int n;
                    try {
                        n = Integer.parseInt(a[2]);
                    } catch (NumberFormatException e) {
                        n = -1;
                    }
                    if (n < 1 || n > Curriculum.STAGES) {
                        Trainer.say("Stage must be 1 to " + Curriculum.STAGES + " or auto.");
                    } else {
                        t.curriculum.force(n);
                        Trainer.say("Stage forced to " + n + " (locks and opponent follow it). Use /rl stage auto to go back.");
                    }
                }
            }
            default -> Trainer.say(HELP);
        }
        return true;
    }
}