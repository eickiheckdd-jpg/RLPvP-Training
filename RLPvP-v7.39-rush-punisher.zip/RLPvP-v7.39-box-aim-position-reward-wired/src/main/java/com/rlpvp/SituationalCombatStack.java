package com.rlpvp;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Random;

/** Orchestrates perception, opponent/event memory, tactical intent, counterfactual scoring and reactive execution. */
final class SituationalCombatStack {
    private static final int MAGIC = 0x53495431; // SIT1
    private final SituationalStateInterpreter interpreter = new SituationalStateInterpreter();
    private final OpponentBehaviorModel opponent = new OpponentBehaviorModel();
    private final EventDrivenCombatMemory events = new EventDrivenCombatMemory();
    private final TacticalDecisionEngine tactics = new TacticalDecisionEngine();
    private final CounterfactualActionEvaluator evaluator = new CounterfactualActionEvaluator();
    private final ReactiveCombatController reactive = new ReactiveCombatController();
    private final CombatIntelligenceSuite intelligence = new CombatIntelligenceSuite();

    private SituationalStateInterpreter.State state;
    private TacticalDecisionEngine.Decision decision;
    private OpponentBehaviorModel.Profile profile = new OpponentBehaviorModel.Profile();
    private EventDrivenCombatMemory.Snapshot eventSnapshot;
    private float boundaryProximity = Float.NaN, inwardForward, inwardRight;
    private long decisionTicks, interventionTicks, rejectedAttacks, correctedSprints, boundaryCorrections;
    private TacticalDecisionEngine.Intent lastIntent = TacticalDecisionEngine.Intent.ENGAGE;
    private double lastConfidence;
    private boolean tickReady;

    void beginEpisode(String opponentKey) {
        opponent.beginEpisode(opponentKey);
        events.beginEpisode(); intelligence.reset(); state = null; decision = null; tickReady = false;
        lastIntent = TacticalDecisionEngine.Intent.ENGAGE;
        lastConfidence = 0.0;
    }

    void setBoundaryContext(float proximity, float inwardForward, float inwardRight) {
        boundaryProximity = Float.isFinite(proximity) ? Math.max(0f, Math.min(1f, proximity)) : Float.NaN;
        this.inwardForward = Float.isFinite(inwardForward) ? Math.max(-1f, Math.min(1f, inwardForward)) : 0f;
        this.inwardRight = Float.isFinite(inwardRight) ? Math.max(-1f, Math.min(1f, inwardRight)) : 0f;
    }

    /** Update once per play tick, before candidate scoring. */
    void beginTick(float[] obs) {
        events.observeTransition(obs);
        float bp = Float.isFinite(boundaryProximity) ? boundaryProximity : 0f;
        state = interpreter.interpret(obs, bp, inwardForward, inwardRight, events.followupOpen());
        opponent.observe(obs, state);
        profile = opponent.profileView(); eventSnapshot = events.snapshot();
        decision = tactics.choose(state, profile, eventSnapshot, opponent.predictedThreat());
        if (heuristicIntelligenceEnabled()) {
            intelligence.update(obs, state, profile, eventSnapshot, decision);
            // The opt-in heuristic stack's threat estimate incorporates recent combo damage as well as long-term tendencies.
            decision = tactics.choose(state, profile, eventSnapshot, intelligence.predictedThreat());
        }
        // With the default all-off mask, the learned policy receives observations/memory but the
        // unused hand-authored intelligence suite is not run on every tick. The reactive guard
        // remains active in enforce() regardless of this flag.
        lastIntent = decision.intent; lastConfidence = heuristicIntelligenceEnabled()
            ? Math.max(decision.confidence, intelligence.confidence()) : decision.confidence;
        decisionTicks++; tickReady = true;
    }

    double scoreCandidate(float[] action, double worldModelScore) {
        if (Config.PLAY_STACK >= 3) return worldModelScore;
        // INTEL_OFF bit 32 is the documented candidate-scoring ablation. It must gate the
        // top-level counterfactual evaluator as well as the nested intelligence-suite scorer;
        // otherwise the default mask (96) still applies hand-authored tactical preferences.
        if ((Config.INTEL_OFF & 32) != 0) return worldModelScore;
        if (!tickReady || state == null || decision == null) return worldModelScore;
        boolean full = Config.PLAY_STACK >= 2;
        double contextual = evaluator.score(state, decision, profile, eventSnapshot,
            full ? intelligence.predictedThreat() : opponent.predictedThreat(), action, worldModelScore);
        return full ? intelligence.scoreCandidate(action, contextual) : contextual;
    }

    /** Adds plausible intent-conditioned alternatives to the policy's own sampled candidate pool. */
    void guideCandidate(float[] a, int mask, Random rng) {
        if (Config.PLAY_STACK >= 3) return;
        if (!tickReady || a == null || a.length < PpoAgent.N_ACT || decision == null || rng == null) return;
        // INTEL_OFF bit 64 is the documented guidance ablation. Honour it for the planner's
        // intent-conditioned candidates as well as the optional intelligence-suite guidance;
        // otherwise the default mask (96) still rewrites movement/attack/sprint proposals.
        if ((Config.INTEL_OFF & 64) != 0) return;
        boolean fwdFree = (mask & ActionMask.LOCK_FWD) == 0;
        boolean sideFree = (mask & ActionMask.LOCK_STRAFE) == 0;
        boolean atkFree = (mask & ActionMask.LOCK_ATTACK) == 0;
        boolean sprintFree = (mask & ActionMask.LOCK_SPRINT) == 0;
        switch (decision.intent) {
            case PURSUE, ENGAGE -> {
                if (fwdFree && state.distance > 2.8f) a[2] = 2f;
                if (sprintFree && fwdFree && state.distance > 3.5f && a[7] < 0.5f) a[6] = 1f;
            }
            case PUNISH, COMBO_FOLLOWUP -> {
                if (fwdFree && state.distance > 1.7f) a[2] = 2f;
                if (atkFree && state.attackOpportunity && state.ownCharge >= Config.MIN_ATTACK_STRENGTH_LATE) a[4] = 1f;
                if (sprintFree && fwdFree && state.distance > 2.6f && a[7] < 0.5f) a[6] = 1f;
            }
            case DEFEND -> {
                if (sideFree) a[3] = rng.nextBoolean() ? 0f : 2f;
                if (fwdFree && state.distance < 2.9f && rng.nextDouble() < 0.6) a[2] = 0f;
                if (atkFree && !state.attackOpportunity && rng.nextDouble() < 0.6) a[4] = 0f;
            }
            case REPOSITION -> {
                if (sideFree) a[3] = rng.nextBoolean() ? 0f : 2f;
                if (Math.abs(state.yawErrorDeg) > 6f) a[0] = clamp(state.yawErrorDeg / 70f);
            }
            case DISENGAGE -> { if (fwdFree && state.distance < 3.4f) a[2] = 0f; }
            case BAIT -> { if (fwdFree && state.distance > 2.3f) a[2] = 1f; if (atkFree && !state.attackOpportunity) a[4] = 0f; }
        }
        if (a.length > 7 && a[7] > 0.5f) a[6] = 0f;
        if (heuristicIntelligenceEnabled()) intelligence.guideCandidate(a, mask, rng);
    }

    /**
     * Replace the policy's episode-local habit block with the persistent profile for this named
     * opponent once the profile has enough fresh samples. The eight inputs retain their trained
     * meanings; this method only supplies memory, never changes an action.
     */
    void applyOpponentHistory(float[] policyObservation) {
        opponent.applyPolicyHistory(policyObservation);
    }

    ReactiveCombatController.Result enforce(float[] action, int mask, float attackGate) {
        if (heuristicIntelligenceEnabled()) intelligence.enforce(action, mask);
        ReactiveCombatController.Result r = reactive.apply(state, action, mask, attackGate);
        if (r.changed()) interventionTicks++;
        rejectedAttacks += r.rejectedAttacks; correctedSprints += r.correctedSprint; boundaryCorrections += r.boundaryCorrections;
        return r;
    }

    void finishTick(float[] obs, float[] action, int mask, float attackGate) {
        events.recordChosen(obs, action, mask, attackGate);
        if (heuristicIntelligenceEnabled()) intelligence.finish(obs, action);
        tickReady = false;
    }

    void recordAppliedSwing(boolean clickQueued, boolean targetOnRay) {
        events.recordAppliedSwing(clickQueued, targetOnRay);
    }

    String intentName() { return lastIntent == null ? "n/a" : lastIntent.name(); }
    double intentConfidence() { return lastConfidence; }
    long safetyInterventions() { return interventionTicks; }
    long rejectedAttacks() { return rejectedAttacks; }
    long correctedSprints() { return correctedSprints; }
    long boundaryCorrections() { return boundaryCorrections; }
    long decisionTicks() { return decisionTicks; }

    String status() {
        String intent = lastIntent == null ? "n/a" : lastIntent.name();
        return events.status() + String.format(java.util.Locale.ROOT,
            "\nintent=%s, decision ticks=%d, safety interventions=%d (attack=%d, sprint=%d, boundary=%d), opponent=%s (profile confidence=%.2f, samples=%d)",
            intent, decisionTicks, interventionTicks, rejectedAttacks, correctedSprints, boundaryCorrections,
            opponent.opponentKey(), opponent.confidence(), opponent.samples()) +
            String.format(java.util.Locale.ROOT, ", persistent habit samples=%d", profile == null ? 0 : profile.habitSamples)
            + "\n" + intelligence.status();
    }

    void write(DataOutput out) throws IOException {
        out.writeInt(MAGIC); out.writeLong(decisionTicks); out.writeLong(interventionTicks);
        out.writeLong(rejectedAttacks); out.writeLong(correctedSprints); out.writeLong(boundaryCorrections);
        opponent.write(out); events.write(out);
    }

    void read(DataInput in) throws IOException {
        if (in.readInt() != MAGIC) return;
        decisionTicks = nonnegative(in.readLong()); interventionTicks = nonnegative(in.readLong());
        rejectedAttacks = nonnegative(in.readLong()); correctedSprints = nonnegative(in.readLong()); boundaryCorrections = nonnegative(in.readLong());
        opponent.read(in); events.read(in); state = null; decision = null; tickReady = false;
    }


    /** True only when at least one hand-authored strategic layer is explicitly enabled. */
    private static boolean heuristicIntelligenceEnabled() {
        return Config.PLAY_STACK == 2 && (Config.INTEL_OFF & 127) != 127;
    }

    private static long nonnegative(long x) { return Math.max(0, x); }
    private static float clamp(float x) { return Math.max(-1f, Math.min(1f, x)); }
}
