package com.rlpvp;

import java.util.Random;

/**
 * Coordinated tactical add-ons for the existing SituationalCombatStack. These systems share a single
 * state snapshot and produce recommendations/constraints; they never issue independent game inputs.
 * It deliberately reuses the existing state interpreter, opponent model, event memory and action evaluator.
 */
final class CombatIntelligenceSuite {
    enum Style { AGGRESSIVE, RUSHER, EVASIVE, DEFENSIVE, MIXED }
    enum Goal { SURVIVE, PUNISH, FOLLOW_UP, CLOSE_DISTANCE, HOLD_RANGE, RECOVER_SPACING, REPOSITION, BAIT }

    private final HitstunStateTracker hitstun = new HitstunStateTracker();
    private final ComboPatternRecognizer comboPatterns = new ComboPatternRecognizer();
    private final AntiComboLearningEngine antiComboLearning = new AntiComboLearningEngine();
    private final ThreatAssessmentEngine threatAssessment = new ThreatAssessmentEngine();
    private final ComboDamagePredictor comboDamage = new ComboDamagePredictor();
    private final DefensiveActionSelector defensiveSelector = new DefensiveActionSelector();
    private final ComboEscapeEngine comboEscape = new ComboEscapeEngine();
    private final CombatSpacingController spacing = new CombatSpacingController();
    private final AttackFeasibilityEvaluator attackFeasibility = new AttackFeasibilityEvaluator();
    private final CombatOpportunityDetector opportunities = new CombatOpportunityDetector();
    private final CombatRiskEvaluator riskEvaluator = new CombatRiskEvaluator();
    private final TacticalConfidenceEstimator confidenceEstimator = new TacticalConfidenceEstimator();
    private final OpponentStyleClassifier styleClassifier = new OpponentStyleClassifier();
    private final OpponentPatternPredictor patternPredictor = new OpponentPatternPredictor();
    private final CounterStrategySelector counterStrategy = new CounterStrategySelector();
    private final PredictiveCombatPlanner predictivePlanner = new PredictiveCombatPlanner();
    private final StrategicGoalManager goalManager = new StrategicGoalManager();
    private final ActionSequencePlanner sequencePlanner = new ActionSequencePlanner();
    private final MovementIntentCoordinator movementCoordinator = new MovementIntentCoordinator();
    private final ResourceManagementPlanner resources = new ResourceManagementPlanner();
    private final AdaptiveStrategyEvaluator adaptation = new AdaptiveStrategyEvaluator();

    private SituationalStateInterpreter.State state;
    private OpponentBehaviorModel.Profile profile;
    private EventDrivenCombatMemory.Snapshot memory;
    private TacticalDecisionEngine.Decision decision;
    private Style style = Style.MIXED;
    private Goal goal = Goal.CLOSE_DISTANCE;
    private double threat, comboRisk, opportunity, confidence;
    private long ticks;
    /** Diagnostic counters for the measured threat/combo thresholds; reset by the benchmark harness. */
    static final long[] DIAG = new long[4];

    void reset() {
        hitstun.reset(); comboPatterns.reset(); antiComboLearning.reset(); adaptation.reset(); patternPredictor.reset();
        state = null; profile = null; memory = null; decision = null; style = Style.MIXED; goal = Goal.CLOSE_DISTANCE;
        threat = comboRisk = opportunity = confidence = 0.0; ticks = 0;
    }

    void update(float[] obs, SituationalStateInterpreter.State s, OpponentBehaviorModel.Profile p,
                EventDrivenCombatMemory.Snapshot m, TacticalDecisionEngine.Decision d) {
        state = s; profile = p; memory = m; decision = d; ticks++;
        hitstun.observe(obs, s);
        comboPatterns.observe(obs, s, hitstun);
        antiComboLearning.observe(s, obs);
        style = styleClassifier.classify(p);
        double predictedAttack = patternPredictor.attackProbability(s, p, style);
        threat = threatAssessment.assess(s, p, predictedAttack, comboPatterns.followUpProbability());
        comboRisk = comboDamage.risk(s, comboPatterns, predictedAttack);
        opportunity = opportunities.score(s, m);
        confidence = confidenceEstimator.estimate(s, p, d, predictedAttack);
        goal = goalManager.select(s, d, threat, opportunity, comboRisk);
        adaptation.observe(obs, s);
        DIAG[0]++; if (threat > 0.55) DIAG[1]++; if (threat > 0.73) DIAG[2]++; if (comboRisk > 0.46) DIAG[3]++;
    }

    double predictedThreat() { return clamp01(Math.max(threat, comboRisk * 0.92)); }
    double confidence() { return confidence; }
    String styleName() { return style.name(); }
    String goalName() { return goal.name(); }
    double comboRisk() { return comboRisk; }
    double opportunityScore() { return opportunity; }

    double scoreCandidate(float[] action, double baseScore) {
        if (state == null || action == null || action.length < PpoAgent.N_ACT) return baseScore;
        if ((Config.INTEL_OFF & 32) != 0) return baseScore;
        int off = Config.INTEL_OFF;
        double score = baseScore;
        if ((off & 128) == 0) score += riskEvaluator.score(state, action, threat, comboRisk, confidence, style);
        if ((off & 256) == 0) score += opportunities.actionBonus(state, action, opportunity);
        if ((off & 512) == 0) score += sequencePlanner.score(state, action, memory);
        if ((off & 1024) == 0) score += resources.score(state, action);
        if ((off & 2048) == 0) score += predictivePlanner.score(state, action, threat, style);
        if ((off & 4096) == 0) score += adaptation.score(state, action);
        return Double.isFinite(score) ? score : -1e6;
    }

    void guideCandidate(float[] action, int mask, Random rng) {
        if (state == null || action == null || action.length < PpoAgent.N_ACT) return;
        if ((Config.INTEL_OFF & 64) != 0) return;
        predictivePlanner.guide(state, action, mask, threat, style, rng);
        sequencePlanner.guide(state, action, mask, memory);
        resources.guide(state, action, mask);
    }

    /** Last-mile action coordination, after candidate selection. */
    void enforce(float[] action, int mask) {
        if (state == null || action == null || action.length < PpoAgent.N_ACT) return;
        int off = Config.INTEL_OFF;
        if ((off & 1) == 0) attackFeasibility.enforce(state, action, mask);
        int preferredSide = counterStrategy.sidePreference(style, profile, antiComboLearning.sidePreference());
        if ((off & 2) == 0) movementCoordinator.enforce(state, action, mask, goal, threat, comboRisk, preferredSide);
        if ((off & 4) == 0) spacing.enforce(state, action, mask, goal);
        if ((off & 8) == 0) comboEscape.enforce(state, action, mask, threat, comboRisk, hitstun, comboPatterns, preferredSide);
        if ((off & 16) == 0) resources.enforce(state, action, mask);
        for (int i = 0; i < action.length; i++) if (!Float.isFinite(action[i])) action[i] = 0f;
    }

    void finish(float[] obs, float[] action) {
        hitstun.finish(obs);
        antiComboLearning.finish(state, obs, action);
        adaptation.finish(state, obs, action);
    }

    String status() {
        return String.format(java.util.Locale.ROOT,
            "combat-intel: goal=%s, style=%s, threat=%.2f, comboRisk=%.2f, opportunity=%.2f, confidence=%.2f, comboHits=%d, predictedFollowup=%.2f, aim-independent ticks=%d",
            goal, style, threat, comboRisk, opportunity, confidence, comboPatterns.hitsInCombo(),
            comboPatterns.followUpProbability(), ticks);
    }

    // ----------------------- tracked combat state and prediction systems -----------------------
    private static final class HitstunStateTracker {
        private float previousHealth = -1f;
        private float previousHurt;
        private int ticksSinceHit = 999;
        private boolean hitThisTick;
        void reset() { previousHealth = -1f; previousHurt = 0f; ticksSinceHit = 999; hitThisTick = false; }
        void observe(float[] obs, SituationalStateInterpreter.State s) {
            hitThisTick = previousHealth >= 0f && s.ownHealth < previousHealth - 0.0035f;
            boolean hurtEdge = s.ownHurt > 0.55f && previousHurt <= 0.35f;
            if (hitThisTick || hurtEdge) ticksSinceHit = 0; else ticksSinceHit = Math.min(999, ticksSinceHit + 1);
            previousHealth = s.ownHealth; previousHurt = s.ownHurt;
        }
        void finish(float[] obs) { /* observation is consumed in observe; kept as explicit lifecycle hook */ }
        boolean recentlyHit() { return ticksSinceHit <= 12; }
        int ticksSinceHit() { return ticksSinceHit; }
        boolean hitThisTick() { return hitThisTick; }
    }

    private static final class ComboPatternRecognizer {
        private int ticksSinceDamage = 999, hits;
        private double followupProbability;
        private float previousHealth = -1f;
        private int sprintStarters;
        void reset() { ticksSinceDamage = 999; hits = 0; followupProbability = 0; previousHealth = -1f; sprintStarters = 0; }
        void observe(float[] obs, SituationalStateInterpreter.State s, HitstunStateTracker hitstun) {
            boolean hpDrop = previousHealth >= 0f && s.ownHealth < previousHealth - 0.0035f;
            if (hpDrop || hitstun.hitThisTick()) {
                if (ticksSinceDamage <= 12) hits = Math.min(8, hits + 1); else hits = 1;
                ticksSinceDamage = 0;
                if (s.enemySprint > 0.5f) sprintStarters = Math.min(4, sprintStarters + 1);
            } else {
                ticksSinceDamage = Math.min(999, ticksSinceDamage + 1);
                if (ticksSinceDamage > 14) { hits = 0; sprintStarters = 0; }
            }
            double continuity = ticksSinceDamage <= 5 ? 0.28 : ticksSinceDamage <= 10 ? 0.15 : 0.0;
            double hitStack = Math.min(0.42, Math.max(0, hits - 1) * 0.10);
            double swingCue = s.enemySwing > 0.5f && ticksSinceDamage <= 8 ? 0.18 : 0.0;
            double sprintCue = s.enemySprint > 0.5f && s.distance < 3.4f ? 0.08 : 0.0;
            followupProbability = clamp01(continuity + hitStack + swingCue + sprintCue + Math.min(0.12, sprintStarters * 0.03));
            previousHealth = s.ownHealth;
        }
        int hitsInCombo() { return hits; }
        int ticksSinceDamage() { return ticksSinceDamage; }
        double followUpProbability() { return followupProbability; }
    }

    private static final class ThreatAssessmentEngine {
        double assess(SituationalStateInterpreter.State s, OpponentBehaviorModel.Profile p,
                      double predictedAttack, double comboProbability) {
            double direct = s.incomingThreat ? 0.46 : 0.0;
            if (s.meInEnemyReach > 0.5f) direct += 0.14;
            if (s.enemySwing > 0.5f) direct += 0.20;
            if (s.enemySprint > 0.5f && s.distance < 3.5f) direct += 0.10;
            if (s.enemyFacing > 0.55f && s.distance < 3.0f) direct += 0.06;
            if (p != null) direct += 0.12 * p.attackRate * p.confidence();
            return clamp01(Math.max(direct, predictedAttack * 0.72) + comboProbability * 0.35);
        }
    }

    private static final class ComboDamagePredictor {
        double risk(SituationalStateInterpreter.State s, ComboPatternRecognizer c, double predictedAttack) {
            if (c == null) return 0.0;
            double continuation = c.followUpProbability();
            if (c.hitsInCombo() >= 2) continuation += 0.14;
            if (s.ownHealth < 0.25f) continuation += 0.15;
            if (s.enemySprint > 0.5f && s.distance < 3.1f) continuation += 0.08;
            return clamp01(continuation * 0.72 + predictedAttack * 0.22);
        }
    }

    private static final class DefensiveActionSelector {
        void apply(SituationalStateInterpreter.State s, float[] a, int mask, double threat, int sidePreference) {
            if (threat < 0.62) return;
            if ((mask & ActionMask.LOCK_ATTACK) == 0 && !s.tradeable) a[4] = 0f;
            if ((mask & ActionMask.LOCK_SPRINT) == 0) a[6] = 0f;
            if ((mask & ActionMask.LOCK_FWD) == 0 && s.distance < 3.0f) a[2] = 0f; // neutral/back up only; never press into the threat
            if ((mask & ActionMask.LOCK_STRAFE) == 0) a[3] = sidePreference < 0 ? 0f : 2f;
            // Jump is used sparingly; it is not a magic dodge and may make the player easier to hit.
            if ((mask & ActionMask.LOCK_JUMP) == 0 && s.ownGround > 0.5f && s.distance < 2.8f && threat > 0.86)
                a[5] = 1f;
        }
    }

    private static final class ComboEscapeEngine {
        private final DefensiveActionSelector defensive = new DefensiveActionSelector();
        void enforce(SituationalStateInterpreter.State s, float[] a, int mask, double threat, double comboRisk,
                     HitstunStateTracker hitstun, ComboPatternRecognizer patterns, int sidePreference) {
            if (hitstun == null || patterns == null) return;
            // No universal combo-break action exists. Measured v7.35 ablation showed that applying
            // broad defense during every predicted combo disabled valid trades and sprint pressure.
            // Only sidestep a confirmed multi-hit sequence; never cancel the counter-swing/sprint/forward input.
            boolean realCombo = patterns.hitsInCombo() >= 2 && patterns.ticksSinceDamage() <= 8;
            if (!realCombo || Math.max(threat, comboRisk) < 0.6) return;
            if ((mask & ActionMask.LOCK_STRAFE) == 0 && Math.round(a[3]) == 1)
                a[3] = sidePreference < 0 ? 0f : 2f;
        }
    }

    private static final class CombatOpportunityDetector {
        double score(SituationalStateInterpreter.State s, EventDrivenCombatMemory.Snapshot m) {
            double value = s.attackOpportunity ? 0.52 : 0.0;
            if (s.opponentRecovering) value += 0.24;
            if (s.followupWindow) value += 0.28;
            if (s.enemyInMyReach > 0.5f && s.lineOfSight > 0.5f) value += 0.08;
            if (s.incomingThreat) value -= 0.24;
            if (m != null && m.repeatedWhiffRisk > 0.6) value -= 0.10;
            return clamp01(value);
        }
        double actionBonus(SituationalStateInterpreter.State s, float[] a, double score) {
            if (a.length < 5) return 0;
            if (a[4] > 0.5f && s.attackOpportunity) return 0.08 * score;
            if (a[4] < 0.5f && score > 0.7 && !s.incomingThreat) return -0.035;
            return 0.0;
        }
    }

    private static final class AttackFeasibilityEvaluator {
        boolean feasible(SituationalStateInterpreter.State s) {
            return s != null && s.lineOfSight > 0.5f && s.ownCharge >= Config.MIN_ATTACK_STRENGTH_LATE
                && (s.enemyInMyReach > 0.5f || s.distance <= Config.ATTACK_REACH + 0.28f)
                && Math.abs(s.yawErrorDeg) <= 35f && Math.abs(s.pitchErrorDeg) <= 28f;
        }
        void enforce(SituationalStateInterpreter.State s, float[] a, int mask) {
            if ((mask & ActionMask.LOCK_ATTACK) != 0 || !feasible(s)) a[4] = 0f;
        }
    }

    private static final class CombatRiskEvaluator {
        double score(SituationalStateInterpreter.State s, float[] a, double threat, double comboRisk,
                     double confidence, Style style) {
            double score = 0;
            int fwd = categorical(a[2]) - 1, side = categorical(a[3]) - 1;
            boolean attack = a[4] > 0.5f, sprint = a[6] > 0.5f;
            if (threat > 0.55) {
                if (attack && !s.tradeable) score -= (0.10 + 0.14 * threat) * (0.65 + confidence * 0.35);
                if (fwd > 0 && s.distance < 3.4f) score -= 0.12 * threat;
                if (side != 0 && s.meInEnemyReach > 0.5f) score += 0.045 * threat;
            }
            // If a facing opponent is crossing laterally, prefer a small evasive step away from
            // that trajectory. This is only a tie-breaker; the policy and learned escape side
            // still dominate, and no directional bias is applied to stationary/uncertain targets.
            if (threat > 0.30 && side != 0 && Math.abs(s.enemySideVelocity) > 0.10f && s.enemyFacing > 0.25f)
                score += -Math.signum(s.enemySideVelocity) * side * 0.035 * threat;
            if (comboRisk > 0.45) {
                if (attack && !s.tradeable) score -= 0.18 * comboRisk;
                if (fwd < 0 && s.distance < 3.1f) score += 0.075 * comboRisk;
                if (side != 0) score += 0.055 * comboRisk;
            }
            if (s.ownHealth < 0.25f) {
                if (attack && !s.opponentRecovering) score -= 0.07;
                if (fwd > 0 && s.distance < 2.2f && !s.followupWindow) score -= 0.06;
            }
            if (style == Style.RUSHER && fwd < 0 && s.distance < 3.4f) score += 0.025 * confidence;
            return score;
        }
    }

    private static final class CombatSpacingController {
        void enforce(SituationalStateInterpreter.State s, float[] a, int mask, Goal goal) {
            if ((mask & ActionMask.LOCK_FWD) != 0) return;
            boolean committedFollowup = s.followupWindow && s.enemyInMyReach > 0.5f;
            if (s.distance < 1.12f && !committedFollowup && !s.opponentRecovering) {
                a[2] = 0f; // backing off is safer than running into the opponent's centre
                if ((mask & ActionMask.LOCK_STRAFE) == 0 && Math.round(a[3]) == 1) a[3] = 2f;
                a[6] = 0f;
            } else if (s.distance < 1.48f && goal != Goal.FOLLOW_UP && !s.opponentRecovering
                    && Math.round(a[2]) == 2 && !s.tradeable) {
                a[2] = 1f; a[6] = 0f;
            }
        }
    }

    private static final class MovementIntentCoordinator {
        void enforce(SituationalStateInterpreter.State s, float[] a, int mask, Goal goal,
                     double threat, double comboRisk, int sidePreference) {
            if ((mask & ActionMask.LOCK_SPRINT) == 0 && (Math.round(a[2]) != 2 || a[7] > 0.5f)) a[6] = 0f;
            boolean outgunned = s.ownCharge < 0.5f && s.incomingThreat && s.meInEnemyReach > 0.5f;
            if (outgunned && threat > 0.8 && (mask & ActionMask.LOCK_STRAFE) == 0 && Math.round(a[3]) == 1)
                a[3] = sidePreference < 0 ? 0f : 2f;
            if (goal == Goal.SURVIVE && outgunned && (mask & ActionMask.LOCK_ATTACK) == 0 && !s.tradeable) a[4] = 0f;
        }
    }

    private static final class CounterStrategySelector {
        int sidePreference(Style style, OpponentBehaviorModel.Profile p, int learnedSide) {
            // Use the safer locally observed side as the default; style adds only a weak prior so it cannot override learning.
            int side = learnedSide < 0 ? -1 : 1;
            if (style == Style.EVASIVE && p != null && Math.abs(p.sideBias) > 0.18) side = p.sideBias > 0 ? -1 : 1;
            if (style == Style.RUSHER && p != null && p.sprintRate > 0.55) side = -side;
            return side;
        }
    }

    private static final class PredictiveCombatPlanner {
        double score(SituationalStateInterpreter.State s, float[] a, double threat, Style style) {
            if (s == null) return 0;
            double value = 0;
            int fwd = categorical(a[2]) - 1;
            if (threat > 0.62 && s.distance < 3.2f) {
                if (fwd < 0) value += 0.04 * threat;
                if (a[3] != 1f) value += 0.025 * threat;
                if (a[4] > 0.5f && !s.tradeable) value -= 0.11 * threat;
            }
            if (style == Style.EVASIVE && s.distance < 3.5f && fwd > 0) value -= 0.025;
            if (style == Style.RUSHER && s.distance > 2.8f && fwd > 0 && threat < 0.55) value += 0.025;
            return value;
        }
        void guide(SituationalStateInterpreter.State s, float[] a, int mask, double threat, Style style, Random rng) {
            if (threat < 0.77 || s.distance > 3.1f || rng == null) return;
            if ((mask & ActionMask.LOCK_ATTACK) == 0 && !s.tradeable) a[4] = 0f;
            if ((mask & ActionMask.LOCK_SPRINT) == 0) a[6] = 0f;
            if ((mask & ActionMask.LOCK_STRAFE) == 0 && Math.round(a[3]) == 1) a[3] = style == Style.EVASIVE ? 0f : 2f;
        }
    }

    private static final class TacticalConfidenceEstimator {
        double estimate(SituationalStateInterpreter.State s, OpponentBehaviorModel.Profile p,
                        TacticalDecisionEngine.Decision d, double predictedAttack) {
            double samples = p == null ? 0 : p.confidence();
            double evidence = s.incomingThreat || s.opponentRecovering || s.followupWindow ? 0.72 : 0.28 + 0.38 * samples;
            if (d != null) evidence = 0.55 * evidence + 0.45 * d.confidence;
            return clamp01(evidence * (0.82 + 0.18 * Math.max(samples, predictedAttack)));
        }
    }

    private static final class OpponentStyleClassifier {
        Style classify(OpponentBehaviorModel.Profile p) {
            if (p == null || p.samples < 8) return Style.MIXED;
            if (p.retreatRate > 0.57) return Style.EVASIVE;
            if (p.attackRate > 0.22 && p.sprintRate > 0.50) return Style.RUSHER;
            if (p.attackRate > 0.25) return Style.AGGRESSIVE;
            if (p.attackRate < 0.06 && p.retreatRate < 0.35) return Style.DEFENSIVE;
            return Style.MIXED;
        }
    }

    /**
     * Short-horizon opponent intent predictor. It combines learned attack cadence with live
     * range, facing, weapon readiness and closing velocity. Velocity is kept as a light EMA to
     * damp one-tick physics noise; it is reset at episode boundaries by the owning suite.
     */
    private static final class OpponentPatternPredictor {
        private double closingEma;
        private boolean haveClosing;
        private int consecutiveCloseCommitTicks;
        private boolean previousSwing;

        void reset() {
            closingEma = 0.0;
            haveClosing = false;
            consecutiveCloseCommitTicks = 0;
            previousSwing = false;
        }

        double attackProbability(SituationalStateInterpreter.State s, OpponentBehaviorModel.Profile p, Style style) {
            if (s == null) return 0.0;
            double closing = clampSigned(s.closingSpeed);
            closingEma = haveClosing ? 0.62 * closingEma + 0.38 * closing : closing;
            haveClosing = true;

            boolean swing = s.enemySwing > 0.5f;
            boolean swingEdge = swing && !previousSwing;
            previousSwing = swing;
            boolean facing = s.enemyFacing > 0.18f;
            boolean close = s.distance <= Config.ATTACK_REACH + 0.85f;
            if (facing && close && (closingEma > 0.08 || s.enemySprint > 0.5f))
                consecutiveCloseCommitTicks = Math.min(6, consecutiveCloseCommitTicks + 1);
            else consecutiveCloseCommitTicks = Math.max(0, consecutiveCloseCommitTicks - 1);

            double samples = p == null ? 0.0 : p.confidence();
            double value = p == null ? 0.10 : p.attackRate * (0.50 + 0.18 * samples) + p.sprintRate * 0.045;
            double proximity = clamp01((Config.ATTACK_REACH + 1.45 - s.distance) / 2.0);
            double facingCue = clamp01((s.enemyFacing - 0.10) / 0.75);
            double readiness = clamp01((s.enemyCharge - 0.30) / 0.70);
            double forwardCommit = clamp01((closingEma - 0.02) / 0.60);

            // Explicit animation and close-range commitment are the strongest immediate cues.
            if (swing) value += swingEdge ? 0.51 : 0.46;
            value += 0.15 * proximity * facingCue * readiness;
            value += 0.11 * proximity * facingCue * forwardCommit;
            value += 0.035 * Math.min(1.0, consecutiveCloseCommitTicks / 4.0) * facingCue;
            if (s.enemySprint > 0.5f && s.distance < 4.0f && closingEma > 0.12)
                value += 0.075 * proximity * facingCue;
            // Immediately after a swing, a close facing enemy may be setting up a follow-up even
            // though its estimated cooldown is still low. Keep this cue narrower than readiness.
            if (s.ticksSinceEnemySwing <= 3.0f && facing && s.meInEnemyReach > 0.5f)
                value += 0.08;
            if (s.distance > 4.2f) value *= 0.45;
            if (closingEma < -0.25) value *= 0.78; // reduce, but do not erase, threat from retreating opponents
            if (style == Style.RUSHER && close) value += 0.045 * (0.5 + samples);
            if (style == Style.EVASIVE && !facing) value *= 0.80;
            return clamp01(value * (0.78 + 0.22 * samples));
        }

        private static double clampSigned(double v) {
            return Double.isFinite(v) ? Math.max(-1.0, Math.min(1.0, v)) : 0.0;
        }
    }

    private static final class StrategicGoalManager {
        Goal select(SituationalStateInterpreter.State s, TacticalDecisionEngine.Decision d,
                    double threat, double opportunity, double comboRisk) {
            if (threat > 0.78 || comboRisk > 0.72) return Goal.SURVIVE;
            if (s.followupWindow && s.enemyInMyReach > 0.5f) return Goal.FOLLOW_UP;
            if (opportunity > 0.68 && s.attackOpportunity) return Goal.PUNISH;
            if (s.distance < 1.12f && !s.opponentRecovering) return Goal.RECOVER_SPACING;
            if (s.distance > 3.2f) return Goal.CLOSE_DISTANCE;
            if (s.lineOfSight < 0.5f || (d != null && d.intent == TacticalDecisionEngine.Intent.REPOSITION)) return Goal.REPOSITION;
            if (d != null && d.intent == TacticalDecisionEngine.Intent.BAIT) return Goal.BAIT;
            return Goal.HOLD_RANGE;
        }
    }

    private static final class ActionSequencePlanner {
        double score(SituationalStateInterpreter.State s, float[] a, EventDrivenCombatMemory.Snapshot m) {
            if (s.followupWindow && a[4] > 0.5f && s.enemyInMyReach > 0.5f && s.lineOfSight > 0.5f) return 0.09;
            if (s.followupWindow && a[2] == 2f && s.distance > 1.8f) return 0.035;
            if (m != null && m.repeatedWhiffRisk > 0.65 && a[4] > 0.5f) return -0.10;
            return 0.0;
        }
        void guide(SituationalStateInterpreter.State s, float[] a, int mask, EventDrivenCombatMemory.Snapshot m) {
            if (s.followupWindow && s.enemyInMyReach > 0.5f && s.attackOpportunity
                    && (mask & ActionMask.LOCK_ATTACK) == 0) a[4] = 1f;
            if (m != null && m.repeatedWhiffRisk > 0.75 && !s.opponentRecovering && (mask & ActionMask.LOCK_ATTACK) == 0)
                a[4] = 0f;
        }
    }

    private static final class ResourceManagementPlanner {
        double score(SituationalStateInterpreter.State s, float[] a) {
            double value = 0;
            if (a[4] > 0.5f && s.ownCharge < Config.MIN_ATTACK_STRENGTH_LATE) value -= 0.18;
            if (a[6] > 0.5f && (s.distance < 1.7f || s.ownCharge < 0.22f)) value -= 0.07;
            if (s.ownHealth < 0.22f && a[6] > 0.5f && s.incomingThreat) value -= 0.08;
            return value;
        }
        void guide(SituationalStateInterpreter.State s, float[] a, int mask) {
            if (s.ownCharge < Config.MIN_ATTACK_STRENGTH_LATE && (mask & ActionMask.LOCK_ATTACK) == 0 && !s.followupWindow) a[4] = 0f;
        }
        void enforce(SituationalStateInterpreter.State s, float[] a, int mask) {
            if (s.ownCharge < Config.MIN_ATTACK_STRENGTH_LATE && !s.attackOpportunity && (mask & ActionMask.LOCK_ATTACK) == 0) a[4] = 0f;
            if (a[7] > 0.5f) a[6] = 0f;
        }
    }

    private static final class AntiComboLearningEngine {
        private int leftFailures, rightFailures;
        private int previousChoice;
        private float previousHealth = -1f;
        private long evaluations;
        void reset() { leftFailures = rightFailures = 0; previousChoice = 0; previousHealth = -1f; evaluations = 0; }
        void observe(SituationalStateInterpreter.State s, float[] obs) {
            if (previousHealth >= 0f && s.ownHealth < previousHealth - 0.0035f) {
                if (previousChoice < 0) leftFailures++; else if (previousChoice > 0) rightFailures++;
                evaluations++;
            }
            previousHealth = s.ownHealth;
        }
        void finish(SituationalStateInterpreter.State s, float[] obs, float[] action) {
            if (s == null || action == null || action.length < 4) return;
            previousChoice = categorical(action[3]) - 1;
        }
        int sidePreference() { return leftFailures < rightFailures ? -1 : 1; }
        long evaluations() { return evaluations; }
    }

    private static final class AdaptiveStrategyEvaluator {
        private double successEma = 0.5;
        private float previousEnemyHealth = -1f, previousOwnHealth = -1f;
        void reset() { successEma = 0.5; previousEnemyHealth = previousOwnHealth = -1f; }
        void observe(float[] obs, SituationalStateInterpreter.State s) {
            if (previousEnemyHealth >= 0 && previousOwnHealth >= 0) {
                boolean dealt = s.enemyHealth < previousEnemyHealth - 0.0035f;
                boolean taken = s.ownHealth < previousOwnHealth - 0.0035f;
                if (dealt || taken) successEma += 0.08 * ((dealt && !taken ? 1.0 : dealt ? 0.55 : 0.0) - successEma);
            }
            previousEnemyHealth = s.enemyHealth; previousOwnHealth = s.ownHealth;
        }
        double score(SituationalStateInterpreter.State s, float[] action) {
            double score = 0.0;
            if (action == null || action.length < 5 || s == null) return score;
            // If recent exchanges are going badly, slightly favour safer actions; if winning cleanly, preserve useful pressure.
            double form = successEma - 0.5;
            if (action[4] > 0.5f) score += form * (s.attackOpportunity ? 0.10 : 0.04);
            if (s.incomingThreat && action[3] != 1f) score += Math.max(0.0, -form) * 0.05;
            return score;
        }
        void finish(SituationalStateInterpreter.State s, float[] obs, float[] action) { }
        double successRate() { return successEma; }
    }

    private static int categorical(float value) { return Math.max(0, Math.min(2, Math.round(value))); }
    private static double clamp01(double value) { return Double.isFinite(value) ? Math.max(0.0, Math.min(1.0, value)) : 0.0; }
}
