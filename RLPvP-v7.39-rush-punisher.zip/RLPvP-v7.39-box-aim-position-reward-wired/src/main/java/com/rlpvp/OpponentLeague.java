package com.rlpvp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/** Elo ledger and performance-focused PFSP sampler shared by the live trainer and simulator. */
final class OpponentLeague {
    static final double INITIAL_RATING = 1200.0;
    static final double TARGET_WIN_RATE = 0.60;
    static final double MIN_TARGET_WIN = 0.50;
    static final double MAX_TARGET_WIN = 0.70;
    static final int PROMOTION_GAMES = 30;
    static final double PROMOTION_RATING = 1225.0;
    /** Stage 8 requires a deeper competitive sample before the open-ended Stage 9 league begins. */
    static final int ADVANCED_PROMOTION_GAMES = 150;
    static final double ADVANCED_PROMOTION_RATING = 1275.0;
    static final double K_FACTOR = 24.0;
    /** Stage 9 reserves a small share for proven problem matchups, even after their Elo rises above the main PFSP band. */
    static final double WEAKNESS_CHALLENGE_SHARE = 0.20;
    static final double MIN_WEAKNESS_EXPECTED_WIN = 0.35;
    /** A candidate with fewer Elo games than this has an unmeasured rating (new styles start at 1200): it stays eligible and gets a floor weight so it is actually played and rated. */
    static final long NEW_OPPONENT_GAMES = 12;
    static final double NEW_OPPONENT_MIN_WEIGHT = 0.6;

    static final class Entry {
        final String id;
        double rating;
        long games, wins, losses, draws;
        // Matchup diagnostics from the learner's point of view when this entry is sampled as its opponent.
        // These are deliberately separate from Elo's symmetric record.
        long matchupGames, matchupWins, matchupLosses, matchupDraws;
        double agentDealt, agentTaken;
        Entry(String id) { this.id = id; rating = INITIAL_RATING; }
    }

    private final Map<String, Entry> entries = new LinkedHashMap<>();

    synchronized Entry ensure(String id) {
        return entries.computeIfAbsent(id, Entry::new);
    }

    synchronized double rating(String id) { return ensure(id).rating; }
    synchronized long games(String id) { return ensure(id).games; }

    /**
     * PFSP selection: first restrict to opponents for which the estimated agent win probability is 50–70%,
     * then draw with a Gaussian preference around 60%. If the pool has no in-band member, choose the closest.
     */
    synchronized String sample(String agentId, List<String> candidates, Random rng) {
        return sample(agentId, candidates, rng, false);
    }

    /**
     * Stage 9 keeps PFSP's 50-70% predicted-win band but increases sampling for opponents that previously exposed
     * matchup weaknesses. Aggressive specialists receive a modest coverage bonus so combo/pressure styles do not
     * disappear behind a single aggregate Elo estimate.
     */
    synchronized String sample(String agentId, List<String> candidates, Random rng, boolean stage9) {
        if (candidates == null || candidates.isEmpty()) return null;
        double own = ensure(agentId).rating;
        List<String> inBand = new ArrayList<>();
        List<String> weaknessChallenges = new ArrayList<>();
        String closest = null;
        double closestDistance = Double.POSITIVE_INFINITY;
        for (String id : candidates) {
            if (id == null || id.equals(agentId)) continue;
            Entry e = ensure(id);
            double p = expected(own, e.rating);
            double distance = Math.abs(p - TARGET_WIN_RATE);
            if (distance < closestDistance) { closestDistance = distance; closest = id; }
            if ((p >= MIN_TARGET_WIN && p <= MAX_TARGET_WIN) || e.games < NEW_OPPONENT_GAMES) inBand.add(id);
            if (stage9 && e.matchupGames >= 3 && p >= MIN_WEAKNESS_EXPECTED_WIN && p < MIN_TARGET_WIN) {
                double learnerScoreRate = (e.matchupWins + 0.5 * e.matchupDraws) / e.matchupGames;
                if (learnerScoreRate < 0.50) weaknessChallenges.add(id);
            }
        }
        // A small corrective-play share keeps a repeatedly troublesome opponent in rotation after Elo has
        // correctly recognized it as stronger than the learner. Main PFSP still supplies the majority of games.
        if (stage9 && !weaknessChallenges.isEmpty() && rng.nextDouble() < WEAKNESS_CHALLENGE_SHARE)
            return sampleWeaknessChallenge(agentId, weaknessChallenges, rng);
        if (inBand.isEmpty()) return closest;
        double total = 0.0;
        double[] weights = new double[inBand.size()];
        for (int i = 0; i < inBand.size(); i++) {
            Entry e = ensure(inBand.get(i));
            double p = expected(own, e.rating);
            double target = Math.exp(-0.5 * Math.pow((p - TARGET_WIN_RATE) / 0.075, 2.0));
            double uncertainty = 0.65 + 0.35 / Math.sqrt(1.0 + e.games / 8.0);
            double weakness = stage9 ? matchupWeaknessWeight(e) : 1.0;
            double pressureCoverage = stage9 && isAggressiveSpecialist(inBand.get(i)) ? 1.35 : 1.0;
            weights[i] = Math.max(1e-6, target * uncertainty * weakness * pressureCoverage);
            if (e.games < NEW_OPPONENT_GAMES) weights[i] = Math.max(weights[i], NEW_OPPONENT_MIN_WEIGHT);
            total += weights[i];
        }
        double pick = rng.nextDouble() * total;
        for (int i = 0; i < weights.length; i++) {
            pick -= weights[i];
            if (pick <= 0.0) return inBand.get(i);
        }
        return inBand.get(inBand.size() - 1);
    }

    /**
     * Pre-league stages: record the agent's result against a scripted bot style (matchup counters only: no Elo, no games count, so promotion is untouched).
     * Episodes that go through result() above are not recorded here, so nothing is counted twice.
     */
    synchronized void styleResult(int style, double agentScore, double dealt, double taken) {
        Entry b = ensure("script:" + style);
        if (agentScore > 0.5) b.matchupWins++; else if (agentScore < 0.5) b.matchupLosses++; else b.matchupDraws++;
        b.matchupGames++;
        if (Double.isFinite(dealt) && dealt >= 0.0) b.agentDealt += dealt;
        if (Double.isFinite(taken) && taken >= 0.0) b.agentTaken += taken;
    }

    /** Draw a style from the base mix, each weight multiplied by 1..2 for styles the agent is weak against (a style is never made rarer than its base share before normalising). */
    synchronized int sampleStyle(double[] base, Random rng) {
        double[] w = new double[base.length];
        double total = 0.0;
        for (int i = 0; i < base.length; i++) {
            if (base[i] <= 0.0) continue;
            w[i] = base[i] * matchupWeaknessWeight(ensure("script:" + i));
            total += w[i];
        }
        double pick = rng.nextDouble() * total;
        int last = 0;
        for (int i = 0; i < w.length; i++) {
            if (w[i] <= 0.0) continue;
            last = i;
            pick -= w[i];
            if (pick <= 0.0) return i;
        }
        return last;
    }

    synchronized void result(String agentId, String opponentId, double agentScore) {
        result(agentId, opponentId, agentScore, Double.NaN, Double.NaN);
    }

    synchronized void result(String agentId, String opponentId, double agentScore, double agentDamageDealt, double agentDamageTaken) {
        if (opponentId == null || opponentId.equals(agentId)) return;
        Entry a = ensure(agentId), b = ensure(opponentId);
        double score = Math.max(0.0, Math.min(1.0, agentScore));
        double ea = expected(a.rating, b.rating);
        double eb = 1.0 - ea;
        double delta = K_FACTOR * (score - ea);
        a.rating += delta;
        b.rating -= delta;
        a.games++; b.games++;
        if (score > 0.5) { a.wins++; b.losses++; b.matchupWins++; }
        else if (score < 0.5) { a.losses++; b.wins++; b.matchupLosses++; }
        else { a.draws++; b.draws++; b.matchupDraws++; }
        b.matchupGames++;
        if (Double.isFinite(agentDamageDealt) && agentDamageDealt >= 0.0) b.agentDealt += agentDamageDealt;
        if (Double.isFinite(agentDamageTaken) && agentDamageTaken >= 0.0) b.agentTaken += agentDamageTaken;
    }

    private String sampleWeaknessChallenge(String agentId, List<String> candidates, Random rng) {
        double own = ensure(agentId).rating;
        double total = 0.0;
        double[] weights = new double[candidates.size()];
        for (int i = 0; i < candidates.size(); i++) {
            String id = candidates.get(i);
            Entry e = ensure(id);
            double p = expected(own, e.rating);
            double challengeBand = Math.exp(-0.5 * Math.pow((p - 0.42) / 0.12, 2.0));
            double pressureCoverage = isAggressiveSpecialist(id) ? 1.35 : 1.0;
            weights[i] = Math.max(1e-6, challengeBand * matchupWeaknessWeight(e) * pressureCoverage);
            total += weights[i];
        }
        double pick = rng.nextDouble() * total;
        for (int i = 0; i < weights.length; i++) {
            pick -= weights[i];
            if (pick <= 0.0) return candidates.get(i);
        }
        return candidates.get(candidates.size() - 1);
    }

    private static double matchupWeaknessWeight(Entry e) {
        if (e.matchupGames <= 0) return 1.0;
        double confidence = Math.min(1.0, e.matchupGames / 12.0);
        double scoreRate = (e.matchupWins + 0.5 * e.matchupDraws) / e.matchupGames;
        double deficit = (e.agentTaken - e.agentDealt) / Math.max(12.0, e.agentTaken + e.agentDealt);
        double weakness = 1.0 + 0.90 * (1.0 - scoreRate) * confidence + 0.45 * Math.max(0.0, Math.min(1.0, deficit)) * confidence;
        return Math.max(1.0, Math.min(2.0, weakness));
    }

    private static boolean isAggressiveSpecialist(String id) {
        if (id == null || !id.startsWith("script:")) return false;
        try { return BotAI.isAggressiveSpecialist(Integer.parseInt(id.substring("script:".length()))); }
        catch (NumberFormatException ex) { return false; }
    }

    synchronized String weaknessSummary(String agentId) {
        List<Entry> weak = new ArrayList<>();
        for (Entry e : entries.values()) if (!e.id.equals(agentId) && e.matchupGames >= 3) weak.add(e);
        weak.sort((x, y) -> Double.compare(matchupWeaknessWeight(y), matchupWeaknessWeight(x)));
        if (weak.isEmpty()) return "weak-vs: insufficient matchup data";
        StringBuilder out = new StringBuilder("weak-vs:");
        for (int i = 0; i < Math.min(3, weak.size()); i++) {
            Entry e = weak.get(i);
            if (i > 0) out.append(';');
            String displayId = e.id;
            if (e.id.startsWith("script:")) {
                try { displayId = BotAI.styleName(Integer.parseInt(e.id.substring("script:".length()))); }
                catch (NumberFormatException ignored) { /* keep the stable raw id */ }
            }
            out.append(' ').append(displayId).append(' ')
                .append(e.matchupWins).append('/').append(e.matchupLosses).append('/').append(e.matchupDraws)
                .append(" D/T ").append(String.format(Locale.ROOT, "%.1f/%.1f", e.agentDealt / e.matchupGames, e.agentTaken / e.matchupGames));
        }
        return out.toString();
    }

    synchronized void snapshot(String id, String sourceId) {
        Entry src = ensure(sourceId), dst = ensure(id);
        copyRecord(src, dst);
    }

    /** Register an immutable policy snapshot exactly once when several training environments share this league. */
    synchronized boolean snapshotIfAbsent(String id, String sourceId) {
        if (entries.containsKey(id)) return false;
        Entry src = ensure(sourceId);
        Entry dst = new Entry(id);
        copyRecord(src, dst);
        entries.put(id, dst);
        return true;
    }

    private static void copyRecord(Entry src, Entry dst) {
        dst.rating = src.rating;
        dst.games = src.games;
        dst.wins = src.wins;
        dst.losses = src.losses;
        dst.draws = src.draws;
    }

    synchronized boolean promotionReady(String agentId) {
        Entry e = ensure(agentId);
        return e.games >= PROMOTION_GAMES && e.rating >= PROMOTION_RATING;
    }

    synchronized String summary(String agentId) {
        Entry e = ensure(agentId);
        return String.format(Locale.ROOT, "Elo %.0f (%d games; W/L/D %d/%d/%d)", e.rating, e.games, e.wins, e.losses, e.draws);
    }

    synchronized void save(Path path) throws IOException {
        Path parent = path.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
        List<Entry> sorted = new ArrayList<>(entries.values());
        sorted.sort(Comparator.comparing(x -> x.id));
        StringBuilder out = new StringBuilder("id,rating,games,wins,losses,draws,matchup_games,matchup_wins,matchup_losses,matchup_draws,agent_dealt,agent_taken\n");
        for (Entry e : sorted) out.append(csv(e.id)).append(',').append(String.format(Locale.ROOT, "%.3f", e.rating))
            .append(',').append(e.games).append(',').append(e.wins).append(',').append(e.losses).append(',').append(e.draws)
            .append(',').append(e.matchupGames).append(',').append(e.matchupWins).append(',').append(e.matchupLosses).append(',').append(e.matchupDraws)
            .append(',').append(String.format(Locale.ROOT, "%.3f", e.agentDealt)).append(',').append(String.format(Locale.ROOT, "%.3f", e.agentTaken)).append('\n');
        Path target = path.toAbsolutePath();
        Path tmp = Files.createTempFile(parent, path.getFileName().toString() + ".", ".tmp");
        try {
            Files.writeString(tmp, out.toString());
            try {
                Files.move(tmp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ex) {
                Files.move(tmp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    synchronized void load(Path path) throws IOException {
        if (!Files.isRegularFile(path)) return;
        List<String> lines = Files.readAllLines(path);
        for (int i = 1; i < lines.size(); i++) {
            String[] p = lines.get(i).split(",", -1);
            if (p.length < 6) continue; // v1 six-column files remain readable
            try {
                Entry e = ensure(unCsv(p[0]));
                e.rating = Double.parseDouble(p[1]); e.games = Long.parseLong(p[2]);
                e.wins = Long.parseLong(p[3]); e.losses = Long.parseLong(p[4]); e.draws = Long.parseLong(p[5]);
                if (p.length >= 12) {
                    e.matchupGames = Long.parseLong(p[6]); e.matchupWins = Long.parseLong(p[7]);
                    e.matchupLosses = Long.parseLong(p[8]); e.matchupDraws = Long.parseLong(p[9]);
                    e.agentDealt = Double.parseDouble(p[10]); e.agentTaken = Double.parseDouble(p[11]);
                }
            } catch (RuntimeException ignored) { /* ignore damaged rows, retain the rest of the ledger */ }
        }
    }

    static double expected(double own, double opponent) { return 1.0 / (1.0 + Math.pow(10.0, (opponent - own) / 400.0)); }
    private static String csv(String s) { return '"' + s.replace("\"", "\"\"") + '"'; }
    private static String unCsv(String s) { return s.length() >= 2 && s.charAt(0) == '"' ? s.substring(1, s.length() - 1).replace("\"\"", "\"") : s; }
}
