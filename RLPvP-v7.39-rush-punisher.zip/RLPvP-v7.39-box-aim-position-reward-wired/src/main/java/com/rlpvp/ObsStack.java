package com.rlpvp;

import java.util.ArrayList;

/**
 * Builds the network input. The current compact layout is exactly 128 values:
 * [current 51-value frame | 64-value trainable GRU state | 8 opponent habits |
 *  recent damage differential | encoded last-hit type | reach margin | normalized target-box dx/dy].
 *
 * The GRU replaces explicit frame stacking: its 18 inputs are updated every tick and its 64 hidden
 * values carry learned temporal context. Set -Drlpvp.obs126=false only for old-checkpoint/debug
 * compatibility; that path retains the historical lag-stack layout.
 */
final class ObsStack {
    static final int GRU_START = Config.FRAME;
    static final int GRU_WIDTH = 64;
    static final int HABIT_START = GRU_START + GRU_WIDTH;
    static final int DAMAGE_DIFF_SLOT = HABIT_START + OpponentMemory.HABITS;
    static final int HIT_TYPE_SLOT = DAMAGE_DIFF_SLOT + 1;
    static final int REACH_MARGIN_SLOT = HIT_TYPE_SLOT + 1;
    static final int BOX_DX_SLOT = REACH_MARGIN_SLOT + 1;
    static final int BOX_DY_SLOT = BOX_DX_SLOT + 1;
    static final int COMPACT_SIZE = BOX_DY_SLOT + 1;

    private final ArrayList<float[]> hist = new ArrayList<>();
    // Internal tick paths may use this buffer only when the consumer reads synchronously and does not retain it.
    private final float[] reusableCompact = new float[Config.OBS_SIZE];
    private static final int[] OFFSET = new int[Config.LAGS.length];

    static {
        if (COMPACT_SIZE != Config.COMPACT_OBS_SIZE) throw new ExceptionInInitializerError("compact observation layout is not 128 values");
        for (int k = 0; k < OFFSET.length; k++) OFFSET[k] = ObsLayout.offset(Config.LAGS, k, Config.FRAME, Config.FAR_FEATURES.length);
    }

    void reset() { hist.clear(); }

    /** Adds this tick's frame and summary, returning a fresh network input. */
    float[] push(float[] frame, float[] summary) {
        if (Config.COMPACT_126) return packCompact(frame, summary);
        return packLegacy(frame, summary);
    }

    /** Returns a per-ObsStack reusable compact buffer. The caller must consume it synchronously and not retain it. */
    float[] pushReusable(float[] frame, float[] summary) {
        if (Config.COMPACT_126) return packCompactInto(frame, summary, reusableCompact);
        return packLegacy(frame, summary);
    }

    private float[] packCompact(float[] frame, float[] summary) {
        return packCompactInto(frame, summary, new float[Config.OBS_SIZE]);
    }

    private float[] packCompactInto(float[] frame, float[] summary, float[] out) {
        if (frame == null || frame.length < Config.FRAME) throw new IllegalArgumentException("frame must contain " + Config.FRAME + " features");
        System.arraycopy(frame, 0, out, 0, Config.FRAME);
        if (summary == null) {
            java.util.Arrays.fill(out, Config.FRAME, out.length, 0f);
            return out;
        }

        int memOff = Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0)
            + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0);
        if (Config.MEMORY && summary.length >= memOff + OpponentMemory.FEATURES) {
            // Episode-local habits and the trained GRU's recurrent state occupy fixed policy slots.
            System.arraycopy(summary, memOff, out, HABIT_START, OpponentMemory.HABITS);
            int hCount = Math.min(GRU_WIDTH, GruCell.H);
            System.arraycopy(summary, memOff + OpponentMemory.HABITS, out, GRU_START, hCount);
            if (hCount < GRU_WIDTH) java.util.Arrays.fill(out, GRU_START + hCount, HABIT_START, 0f);
        } else {
            java.util.Arrays.fill(out, GRU_START, HABIT_START + OpponentMemory.HABITS, 0f);
        }

        // Outcome and current combat state remain explicit; the GRU learns the longer history.
        out[DAMAGE_DIFF_SLOT] = summary.length > 9 ? clamp(summary[8] - summary[9]) : 0f;
        if (summary.length > 4) {
            int mask = (summary[1] > 0.5f ? HitMemory.CRIT : 0)
                | (summary[2] > 0.5f ? HitMemory.SPRINT : 0)
                | (summary[3] > 0.5f ? HitMemory.SWEEP : 0)
                | (summary[4] > 0.5f ? HitMemory.WEAK : 0);
            out[HIT_TYPE_SLOT] = mask / 15.0f;
        } else out[HIT_TYPE_SLOT] = 0f;
        if (Config.COMBAT_OBSERVATIONS) {
            int combatOff = Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0)
                + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0)
                + (Config.MEMORY ? Config.MEMORY_FEATURES : 0)
                + (Config.KB_TIMING ? Config.KB_FEATURES : 0);
            out[REACH_MARGIN_SLOT] = summary.length > combatOff + CombatObservationMemory.REACH_MARGIN
                ? summary[combatOff + CombatObservationMemory.REACH_MARGIN] : 0f;
        } else out[REACH_MARGIN_SLOT] = 0f;
        if (Config.COMBAT_OBSERVATIONS) {
            int combatOff = Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0)
                + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0)
                + (Config.MEMORY ? Config.MEMORY_FEATURES : 0)
                + (Config.KB_TIMING ? Config.KB_FEATURES : 0);
            out[BOX_DX_SLOT] = summary.length > combatOff + CombatObservationMemory.CROSSHAIR_BOX_DX
                ? summary[combatOff + CombatObservationMemory.CROSSHAIR_BOX_DX] : 0f;
            out[BOX_DY_SLOT] = summary.length > combatOff + CombatObservationMemory.CROSSHAIR_BOX_DY
                ? summary[combatOff + CombatObservationMemory.CROSSHAIR_BOX_DY] : 0f;
        } else {
            out[BOX_DX_SLOT] = out[BOX_DY_SLOT] = 0f;
        }
        return out;
    }

    private float[] packLegacy(float[] frame, float[] summary) {
        if (hist.isEmpty()) {
            for (int i = 0; i <= Config.MAX_LAG; i++) hist.add(frame);
        } else {
            hist.add(frame);
            if (hist.size() > Config.MAX_LAG + 1) hist.remove(0);
        }
        float[] out = new float[Config.OBS_SIZE];
        int n = hist.size();
        for (int k = 0; k < Config.LAGS.length; k++) {
            float[] fr = hist.get(Math.max(0, n - 1 - Config.LAGS[k]));
            if (ObsLayout.near(Config.LAGS[k])) System.arraycopy(fr, 0, out, OFFSET[k], Config.FRAME);
            else for (int j = 0; j < Config.FAR_FEATURES.length; j++) out[OFFSET[k] + j] = fr[Config.FAR_FEATURES[j]];
        }
        if (summary != null) System.arraycopy(summary, 0, out, Config.OBS_SIZE - Config.SUMMARY, Math.min(summary.length, Config.SUMMARY));
        return out;
    }

    static float encodeHitMask(int mask) { return (mask & 15) / 15.0f; }
    static int decodeHitMask(float encoded) {
        if (!Float.isFinite(encoded)) return 0;
        return Math.max(0, Math.min(15, Math.round(encoded * 15.0f)));
    }
    private static float clamp(float x) { return !Float.isFinite(x) ? 0f : Math.max(-1f, Math.min(1f, x)); }
}
