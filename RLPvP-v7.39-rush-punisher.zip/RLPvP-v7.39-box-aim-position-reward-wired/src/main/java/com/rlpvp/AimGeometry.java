package com.rlpvp;

/**
 * Camera-relative target-box geometry shared by the Minecraft adapter and offline simulator.
 * Outputs describe where the target's projected bounding-box centre is relative to the crosshair,
 * measured in projected half-widths / half-heights. Positive X means target to the right;
 * negative Y means target above. These are observations only and never alter camera actions.
 */
final class AimGeometry {
    private static final double MIN_HALF_ANGLE_DEG = 0.05;
    private AimGeometry() {}

    static void normalizedError(double eyeX, double eyeY, double eyeZ,
                                double cameraYawDeg, double cameraPitchDeg,
                                double minX, double maxX, double minY, double maxY,
                                double minZ, double maxZ, float[] out, int offset) {
        if (out == null || offset < 0 || offset + 1 >= out.length) return;
        if (!(Double.isFinite(eyeX) && Double.isFinite(eyeY) && Double.isFinite(eyeZ)
                && Double.isFinite(cameraYawDeg) && Double.isFinite(cameraPitchDeg)
                && Double.isFinite(minX) && Double.isFinite(maxX)
                && Double.isFinite(minY) && Double.isFinite(maxY)
                && Double.isFinite(minZ) && Double.isFinite(maxZ))
                || maxX < minX || maxY < minY || maxZ < minZ) {
            out[offset] = out[offset + 1] = 0f;
            return;
        }

        double cx = (minX + maxX) * 0.5;
        double cy = (minY + maxY) * 0.5;
        double cz = (minZ + maxZ) * 0.5;
        double centerDx = cx - eyeX, centerDy = cy - eyeY, centerDz = cz - eyeZ;
        double centerHoriz = Math.hypot(centerDx, centerDz);
        double centerYaw = Math.toDegrees(Math.atan2(-centerDx, centerDz));
        double centerYawOffset = wrap180(centerYaw - cameraYawDeg);
        double centerPitch = -Math.toDegrees(Math.atan2(centerDy, Math.max(centerHoriz, 1.0e-9)));
        double centerPitchOffset = centerPitch - cameraPitchDeg;

        double minYawOffset = Double.POSITIVE_INFINITY;
        double maxYawOffset = Double.NEGATIVE_INFINITY;
        double minPitchOffset = Double.POSITIVE_INFINITY;
        double maxPitchOffset = Double.NEGATIVE_INFINITY;
        for (int ix = 0; ix < 2; ix++) {
            double x = ix == 0 ? minX : maxX;
            for (int iy = 0; iy < 2; iy++) {
                double y = iy == 0 ? minY : maxY;
                for (int iz = 0; iz < 2; iz++) {
                    double z = iz == 0 ? minZ : maxZ;
                    double dx = x - eyeX, dy = y - eyeY, dz = z - eyeZ;
                    double horiz = Math.hypot(dx, dz);
                    double cornerYaw = Math.toDegrees(Math.atan2(-dx, dz));
                    // Unwrap all corners around the target-centre bearing, including targets behind us.
                    double yawOffset = centerYawOffset + wrap180(cornerYaw - centerYaw);
                    double pitchOffset = -Math.toDegrees(Math.atan2(dy, Math.max(horiz, 1.0e-9))) - cameraPitchDeg;
                    minYawOffset = Math.min(minYawOffset, yawOffset);
                    maxYawOffset = Math.max(maxYawOffset, yawOffset);
                    minPitchOffset = Math.min(minPitchOffset, pitchOffset);
                    maxPitchOffset = Math.max(maxPitchOffset, pitchOffset);
                }
            }
        }
        double halfYaw = Math.max(MIN_HALF_ANGLE_DEG, (maxYawOffset - minYawOffset) * 0.5);
        double halfPitch = Math.max(MIN_HALF_ANGLE_DEG, (maxPitchOffset - minPitchOffset) * 0.5);
        out[offset] = squash(centerYawOffset / halfYaw);
        out[offset + 1] = squash(centerPitchOffset / halfPitch);
    }

    private static float squash(double v) {
        if (!Double.isFinite(v)) return 0f;
        return (float) Math.tanh(Math.max(-20.0, Math.min(20.0, v)) * 0.5);
    }

    private static double wrap180(double value) {
        value %= 360.0;
        if (value >= 180.0) value -= 360.0;
        if (value < -180.0) value += 360.0;
        return value;
    }

}
