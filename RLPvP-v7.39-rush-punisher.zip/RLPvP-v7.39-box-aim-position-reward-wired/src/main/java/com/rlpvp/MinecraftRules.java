package com.rlpvp;

import java.util.Random;

/**
 * Equipment profiles and the simulator-facing adapter around Minecraft263Combat.
 *
 * Target-kit arithmetic is ported with the same float expressions and ordering as the user-supplied Minecraft 26.3
 * reference methods. Minecraft263Combat is a clean-room, dependency-free port; it does not load Minecraft server
 * classes. The target profile is ordinary unenchanted diamond-sword PvP against full diamond armor with Protection III
 * on all four pieces. Non-target legacy kit modifiers remain compatibility profiles, not 26.3 parity claims.
 */
final class MinecraftRules {
    private MinecraftRules() {}

    /** One armor item in an equipment profile. Values are the item contribution, not player totals. */
    static final class ArmorPiece {
        final String slot;
        final String itemId;
        final double armorPoints;
        final double toughness;
        final int protectionLevel;

        ArmorPiece(String slot, String itemId, double armorPoints, double toughness, int protectionLevel) {
            this.slot = slot;
            this.itemId = itemId;
            this.armorPoints = armorPoints;
            this.toughness = toughness;
            this.protectionLevel = protectionLevel;
        }
    }

    /** Explicit item/armor data for the target kit, derived from the reference version's item attributes. */
    static final class EquipmentProfile {
        final String weaponItemId;
        final double playerBaseAttackDamage;
        final double weaponAttackDamageModifier;
        final double playerBaseAttackSpeed;
        final double weaponAttackSpeedModifier;
        private final ArmorPiece[] armorPieces;

        EquipmentProfile(String weaponItemId, double playerBaseAttackDamage, double weaponAttackDamageModifier,
                         double playerBaseAttackSpeed, double weaponAttackSpeedModifier, ArmorPiece... armorPieces) {
            this.weaponItemId = weaponItemId;
            this.playerBaseAttackDamage = playerBaseAttackDamage;
            this.weaponAttackDamageModifier = weaponAttackDamageModifier;
            this.playerBaseAttackSpeed = playerBaseAttackSpeed;
            this.weaponAttackSpeedModifier = weaponAttackSpeedModifier;
            this.armorPieces = armorPieces.clone();
        }

        double attackDamage() { return playerBaseAttackDamage + weaponAttackDamageModifier; }
        double attackSpeed() { return playerBaseAttackSpeed + weaponAttackSpeedModifier; }
        double totalArmor() {
            double total = 0.0;
            for (ArmorPiece piece : armorPieces) total += piece.armorPoints;
            return total;
        }
        double totalToughness() {
            double total = 0.0;
            for (ArmorPiece piece : armorPieces) total += piece.toughness;
            return total;
        }
        /** Ordinary melee damage is protected by Protection's level on each equipped piece. */
        double genericMeleeProtectionEpf() {
            int total = 0;
            for (ArmorPiece piece : armorPieces) total += piece.protectionLevel;
            return Math.min(20, Math.max(0, total));
        }
        ArmorPiece[] armorPieces() { return armorPieces.clone(); }
    }

    /** Equipment set requested for this training task. Both fighters use this same profile by default. */
    static final EquipmentProfile DIAMOND_PROT3_EQUIPMENT = new EquipmentProfile(
        "minecraft:diamond_sword",
        1.0, 6.0,       // player base attack damage + diamond sword main-hand modifier = 7
        4.0, -2.4,      // player base attack speed + diamond sword modifier = 1.6 (12.5 ticks per full charge)
        new ArmorPiece("head",  "minecraft:diamond_helmet",      3, 2, 3),
        new ArmorPiece("chest", "minecraft:diamond_chestplate",  8, 2, 3),
        new ArmorPiece("legs",  "minecraft:diamond_leggings",    6, 2, 3),
        new ArmorPiece("feet",  "minecraft:diamond_boots",      3, 2, 3)
    );

    /** Damage breakdown for the non-bypassing, ordinary melee damage source used by the default kit. */
    static final class DamageBreakdown {
        final double incomingDamage;
        final double afterArmor;
        final double afterResistance;
        final double protectionEpf;
        final double finalDamage;

        DamageBreakdown(double incomingDamage, double afterArmor, double afterResistance,
                        double protectionEpf, double finalDamage) {
            this.incomingDamage = incomingDamage;
            this.afterArmor = afterArmor;
            this.afterResistance = afterResistance;
            this.protectionEpf = protectionEpf;
            this.finalDamage = finalDamage;
        }
    }

    /** Equipment / status of one fighter. */
    static final class Kit {
        final String name;
        final double weaponDamage;        // total attack-damage attribute; normal diamond sword = 1 + 6 = 7
        final int sharpness;              // Sharpness level (0 = none); unrelated to Protection III target kit
        final double armor, toughness;    // total armor points and armor toughness
        final double protectionEpf;       // applicable protection factor (EPF), capped at 20
        final int resistanceAmp;           // Resistance effect amplifier, -1 = none
        final double knockbackResistance; // attribute range -2..1
        final float absorption;
        final double regenPerTick;        // 0 = off, as on most practice servers
        final double attackSpeed;
        final EquipmentProfile equipment;

        Kit(String name, double weaponDamage, int sharpness, double armor, double toughness, double protectionEpf,
            int resistanceAmp, double knockbackResistance, float absorption, double regenPerTick) {
            this(name, weaponDamage, sharpness, armor, toughness, protectionEpf, resistanceAmp, knockbackResistance,
                 absorption, regenPerTick, 1.6, null);
        }

        Kit(String name, double weaponDamage, int sharpness, double armor, double toughness, double protectionEpf,
            int resistanceAmp, double knockbackResistance, float absorption, double regenPerTick,
            double attackSpeed, EquipmentProfile equipment) {
            this.name = name;
            this.sharpness = sharpness;
            this.resistanceAmp = resistanceAmp;
            this.knockbackResistance = knockbackResistance;
            this.absorption = absorption;
            this.regenPerTick = regenPerTick;
            this.equipment = equipment;
            this.weaponDamage = equipment == null ? weaponDamage : equipment.attackDamage();
            this.armor = equipment == null ? armor : equipment.totalArmor();
            this.toughness = equipment == null ? toughness : equipment.totalToughness();
            this.protectionEpf = equipment == null ? protectionEpf : equipment.genericMeleeProtectionEpf();
            this.attackSpeed = equipment == null ? attackSpeed : equipment.attackSpeed();
        }

        double attackCooldownTicks() { return Minecraft263Combat.attackCooldownDelay(attackSpeed); }
        String profileDescription() {
            if (equipment == null) {
                return name + ": damage=" + weaponDamage + ", armor=" + armor + ", toughness=" + toughness
                    + ", Protection EPF=" + protectionEpf + ", attackSpeed=" + attackSpeed;
            }
            StringBuilder b = new StringBuilder();
            b.append("Kit: ").append(name).append('\n');
            b.append("Weapon: ").append(equipment.weaponItemId).append("; attack damage ")
             .append(equipment.playerBaseAttackDamage).append(" + ").append(equipment.weaponAttackDamageModifier)
             .append(" = ").append(weaponDamage).append("; attack speed ")
             .append(equipment.playerBaseAttackSpeed).append(" + (").append(equipment.weaponAttackSpeedModifier)
             .append(") = ").append(attackSpeed).append("; full cooldown ")
             .append(String.format(java.util.Locale.ROOT, "%.2f", attackCooldownTicks())).append(" ticks\n");
            b.append("Armor:\n");
            for (ArmorPiece piece : equipment.armorPieces()) {
                b.append("  ").append(piece.slot).append(" ").append(piece.itemId).append(": armor ")
                 .append(piece.armorPoints).append(", toughness ").append(piece.toughness)
                 .append(", Protection ").append(piece.protectionLevel).append('\n');
            }
            b.append("Totals: armor ").append(armor).append(", toughness ").append(toughness)
             .append(", melee Protection EPF ").append(protectionEpf).append("/20\n")
             .append("Sword enchantments: none; effects: none; shield: none; absorption/regeneration: ")
             .append(absorption).append("/").append(regenPerTick).append('\n');
            return b.toString();
        }
    }

    /** The old unarmoured regression profile. */
    static final Kit NAKED = new Kit("naked", 7, 0, 0, 0, 0, -1, 0, 0f, 0);
    static final Kit IRON = new Kit("iron", 6, 0, 15, 0, 0, -1, 0, 0f, 0);
    static final Kit DIAMOND = new Kit("diamond", 7, 0, 20, 8, 0, -1, 0, 0f, 0);
    static final Kit DIAMOND_PROT = new Kit("diamond+prot4+sharp3", 7, 3, 20, 8, 16, -1, 0, 0f, 0);
    /** Normal diamond sword + full diamond armor with Protection III on helmet, chestplate, leggings, and boots. */
    static final Kit DIAMOND_PROT3 = new Kit("diamond+prot3", 7, 0, 20, 8, 12, -1, 0, 0f, 0,
        1.6, DIAMOND_PROT3_EQUIPMENT);
    static final Kit NETHERITE = new Kit("netherite+prot4+sharp5", 8, 5, 20, 12, 16, -1, 0.4, 0f, 0);

    private static final Kit[] POOL = {NAKED, NAKED, IRON, DIAMOND, DIAMOND_PROT, NETHERITE};

    static Kit byName(String n) {
        if (n == null) return DIAMOND_PROT3;
        switch (n.toLowerCase(java.util.Locale.ROOT)) {
            case "diamond_prot3": case "prot3": case "diamond-prot3": return DIAMOND_PROT3;
            case "naked": return NAKED;
            case "iron": return IRON;
            case "diamond": return DIAMOND;
            case "diamond_prot": case "prot": return DIAMOND_PROT;
            case "netherite": return NETHERITE;
            default: return DIAMOND_PROT3;
        }
    }

    static Kit random(Random r) { return POOL[r.nextInt(POOL.length)]; }

    /**
     * Ordinary player attack damage, following Player.attack's ordering for this melee model:
     * charge scales base damage by 0.2 + strength^2 * 0.8; the critical-hit multiplier applies to base damage;
     * sword enchantment bonus, if configured, is added using the charge scale. Target kit has no sword enchantments.
     */
    static double attackDamage(Kit attacker, double scale, boolean crit) {
        float s = Minecraft263Combat.clamp((float)(Double.isFinite(scale) ? scale : 0.0), 0.0F, 1.0F);
        float baseDamage = (float)attacker.weaponDamage;
        // The target diamond sword is unenchanted. The optional legacy kit profiles still expose
        // their historical Sharpness test value through getEnchantedDamage's bonus stage.
        float enchantedDamage = baseDamage;
        if (attacker.sharpness > 0) enchantedDamage += (0.5F * attacker.sharpness + 0.5F);
        return Minecraft263Combat.playerAttackDamage(baseDamage, s, crit, enchantedDamage, 0.0F);
    }

    /** Exact CombatRules armor/toughness expression (float arithmetic). */
    static double armorAbsorb(double damage, double armor, double toughness) {
        float incoming = sanitizeDamage((float)damage);
        return Minecraft263Combat.damageAfterArmorAbsorb(incoming, (float)armor, (float)toughness, false);
    }

    static float sanitizeDamage(float damage) {
        if (damage < 0.0F) damage = 0.0F;
        if (Float.isNaN(damage) || Float.isInfinite(damage)) damage = Float.MAX_VALUE;
        return damage;
    }

    /** Vanilla ordering: armor -> Resistance -> Protection; returned finalDamage is before absorption. */
    static DamageBreakdown damageBreakdown(Kit defender, double damage) {
        Minecraft263Combat.DamageResult result = Minecraft263Combat.resolveDamage(
            (float)damage, (float)defender.armor, (float)defender.toughness,
            defender.resistanceAmp, (float)defender.protectionEpf, 0.0F,
            false, false, false, false);
        return new DamageBreakdown(result.incoming, result.afterArmor, result.afterResistance,
            (float)defender.protectionEpf, result.afterProtection);
    }

    static double afterDefense(Kit defender, double damage) {
        return damageBreakdown(defender, damage).finalDamage;
    }

    /** During hurt cooldown, compare new raw damage with lastHurt before armor/effects/enchantments. */
    static double invulnerableExtra(double rawDamage, double lastRawDamage) {
        float raw = sanitizeDamage((float)rawDamage);
        float last = sanitizeDamage((float)lastRawDamage);
        return Minecraft263Combat.invulnerableExcess(raw, last);
    }

    /** LivingEntity.knockback(): power *= 1 - knockback_resistance. */
    static double knockbackStrength(double strength, Kit defender) {
        if (!Double.isFinite(strength)) return 0.0;
        double resistance = Minecraft26Physics.clamp(defender.knockbackResistance, -2.0, 1.0);
        return Minecraft263Combat.knockbackPower(strength, resistance);
    }


    static final int FULL_CHARGE_TICKS = (int) Math.ceil(Config.ENEMY_CHARGE_TICKS - 0.5);
    static final int INVUL_BLOCK_TICKS = 10;

    static double fullHitHp(Kit attacker, Kit defender) {
        return afterDefense(defender, attackDamage(attacker, 1.0, false));
    }

    static int hitsToKill(Kit attacker, Kit defender) {
        double hpPerHit = fullHitHp(attacker, defender);
        if (!(hpPerHit > 0.0) || !Double.isFinite(hpPerHit)) return Integer.MAX_VALUE;
        return (int) Math.ceil((20.0 + defender.absorption) / hpPerHit - 1e-9);
    }

    static int perfectTicksToKill(Kit attacker, Kit defender) {
        int hits = hitsToKill(attacker, defender);
        if (hits == Integer.MAX_VALUE) return Integer.MAX_VALUE;
        return (hits - 1) * Math.max(FULL_CHARGE_TICKS, INVUL_BLOCK_TICKS);
    }

    static int episodeTicks(Kit me, Kit opponent) {
        long ttk = Math.max((long) perfectTicksToKill(me, opponent), (long) perfectTicksToKill(opponent, me));
        if (ttk == Integer.MAX_VALUE) ttk = Config.EPISODE_TICKS_MAX;
        long raw = (long) Math.ceil(Config.EPISODE_KILL_TIME_FACTOR * Math.min(ttk, 100_000L));
        long rounded = ((raw + 19L) / 20L) * 20L;
        return (int) Math.max(Config.EPISODE_TICKS, Math.min(Config.EPISODE_TICKS_MAX, rounded));
    }
}
