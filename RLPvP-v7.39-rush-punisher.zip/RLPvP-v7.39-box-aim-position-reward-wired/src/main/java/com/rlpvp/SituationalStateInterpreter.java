package com.rlpvp;

/**
 * Turns the current observation frame into a compact combat situation.  This is intentionally
 * separate from reward calculation: it describes what is happening, not what the agent is paid.
 * The first Config.FRAME values are the current frame in the stacked observation.
 */
final class SituationalStateInterpreter {
    enum Range { OUT_OF_REACH, APPROACH, EDGE, MELEE, TOO_CLOSE }

    static final class State {
        float ownHealth, enemyHealth;
        float ownForwardVelocity, ownSideVelocity, ownVerticalVelocity;
        float enemyForwardVelocity, enemySideVelocity, enemyVerticalVelocity;
        float enemyRelativeForward, enemyRelativeSide;
        float ownCharge, enemyCharge, ownHurt, enemyHurt;
        float distance, yawErrorDeg, pitchErrorDeg, closingSpeed;
        float enemyFacing, enemySwing, enemySprint, enemyGround, ownGround, ownSprint;
        float lineOfSight, enemyInMyReach, meInEnemyReach, canCrit;
        float ticksSinceEnemySwing, ticksSinceMySwing;
        float lastAttack, lastForward, lastStrafe, lastJump, lastSprint, lastSneak;
        float boundaryProximity, inwardForward, inwardRight;
        boolean incomingThreat, opponentRecovering, attackOpportunity, tradeable, followupWindow, lowHealthDisadvantage;
        Range range;

        boolean aimedEnough() { return Math.abs(yawErrorDeg) <= 18.0f && Math.abs(pitchErrorDeg) <= 16.0f; }
        boolean weaponReady() { return ownCharge >= Config.MIN_ATTACK_STRENGTH_LATE; }
        boolean enemyInRange() { return distance <= Config.ATTACK_REACH + 0.20f || enemyInMyReach > 0.5f; }
    }

    State interpret(float[] obs, float boundaryProximity, float inwardForward, float inwardRight,
                    boolean followupWindow) {
        State s = new State();
        if (obs == null || obs.length < Config.FRAME) return s;
        s.ownHealth = clamp01(obs[0]);
        s.ownForwardVelocity = obs[1]; s.ownSideVelocity = obs[2]; s.ownVerticalVelocity = obs[3];
        s.ownGround = obs[4]; s.ownSprint = obs[5]; s.ownCharge = clamp01(obs[6]); s.ownHurt = clamp01(obs[7]);
        s.distance = Math.max(0f, obs[12] * 6f);
        s.yawErrorDeg = obs[13] * 180f; s.pitchErrorDeg = obs[14] * 90f;
        s.enemyHealth = clamp01(obs[15]);
        s.enemyRelativeForward = clamp(obs[9]); s.enemyRelativeSide = clamp(obs[10]);
        s.enemyForwardVelocity = obs[16]; s.enemySideVelocity = obs[17]; s.enemyVerticalVelocity = obs[18];
        s.enemyGround = obs[19]; s.enemyHurt = clamp01(obs[20]); s.enemyFacing = obs[21];
        s.enemySprint = obs[22]; s.enemySwing = obs[23];
        s.lineOfSight = obs[26];
        s.lastForward = obs[29]; s.lastStrafe = obs[30]; s.lastAttack = obs[31];
        s.lastJump = obs[32]; s.lastSprint = obs[33];
        s.ticksSinceEnemySwing = Math.max(0f, obs[34] * 20f);
        s.enemyCharge = clamp01(obs[42]); s.canCrit = obs[43];
        s.enemyInMyReach = obs[44]; s.meInEnemyReach = obs[45];
        s.ticksSinceMySwing = Math.max(0f, obs[46] * 20f); s.closingSpeed = obs[47];
        s.lastSneak = obs.length > 48 ? obs[48] : 0f;
        s.boundaryProximity = clamp01(boundaryProximity);
        s.inwardForward = clamp(inwardForward); s.inwardRight = clamp(inwardRight);
        s.followupWindow = followupWindow;

        s.range = s.distance > Config.ATTACK_REACH + 0.7f ? Range.OUT_OF_REACH
            : s.distance > Config.ATTACK_REACH + 0.15f ? Range.APPROACH
            : s.distance > 2.15f ? Range.EDGE
            : s.distance > 1.15f ? Range.MELEE : Range.TOO_CLOSE;
        // Swing animation is the strongest immediate cue. Charge/position/facing supply a lower-confidence anticipation cue.
        s.incomingThreat = (s.enemySwing > 0.5f && (s.meInEnemyReach > 0.5f || s.distance < 3.4f))
            || (s.enemyCharge < 0.18f && s.enemyFacing > 0.25f && s.meInEnemyReach > 0.5f && s.distance < 3.1f);
        s.opponentRecovering = s.enemyHurt > 0.25f
            || (!s.incomingThreat && s.enemyCharge < 0.24f && s.ticksSinceEnemySwing < 7f);
        s.attackOpportunity = s.enemyInMyReach > 0.5f && s.lineOfSight > 0.5f
            && Math.abs(s.yawErrorDeg) < 24f && Math.abs(s.pitchErrorDeg) < 22f
            && (s.opponentRecovering || s.enemyFacing < 0.1f || !s.incomingThreat);
        s.tradeable = s.enemyInMyReach > 0.5f && s.lineOfSight > 0.5f && s.ownCharge >= 0.9f
            && Math.abs(s.yawErrorDeg) < 14f && Math.abs(s.pitchErrorDeg) < 14f;
        s.lowHealthDisadvantage = s.ownHealth < s.enemyHealth - 0.18f;
        return s;
    }

    private static float clamp(float v) { return !Float.isFinite(v) ? 0f : Math.max(-1f, Math.min(1f, v)); }
    private static float clamp01(float v) { return !Float.isFinite(v) ? 0f : Math.max(0f, Math.min(1f, v)); }
}
