package com.rlpvp;

import java.util.Locale;

/** Reward shaping, shared by the mod and any offline simulator so both train on the same signal. */
final class Reward {
    private Reward() {}

    static double shaping(long trainTicks) {
        return Math.max(Config.SHAPING_MIN, Math.exp(-trainTicks / (double) Config.SHAPING_TAU_TICKS));
    }

    /**
     * A per-tick decomposition of the base reward. Values are pre-PPO scaling, exactly the
     * contributions returned by {@link #tick}; this is used to audit actual reward mass rather
     * than infer it from constants.
     */
    static final class Breakdown {
        double dealtDamage, takenDamage;
        double facing, pitch, closeness, progress, spacing, hpAdvantage;
        double time, technique;

        void clear() {
            dealtDamage = takenDamage = facing = pitch = closeness = progress = spacing = hpAdvantage = time = technique = 0.0;
        }
        double total() {
            return dealtDamage + takenDamage + facing + pitch + closeness + progress + spacing + hpAdvantage + time + technique;
        }
    }

    /**
     * Windowed audit and technique diagnostics. Reward totals are pre-PPO scaling, so their ratios
     * are the same ratios seen by the learner. The simulator marks server telemetry available and
     * records authoritative packet outcomes; the Fabric client does not pretend it can inspect the
     * server's internal knockback branch.
     */
    static final class Telemetry {
        private double dealtDamageReward, takenDamageReward, softCreditReward;
        private double facingReward, pitchReward, closenessReward, progressReward, spacingReward, hpAdvantageReward;
        private double timeReward, legacyTechniqueReward, discoveryReward, orbitReward, cameraReward;
        private double jumpGuardReward, movementGuardReward, terminalReward, otherReward;
        private double totalReward, positiveReward, negativeRewardMagnitude, absoluteReward;
        private long jumpCommands, jumpStarts, swingAttempts, fallingPhaseSwings, critCandidateSwings;
        private long clientCritLabelHits, clientSprintLabelHits;
        private double clientCritDamageHp, clientSprintDamageHp;
        private long serverAttackAttempts, serverCritAttempts, serverSprintAttempts;
        private long serverCritConfirmed, serverSprintKnockbackConfirmed;
        private double serverCritDamageHp, serverSprintDamageHp;
        private long sprintLaneEligibleTicks;
        private boolean previousJumpCommand;
        private boolean serverTelemetryAvailable;

        void setServerTelemetryAvailable(boolean available) { serverTelemetryAvailable = available; }

        void noteAction(boolean jumpPressed) {
            if (jumpPressed && !previousJumpCommand) jumpCommands++;
            previousJumpCommand = jumpPressed;
        }
        void noteJumpStart() { jumpStarts++; }
        void noteSwing(boolean grounded, double verticalVelocity, boolean fullCharge, boolean sprinting) {
            swingAttempts++;
            boolean falling = !grounded && verticalVelocity < 0.0;
            if (falling) fallingPhaseSwings++;
            if (falling && fullCharge && !sprinting) critCandidateSwings++;
        }
        void noteClientLabelledHit(boolean crit, boolean sprint, double damageHp) {
            if (crit) { clientCritLabelHits++; clientCritDamageHp += Math.max(0.0, damageHp); }
            if (sprint) { clientSprintLabelHits++; clientSprintDamageHp += Math.max(0.0, damageHp); }
        }
        void noteServerAttack(boolean critEligible, boolean sprintEligible) {
            serverAttackAttempts++;
            if (critEligible) serverCritAttempts++;
            if (sprintEligible) serverSprintAttempts++;
        }
        void noteServerResolvedHit(boolean critConfirmed, boolean sprintKnockbackConfirmed, double damageHp) {
            if (critConfirmed) { serverCritConfirmed++; serverCritDamageHp += Math.max(0.0, damageHp); }
            if (sprintKnockbackConfirmed) { serverSprintKnockbackConfirmed++; serverSprintDamageHp += Math.max(0.0, damageHp); }
        }
        void noteSprintLaneOpportunity(boolean eligible) { if (eligible) sprintLaneEligibleTicks++; }

        void addBase(Breakdown b) { addBase(b, 0.0); }
        /** Split soft-hit shaping credit from actual-damage reward without changing the total PPO return. */
        void addBase(Breakdown b, double softCredit) {
            double soft = Math.max(0.0, softCredit);
            dealtDamageReward += b.dealtDamage - Math.min(b.dealtDamage, soft);
            softCreditReward += Math.min(b.dealtDamage, soft);
            takenDamageReward += b.takenDamage;
            facingReward += b.facing; pitchReward += b.pitch; closenessReward += b.closeness;
            progressReward += b.progress; spacingReward += b.spacing; hpAdvantageReward += b.hpAdvantage;
            timeReward += b.time; legacyTechniqueReward += b.technique;
            // Preserve gross positive/negative mass as well as net total; camera/shaping components can
            // otherwise cancel across a window and look deceptively small.
            recordContribution(b.dealtDamage); recordContribution(b.takenDamage);
            recordContribution(b.facing); recordContribution(b.pitch); recordContribution(b.closeness);
            recordContribution(b.progress); recordContribution(b.spacing); recordContribution(b.hpAdvantage);
            recordContribution(b.time); recordContribution(b.technique);
            totalReward += b.total();
        }
        private void recordContribution(double v) {
            if (v > 0.0) positiveReward += v;
            else if (v < 0.0) negativeRewardMagnitude -= v;
            absoluteReward += Math.abs(v);
        }
        void addDiscovery(double v) { discoveryReward += v; totalReward += v; recordContribution(v); }
        void addOrbit(double v) { orbitReward += v; totalReward += v; recordContribution(v); }
        void addCamera(double v) { cameraReward += v; totalReward += v; recordContribution(v); }
        /** Per-term split of the camera reward (progress/overshoot/jerk/still/hold/critWindow), logged so a large camera penalty can be attributed. */
        private final double[] camTerms = new double[CameraReward.TERMS];
        private static final int POSITION_TERMS = CombatPositionReward.TERMS;
        private final double[] positionTerms = new double[POSITION_TERMS];
        void addCameraTerms(double[] t) { for (int i = 0; i < camTerms.length; i++) camTerms[i] += t[i]; }
        /** Adds the position-reward sum to PPO/audit totals and records its per-term decomposition. */
        void addPositionReward(double[] terms) {
            double sum = 0.0;
            if (terms != null) for (int i = 0; i < positionTerms.length && i < terms.length; i++) {
                positionTerms[i] += terms[i];
                sum += terms[i];
            }
            addOther(sum);
        }
        void addJumpGuard(double v) { jumpGuardReward += v; totalReward += v; recordContribution(v); }
        void addMovementGuard(double v) { movementGuardReward += v; totalReward += v; recordContribution(v); }
        void addTerminal(double v) { terminalReward += v; totalReward += v; recordContribution(v); }
        void addOther(double v) { otherReward += v; totalReward += v; recordContribution(v); }

        void mergeWindow(Telemetry x) {
            dealtDamageReward += x.dealtDamageReward; takenDamageReward += x.takenDamageReward; softCreditReward += x.softCreditReward;
            facingReward += x.facingReward; pitchReward += x.pitchReward; closenessReward += x.closenessReward;
            progressReward += x.progressReward; spacingReward += x.spacingReward; hpAdvantageReward += x.hpAdvantageReward;
            timeReward += x.timeReward; legacyTechniqueReward += x.legacyTechniqueReward; discoveryReward += x.discoveryReward;
            for (int i = 0; i < camTerms.length; i++) camTerms[i] += x.camTerms[i];
            for (int i = 0; i < positionTerms.length; i++) positionTerms[i] += x.positionTerms[i];
            orbitReward += x.orbitReward; cameraReward += x.cameraReward; jumpGuardReward += x.jumpGuardReward;
            movementGuardReward += x.movementGuardReward; terminalReward += x.terminalReward; otherReward += x.otherReward;
            totalReward += x.totalReward; positiveReward += x.positiveReward;
            negativeRewardMagnitude += x.negativeRewardMagnitude; absoluteReward += x.absoluteReward;
            jumpCommands += x.jumpCommands; jumpStarts += x.jumpStarts; swingAttempts += x.swingAttempts;
            fallingPhaseSwings += x.fallingPhaseSwings; critCandidateSwings += x.critCandidateSwings;
            clientCritLabelHits += x.clientCritLabelHits; clientSprintLabelHits += x.clientSprintLabelHits;
            clientCritDamageHp += x.clientCritDamageHp; clientSprintDamageHp += x.clientSprintDamageHp;
            serverAttackAttempts += x.serverAttackAttempts; serverCritAttempts += x.serverCritAttempts; serverSprintAttempts += x.serverSprintAttempts;
            serverCritConfirmed += x.serverCritConfirmed; serverSprintKnockbackConfirmed += x.serverSprintKnockbackConfirmed;
            serverCritDamageHp += x.serverCritDamageHp; serverSprintDamageHp += x.serverSprintDamageHp;
            sprintLaneEligibleTicks += x.sprintLaneEligibleTicks;
            serverTelemetryAvailable |= x.serverTelemetryAvailable;
        }

        String summaryAndReset() {
            String s = String.format(Locale.ROOT,
                "reward(pre-scale): dealt %+.3f taken %+.3f soft %+.3f dense[face %+.3f pitch %+.3f close %+.3f progress %+.3f spacing %+.3f lead %+.3f] time %+.3f tech %+.3f discovery %+.3f orbit %+.3f camera %+.3f jumpGuard %+.3f moveGuard %+.3f terminal %+.3f other %+.3f total %+.3f gross(+/−/abs) %.3f/%.3f/%.3f | jump cmd/start %d/%d, swings %d falling %d critCandidates %d, clientLabel crit/sprint %d/%d",
                dealtDamageReward, takenDamageReward, softCreditReward, facingReward, pitchReward, closenessReward,
                progressReward, spacingReward, hpAdvantageReward, timeReward, legacyTechniqueReward,
                discoveryReward, orbitReward, cameraReward, jumpGuardReward, movementGuardReward, terminalReward, otherReward,
                totalReward, positiveReward, negativeRewardMagnitude, absoluteReward, jumpCommands, jumpStarts, swingAttempts, fallingPhaseSwings, critCandidateSwings,
                clientCritLabelHits, clientSprintLabelHits);
            if (serverTelemetryAvailable) {
                s += String.format(Locale.ROOT,
                    " | server attempts=%d critEligible=%d sprintEligible=%d confirmedCrit=%d confirmedSprintKB=%d critConv=%.1f%% sprintKBConv=%.1f%%",
                    serverAttackAttempts, serverCritAttempts, serverSprintAttempts, serverCritConfirmed,
                    serverSprintKnockbackConfirmed,
                    100.0 * serverCritConfirmed / Math.max(1L, serverCritAttempts),
                    100.0 * serverSprintKnockbackConfirmed / Math.max(1L, serverSprintAttempts));
            } else {
                s += " | server-confirmation unavailable in client-only telemetry";
            }
            s += String.format(Locale.ROOT,
                " | client-labelled damage crit/sprint %.2f/%.2f HP | sprintLane eligibleTicks=%d reward=0",
                clientCritDamageHp, clientSprintDamageHp, sprintLaneEligibleTicks);
            StringBuilder cb = new StringBuilder(" | camera terms");
            for (int i = 0; i < camTerms.length; i++) cb.append(String.format(Locale.ROOT, " %s %+.3f", CameraReward.TERM_NAMES[i], camTerms[i]));
            s += cb;
            String[] positionNames = CombatPositionReward.TERM_NAMES;
            StringBuilder pb = new StringBuilder(" | position terms");
            for (int i = 0; i < positionTerms.length; i++) pb.append(String.format(Locale.ROOT, " %s %+.3f", positionNames[i], positionTerms[i]));
            s += pb;
            clearWindow();
            return s;
        }

        static String csvHeader() {
            return "ticks,episodes,dealtDamageReward,takenDamageReward,softCreditReward,facingReward,pitchReward,closenessReward,progressReward,spacingReward,hpAdvantageReward,timeReward,legacyTechniqueReward,discoveryReward,orbitReward,cameraReward,jumpGuardReward,movementGuardReward,terminalReward,otherReward,totalReward,positiveReward,negativeRewardMagnitude,absoluteReward,jumpCommands,jumpStarts,swingAttempts,fallingPhaseSwings,critCandidateSwings,clientCritLabelHits,clientSprintLabelHits,clientCritDamageHp,clientSprintDamageHp,serverTelemetryAvailable,serverAttackAttempts,serverCritAttempts,serverSprintAttempts,serverCritConfirmed,serverSprintKnockbackConfirmed,serverCritDamageHp,serverSprintDamageHp,sprintLaneEligibleTicks,critCandidateRate,serverCritConversionRate,serverSprintKnockbackConversionRate,positionBandReward,positionLookAwayPenalty,positionComboBreakReward,positionConsecutiveHitsPenalty,positionAirborneHitPenalty";
        }
        String csvRow(long ticks, long episodes) {
            return String.format(Locale.ROOT,
                "%d,%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%d,%d,%d,%d,%d,%d,%d,%.4f,%.4f,%s,%d,%d,%d,%d,%d,%.4f,%.4f,%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f",
                ticks, episodes, dealtDamageReward, takenDamageReward, softCreditReward, facingReward, pitchReward,
                closenessReward, progressReward, spacingReward, hpAdvantageReward, timeReward, legacyTechniqueReward,
                discoveryReward, orbitReward, cameraReward, jumpGuardReward, movementGuardReward, terminalReward,
                otherReward, totalReward, positiveReward, negativeRewardMagnitude, absoluteReward, jumpCommands, jumpStarts, swingAttempts, fallingPhaseSwings,
                critCandidateSwings, clientCritLabelHits, clientSprintLabelHits, clientCritDamageHp, clientSprintDamageHp,
                serverTelemetryAvailable, serverAttackAttempts, serverCritAttempts, serverSprintAttempts,
                serverCritConfirmed, serverSprintKnockbackConfirmed, serverCritDamageHp, serverSprintDamageHp,
                sprintLaneEligibleTicks, critCandidateSwings / (double) Math.max(1L, swingAttempts),
                serverCritConfirmed / (double) Math.max(1L, serverCritAttempts),
                serverSprintKnockbackConfirmed / (double) Math.max(1L, serverSprintAttempts),
                positionTerms[0], positionTerms[1], positionTerms[2], positionTerms[3], positionTerms[4]);
        }

        void clearWindow() {
            dealtDamageReward = takenDamageReward = softCreditReward = 0.0;
            facingReward = pitchReward = closenessReward = progressReward = spacingReward = hpAdvantageReward = 0.0;
            timeReward = legacyTechniqueReward = discoveryReward = orbitReward = cameraReward = 0.0;
            jumpGuardReward = movementGuardReward = terminalReward = otherReward = totalReward = 0.0;
            jumpCommands = jumpStarts = swingAttempts = fallingPhaseSwings = critCandidateSwings = 0;
            clientCritLabelHits = clientSprintLabelHits = 0; clientCritDamageHp = clientSprintDamageHp = 0.0;
            serverAttackAttempts = serverCritAttempts = serverSprintAttempts = serverCritConfirmed = serverSprintKnockbackConfirmed = 0;
            serverCritDamageHp = serverSprintDamageHp = 0.0; sprintLaneEligibleTicks = 0;
            positiveReward = negativeRewardMagnitude = absoluteReward = 0.0;
            java.util.Arrays.fill(camTerms, 0.0);
            java.util.Arrays.fill(positionTerms, 0.0);
            // previousJumpCommand and serverTelemetryAvailable are cross-window state/capability flags.
        }
    }

    /** Sprint-lane opportunity is measured, not rewarded. */
    static boolean sprintLaneEligible(double charge, double dist, double yawErrDeg, boolean sprintingForward, double weight) {
        return sprintingForward && charge >= 0.9 && dist >= Config.SPRINT_LANE_MIN
            && dist <= Config.SPRINT_LANE_MAX && yawErrDeg <= Config.SPRINT_LANE_YAW_DEG;
    }

    /** Deprecated: a technique identity must not carry a standalone positive reward. */
    @Deprecated
    static double sprintLane(double charge, double dist, double yawErrDeg, boolean sprintingForward, double weight, double shaping, double idleScale, double denseScale) {
        return 0.0;
    }

    /** Deprecated: per-hit frequency bonuses distorted the policy objective; hit identity is now telemetry-only. */
    @Deprecated
    static double critSatiationBonus(boolean newHit, boolean criticalHit, boolean sprintHit, int recentSwings, int recentCriticals, int recentSprintHits,
                                     double hitUnit, double techWeight) {
        return 0.0;
    }

    /** Deprecated compatibility overload; returns zero by design. */
    @Deprecated
    static double critSatiationBonus(boolean newHit, boolean criticalHit, boolean sprintHit,
                                     int recentSwings, int recentCriticals, int recentSprintHits) {
        return 0.0;
    }

    /** Retired circle-strafe identity reward. Orbiting remains available to the policy and is measured through outcomes. */
    static double orbit(double px, double pz, double cx, double cz, double yawErrDeg, double dist, boolean tookHit, double weight, double denseScale) {
        if (!Config.techniqueRewardsEnabled()) return 0.0;
        if (weight <= 0.0 || tookHit || dist < Config.ORBIT_MIN_DIST || dist > Config.ORBIT_MAX_DIST || yawErrDeg > Config.ORBIT_MAX_YAW_ERR_DEG) return 0.0;
        double pn = Math.hypot(px, pz), cn = Math.hypot(cx, cz);
        if (pn < 1e-6 || cn < 1e-6) return 0.0;
        double rate = Math.abs(Math.atan2(px * cz - pz * cx, px * cx + pz * cz));
        return weight * Config.ORBIT_W * Math.min(1.0, rate / Config.ORBIT_REF_RATE) * denseScale;
    }

    /** Per-tick reward (unscaled). */
    static double tick(float dealt, float taken, double dist, double prevDist, double yawErr, double pitchErr,
                       double shaping, double pitchRamp, Curriculum.Weights w, double idleScale,
                       double charge, double tech, double hpLead) {
        return tick(dealt, taken, dist, prevDist, yawErr, pitchErr, shaping, pitchRamp, w, idleScale, charge, tech, hpLead, 1.0, 1.0, null);
    }

    static double tick(float dealt, float taken, double dist, double prevDist, double yawErr, double pitchErr,
                       double shaping, double pitchRamp, Curriculum.Weights w, double idleScale,
                       double charge, double tech, double hpLead, double dmgScale, double denseScale) {
        return tick(dealt, taken, dist, prevDist, yawErr, pitchErr, shaping, pitchRamp, w, idleScale,
            charge, tech, hpLead, dmgScale, denseScale, null);
    }

    static double tick(float dealt, float taken, double dist, double prevDist, double yawErr, double pitchErr,
                       double shaping, double pitchRamp, Curriculum.Weights w, double idleScale,
                       double charge, double tech, double hpLead, double dmgScale, double denseScale, Breakdown b) {
        if (b != null) b.clear();
        double dmgMultiplier = Config.W_DAMAGE * dmgScale * RewardTuning.get("damage") / 20.0;
        double dealtR = Math.max(0.0, dealt) * dmgMultiplier;
        double takenR = -Math.max(0.0, taken) * dmgMultiplier;
        if (b != null) { b.dealtDamage = dealtR; b.takenDamage = takenR; }

        double dense = 0;
        if (dist < 8.0) {
            double face = shaping * Config.FACING_REWARD * RewardTuning.get("facing") * w.facing * aim(yawErr * 180.0, Config.AIM_YAW_SCALE_DEG);
            double pitch = shaping * Config.PITCH_FACING_REWARD * RewardTuning.get("pitch") * w.pitch * pitchRamp * aim(pitchErr * 90.0, Config.AIM_PITCH_SCALE_DEG);
            dense += face + pitch;
            if (b != null) { b.facing = face; b.pitch = pitch; }
        }
        double closeness = Math.max(0.0, Math.min(1.0, 1.0 - Math.max(0.0, dist - 2.5) / 6.0));
        double closeR = shaping * Config.CLOSENESS_REWARD * RewardTuning.get("closeness") * w.closeness * closeness;
        dense += closeR;
        if (b != null) b.closeness = closeR;
        if (prevDist > Config.PROGRESS_MIN_PREV_DIST && dist < prevDist) {
            double progressR = shaping * Config.PROGRESS_REWARD * RewardTuning.get("progress") * w.progress * Math.min(prevDist - dist, 0.5);
            dense += progressR;
            if (b != null) b.progress = progressR;
        }
        // Spacing: when charged, stand at striking distance; while recharging, stay just outside reach.
        if (charge >= 0.5) {
            if (dist >= Config.SPACING_MIN && dist <= Config.SPACING_MAX) {
                double spacingR = shaping * Config.SPACING_REWARD * RewardTuning.get("spacing") * w.spacing;
                dense += spacingR;
                if (b != null) b.spacing = spacingR;
            }
        } else if (dist > Config.SPACING_MAX && dist <= Config.RETREAT_MAX) {
            double spacingR = shaping * Config.SPACING_REWARD * Config.RETREAT_FRACTION * w.spacing;
            dense += spacingR;
            if (b != null) b.spacing = spacingR;
        }
        // Positive HP lead is a bounded auxiliary signal, included in the audited dense subtotal.
        double leadR = hpLead > 0 ? Config.HP_ADVANTAGE_REWARD * RewardTuning.get("hp_advantage") * w.hpAdv * Math.min(1.0, hpLead) : 0.0;
        dense += leadR;
        if (b != null) b.hpAdvantage = leadR;

        double shapedDense = dense * idleScale * denseScale;
        if (b != null) {
            b.facing *= idleScale * denseScale; b.pitch *= idleScale * denseScale;
            b.closeness *= idleScale * denseScale; b.progress *= idleScale * denseScale;
            b.spacing *= idleScale * denseScale; b.hpAdvantage *= idleScale * denseScale;
        }
        double timeR = Config.TIME_PENALTY * RewardTuning.get("time") * w.time;
        double techR = Config.techniqueRewardsEnabled() ? tech * RewardTuning.get("technique") : 0.0;
        if (b != null) { b.time = timeR; b.technique = techR; }
        return dealtR + takenR + shapedDense + timeR + techR;
    }

    /** Damage multiplier for the kit: 1 for unarmored hits, up to DMG_SCALE_MAX when a typical hit is a small share of what a sword does. */
    static double damageScale(double typicalHit) {
        double h = Math.max(0.25, typicalHit);
        return Math.max(1.0, Math.min(Config.DMG_SCALE_MAX, Math.pow(Config.TECH_HIT_REF / h, Config.DMG_SCALE_EXP)));
    }

    /** Legacy compatibility hook; near-miss pseudo-damage is disabled (returns zero). */
    static float softHp(double typicalHit) { return (float) (Config.SOFT_HIT_FRACTION * Math.min((double) Config.SOFT_HIT_HP, Math.max(0.1, typicalHit))); }
    static float softCapHp(double typicalHit) { return (float) (Config.SOFT_EPISODE_CAP_HP * Math.min(1.0, Math.max(0.1, typicalHit) / Config.SOFT_HIT_HP)); }
    static double denseScale(int episodeTicks) { return Math.max(Config.DENSE_SCALE_MIN, Math.min(1.0, Config.EPISODE_TICKS / (double) Math.max(1, episodeTicks))); }

    static double aim(double errDeg, double scaleDeg) {
        double k = errDeg / scaleDeg;
        return 1.0 / (1.0 + k * k);
    }

    /** Legacy technique payout hook. In this build hit labels and whiff classifications are telemetry-only. */
    static double techBonus(boolean realHit, boolean crit, boolean sprintHit, int combo, boolean firstHit,
                            boolean pointlessWhiff, double techWeight) {
        return techBonus(realHit, crit, sprintHit, combo, firstHit, pointlessWhiff, techWeight, false, false, false, 0.0);
    }

    static double techBonus(boolean realHit, boolean crit, boolean sprintHit, int combo, boolean firstHit,
                            boolean pointlessWhiff, double techWeight, boolean fullCharge, boolean resetGap,
                            boolean punish, double lateWeight) {
        if (!Config.techniqueRewardsEnabled()) return 0.0;
        double b = 0;
        if (realHit) {
            if (crit) b += Config.CRIT_BONUS;
            if (sprintHit) b += Config.SPRINT_HIT_BONUS;
            if (combo >= 2) b += Config.COMBO_BONUS * Math.min(combo - 1, 3);
            if (firstHit) b += Config.FIRST_HIT_BONUS;
        }
        if (pointlessWhiff) b -= Config.WHIFF_PENALTY;
        b *= techWeight;
        if (realHit && lateWeight > 0) {
            double t = 0;
            if (fullCharge) t += Config.FULL_CHARGE_HIT_BONUS;
            if (resetGap) t += Config.RESET_HIT_BONUS;
            if (punish) t += Config.PUNISH_HIT_BONUS;
            b += t * lateWeight;
        }
        return b;
    }

    static boolean isPointlessWhiff(double dist, double yawErr) { return dist > Config.WHIFF_FAR_DIST || yawErr > Config.WHIFF_OFFAIM_YAW; }
    static boolean isPointlessWhiff(double dist, double yawErr, double pitchErr) { return isPointlessWhiff(dist, yawErr) || pitchErr > Config.WHIFF_OFFAIM_PITCH; }
    static double idleScale(int stage, int ticksSinceRealHit) {
        if (stage < 6) return 1.0;
        return Math.max(0.0, Math.min(1.0, 1.0 - (ticksSinceRealHit - Config.IDLE_FREE_TICKS) / (double) Config.IDLE_FADE_TICKS));
    }
    static double terminal(EpisodeOutcome outcome) {
        if (outcome == EpisodeOutcome.WIN) return Config.W_WIN;
        if (outcome == EpisodeOutcome.LOSS) return -Config.W_WIN;
        return 0.0;
    }
    static double terminal(boolean win, boolean meDead) { return terminal(EpisodeOutcome.classify(meDead, win, win, false)); }
}
