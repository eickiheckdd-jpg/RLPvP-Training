package com.rlpvp;

/** High-contrast tactical instrumentation palette. ARGB ints, no Minecraft classes. */
final class HudTheme {
    private HudTheme() {}

    static final int WHITE = 0xFFF5FAFF;
    static final int TEXT = 0xFFE1EAF5;
    static final int DIM = 0xFF8494AD;
    static final int FAINT = 0xFF3B4862;
    static final int GREEN = 0xFF56F0B2;
    static final int LIME = 0xFFC6FF65;
    static final int YELLOW = 0xFFFFD166;
    static final int ORANGE = 0xFFFF9F5A;
    static final int RED = 0xFFFF637C;
    static final int BLUE = 0xFF69AFFF;
    static final int CYAN = 0xFF52E4F7;
    static final int PURPLE = 0xFFB7A0FF;
    static final int PANEL_BG = 0xE80A101D;
    static final int PANEL_EDGE = 0xFF26354D;
    static final int TRACK = 0xFF1B293A;
    static final int GRAPH_BG = 0xFF101B2A;

    static int alpha(int rgb, int a) {
        return ((Math.max(0, Math.min(255, a))) << 24) | (rgb & 0xFFFFFF);
    }

    static int lerp(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    static int ramp(double t) {
        t = Math.max(0, Math.min(1, t));
        return t < 0.5 ? lerp(RED, YELLOW, t * 2) : lerp(YELLOW, GREEN, (t - 0.5) * 2);
    }

    static int hpColor(double frac) { return frac > 0.5 ? GREEN : frac > 0.25 ? YELLOW : RED; }
    static int entropyColor(double e) { return e >= Trainer.entropyFloorNow ? GREEN : e >= Trainer.entropyFloorNow * 0.6 ? YELLOW : RED; }
    static int rateColor(double r) { return r >= 0.5 ? GREEN : r >= 0.25 ? YELLOW : RED; }
    static int distColor(double dist) { return dist <= Config.ATTACK_REACH ? GREEN : dist <= Config.RETREAT_MAX ? YELLOW : RED; }
    static int aimColor(double yawDeg, double pitchDeg) {
        double e = Math.max(Math.abs(yawDeg), Math.abs(pitchDeg) * 1.5);
        return e <= 6 ? GREEN : e <= 20 ? YELLOW : RED;
    }
}
