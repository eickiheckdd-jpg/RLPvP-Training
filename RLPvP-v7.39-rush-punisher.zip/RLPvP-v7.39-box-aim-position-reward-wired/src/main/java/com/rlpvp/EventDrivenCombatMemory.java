package com.rlpvp;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Iterator;

/**
 * Causal transition memory for live play. An attack is not called a hit or a whiff on the next
 * frame: it remains pending for Minecraft's damage-credit window, then resolves against observed
 * health/hurt changes. Hit categories prefer HitMemory's confirmed swing mask and use the stored
 * swing context only as a fallback. This class describes outcomes; it never scripts actions.
 */
final class EventDrivenCombatMemory {
    private static final int MAGIC_V1 = 0x45564D31; // EVM1 legacy counters
    private static final int MAGIC_V2 = 0x45564D32; // EVM2 causal attack outcomes and typed hits
    private static final int FOLLOWUP_TICKS = 20;
    private static final int COMBO_GAP_TICKS = 20;

    private static final int MAX_PENDING_ATTACKS = 8;
    private final float[] previousObs = new float[Config.OBS_SIZE];
    private final ArrayDeque<PendingAttack> pendingAttacks = new ArrayDeque<>();
    private PendingAttack chosenAttack;
    private boolean havePrevious;
    private boolean previousPunishOpportunity;

    private static final class PendingAttack {
        int age;
        float distance, yaw, pitch, forward, strafe;
        float charge, canCrit, sprinting, ground;
        boolean targetOnRay;
    }

    private int followupAge = -1;
    private boolean followupConverted;
    private int repeatedWhiffStreak;

    private long observations, attackAttempts, confirmedHits, normalHits, criticalHits, sprintHits, sweepHits, weakHits;
    private long whiffs, outOfRangeWhiffs, aimWhiffs, sprintHitOpportunities, followupConversions, failedFollowups;
    private long takenHits, punishWindows, punishConversions;
    private long comboChains, comboHits, maxCombo, interruptedCombos;
    private int currentCombo;
    private int ticksSinceOwnHit = 999;
    private double dealtHpProxy, takenHpProxy;
    private double lastWhiffDistance = -1, lastWhiffYaw, lastWhiffPitch;
    private float lastWhiffForward, lastWhiffStrafe;

    static final class Snapshot {
        final boolean followupOpen;
        final double hitRate, whiffRate, repeatedWhiffRisk;
        final double lastWhiffDistance, lastWhiffYaw, lastWhiffPitch;
        final long confirmedHits, whiffs, sprintHits, criticalHits, normalHits, sweepHits, weakHits;
        final long followupConversions, failedFollowups, comboHits, maxCombo;
        final int currentCombo;

        Snapshot(boolean open, double hitRate, double whiffRate, double repeatedRisk,
                 double dist, double yaw, double pitch, long hits, long whiffs, long sprintHits,
                 long criticalHits, long normalHits, long sweepHits, long weakHits,
                 long conversions, long failures, long comboHits, long maxCombo, int currentCombo) {
            this.followupOpen = open; this.hitRate = hitRate; this.whiffRate = whiffRate;
            this.repeatedWhiffRisk = repeatedRisk; this.lastWhiffDistance = dist;
            this.lastWhiffYaw = yaw; this.lastWhiffPitch = pitch; this.confirmedHits = hits;
            this.whiffs = whiffs; this.sprintHits = sprintHits; this.criticalHits = criticalHits;
            this.normalHits = normalHits; this.sweepHits = sweepHits; this.weakHits = weakHits;
            this.followupConversions = conversions; this.failedFollowups = failures;
            this.comboHits = comboHits; this.maxCombo = maxCombo; this.currentCombo = currentCombo;
        }
    }

    void beginEpisode() {
        havePrevious = false;
        pendingAttacks.clear();
        chosenAttack = null;
        previousPunishOpportunity = false;
        followupAge = -1;
        followupConverted = false;
        repeatedWhiffStreak = 0;
        currentCombo = 0;
        ticksSinceOwnHit = 999;
        java.util.Arrays.fill(previousObs, 0f);
    }

    /** Called once at the start of each actPlay tick, before selecting the next action. */
    void observeTransition(float[] obs) {
        if (obs == null || obs.length < Config.FRAME) return;
        observations++;
        if (havePrevious) {
            if (ticksSinceOwnHit < 999) ticksSinceOwnHit++;
            if (currentCombo > 0 && ticksSinceOwnHit > COMBO_GAP_TICKS) currentCombo = 0;
            double enemyDamage = previousObs[15] - obs[15];
            double selfDamage = previousObs[0] - obs[0];
            boolean hurtEdge = obs[20] > 0.25f && previousObs[20] <= 0.15f;
            boolean damageEvent = enemyDamage > 0.001 || hurtEdge;

            if (selfDamage > 0.001) {
                takenHpProxy += selfDamage * 20.0;
                takenHits++;
                if (currentCombo > 0) interruptedCombos++;
                currentCombo = 0;
                ticksSinceOwnHit = 999;
            }

            boolean ownHit = false;
            int hitMask = 0;
            PendingAttack creditedAttack = null;
            if (damageEvent && !pendingAttacks.isEmpty()) {
                // Prefer the newest still-creditable swing: delayed damage should be linked
                // to the closest preceding attack pulse, while older overlapping attempts
                // remain pending and resolve as misses if they never receive damage credit.
                Iterator<PendingAttack> reverse = pendingAttacks.descendingIterator();
                while (reverse.hasNext()) {
                    PendingAttack pending = reverse.next();
                    if (pending.age <= Config.HIT_CREDIT_TICKS) {
                        creditedAttack = pending;
                        break;
                    }
                }
            }
            if (creditedAttack != null) {
                pendingAttacks.remove(creditedAttack);
                ownHit = true;
                hitMask = confirmedHitMask(obs, enemyDamage > 0.001, creditedAttack);
                classifyHit(hitMask);
                confirmedHits++;
                comboHits++;
                if (currentCombo == 0) comboChains++;
                currentCombo++;
                ticksSinceOwnHit = 0;
                maxCombo = Math.max(maxCombo, currentCombo);
                if (enemyDamage > 0) dealtHpProxy += enemyDamage * 20.0;
                repeatedWhiffStreak = 0;
                boolean punishOpportunity = previousObs[20] > 0.3f && previousObs[6] > 0.5f
                    && previousObs[12] * 6f < 3.4f;
                if (punishOpportunity) punishConversions++;
            }

            // Each emitted attack pulse receives its own credit window. This matters near
            // the relaxed 0.5 charge threshold, where another swing can be emitted before
            // the preceding six-tick damage-credit window has fully expired.
            Iterator<PendingAttack> pendingIterator = pendingAttacks.iterator();
            while (pendingIterator.hasNext()) {
                PendingAttack pending = pendingIterator.next();
                pending.age++;
                if (pending.age > Config.HIT_CREDIT_TICKS) {
                    resolveWhiff(pending);
                    pendingIterator.remove();
                }
            }

            // Resolve a previously opened sprint-hit follow-up before opening a new one. A second
            // sprint hit can therefore convert the first opportunity and begin another chain.
            if (followupAge >= 0 && !followupConverted) {
                followupAge++;
                if (ownHit && followupAge > 0 && followupAge <= FOLLOWUP_TICKS) {
                    followupConversions++;
                    followupConverted = true;
                    followupAge = -1;
                } else if (followupAge >= FOLLOWUP_TICKS) {
                    failedFollowups++;
                    followupAge = -1;
                    followupConverted = false;
                }
            }
            if (ownHit && (hitMask & HitMemory.SPRINT) != 0) {
                sprintHitOpportunities++;
                followupAge = 0;
                followupConverted = false;
            }
            boolean punishOpportunity = previousObs[20] > 0.3f && previousObs[6] > 0.5f
                && previousObs[12] * 6f < 3.4f;
            if (punishOpportunity && !previousPunishOpportunity) punishWindows++;
            previousPunishOpportunity = punishOpportunity;
        }
        System.arraycopy(obs, 0, previousObs, 0, Math.min(obs.length, previousObs.length));
        havePrevious = true;
    }

    private int confirmedHitMask(float[] obs, boolean healthDamageConfirmed, PendingAttack creditedAttack) {
        if (Config.COMPACT_126 && healthDamageConfirmed && obs.length >= Config.COMPACT_OBS_SIZE) {
            // The compact vector stores the last confirmed hit mask as a four-bit packed scalar.
            return ObsStack.decodeHitMask(obs[ObsStack.HIT_TYPE_SLOT]);
        }
        int offset = ObsLayout.summaryOffset();
        if (!Config.COMPACT_126 && Config.MEMORY && healthDamageConfirmed && obs.length >= offset + Config.SUMMARY_BASE) {
            return summaryHitMask(obs, offset);
        }
        // Fallback for hurt-animation-only servers or a damage event not reflected in the
        // hit summary. This is an estimate based on swing context, not a claim about an exact
        // Minecraft hit type.
        if (creditedAttack == null) return 0;
        PendingAttack p = creditedAttack;
        if (p.charge < Config.FULL_CHARGE) return HitMemory.WEAK;
        if (p.canCrit > 0.5f && p.sprinting < 0.5f) return HitMemory.CRIT;
        if (p.sprinting > 0.5f) return HitMemory.SPRINT;
        if (p.ground > 0.5f) return HitMemory.SWEEP;
        return 0;
    }

    private static int summaryHitMask(float[] obs, int offset) {
        int mask = 0;
        if (obs[offset + 1] > 0.5f) mask |= HitMemory.CRIT;
        if (obs[offset + 2] > 0.5f) mask |= HitMemory.SPRINT;
        if (obs[offset + 3] > 0.5f) mask |= HitMemory.SWEEP;
        if (obs[offset + 4] > 0.5f) mask |= HitMemory.WEAK;
        return mask;
    }

    private void classifyHit(int mask) {
        if ((mask & HitMemory.CRIT) != 0) criticalHits++;
        else if ((mask & HitMemory.SPRINT) != 0) sprintHits++;
        else if ((mask & HitMemory.WEAK) != 0) weakHits++;
        else if ((mask & HitMemory.SWEEP) != 0) sweepHits++;
        else normalHits++;
    }

    private void resolveWhiff(PendingAttack pending) {
        whiffs++;
        // A target-ray click with no credited health change is not an aim/range miss; it may
        // have met an invulnerability window or another no-damage condition. Keep it as an
        // unresolved attempt, but do not mislabel it as a geometry/aim failure.
        boolean outside = !pending.targetOnRay && pending.distance > Config.ATTACK_REACH + 0.12f;
        boolean badAim = !pending.targetOnRay && (Math.abs(pending.yaw) > 20f || Math.abs(pending.pitch) > 18f);
        if (outside) outOfRangeWhiffs++;
        if (badAim) aimWhiffs++;
        if (repeatedWhiffStreak < 8) repeatedWhiffStreak++;
        lastWhiffDistance = pending.distance;
        lastWhiffYaw = pending.yaw;
        lastWhiffPitch = pending.pitch;
        lastWhiffForward = pending.forward;
        lastWhiffStrafe = pending.strafe;
    }

    /** Store the final policy action after play-mode reranking and safety validation. */
    void recordChosen(float[] obs, float[] action, int mask, float attackGate) {
        chosenAttack = null;
        if (obs == null || action == null) return;
        float gate = Float.isFinite(attackGate) ? Math.max(0f, Math.min(1f, attackGate)) : Config.MIN_ATTACK_STRENGTH;
        if (action.length > 4 && action[4] > 0.5f && (mask & ActionMask.LOCK_ATTACK) == 0
                && obs.length > 14 && obs[6] >= gate) {
            PendingAttack pending = new PendingAttack();
            pending.distance = Math.max(0f, obs[12] * 6f);
            pending.yaw = obs[13] * 180f;
            pending.pitch = obs[14] * 90f;
            pending.forward = action.length > 2 ? action[2] : 0f;
            pending.strafe = action.length > 3 ? action[3] : 0f;
            pending.charge = obs[6];
            pending.canCrit = obs.length > 43 ? obs[43] : 0f;
            pending.sprinting = obs[5];
            pending.ground = obs[4];
            chosenAttack = pending;
        }
        System.arraycopy(obs, 0, previousObs, 0, Math.min(obs.length, previousObs.length));
        havePrevious = true;
    }

    /**
     * Confirm whether ActionApplier actually queued the click. Policy intent alone is not an
     * emitted attack: a screen, block ray, cooldown, or unavailable game mode can suppress it.
     */
    void recordAppliedSwing(boolean clickQueued, boolean targetOnRay) {
        PendingAttack pending = chosenAttack;
        chosenAttack = null;
        if (!clickQueued || pending == null) return;
        pending.targetOnRay = targetOnRay;
        if (pendingAttacks.size() >= MAX_PENDING_ATTACKS) resolveWhiff(pendingAttacks.removeFirst());
        pendingAttacks.addLast(pending);
        attackAttempts++;
    }

    boolean followupOpen() { return followupAge >= 0 && !followupConverted && followupAge < FOLLOWUP_TICKS; }
    int followupAge() { return followupAge; }

    Snapshot snapshot() {
        double hr = attackAttempts > 0 ? (double) confirmedHits / attackAttempts : 0;
        double wr = attackAttempts > 0 ? (double) whiffs / attackAttempts : 0;
        double repeated = Math.min(1.0, repeatedWhiffStreak / 4.0);
        return new Snapshot(followupOpen(), hr, wr, repeated, lastWhiffDistance, lastWhiffYaw,
            lastWhiffPitch, confirmedHits, whiffs, sprintHits, criticalHits, normalHits, sweepHits,
            weakHits, followupConversions, failedFollowups, comboHits, maxCombo, currentCombo);
    }

    String status() {
        double wr = attackAttempts == 0 ? 0 : (100.0 * whiffs / attackAttempts);
        return String.format(java.util.Locale.ROOT,
            "situational: hits=%d (normal=%d, crit=%d, sprint=%d, sweep=%d, weak=%d), attacks=%d, whiffs=%d (%.1f%%; range=%d aim=%d), follow-ups=%d/%d failed=%d, combo=%d max=%d chains=%d interrupted=%d, punish=%d/%d, incoming=%d, damage proxy=%.1f/%.1f, frames=%d",
            confirmedHits, normalHits, criticalHits, sprintHits, sweepHits, weakHits, attackAttempts, whiffs, wr,
            outOfRangeWhiffs, aimWhiffs, followupConversions, sprintHitOpportunities, failedFollowups,
            currentCombo, maxCombo, comboChains, interruptedCombos, punishConversions, punishWindows,
            takenHits, dealtHpProxy, takenHpProxy, observations);
    }

    void write(DataOutput out) throws IOException {
        out.writeInt(MAGIC_V2);
        out.writeLong(observations); out.writeLong(attackAttempts); out.writeLong(confirmedHits);
        out.writeLong(normalHits); out.writeLong(criticalHits); out.writeLong(sprintHits); out.writeLong(whiffs);
        out.writeLong(outOfRangeWhiffs); out.writeLong(aimWhiffs); out.writeLong(sprintHitOpportunities);
        out.writeLong(followupConversions); out.writeLong(failedFollowups); out.writeLong(takenHits);
        out.writeLong(punishWindows); out.writeLong(punishConversions); out.writeDouble(dealtHpProxy); out.writeDouble(takenHpProxy);
        out.writeInt(repeatedWhiffStreak); out.writeDouble(lastWhiffDistance); out.writeDouble(lastWhiffYaw); out.writeDouble(lastWhiffPitch);
        out.writeFloat(lastWhiffForward); out.writeFloat(lastWhiffStrafe);
        out.writeLong(sweepHits); out.writeLong(weakHits); out.writeLong(comboChains); out.writeLong(comboHits);
        out.writeLong(maxCombo); out.writeLong(interruptedCombos);
    }

    void read(DataInput in) throws IOException {
        int magic = in.readInt();
        if (magic != MAGIC_V1 && magic != MAGIC_V2) return;
        observations = nonnegative(in.readLong()); attackAttempts = nonnegative(in.readLong()); confirmedHits = nonnegative(in.readLong());
        normalHits = nonnegative(in.readLong()); criticalHits = nonnegative(in.readLong()); sprintHits = nonnegative(in.readLong()); whiffs = nonnegative(in.readLong());
        outOfRangeWhiffs = nonnegative(in.readLong()); aimWhiffs = nonnegative(in.readLong()); sprintHitOpportunities = nonnegative(in.readLong());
        followupConversions = nonnegative(in.readLong()); failedFollowups = nonnegative(in.readLong()); takenHits = nonnegative(in.readLong());
        punishWindows = nonnegative(in.readLong()); punishConversions = nonnegative(in.readLong());
        dealtHpProxy = finite(in.readDouble()); takenHpProxy = finite(in.readDouble());
        repeatedWhiffStreak = Math.max(0, Math.min(8, in.readInt())); lastWhiffDistance = finite(in.readDouble());
        lastWhiffYaw = finite(in.readDouble()); lastWhiffPitch = finite(in.readDouble());
        lastWhiffForward = finiteFloat(in.readFloat()); lastWhiffStrafe = finiteFloat(in.readFloat());
        if (magic == MAGIC_V2) {
            sweepHits = nonnegative(in.readLong()); weakHits = nonnegative(in.readLong());
            comboChains = nonnegative(in.readLong()); comboHits = nonnegative(in.readLong());
            maxCombo = nonnegative(in.readLong()); interruptedCombos = nonnegative(in.readLong());
        }
        beginEpisode();
    }

    private static long nonnegative(long v) { return Math.max(0, v); }
    private static double finite(double v) { return Double.isFinite(v) ? v : 0; }
    private static float finiteFloat(float v) { return Float.isFinite(v) ? v : 0f; }
}
