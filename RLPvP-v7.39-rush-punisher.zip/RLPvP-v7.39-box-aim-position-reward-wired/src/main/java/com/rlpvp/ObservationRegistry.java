package com.rlpvp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

/** Named registry for existing frame features. Disabling features zeroes their columns without changing checkpoint dimensions. */
final class ObservationRegistry {
    private static final Map<String, int[]> FEATURES = new LinkedHashMap<>();
    private static final boolean[] DISABLED = new boolean[Config.FRAME];
    private static final float[] SCALE = new float[Config.FRAME];
    static {
        java.util.Arrays.fill(SCALE, 1.0f);
        FEATURES.put("own_health", new int[]{0});
        FEATURES.put("own_velocity", new int[]{1, 2, 3});
        FEATURES.put("own_ground", new int[]{4});
        FEATURES.put("own_sprint", new int[]{5});
        FEATURES.put("own_cooldown", new int[]{6});
        FEATURES.put("own_hurt", new int[]{7});
        FEATURES.put("own_pitch", new int[]{8});
        FEATURES.put("target_position", new int[]{9, 10, 11, 12});
        FEATURES.put("yaw_error", new int[]{13, 40});
        FEATURES.put("pitch_error", new int[]{14, 41});
        FEATURES.put("target_health", new int[]{15});
        FEATURES.put("target_velocity", new int[]{16, 17, 18});
        FEATURES.put("target_ground", new int[]{19});
        FEATURES.put("target_hurt", new int[]{20});
        FEATURES.put("target_facing", new int[]{21});
        FEATURES.put("target_sprint", new int[]{22});
        FEATURES.put("target_swing", new int[]{23});
        FEATURES.put("hit_timers", new int[]{24, 25, 34, 46});
        FEATURES.put("line_of_sight", new int[]{26});
        FEATURES.put("last_action", new int[]{27, 28, 29, 30, 31, 32, 33});
        FEATURES.put("curriculum_locks", new int[]{35, 36, 37, 38, 39, 50});
        FEATURES.put("combat_timing", new int[]{42, 43, 44, 45, 47});
        FEATURES.put("sneak", new int[]{48, 49});
        Properties p = new Properties();
        Path file = Path.of(System.getProperty("rlpvp.observations.path", "config/rlpvp-observations.properties"));
        if (Files.isRegularFile(file)) try (var in = Files.newInputStream(file)) { p.load(in); }
        catch (IOException ignored) { /* use full observation */ }
        String disabled = p.getProperty("observations.disable", "");
        for (String name : disabled.split(",")) {
            int[] indices = FEATURES.get(name.trim());
            if (indices != null) for (int index : indices) if (index >= 0 && index < DISABLED.length) DISABLED[index] = true;
        }
        // Multipliers let experiments mute or emphasize existing semantic groups without changing the saved observation shape.
        for (Map.Entry<String, int[]> feature : FEATURES.entrySet()) {
            String raw = p.getProperty("observations.scale." + feature.getKey(), "1.0");
            float scale;
            try { scale = Float.parseFloat(raw.trim()); }
            catch (RuntimeException ex) { scale = 1.0f; }
            if (!Float.isFinite(scale)) scale = 1.0f;
            scale = Math.max(0.0f, Math.min(10.0f, scale));
            for (int index : feature.getValue()) if (index >= 0 && index < SCALE.length) SCALE[index] = scale;
        }
    }
    private ObservationRegistry() {}
    static float[] apply(float[] frame) {
        if (frame == null) return null;
        int n = Math.min(frame.length, DISABLED.length);
        for (int i = 0; i < n; i++) frame[i] = DISABLED[i] ? 0f : frame[i] * SCALE[i];
        return frame;
    }
    static String names() { return String.join(",", FEATURES.keySet()); }
}
