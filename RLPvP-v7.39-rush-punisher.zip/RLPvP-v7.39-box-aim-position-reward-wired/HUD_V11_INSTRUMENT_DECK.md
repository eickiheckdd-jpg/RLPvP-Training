# HUD v11 – Instrument Deck (RlHud.java rewrite)

Only RlHud.java (21 KB -> ~62 KB) and one line of RlCommands.java changed. The `RlHud.Data` record, `KEY_*` constants, `render(GuiGraphics)`
and `command(String)` keep their signatures, so Trainer.java needs no change. HudDraw / HudState / HudTheme are reused, not duplicated.

New widgets: AIM PIPELINE (requested -> filtered -> actual per axis, lag %, yaw trace), COMBAT INTEL (intent, confidence, safety / rejected-attack /
sprint-fix / boundary counters that Data carried but the HUD never showed), MOTION (own vs enemy speed, pace verdict), crosshair assist (charge
meter with swing notch + off-axis pointer), alert strip, full training panel (stage track, win/loss split, dealt/taken, whiff/crit/sprint meters,
return sparkline, entropy vs floor, recent results).
Improved: target lock (smoothed bars, ghost damage trail, hit flashes, HP lead, aim box), live signals (spacing window, closing/opening speed,
READY pulse, episode clock), radar (range rings, reach ring, view cone, enemy trail, bearing), input stream (CPS, swing-result chip), dials (lit sweep).
Layout: height-aware auto-stacking columns (a widget that would hit the hotbar is skipped), slide-in, time-based animation, opacity, flip.

Commands: /rl hud [on|off|auto|combat|training|diag|full|mini|flip|reset|status|opacity <25-100>|toggle <widget>]

Verification: compiled with javac against small stubs of GuiGraphics/Font/Minecraft plus the real HudDraw/HudState/HudTheme/Config/Curriculum;
rendered headlessly at 320x180, 427x240, 480x270 and 640x360 to PNG and inspected. NOT built with Gradle / not run inside Minecraft 26.3, so
the real font metrics and the GuiGraphics.drawString signature on 26.3 are unverified (the original code used the same calls).
