# Crit Satiation, Sprint-Reset Readiness, and PPO Entropy Taper

## Implemented

### 1. Crit satiation reward

`Reward.critSatiationBonus(...)` now adds a reward once per newly confirmed landed hit in both the Minecraft-side trainer (`Trainer`) and the offline simulator (`PvpSim`):

- Critical hit with rolling crit density `<= 0.35`: `+2.0`
- Critical hit with rolling crit density `> 0.35`: `+0.2`
- Sprint hit: `+3.5` (takes precedence if hit labels ever overlap)
- Ordinary hit or an already-consumed/split health update: `+0.0`

The density uses `HitMemory`'s rolling 96-tick swing / landed-hit counts, with `totalSwings = recentMySwings + 1.0`. Existing damage, exchange, and terminal rewards are preserved.

### 2. `sprint_reset_ready` observation

Added feature index 11 to the appended combat-observation block, increasing its size from 11 to 12 without moving existing feature indices. The flag is `1.0` only when the agent is currently sprinting, the observed since-hit age is `> 10` ticks or `-1`, and forward has been released at least once since the most recent landed hit. A new hit clears that release latch. This avoids claiming reset readiness just because time passed while W remained held; it is still an observation proxy, not a guarantee of Minecraft server-side knockback.

The source-layout migration recognizes pre-change 11-feature combat checkpoints. Existing 11 features retain their positions; the new feature starts with zero input weights in an old checkpoint.

### 3. Late-stage PPO entropy taper

This repository's curriculum currently has **eight stages**, not nine. Instead of inventing a new curriculum stage, the Java PPO trainer now tapers the entropy coefficient in stage 8 (and any future stage 9+) from `1.0x` to `0.4x` linearly over 300,000 ticks after entering that stage. With `ENTROPY_COEF = 0.004`, the coefficient reaches `0.0016` before the existing anti-collapse floor boost. The schedule is wired into the regular trainer, single-process simulator, and parallel simulator trainer. The continuous camera/Gaussian entropy gradient now uses the same scheduled coefficient as the discrete policy heads.

## Verification

- `bash tests/run.sh` — **passed**.
- Added checks for the crit thresholds, sprint-hit override, entropy schedule, reset-ready threshold / forward release latch, and appended observation migration.
- Loaded and re-saved both the pre-change `checkpoint-1200000.bin` and the current `state.bin` (1,425,000 ticks) using the new checkpoint migration; both loaded and reloaded successfully, and the source files were unchanged.
- A full Gradle build could not be completed because the wrapper needed to download Gradle 9.5.1 and DNS/network access to `services.gradle.org` was unavailable in this environment. This is an environment limitation, not a reported compile failure from the test suite.

## Training state

No `PvpSim`, `PvpEval`, or training-pipeline process was running at the time of the implementation check. Training was **not restarted**. The existing log's latest progress row is 1,425,000 ticks; the state file loads as 1,425,000 ticks / stage 8. The existing run artifacts were left in place.
