# RLPvP v7.36 — Technique Opportunity Audit

## Scope

This change adds a measurement-only audit for choosing and converting critical-hit and sprint-knockback opportunities. It is deliberately not a hand-written combat controller and does not force any technique.

The existing outcome-first PPO policy remains in control. No technique reward bonus, action override, action mask, extra policy input, new action, checkpoint field, or model-layout change was introduced. The existing aim and Minecraft-port combat mechanics are untouched.

## What is measured

For each technique category (`crit`, `sprint`, and baseline `other`), the audit records:

1. Mechanically plausible opportunity windows.
2. Whether the policy selected its attack head at least once during the window.
3. Actual swing attempts, separately from policy selection.
4. Client-side ray/target selection, separately from an attempted swing.
5. Confirmed hits and effective HP damage, split between authoritative simulator-server resolution and mod-side credited HP telemetry. Lethal overkill is excluded so the simulator's value matches its effective HP-delta accounting.
6. Mean distance and absolute yaw/pitch error at the beginning of each completed opportunity window.
7. Ambiguous mutually-exclusive hit labels, retained in the baseline bucket instead of being silently double-counted.

A window is a continuous run of ticks satisfying the recorded eligibility checks; it is counted once when it closes. A window still open at an episode boundary is marked `censored`, not as an unselected opportunity. A truncated window can still be marked `selected` if the policy did select the attack head before the episode ended; `selected` and `censored` are therefore allowed to overlap. Windows spanning log boundaries remain open in worker state and are counted when they eventually close.

## Eligibility definition

An opportunity window requires:

- the existing policy attack head is unlocked;
- clear line of sight;
- target hitbox within the configured attack reach;
- attack charge strictly greater than `Config.FULL_CHARGE`;
- for criticals: the existing observation's falling/not-sprinting posture;
- for sprint knockback: the observed sprinting state.

These are telemetry eligibility checks, not action requirements or assertions that the server must accept the hit. The actual server can still reject or classify an attack differently due to timing, state changes, invulnerability, packet ordering, or other mechanics. This distinction is intentional.

The audit's swing label uses the simulator/server strict `> FULL_CHARGE` threshold. The pre-existing inclusive `>= FULL_CHARGE` label used by the memory/reward path was not changed, to avoid altering existing training semantics.

## CSV output

- Fabric mod training: `config/rlpvp/technique-opportunity-audit.csv`
- Parallel simulator training: `<checkpoint>.technique-opportunity-audit.csv`

Each category contains the following fields:

`opportunities, selected, notSelected, censored, opportunitySwingAttempts, opportunityTargetSelected, swingAttempts, targetSelected, confirmedHits, serverResolvedHits, clientCreditedHits, damageHp, selectionRate, targetRate, hitRate, meanOpportunityDistance, meanOpportunityYawError, meanOpportunityPitchError, ambiguousLabels`

`opportunitySwingAttempts` and `opportunityTargetSelected` count typed swing attempts that occurred while that specific opportunity window was open. The global swing/target counters also include typed attempts outside a valid range/line-of-sight opportunity, which helps separate mechanics/positioning failures from decisions made inside a valid window.

Rates are descriptive ratios with a zero-safe denominator:

- `selectionRate = selected / opportunities`
- `targetRate = targetSelected / swingAttempts`
- `hitRate = confirmedHits / swingAttempts`

Do not compare `serverResolvedHits` and `clientCreditedHits` as if they were two independent hit populations across different runtimes. The simulator reports authoritative server-resolved hit events; the mod currently reports hits credited by observed HP changes. They intentionally have separate columns because their evidence sources differ.

## Integration points

- `Trainer`: records policy selections, queued swing labels, and mod-side credited damage; emits the audit alongside the existing training/reward logs.
- `PvpSim`: records the same opportunity/selection/swing sequence and authoritative server-resolved hit outcomes.
- `ParallelPvpTrain`: merges each worker's closed-window counters and writes one aggregate audit row per training log interval.
- `tests/TechniqueOpportunityAuditCheck.java`: validates window closure/censoring, all three technique categories, independent event counters, source separation, ambiguity handling, strict charge boundary, CSV column alignment, merge, and clear behavior.

## Why this is the first change

Current rewards are configured outcome-first and technique identity rewards are disabled. Increasing sprint-hit or critical-hit rewards to target a percentage would teach frequency rather than decision quality and could make the policy exploit the reward. The new audit establishes the missing opportunity -> selection -> attempt -> ray selection -> confirmed outcome chain. Once representative windows exist, a later policy/reward change can be justified by evidence (for example, whether opportunities are ignored, selected but not attempted, or attempted but not converted).

This commit therefore improves diagnosis and evaluation; it does not claim to have already changed the learned policy's behavior or improved win rate.

## Verification

Passed:

- `sh sim/regression.sh` (includes `TechniqueOpportunityAuditCheck`)
- `sh sim/modelinfo.sh` (observation size 446, 14 actions, checkpoint/model shape unchanged)
- Parallel trainer Java compilation using the exact `javac` source list from `sim/train_parallel.sh`
- `sh sim/aimstability.sh`

Known unrelated limitations in this source archive:

- `sh tests/run.sh` reaches the existing `GameplayRotationCheck` and reports four failures in the small-correction, overshoot/stability, and fine-aim cases. The change does not touch camera/aim code. `sim/aimstability.sh` passes its separate pipeline checks.
- The full Fabric/Gradle build could not be completed because the wrapper needs Gradle 9.5.1 from `services.gradle.org`, and DNS/network access was unavailable in this environment.
- `sim/prediction.sh` has a pre-existing compile mismatch in `CombatPredictionEval.java` against the `EventDrivenCombatMemory.Snapshot` constructor; this is unrelated to the audit.

No claim is made that a live Minecraft client or the full Fabric build was verified here.
