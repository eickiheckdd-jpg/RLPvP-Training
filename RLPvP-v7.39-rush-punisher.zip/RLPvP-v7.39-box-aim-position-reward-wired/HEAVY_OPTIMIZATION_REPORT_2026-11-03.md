# RLPvP v7.38 — Learning-Preserving Heavy Optimization Pass

**Candidate only.** This package is intended to speed up training without changing what the AI is trained to do. It does not replace or edit an already-running training process or checkpoint.

## Summary

The main live-training bottleneck identified by the 20-second Java Flight Recorder sample was GRU replay/backpropagation on the single learner thread. The sample had 1,915 execution samples; the learner thread dominated, with `GruCell.backWindow` and `GruCell.core` the largest hot methods. The acting environment threads used substantially less CPU time during that capture.

The main new optimization is a one-sample-ahead GRU replay pipeline. It uses a dedicated daemon thread and a second, forward-only GRU cell to compute the next minibatch sample's recurrent forward window while the learner thread processes the current sample's policy/value gradients and GRU backpropagation. The second cell receives an exact copy of the learner's GRU weights at the start of each minibatch. Its completed forward caches and observation are copied back; all trainable gradients are still accumulated, in the original order, by the original learner GRU.

The pipeline is enabled by default when GRU training is enabled. Set `-Drlpvp.gruPrefetch=false` to use the original synchronous replay path. A prefetch exception falls back to synchronous replay rather than continuing with an incomplete cache.

## Why this preserves the learning target

No training objective or combat behavior was changed:

- Same observation vector, feature ordering, and 126-input compact layout.
- Same action sampling, RNG call sites, policy and value networks, PPO clipping, GAE, advantage normalization, entropy calculation, KL adaptation, minibatch and epoch order.
- Same GRU weights, equations, sequence boundaries, BPTT window, backpropagation code, gradient accumulation order, Adam state and update cadence.
- Same reward functions, reward configuration values, curriculum, PFSP/league, opponent sampling, simulator combat formulas, kit, latency model, aim and movement decisions.
- No scripted combos, fixed crit/sprint/dodge behavior, aiming corrections, or reward changes.

The replay worker only computes deterministic forward values for the *next* sample using a bit-identical copy of the current minibatch's GRU weights. The learner copies that sample's cached hidden states/gates into its own GRU and then runs the unchanged backward pass. The learner's GRU weights are not updated until the minibatch ends, and every prefetched task is awaited before that update. No random numbers are drawn by the worker.

The previous safe allocation work remains in the candidate: reusable simulator packet/entity/frame scratch, scalarized hot ray/frame calculations, compact-observation reuse only at synchronous simulator call sites, one-time parsing of immutable reward-sidecar values, and direct copy of persisted consequence-model state rather than serializing it to a temporary byte array.

## Tests and exactness checks

1. `bash sim/regression.sh` — completed successfully, including the simulator network, combat outcome, sprint follow-up, Minecraft physics/combat, diamond Prot III kit, opponent league/PFSP, compact observation and GRU migration/regression checks.
2. `GruCellCheck` — passed finite-difference BPTT gradient validation, acting-step/window equivalence, and a new check that a copied replay cache produces an exactly equal BPTT gradient array.
3. `ConsequenceStateCopyCheck` — passed: direct persisted-state copy serializes byte-for-byte identically to its source.
4. Same-seed end-to-end simulator run, 8,192 ticks, seed `765432`, 126 observations, GRU training enabled, diamond Prot III kit:
   - synchronous replay (`-Drlpvp.gruPrefetch=false`): checkpoint SHA-256 `04a6e6658dbc8840674954f897e6d1359cdab33694ff29925e9ad41a6c5e189e`
   - prefetched replay (`-Drlpvp.gruPrefetch=true`): checkpoint SHA-256 `04a6e6658dbc8840674954f897e6d1359cdab33694ff29925e9ad41a6c5e189e`
   - The checkpoint files were byte-for-byte identical after the same 8,192-tick training run.

The full `tests/run.sh` command compiled the test set and passed the tests reached, but hit the execution timeout during the pre-existing, computationally heavy `ConsequenceModelCheck`. The smaller dedicated `ConsequenceStateCopyCheck` completed successfully. The full Fabric/Gradle `compileJava` task could not be run because the wrapper needed to download Gradle 9.5.1 and network DNS was unavailable. The simulator source and tests did compile with the installed JDK.

## Measured speed sample

On the same 8,192-tick simulator workload:

| Run | Wall time | User CPU time | Peak RSS |
|---|---:|---:|---:|
| synchronous replay | 34.45 s | 34.42 s | 90,140 KB |
| prefetched replay | 28.13 s | 32.30 s | 91,220 KB |
| second prefetched replay | 28.62 s | 33.12 s | 96,180 KB |

The first A/B pair measured **18.3% lower wall time** (about **22.5% more throughput**); the second prefetched run was similar. This is a promising result, not a guaranteed sustained gain. This is an 8,192-tick simulator benchmark, not yet a long stage-9, two-environment `ParallelPvpTrain` benchmark. Peak memory rises slightly because the prefetch cell and two reusable output arrays are retained.

## Deployment safety

- The currently-running 3-million-tick training process and its checkpoint were not changed by this work.
- This is a separate source candidate. To roll back, launch the same source with `-Drlpvp.gruPrefetch=false`, which uses synchronous GRU replay. The previous source ZIP/checkpoint remains the fallback.
- Do not compare candidates on win rate alone. Resume from a copy of the same checkpoint and compare serialized state for deterministic short checks, then use the same fixed held-out opponent styles/seeds for policy evaluation.
- No optimization can honestly be promised to be bug-free for every runtime and workload. The exact-state test, regression suite, fallback switch, and untouched baseline are the safeguards used here.
