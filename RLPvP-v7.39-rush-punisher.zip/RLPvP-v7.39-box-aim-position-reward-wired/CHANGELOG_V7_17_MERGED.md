# RLPvP v7.17 — merged capacity, motion memory, and guard improvements

## Merge intent
This release combines the most useful, compatible parts of v7.15 and v7.16. It does not claim better combat performance without controlled training comparisons.

## Retained from v7.15
- Optional `OBS_V2` and eight situational `MotionMemory` features, integrated in both the simulator and Minecraft mod trainer.
- Pooled CollapseGuard evidence, Wilson confidence bounds, best non-failed checkpoint tracking, and stage-entry weight snapshots.
- Adaptive PPO learning-rate adjustment based on rollout KL.
- Existing outcome classification and migration compatibility.

## Integrated from v7.16
- More robust movement SpamGuard with rate-based reversal/sprint-toggle checks, stuck-movement detection, per-tick and per-episode caps, hit grace, and curriculum lock awareness.
- Model-capacity diagnostics and regression tests for network parameter counts, serialized sizes, gradient flow, and widening.
- Function-preserving hidden-layer widening: existing policy output remains unchanged immediately after widening, new units can learn, and Adam moments reset.

## Model configuration
- Default: `-Drlpvp.model=base` (`128,128`).
- Presets: `-Drlpvp.model=m10` (`960,960`) or `-Drlpvp.model=m15` (`1024,1024,512`).
- Custom architecture: `-Drlpvp.hidden=512,512` or `-Drlpvp.hidden=512,512,256`.
- Optional explicit source shape for custom checkpoint widening: `-Drlpvp.transferFrom=128,128`.
- `-Drlpvp.obsV2=true` enables motion features and changes the observation input layout. Compatible legacy checkpoints are input-mapped on load; test before using any valuable checkpoint.
- Hidden-layer depth changes are intentionally not auto-transferred. Train a different-depth model from scratch.

## Tests run in this workspace
- Java compilation of simulator + Minecraft-free test targets: passed.
- `RlTests`: passed.
- `MotionMemoryCheck` with `OBS_V2=true`: passed.
- `OutcomeRegressionTest`: 43 passed, 0 failed.
- `MoveSpamCheck`: passed after aligning the sneak-rate threshold with v7.16.
- `NetCapacityCheck`: passed, including exact function preservation on widening and gradient movement for new units.
- `GuardCheck`, `CurriculumGateCheck`, `MinecraftRulesCheck`, `SpamGuardCheck`, `GlideCameraCheck`, `AimBrakeCheck`, `GameplayRotationCheck`: passed.
- Simulator smoke run: 5,000 ticks saved successfully.
- End-to-end checkpoint migration from `128,128` to `256,256`: passed; log confirmed function-preserving widening.

## Limitations / not verified
- The full `tests/run.sh` sequence did not complete within the execution window because `ConsequenceModelCheck` remained running; the whole suite must not be described as fully passing.
- The Fabric/Minecraft Gradle build was not verified in this merge.
- No long training or controlled A/B benchmark was run. Win rate, whiff rate, Stage 7 stability, and actual in-game performance improvements remain unproven.
- ModelInfo timing is a rough JVM microbenchmark, not a representative Android/Termux performance benchmark.

## Combat observation expansion
- Enabled `rlpvp.obsV2` by default (still switchable off for ablation testing).
- Added 11 appended combat observations for spacing, velocity alignment, line-of-sight crosshair alignment, recent hit efficiency, sprint-state sensing, sprint interruptions, and attacks attempted during the opponent hurt timer.
- Kept the existing per-tick frame and prior summary block positions stable; added semantic summary-block checkpoint migration for optional-feature combinations.
- Added regression coverage for observation values, one-tick iframe event delivery, summary dimensions, and old-layout mapping.
- `sprint_modifier_active` is explicitly an observable proxy, not a direct Minecraft knockback flag.
