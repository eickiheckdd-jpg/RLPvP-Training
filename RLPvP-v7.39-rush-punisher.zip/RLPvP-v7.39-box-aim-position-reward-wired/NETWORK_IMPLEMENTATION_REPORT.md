# RLPvP V10 network implementation report

## Implemented

- Added `NetworkSimulation.java`: per-client RTT sampling, asymmetric C2S/S2C delays, per-packet jitter, tick-boundary delivery, stream serialization, ordered delivery, retransmission stalls, and TCP-like head-of-line blocking.
- Added authoritative server player replicas separate from locally predicted client entities in `PvpSim`.
- Added changed player-input, sprint-command, movement/rotation/status, and attack messages with C2S stream ordering. The packet order follows the supplied `LocalPlayer.sendChanges()` / `sendPosition()` structure; an ordered client-tick-end marker models the server handler's per-client-tick movement guard reset.
- Added server-side movement input checks, server-ticker attack calculation, range validation, authoritative damage, delayed knockback, and delayed correction response.
- Routed changed remote-entity/player-status snapshots through the actual modeled S2C stream; client interpolation begins on delivery rather than using a second independent delay model.
- Added training log telemetry for RTT, average C2S/S2C delay, movement/attack packet counts, movement corrections, and retransmission counts.
- Preserved PPO observation length and checkpoint serialization.
- Copied all 25 uploaded Minecraft reference source files into `reference/minecraft-26.3/network/` for provenance and auditability.

## Tests run

- `sh sim/regression.sh` — PASS: `NetworkSimulationTest` 15/15; `PvpSimNetworkTest` 11/11; `OutcomeRegressionTest` 43/43; `SprintHitFollowupMemoryTest` 12/12; `CombatObservationMemoryTest` passed; `Minecraft26PhysicsTest` 25/25; kit/rules, Prot III, exact combat, and measured-merge checks passed.
- `sh sim/run.sh 50 /tmp/rlpvp-v10-smoke-after-s2c.bin 123 - -` — PASS; standalone compile and 50-tick smoke training saved a checkpoint.
- `sh sim/run.sh 5 /tmp/rlpvp-v10-resume-after-s2c.bin 77 /mnt/data/rlpvp-v9-merged-fresh-3m.bin -` — PASS; loaded the V9 checkpoint at 1,200,132 ticks and advanced five ticks without observation migration.
- Two-environment network smoke from the V9 checkpoint reached 1,202,182 ticks. Telemetry showed RTT 51.8–66.3 ms, C2S 26.8–34.5 ms, S2C 24.9–31.9 ms, 4,085 accepted movement packets, 183 attack packets, 0 movement corrections, and 12 modeled TCP retransmission events.

## Not yet verified

- Full legacy `tests/run.sh` was run; all network/combat regression checks passed, but the same four pre-existing camera-controller assertions remain failing (`2 small 2 deg correction`, `7 overshoot toward 120 deg`, `8 stability`, `fine aiming`).
- Full Fabric/Gradle build was not run; the Fabric mod target remains 1.21.11 and is separate from the standalone simulator.
- No live 1.21.11 or 26.3 server trace comparison was performed.
- The network layer is an explicit tick-driven TCP-like approximation, not a real TCP/Netty stack. An invalid second position packet before an ordered client-tick-end marker produces a corrective response in the simulator rather than the vanilla disconnect; correctly ordered client ticks include that marker, so ordinary jitter does not trigger this fallback.
- Block collision and full attack-range component behavior remain incomplete.

## Checkpoint behavior

The PPO observation layout is unchanged, so existing V9 neural weights are structurally compatible. The new server/client separation changes transition dynamics, however; resume from an old checkpoint is a warm-start into a different environment, not a claim that the existing policy is already adapted to the new latency model.
