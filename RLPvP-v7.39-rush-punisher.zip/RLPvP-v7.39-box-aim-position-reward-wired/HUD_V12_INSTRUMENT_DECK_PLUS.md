# HUD v12 - Instrument Deck Plus (RlHud.java, ~88 KB)

Builds on v11. Only RlHud.java and one line of RlCommands.java differ from the v10 source; the Data record, KEY_* constants, render() and
command(String) are unchanged, so Trainer.java needs nothing.

New in v12: SWING ACCURACY (hits/misses/wrong-entity, streaks, charge-at-swing histogram, early-swing %), DUEL TIMELINE (both HP over ~20 s,
lead bar), SESSION (FPS, training ticks/s, ETA to next stage, win-rate trend), EVENT FEED (hits, damage taken, misses, intent changes, auto-collapsed
repeats), BEARING TAPE above the crosshair, HIT FEEDBACK (hit marker, red edge flash, low-HP pulse), CURRICULUM ladder (training view), STATS view,
themes (ice/ember/mono/violet/mint), presets (competitive/tuning/review/stream/training), settings persistence (config/rlpvp-hud.properties),
/rl hud layout (reports widgets dropped for lack of height), /rl hud clear, /rl hud help.

Commands: /rl hud [on|off|auto|combat|training|diag|stats|full|mini|flip|reset|status|clear|opacity <25-100>|theme <name>|preset <name>|layout|toggle <widget>]

Verified: javac against stubs of GuiGraphics/Font/Minecraft + real HudDraw/HudState/HudTheme/Config/Curriculum; headless PNG renders at 320x180 to
960x540; command handler and settings save exercised. NOT verified: Gradle build, running inside Minecraft 26.3, real font metrics.
