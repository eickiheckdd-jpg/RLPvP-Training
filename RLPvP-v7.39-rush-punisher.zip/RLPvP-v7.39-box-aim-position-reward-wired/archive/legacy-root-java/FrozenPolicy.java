package com.rlpvp;

import java.util.Random;

/**
 * A frozen copy of the actor network, used to drive the Carpet bot in stage 8 (self-play).
 * Immutable after construction (the learner keeps training its own copy), so it is safe to hand
 * from the client thread to the server thread. No Minecraft classes here.
 */
final class FrozenPolicy {
    private final Net net;
    private final Net twin;   // mirrored pass (symmetric policy)
    private final float[] zA = new float[Config.ACTION_SIZE];
    private final float[] obsM = new float[Config.OBS_SIZE];
    private final Random rng = new Random();
    private final float[] z = new float[Config.ACTION_SIZE];
    private final float[] action = new float[PpoAgent.N_ACT];

    FrozenPolicy(float[] actorWeights) {
        int[] s = new int[Config.HIDDEN.length + 2];
        s[0] = Config.OBS_SIZE;
        System.arraycopy(Config.HIDDEN, 0, s, 1, Config.HIDDEN.length);
        s[s.length - 1] = Config.ACTION_SIZE;
        net = new Net(s, 1f, null);
        System.arraycopy(actorWeights, 0, net.w, 0, actorWeights.length);
        twin = net.twin();
    }

    /** Samples an action {yawDelta, pitchDelta, fwd, strafe, attack, jump, sprint}. The returned array is reused. */
    float[] act(float[] obs, int mask) {
        float[] raw = net.forward(obs);
        if (Config.SYMMETRIC_POLICY) { // same symmetric policy the learner uses
            System.arraycopy(raw, 0, zA, 0, raw.length);
            Symmetry.obs(obs, obsM);
            Symmetry.logits(zA, twin.forward(obsM), z);
        } else {
            System.arraycopy(raw, 0, z, 0, raw.length);
        }
        ActionMask.apply(z, mask);
        PpoAgent.sampleAction(z, mask, rng, action);
        return action;
    }
}