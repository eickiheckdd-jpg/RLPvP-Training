package com.rlpvp;

/**
 * Response curve between the policy output and how strongly the virtual hand pushes the mouse (relative mouse control).
 *
 *     applied = sign(a) * ( mix * |a| + (1 - mix) * |a|^p )        a = raw network output, clamped to [-1, 1]
 *
 * p = Config.CAMERA_EXPONENT (3 = cubic), mix = Config.CAMERA_LINEAR_MIX (0 = pure power). p = 1 is the old linear mapping.
 * Why: a cubic curve spends most of the output range on small control inputs, allowing delicate mouse force and preserving strong
 * movement at the extremes. CameraDynamics turns that effort into a jerk-limited physical mouse trajectory. PPO optimises the RAW action
 * (its log-prob never sees this curve); the curve is applied where the action enters the mouse controller.
 *
 * Every camera-control consumer (`ActionApplier`, `BotBrain`, `PvpSim`) must map the raw action through apply() before it enters the mouse
 * dynamics. The camera reward and last-action observation use the actual resulting motion, not this command value. Pure Java, no game classes.
 */
final class CameraMap {
    private CameraMap() {}

    static float apply(float a) {
        return apply(a, Config.CAMERA_EXPONENT, Config.CAMERA_LINEAR_MIX);
    }

    static float apply(float a, float p, float mix) {
        float x = Math.max(-1f, Math.min(1f, a));
        float m = Math.abs(x);
        float y = mix * m + (1f - mix) * (float) Math.pow(m, p);
        return x < 0 ? -y : y;
    }

    /**
     * Raw std whose MEAN applied control effort |apply(sigma * eps)|, eps ~ N(0,1), equals the mean effort of a LINEAR control with std x
     * (0.798 * x). For p = 1 this returns x. Used for the start jitter and the smallest std, so exploration starts as visible as before.
     */
    static float stdForMeanAbs(float x, float p, float mix) {
        double target = 0.7978845608 * x, lo = 1e-5, hi = 4.0;
        for (int i = 0; i < 50; i++) {
            double mid = 0.5 * (lo + hi);
            if (meanAbs(mid, p, mix) < target) lo = mid; else hi = mid;
        }
        return (float) (0.5 * (lo + hi));
    }

    private static double meanAbs(double sigma, float p, float mix) {
        double s = 0, step = 0.02;
        for (double e = -8.0; e <= 8.0; e += step) s += Math.abs(apply((float) (sigma * e), p, mix)) * Math.exp(-0.5 * e * e);
        return s * step / Math.sqrt(2.0 * Math.PI);
    }

    /**
     * Raw std limit for the LARGEST sampling noise: the applied effort at tailSigmas standard deviations equals x. A power curve cubes
     * the tails (2 sigma of raw noise is 8x the applied effort of 1 sigma), so for p > 1 the noise is judged at 2 sigma; a linear camera
     * keeps the old 1-sigma rule.
     */
    static float stdForTail(float x, float p, float mix) {
        return inverse(x, p, mix) / (p > 1f ? 2f : 1f);
    }

    /** Raw output that produces the applied value y (|y| <= 1). Used to keep the std limits and hand-written controllers in applied units. */
    static float inverse(float y) {
        return inverse(y, Config.CAMERA_EXPONENT, Config.CAMERA_LINEAR_MIX);
    }

    static float inverse(float y, float p, float mix) {
        float t = Math.max(-1f, Math.min(1f, y));
        float target = Math.abs(t);
        float lo = 0f, hi = 1f; // apply() is strictly increasing on [0, 1] for p >= 1
        for (int i = 0; i < 40; i++) {
            float mid = 0.5f * (lo + hi);
            if (apply(mid, p, mix) < target) lo = mid; else hi = mid;
        }
        float r = 0.5f * (lo + hi);
        return t < 0 ? -r : r;
    }
}
