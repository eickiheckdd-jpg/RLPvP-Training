package com.rlpvp;

/**
 * The gameplay camera controller: the ONE implementation of "policy action -> actual yaw / pitch change", shared by the live mod
 * (ActionApplier), the self-play bot (BotBrain) and the simulator (PvpSim). Pure Java, primitives only, no allocation per tick.
 *
 *   raw policy output a (hand effort, relative, NOT a target angle)
 *     -> sanitize (NaN/inf -> 0, clamp [-1,1])  -> CameraMap response curve  -> x axis scale (deg/tick of hand effort)
 *     -> [optional] AimBrake: predictive braking from the observed target error and the TRUE camera velocity/acceleration
 *     -> CameraDynamics: force - drag, acceleration limit, jerk limit, 4 sub-steps  -> relative camera displacement (deg)
 *     -> pitch clamped to +-90 (hard stop zeroes the pitch velocity), yaw wrapped to [-180, 180).
 * Yaw and pitch have independent controllers and independent limits (YAW_SCALE / PITCH_SCALE). No rendering code is involved: the
 * result is the authoritative rotation used for ray casts, attacks and observations.
 */
final class GameplayRotation {
    final CameraDynamics yaw = new CameraDynamics(), pitch = new CameraDynamics();

    /** Outputs of the last step(): angles after the update and the degrees actually turned (pitch after the clamp). */
    float newYaw, newPitch, dYaw, dPitch;

    // target angular speed estimate per axis (deg/tick): d(target) = d(error) + own turn of the previous tick; smoothed, clamped, reset with the fight
    private boolean haveErr;
    private double prevErrYaw, prevErrPitch, vtYaw, vtPitch;
    private static final double VT_SMOOTH = 0.5;

    private static double estimate(double vt, double err, double prevErr, double ownTurn, double scale) {
        double d = err - prevErr;
        if (!Double.isFinite(d) || Math.abs(d) > 90.0) return 0.0; // wrap / target switch: no estimate
        double raw = Math.max(-0.25 * scale, Math.min(0.25 * scale, d + ownTurn));
        return vt + VT_SMOOTH * (raw - vt);
    }

    /** New fight / AI activated / deactivated / respawn: the mouse starts at rest, no stored velocity or acceleration. */
    void reset() { yaw.reset(); pitch.reset(); dYaw = dPitch = 0f; haveErr = false; vtYaw = vtPitch = 0.0; }

    /** Observation missing or stale: no new hand effort; drag and the jerk limit bring the mouse to rest smoothly (no jump, no freeze). */
    void hold(float curYaw, float curPitch) { step(0f, 0f, curYaw, curPitch, 0.0, 0.0, false, false, false); }

    static float sane(float a) { return Float.isFinite(a) ? Math.max(-1f, Math.min(1f, a)) : 0f; }

    static float wrapDegrees(float d) {
        d %= 360f;
        if (d >= 180f) d -= 360f;
        if (d < -180f) d += 360f;
        return d;
    }

    /** Shortest signed yaw difference to - from, in [-180, 180). */
    static float shortestYawDelta(float from, float to) { return wrapDegrees(to - from); }

    /**
     * @param rawYaw,rawPitch policy camera outputs (raw, before CameraMap)
     * @param curYaw,curPitch current authoritative angles (deg)
     * @param errYaw,errPitch observed error to the enemy in degrees (positive = enemy is in the positive turning direction); used by AimBrake only
     * @param errKnown        false when there is no valid target/observation: no braking envelope, the policy's command is used as it is
     * @param pitchFree       false while the pitch is locked/ignored by the curriculum: no pitch braking
     * @param brake           AimBrake on/off (Config.AIM_BRAKE)
     */
    GameplayRotation step(float rawYaw, float rawPitch, float curYaw, float curPitch, double errYaw, double errPitch, boolean errKnown, boolean pitchFree, boolean brake) {
        return stepEffort(CameraMap.apply(sane(rawYaw)) * Config.YAW_SCALE, CameraMap.apply(sane(rawPitch)) * Config.PITCH_SCALE,
                curYaw, curPitch, errYaw, errPitch, errKnown, pitchFree, brake);
    }

    /** Same as step() but takes hand effort in deg/tick (after CameraMap), used by the simulator which adds its own sensitivity / noise first. */
    GameplayRotation stepEffort(double cmdYaw, double cmdPitch, float curYaw, float curPitch, double errYaw, double errPitch, boolean errKnown, boolean pitchFree, boolean brake) {
        if (brake && errKnown) {
            if (haveErr) { // dYaw / dPitch still hold last tick's applied turn here
                vtYaw = estimate(vtYaw, errYaw, prevErrYaw, dYaw, Config.YAW_SCALE);
                vtPitch = pitchFree ? estimate(vtPitch, errPitch, prevErrPitch, dPitch, Config.PITCH_SCALE) : 0.0;
            }
            prevErrYaw = errYaw; prevErrPitch = errPitch; haveErr = true;
            cmdYaw = AimBrake.limit(cmdYaw, yaw, errYaw, Config.YAW_SCALE, vtYaw);
            if (pitchFree) cmdPitch = AimBrake.limit(cmdPitch, pitch, errPitch, Config.PITCH_SCALE, vtPitch);
        } else {
            haveErr = false; vtYaw = vtPitch = 0.0;
        }
        float dy = (float) yaw.step(cmdYaw, Config.YAW_SCALE);
        float dp = (float) pitch.step(cmdPitch, Config.PITCH_SCALE);
        float np = Math.max(-90f, Math.min(90f, curPitch + dp));
        if (np != curPitch + dp) pitch.halt(); // hit the pitch stop: no wind-up against it
        dYaw = dy;
        dPitch = np - curPitch;
        newPitch = np;
        newYaw = wrapDegrees(curYaw + dy);
        return this;
    }
}
