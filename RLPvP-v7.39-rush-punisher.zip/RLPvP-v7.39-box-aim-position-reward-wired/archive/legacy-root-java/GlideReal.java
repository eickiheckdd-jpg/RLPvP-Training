package com.rlpvp;

/**
 * Minecraft-facing half of the real-rotation glide (needs game classes, so it is NOT part of the standalone simulator / test builds; the pure curve
 * maths is GlideCamera, the entry for the display mixin is GlideBridge). Called by MinecraftFrameMixin (per frame) and ActionApplier (tick start).
 */
public final class GlideReal {
    private GlideReal() {}

    private static final double[] FRAME = new double[2];

    /** Called once per frame (before the game ticks) with the local player: moves the real yaw / pitch along the glide curve. Never throws. */
    public static void frame(net.minecraft.client.player.LocalPlayer p) {
        try {
            if (p == null || !GlideCamera.frame(FRAME)) return;
            float y = (float) FRAME[0], x = (float) FRAME[1];
            p.setYRot(y); p.yRotO = y;   // no vanilla interpolation on top: the value IS the camera
            p.setXRot(x); p.xRotO = x;
        } catch (Throwable t) { GlideCamera.setEnabled(false); }
    }

    private static final double[] END = new double[2];

    /** Tick start: complete the pending curve so the tick reads the exact end angles of the last segment (also when several ticks run back to back). */
    public static void finish(net.minecraft.client.player.LocalPlayer p) {
        try {
            if (p == null || !GlideCamera.finishReal(END)) return;
            p.setYRot((float) END[0]); p.yRotO = (float) END[0];
            p.setXRot((float) END[1]); p.xRotO = (float) END[1];
        } catch (Throwable t) { GlideCamera.setEnabled(false); }
    }
}
