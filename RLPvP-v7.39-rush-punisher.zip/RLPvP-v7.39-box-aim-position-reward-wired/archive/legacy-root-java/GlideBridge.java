package com.rlpvp;

/** Public entry for the mixin (the mixin lives in another package; GlideCamera stays package-private). Never throws; returns null for "leave vanilla's value". */
public final class GlideBridge {
    private GlideBridge() {}

    public static Float yaw(float vanilla, float partialTick) {
        try {
            if (!GlideCamera.active() || Config.GLIDE_REAL_ROTATION) return null; // real-rotation mode moves the real angles instead
            return (float) (vanilla + GlideCamera.yawOffset(partialTick));
        } catch (Throwable t) { GlideCamera.setEnabled(false); return null; }
    }

    public static Float pitch(float vanilla, float partialTick) {
        try {
            if (!GlideCamera.active() || Config.GLIDE_REAL_ROTATION) return null; // real-rotation mode moves the real angles instead
            return Math.max(-90f, Math.min(90f, (float) (vanilla + GlideCamera.pitchOffset(partialTick))));
        } catch (Throwable t) { GlideCamera.setEnabled(false); return null; }
    }
}
