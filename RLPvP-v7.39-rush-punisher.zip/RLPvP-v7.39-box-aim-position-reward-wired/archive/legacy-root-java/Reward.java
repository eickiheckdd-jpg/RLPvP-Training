package com.rlpvp;

/** Reward shaping, shared by the mod and any offline simulator so both train on the same signal. */
final class Reward {
    private Reward() {}

    static double shaping(long trainTicks) {
        return Math.max(Config.SHAPING_MIN, Math.exp(-trainTicks / (double) Config.SHAPING_TAU_TICKS));
    }

    /**
     * Per-tick reward (unscaled).
     *
     * @param dealt     HP of damage I dealt this tick (real, plus capped soft credit in early stages)
     * @param prevDist  distance to the enemy on the previous tick
     * @param yawErr    |yaw error| / 180 (frame[13]); 0 = looking straight at the enemy
     * @param pitchErr  |pitch error| / 90 (frame[14]); 0 = looking straight at the enemy
     * @param pitchRamp 0 in stage 1, ramps to 1 after it (Curriculum.pitchRamp)
     * @param w         curriculum weights for the current stage
     * @param idleScale 1 while engaged, fading to 0 when no real hit has landed for a while (see idleScale())
     * @param charge    my weapon cooldown, 0..1 (decides which spacing is rewarded)
     * @param tech      technique bonus/penalty for this tick, from techBonus() (already weighted)
     * @param hpLead    (my HP - enemy HP) / 20, -1..1; only a positive lead is paid, and only from stage 7 (Weights.hpAdv)
     */
    static double tick(float dealt, float taken, double dist, double prevDist, double yawErr, double pitchErr,
                       double shaping, double pitchRamp, Curriculum.Weights w, double idleScale,
                       double charge, double tech, double hpLead) {
        double r = (dealt - taken) / 20.0 * Config.W_DAMAGE;
        double dense = 0;
        if (dist < 8.0) {
            dense += shaping * Config.FACING_REWARD * w.facing * aim(yawErr * 180.0, Config.AIM_YAW_SCALE_DEG);
            dense += shaping * Config.PITCH_FACING_REWARD * w.pitch * pitchRamp * aim(pitchErr * 90.0, Config.AIM_PITCH_SCALE_DEG);
        }
        double closeness = Math.max(0.0, Math.min(1.0, 1.0 - Math.max(0.0, dist - 2.5) / 6.0));
        dense += shaping * Config.CLOSENESS_REWARD * w.closeness * closeness;
        if (prevDist > Config.PROGRESS_MIN_PREV_DIST && dist < prevDist) {
            dense += shaping * Config.PROGRESS_REWARD * w.progress * Math.min(prevDist - dist, 0.5);
        }
        // Spacing: when the weapon is charged, stand at hitting distance; while it recharges, stay just out of reach
        // (a real fighter steps back after a swing instead of standing in the enemy's hit range).
        if (charge >= 0.5) {
            if (dist >= Config.SPACING_MIN && dist <= Config.SPACING_MAX) dense += shaping * Config.SPACING_REWARD * w.spacing;
        } else if (dist > Config.SPACING_MAX && dist <= Config.RETREAT_MAX) {
            dense += shaping * Config.SPACING_REWARD * Config.RETREAT_FRACTION * w.spacing;
        }
        // small lead bonus: inside `dense` so anti-stalling also stops it paying when I get ahead and then hide
        if (hpLead > 0) dense += Config.HP_ADVANTAGE_REWARD * w.hpAdv * Math.min(1.0, hpLead);
        r += dense * idleScale;
        r += Config.TIME_PENALTY * w.time;
        r += tech;
        return r;
    }

    /** 1 on target, 0.5 at {@code scaleDeg} off, falling off smoothly (the old linear 1-err/180 hardly changed between 0 and 10 degrees). */
    static double aim(double errDeg, double scaleDeg) {
        double k = errDeg / scaleDeg;
        return 1.0 / (1.0 + k * k);
    }

    /**
     * Fighting-technique bonuses. Positive terms need a REAL damaging hit, so they cannot be farmed; the only
     * negative term is for swinging blind (out of reach or far off-aim).
     *
     * @param realHit        a real hit landed this tick (health actually dropped)
     * @param crit           the hit was a jump-crit (falling, not sprinting)
     * @param sprintHit      I was sprinting when I swung (extra knockback)
     * @param combo          consecutive damaging hits without taking damage, including this one
     * @param firstHit       first damaging hit of the episode
     * @param pointlessWhiff last tick's swing missed AND the enemy was far / far off-aim
     */
    static double techBonus(boolean realHit, boolean crit, boolean sprintHit, int combo, boolean firstHit,
                            boolean pointlessWhiff, double techWeight) {
        return techBonus(realHit, crit, sprintHit, combo, firstHit, pointlessWhiff, techWeight, false, false, false, 0.0);
    }

    /**
     * Outcome-first mode deliberately ignores technique labels. The only remaining action-specific penalty
     * is a pointless swing that is obviously out of reach / badly off target; damage and wins are rewarded
     * in tick() and terminal().
     */
    static double techBonus(boolean realHit, boolean crit, boolean sprintHit, int combo, boolean firstHit,
                            boolean pointlessWhiff, double techWeight, boolean fullCharge, boolean resetGap,
                            boolean punish, double lateWeight) {
        if (Config.outcomeOnlyRewards()) return pointlessWhiff ? -Config.WHIFF_PENALTY * techWeight : 0.0;
        double b = 0;
        if (realHit) {
            if (crit) b += Config.CRIT_BONUS;
            if (sprintHit) b += Config.SPRINT_HIT_BONUS;
            if (combo >= 2) b += Config.COMBO_BONUS * Math.min(combo - 1, 3);
            if (firstHit) b += Config.FIRST_HIT_BONUS;
        }
        if (pointlessWhiff) b -= Config.WHIFF_PENALTY;
        b *= techWeight;
        if (realHit && lateWeight > 0) {
            double t = 0;
            if (fullCharge) t += Config.FULL_CHARGE_HIT_BONUS;
            if (resetGap) t += Config.RESET_HIT_BONUS;
            if (punish) t += Config.PUNISH_HIT_BONUS;
            b += t * lateWeight;
        }
        return b;
    }

    /** True for a swing that was pointless: it missed and the enemy was out of reach or well off the crosshair. */
    static boolean isPointlessWhiff(double dist, double yawErr) {
        return dist > Config.WHIFF_FAR_DIST || yawErr > Config.WHIFF_OFFAIM_YAW;
    }

    /** Same, but a swing that is off in pitch counts too. pitchErr = |pitch error| / 90. */
    static boolean isPointlessWhiff(double dist, double yawErr, double pitchErr) {
        return isPointlessWhiff(dist, yawErr) || pitchErr > Config.WHIFF_OFFAIM_PITCH;
    }

    /** Anti-stalling: dense shaping only pays while the agent is actually landing hits (stage 6+). */
    static double idleScale(int stage, int ticksSinceRealHit) {
        if (stage < 6) return 1.0;
        return Math.max(0.0, Math.min(1.0, 1.0 - (ticksSinceRealHit - Config.IDLE_FREE_TICKS) / (double) Config.IDLE_FADE_TICKS));
    }

    /** Terminal bonus: draws and no-contests receive no extra reward. */
    static double terminal(EpisodeOutcome outcome) {
        if (outcome == EpisodeOutcome.WIN) return Config.W_WIN;
        if (outcome == EpisodeOutcome.LOSS) return -Config.W_WIN;
        return 0.0;
    }

    /**
     * v7.20 time shaping added on top of terminal(): a WIN pays Config.FAST_WIN_BONUS x the share of the episode time that was left (a quick kill is
     * worth more than a slow one), a TIMEOUT draw from Config.DRAW_PENALTY_FROM_STAGE on costs Config.DRAW_PENALTY. Mutual KOs and no-contests: 0.
     */
    static double finishAdjust(EpisodeOutcome outcome, int ticks, int limit, int stage) {
        if (outcome == EpisodeOutcome.WIN) return Config.FAST_WIN_BONUS * Math.max(0.0, 1.0 - ticks / (double) Math.max(1, limit));
        if (outcome == EpisodeOutcome.TIMEOUT && stage >= Config.DRAW_PENALTY_FROM_STAGE) return -Config.DRAW_PENALTY;
        return 0.0;
    }

    /** Legacy helper retained for source compatibility; simultaneous win + death is a mutual KO, not a win. */
    static double terminal(boolean win, boolean meDead) {
        return terminal(EpisodeOutcome.classify(meDead, win, win, false));
    }
}