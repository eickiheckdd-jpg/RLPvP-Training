package com.rlpvp;

/**
 * Temporary curriculum locks. A locked head can only choose its neutral action: every other logit of a
 * categorical / on-off head is set to a huge negative number before sampling, and a locked pitch axis is
 * simply fixed at 0 (PpoAgent skips it in sampling, log-prob, entropy and gradient). The mask in force is
 * stored with each transition (PpoAgent) and re-applied when that transition is learned from, so PPO
 * log-probs stay correct. A locked head has probability 1, log-prob 0 and zero gradient, so nothing is
 * learned (or unlearned) on it while locked. The agent is also TOLD which heads are locked
 * (Observation.frame, see flags()), so it does not waste credit assignment on actions that were never simulated.
 *
 * Yaw is never locked. No Minecraft classes here.
 */
final class ActionMask {
    private ActionMask() {}

    static final int LOCK_PITCH = 1;
    static final int LOCK_FWD = 2;
    static final int LOCK_STRAFE = 4;
    static final int LOCK_JUMP = 8;
    static final int LOCK_SPRINT = 16;
    /** Attack is locked in the aim-only stages (1-2): the agent cannot swing, so it can only learn to aim. */
    static final int LOCK_ATTACK = 32;
    /** Sneak is locked until stage 6: it only matters once the agent moves and fights. Its lock flag is frame feature 50 (appended). */
    static final int LOCK_SNEAK = 64;
    static final int LOCK_MOVEMENT = LOCK_FWD | LOCK_STRAFE;
    static final int N_FLAGS = 5;

    private static final float MASKED = -1e4f;
    static final int NEUTRAL_MOVE = 1; // "none"

    static boolean pitchLocked(int mask) {
        return (mask & LOCK_PITCH) != 0;
    }

    /** Mask to use for this tick: the curriculum mask plus LOCK_ATTACK when no swing could connect (Config.ATTACK_GATE). Angles in degrees. */
    static int withAttackGate(int base, double dist, double yawErrDeg, double pitchErrDeg) {
        if (!Config.ATTACK_GATE || (base & LOCK_ATTACK) != 0) return base;
        boolean ok = dist <= Config.ATTACK_GATE_DIST && Math.abs(yawErrDeg) <= Config.ATTACK_GATE_YAW
            && ((base & LOCK_PITCH) != 0 || Math.abs(pitchErrDeg) <= Config.ATTACK_GATE_PITCH);
        return ok ? base : base | LOCK_ATTACK;
    }

    /** Overwrites the logits of locked categorical / on-off heads in place. */
    static void apply(float[] z, int mask) {
        if (mask == 0) return;
        if ((mask & LOCK_FWD) != 0) lock(z, Config.OFF_FWD, 3, NEUTRAL_MOVE);
        if ((mask & LOCK_STRAFE) != 0) lock(z, Config.OFF_STRAFE, 3, NEUTRAL_MOVE);
        if ((mask & LOCK_JUMP) != 0) z[Config.OFF_JUMP] = MASKED;     // sigmoid -> 0: never jumps
        if ((mask & LOCK_SPRINT) != 0) z[Config.OFF_SPRINT] = MASKED; // never sprints
        if ((mask & LOCK_SNEAK) != 0) z[Config.OFF_SNEAK] = MASKED;   // never sneaks
        if ((mask & LOCK_ATTACK) != 0) z[Config.OFF_ATTACK] = MASKED; // never swings (sigmoid -> 0)
    }

    private static void lock(float[] z, int off, int len, int keep) {
        for (int i = 0; i < len; i++) if (i != keep) z[off + i] = MASKED;
    }

    /** 1 = locked, one float per head: pitch, forward/back, strafe, jump, sprint (observation input). */
    static void flags(int mask, float[] out, int at) {
        out[at] = (mask & LOCK_PITCH) != 0 ? 1f : 0f;
        out[at + 1] = (mask & LOCK_FWD) != 0 ? 1f : 0f;
        out[at + 2] = (mask & LOCK_STRAFE) != 0 ? 1f : 0f;
        out[at + 3] = (mask & LOCK_JUMP) != 0 ? 1f : 0f;
        out[at + 4] = (mask & LOCK_SPRINT) != 0 ? 1f : 0f;
    }

    /** Human-readable lock list for the HUD and /rl status. */
    static String label(int mask) {
        if (mask == 0) return "none";
        StringBuilder sb = new StringBuilder();
        add(sb, (mask & LOCK_PITCH) != 0, "Pitch");
        if ((mask & LOCK_MOVEMENT) == LOCK_MOVEMENT) add(sb, true, "Movement");
        else {
            add(sb, (mask & LOCK_FWD) != 0, "Forward/back");
            add(sb, (mask & LOCK_STRAFE) != 0, "Strafe");
        }
        add(sb, (mask & LOCK_JUMP) != 0, "Jump");
        add(sb, (mask & LOCK_SPRINT) != 0, "Sprint");
        add(sb, (mask & LOCK_SNEAK) != 0, "Sneak");
        add(sb, (mask & LOCK_ATTACK) != 0, "Attack");
        return sb.toString();
    }

    private static void add(StringBuilder sb, boolean on, String s) {
        if (!on) return;
        if (sb.length() > 0) sb.append(" + ");
        sb.append(s);
    }
}