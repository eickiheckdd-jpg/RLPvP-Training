package com.rlpvp;

import java.util.Locale;

/**
 * Jump-reset learning signal. Pure Java, shared by Trainer and PvpSim. It never presses a key and adds no observation input: the
 * policy already sees the hurt timer, ground flag, enemy swing timing and its own last jump, so it has to discover the timing itself.
 *
 * What it does: when I take a real hit it opens a measurement. The knockback is the distance I travelled AWAY from the attacker over
 * Config.JR_MEASURE_TICKS ticks (the real game or the simulator decides what a jump does to it; nothing is assumed here). A hit counts as a
 * RESET ATTEMPT if I chose a jump from the ground up to Config.JR_LOOKBACK ticks before the hit (the tick of the hit included) or
 * Config.JR_POST_TICKS after it. Hits without a jump update a baseline (EMA, one per enemy-sprint state). An attempt that moved me clearly
 * less than that baseline is paid in proportion to the reduction; one that made it clearly worse costs a little. Bonuses are annealed with
 * TechniqueDiscovery.anneal, capped per episode and need Config.TECH_DISCOVERY and a technique-stage weight, like the other hints.
 */
final class JumpReset {
    /** Per-tick input. */
    static final class In {
        boolean hit;                 // real damage taken this tick
        boolean jumpPrev;            // the jump head chosen on the previous tick
        boolean onGround;            // I stand on the ground now
        double mx, mz, ex, ez;       // my / the enemy's horizontal position now
        boolean enemySprint;         // the enemy was sprinting (bigger knockback)
        double techW; long techTicks; int tick;
    }

    private final boolean[] hist = new boolean[4];   // hist[0] = a jump from the ground was chosen on the previous tick
    private boolean prevGround = true;
    private boolean open, attempt;
    private int age, postLeft, lastHitTick = -1000, epN;
    private double sx, sz, ax, az, epPaid;
    private boolean sprintKb;
    private final double[] base = new double[2];
    private final int[] baseN = new int[2];
    // window statistics
    private int wHits, wAttempts, wReduced, wWorse, wJudged;
    private double wPaid, wDispAttempt, wDispBase;
    private int nDispAttempt, nDispBase;

    void reset() {
        java.util.Arrays.fill(hist, false);
        prevGround = true; open = attempt = false; age = postLeft = epN = 0; lastHitTick = -1000; epPaid = 0;
    }

    /** @return reward for this tick (0 unless a reset attempt was just judged). */
    double tick(In s) {
        boolean jumped = s.jumpPrev && prevGround;
        hist[3] = hist[2]; hist[2] = hist[1]; hist[1] = hist[0]; hist[0] = jumped;
        prevGround = s.onGround;
        if (open && postLeft > 0) { postLeft--; if (jumped) attempt = true; }
        if (s.hit && s.tick - lastHitTick >= Config.JR_MIN_GAP_TICKS) {
            lastHitTick = s.tick; wHits++;
            double dx = s.mx - s.ex, dz = s.mz - s.ez, len = Math.hypot(dx, dz);
            open = len > 1e-6;
            if (!open) return 0.0;
            ax = dx / len; az = dz / len; sx = s.mx; sz = s.mz; age = 0; postLeft = Config.JR_POST_TICKS; sprintKb = s.enemySprint;
            attempt = false;
            for (int i = 0; i < Config.JR_LOOKBACK && i < hist.length; i++) attempt |= hist[i];
            return 0.0;
        }
        if (!open) return 0.0;
        if (++age < Config.JR_MEASURE_TICKS) return 0.0;
        open = false;
        double disp = Math.max(0.0, (s.mx - sx) * ax + (s.mz - sz) * az);
        int b = sprintKb ? 1 : 0;
        if (!attempt) {
            base[b] = baseN[b] == 0 ? disp : base[b] + Config.JR_EMA * (disp - base[b]);
            baseN[b]++; wDispBase += disp; nDispBase++;
            return 0.0;
        }
        wAttempts++; wDispAttempt += disp; nDispAttempt++;
        if (baseN[b] < Config.JR_MIN_BASE) return 0.0;
        wJudged++;
        double ref = Math.max(base[b], Config.JR_MIN_REF), red = (ref - disp) / ref;
        double scale = Config.TECH_DISCOVERY && s.techW > 0 ? TechniqueDiscovery.anneal(s.techTicks) * s.techW : 0.0;
        if (scale <= 0) return 0.0;
        if (red >= Config.JR_MIN_REDUCTION) {
            wReduced++;
            double a = Config.JR_BONUS * scale * Math.min(1.0, red / Config.JR_FULL_REDUCTION) / (1.0 + 0.5 * epN);
            a = Math.min(a, Math.max(0.0, Config.JR_EPISODE_CAP - epPaid));
            epPaid += a; epN++; wPaid += a;
            return a;
        }
        if (red <= Config.JR_WORSE_AT) { wWorse++; double p = Config.JR_WORSE_PENALTY * scale; wPaid -= p; return -p; }
        return 0.0;
    }

    String summary() {
        if (wHits == 0) return "jumpReset -";
        return String.format(Locale.ROOT, "jumpReset hits %d attempts %d reduced %d worse %d (judged %d) kb attempt %.2f vs base %.2f paid %+.2f",
            wHits, wAttempts, wReduced, wWorse, wJudged, nDispAttempt == 0 ? 0.0 : wDispAttempt / nDispAttempt, nDispBase == 0 ? 0.0 : wDispBase / nDispBase, wPaid);
    }

    void clearWindow() {
        wHits = wAttempts = wReduced = wWorse = wJudged = nDispAttempt = nDispBase = 0; wPaid = wDispAttempt = wDispBase = 0;
    }
}
