package com.rlpvp;

/**
 * Legacy technique-shaped reward terms. Kept as a telemetry-compatible class for older tooling;
 * with Config.OUTCOME_ONLY_REWARDS (the default), tick() and onSwing() contribute no reward.
 * New learning should infer whether a technique helps from damage, damage avoided, and episode outcomes.
 */
final class TechniqueReward {
    static final double STRAFE_TRACK = 0.003, STILL = 0.003, COUNTER = 0.04, SAME_DIR = 0.004, HOLD_W = 0.008, SPRINT_CHAIN = 0.25;
    static final double FLEE = 0.006;
    static final int FLEE_CAP = 120;
    static final double CRIT_SETUP = 0.08, CRIT_READY = 0.004, OVERLAP = 0.01;
    static final int CRIT_SETUP_CAP = 6, CRIT_READY_CAP = 20, OVERLAP_DIST_X10 = 11;
    static final double CRIT_SAFE = 0.4, CRIT_REPEAT = 0.4, JUMP_PUNISHED = 0.25, DODGE = 0.3, DISENGAGE = 0.004, REPEEK = 0.4, WHIFF_STREAK = 0.08;
    static final int STILL_TICKS = 10, SAME_DIR_TICKS = 24, HOLD_W_TICKS = 12, COUNTER_CAP = 12, COUNTER_COOLDOWN = 8, DODGE_CAP = 10, DODGE_WINDOW = 5,
        DISENGAGE_CAP = 60, REPEEK_WINDOW = 80, REPEEK_MIN = 15, WHIFF_WINDOW = 12, CHAIN_WINDOW = 40;

    /** What the caller knows at the start of a tick (all from the frame / events the mod already computes). */
    static final class In {
        int lockMask, stage;
        double techW, idle;
        double dist, prevDist, yawErrDeg;
        double myHp01, oppHp01;            // frame[0], frame[15]
        double myCharge;                   // frame[6]
        double myRight, myFwd;             // blocks per tick (frame[2], frame[1] times 0.6)
        boolean myGround, canCrit;         // frame[4], frame[43]
        double enemyFacing, enemyCharge;   // frame[21], frame[42]
        boolean inMyReach, inTheirReach;   // frame[44], frame[45]
        boolean oppSwingStart;
        float realDealt, taken;
        boolean hitSprint, hitCrit;
        int prevStrafe, prevFwd;           // my keys on the previous tick: -1 / 0 / +1
        boolean prevSprint;
    }

    private boolean lastGround = true;
    private int setups, readyTicks, fleeTicks;
    private int still, runDir, runLen, flipCd, counters, holdW, chain, sinceHit = 999, critStreak, dodgeTimer, dodges, disTicks, sinceDis = 999, sinceWhiff = 999;

    void reset() {
        still = runDir = runLen = flipCd = counters = holdW = chain = critStreak = dodgeTimer = dodges = disTicks = 0;
        lastGround = true; setups = readyTicks = fleeTicks = 0;
        sinceHit = sinceDis = sinceWhiff = 999;
    }

    /** Reward for the previous tick's behaviour, from the state it led to. */
    double tick(In s) {
        // In outcome-first mode technique counters may still be observed for diagnostics, but they do
        // not enter the reward. The policy must infer their usefulness from combat consequences.
        if (Config.outcomeOnlyRewards()) return 0.0;
        double w = s.techW;
        if (w <= 0) return 0;
        boolean strafeFree = (s.lockMask & ActionMask.LOCK_STRAFE) == 0, fwdFree = (s.lockMask & ActionMask.LOCK_FWD) == 0;
        boolean jumpFree = (s.lockMask & ActionMask.LOCK_JUMP) == 0;
        double r = 0, speed = Math.hypot(s.myFwd, s.myRight);
        boolean engaged = s.dist < 4.5;
        sinceHit++; sinceDis++; sinceWhiff++; if (flipCd > 0) flipCd--;

        // ---- Tier S: strafe while tracking, do not stand still ----
        if (strafeFree && s.dist >= 1.5 && s.dist <= 4.5 && s.yawErrDeg <= 12.0 && Math.abs(s.myRight) >= 0.12) r += STRAFE_TRACK * w * s.idle;
        still = (engaged && speed < 0.03) ? still + 1 : 0;
        if ((strafeFree || fwdFree) && still >= STILL_TICKS) r -= STILL * w * s.idle;

        // ---- Tier A: counter-strafe / endless circle ----
        if (strafeFree) {
            if (s.prevStrafe != 0) {
                if (s.prevStrafe == runDir) runLen++;
                else {
                    if (runDir != 0 && runLen >= 4 && s.enemyFacing > 0.9 && engaged && flipCd == 0 && counters < COUNTER_CAP) {
                        r += COUNTER * w; counters++; flipCd = COUNTER_COOLDOWN;
                    }
                    runDir = s.prevStrafe; runLen = 1;
                }
            } else runLen = Math.max(0, runLen - 1);
            if (runLen > SAME_DIR_TICKS && s.dist < 5.0) r -= SAME_DIR * w * Math.min(1.0, (runLen - SAME_DIR_TICKS) / 40.0);
        }
        holdW = (fwdFree && s.prevFwd == 1 && s.dist <= 2.6) ? holdW + 1 : 0;
        if (holdW > HOLD_W_TICKS) r -= HOLD_W * w;

        // ---- crit setup: the jump itself, at the right moment (the hit is paid separately) ----
        if (jumpFree) {
            if (lastGround && !s.myGround && s.dist >= 1.8 && s.dist <= 3.8 && s.yawErrDeg <= 12.0 && s.myCharge >= 0.7 && setups < CRIT_SETUP_CAP) { r += CRIT_SETUP * w; setups++; }
            if (s.canCrit && s.inMyReach && s.myCharge >= 0.9 && s.yawErrDeg <= 8.0 && readyTicks < CRIT_READY_CAP) { r += CRIT_READY * w; readyTicks++; }
        }
        lastGround = s.myGround;
        if (s.dist < OVERLAP_DIST_X10 / 10.0 && s.dist > 0) r -= OVERLAP * w;   // standing inside the enemy

        // ---- hits: sprint chain, crit safety / variety, re-peek ----
        if (s.realDealt > 0) {
            if (s.hitSprint) {
                chain = sinceHit <= CHAIN_WINDOW ? chain + 1 : 1;
                if (chain >= 2) r += SPRINT_CHAIN * w * Math.min(chain - 1, 3);
            } else chain = 0;
            if (s.hitCrit) {
                critStreak++;
                if (critStreak >= 2) r -= CRIT_REPEAT * w;
                if (s.enemyCharge < 0.6 || s.enemyFacing < 0.5 || !s.inTheirReach) r += CRIT_SAFE * w;
            } else critStreak = 0;
            if (disTicks >= REPEEK_MIN && sinceDis <= REPEEK_WINDOW) { r += REPEEK * w; disTicks = 0; sinceDis = 999; }
            sinceHit = 0;
        }
        if (jumpFree && s.taken > 0 && !s.myGround) r -= JUMP_PUNISHED * w; // jumped into a hit

        // ---- bait / dodge: the enemy swung at me and I took nothing ----
        if (s.oppSwingStart && s.inTheirReach && s.enemyFacing > 0.8 && dodgeTimer == 0) dodgeTimer = DODGE_WINDOW + 1;
        if (dodgeTimer > 0) {
            if (s.taken > 0) dodgeTimer = 0;
            else if (--dodgeTimer == 0 && dodges < DODGE_CAP) { r += DODGE * w; dodges++; }
        }

        // ---- disengage when clearly behind ----
        boolean behind = s.myHp01 < 0.4 && s.myHp01 + 0.15 < s.oppHp01;
        if (s.stage >= 5 && s.dist > 7.0 && !behind && fleeTicks < FLEE_CAP) { r -= FLEE * w; fleeTicks++; }
        if (behind && s.dist >= 3.4 && s.dist >= s.prevDist - 0.02 && disTicks < DISENGAGE_CAP) { r += DISENGAGE * w; disTicks++; sinceDis = 0; }
        return r;
    }

    /** Call when I swing (landed = the crosshair was on the enemy). A second miss within 12 ticks costs: prefer one clean hit to panic swings. */
    double onSwing(boolean landed, double techW) {
        if (Config.outcomeOnlyRewards()) return 0.0;
        double r = 0;
        if (!landed) {
            if (sinceWhiff <= WHIFF_WINDOW) r -= WHIFF_STREAK * techW;
            sinceWhiff = 0;
        } else sinceWhiff = 999;
        return r;
    }
}
