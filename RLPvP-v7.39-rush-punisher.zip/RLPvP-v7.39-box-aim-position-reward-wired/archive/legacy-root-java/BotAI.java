package com.rlpvp;

import java.util.Random;

/**
 * Scripted fighter for the AGGRESSIVE and STRONG opponents. Minecraft-free, shared by the mod (BotBrain) and the simulator (PvpSim),
 * so both train against the same opponent. It is "fair": it only knows where the agent was a few ticks ago (reaction lag 1-2 ticks),
 * turns at a limited rate with aim noise, swings only at full charge and only when its own crosshair belief is on target, and can only
 * hit what its real ray hits within reach 3.0 (a miss costs it its cooldown).
 *
 * Why this beats a pure W+D orbit (the habit the old bots allowed): the old bots aimed at where the agent WAS 2 ticks ago and only swung
 * when that stale angle was within 12 degrees, so a fast sprint-orbit stayed outside the aim window and was almost never hit.
 *  - LEAD AIM      it extrapolates the agent's velocity (from its delayed observations) over the lag + 1 tick, so a steady orbit is tracked
 *  - SWING RULE    it swings when its predicted crosshair is within the hitbox angle, not when a stale angle is "close enough"
 *  - MIRROR STRAFE it strafes the same way the agent moves sideways (in its own frame), which cancels the agent's orbit speed relative to
 *                  the bot instead of letting the agent slide out of the crosshair; it re-evaluates every 2-5 ticks, so counter-strafes work
 *  - PURSUIT       it closes in (sprinting) when the agent circles wide or keeps away for 12+ ticks; it holds a spacing ring otherwise
 *  - PUNISH        when the agent's weapon is recharging (it just swung) the bot rushes in and swings
 *  - TECHNIQUE     w-tap after a swing, safe jump-crits while the agent recharges, disengage + re-peek when behind
 *                  (jump reset only for the ELITE bot, and it keeps sprinting at the agent: a plain reset left the STRONG bot airborne and out of reach)
 * Three styles are picked per episode (COUNTER, PRESSURE, BAITER) so there is no single habit to beat. Everything scales with
 * difficulty 0..1 (see BotDifficulty), which adapts to how well the agent is doing against it.
 */
final class BotAI {
    static final int COUNTER = 0, PRESSURE = 1, BAITER = 2;
    /** Reach is measured from the eye to the nearest face of the hitbox (3.0), which is about 3.3 between centers; swing a little inside that. */
    static final double REACH_CENTER = 3.2;
    /** Ticks without a swing or a hit before a waiting style commits to the fight. */
    static final int QUIET_COMMIT = 50;

    static final class Skill {
        double lead, noise, mirror, punish, fire, critProb, spacing;
        /** ELITE only: chance to jump-reset when hit, share of random (non-mirrored) strafe, pressure (shorter chase / commit timers). */
        double jumpReset, unpredict;
        boolean elite;
        int lag, style;
        float turn;
        boolean disengage;
    }

    static final class In {
        double bx, by, bz, byaw, bpitch, eyeY, bvy, bScale, bHp;
        boolean bGround;
        int hurtTime;
        double tx, ty, tz, tScale, tHp;
    }

    static final class Out {
        float yaw, pitch;
        int fwd, str;
        boolean sprint, jump, attack;
    }

    final In in = new In();
    final Out out = new Out();
    private final Random rng;
    private Skill sk;
    private final double[][] hist = new double[6][3]; // newest first
    private int histN, strafe, strafeHold, wtap, critTicks, farTicks, quiet;
    private boolean critArm, retreating;

    BotAI(Random rng) {
        this.rng = rng;
    }

    void reset() {
        sk = null;
        histN = strafe = strafeHold = wtap = critTicks = farTicks = quiet = 0;
        critArm = retreating = false;
    }

    boolean ready() {
        return sk != null;
    }

    Skill skill() {
        return sk;
    }

    /** Picks this episode's style and strengths. strong = the league's STRONG fighter (else the AGGRESSIVE one). */
    void newEpisode(boolean strong, double difficulty) { newEpisode(strong, false, difficulty); }

    /** elite = the stage-8 fighter: strong + jump reset, unpredictable strafing, more pressure, better spacing discipline, more crits. */
    void newEpisode(boolean strong, boolean elite, double difficulty) {
        double d = Math.max(0.0, Math.min(1.0, elite ? Math.max(Config.ELITE_MIN_DIFFICULTY, difficulty) : difficulty));
        Skill s = new Skill();
        double r = rng.nextDouble();
        s.style = strong ? (r < 0.40 ? COUNTER : r < 0.75 ? PRESSURE : BAITER) : (r < 0.70 ? PRESSURE : COUNTER);
        // difficulty 0 is a bot a stage-6 agent can beat (the old floor 0.30 lead / 3 deg noise / 70 % fire crushed it: win 0 %, then the agent fled)
        s.lead = 0.75 * d; // full lead (1.0) over-predicts a curving orbit and made the strongest bot WORSE (measured with BotBench)
        s.noise = 6.0 - 5.0 * d;
        s.lag = (d >= 0.55 && rng.nextBoolean()) ? 1 : 2;
        s.turn = Math.min(Config.BOT_TURN_STRONG, (float) (9.0 + 21.0 * d));
        s.mirror = Math.min(0.80, 0.80 * d + (s.style == COUNTER ? 0.05 * d : 0.0));
        s.punish = 0.10 + 0.90 * d;
        s.fire = 0.30 + 0.65 * d;
        s.critProb = 0.01 + 0.04 * d;
        s.disengage = d >= 0.6;
        s.spacing = s.style == COUNTER ? 3.3 : s.style == PRESSURE ? 2.5 : 3.6; // BAITER / COUNTER wait at the edge of reach: whoever steps in gets hit first
        if (elite) {
            s.elite = true;
            s.style = r < 0.55 ? PRESSURE : r < 0.85 ? COUNTER : BAITER;
            s.spacing = s.style == PRESSURE ? 2.4 : 3.1;                 // tighter than STRONG: stay at the edge of its own reach, step in only to hit
            s.critProb = 0.03 + 0.07 * d;
            s.jumpReset = Config.ELITE_JUMP_RESET_BASE + 0.35 * d;
            s.unpredict = Config.ELITE_UNPREDICTABLE;
            s.fire = Math.min(0.98, s.fire + 0.05);
        }
        sk = s;
    }

    static double wrap(double a) {
        a %= 360.0;
        if (a >= 180.0) a -= 360.0;
        if (a < -180.0) a += 360.0;
        return a;
    }

    Out think(In s) {
        Skill k = sk;
        // ---- perception: the agent's position a few ticks ago, plus a velocity estimate from those delayed samples ----
        if (histN == 0) for (double[] h : hist) { h[0] = s.tx; h[1] = s.ty; h[2] = s.tz; }
        else {
            for (int i = hist.length - 1; i > 0; i--) { hist[i][0] = hist[i - 1][0]; hist[i][1] = hist[i - 1][1]; hist[i][2] = hist[i - 1][2]; }
            hist[0][0] = s.tx; hist[0][1] = s.ty; hist[0][2] = s.tz;
        }
        histN++;
        double[] seen = hist[k.lag], older = hist[k.lag + 1];
        double vx = seen[0] - older[0], vy = seen[1] - older[1], vz = seen[2] - older[2];
        double horizon = (k.lag + 1.0) * k.lead;
        double px = seen[0] + vx * horizon, pz = seen[2] + vz * horizon, py = seen[1] + Math.max(-0.6, Math.min(0.6, vy * horizon * 0.5));

        // ---- aim at the predicted position (turn-rate limited, noisy) ----
        double dx = px - s.bx, dz = pz - s.bz, horiz = Math.hypot(dx, dz);
        double dy = (py + 0.9) - s.eyeY;
        double wantYaw = Math.toDegrees(Math.atan2(-dx, dz));
        double wantPitch = -Math.toDegrees(Math.atan2(dy, Math.max(horiz, 1e-6)));
        double dYaw = Math.max(-k.turn, Math.min(k.turn, wrap(wantYaw - s.byaw))) + rng.nextGaussian() * k.noise;
        double dPitch = Math.max(-k.turn * 0.5, Math.min(k.turn * 0.5, wantPitch - s.bpitch)) + rng.nextGaussian() * k.noise * 0.5;
        out.yaw = (float) wrap(s.byaw + dYaw);
        out.pitch = (float) Math.max(-90.0, Math.min(90.0, s.bpitch + dPitch));
        double dist = Math.sqrt(horiz * horiz + (py - s.by) * (py - s.by));
        double tol = Math.toDegrees(Math.atan2(0.36, Math.max(dist, 0.6)));  // hitbox half width 0.3 + a little anticipation
        boolean onTarget = Math.abs(wrap(wantYaw - out.yaw)) <= tol && Math.abs(wantPitch - out.pitch) <= 14.0;
        boolean ready = s.bScale >= Config.MIN_ATTACK_STRENGTH;
        boolean tRecharge = s.tScale < 0.55; // the agent just swung: its weapon is dead for a moment

        // ---- movement: spacing ring, pursuit, punish, disengage ----
        int f;
        boolean sprint = false, jump = false, attack = false;
        // nothing has happened for a while (the agent is waiting at the edge too): stop waiting and take the fight to it
        quiet = (s.hurtTime > 0) ? 0 : quiet + 1;
        double spacing = quiet > (k.elite ? QUIET_COMMIT / 2 : QUIET_COMMIT) ? Math.min(k.spacing, 2.5) : k.spacing;
        boolean behind = k.disengage && s.bHp <= 7.0 && s.tHp >= s.bHp + 3.0;
        if (behind && !ready && dist < 4.5) retreating = true;
        if (retreating && (ready || dist > 5.0 || !behind)) retreating = false;
        if (retreating) f = -1;
        else if (dist > spacing + 0.4) { f = 1; sprint = dist > 3.9; }
        else if (dist < spacing - 0.5) f = -1;
        else f = (k.style == PRESSURE || quiet > QUIET_COMMIT || (tRecharge && rng.nextDouble() < k.punish)) ? 1 : 0;
        if ((k.style == PRESSURE || quiet > QUIET_COMMIT) && dist < 1.6) f = -1;
        farTicks = dist > 3.8 ? farTicks + 1 : 0;
        if (!retreating && farTicks > (k.elite ? 6 : 12)) { f = 1; sprint = true; }          // the agent keeps away: commit and chase
        if (!retreating && tRecharge && ready && dist <= 4.8) { f = 1; sprint = dist > 2.6; } // punish: rush in while its weapon recharges

        // ---- strafe: follow the agent's sideways motion in the bot's frame so an orbit cannot slide out of the crosshair ----
        if (--strafeHold <= 0) {
            double yr = Math.toRadians(s.byaw);
            double latV = vx * -Math.cos(yr) + vz * -Math.sin(yr); // + = the agent moves to the bot's right
            if (Math.abs(latV) > 0.04 && rng.nextDouble() < k.mirror) strafe = latV > 0 ? 1 : -1;
            else strafe = rng.nextDouble() < 0.15 ? 0 : (rng.nextBoolean() ? -1 : 1);
            strafeHold = 2 + rng.nextInt(4);
            if (k.elite && rng.nextDouble() < k.unpredict) { strafe = rng.nextInt(3) - 1; strafeHold = 1 + rng.nextInt(7); } // random direction / pause, random length: no rhythm to read
        }

        // ---- attack / technique ----
        // jump-crit only from a safe spot (the agent is recharging and far enough that nothing can hit me first); never instead of a plain swing
        if (!critArm && s.bGround && ready && !retreating && dist > 3.0 && dist < 3.7 && s.tScale < 0.4 && rng.nextDouble() < 0.10 + k.critProb) {
            jump = true; critArm = true; critTicks = 12;
        }
        boolean falling = !s.bGround && s.bvy < 0;
        if (critArm) {
            sprint = false;
            // swing on the way down; but a plain swing is better than waiting once the agent's weapon is back or time runs short
            if (dist <= REACH_CENTER && ready && onTarget && (falling || s.tScale >= 0.8 || critTicks <= 5)) { attack = true; critArm = false; }
            if (--critTicks <= 0) critArm = false;
        } else if (wtap > 0) {
            wtap--;
            f = 0; sprint = false;
        } else if (!retreating && dist <= REACH_CENTER && ready && onTarget && rng.nextDouble() < k.fire) {
            attack = true;
            wtap = k.elite ? 1 : 2;
        }
        // jump reset: just hit (hurtTime 9-10) while grounded: hop and keep sprinting at the agent so the forward kick of the sprint-jump offsets the knockback
        if (k.elite && !critArm && !retreating && s.hurtTime >= 9 && s.bGround && rng.nextDouble() < k.jumpReset) { jump = true; f = 1; sprint = true; }
        if (attack) quiet = 0;
        out.fwd = f;
        out.str = strafe;
        out.sprint = sprint && f > 0;
        out.jump = jump;
        out.attack = attack;
        return out;
    }
}
