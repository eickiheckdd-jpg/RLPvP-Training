package com.rlpvp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Random;

/**
 * Online PPO (actor-critic, clipped objective, GAE) that learns while the game runs.
 *
 * Every tick the trainer calls:
 *   addReward(r)      reward caused by the previous action
 *   actTrain(obs)     sample an action (also stores the transition)
 *   learnTick()       one minibatch gradient step if a finished rollout is waiting
 *
 * Experience goes into a double buffer: while the next ROLLOUT ticks are being collected, the
 * learner works through the previous rollout, one MINIBATCH-sized gradient step per tick, so the
 * game never stalls on a big update. Each stored transition keeps the log-prob of the policy that
 * acted, so PPO's ratio/clipping stays correct even though the policy keeps changing.
 *
 * The policy is factorised: 2 Gaussian heads (yaw delta, pitch delta = continuous mouse movement, each
 * a mean and a log-std), 2 categorical heads (forward, strafe) and 3 Bernoulli heads (attack, jump,
 * sprint), all read from the actor's 13 outputs. Action vector layout (floats):
 * {yawDelta, pitchDelta, fwd, strafe, attack, jump, sprint}. Camera deltas are normalised (see Config.YAW_SCALE).
 *
 * No Minecraft classes here, so it can be tested offline.
 */
final class PpoAgent {
    static final int N_ACT = 8; // yaw, pitch, fwd, strafe, attack, jump, sprint, sneak
    private static final int[] GAUSS_OFF = {Config.OFF_YAW, Config.OFF_PITCH};
    private static final int[] CAT_OFF = {Config.OFF_FWD, Config.OFF_STRAFE};
    private static final double HALF_LOG_2PI = 0.5 * Math.log(2 * Math.PI);
    private static final int[] BERN_IDX = {Config.OFF_ATTACK, Config.OFF_JUMP, Config.OFF_SPRINT, Config.OFF_SNEAK};

    private static final int MAGIC = 0x524C5050; // "RLPP"
    private static final int VERSION = 7; // 7: sneak (frame 48 -> 51, output 13 -> 14); 4..6 are migrated on load

    final Net actor;
    final Net critic;
    private final ConsequenceModel consequences;
    // ---- trainable GRU memory (GruCell / OpponentMemory): the cell, the per-tick context of the transition in flight and replay scratch ----
    private final GruCell gru = new GruCell();
    private final float[] cH = new float[GruCell.H], cX = new float[GruCell.X], pH = new float[GruCell.H], pX = new float[GruCell.X];
    private final float[] obsTmp = new float[Config.OBS_SIZE], gruGrad = new float[GruCell.H];
    private static final int GRU_TRAILER_MAGIC = 0x47525531; // "GRU1": optional trailer after the TECH trailer
    private final Random rng;

    long totalTicks = 0;
    /** Curriculum progress, saved with the agent (see Curriculum.restore). */
    int stage = 1;
    long stageEnterTicks = 0;
    int updates = 0;       // finished rollouts that were fully trained on
    int skipped = 0;       // rollouts cut short (KL early stop) or dropped
    /** Technique-discovery annealing clock (training ticks with technique weight > 0). Saved in an optional trailer. */
    long techTicks = 0;
    private static final int TRAILER_MAGIC = 0x54454348; // "TECH": optional trailer after the consequence section
    private static final java.util.Set<Path> BACKED_UP = java.util.concurrent.ConcurrentHashMap.newKeySet();

    // ---- scratch ----
    private final float[] p = new float[Config.ACTION_SIZE];
    private final float[] ls = new float[Config.ACTION_SIZE];
    private final float[] gz = new float[Config.ACTION_SIZE];
    private final float[] dV = new float[1];
    private final float[] logitsCopy = new float[Config.ACTION_SIZE];
    private final float[] action = new float[N_ACT];
    private double lastEntropy;
    private final java.util.Random playRng = new java.util.Random(0x5eedL); // play-mode sampling must not disturb the training RNG stream
    // per-head entropy floors (forward/back, strafe, jump): see Config.HEAD_ENTROPY_FLOOR_FRAC
    private final double[] headEntEma = new double[3];
    private final boolean[] headEmaInit = new boolean[3];
    private final float[] headBoost = {1f, 1f, 1f};
    private final double[] bernEnt = new double[BERN_IDX.length];
    private double lastRatio;
    private boolean lastClipped;

    // ---- curriculum hooks (temporary action locks + entropy boost) ----
    private int curMask = 0;      // ActionMask bits applied to new actions
    private int pMask = 0;        // mask that was active when the pending action was sampled
    private float entropyCoef = Config.ENTROPY_COEF;
    private final float[] zMasked = new float[Config.ACTION_SIZE];
    // symmetric policy: a second view of the actor for the mirrored observation (shares weights and gradients)
    private final Net twin;
    private final float[] zA = new float[Config.ACTION_SIZE];
    private final float[] obsM = new float[Config.OBS_SIZE];
    private final float[] gzA = new float[Config.ACTION_SIZE];
    private final float[] gzB = new float[Config.ACTION_SIZE];

    // One-step model-based action search used only in PLAY. Training continues to sample directly
    // from the PPO policy so its stored log-probabilities remain mathematically correct.
    private static final int PLAN_CANDIDATES = 12;
    private static final double PLAN_MIN_GAIN = 0.02; // avoid reranking on tiny model-score differences
    private final float[] planNextFrame = new float[Config.FRAME];
    private final float[] planFutureObs = new float[Config.OBS_SIZE];
    private final float[] planCandidate = new float[N_ACT];
    private final float[] planBest = new float[N_ACT];

    // ---- pending transition (state seen, action taken, waiting for its reward) ----
    private final float[] pObs = new float[Config.OBS_SIZE];
    private final float[] pAct = new float[N_ACT];
    private float pLogp, pVal, pRew;
    private boolean hasPending = false;

    // ---- double buffer ----
    private static final class Rollout {
        final float[][] obs = new float[Config.ROLLOUT][Config.OBS_SIZE];
        final float[][] act = new float[Config.ROLLOUT][N_ACT];
        final float[] logp = new float[Config.ROLLOUT];
        final float[] val = new float[Config.ROLLOUT];
        final float[] rew = new float[Config.ROLLOUT];
        final float[] boot = new float[Config.ROLLOUT];
        final boolean[] done = new boolean[Config.ROLLOUT];
        final float[] adv = new float[Config.ROLLOUT];
        final float[] ret = new float[Config.ROLLOUT];
        final int[] mask = new int[Config.ROLLOUT]; // lock mask the action was sampled under
        final float[][] hPrev = new float[Config.ROLLOUT][GruCell.H]; // GRU state BEFORE this tick's update, as acted
        final float[][] gx = new float[Config.ROLLOUT][GruCell.X];    // the GRU input of this tick
        int n = 0;
    }

    private Rollout fill = new Rollout();
    private Rollout train = new Rollout();
    private boolean trainReady = false;
    private final int[] perm = new int[Config.ROLLOUT];
    private int epoch = 0;
    private int mbIdx = 0;

    // ---- rolling stats (reset by takeStats) ----
    private int stSteps;
    private double stKl, stEnt, stClip, stVLoss, stGrad;
    private int stSamples;
    private double rolloutKlSum;
    private int rolloutKlBatches;

    PpoAgent(long seed) {
        this.rng = new Random(seed);
        this.actor = new Net(actorSizes(), 0.01f, rng);
        this.twin = actor.twin();
        this.critic = new Net(criticSizes(), 1.0f, rng);
        this.consequences = new ConsequenceModel(rng);
        applyPriorBias(actor.w);
        if (gruTrainOn()) {
            int slot = OpponentMemory.slotStart();
            actor.trackInput(slot, GruCell.H); twin.trackInput(slot, GruCell.H); critic.trackInput(slot, GruCell.H);
        }
        for (int i = 0; i < perm.length; i++) perm[i] = i;
    }

    private static boolean gruTrainOn() { return Config.MEMORY && Config.GRU_TRAIN; }

    /** The GRU cell the environments should run (OpponentMemory.useCell): this agent's trained one. */
    GruCell gruCell() { return gru; }

    /** Call once per tick BEFORE actTrain: the GRU's hidden state before this tick's update and this tick's cell input. */
    void noteMemory(float[] hBefore, float[] x) {
        System.arraycopy(hBefore, 0, cH, 0, GruCell.H);
        System.arraycopy(x, 0, cX, 0, GruCell.X);
    }

    private static int[] actorSizes() {
        return sizes(Config.ACTION_SIZE);
    }

    private static int[] criticSizes() {
        return sizes(1);
    }

    private static int[] sizes(int out) {
        return sizes(out, Config.OBS_SIZE);
    }

    private static int[] sizes(int out, int obsSize) { return sizes(out, obsSize, Config.HIDDEN); }

    private static int[] sizes(int out, int obsSize, int[] hidden) {
        int[] s = new int[hidden.length + 2];
        s[0] = obsSize;
        System.arraycopy(hidden, 0, s, 1, hidden.length);
        s[s.length - 1] = out;
        return s;
    }

    private static int[][] knownHiddenShapes() {
        java.util.ArrayList<int[]> shapes = new java.util.ArrayList<>();
        shapes.add(new int[]{128, 128}); shapes.add(new int[]{256, 256}); shapes.add(new int[]{256, 256, 128}); shapes.add(new int[]{960, 960}); shapes.add(new int[]{1024, 1024, 512});
        shapes.add(Config.HIDDEN.clone());
        if (Config.TRANSFER_FROM != null) shapes.add(Config.TRANSFER_FROM.clone());
        return shapes.toArray(new int[0][]);
    }
    private static boolean canWiden(int[] from, int[] to) {
        if (from.length != to.length) return false;
        for (int i = 0; i < from.length; i++) if (from[i] > to[i]) return false;
        return true;
    }

    private static int[] identityMap(int n) {
        int[] map = new int[n]; for (int i = 0; i < n; i++) map[i] = i; return map;
    }

    static final float SNEAK_PRIOR_BIAS = -3f;

    /** Sane starting behaviour: tiny camera jitter, walk forward, sprint, rarely jump. PPO changes it from there. */
    private static void applyPriorBias(float[] w) {
        int ob = w.length - Config.ACTION_SIZE; // output biases are the last ACTION_SIZE floats
        // camera: mean 0 and a tiny std, so the agent starts with an almost invisible jitter and has to learn to turn faster
        w[ob + Config.OFF_YAW + 1] = (float) Math.log(Config.LOOK_STD_INIT);
        w[ob + Config.OFF_PITCH + 1] = (float) Math.log(Config.LOOK_STD_INIT);
        w[ob + Config.OFF_FWD + 2] = 1f;
        w[ob + Config.OFF_STRAFE + 1] = 1f;
        w[ob + Config.OFF_ATTACK] = 0.1f;
        w[ob + Config.OFF_JUMP] = -1.2f; // was -2 (p = 0.12): jump-crits were almost never tried; PPO still decides whether jumping pays
        w[ob + Config.OFF_SPRINT] = 1f;
        w[ob + Config.OFF_SNEAK] = SNEAK_PRIOR_BIAS; // p = 0.05: sneaking slows to 30 % and stops sprinting, so it starts rare; PPO decides whether it pays
    }

    // ------------------------------------------------------------------ acting
    /** Sample an action and remember the transition. The returned array is reused: use it right away. */
    float[] actTrain(float[] obs) {
        policyLogits(obs, logitsCopy);
        ActionMask.apply(logitsCopy, curMask); // temporary curriculum locks: locked heads can only pick their neutral choice
        float v = critic.forward(obs)[0];
        sampleAction(logitsCopy, curMask, rng, action);
        float logp = (float) evalPolicy(logitsCopy, action, curMask, 0f, 0f, null);
        updateHeadEntropy();

        if (hasPending) {
            // The previous action's actual next frame is supervised feedback for the consequence model.
            consequences.observe(pObs, pAct, obs);
            commit(false, 0f, v);
        }
        System.arraycopy(obs, 0, pObs, 0, obs.length);
        System.arraycopy(cH, 0, pH, 0, GruCell.H);
        System.arraycopy(cX, 0, pX, 0, GruCell.X);
        System.arraycopy(action, 0, pAct, 0, N_ACT);
        pLogp = logp;
        pMask = curMask;
        pVal = v;
        pRew = 0f;
        hasPending = true;
        totalTicks++;
        return action;
    }

    /** Most likely action, no learning, nothing stored (for /rl play). */
    /** Tracks each movement head's own entropy and raises that head's entropy bonus when it collapses (see Config.HEAD_ENTROPY_FLOOR_FRAC). */
    private void updateHeadEntropy() {
        final double[] now = {headEnt[0], headEnt[1], bernEnt[1]};
        final double[] max = {Math.log(3.0), Math.log(3.0), Math.log(2.0)};
        final int[] lock = {ActionMask.LOCK_FWD, ActionMask.LOCK_STRAFE, ActionMask.LOCK_JUMP};
        for (int i = 0; i < 3; i++) {
            if ((curMask & lock[i]) != 0) { headBoost[i] = 1f; headEmaInit[i] = false; continue; } // locked: nothing to explore
            headEntEma[i] = headEmaInit[i] ? 0.99 * headEntEma[i] + 0.01 * now[i] : now[i];
            headEmaInit[i] = true;
            headBoost[i] = headEntEma[i] < Config.HEAD_ENTROPY_FLOOR_FRAC * max[i] ? Config.HEAD_ENTROPY_BOOST : 1f;
        }
    }

    /** Multiplier currently applied to a head's entropy bonus (0 fwd/back, 1 strafe, 2 jump). For logs and tests. */
    float headBoost(int head) { return headBoost[head]; }

    /**
     * The policy as it is PLAYED (/rl play, the simulator's evaluation and probes): camera = mean (no sampling noise), discrete heads
     * sampled from the trained distribution at Config.PLAY_TEMPERATURE. actGreedy (argmax) can never choose a minority action, so it
     * reports one-sided strafing and zero jumps/back-steps/crits for a policy that actually mixes them. Uses its own RNG.
     */
    float[] actPlay(float[] obs) {
        if (!Config.PLAY_STOCHASTIC) return actGreedy(obs);
        policyLogits(obs, zMasked);
        ActionMask.apply(zMasked, curMask);
        float[] z = zMasked;
        final double t = Math.max(0.05, Config.PLAY_TEMPERATURE);
        action[0] = clampLook(z[Config.OFF_YAW] * (float) Math.exp(logStd(z[Config.OFF_YAW + 1])));
        action[1] = ActionMask.pitchLocked(curMask) ? 0f : clampLook(z[Config.OFF_PITCH] * (float) Math.exp(logStd(z[Config.OFF_PITCH + 1])));
        for (int h = 0; h < 2; h++) {
            int off = CAT_OFF[h];
            double max = Math.max(z[off], Math.max(z[off + 1], z[off + 2])) / t;
            double e0 = Math.exp(z[off] / t - max), e1 = Math.exp(z[off + 1] / t - max), e2 = Math.exp(z[off + 2] / t - max);
            double u = playRng.nextDouble() * (e0 + e1 + e2);
            action[2 + h] = u < e0 ? 0 : (u < e0 + e1 ? 1 : 2);
        }
        for (int b = 0; b < BERN_IDX.length; b++) {
            double pr = 1.0 / (1.0 + Math.exp(-z[BERN_IDX[b]] / t));
            action[4 + b] = playRng.nextDouble() < pr ? 1 : 0;
        }
        if (consequences.planningReady()) planWithPredictedConsequences(obs, z, curMask, action);
        return action;
    }

    /**
     * Evaluates a small pool of candidate actions with the learned one-step dynamics model. No move
     * type receives an intrinsic bonus; candidates are ranked by predicted combat outcomes plus the
     * critic's estimate of future return in the predicted next state.
     */
    private void planWithPredictedConsequences(float[] obs, float[] maskedLogits, int mask, float[] baseline) {
        System.arraycopy(baseline, 0, planBest, 0, N_ACT);
        double bestScore = scorePredictedAction(obs, planBest);
        for (int i = 0; i < PLAN_CANDIDATES; i++) {
            sampleAction(maskedLogits, mask, playRng, planCandidate);
            planCandidate[0] = clampLook(planCandidate[0]);
            planCandidate[1] = ActionMask.pitchLocked(mask) ? 0f : clampLook(planCandidate[1]);
            mutateCandidate(mask);
            double score = scorePredictedAction(obs, planCandidate);
            if (score > bestScore + PLAN_MIN_GAIN) {
                bestScore = score;
                System.arraycopy(planCandidate, 0, planBest, 0, N_ACT);
            }
        }
        System.arraycopy(planBest, 0, baseline, 0, N_ACT);
    }

    /** Mutates a generic action head, not a named combat technique; locked curriculum heads stay locked. */
    private void mutateCandidate(int mask) {
        if (playRng.nextDouble() < 0.65) {
            for (int attempt = 0; attempt < 6; attempt++) {
                int head = playRng.nextInt(6);
                switch (head) {
                    case 0:
                        if ((mask & ActionMask.LOCK_FWD) == 0) { planCandidate[2] = playRng.nextInt(3); return; }
                        break;
                    case 1:
                        if ((mask & ActionMask.LOCK_STRAFE) == 0) { planCandidate[3] = playRng.nextInt(3); return; }
                        break;
                    case 2:
                        if ((mask & ActionMask.LOCK_ATTACK) == 0) { planCandidate[4] = playRng.nextBoolean() ? 1f : 0f; return; }
                        break;
                    case 3:
                        if ((mask & ActionMask.LOCK_JUMP) == 0) { planCandidate[5] = playRng.nextBoolean() ? 1f : 0f; return; }
                        break;
                    case 4:
                        if ((mask & ActionMask.LOCK_SPRINT) == 0) { planCandidate[6] = playRng.nextBoolean() ? 1f : 0f; return; }
                        break;
                    case 5:
                        if ((mask & ActionMask.LOCK_SNEAK) == 0) { planCandidate[7] = playRng.nextBoolean() ? 1f : 0f; return; }
                        break;
                }
            }
        } else {
            // Small controller-space variations let the model compare alternative camera efforts too.
            planCandidate[0] = clampLook(planCandidate[0] + (float) (playRng.nextGaussian() * 0.12));
            if (!ActionMask.pitchLocked(mask)) planCandidate[1] = clampLook(planCandidate[1] + (float) (playRng.nextGaussian() * 0.10));
        }
    }

    private double scorePredictedAction(float[] obs, float[] candidate) {
        consequences.predict(obs, candidate, planNextFrame);
        buildPredictedObservation(obs, planNextFrame, planFutureObs);

        // Generic outcome objective: predicted health advantage. No critical/sprint/combo/strafe labels.
        double immediate = Config.W_DAMAGE * ((obs[15] - planNextFrame[15]) - (obs[0] - planNextFrame[0]));
        boolean enemyDead = planNextFrame[15] <= 0.005f;
        boolean meDead = planNextFrame[0] <= 0.005f;
        if (enemyDead) immediate += Config.W_WIN;
        if (meDead) immediate -= Config.W_WIN;

        // Keep the existing direct, outcome-grounded pointless-swing penalty; never reward a technique identity.
        double dist = obs[12] * 6.0;
        double gate = stage >= Config.GATE_RELAX_STAGE ? Config.MIN_ATTACK_STRENGTH_LATE : Config.MIN_ATTACK_STRENGTH;
        if (candidate[4] > 0.5f && obs[6] >= gate
                && Reward.isPointlessWhiff(dist, Math.abs(obs[13]), Math.abs(obs[14]))) {
            immediate -= Config.WHIFF_PENALTY;
        }

        double future = (enemyDead || meDead) ? 0.0 : critic.forward(planFutureObs)[0];
        return immediate * Config.REWARD_SCALE + Config.GAMMA * future;
    }

    /** Builds a plausible t+1 stack: predicted frame at lag 0, existing recent frames shifted back one slot. */
    private static void buildPredictedObservation(float[] current, float[] predictedFrame, float[] out) {
        System.arraycopy(current, 0, out, 0, Config.OBS_SIZE);
        System.arraycopy(predictedFrame, 0, out, 0, Config.FRAME);
        for (int targetSlot = 1; targetSlot < Config.LAGS.length; targetSlot++) {
            int sourceSlot = targetSlot - 1;
            int targetOffset = ObsLayout.offset(Config.LAGS, targetSlot, Config.FRAME, Config.FAR_FEATURES.length);
            int sourceOffset = ObsLayout.offset(Config.LAGS, sourceSlot, Config.FRAME, Config.FAR_FEATURES.length);
            if (ObsLayout.near(Config.LAGS[targetSlot])) {
                System.arraycopy(current, sourceOffset, out, targetOffset, Config.FRAME);
            } else {
                for (int j = 0; j < Config.FAR_FEATURES.length; j++) {
                    int feature = Config.FAR_FEATURES[j];
                    int sourceIndex;
                    if (ObsLayout.near(Config.LAGS[sourceSlot])) sourceIndex = sourceOffset + feature;
                    else sourceIndex = sourceOffset + j;
                    out[targetOffset + j] = current[sourceIndex];
                }
            }
        }
        // Hit-memory summary is retained as the closest available estimate; it updates on the next real observation.
    }

    String consequenceStatus() {
        if (consequences.planningReady()) {
            return "planning=ON, world-model samples=" + consequences.transitions()
                + ", validation MAE=" + String.format(java.util.Locale.ROOT, "%.3f", consequences.validationMae());
        }
        String err = Double.isNaN(consequences.validationMae()) ? "n/a"
            : String.format(java.util.Locale.ROOT, "%.3f", consequences.validationMae());
        return "planning=warming up, world-model samples=" + consequences.transitions() + ", validation MAE=" + err;
    }

    /**
     * The actor's logits for one observation. With SYMMETRIC_POLICY they are the average of the plain pass and the mirrored pass
     * (see Symmetry), so the policy is exactly left/right symmetric; otherwise the plain network output.
     */
    private void policyLogits(float[] obs, float[] dest) {
        float[] z = actor.forward(obs);
        if (!Config.SYMMETRIC_POLICY) {
            System.arraycopy(z, 0, dest, 0, z.length);
            return;
        }
        System.arraycopy(z, 0, zA, 0, z.length);
        Symmetry.obs(obs, obsM);
        float[] zm = twin.forward(obsM);
        Symmetry.logits(zA, zm, dest);
    }

    /** Test hook: the logits the policy would act on for this observation (no locks applied). */
    float[] logitsFor(float[] obs) {
        float[] out = new float[Config.ACTION_SIZE];
        policyLogits(obs, out);
        return out;
    }


    /** Learning-rate multiplier. The collapse guard lowers it after each rollback so the same drift is less likely to repeat. */
    volatile float lrScale = 1f;

    float[] actGreedy(float[] obs) {
        policyLogits(obs, zMasked);
        ActionMask.apply(zMasked, curMask);
        float[] z = zMasked;
        action[0] = clampLook(z[Config.OFF_YAW] * (float) Math.exp(logStd(z[Config.OFF_YAW + 1])));
        action[1] = ActionMask.pitchLocked(curMask) ? 0f : clampLook(z[Config.OFF_PITCH] * (float) Math.exp(logStd(z[Config.OFF_PITCH + 1])));
        for (int h = 0; h < 2; h++) {
            int best = 0;
            for (int i = 1; i < 3; i++) if (z[CAT_OFF[h] + i] > z[CAT_OFF[h] + best]) best = i;
            action[2 + h] = best;
        }
        for (int b = 0; b < BERN_IDX.length; b++) action[4 + b] = z[BERN_IDX[b]] > 0f ? 1 : 0;
        return action;
    }

    private static float clampLook(float x) {
        return Math.max(-1f, Math.min(1f, x));
    }

    /** Copy of both networks' weights (actor, critic) for the best-checkpoint rollback. */
    float[][] exportWeights() {
        return new float[][] {actor.w.clone(), critic.w.clone()};
    }

    /**
     * Restores weights from exportWeights(). Adam moments are cleared and all not-yet-learned experience
     * (collected by the policy that is being rolled back) is thrown away.
     */
    void importWeights(float[][] s) {
        System.arraycopy(s[0], 0, actor.w, 0, actor.w.length);
        System.arraycopy(s[1], 0, critic.w, 0, critic.w.length);
        actor.resetAdam();
        critic.resetAdam();
        trainReady = false;
        fill.n = 0;
        hasPending = false;
    }

    /** Drops the in-flight transition without learning from it (used by offline evaluation). */
    void discardPending() {
        hasPending = false;
    }

    /** Sets the temporary action locks (ActionMask bits) used for the next sampled actions. */
    void setMask(int mask) {
        curMask = mask;
    }

    int mask() {
        return curMask;
    }

    /** Entropy bonus coefficient (the curriculum raises it briefly after a lock is lifted). */
    void setEntropyCoef(float c) {
        entropyCoef = c;
    }

    /** Adds (unscaled) reward for the most recent action. Safe to call several times per tick. */
    void addReward(double r) {
        if (hasPending) pRew += (float) (r * Config.REWARD_SCALE);
    }

    /**
     * Ends the current episode.
     * @param terminal true if someone died (no future reward); false for timeouts / opponent leaving,
     *                 where the critic's estimate of {@code finalObs} is used to bootstrap.
     * @param finalObs the observation after the last action, or null if not available.
     */
    void endEpisode(boolean terminal, float[] finalObs) {
        if (!hasPending) return;
        float boot = 0f;
        if (finalObs != null) consequences.observe(pObs, pAct, finalObs);
        if (!terminal) boot = finalObs != null ? critic.forward(finalObs)[0] : pVal;
        commit(true, boot, 0f);
    }

    // ------------------------------------------------------------------ buffer
    private void commit(boolean done, float boot, float nextValue) {
        Rollout r = fill;
        int i = r.n++;
        System.arraycopy(pObs, 0, r.obs[i], 0, pObs.length);
        System.arraycopy(pAct, 0, r.act[i], 0, N_ACT);
        r.logp[i] = pLogp;
        r.val[i] = pVal;
        r.mask[i] = pMask;
        System.arraycopy(pH, 0, r.hPrev[i], 0, GruCell.H);
        System.arraycopy(pX, 0, r.gx[i], 0, GruCell.X);
        r.rew[i] = pRew;
        r.done[i] = done;
        r.boot[i] = boot;
        hasPending = false;
        if (r.n == Config.ROLLOUT) finishRollout(done ? 0f : nextValue);
    }

    private void finishRollout(float lastValue) {
        Rollout r = fill;
        final int T = r.n;
        float gae = 0f;
        for (int t = T - 1; t >= 0; t--) {
            float nonTerm = r.done[t] ? 0f : 1f;
            float nextV = (t == T - 1) ? lastValue : r.val[t + 1];
            float delta = r.rew[t] + Config.GAMMA * nextV * nonTerm + Config.GAMMA * r.boot[t] - r.val[t];
            gae = delta + Config.GAMMA * Config.GAE_LAMBDA * nonTerm * gae;
            r.adv[t] = gae;
            r.ret[t] = gae + r.val[t];
        }
        // normalise advantages over this rollout (returns stay as they are for the critic)
        double mean = 0;
        for (int t = 0; t < T; t++) mean += r.adv[t];
        mean /= T;
        double var = 0;
        for (int t = 0; t < T; t++) var += (r.adv[t] - mean) * (r.adv[t] - mean);
        float std = (float) Math.sqrt(var / T) + 1e-6f;
        for (int t = 0; t < T; t++) r.adv[t] = (float) ((r.adv[t] - mean) / std);

        if (trainReady) skipped++; // the learner didn't finish the last one in time
        Rollout tmp = train;
        train = fill;
        fill = tmp;
        fill.n = 0;
        trainReady = true;
        epoch = 0;
        mbIdx = 0;
        shuffle();
    }

    private void shuffle() {
        for (int i = perm.length - 1; i > 0; i--) {
            int j = rng.nextInt(i + 1);
            int t = perm[i]; perm[i] = perm[j]; perm[j] = t;
        }
    }

    // ------------------------------------------------------------------ learning
    /** One minibatch gradient step if a rollout is waiting. @return true if a step ran. */
    boolean learnTick() {
        if (!trainReady) return false;
        Rollout r = train;
        final int T = r.n;
        int start = mbIdx * Config.MINIBATCH;
        int end = Math.min(start + Config.MINIBATCH, T);
        int count = end - start;

        double kl = 0, ent = 0, vloss = 0;
        int clipped = 0;
        final boolean gruOn = gruTrainOn();
        for (int k = start; k < end; k++) {
            int i = perm[k];
            float[] obsI = r.obs[i];
            if (gruOn) {   // recompute the GRU part of the input with the CURRENT cell over the preceding ticks, from the state stored when it acted
                obsI = replayObs(r, i);
                actor.clearInputGrad(); twin.clearInputGrad(); critic.clearInputGrad();
            }
            policyLogits(obsI, zMasked);
            ActionMask.apply(zMasked, r.mask[i]); // same lock the action was sampled under, so log-probs stay correct
            evalPolicy(zMasked, r.act[i], r.mask[i], r.logp[i], r.adv[i], gz);
            if (Config.SYMMETRIC_POLICY) { // both passes get their share of the gradient (they share weights and the gradient buffer)
                Symmetry.grads(gz, gzA, gzB);
                actor.backward(gzA);
                twin.backward(gzB);
            } else {
                actor.backward(gz);
            }
            kl += (lastRatio - 1.0) - Math.log(lastRatio);
            ent += lastEntropy;
            if (lastClipped) clipped++;

            float v = critic.forward(obsI)[0];
            float err = v - r.ret[i];
            vloss += Math.abs(err) < 1f ? 0.5 * err * err : Math.abs(err) - 0.5;
            dV[0] = Math.max(-1f, Math.min(1f, err)); // Huber gradient
            critic.backward(dV);
            if (gruOn) {   // gradient of the loss w.r.t. the GRU outputs (both policy passes share them, the critic counts half) -> back through the window
                float[] ga = actor.inputGrad(), gb = twin.inputGrad(), gc = critic.inputGrad();
                for (int q = 0; q < GruCell.H; q++) gruGrad[q] = ga[q] + gb[q] + 0.5f * gc[q];
                gru.backWindow(gruGrad);
            }
        }
        if (gruOn) gru.step(Config.LR_GRU * lrScale, Config.GRU_MAX_NORM, count);
        float gn = actor.step(Config.LR_ACTOR * lrScale, Config.MAX_GRAD_NORM, count);
        critic.step(Config.LR_CRITIC * lrScale, Config.MAX_GRAD_NORM, count);

        stSteps++;
        stSamples += count;
        stKl += kl; stEnt += ent; stClip += clipped; stVLoss += vloss; stGrad += gn;

        double meanKl = kl / count;
        rolloutKlSum += meanKl;
        rolloutKlBatches++;
        mbIdx++;
        if (mbIdx * Config.MINIBATCH >= T) {
            mbIdx = 0;
            epoch++;
            if (epoch >= Config.EPOCHS) {
                trainReady = false;
                updates++;
            } else {
                shuffle();
            }
        }
        if (trainReady && meanKl > 1.5 * Config.TARGET_KL) { // policy already moved enough on this data
            trainReady = false;
            skipped++;
        }
        if (!trainReady && rolloutKlBatches > 0) {
            double rolloutKl = rolloutKlSum / rolloutKlBatches;
            if (rolloutKl > Config.TARGET_KL * Config.KL_ADAPT_UPPER) lrScale = Math.max(Config.LR_SCALE_MIN, lrScale * 0.7f);
            else if (rolloutKl < Config.TARGET_KL * Config.KL_ADAPT_LOWER) lrScale = Math.min(Config.LR_SCALE_MAX, lrScale * 1.05f);
            rolloutKlSum = 0; rolloutKlBatches = 0;
        }
        return true;
    }

    /**
     * The observation of sample i with its GRU slots recomputed by the current cell: replay up to Config.GRU_BPTT ticks of the rollout (never across
     * an episode end) from the hidden state stored at the window start. Leaves the window cached in the cell for backWindow().
     */
    private float[] replayObs(Rollout r, int i) {
        int s = i, n = 1;
        while (n < Config.GRU_BPTT && s > 0 && !r.done[s - 1]) { s--; n++; }
        gru.beginWindow(r.hPrev[s]);
        for (int t = s; t <= i; t++) gru.windowStep(r.gx[t]);
        System.arraycopy(r.obs[i], 0, obsTmp, 0, obsTmp.length);
        System.arraycopy(gru.windowH(), 0, obsTmp, OpponentMemory.slotStart(), GruCell.H);
        return obsTmp;
    }

    boolean learnerBusy() {
        return trainReady;
    }

    // ------------------------------------------------------------------ parallel training (sim/ParallelPvpTrain)
    /**
     * Moves this (acting-only) agent's finished rollout into {@code learner}, which then learns from it with learnTick(). The learner must be
     * idle. The data was collected by the weights this agent had; PPO's stored log-probs and clipping handle the small lag.
     * @return false if there was no finished rollout (or the learner was busy)
     */
    boolean handRolloutTo(PpoAgent learner) {
        if (!trainReady || learner.trainReady) return false;
        Rollout s = train, d = learner.train;
        final int n = s.n;
        for (int i = 0; i < n; i++) {
            System.arraycopy(s.obs[i], 0, d.obs[i], 0, s.obs[i].length);
            System.arraycopy(s.act[i], 0, d.act[i], 0, N_ACT);
        }
        System.arraycopy(s.logp, 0, d.logp, 0, n);
        System.arraycopy(s.val, 0, d.val, 0, n);
        System.arraycopy(s.rew, 0, d.rew, 0, n);
        System.arraycopy(s.boot, 0, d.boot, 0, n);
        System.arraycopy(s.done, 0, d.done, 0, n);
        System.arraycopy(s.adv, 0, d.adv, 0, n);
        System.arraycopy(s.ret, 0, d.ret, 0, n);
        System.arraycopy(s.mask, 0, d.mask, 0, n);
        for (int i = 0; i < n; i++) {
            System.arraycopy(s.hPrev[i], 0, d.hPrev[i], 0, GruCell.H);
            System.arraycopy(s.gx[i], 0, d.gx[i], 0, GruCell.X);
        }
        d.n = n;
        trainReady = false;
        learner.trainReady = true;
        learner.epoch = 0;
        learner.mbIdx = 0;
        learner.shuffle();
        return true;
    }

    /** Copies the learned weights (and the stage / tick bookkeeping) of {@code m} into this acting copy. Adam state stays with the learner. */
    void adoptFrom(PpoAgent m) {
        System.arraycopy(m.actor.w, 0, actor.w, 0, actor.w.length);
        System.arraycopy(m.critic.w, 0, critic.w, 0, critic.w.length);
        gru.copyWeightsFrom(m.gru);
        totalTicks = m.totalTicks;
        stage = m.stage;
        stageEnterTicks = m.stageEnterTicks;
    }

    /** Takes over {@code w}'s consequence (world) model by serialising it, so the saved checkpoint carries one that was trained on real transitions. */
    void adoptConsequenceFrom(PpoAgent w) throws IOException {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream(1 << 21);
        w.consequences.write(new java.io.DataOutputStream(bos));
        consequences.read(new java.io.DataInputStream(new java.io.ByteArrayInputStream(bos.toByteArray())));
    }

    /** Averages since the last call: {steps, kl, entropy, clipFraction, valueLoss, gradNorm}. */
    double[] takeStats() {
        double n = Math.max(1, stSamples);
        double[] s = {stSteps, stKl / n, stEnt / n, stClip / n, stVLoss / n, stSteps == 0 ? 0 : stGrad / stSteps};
        stSteps = 0; stSamples = 0; stKl = 0; stEnt = 0; stClip = 0; stVLoss = 0; stGrad = 0;
        return s;
    }

    // ------------------------------------------------------------------ policy math
    private static float logStd(float raw) {
        return Math.max(Config.LOOK_LOGSTD_MIN, Math.min(Config.LOOK_LOGSTD_MAX, raw));
    }

    /** Samples {yaw, pitch, fwd, strafe, attack, jump, sprint}. Static so FrozenPolicy shares it. Camera values are NOT clamped here (log-prob uses the raw sample). */
    static void sampleAction(float[] z, int mask, Random rng, float[] out) {
        for (int g = 0; g < 2; g++) {
            if (g == 1 && ActionMask.pitchLocked(mask)) { out[1] = 0f; continue; }
            int off = GAUSS_OFF[g];
            out[g] = (float) (Math.exp(logStd(z[off + 1])) * (z[off] + rng.nextGaussian())); // x = sigma * (m + eps)
        }
        for (int h = 0; h < 2; h++) {
            int off = CAT_OFF[h];
            float max = Math.max(z[off], Math.max(z[off + 1], z[off + 2]));
            double sum = 0;
            for (int i = 0; i < 3; i++) sum += Math.exp(z[off + i] - max);
            double u = rng.nextDouble() * sum, acc = 0;
            int pick = 2;
            for (int i = 0; i < 3; i++) {
                acc += Math.exp(z[off + i] - max);
                if (u < acc) { pick = i; break; }
            }
            out[2 + h] = pick;
        }
        for (int b = 0; b < BERN_IDX.length; b++) {
            double pr = 1.0 / (1.0 + Math.exp(-z[BERN_IDX[b]]));
            out[4 + b] = rng.nextDouble() < pr ? 1 : 0;
        }
    }

    private static double softplus(double x) {
        return x > 0 ? x + Math.log1p(Math.exp(-x)) : Math.log1p(Math.exp(x));
    }

    /**
     * Log-prob of action {@code a} under logits {@code z} (with the curriculum {@code mask}). If {@code grad} is
     * non-null it is filled with d(loss)/d(logits) for ONE sample of the PPO objective
     *   loss = -min(ratio*adv, clip(ratio)*adv) - entropyCoef * entropy.
     * Camera heads are parametrised as x = sigma * (m + eps), eps ~ N(0,1): the network outputs m (in std units) and
     * log-sigma. With a tiny sigma this keeps PPO's ratio well behaved (a plain mean parameter would make the
     * policy absurdly sensitive and the KL early stop would skip every rollout).
     * A locked pitch axis contributes nothing. lastEntropy covers the discrete + on/off heads only.
     */
    double evalPolicy(float[] z, float[] a, int mask, float oldLogp, float adv, float[] grad) {
        double logp = 0, ent = 0;
        // ---- camera (Gaussian) ----
        double[] zs2 = gaussZ2;
        for (int g = 0; g < 2; g++) {
            int off = GAUSS_OFF[g];
            if (g == 1 && ActionMask.pitchLocked(mask)) { zs2[g] = Double.NaN; continue; }
            float ls = logStd(z[off + 1]);
            double sigma = Math.exp(ls);
            double zsc = a[g] / sigma - z[off]; // (x - mean) / sigma with mean = m * sigma
            zs2[g] = zsc * zsc;
            logp += -0.5 * zs2[g] - ls - HALF_LOG_2PI;
        }
        // ---- categorical (forward, strafe) ----
        for (int h = 0; h < 2; h++) {
            int off = CAT_OFF[h];
            float max = Math.max(z[off], Math.max(z[off + 1], z[off + 2]));
            double sum = 0;
            for (int i = 0; i < 3; i++) sum += Math.exp(z[off + i] - max);
            double lse = max + Math.log(sum);
            double hEnt = 0;
            for (int i = 0; i < 3; i++) {
                double l = z[off + i] - lse;
                ls[off + i] = (float) l;
                p[off + i] = (float) Math.exp(l);
                hEnt -= p[off + i] * l;
            }
            logp += ls[off + Math.round(a[2 + h])];
            ent += hEnt;
            headEnt[h] = hEnt;
        }
        for (int b = 0; b < BERN_IDX.length; b++) {
            double zb = z[BERN_IDX[b]];
            double pb = 1.0 / (1.0 + Math.exp(-zb));
            boolean on = a[4 + b] > 0.5f;
            logp += on ? -softplus(-zb) : -softplus(zb);
            bernEnt[b] = pb * softplus(-zb) + (1 - pb) * softplus(zb);
            ent += bernEnt[b];
            bernP[b] = pb;
        }
        lastEntropy = ent;
        double ratio = Math.exp(Math.max(-20.0, Math.min(20.0, logp - oldLogp)));
        lastRatio = ratio;
        lastClipped = (adv >= 0 && ratio > 1 + Config.CLIP) || (adv < 0 && ratio < 1 - Config.CLIP);

        if (grad != null) {
            double coef = lastClipped ? 0.0 : -adv * ratio; // d(loss)/d(logp)
            for (int g = 0; g < 2; g++) {
                int off = GAUSS_OFF[g];
                if (Double.isNaN(zs2[g])) { grad[off] = 0f; grad[off + 1] = 0f; continue; }
                float rawLs = z[off + 1];
                double sigma = Math.exp(logStd(rawLs));
                double zsc = a[g] / sigma - z[off];
                boolean inRange = rawLs > Config.LOOK_LOGSTD_MIN && rawLs < Config.LOOK_LOGSTD_MAX;
                grad[off] = (float) (coef * zsc); // dlogp/dm
                if (inRange) grad[off + 1] = (float) (coef * (zsc * (zsc + z[off]) - 1.0) - Config.ENTROPY_COEF * Config.LOOK_ENTROPY_SCALE);
                else grad[off + 1] = rawLs <= Config.LOOK_LOGSTD_MIN ? -Config.LOOK_CLAMP_RESTORE : Config.LOOK_CLAMP_RESTORE; // push back inside the limits
            }
            for (int h = 0; h < 2; h++) {
                int off = CAT_OFF[h];
                for (int i = 0; i < 3; i++) {
                    double dlogp = (i == Math.round(a[2 + h]) ? 1.0 : 0.0) - p[off + i];
                    double dEnt = -p[off + i] * (ls[off + i] + headEnt[h]);
                    grad[off + i] = (float) (coef * dlogp - entropyCoef * headBoost[h] * dEnt);
                }
            }
            for (int b = 0; b < BERN_IDX.length; b++) {
                double zb = z[BERN_IDX[b]], pb = bernP[b];
                double dlogp = (a[4 + b] > 0.5f ? 1.0 : 0.0) - pb;
                double dEnt = -zb * pb * (1 - pb);
                grad[BERN_IDX[b]] = (float) (coef * dlogp - entropyCoef * (b == 1 ? headBoost[2] : 1f) * dEnt);
            }
        }
        return logp;
    }

    private final double[] headEnt = new double[2];
    private final double[] bernP = new double[BERN_IDX.length];
    private final double[] gaussZ2 = new double[2];

    /** Largest possible lastEntropy for the heads NOT locked by {@code mask} (locked heads contribute 0). */
    static double maxEntropy(int mask) {
        double e = 0.0;
        if ((mask & ActionMask.LOCK_ATTACK) == 0) e += Math.log(2.0);
        if ((mask & ActionMask.LOCK_FWD) == 0) e += Math.log(3.0);
        if ((mask & ActionMask.LOCK_STRAFE) == 0) e += Math.log(3.0);
        if ((mask & ActionMask.LOCK_JUMP) == 0) e += Math.log(2.0);
        if ((mask & ActionMask.LOCK_SPRINT) == 0) e += Math.log(2.0);
        return e;
    }

    // test hooks
    double lastEntropy() { return lastEntropy; }
    double lastRatio() { return lastRatio; }

    // ------------------------------------------------------------------ persistence
    void save(Path file) throws IOException {
        Files.createDirectories(file.getParent());
        backupOnce(file);
        Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(tmp)))) {
            out.writeInt(MAGIC);
            out.writeInt(VERSION);
            out.writeInt(actor.w.length);
            out.writeInt(critic.w.length);
            out.writeLong(totalTicks);
            out.writeInt(updates);
            out.writeInt(stage);
            out.writeLong(stageEnterTicks);
            actor.write(out);
            critic.write(out);
            consequences.write(out);
            out.writeInt(TRAILER_MAGIC);   // older code stops reading before this: still loadable by older builds
            out.writeLong(techTicks);
            out.writeInt(GRU_TRAILER_MAGIC);   // optional: the trained memory cell (a build without it stops before this)
            gru.write(out);
        }
        Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
    }

    /** Before the FIRST overwrite of an existing save in this JVM, keep a timestamped copy (never silently lose trained weights). */
    private static void backupOnce(Path file) {
        Path abs = file.toAbsolutePath().normalize();
        if (!Files.exists(abs) || !BACKED_UP.add(abs)) return;
        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        Path bak = abs.resolveSibling(abs.getFileName() + ".bak-" + ts);
        try {
            Files.copy(abs, bak, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("rlpvp: backed up existing checkpoint to " + bak);
        } catch (IOException e) {
            System.err.println("rlpvp: WARNING could not back up " + abs + " before overwriting: " + e.getMessage());
        }
    }

    static PpoAgent load(Path file, long seed) throws IOException {
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(file)))) {
            int magic = in.readInt();
            int version = in.readInt();
            if (magic != MAGIC || (version < 4 || version > VERSION)) {
                throw new IOException("not a compatible PPO state file (supported state versions: 4, 5, 6 and 7)");
            }
            int a = in.readInt(), c = in.readInt();
            // Detect the checkpoint's original architecture independently of the selected runtime model.
            // Width changes can be warm-started; depth changes are intentionally rejected by Net.readTransferred.
            int legacyFrame = 0, oldOut = Config.ACTION_SIZE, sourceObs = Config.OBS_SIZE;
            boolean legacy = false, preSneak = false;
            int[] sourceHidden = null, inputMap = null;
            int preIn = ObsLayout.sizePreSneak();
            int baseObs = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, Config.SUMMARY_BASE);
            outer: for (int[] hidden : knownHiddenShapes()) {
                for (int out : new int[]{Config.ACTION_SIZE, Config.ACTION_SIZE_PRE_SNEAK}) {
                    if (a == Net.paramCount(sizes(out, Config.OBS_SIZE, hidden))
                            && c == Net.paramCount(sizes(1, Config.OBS_SIZE, hidden))) {
                        sourceHidden = hidden; sourceObs = Config.OBS_SIZE; oldOut = out;
                        preSneak = out == Config.ACTION_SIZE_PRE_SNEAK;
                        inputMap = preSneak ? ObsLayout.preSneakMap() : identityMap(sourceObs);
                        break outer;
                    }
                }
                // v7.19: checkpoints made before the memory block (same layout minus MEMORY_FEATURES summary inputs); the new inputs start at zero weight.
                if (Config.MEMORY) {
                    int preMemSummary = Config.SUMMARY - Config.MEMORY_FEATURES;
                    int preMemObs = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, preMemSummary);
                    if (a == Net.paramCount(sizes(Config.ACTION_SIZE, preMemObs, hidden)) && c == Net.paramCount(sizes(1, preMemObs, hidden))) {
                        sourceHidden = hidden; sourceObs = preMemObs; oldOut = Config.ACTION_SIZE;
                        inputMap = ObsLayout.summaryMap(preMemSummary); break outer;
                    }
                }
                // Checkpoints with the original 20 summary inputs remain loadable when optional summary memories are appended.
                if (Config.SUMMARY > Config.SUMMARY_BASE && a == Net.paramCount(sizes(Config.ACTION_SIZE, baseObs, hidden))
                        && c == Net.paramCount(sizes(1, baseObs, hidden))) {
                    sourceHidden = hidden; sourceObs = baseObs; oldOut = Config.ACTION_SIZE;
                    inputMap = ObsLayout.baseSummaryMap(); break outer;
                }
                // Preserve older OBS_V2 checkpoints (20 base + 10 motion-memory inputs) when sprint memory is added.
                int oldV2Obs = ObsLayout.size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, Config.SUMMARY_BASE + Config.V2_FEATURES);
                if (Config.SPRINT_FOLLOWUP && Config.OBS_V2 && a == Net.paramCount(sizes(Config.ACTION_SIZE, oldV2Obs, hidden))
                        && c == Net.paramCount(sizes(1, oldV2Obs, hidden))) {
                    sourceHidden = hidden; sourceObs = oldV2Obs; oldOut = Config.ACTION_SIZE;
                    inputMap = ObsLayout.summaryMap(Config.SUMMARY_BASE + Config.V2_FEATURES); break outer;
                }
                if (a == Net.paramCount(sizes(Config.ACTION_SIZE_PRE_SNEAK, preIn, hidden))
                        && c == Net.paramCount(sizes(1, preIn, hidden))) {
                    sourceHidden = hidden; sourceObs = preIn; oldOut = Config.ACTION_SIZE_PRE_SNEAK;
                    preSneak = true; inputMap = ObsLayout.preSneakMap(); break outer;
                }
                for (int lf : Config.LEGACY_FRAMES) {
                    int oldIn = lf * Config.LEGACY_LAGS.length;
                    for (int out : new int[]{Config.ACTION_SIZE, Config.ACTION_SIZE_PRE_SNEAK}) {
                        if (a == Net.paramCount(sizes(out, oldIn, hidden))
                                && c == Net.paramCount(sizes(1, oldIn, hidden))) {
                            sourceHidden = hidden; sourceObs = oldIn; oldOut = out; legacyFrame = lf;
                            legacy = true; inputMap = ObsLayout.legacyMap(legacyFrame, Config.LEGACY_LAGS); break outer;
                        }
                    }
                }
            }
            if (sourceHidden == null) {
                throw new IOException("unrecognized checkpoint network layout: " + a + "/" + c + " params (selected model " + Config.MODEL + ")");
            }
            if (sourceHidden.length != Config.HIDDEN.length) {
                throw new IOException("checkpoint has " + sourceHidden.length + " hidden layers but selected model has " + Config.HIDDEN.length
                    + "; depth changes are not transferable. Choose a target with the same number of layers or train the new depth from scratch.");
            }
            boolean widening = !java.util.Arrays.equals(sourceHidden, Config.HIDDEN)
                && canWiden(sourceHidden, Config.HIDDEN) && sourceObs == Config.OBS_SIZE && !legacy && !preSneak;
            PpoAgent agent = new PpoAgent(seed);
            // A v4 critic was trained against technique-identity bonuses. Keep the learned actor, but
            // reinitialise the critic so model-based look-ahead is trained on the new outcome objective.
            float[] freshCriticWeights = agent.critic.w.clone();
            agent.totalTicks = in.readLong();
            agent.updates = in.readInt();
            agent.stage = in.readInt();
            agent.stageEnterTicks = in.readLong();
            int oldIn = sourceObs;
            int[] oldActorSizes = sizes(oldOut, oldIn, sourceHidden);
            int[] oldCriticSizes = sizes(1, oldIn, sourceHidden);
            boolean sameArchitecture = java.util.Arrays.equals(oldActorSizes, actorSizes())
                && java.util.Arrays.equals(oldCriticSizes, criticSizes());
            if (sameArchitecture && !legacy && !preSneak) {
                agent.actor.read(in); agent.critic.read(in);
            } else if (widening) {
                Net oldActor = new Net(oldActorSizes, 0f, null);
                Net oldCritic = new Net(oldCriticSizes, 0f, null);
                oldActor.read(in); oldCritic.read(in);
                agent.actor.widenFrom(oldActor); agent.critic.widenFrom(oldCritic);
                System.out.println("rlpvp: function-preserving widening " + java.util.Arrays.toString(sourceHidden) + " -> "
                    + java.util.Arrays.toString(Config.HIDDEN) + "; Adam moments reset; curriculum/counters retained.");
            } else {
                agent.actor.readTransferred(in, oldActorSizes, inputMap);
                agent.critic.readTransferred(in, oldCriticSizes, inputMap);
                if (!java.util.Arrays.equals(sourceHidden, Config.HIDDEN))
                    System.out.println("rlpvp: warm-started " + Config.MODEL + " from checkpoint hidden shape " + java.util.Arrays.toString(sourceHidden));
            }
            if (oldOut < Config.ACTION_SIZE || preSneak) {
                agent.actor.w[agent.actor.w.length - Config.ACTION_SIZE + Config.OFF_SNEAK] = SNEAK_PRIOR_BIAS;
            }
            if (version >= 5) {
                if (preSneak && !legacy) agent.consequences.readDiscardingOldLayout(in, version, preIn + 7, Config.FRAME_PRE_SNEAK);
                else if (legacy) throw new IOException("unsupported combination: legacy frame layout with a consequence section");
                else if (sourceObs != Config.OBS_SIZE) agent.consequences.readDiscardingOldInputLayout(in, version, sourceObs);
                else agent.consequences.read(in, version);
            } else {
                System.arraycopy(freshCriticWeights, 0, agent.critic.w, 0, freshCriticWeights.length);
                agent.critic.resetAdam();
                // The consequence model remains intentionally untrained. It only activates after it
                // has gathered and validated transitions in this runtime.
            }
            try {
                if (in.readInt() == TRAILER_MAGIC) agent.techTicks = Math.max(0L, in.readLong());
            } catch (EOFException e) {
                // save from before technique discovery: no trailer, annealing clock starts at 0
            }
            try {
                if (in.readInt() == GRU_TRAILER_MAGIC) agent.gru.read(in);
            } catch (EOFException e) {
                // save from before the trainable memory cell: the default cell is used (same behaviour as the old fixed memory)
            }
            return agent;
        }
    }
}