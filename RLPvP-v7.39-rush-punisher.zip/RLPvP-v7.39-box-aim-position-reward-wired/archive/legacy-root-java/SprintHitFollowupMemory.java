package com.rlpvp;

/**
 * Descriptive temporal memory for learning what happens after a confirmed sprint hit.
 * It never selects or forces an action; it only contributes observation features and event metrics.
 */
final class SprintHitFollowupMemory {
    static final int NONE = 0, SPRINT_HIT = 1, FOLLOWUP_HIT = 2, EXPIRED = 4;
    static final int FEATURES = 8;
    private static final int WINDOW_TICKS = 20;
    private static final int PULSE_TICKS = 3;

    private boolean active;
    private int age = WINDOW_TICKS, pulseAge = PULSE_TICKS;
    private float startDistance, separationDelta;
    private float enemyForward, enemySide, enemyVertical;
    private boolean converted, expired;
    private int lastFollowupTicks;
    private final float[] features = new float[FEATURES];

    void reset() {
        active = false;
        age = WINDOW_TICKS;
        pulseAge = PULSE_TICKS;
        startDistance = separationDelta = enemyForward = enemySide = enemyVertical = 0f;
        converted = expired = false;
        lastFollowupTicks = 0;
        java.util.Arrays.fill(features, 0f);
    }

    /**
     * Call once per tick after the current frame is built. {@code sprintHitLanded} and
     * {@code anyHitLanded} must describe confirmed damage, not an attempted swing.
     * Frame values use the project's normalized observation scale.
     */
    int tick(boolean sprintHitLanded, boolean anyHitLanded, float distance,
             float enemyForwardVelocity, float enemySideVelocity, float enemyVerticalVelocity) {
        int events = NONE;
        if (pulseAge < PULSE_TICKS) pulseAge++;

        // Resolve the previous opportunity first, so a new sprint hit can also be counted as
        // the follow-up to the preceding sprint hit when both happen on the same confirmed hit.
        if (active) {
            age++;
            separationDelta = clamp((distance - startDistance) / 3f);
            if (anyHitLanded && age > 0) {
                active = false;
                converted = true;
                expired = false;
                pulseAge = 0;
                lastFollowupTicks = age;
                events |= FOLLOWUP_HIT;
            } else if (age >= WINDOW_TICKS) {
                active = false;
                converted = false;
                expired = true;
                pulseAge = 0;
                events |= EXPIRED;
            }
        }
        if (sprintHitLanded) {
            active = true;
            age = 0;
            startDistance = distance;
            separationDelta = 0f;
            if ((events & FOLLOWUP_HIT) == 0) {
                converted = false;
                pulseAge = PULSE_TICKS;
            }
            expired = false;
            events |= SPRINT_HIT;
        }
        enemyForward = clamp(enemyForwardVelocity);
        enemySide = clamp(enemySideVelocity);
        enemyVertical = clamp(enemyVerticalVelocity);
        fill(features, 0);
        return events;
    }

    private void fill(float[] out, int offset) {
        out[offset] = active ? 1f : 0f;
        out[offset + 1] = active ? clamp(age / (float) WINDOW_TICKS) : (age >= WINDOW_TICKS ? 1f : clamp(age / (float) WINDOW_TICKS));
        out[offset + 2] = active ? separationDelta : 0f;
        out[offset + 3] = enemyForward;
        out[offset + 4] = enemySide;
        out[offset + 5] = enemyVertical;
        out[offset + 6] = converted && pulseAge < PULSE_TICKS ? 1f : 0f;
        out[offset + 7] = expired && pulseAge < PULSE_TICKS ? 1f : 0f;
    }

    int lastFollowupTicks() { return lastFollowupTicks; }

    void fillSummary(float[] summary) {
        if (!Config.SPRINT_FOLLOWUP) return;
        int offset = Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0);
        if (summary.length >= offset + FEATURES) fill(summary, offset);
    }

    private static float clamp(float v) { return Float.isNaN(v) ? 0f : Math.max(-1f, Math.min(1f, v)); }
}
