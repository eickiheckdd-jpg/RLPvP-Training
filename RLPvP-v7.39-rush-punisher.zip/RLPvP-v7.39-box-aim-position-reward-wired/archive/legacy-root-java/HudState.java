package com.rlpvp;

import java.util.ArrayList;
import java.util.List;

/**
 * Per-frame HUD state that must survive between frames: smoothed bar values, the toast, and alert detection.
 * Render thread only. No Minecraft classes.
 */
final class HudState {
    /** A short line shown under the widget (red = needs attention). */
    record Alert(String text, int color) {}

    // ---- smoothed display values (so bars glide instead of jumping every 5 ticks)
    double myHp = 20, oppHp = 20, charge = 1, dist = 4, yawErr = 0, pitchErr = 0, entropy = 0, winRate = 0;
    private long lastNanos = 0;
    private boolean primed = false;

    // ---- toast
    private String toastText = "";
    private int toastColor = HudTheme.WHITE;
    private long toastUntilMs = 0;
    private int toastPriority = 0;

    // ---- change detection
    private int lastEpisodes = -1, lastStage = -1, lastRollbacks = -1;
    private long rollbackShownUntilMs = 0;

    /** Advances the smoothing by the real time since the last frame and feeds change detection. */
    void update(RlHud.Data d) {
        long now = System.nanoTime();
        double dt = lastNanos == 0 ? 0.016 : Math.min(0.1, (now - lastNanos) / 1e9);
        lastNanos = now;
        long ms = System.currentTimeMillis();

        if (!primed || !d.inEpisode()) { // snap while idle so a new episode does not start with stale numbers
            myHp = d.myHp(); oppHp = d.oppHp(); charge = d.charge(); dist = d.dist();
            yawErr = d.yawErrDeg(); pitchErr = d.pitchErrDeg();
            primed = true;
        } else {
            myHp = approach(myHp, d.myHp(), dt, 14);
            oppHp = approach(oppHp, d.oppHp(), dt, 14);
            charge = approach(charge, d.charge(), dt, 25);
            dist = approach(dist, d.dist(), dt, 18);
            yawErr = approach(yawErr, d.yawErrDeg(), dt, 22);
            pitchErr = approach(pitchErr, d.pitchErrDeg(), dt, 22);
        }
        entropy = approach(entropy, d.entropy(), dt, 4);
        winRate = approach(winRate, d.winRate(), dt, 4);

        if (lastStage != -1 && d.stage() != lastStage) {
            toast("Stage " + d.stage() + ": " + d.opponent(), HudTheme.YELLOW, 3, ms, 4000);
        }
        if (lastRollbacks != -1 && d.rollbacks() > lastRollbacks) {
            rollbackShownUntilMs = ms + 8000;
            toast("Collapse guard: rolled back to best weights", HudTheme.ORANGE, 4, ms, 5000);
        }
        lastStage = d.stage();
        lastEpisodes = d.episodes();
        lastRollbacks = d.rollbacks();
    }

    private static double approach(double cur, double target, double dt, double rate) {
        double k = 1 - Math.exp(-rate * dt);
        return cur + (target - cur) * k;
    }

    // ------------------------------------------------------------------ toast
    private void toast(String text, int color, int priority, long nowMs, long durationMs) {
        boolean showing = nowMs < toastUntilMs;
        if (showing && priority < toastPriority) return; // never let a routine result replace a warning
        toastText = text;
        toastColor = color;
        toastPriority = priority;
        toastUntilMs = nowMs + durationMs;
    }

    boolean toastActive() {
        return System.currentTimeMillis() < toastUntilMs && !toastText.isEmpty();
    }

    String toastText() { return toastText; }

    int toastColor() { return toastColor; }

    /** 0..255, fading out over the last 600 ms. */
    int toastAlpha() {
        long left = toastUntilMs - System.currentTimeMillis();
        return (int) Math.max(0, Math.min(255, left * 255 / 600));
    }

    // ------------------------------------------------------------------ alerts
    /** Conditions worth a warning colour. Training-only ones are skipped in play mode. */
    List<Alert> alerts(RlHud.Data d) {
        List<Alert> out = new ArrayList<>(3);
        long ms = System.currentTimeMillis();
        if (!d.play() && d.entropy() > 0 && d.entropy() < Trainer.entropyFloorNow) out.add(new Alert("low entropy", HudTheme.entropyColor(d.entropy())));
        if (!d.play() && ms < rollbackShownUntilMs) out.add(new Alert("rolled back", HudTheme.ORANGE));
        if (d.inEpisode() && !d.los()) out.add(new Alert("no line of sight", HudTheme.RED));
        if (!d.play() && d.inEpisode() && d.stage() >= 6 && d.idleScale() < 0.3) out.add(new Alert("stalling: no hit", HudTheme.ORANGE));
        return out;
    }

    int alertColor(RlHud.Data d) {
        List<Alert> a = alerts(d);
        return a.isEmpty() ? HudTheme.GREEN : a.get(0).color();
    }
}