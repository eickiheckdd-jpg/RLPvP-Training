package com.rlpvp;

/**
 * Longer-term memory features appended to the summary (Config.MEMORY, 16 inputs). Descriptive only: never selects an action.
 *
 * HABITS (8, running statistics of THIS episode's opponent, warmed up as a plain mean, then an EMA): strafe activity, strafe direction
 * flip rate, sprint share, airborne share, swing rate, preferred distance, approach pressure, and how often it hits back within 20 ticks
 * after I hit it. They tell the policy what kind of fighter it is facing, not just what happened in the last 4.8 s.
 *
 * RECURRENT (8): the hidden state of a GRU cell (GruCell) driven by compact fight signals. With Config.GRU_TRAIN the agent trains the cell with
 * truncated backprop through time (see PpoAgent.learnTick); the cell it uses comes from useCell(agent.gruCell()). Without an agent cell it
 * uses the untrained default, which integrates over about 3 to 100 ticks. All 16 inputs are left/right mirror-invariant, so Symmetry (which only
 * flips lateral inputs) stays exactly equivariant.
 */
final class OpponentMemory {
    static final int HABITS = 8, H = GruCell.H, X = GruCell.X, FEATURES = HABITS + H;
    private static final double ALPHA = 1.0 / 150.0;
    private static final int COUNTER_WINDOW = 20;

    private GruCell cell = GruCell.DEFAULT;
    private final float[] h = new float[H], hBefore = new float[H], x = new float[X], out = new float[H];
    private final double[] hab = new double[HABITS];
    private final int[] habN = new int[HABITS];
    private int lastSide, counterLeft;
    private boolean prevSwing;

    OpponentMemory() { reset(); }

    /** Use this (trained) cell from the next tick on. Null = the shared default. */
    void useCell(GruCell c) { cell = c == null ? GruCell.DEFAULT : c; }

    void reset() {
        java.util.Arrays.fill(h, 0f);
        java.util.Arrays.fill(hBefore, 0f);
        java.util.Arrays.fill(hab, 0.0);
        java.util.Arrays.fill(habN, 0);
        hab[7] = 0.5; habN[7] = 2;           // hit-back rate starts undecided
        lastSide = 0; counterLeft = 0; prevSwing = false;
    }

    /** Hidden state before this tick's update and this tick's cell input (for PpoAgent.noteMemory). */
    float[] hBefore() { return hBefore; }
    float[] x() { return x; }

    /** Input index of the first recurrent output inside the network observation. */
    static int slotStart() {
        return Config.OBS_SIZE - Config.SUMMARY + Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0)
            + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0) + HABITS;
    }

    private void ema(int k, double v, double alpha) {
        habN[k]++;
        double a = Math.max(alpha, 1.0 / habN[k]);
        hab[k] += a * (v - hab[k]);
    }

    private static float c(float v) { return Float.isNaN(v) ? 0f : Math.max(-1f, Math.min(1f, v)); }

    /** Call once per tick after the frame is built. dealt / taken = confirmed damage this tick. */
    void tick(float[] fr, boolean dealt, boolean taken) {
        // ---- habits ----
        float side = c(fr[17]);
        int sd = Math.abs(side) > 0.02f ? (side > 0 ? 1 : -1) : 0;
        ema(0, sd != 0 ? 1.0 : 0.0, ALPHA);                            // strafe ACTIVITY (not direction): keeps every memory input mirror-invariant, see Symmetry
        if (sd != 0) { ema(1, lastSide != 0 && sd != lastSide ? 1.0 : 0.0, ALPHA * 2); lastSide = sd; }
        ema(2, fr[22] > 0.5f ? 1.0 : 0.0, ALPHA);
        ema(3, fr[19] > 0.5f ? 0.0 : 1.0, ALPHA);
        boolean swing = fr[23] > 0.5f;
        ema(4, swing && !prevSwing ? 1.0 : 0.0, ALPHA);
        prevSwing = swing;
        ema(5, c(fr[12]), ALPHA);
        ema(6, c(-fr[16] * (fr[9] >= 0f ? 1f : -1f)), ALPHA);           // enemy velocity toward me (+) or away (-)
        if (taken && counterLeft > 0) { ema(7, 1.0, 0.2); counterLeft = 0; }
        else if (counterLeft > 0 && --counterLeft == 0) ema(7, 0.0, 0.2);
        if (dealt) counterLeft = COUNTER_WINDOW;

        // ---- recurrent cell ----
        x[0] = c(fr[12]); x[1] = c(fr[47]); x[2] = Math.abs(side); x[3] = c(fr[16]); x[4] = swing ? 1f : 0f; x[5] = fr[22] > 0.5f ? 1f : 0f;
        x[6] = dealt ? 1f : 0f; x[7] = taken ? 1f : 0f;
        System.arraycopy(h, 0, hBefore, 0, H);
        cell.step(h, x, out);
    }

    void fillSummary(float[] summary) {
        if (!Config.MEMORY) return;
        int off = Config.SUMMARY_BASE + (Config.OBS_V2 ? Config.V2_FEATURES : 0) + (Config.SPRINT_FOLLOWUP ? Config.SPRINT_FOLLOWUP_FEATURES : 0);
        if (summary.length < off + FEATURES) return;
        for (int k = 0; k < HABITS; k++) {
            double v = k == 1 ? hab[k] * 5.0 : k == 4 ? hab[k] * 10.0 : hab[k];   // flip / swing rates are small: scale into range
            summary[off + k] = c((float) (k == 0 || k == 2 || k == 3 || k == 7 ? 2.0 * v - 1.0 : v));
        }
        for (int j = 0; j < H; j++) summary[off + HABITS + j] = h[j];
    }
}
