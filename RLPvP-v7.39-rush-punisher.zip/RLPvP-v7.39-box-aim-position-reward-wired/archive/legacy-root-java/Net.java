package com.rlpvp;

import java.util.Random;

/**
 * Small MLP with manual backprop and Adam. Pure Java (no Minecraft classes) and allocation-free
 * after construction, so it is cheap to run every tick.
 *
 * Params are one flat float[]: for each layer, weights (out x in, one row per output neuron)
 * then biases. Hidden layers use tanh, the output layer is linear.
 *
 * Usage for one sample: forward(x), then backward(dOut) which ADDS into the gradient buffer.
 * Call step(...) once per minibatch to apply the averaged gradient and clear it.
 */
final class Net {
    final int[] sizes;
    final float[] w;
    private final float[] g;
    private final float[] m;
    private final float[] v;
    private final int[] off;
    private final float[][] act;     // act[0] = input (reference, not copied), act[l+1] = layer output
    private final float[] dA;
    private final float[] dB;
    int adamT = 0;

    Net(int[] sizes, float outScale, Random rng) {
        this.sizes = sizes.clone();
        int layers = sizes.length - 1;
        off = new int[layers];
        int n = 0, widest = 0;
        for (int l = 0; l < layers; l++) {
            off[l] = n;
            n += sizes[l] * sizes[l + 1] + sizes[l + 1];
            widest = Math.max(widest, sizes[l + 1]);
        }
        widest = Math.max(widest, sizes[0]);
        w = new float[n];
        g = new float[n];
        m = new float[n];
        v = new float[n];
        act = new float[sizes.length][];
        for (int l = 1; l < sizes.length; l++) act[l] = new float[sizes[l]];
        dA = new float[widest];
        dB = new float[widest];
        if (rng != null) init(outScale, rng);
    }

    /** Shares {@code b}'s weights, gradient buffer and Adam state, but has its OWN activation buffers (see twin()). */
    private Net(Net b) {
        sizes = b.sizes;
        w = b.w;
        g = b.g;
        m = b.m;
        v = b.v;
        off = b.off;
        act = new float[sizes.length][];
        for (int l = 1; l < sizes.length; l++) act[l] = new float[sizes[l]];
        dA = new float[b.dA.length];
        dB = new float[b.dB.length];
    }

    /**
     * A second view of the SAME network: same weights, same gradient buffer, separate activation buffers. That lets two inputs
     * be run forward first and back-propagated afterwards (the symmetric policy runs the observation and its mirror image).
     * Only the original should call step().
     */
    Net twin() {
        return new Net(this);
    }

    // ---- gradient w.r.t. a slice of the INPUT (the GRU outputs inside the observation); accumulates across backward() calls until cleared ----
    private int igFrom, igCnt;
    private float[] inGrad = new float[0];

    void trackInput(int from, int cnt) { igFrom = from; igCnt = cnt; inGrad = new float[cnt]; }
    float[] inputGrad() { return inGrad; }
    void clearInputGrad() { java.util.Arrays.fill(inGrad, 0f); }

    static int paramCount(int[] sizes) {
        int n = 0;
        for (int l = 0; l < sizes.length - 1; l++) n += sizes[l] * sizes[l + 1] + sizes[l + 1];
        return n;
    }

    private void init(float outScale, Random rng) {
        int layers = sizes.length - 1;
        for (int l = 0; l < layers; l++) {
            int in = sizes[l], out = sizes[l + 1];
            float scale = (float) Math.sqrt(1.0 / in) * (l == layers - 1 ? outScale : 1f);
            for (int i = 0; i < in * out; i++) w[off[l] + i] = (float) (rng.nextGaussian() * scale);
            // biases stay 0
        }
    }

    /** @return the output layer's internal array (valid until the next forward call). */
    float[] forward(float[] x) {
        act[0] = x;
        int layers = sizes.length - 1;
        for (int l = 0; l < layers; l++) {
            int in = sizes[l], out = sizes[l + 1];
            float[] a = act[l], o = act[l + 1];
            int bBase = off[l] + in * out;
            boolean last = l == layers - 1;
            for (int j = 0; j < out; j++) {
                int row = off[l] + j * in;
                // four independent partial sums: the JIT cannot reorder a float reduction itself, so a single accumulator is latency bound
                float s0 = 0f, s1 = 0f, s2 = 0f, s3 = 0f;
                int i = 0;
                for (; i + 3 < in; i += 4) {
                    s0 += w[row + i] * a[i]; s1 += w[row + i + 1] * a[i + 1];
                    s2 += w[row + i + 2] * a[i + 2]; s3 += w[row + i + 3] * a[i + 3];
                }
                for (; i < in; i++) s0 += w[row + i] * a[i];
                float s = w[bBase + j] + ((s0 + s1) + (s2 + s3));
                o[j] = last ? s : fastTanh(s);
            }
        }
        return act[layers];
    }

    /** Backprop for the sample passed to the most recent forward(). Accumulates into the gradient. */
    void backward(float[] dOut) {
        int layers = sizes.length - 1;
        float[] cur = dA, nxt = dB;
        System.arraycopy(dOut, 0, cur, 0, sizes[layers]);
        for (int l = layers - 1; l >= 0; l--) {
            int in = sizes[l], out = sizes[l + 1];
            float[] a = act[l], o = act[l + 1];
            int bBase = off[l] + in * out;
            boolean last = l == layers - 1;
            boolean needPrev = l > 0;
            if (needPrev) java.util.Arrays.fill(nxt, 0, in, 0f);
            for (int j = 0; j < out; j++) {
                float dz = last ? cur[j] : cur[j] * (1f - o[j] * o[j]);
                g[bBase + j] += dz;
                int row = off[l] + j * in;
                if (l == 0 && igCnt > 0) for (int i = 0; i < igCnt; i++) inGrad[i] += w[row + igFrom + i] * dz;
                for (int i = 0; i < in; i++) g[row + i] += dz * a[i];
                if (needPrev) for (int i = 0; i < in; i++) nxt[i] += w[row + i] * dz;   // two plain loops vectorise; one loop with a branch did not
            }
            float[] t = cur; cur = nxt; nxt = t;
        }
    }

    /** Applies Adam using the accumulated gradient divided by batch. Returns the pre-clip gradient norm. */
    float step(float lr, float maxNorm, int batch) {
        float inv = 1f / batch;
        double sq = 0;
        for (int i = 0; i < g.length; i++) {
            g[i] *= inv;
            sq += (double) g[i] * g[i];
        }
        float norm = (float) Math.sqrt(sq);
        float clip = norm > maxNorm ? maxNorm / (norm + 1e-6f) : 1f;
        adamT++;
        final float b1 = 0.9f, b2 = 0.999f, eps = 1e-8f;
        float c1 = 1f - (float) Math.pow(b1, adamT);
        float c2 = 1f - (float) Math.pow(b2, adamT);
        for (int i = 0; i < w.length; i++) {
            float gi = g[i] * clip;
            m[i] = b1 * m[i] + (1f - b1) * gi;
            v[i] = b2 * v[i] + (1f - b2) * gi * gi;
            w[i] -= lr * (m[i] / c1) / ((float) Math.sqrt(v[i] / c2) + eps);
            g[i] = 0f;
        }
        return norm;
    }

    /**
     * Function-preserving widening for equal input/output sizes and equal depth. Existing weights are copied exactly;
     * new hidden units keep their random incoming weights but have zero outgoing weights, so they initially do not
     * alter the old policy and can begin learning as outgoing weights change. Optimizer moments are reset.
     */
    void widenFrom(Net old) {
        if (old.sizes.length != sizes.length || old.sizes[0] != sizes[0]
                || old.sizes[old.sizes.length - 1] != sizes[sizes.length - 1])
            throw new IllegalArgumentException("widenFrom: depth/input/output size differ");
        for (int l = 0; l < sizes.length; l++)
            if (old.sizes[l] > sizes[l]) throw new IllegalArgumentException("widenFrom: target layer is narrower at " + l);
        for (int l = 0; l < sizes.length - 1; l++) {
            int inOld = old.sizes[l], outOld = old.sizes[l + 1];
            int inNew = sizes[l], outNew = sizes[l + 1];
            int oldOffset = old.off[l], newOffset = off[l];
            for (int j = 0; j < outNew; j++) {
                for (int i = 0; i < inNew; i++) {
                    int dst = newOffset + j * inNew + i;
                    if (j < outOld && i < inOld) w[dst] = old.w[oldOffset + j * inOld + i];
                    else if (j < outOld) w[dst] = 0f; // old unit must ignore new inputs
                    else if (i >= inOld) w[dst] = 0f; // new-to-new edges stay silent
                    // new unit from old inputs keeps its random initial weight
                }
                int dstBias = newOffset + outNew * inNew + j;
                w[dstBias] = j < outOld ? old.w[oldOffset + outOld * inOld + j] : 0f;
            }
        }
        resetAdam();
    }

    /** Clears Adam moments and the gradient buffer (used after a weight rollback). */
    void resetAdam() {
        java.util.Arrays.fill(m, 0f);
        java.util.Arrays.fill(v, 0f);
        java.util.Arrays.fill(g, 0f);
        adamT = 0;
    }

    void zeroGrad() {
        java.util.Arrays.fill(g, 0f);
    }

    /** Test hook: the current accumulated gradient. */
    float[] gradView() {
        return g;
    }

    // ---- persistence helpers (used by PpoAgent) ----
    void write(java.io.DataOutputStream out) throws java.io.IOException {
        out.writeInt(adamT);
        for (float x : w) out.writeFloat(x);
        for (float x : m) out.writeFloat(x);
        for (float x : v) out.writeFloat(x);
    }

    /**
     * Reads a save made with an older input layout of {@code oldIn} inputs; {@code map[i]} is where old input i lives now
     * (-1 = gone). Every kept weight keeps its meaning; weights of new inputs start at 0, so the loaded policy behaves
     * exactly as before until training starts to use them.
     */
    void readLegacyInput(java.io.DataInputStream in, int oldIn, int[] map) throws java.io.IOException {
        readLegacyShape(in, oldIn, map, sizes[sizes.length - 1]);
    }

    /**
     * Like readLegacyInput, and the OUTPUT layer may also have had fewer neurons ({@code oldOut} <= the current size): the rows that existed
     * keep their weights, new output rows (and their Adam moments) start at 0; the caller sets any prior bias. Hidden sizes must be unchanged.
     */
    void readLegacyShape(java.io.DataInputStream in, int oldIn, int[] map, int oldOut) throws java.io.IOException {
        int[] oldSizes = sizes.clone();
        oldSizes[0] = oldIn;
        oldSizes[oldSizes.length - 1] = oldOut;
        int n = paramCount(oldSizes);
        adamT = in.readInt();
        float[] ow = new float[n], om = new float[n], ov = new float[n];
        for (int i = 0; i < n; i++) ow[i] = in.readFloat();
        for (int i = 0; i < n; i++) om[i] = in.readFloat();
        for (int i = 0; i < n; i++) ov[i] = in.readFloat();
        reshape(ow, w, oldSizes, map);
        reshape(om, m, oldSizes, map);
        reshape(ov, v, oldSizes, map);
    }

    /** Reads a checkpoint network with a different hidden width but the same number of layers. New units start at zero;
     * existing rows/columns retain their coordinates. This is a warm-start, not a guarantee of identical function when widening. */
    void readTransferred(java.io.DataInputStream in, int[] oldSizes, int[] inputMap) throws java.io.IOException {
        if (oldSizes.length != sizes.length) {
            throw new java.io.IOException("cannot transfer network across depth changes: checkpoint has "
                + (oldSizes.length - 2) + " hidden layers, selected model has " + (sizes.length - 2));
        }
        for (int i = 1; i < sizes.length - 1; i++) if (sizes[i] < oldSizes[i])
            throw new java.io.IOException("refusing to shrink hidden layer " + i + " from " + oldSizes[i] + " to " + sizes[i]);
        int n = paramCount(oldSizes);
        int oldAdamT = in.readInt();
        float[] ow = new float[n], om = new float[n], ov = new float[n];
        for (int i = 0; i < n; i++) ow[i] = in.readFloat();
        for (int i = 0; i < n; i++) om[i] = in.readFloat();
        for (int i = 0; i < n; i++) ov[i] = in.readFloat();
        reshape(ow, w, oldSizes, inputMap);
        reshape(om, m, oldSizes, inputMap);
        reshape(ov, v, oldSizes, inputMap);
        // Adam moments from a narrower model are not calibrated for new zero-initialised parameters; retain timestep but reset moments.
        if (java.util.Arrays.equals(oldSizes, sizes)) adamT = oldAdamT;
        else resetAdam();
    }

    private void reshape(float[] old, float[] dst, int[] oldSizes, int[] map) {
        java.util.Arrays.fill(dst, 0f);
        int po = 0, pn = 0;
        for (int l = 0; l < sizes.length - 1; l++) {
            int inO = oldSizes[l], outO = oldSizes[l + 1], inN = sizes[l], outN = sizes[l + 1];
            int rows = Math.min(outO, outN);
            for (int r = 0; r < rows; r++) {
                for (int i = 0; i < inO; i++) {
                    int col = l == 0 ? map[i] : i;
                    if (col >= 0 && col < inN) dst[pn + r * inN + col] = old[po + r * inO + i];
                }
            }
            int bo = po + inO * outO, bn = pn + inN * outN;
            for (int r = 0; r < rows; r++) dst[bn + r] = old[bo + r];
            po = bo + outO;
            pn = bn + outN;
        }
    }

    private void widenInput(float[] old, float[] dst, int oldIn, int[] map) {
        java.util.Arrays.fill(dst, 0f);
        int newIn = sizes[0], out0 = sizes[1];
        for (int r = 0; r < out0; r++) {
            for (int i = 0; i < oldIn; i++) {
                if (map[i] >= 0) dst[r * newIn + map[i]] = old[r * oldIn + i];
            }
        }
        int oldRest = oldIn * out0, newRest = newIn * out0;   // first-layer biases and every later layer are unchanged
        System.arraycopy(old, oldRest, dst, newRest, old.length - oldRest);
    }

    void read(java.io.DataInputStream in) throws java.io.IOException {
        adamT = in.readInt();
        for (int i = 0; i < w.length; i++) w[i] = in.readFloat();
        for (int i = 0; i < m.length; i++) m[i] = in.readFloat();
        for (int i = 0; i < v.length; i++) v[i] = in.readFloat();
    }

    /**
     * tanh through the intrinsified Math.exp. Math.tanh in JDK 21 goes through StrictMath.expm1 (a pure-Java fdlibm port) and was about 70 % of
     * all CPU time in a profiled training run. Same function to within about 1e-15 in double; the result is rounded to float like before, so
     * checkpoints, widening and the backward pass (which uses the stored activation) are unaffected.
     */
    static float fastTanh(float x) {
        if (x > 9f) return 1f;
        if (x < -9f) return -1f;
        if (Math.abs(x) < 1e-4f) return x - x * x * x * (1f / 3f);
        double e = Math.exp(2.0 * x);
        return (float) (1.0 - 2.0 / (e + 1.0));
    }
}