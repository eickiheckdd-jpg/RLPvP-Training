package com.rlpvp;

/**
 * Optional, compact situational memory appended to the observation (enabled by -Drlpvp.obsV2=true).
 * These are descriptive state features, not scripted actions or technique bonuses.
 */
final class MotionMemory {
    /** Number of appended motion-memory features; kept explicit for observation-layout integrations. */
    static final int FEATURE_COUNT = Config.V2_FEATURES;

    private double prevAim = Double.NaN, prevDist = Double.NaN;
    private double keyChangeEma, opponentFlipEma;
    private double prevOppLateral;
    private int strafeDir, strafeRun, ticksSinceChange, prevFwd;
    private boolean prevSprint;
    private float[] features = new float[Config.V2_FEATURES];
    private double prevErrYaw = Double.NaN, prevErrPitch = Double.NaN;

    void reset() {
        prevAim = prevDist = Double.NaN; prevErrYaw = prevErrPitch = Double.NaN; keyChangeEma = opponentFlipEma = 0;
        prevOppLateral = 0; strafeDir = 0; strafeRun = 0; ticksSinceChange = 20; prevFwd = 0; prevSprint = false;
        java.util.Arrays.fill(features, 0f);
    }

    /** Call once per tick after frame construction; lastAct uses the project's encoded {-1,0,1} movement values. */
    void tick(float[] frame, float[] lastAct, double distance) { tick(frame, lastAct, distance, 0.0, 0.0); }

    /** Wraps an angle difference to [-180, 180). */
    static double wrap180(double d) { d %= 360.0; if (d >= 180.0) d -= 360.0; if (d < -180.0) d += 360.0; return d; }

    /**
     * @param turnYawDeg,turnPitchDeg the camera turn (degrees, agent space, same sign as the aim error: turning +x reduces the error by x) that was
     *        applied since the previous observation. The aim error changes by (target motion - own turn), so the TARGET's angular velocity is
     *        d(error) + turn: the agent can see how fast the target moves across its crosshair (it needs this to lead its aim at moving opponents).
     */
    void tick(float[] frame, float[] lastAct, double distance, double turnYawDeg, double turnPitchDeg) {
        if (!Config.OBS_V2) return;
        double aim = Math.min(1.0, Math.hypot(frame[13], frame[14]));
        double aimTrend = Double.isNaN(prevAim) ? 0 : Math.max(-1, Math.min(1, (prevAim - aim) * 4));
        double closing = Double.isNaN(prevDist) ? 0 : Math.max(-1, Math.min(1, (prevDist - distance) * 2));
        int str = lastAct.length > 3 ? Math.round(lastAct[3]) : 0;
        int fwd = lastAct.length > 2 ? Math.round(lastAct[2]) : 0;
        boolean sprint = lastAct.length > 6 && lastAct[6] > 0.5f;
        boolean changed = str != strafeDir || fwd != prevFwd || sprint != prevSprint;
        keyChangeEma += 0.08 * ((changed ? 1 : 0) - keyChangeEma);
        if (changed) ticksSinceChange = 0; else ticksSinceChange = Math.min(20, ticksSinceChange + 1);
        if (str != 0 && str == strafeDir) strafeRun = Math.min(20, strafeRun + 1);
        else { strafeDir = str; strafeRun = str == 0 ? 0 : 1; }
        double oppLat = frame[17];
        boolean flip = Math.abs(oppLat) > 0.08 && Math.abs(prevOppLateral) > 0.08 && Math.signum(oppLat) != Math.signum(prevOppLateral);
        opponentFlipEma += 0.08 * ((flip ? 1 : 0) - opponentFlipEma);
        features[0] = (float) aimTrend;
        features[1] = (float) (Math.signum(strafeDir) * Math.min(1, strafeRun / 10.0));
        features[2] = (float) Math.max(0, Math.min(1, keyChangeEma));
        double moveSpeed = Math.hypot(frame[1], frame[2]);
        features[3] = (float) Math.max(-1, Math.min(1, closing / Math.max(0.2, moveSpeed)));
        features[4] = (float) Math.max(0, Math.min(1, opponentFlipEma * 5));
        features[5] = (float) Math.max(-1, Math.min(1, oppLat));
        features[6] = (float) closing;
        features[7] = (float) (ticksSinceChange / 20.0);
        double errYaw = frame[13] * 180.0, errPitch = frame[14] * 90.0;
        double tvYaw = Double.isNaN(prevErrYaw) ? 0.0 : wrap180(errYaw - prevErrYaw) + turnYawDeg;
        double tvPitch = Double.isNaN(prevErrPitch) ? 0.0 : (errPitch - prevErrPitch) + turnPitchDeg;
        features[8] = (float) Math.max(-1.0, Math.min(1.0, tvYaw / 10.0));    // +-10 deg/tick = +-1
        features[9] = (float) Math.max(-1.0, Math.min(1.0, tvPitch / 5.0));   // +-5 deg/tick = +-1
        prevErrYaw = errYaw; prevErrPitch = errPitch;
        prevAim = aim; prevDist = distance; prevOppLateral = oppLat; prevFwd = fwd; prevSprint = sprint;
    }

    void fill(float[] summary) {
        if (!Config.OBS_V2 || summary.length < Config.SUMMARY_BASE + features.length) return;
        System.arraycopy(features, 0, summary, Config.SUMMARY_BASE, features.length);
    }
}
