package com.rlpvp;

import java.util.Locale;
import java.util.Random;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Opponent logic for the curriculum. Runs on the integrated SERVER thread (once per server tick)
 * and drives the Carpet fake player through CarpetController. Settings are written by the client
 * thread (volatile fields); nothing here touches the learning agent's own camera or actions.
 *
 * Modes: stationary, strafe left/right, walk in 4 directions + light attacks, aggressive, STRONG
 * (spacing, strafe flips, w-tap, jump-crits, jump-reset) and self-play (a frozen copy of the learning
 * policy, fed an observation built from the BOT's view).
 *
 * Scripted bots no longer snap their camera onto the agent: they turn at a limited speed, with a
 * little noise and a 2-tick reaction delay, so the agent can win exchanges by moving unpredictably
 * (the old bots had a perfect instant aimbot, which no human has).
 * Missing bot or failed control never crashes: it logs once and carries on.
 */
final class BotBrain {
    volatile boolean active;
    volatile String botName;
    volatile String agentName;
    volatile Curriculum.Opponent mode = Curriculum.Opponent.STATIONARY;
    volatile FrozenPolicy policy;

    private final CarpetController ctl = new CarpetController();
    private final Random rng = new Random();
    private final BotAI ai = new BotAI(rng);
    volatile int stage = 1;            // set by Trainer: the stationary bot hops in stages BOT_HOP_MIN_STAGE..MAX_STAGE (pitch practice)
    volatile double hopLevel = 0.0; // 0..1, from Curriculum.hopLevel() (Trainer)
    private int hopCd = 10;
    volatile double difficulty = 0.3; // set by Trainer (BotDifficulty), 0..1
    private boolean wasActive;
    private boolean warned;

    // scripted behaviour state
    private int ticksLeft;
    private int fwd;
    private int strafe;
    private int attackCd;
    private int wtapLeft;
    private boolean critArm;
    private int critTicks;
    private double aimErrYaw; // degrees, after this tick's turn
    private final Vec3[] aimHist = new Vec3[3]; // reaction delay: the bot sees where the agent was 2 ticks ago
    private int aimHistN;

    // self-play state
    private final ObsStack spObs = new ObsStack();
    private final float[] spLastAct = new float[7];
    private final GameplayRotation spRot = new GameplayRotation();
    private Vec3 spPrevBot;
    private Vec3 spPrevAgent;
    private float spPrevBotHp;
    private float spPrevAgentHp;
    private int spSinceDealt = 40;
    private int spSinceTaken = 40;
    private int spSinceOppSwing = 40;
    private boolean spOppSwinging;
    private int spSinceMySwing = 40;
    private final HitMemory spMem = new HitMemory();
    private final float[] spSummary = new float[Config.SUMMARY];
    private int spAgentHitMask;
    private boolean spFresh = true;

    private static ServerPlayer find(MinecraftServer server, String name) {
        return name == null ? null : server.getPlayerList().getPlayerByName(name);
    }

    /** True if the bot's body overlaps solid blocks (block collisions only, so standing next to the agent is fine). */
    private static boolean insideBlocks(Level level, ServerPlayer bot) {
        return level.getBlockCollisions(bot, bot.getBoundingBox().deflate(0.02)).iterator().hasNext();
    }

    // last known bot pose, so a bot that died (and was removed) can be respawned where it stood
    private double lastX, lastY, lastZ;
    private float lastYaw, lastPitch;
    private boolean haveLast;
    private int respawnCd, respawnTries;
    private int stuckCheck;
    private boolean warnedStuck;

    /** Stage 2-3 stationary bot: hops at the curriculum's hop level (never teleported), so its height changes and the agent has to learn PITCH tracking. */
    private boolean stationaryHop(ServerPlayer bot) {
        double level = hopLevel; // set by Trainer from Curriculum.hopLevel(): starts at 0 and rises as the agent masters pitch tracking
        if (!Config.BOT_HOP || stage < Config.BOT_HOP_MIN_STAGE || stage > Config.BOT_HOP_MAX_STAGE || level <= 0.0) return false;
        if (--hopCd > 0) return false;
        hopCd = (int) Math.round((Config.BOT_HOP_MIN_TICKS + rng.nextInt(Config.BOT_HOP_MAX_TICKS - Config.BOT_HOP_MIN_TICKS + 1)) / level);
        return bot.onGround();
    }

    /** Server thread: new episode. The bot is NEVER teleported, only healed and its scripted state reset. */
    void refresh(MinecraftServer server, String botNm, String agentNm) {
        ServerPlayer agentP = find(server, agentNm);
        if (Config.HEAL_AGENT && agentP != null) {
            agentP.setHealth(agentP.getMaxHealth());
            agentP.getFoodData().setFoodLevel(20);
        }
        ServerPlayer bot = find(server, botNm);
        if (bot == null) return;
        bot.setHealth(bot.getMaxHealth());
        bot.invulnerableTime = 0;
        spFresh = true;
        hopCd = 6 + rng.nextInt(10);
        ticksLeft = 0;
        attackCd = 20;
        wtapLeft = 0;
        critArm = false;
        critTicks = 0;
        spRot.reset();
        aimHistN = 0;
        ai.reset();
    }

    void serverTick(MinecraftServer server) {
        if (!active) {
            if (wasActive) {
                wasActive = false;
                ServerPlayer b = find(server, botName);
                if (b != null) ctl.stop(server, b);
            }
            return;
        }
        wasActive = true;
        ServerPlayer bot = find(server, botName);
        ServerPlayer agent = find(server, agentName);
        if (bot == null && agent != null && Config.RESPAWN_BOT && haveLast && respawnTries < 5 && botName != null) {
            if (--respawnCd <= 0) { // Carpet removes a bot that died: bring it back where it stood (not a teleport)
                respawnCd = 60;
                respawnTries++;
                CarpetController.run(server, String.format(Locale.ROOT, "player %s spawn at %.3f %.3f %.3f facing %.1f %.1f",
                    botName, lastX, lastY, lastZ, lastYaw, lastPitch));
            }
            return;
        }
        if (bot == null || agent == null) {
            if (!warned) {
                warned = true;
                Trainer.LOG.warn("rlpvp: bot '{}' or agent '{}' not found on the integrated server; opponent control is off",
                    botName, agentName);
            }
            return;
        }
        warned = false;
        respawnTries = 0;
        if (bot.getHealth() > 0f) {
            lastX = bot.getX(); lastY = bot.getY(); lastZ = bot.getZ();
            lastYaw = bot.getYRot(); lastPitch = bot.getXRot();
            haveLast = true;
        }

        // The bot is never teleported. If it ever gets wedged in blocks we only warn (once) so you can fix the arena.
        if (++stuckCheck >= 10) {
            stuckCheck = 0;
            if (insideBlocks(bot.level(), bot)) {
                if (!warnedStuck) {
                    warnedStuck = true;
                    Trainer.LOG.warn("rlpvp: bot is inside blocks; it is not teleported, check the arena");
                }
            } else {
                warnedStuck = false;
            }
        }

        Curriculum.Opponent m = mode;
        switch (m) {
            case STATIONARY -> ctl.apply(server, bot, 0, 0, false, stationaryHop(bot), false);
            case SELF_PLAY -> {
                FrozenPolicy p = policy;
                if (p == null) smart(server, bot, agent, Curriculum.Opponent.STRONG);
                else selfPlay(server, bot, agent, p);
            }
            case AGGRESSIVE, STRONG, ELITE -> smart(server, bot, agent, m);
            default -> scripted(server, bot, agent, m);
        }
    }

    // ------------------------------------------------------------------ BotAI opponents (AGGRESSIVE / STRONG)
    private void smart(MinecraftServer server, ServerPlayer bot, ServerPlayer agent, Curriculum.Opponent m) {
        if (!ai.ready()) ai.newEpisode(m == Curriculum.Opponent.STRONG || m == Curriculum.Opponent.ELITE, m == Curriculum.Opponent.ELITE, m == Curriculum.Opponent.AGGRESSIVE ? 0.7 * difficulty : difficulty);
        BotAI.In s = ai.in;
        s.bx = bot.getX(); s.by = bot.getY(); s.bz = bot.getZ();
        s.byaw = bot.getYRot(); s.bpitch = bot.getXRot(); s.eyeY = bot.getEyeY(); s.bvy = bot.getDeltaMovement().y;
        s.bGround = bot.onGround(); s.hurtTime = bot.hurtTime; s.bScale = bot.getAttackStrengthScale(0.5f); s.bHp = bot.getHealth();
        s.tx = agent.getX(); s.ty = agent.getY(); s.tz = agent.getZ();
        s.tScale = agent.getAttackStrengthScale(0.5f); s.tHp = agent.getHealth();
        BotAI.Out o = ai.think(s);
        CarpetController.look(bot, o.yaw, o.pitch);
        ctl.apply(server, bot, o.fwd, o.str, o.sprint, o.jump, o.attack);
    }

    // ------------------------------------------------------------------ scripted opponents (STRAFE / WALK)
    private void scripted(MinecraftServer server, ServerPlayer bot, ServerPlayer agent, Curriculum.Opponent m) {
        float turn = switch (m) {
            case STRONG -> Config.BOT_TURN_STRONG;
            case AGGRESSIVE -> Config.BOT_TURN_AGGRESSIVE;
            default -> Config.BOT_TURN_WALK;
        };
        float noise = m == Curriculum.Opponent.STRONG ? 1.5f : m == Curriculum.Opponent.AGGRESSIVE ? 2.5f : 1.0f;
        aimAt(bot, agent, turn, noise);
        double dist = bot.position().distanceTo(agent.position());
        boolean ready = bot.getAttackStrengthScale(0.5f) >= Config.MIN_ATTACK_STRENGTH;
        boolean aimed = aimErrYaw < 12.0;

        int f = fwd;
        boolean sprint = false;
        boolean jump = false;
        boolean attack = false;

        if (m == Curriculum.Opponent.STRONG) {
            if (--ticksLeft <= 0) { // strafe almost always, flipping direction at random intervals
                strafe = rng.nextFloat() < 0.1f ? 0 : (rng.nextBoolean() ? -1 : 1);
                ticksLeft = 5 + rng.nextInt(9);
            }
            boolean cooling = bot.getAttackStrengthScale(0.5f) < 0.6f;
            if (dist > 3.2) f = 1;
            else if (dist < 1.9) f = -1;
            else f = cooling ? (rng.nextFloat() < 0.35f ? -1 : 0) : (rng.nextFloat() < 0.5f ? 1 : 0);

            // jump-reset: jump the moment we are hit so the knockback is carried instead of eaten
            if (bot.hurtTime >= 9 && bot.onGround()) jump = true;

            // jump-crit: leave the ground, then swing on the way down while NOT sprinting
            if (!critArm && bot.onGround() && ready && dist > 2.3 && dist < 3.8 && rng.nextFloat() < 0.04f) {
                jump = true;
                critArm = true;
                critTicks = 16;
            }
            if (critArm) {
                if (--critTicks <= 0) critArm = false;
                boolean falling = !bot.onGround() && bot.getDeltaMovement().y < 0;
                if (falling && dist <= Config.ATTACK_REACH && ready && aimed) {
                    attack = true;
                    critArm = false;
                }
                sprint = false;
            } else if (wtapLeft > 0) { // w-tap: let go of forward for a moment so sprint (and its knockback) resets
                wtapLeft--;
                f = 0;
            } else {
                sprint = f > 0 && dist > 2.2;
                if (dist <= Config.ATTACK_REACH && ready && aimed && rng.nextFloat() < 0.85f) {
                    attack = true;
                    wtapLeft = 2;
                }
            }
        } else {
            if (--ticksLeft <= 0) {
                if (m == Curriculum.Opponent.STRAFE) {
                    strafe = rng.nextBoolean() ? -1 : 1;
                    fwd = 0;
                    ticksLeft = 8 + rng.nextInt(18);
                } else if (m == Curriculum.Opponent.WALK) {
                    fwd = rng.nextInt(3) - 1;
                    strafe = rng.nextInt(3) - 1;
                    ticksLeft = 10 + rng.nextInt(16);
                } else {
                    strafe = rng.nextInt(3) - 1;
                    ticksLeft = 6 + rng.nextInt(12);
                }
            }
            f = fwd;
            if (m == Curriculum.Opponent.AGGRESSIVE) {
                f = dist > 2.4 ? 1 : (rng.nextFloat() < 0.15f ? -1 : 0);
                sprint = dist > 3.5;
                jump = rng.nextFloat() < 0.01f;
                attack = dist <= 3.1 && ready && aimed && rng.nextFloat() < 0.6f;
            } else if (m == Curriculum.Opponent.STRAFE) {
                f = dist > 4.0 ? 1 : (dist < 2.0 ? -1 : 0); // stay roughly in front of the agent
            } else { // WALK: random 4-direction walk with a leash, light attacks
                if (dist > 4.5) f = 1;
                else if (dist < 1.8) f = -1;
                if (--attackCd <= 0 && dist <= 3.1 && ready && aimed) {
                    attack = true;
                    attackCd = 40 + rng.nextInt(30);
                }
            }
        }
        ctl.apply(server, bot, f, strafe, sprint, jump, attack);
    }

    /** Turns the bot toward where the agent was 2 ticks ago, at most {@code maxTurn} degrees this tick, plus noise. */
    private void aimAt(ServerPlayer bot, ServerPlayer agent, float maxTurn, float noise) {
        Vec3 now = agent.position();
        if (aimHistN == 0) {
            for (int i = 0; i < aimHist.length; i++) aimHist[i] = now;
            aimHistN = aimHist.length;
        } else {
            System.arraycopy(aimHist, 1, aimHist, 0, aimHist.length - 1);
            aimHist[aimHist.length - 1] = now;
        }
        Vec3 seen = aimHist[0];
        double dx = seen.x - bot.getX();
        double dz = seen.z - bot.getZ();
        double dy = seen.y + agent.getBbHeight() * 0.5 - bot.getEyeY();
        float wantYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.max(1e-6, Math.sqrt(dx * dx + dz * dz))));
        float dYaw = Mth.clamp(Mth.wrapDegrees(wantYaw - bot.getYRot()), -maxTurn, maxTurn) + (float) rng.nextGaussian() * noise;
        float dPitch = Mth.clamp(wantPitch - bot.getXRot(), -maxTurn * 0.5f, maxTurn * 0.5f) + (float) rng.nextGaussian() * noise * 0.5f;
        float yaw = Mth.wrapDegrees(bot.getYRot() + dYaw);
        float pitch = Mth.clamp(bot.getXRot() + dPitch, -90f, 90f);
        CarpetController.look(bot, yaw, pitch);
        aimErrYaw = Math.abs(Mth.wrapDegrees(wantYaw - yaw));
    }

    // ------------------------------------------------------------------ self-play / league snapshots
    private void selfPlay(MinecraftServer server, ServerPlayer bot, ServerPlayer agent, FrozenPolicy pol) {
        Vec3 bp = bot.position();
        Vec3 ap = agent.position();
        if (spFresh) {
            spPrevBot = bp;
            spPrevAgent = ap;
            spPrevBotHp = bot.getHealth();
            spPrevAgentHp = agent.getHealth();
            spSinceDealt = 40;
            spSinceTaken = 40;
            spSinceOppSwing = 40;
            spOppSwinging = false;
            spSinceMySwing = 40;
            spMem.reset();
            spAgentHitMask = 0;
            java.util.Arrays.fill(spLastAct, 0f);
            spObs.reset();
            spFresh = false;
        }
        Vec3 botVel = bp.subtract(spPrevBot);
        Vec3 agentVel = ap.subtract(spPrevAgent);
        float dealt = Math.max(0f, spPrevAgentHp - agent.getHealth()); // damage the bot did
        float taken = Math.max(0f, spPrevBotHp - bot.getHealth());
        spPrevBot = bp;
        spPrevAgent = ap;
        spPrevBotHp = bot.getHealth();
        spPrevAgentHp = agent.getHealth();
        spSinceDealt = dealt > 0 ? 0 : Math.min(spSinceDealt + 1, 40);
        spSinceTaken = taken > 0 ? 0 : Math.min(spSinceTaken + 1, 40);
        boolean sw = agent.swinging;
        boolean swStart = sw && !spOppSwinging;
        spSinceOppSwing = swStart ? 0 : Math.min(spSinceOppSwing + 1, 40);
        spOppSwinging = sw;
        spMem.tick(dealt, taken, swStart, spAgentHitMask);
        spMem.fill(spSummary);
        spAgentHitMask = HitMemory.typeMask(true, !agent.onGround() && agentVel.y < 0 && !agent.isSprinting(), agent.isSprinting(), agent.onGround());

        // The observation is built from the BOT's point of view, with the learning agent as its enemy.
        float[] frame = Observation.frame(bot, agent, botVel, agentVel, spSinceDealt, spSinceTaken, spLastAct, spSinceOppSwing, spSinceMySwing, 0);
        float[] a = pol.act(spObs.push(frame, spSummary), 0); // no locks in stage 8
        spRot.step(a[0], a[1], bot.getYRot(), bot.getXRot(), 0.0, 0.0, false, false, false); // same mouse dynamics as the agent; frozen opponents never use the aim brake
        Observation.encodeAction(a, spRot.yaw.vel() / Config.YAW_SCALE, spRot.pitch.vel() / Config.PITCH_SCALE, spLastAct);
        float yaw = spRot.newYaw, pitch = spRot.newPitch;
        CarpetController.look(bot, yaw, pitch);
        boolean attack = a[4] > 0.5f && bot.getAttackStrengthScale(0.5f) >= Config.MIN_ATTACK_STRENGTH;
        spSinceMySwing = attack ? 0 : Math.min(spSinceMySwing + 1, 40);
        if (attack) {
            boolean botFull = bot.getAttackStrengthScale(0.5f) >= Config.FULL_CHARGE;
            boolean botSprint = bot.isSprinting();
            spMem.swing(HitMemory.typeMask(botFull, !bot.onGround() && botVel.y < 0 && !botSprint, botSprint, bot.onGround()), true);
        }
        ctl.apply(server, bot, Math.round(a[2]) - 1, Math.round(a[3]) - 1, a[6] > 0.5f, a[5] > 0.5f, attack);
    }
}