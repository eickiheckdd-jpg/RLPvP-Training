package com.rlpvp;

/** Every tunable number lives here. */
final class Config {
    private Config() {}

    // ---------------- observation ----------------
    /** Floats per tick (see Observation.frame for the exact layout). */
    /**
     * 48 original features + 3 appended for SNEAK (appended, so no existing index moved): 48 = I am sneaking, 49 = the enemy is sneaking,
     * 50 = my sneak head is locked by the curriculum. FRAME_PRE_SNEAK is the layout of older saves (migrated on load, see PpoAgent.load).
     */
    static final int FRAME = 51;
    static final int FRAME_PRE_SNEAK = 48;
    /** Frame sizes of older saves (all used the lags LEGACY_LAGS and no summary): they are migrated on load, see PpoAgent.load. */
    static final int[] LEGACY_FRAMES = {42, 48};
    static final int[] LEGACY_LAGS = {0, 1, 4, 16};
    /**
     * Which past ticks are fed to the network: 0 = now, 1 = last tick (shows knockback / hit onset), ... up to 96 ticks
     * (4.8 s) back. Lags up to NEAR_LAG_MAX carry the whole frame, older ones only FAR_FEATURES (keeps the network small).
     */
    static final int[] LAGS = {0, 1, 2, 4, 8, 16, 32, 48, 64, 80, 96};
    /** Must equal the largest value in LAGS. */
    static final int MAX_LAG = 96;
    static final int NEAR_LAG_MAX = 16;
    /** Frame features kept for the far lags: own health / velocity / sprint / hurt, enemy position, distance, aim, enemy health / hurt / swing, hit timers. */
    static final int[] FAR_FEATURES = {0, 1, 2, 5, 7, 9, 10, 12, 13, 15, 20, 23, 24, 25};
    /** Ticks the HitMemory summary looks back (96 = 4.8 s). */
    static final int MEMORY_WINDOW = 96;
    /** Floats from HitMemory, appended once to the network input. */
    static final int SUMMARY_BASE = 20;
    /** Opt in with -Drlpvp.obsV2=true to append 10 situational motion-memory features. This changes the input layout and warm-starts old checkpoints. */
    static final boolean OBS_V2 = Boolean.parseBoolean(System.getProperty("rlpvp.obsV2", "false"));
    /** Optional OBS_V2 inputs: 8 movement-memory features + 2 target angular velocities (yaw, pitch; see MotionMemory). */
    static final int V2_FEATURES = 10;
    /** Sprint-hit follow-up memory is descriptive only; enabled by default for new training. Set false to run the legacy input layout. */
    static final boolean SPRINT_FOLLOWUP = Boolean.parseBoolean(System.getProperty("rlpvp.sprintFollowup", "true"));
    static final int SPRINT_FOLLOWUP_FEATURES = SprintHitFollowupMemory.FEATURES;
    /** v7.19 memory block (OpponentMemory): 8 opponent-habit statistics + 8 fixed multi-timescale recurrent traces. Appended after the follow-up block; old checkpoints warm-start with zero weights on the new inputs. -Drlpvp.memory=false = previous layout. */
    static final boolean MEMORY = Boolean.parseBoolean(System.getProperty("rlpvp.memory", "true"));
    static final int MEMORY_FEATURES = OpponentMemory.FEATURES;
    /** Train the memory GRU (GruCell) with truncated backprop through time inside PPO. false = keep the default (seeded, multi-timescale) cell untrained. */
    static final boolean GRU_TRAIN = Boolean.parseBoolean(System.getProperty("rlpvp.gruTrain", "true"));
    /** Ticks of history replayed (and back-propagated through) per PPO sample. */
    static final int GRU_BPTT = 16;
    static final float LR_GRU = 5e-4f, GRU_MAX_NORM = 0.5f;
    static final int SUMMARY = SUMMARY_BASE + (OBS_V2 ? V2_FEATURES : 0) + (SPRINT_FOLLOWUP ? SPRINT_FOLLOWUP_FEATURES : 0) + (MEMORY ? MEMORY_FEATURES : 0);
    /** Total network inputs: full recent frames + compact far-lag features + summary. */
    static final int OBS_SIZE = ObsLayout.size(LAGS, FRAME, FAR_FEATURES.length, SUMMARY);

    // ---------------- network ----------------
    /** Select a preset with -Drlpvp.model=base|wide|deep|m10|m15, or provide custom layers with -Drlpvp.hidden=512,512[,256]. */
    static final String MODEL = System.getProperty("rlpvp.model", "base").trim().toLowerCase(java.util.Locale.ROOT);
    static final int[] HIDDEN = parseHidden(System.getProperty("rlpvp.hidden"), MODEL);
    /** Optional source shape for a custom-width checkpoint transfer: -Drlpvp.transferFrom=128,128. */
    static final int[] TRANSFER_FROM = parseLayerList(System.getProperty("rlpvp.transferFrom"), null);
    private static int[] parseHidden(String custom, String model) {
        if (custom != null && !custom.isBlank()) return parseLayerList(custom, null);
        return switch (model) {
            case "base" -> new int[]{128, 128};
            case "wide" -> new int[]{256, 256};          // 128,128 checkpoints widen function-preservingly
            case "deep" -> new int[]{256, 256, 128};     // different depth: starts fresh (depth changes cannot be transferred)
            case "m10" -> new int[]{960, 960};
            case "m15" -> new int[]{1024, 1024, 512};
            default -> throw new IllegalArgumentException("Unknown -Drlpvp.model=" + model + " (expected base, wide, deep, m10, m15) or set -Drlpvp.hidden=512,512");
        };
    }
    static int[] parseLayerList(String value, int[] fallback) {
        if (value == null || value.isBlank()) return fallback;
        String[] pieces = value.trim().split("\\s*,\\s*");
        if (pieces.length < 1 || pieces.length > 8) throw new IllegalArgumentException("hidden layer list must have 1..8 layers");
        int[] layers = new int[pieces.length];
        for (int i = 0; i < pieces.length; i++) {
            layers[i] = Integer.parseInt(pieces[i]);
            if (layers[i] < 8 || layers[i] > 4096) throw new IllegalArgumentException("hidden layer size out of range 8..4096: " + layers[i]);
        }
        return layers;
    }

    // ---------------- actions ----------------
    /**
     * Camera = continuous relative mouse control (no buckets). The actor outputs a Gaussian (mean, log-std) per axis in
     * NORMALISED hand-effort units; samples are clamped to [-1, 1] and then passed through CameraMap and CameraDynamics.
     * The physical controller converts effort into acceleration, mouse velocity and relative displacement.
     */
    /**
     * Optional low-pass filter on mouse-hand effort (1.0 = off). Physical movement is already generated by CameraDynamics; this extra
     * filter only adds delay, so leave it off unless a controlled evaluation shows a benefit. Smaller values make the input command laggier.
     * The policy must be trained with the same filter setting used during play; the simulator uses this value too.
     */
    static final float LOOK_SMOOTH = 1.0f;
    static final int LOOK_SMOOTH_POLES = 2;
    /**
     * Response curve for the camera head's mouse-hand effort (see CameraMap): applied = sign(a) * (mix*|a| + (1-mix)*|a|^p). 3 = cubic, so
     * the policy can apply tiny hand force for micro-adjustments and strong force for faster mouse movement.
     * 1 = linear hand effort. Changing this curve changes the learned controller, so retrain when changing it.
     * The std limits below are given in APPLIED effort units and converted to raw units (CameraMap.stdForMeanAbs / stdForTail). These describe
     * the policy's hand-effort exploration, not camera displacement; actual movement is determined by the physical mouse controller.
     */
    static final float CAMERA_EXPONENT = 3f;
    /** Share of the linear term kept in the curve (0 = pure power). Raise to 0.15-0.3 if the aim does not form in stages 1-2. */
    static final float CAMERA_LINEAR_MIX = 0f;
    /**
     * Physical mouse dynamics (see CameraDynamics). The camera head represents hand effort applied to a mouse, not an instant rotation:
     * effort creates acceleration, mouse/hand drag opposes existing movement, and acceleration changes are jerk-limited. The two camera
     * observation inputs continue to carry actual mouse velocity after integration. `false` is a diagnostic bypass, not a training mode.
     * This changes action semantics from the v9 spring/damper version, so train a fresh checkpoint with these settings.
     */
    static final boolean CAMERA_DYNAMICS = true;
    /** Maximum acceleration as a fraction of the maximum camera-equivalent mouse speed per tick^2 (yaw: 13.5 deg/tick^2). Was 0.7 (31.5): the camera could go from rest to 31 deg/tick in ONE tick, and since the game shows the camera at 20 Hz that is a visible jolt. */
    static final float CAM_ACC_MAX_FRAC = 0.30f;
    /** Maximum change of acceleration per tick, as a fraction of the axis speed scale (yaw: 5.4 deg/tick^3). Was 1.0 (45): acceleration could switch on at full strength in a single tick. */
    static final float CAM_JERK_MAX_FRAC = 0.12f;
    /** Velocity drag per tick when the hand is not pushing; matching the acceleration fraction makes full input balance at top speed. */
    static final float CAM_MOUSE_DRAG = 0.30f; // = CAM_ACC_MAX_FRAC, so a full push still balances at the full axis speed; a lower drag lets a flick coast and stop gently

    // ---------------- pitch practice (stages 2-3): the stationary bot hops, ADAPTIVELY ----------------
    /**
     * The stationary bot hops now and then (it is never teleported). A bot that stands on the same spot gives a constant pitch error, so there is
     * nothing to learn on the pitch axis once the first correction is done; a hop moves the target up and down by about 1.25 blocks (roughly +-13 degrees
     * at 2.6 blocks), so the agent has to TRACK it with pitch. Applies to the stationary bot only, in the stages below.
     *
     * The hop frequency is a performance-driven LEVEL (Curriculum.hopLevel, 0..1), not a constant. A fixed hop every 12-30 ticks (airborne about half
     * of the time) made the stage-2 aim gate unreachable for a fresh policy: the gate read 0 % for 1,000,000 ticks (the same run with no hops
     * read 73 % within 84 episodes), and with the stage timers gone the run never left stage 2. Now the level starts at 0 (no hops), rises by
     * BOT_HOP_STEP after each BOT_HOP_WINDOW episodes whose success rate is >= BOT_HOP_RAISE_AT, falls when it is < BOT_HOP_LOWER_AT, and stage 2
     * is only left once the gate is held at level >= BOT_HOP_REQUIRED_LEVEL (so pitch tracking really is learned before attacks unlock).
     * At level 1 a grounded bot waits BOT_HOP_MIN_TICKS..MAX_TICKS between hops (about 25 % of the time airborne); lower levels wait proportionally longer.
     */
    static final boolean BOT_HOP = true;
    static final int BOT_HOP_MIN_STAGE = 2;
    static final int BOT_HOP_MAX_STAGE = 3;
    static final int BOT_HOP_MIN_TICKS = 30;
    static final int BOT_HOP_MAX_TICKS = 60;
    static final double BOT_HOP_STEP = 0.1;
    static final int BOT_HOP_WINDOW = 10;
    static final double BOT_HOP_RAISE_AT = 0.75;
    static final double BOT_HOP_LOWER_AT = 0.50;
    static final double BOT_HOP_REQUIRED_LEVEL = 0.7;
    /**
     * AimBrake (see AimBrake): braking envelope near the target so the camera cannot overshoot and hunt. Part of the mouse physics:
     * train and play with the same value. Decel fraction = share of the mouse's max acceleration assumed available for braking (kept
     * below 1 because acceleration is jerk-limited); track fraction = speed always allowed so a strafing enemy can be followed.
     */
    static final boolean AIM_BRAKE = true;
    /** Display-only: draw the AI's camera between ticks on a smooth curve (GlideCamera) instead of vanilla's straight lines. Off = vanilla interpolation. */
    static final boolean GLIDE_CAMERA = true;
    /**
     * The player's REAL yaw / pitch (not only the drawn view) follow the Hermite curve every frame, like a real mouse turning the head continuously
     * between the 20 Hz ticks. The tick still starts and ends on the same angles (what the policy, attacks and packets use). Replaces the display-only
     * offset (they are never applied together). Needs the Minecraft.runTick mixin; if it does not apply, rotation is exactly the old per-tick one.
     */
    static final boolean GLIDE_REAL_ROTATION = true;
    static final float AIM_BRAKE_DECEL_FRAC = 0.35f;
    static final float AIM_BRAKE_TRACK_FRAC = 0.02f;
    static final float AIM_BRAKE_GAIN = 0.8f;
    /** Max push toward the target per degree of remaining error (hand-effort deg/tick per degree); a target moving 2 deg/tick needs ~1 deg of error. */
    static final float AIM_BRAKE_PUSH_GAIN = 2.0f;
    /** Ticks of own motion assumed before the brake takes effect (one policy tick + jerk-limited ramp). */
    static final float AIM_BRAKE_LOOKAHEAD = 0.5f;
    /** Overshoot (deg) the predictive brake tolerates so that fine corrections do not stall. */
    static final float AIM_BRAKE_SLACK_DEG = 0.5f;
    /** Ticks of the target's own estimated motion (away from the camera) added to the brake's room; 0 = target assumed still. */
    static final float AIM_BRAKE_TRACK_TICKS = 3f;
    /** Brake model used to predict the stopping travel: hand effort = -gain * velocity (deg/tick per deg/tick). */
    static final float CAM_STOP_GAIN = 3.0f;
    /** Integration sub-steps per game tick. */
    static final int CAM_SUBSTEPS = 4;
    static final float YAW_SCALE = 45f;
    static final float PITCH_SCALE = 15f;
    /** Starting std whose mean applied hand effort matches the old linear 0.01 control noise. */
    static final float LOOK_STD_INIT = CameraMap.stdForMeanAbs(0.01f, CAMERA_EXPONENT, CAMERA_LINEAR_MIX);
    static final float LOOK_LOGSTD_MIN = (float) Math.log(CameraMap.stdForMeanAbs(0.003f, CAMERA_EXPONENT, CAMERA_LINEAR_MIX));
    /** Largest raw std: 2-sigma (cubic) / 1-sigma (linear) applied hand effort is at most 15% of max effort. */
    static final float LOOK_LOGSTD_MAX = (float) Math.log(CameraMap.stdForTail(0.15f, CAMERA_EXPONENT, CAMERA_LINEAR_MIX));
    /** Entropy bonus on the camera std, relative to ENTROPY_COEF (small, so the std can shrink once aim is good). */
    static final float LOOK_ENTROPY_SCALE = 0.25f; // applied to the BASE entropy coef (never boosted by the anti-collapse floor)
    /** Gradient that pushes the camera log-std back inside its limits (without it a std stuck at a limit could never recover). */
    static final float LOOK_CLAMP_RESTORE = 0.01f;

    static final int OFF_YAW = 0;                                // mean, then log-std at +1
    static final int OFF_PITCH = OFF_YAW + 2;                    // 2   mean, log-std at +1
    static final int OFF_FWD = OFF_PITCH + 2;                    // 4   (back / none / forward)
    static final int OFF_STRAFE = OFF_FWD + 3;                   // 7   (left / none / right)
    static final int OFF_ATTACK = OFF_STRAFE + 3;                // 10
    static final int OFF_JUMP = OFF_ATTACK + 1;                  // 11
    static final int OFF_SPRINT = OFF_JUMP + 1;                  // 12
    static final int OFF_SNEAK = OFF_SPRINT + 1;                 // 13  (on / off; sneaking slows to 30 %, stops sprinting, lowers eyes to 1.27 and the hitbox to 1.5)
    static final int ACTION_SIZE = OFF_SNEAK + 1;                // 14
    static final int ACTION_SIZE_PRE_SNEAK = 13;                 // output size of older saves

    // ---------------- PPO (online, learns while you play) ----------------
    /** Ticks of experience collected before a batch is handed to the learner (was 128: far too noisy for GAE + advantage normalisation). */
    static final int ROLLOUT = 512;
    /** Samples per gradient step. One step runs on every tick while a batch is waiting. */
    static final int MINIBATCH = 64;
    /** Passes over each rollout. 4 epochs * (512/64) = 32 gradient steps per 512 ticks. */
    static final int EPOCHS = 4;
    static final float GAMMA = 0.99f;
    static final float GAE_LAMBDA = 0.95f;
    static final float CLIP = 0.2f;
    static final float LR_ACTOR = 3e-4f;
    static final float LR_CRITIC = 1e-3f;
    /** Bonus for keeping the policy random enough to explore. */
    static final float ENTROPY_COEF = 0.004f;
    static final float MAX_GRAD_NORM = 0.5f;
    /** If the policy moves further than 1.5x this within one rollout, the rest of that rollout is skipped. */
    static final float TARGET_KL = 0.03f;
    /** Adaptive PPO step-size bounds; adjustment occurs once per completed rollout. */
    static final float LR_SCALE_MIN = 0.20f, LR_SCALE_MAX = 1.50f;
    static final float KL_ADAPT_UPPER = 1.5f, KL_ADAPT_LOWER = 0.5f;
    /** Rewards are multiplied by this before learning so values stay near O(1). */
    static final float REWARD_SCALE = 0.2f;
    /** If the (summed over heads) policy entropy falls under this, the entropy bonus is multiplied (anti-collapse). */
    static final double ENTROPY_FLOOR_FRAC = 0.3; // fraction of the maximum entropy of the UNLOCKED discrete / on-off heads
    static final float ENTROPY_FLOOR_BOOST = 3f;
    static final int AUTOSAVE_EVERY_TICKS = 6000; // 5 minutes at 20 TPS
    /** Autosave interval while the curriculum is still in stage 1-3 (early progress is cheap to lose). */
    static final int AUTOSAVE_EARLY_TICKS = 2000;
    static final int STATS_EVERY_EPISODES = 10;

    // ---------------- episode ----------------
    /** Default live-mod episode limit in ticks (20 ticks = 1 second). The simulator sizes its limit to the selected kit. */
    static final int EPISODE_TICKS = 300;
    /**
     * STAGE-GATE decision at the time limit. Against diamond armor + Protection III a kill needs ~21 full hits (0.98 HP each), so a clearly
     * winning duel often has not ended when time is up, and a gate that counts only kills reads 0 % for a policy that out-fights the bot
     * (measured: dealt 9.5 HP vs a stationary bot, 100 % timeouts, 0 % wins). A timeout counts as a gate SUCCESS when the agent dealt at least
     * LEAD_MIN_DEALT_HP and out-damaged the enemy by at least LEAD_MARGIN_HP. Gate only: the terminal reward stays 0 for a timeout, wins/losses in
     * the logs stay kills, and the guard's collapse rule is unchanged. OFF by default (opt in with -Drlpvp.leadDecision=true): in a 500k-tick from-scratch A/B it promoted the agent faster but ended in a passive policy.
     */
    static final boolean LEAD_DECISION = "true".equals(System.getProperty("rlpvp.leadDecision")); // OFF by default: see docs/CHANGELOG_V7_19.md
    static final double LEAD_MIN_DEALT_HP = 6.0, LEAD_MARGIN_HP = 5.0;
    static boolean leadDecision(boolean timedOut, double dealtHp, double takenHp) {
        return LEAD_DECISION && timedOut && dealtHp >= LEAD_MIN_DEALT_HP && dealtHp - takenHp >= LEAD_MARGIN_HP;
    }
    /** Simulator gives a full-charge, always-landed kill about twice its theoretical minimum time; override with -Dsim.episodeTicks=N for A/B. */
    static final double EPISODE_KILL_TIME_FACTOR = 2.0;
    /** Hard safety cap for simulator episode lengths. */
    static final int EPISODE_TICKS_MAX = 1200;
    /**
     * A player must be this close (blocks) to be picked as the opponent. 48 = the usual player tracking distance on servers (a player farther away
     * is not even loaded on the client). NOTE: the distance input saturates at 6 blocks (dist / 6), so beyond that the policy sees "far" and relies on
     * the yaw/pitch error to turn and approach; it was trained at 3-6 blocks.
     */
    static final double TARGET_RANGE = 96.0;
    /** The current opponent is dropped (episode ends) when it gets farther than this. */
    static final double TARGET_LOSE_RANGE = 112.0;

    // ---------------- combat bookkeeping ----------------
    /** Health lost by the opponent only counts as "my damage" this many ticks after my swing. */
    static final int HIT_CREDIT_TICKS = 6;
    /** Attack only fires when the weapon cooldown is at least this charged (0..1). */
    static final float MIN_ATTACK_STRENGTH = 0.9f;
    /**
     * From this stage on the agent may swing before the weapon is fully charged (gate lowered to MIN_ATTACK_STRENGTH_LATE),
     * so it can LEARN to wait for a full charge (FULL_CHARGE_HIT_BONUS) instead of being forced to. Earlier stages keep the hard gate.
     */
    static final int GATE_RELAX_STAGE = 99; // relaxing the gate at stage 6 made the simulated agent spam swings and flee; keep the hard 0.9 gate (set to 6 to experiment)
    static final float MIN_ATTACK_STRENGTH_LATE = 0.5f;
    /**
     * For servers that hide or fake bot health: count a hit from the opponent's hurt animation
     * instead of a health drop. Leave off unless your bots' health never changes on your screen.
     */
    static final boolean HURT_FALLBACK = false;
    /** HP credited per hit when HURT_FALLBACK is on (about a diamond sword hit). */
    static final float FALLBACK_HIT_HP = 7f;
    /** Click "Respawn" automatically when the agent dies. */
    static final boolean AUTO_RESPAWN = true;

    // ---------------- reward ----------------
    /** Reward for dealing all 20 HP of damage (and penalty for taking it). */
    static final float W_DAMAGE = 12f;   // 9 made the simulated agent flee as soon as the enemy started hitting back (stage 5); raise tech weights, not this
    static final float W_WIN = 15f;
    /** v7.20 faster kills: a win adds FAST_WIN_BONUS x (share of the episode time left); a TIMEOUT draw from DRAW_PENALTY_FROM_STAGE on costs DRAW_PENALTY (a loss is -W_WIN, so a draw stays much better than a loss). See Reward.finishAdjust. */
    static final float FAST_WIN_BONUS = 3f, DRAW_PENALTY = 3f;
    static final int DRAW_PENALTY_FROM_STAGE = 6;
    /** v7.20: false (default) keeps the sneak head locked in EVERY stage (it only lowers the hitbox, stops sprinting and slows to 30 %). -Drlpvp.sneak=true re-enables it from stage 6. */
    static final boolean SNEAK_ENABLED = Boolean.parseBoolean(System.getProperty("rlpvp.sneak", "false"));
    /** Dense shaping (facing + closeness) fades from 1.0 down to SHAPING_MIN as training ticks pass. */
    static final float SHAPING_MIN = 0.35f;
    static final float SHAPING_TAU_TICKS = 400_000f;   // was 100k: with 378 inputs the agent learns slower and the aim shaping was gone before it could aim
    static final float FACING_REWARD = 0.01f;      // per tick at full shaping
    static final float CLOSENESS_REWARD = 0.0025f; // per tick at full shaping

    // ---------------- reward objective ----------------
    /** Default to outcome-first learning: do not assign intrinsic value to named combat techniques. */
    static final boolean OUTCOME_ONLY_REWARDS = true;
    static boolean outcomeOnlyRewards() { return OUTCOME_ONLY_REWARDS; }

    // ---------------- situational technique discovery (see TechniqueDiscovery) ----------------
    /** Small, temporary, outcome-settled technique hints. Independent of OUTCOME_ONLY_REWARDS (keep that true: legacy bonuses stay off). */
    static final boolean TECH_DISCOVERY = true;
    /** Base bonuses (before curriculum tech weight, annealing and per-episode diminishing). A 7 HP hit is worth 4.2 via W_DAMAGE. */
    static final float TECH_CRIT = 0.40f;
    static final float TECH_SPRINT_HIT = 0.15f;
    static final float TECH_KB_FOLLOWUP = 0.25f;   // next real hit 6..30 ticks after a sprint hit, no damage taken in between
    static final float TECH_COMBO = 0.15f;         // per extra consecutive hit (max 3 extra)
    static final float TECH_FIRST_HIT = 0.20f;
    static final float TECH_PUNISH = 0.20f;        // hit within PUNISH_WINDOW_TICKS of the enemy's swing while its weapon is low
    static final float TECH_DODGE = 0.10f;         // enemy swung while I was in its reach and moving; nothing landed
    static final float TECH_PUNISH_MAX_ENEMY_CHARGE = 0.6f;
    /** Knockback follow-up that needed a real chase (enemy pushed >= TECH_PURSUIT_MIN_GAP blocks farther than at the sprint hit, then I closed in) pays x this; a hit with no separation is just standing next to it. Still settled by the exchange, so never paid for losing trades. */
    static final double TECH_PURSUIT_MULT = 1.6;
    static final double TECH_PURSUIT_MIN_GAP = 0.8;
    /** W-tap: a sprint hit that follows a sprint hit inside the follow-up window after a CLEAN sprint reset (sprint dropped for 1..TECH_WTAP_MAX_DROP ticks, not a long stop). Settled by the exchange like every technique bonus. */
    static final float TECH_WTAP = 0.12f;
    static final int TECH_WTAP_MAX_DROP = 4;
    /** Combo denial: second+ hit of a combo; paid only if the exchange was won AND I took nothing. x(1 + 0.5 * enemy swings that could not reach me, max 2). */
    static final float TECH_DENY = 0.15f;
    static final int TECH_FOLLOWUP_MIN_TICKS = 6;
    static final int TECH_FOLLOWUP_MAX_TICKS = 30;
    static final int TECH_DODGE_WINDOW = 6;
    static final int TECH_DODGE_CAP = 3;
    static final double TECH_DODGE_MIN_SPEED = 0.08;   // blocks/tick
    static final double TECH_DODGE_MIN_FACING = 0.8;
    /** One technique event per landed swing, and at least this many ticks between events (vanilla hurt-invulnerability is 10). */
    static final int TECH_MIN_EVENT_GAP_TICKS = 10;
    /** A technique bonus is only paid if HP dealt - HP taken over this many ticks after the hit is positive. */
    static final int TECH_EXCHANGE_TICKS = 20;
    /** Hard cap on technique bonus per episode (W_WIN is 15). */
    static final float TECH_EPISODE_CAP = 2.5f;
    /** Bonuses fade (cosine) from 1 to TECH_FLOOR over this many technique-stage training ticks, then stay at the floor (set 0 to remove fully). */
    static final long TECH_ANNEAL_TICKS = 1_500_000L;
    static final float TECH_FLOOR = 0.25f;
    /** Preserved miss penalty (not annealed): a miss within this many ticks of the previous miss. */
    static final float WHIFF_STREAK_PENALTY = 0.08f;
    static final int WHIFF_STREAK_WINDOW = 12;

    // ---------------- reward additions (curriculum) ----------------
    /** Pitch-facing term. Multiplied by the curriculum pitch weight (0 in stage 1, ramps to 1 from stage 2). */
    static final float PITCH_FACING_REWARD = 0.01f; // = FACING_REWARD: pitch is rewarded like yaw
    /** Small per-tick cost so the agent does not stall. Scaled by the curriculum time weight. */
    static final float TIME_PENALTY = -0.001f;
    /** Reward per block of distance closed, only while the enemy was farther than PROGRESS_MIN_PREV_DIST. */
    static final float PROGRESS_REWARD = 0.02f;
    static final double PROGRESS_MIN_PREV_DIST = 3.5;
    /** Per-tick bonus for standing at sword range (stage 7+). */
    static final float SPACING_REWARD = 0.004f;
    static final double SPACING_MIN = 2.0;
    static final double SPACING_MAX = 3.2;

    // ---------------- legacy technique bonuses (used only when OUTCOME_ONLY_REWARDS=false) ----------------
    /** Real reach used by ActionApplier's own crosshair ray (vanilla survival entity reach). */
    static final double ATTACK_REACH = 3.0;
    /** Jump-crit: hit while falling and not sprinting (+50% damage in vanilla). Extra on top of the damage itself. */
    static final float CRIT_BONUS = 1.4f;       // clearly above SPRINT_HIT_BONUS: a jump-crit (+50 % damage) must beat a sprint hit
    /** Sprint hit = extra knockback; teaches sprint-resets / W-tapping. */
    static final float SPRINT_HIT_BONUS = 0.15f;
    /** Per extra consecutive hit without taking damage (capped at 3 extra). */
    static final float COMBO_BONUS = 0.3f;
    /** Winning the opening exchange. */
    static final float FIRST_HIT_BONUS = 0.5f;
    /** Swinging blind (target out of reach or far off-aim). Hits are never penalised, only pointless swings. */
    static final float WHIFF_PENALTY = 0.2f;
    /**
     * Cost of EVERY missed swing (a miss spends the 12-tick attack cooldown, and the 6.3-degree 'pointless' cone above never charged a swing
     * that was merely a little off). Measured: the v7.2 checkpoint misses 81-93 % of its swings in evaluation. Small next to a hit (7 HP = 4.2),
     * applied in training only. DEFAULT 0 (off): an 80k-tick A/B from the v7.2 checkpoint with 0.12 did NOT lower the whiff rate (81 % vs 75 % without it) and that run fell back to stage 6, so it is unproven. -Drlpvp.missCost=0.12 re-enables it for experiments.
     */
    /**
     * ATTACK GATE (invalid-action masking, like masking an illegal move): a swing is only offered to the policy when it could possibly connect, i.e. the
     * enemy is within ATTACK_GATE_DIST blocks and the crosshair is within ATTACK_GATE_YAW / ATTACK_GATE_PITCH degrees of it (the policy's own, delayed
     * observation). The masks are far wider than the hit cone (hitbox half-angle ~6 degrees at 3 blocks), so WHEN to swing inside the cone, and
     * whether to correct aim first, is still learned; only swings that cannot hit are removed (the evaluated policy had 75-93 % misses).
     * The mask is stored with every transition (PPO log-probs stay exact) and the head's entropy is excluded while masked.
     * -Drlpvp.attackGate=false turns it off (A/B runs, old behaviour).
     */
    static final boolean ATTACK_GATE = !"false".equalsIgnoreCase(System.getProperty("rlpvp.attackGate", "true"));
    /** v7.20 tighter (was 4.0 / 20 / 30): the hit cone is ~6 degrees at 3 blocks and reach is ~3.3, so these still leave room for the policy's delayed view while removing swings that cannot connect. */
    static final double ATTACK_GATE_DIST = 3.7, ATTACK_GATE_YAW = 12.0, ATTACK_GATE_PITCH = 20.0;
    /** v7.20: default 0.05 (was 0). Every missed swing spends the attack cooldown. Small next to a hit (7 HP = 4.2) so the agent does not stop swinging. -Drlpvp.missCost=0 restores the old value. */
    static final float MISS_COST = Float.parseFloat(System.getProperty("rlpvp.missCost", "0.05"));
    static final double WHIFF_FAR_DIST = 3.6;
    static final double WHIFF_OFFAIM_YAW = 0.035; // |yaw err| / 180 = 6.3 degrees, about the hitbox half-angle at 3 blocks: a swing that is not on the enemy costs something
    static final double WHIFF_OFFAIM_PITCH = 0.06; // |pitch err| / 90 = 5.4 degrees (the pitch axis counts too)
    /** While the weapon recharges (<50%), standing just outside enemy reach is worth this fraction of SPACING_REWARD. */
    static final double RETREAT_MAX = 4.3;
    static final float RETREAT_FRACTION = 0.8f;

    // ---------------- timing bonuses (stage 6+, paid only together with a REAL hit, scaled by Weights.late) ----------------
    /** A weapon is "fully charged" at this cooldown value. */
    static final float FULL_CHARGE = 0.9f;
    /** Hit that was swung with a fully charged weapon (only meaningful once the hard gate is lowered, GATE_RELAX_STAGE). */
    static final float FULL_CHARGE_HIT_BONUS = 0.3f;
    /** Weak W-tap / reset signal: the hit's swing came this many ticks after my previous swing. */
    static final int RESET_GAP_MIN = 8;
    static final int RESET_GAP_MAX = 13;
    static final float RESET_HIT_BONUS = 0.15f;
    /** Hit whose swing started within this many ticks after the ENEMY started a swing (its weapon was recharging). */
    static final int PUNISH_WINDOW_TICKS = 6;
    static final float PUNISH_HIT_BONUS = 0.35f;
    /** Per tick while my HP is above the enemy's (scaled by the lead and by anti-stalling, stage 7+ only). */
    static final float HP_ADVANTAGE_REWARD = 0.004f;
    /** The enemy's weapon is assumed to need this many ticks to recharge (a sword; its real cooldown is not synced to remote clients). */
    static final float ENEMY_CHARGE_TICKS = 12.5f;

    /** Aim reward shape 1/(1+(err/scale)^2): ~1 on target, 0.5 at this many degrees off, so small improvements matter. */
    static final double AIM_YAW_SCALE_DEG = 10.0;
    static final double AIM_PITCH_SCALE_DEG = 10.0; // = AIM_YAW_SCALE_DEG

    // ---------------- soft hit credit (learning aid, never auto-aim) ----------------
    /** A swing that misses the crosshair but had decent aim at a target in reach counts as this fraction of a hit. */
    static final float SOFT_HIT_FRACTION = 0.25f;
    /** Soft credit is a stage 1-4 aiming aid only; from this stage on it is off (it was farmable by whiffing). */
    static final int SOFT_MAX_STAGE = 4;
    /** Max soft-credit HP per episode, so whiff-spamming cannot out-earn real fighting. */
    static final float SOFT_EPISODE_CAP_HP = 3.5f;
    /** HP a full sword hit is worth for the soft-credit calculation (about a diamond sword). */
    static final float SOFT_HIT_HP = 7f;
    static final double SOFT_HIT_REACH = 3.0;
    /** |yaw error| / 180 at or below this (0.06 is about 11 degrees). */
    static final double SOFT_YAW_ERR = 0.06;
    /** |pitch error| / 90 at or below this (0.10 is about 9 degrees). */
    static final double SOFT_PITCH_ERR = 0.10;

    // ---------------- anti-stalling ----------------
    /** Dense shaping stays at full strength this many ticks into an episode with no real hit landed... */
    static final int IDLE_FREE_TICKS = 60;
    /** ...then fades linearly to 0 over this many ticks, so standing at spacing without fighting stops paying. */
    static final int IDLE_FADE_TICKS = 120;

    // ---------------- policy prior ----------------

    // ---------------- curriculum ----------------
    // No STAGE_MIN_TICKS / STAGE_MAX_TICKS: progression is purely performance based (see Curriculum). The evidence minimum is GATE_EPISODES.
    /** Recent win rate required to leave stages 1..8 (stage 1 cannot be won, the bot is out of reach: it counts on-target time instead). */
    static final float[] STAGE_GATE_WIN = {0.60f, 0.60f, 0.60f, 0.60f, 0.60f, 0.55f, 0.50f, 0.45f};
    /** Stages 1..AIM_GATE_MAX_STAGE count an episode as a success if it was won OR the agent was on target this fraction of the time (the bot is no longer placed, so a kill may be out of reach). */
    static final int AIM_GATE_MAX_STAGE = 4;
    static final double AIM_GATE_ON_TARGET = 0.6;
    /** Aim-stage stall relief (see docs/CAMERA_DYNAMICS.md): first AIM_GATE_GRACE_TICKS of an episode are ignored; every AIM_GATE_RELIEF_EPISODES episodes in the stage lower the on-target share by AIM_GATE_RELIEF_STEP down to AIM_GATE_FLOOR. */
    static final int AIM_GATE_GRACE_TICKS = 15;
    static final int AIM_GATE_RELIEF_EPISODES = 90;
    static final double AIM_GATE_RELIEF_STEP = 0.05;
    static final double AIM_GATE_FLOOR = 0.30;
    static final double ON_TARGET_DEG = 6.0;
    /** Win rate is measured over this many most recent episodes of the stage. */
    static final int GATE_EPISODES = 30;
    // ---------------- SpamGuard: jumps that lead nowhere and sneaking are charged, jumps that lead to a real hit are refunded (see SpamGuard)
    static final int SPAM_EMA_TICKS = 100;
    static final int SPAM_JUMP_WINDOW = 30;            // ticks after a jump in which a real hit refunds it
    static final double SPAM_JUMP_COST = 0.006, SPAM_JUMP_REFUND = 0.02, SPAM_JUMP_UNJUST = 0.01;
    static final double SPAM_JUMP_OK = 0.03;           // unjustified jumps per tick allowed before the rate penalty (about one per 33 ticks)
    static final double SPAM_RATE_W = 0.3;
    static final double SPAM_SNEAK_TICK = 0.0015, SPAM_SNEAK_TOGGLE = 0.008;
    static final double SPAM_SNEAK_OK = 0.20;          // share of time spent sneaking allowed before the rate penalty
    static final double SPAM_SNEAK_RATE_W = 0.05;
    // Small movement-pathology penalties. These are capped per episode and never forbid a technique.
    static final double SPAM_MOVE_STAGNATION = 0.0015, SPAM_MOVE_OVERLAP = 0.004;
    static final double SPAM_MOVE_REVERSAL = 0.003, SPAM_MOVE_SPRINT_TOGGLE = 0.002;
    static final double SPAM_MOVE_BAD_STRAFE = 0.0015, SPAM_MOVE_EP_CAP = 0.35;
    // v7.16 movement-spam guard: bounded, rate-based penalties; never hard-code combat sequences.
    static final int SPAM_FLIP_WINDOW = 3;
    static final double SPAM_FLIP_OK = 0.12, SPAM_SPRINT_TOGGLE_OK = 0.06, SPAM_FLIP_W = 0.2;
    static final double SPAM_STUCK_SPEED = 0.02;
    static final int SPAM_STUCK_TICKS = 10, SPAM_HIT_GRACE = 12;
    static final double SPAM_STUCK_COST = 0.002, SPAM_SPRINT_NOFWD_COST = 0.0008;
    static final double SPAM_MOVE_TICK_CAP = 0.01, SPAM_MOVE_EPISODE_CAP = 0.8;
    // v7.18 key chatter: a W / S / A / D / sprint key that changes again before it was held SPAM_CHATTER_MIN_HOLD ticks is a one-tick tap.
    // Rate-based (free below SPAM_CHATTER_OK) + a tiny per-event cost, inside the same per-tick / per-episode caps. W / sprint taps are free inside a combo window (a real w-tap).
    static final int SPAM_CHATTER_MIN_HOLD = 3;
    static final double SPAM_CHATTER_OK = 0.04, SPAM_CHATTER_W = 0.5, SPAM_CHATTER_COST = 0.004;
    /** Ticks after MY real hit in which a W / sprint tap counts as a w-tap (not chatter). */
    static final int SPAM_COMBO_TICKS = 14;

    // ---------------- jump reset (JumpReset): measured knockback reduction, never a scripted key press ----------------
    /** Jump choices up to this many ticks BEFORE the hit (1 = the tick of the hit) and this many AFTER it count as a reset attempt (the jump must start on the ground). */
    static final int JR_LOOKBACK = 2, JR_POST_TICKS = 1;
    /** Knockback is measured as blocks moved away from the attacker over this many ticks after the hit. */
    static final int JR_MEASURE_TICKS = 8, JR_MIN_GAP_TICKS = 8;
    /** Baseline (no-reset hits, one per enemy-sprint state) needs this many samples before a reset is judged; EMA rate of the baseline. */
    static final int JR_MIN_BASE = 4;
    static final double JR_EMA = 0.2, JR_MIN_REDUCTION = 0.12, JR_FULL_REDUCTION = 0.5, JR_MIN_REF = 0.3;
    /** Bonus for a reset that cut the knockback (x reduction / JR_FULL_REDUCTION, annealed like the other technique hints), small penalty for a reset that made it clearly worse. */
    static final float JR_BONUS = 0.30f, JR_WORSE_PENALTY = 0.05f, JR_EPISODE_CAP = 1.0f;
    static final double JR_WORSE_AT = -0.25;
    /** The consequence model trains on every Nth transition (validation samples are unaffected): about half its per-tick cost at 2. */
    static final int CONSEQUENCE_TRAIN_EVERY = 2;
    /**
     * REVIEW MIXING: from REVIEW_FROM_STAGE on, a share of the training episodes is played against opponents of EARLIER stages (3..stage-1, the
     * nearest ones most often). It keeps the agent from forgetting how to beat them, and gives a learning signal while the current stage is too hard
     * (a stage-7 run sat at 16-21 % wins for 1,400 episodes). Review episodes never count toward the gate, the hop level or the collapse guard.
     * A stalled stage (no gate after STALL_EPISODES episodes and under half of the needed rate) doubles the share.
     */
    static final int REVIEW_FROM_STAGE = 6;
    static final int REVIEW_MIN_STAGE = 3;
    static final double REVIEW_SHARE = 0.20;
    static final double REVIEW_SHARE_STALLED = 0.40;
    static final int STALL_EPISODES = 20 * GATE_EPISODES;
    /**
     * A stage is only left after the window has stayed at the gate for this many consecutive episodes (counting the one that filled it: one extra full window): a single lucky
     * window of 30 episodes is not enough evidence (a fresh run reached stage 7 after 100k ticks on 53 % wins and collapsed there).
     */
    static final int GATE_HOLD_EPISODES = 30;
    /** Every time stage s+1 collapsed and the agent was sent back, the gate for leaving stage s rises by this much (max GATE_BUMP_MAX). */
    static final float GATE_BUMP_PER_COLLAPSE = 0.05f;
    static final float GATE_BUMP_MAX = 0.15f;
    /** Ticks over which the pitch reward weight ramps from 0 to 1 after leaving stage 1. */
    static final long PITCH_RAMP_TICKS = 6000;
    /** Entropy coefficient multiplier right after a lock is lifted, decaying back to 1 over ENTROPY_BOOST_TICKS. */
    static final float ENTROPY_BOOST = 3f;
    static final long ENTROPY_BOOST_TICKS = 6000;

    // ---------------- opponent bot (Carpet, singleplayer only) ----------------
    // The bot is NEVER teleported. Between episodes it is only healed in place.
    /** Heal the bot and the agent (health + food) at the start of each episode. Nobody is moved. */
    static final boolean HEAL_AGENT = true;
    /** Ticks to wait after healing so the new health has reached the client before the episode starts. */
    static final int HEAL_WARMUP_TICKS = 3;
    /** If a Carpet bot dies and is removed, respawn it where it died (/player <n> spawn at ...). */
    static final boolean RESPAWN_BOT = true;
    /** Stage 7: how often the frozen self-play opponent is refreshed from the learning policy. */
    static final long SELF_PLAY_SNAPSHOT_TICKS = 25_000;
    /** Stage 7 is a league: past snapshots + scripted opponents. Max frozen snapshots kept. */
    static final int LEAGUE_POOL = 8;
    /** Stage 7 opponent mix per episode: P(snapshot), P(strong scripted), rest = aggressive scripted. */
    static final double LEAGUE_P_SNAPSHOT = 0.5;
    static final double LEAGUE_P_STRONG = 0.3;
    /** Scripted bots turn at a limited speed (degrees/tick) instead of snapping to the agent. */
    static final float BOT_TURN_WALK = 40f;
    static final float BOT_TURN_AGGRESSIVE = 35f;
    static final float BOT_TURN_STRONG = 30f;
    /** Stage 8 ELITE bot: minimum adaptive difficulty, base chance to jump-reset when hit, share of random (unpredictable) strafe decisions. */
    static final double ELITE_MIN_DIFFICULTY = 0.6, ELITE_JUMP_RESET_BASE = 0.5, ELITE_UNPREDICTABLE = 0.4;

    // ---------------- play policy / per-head exploration ----------------
    /**
     * /rl play and the simulator's evaluation use PpoAgent.actPlay: camera = mean (no noise), discrete heads SAMPLED at this temperature.
     * Pure argmax (actGreedy) can never pick a minority action: jump (low prior probability) and "no strafe"/"back" are never the plurality, so a
     * greedy evaluation showed 100% one-sided strafe, 0 jumps, 0 crits even when the trained policy mixes them. 1.0 = exactly the trained policy.
     */
    static final boolean PLAY_STOCHASTIC = true;
    static final float PLAY_TEMPERATURE = 1.0f;
    /**
     * Per-head entropy floors. The old floor was on the SUM of the discrete heads, which the attack/sprint heads can satisfy while
     * strafe collapses to one key. A head (forward/back, strafe, jump) whose own entropy EMA falls below this fraction of its maximum
     * gets its entropy bonus multiplied. The attack and sprint heads are deliberately excluded (a random attack head just whiffs).
     */
    static final double HEAD_ENTROPY_FLOOR_FRAC = 0.35;
    static final float HEAD_ENTROPY_BOOST = 3f;

    // ---------------- greedy gate (the offline simulator probes the shipped policy; the mod never sets it, so nothing changes there) ----------------
    /** From this stage on, leaving a stage needs the play-mode probe to land hits. */
    static final int GREEDY_GATE_FROM_STAGE = 4;
    /** Entering this stage or later can NOT be forced by the max-tick timer. */
    static final int GREEDY_HARD_FROM_STAGE = 6;
    static final double GREEDY_GATE_HITS = 2.0;
    /** From stage 6 the probe must also not lose the damage race by more than this ratio (dealt >= ratio * taken). */
    static final double GREEDY_GATE_DAMAGE_RATIO = 0.5;
    static final long GREEDY_PROBE_TICKS = 15_000;
    static final int GREEDY_PROBE_EPISODES = 10;

    // ---------------- collapse guard (best-checkpoint rollback, see CollapseGuard) ----------------
    /** Rollback only if the smoothed score is this far below the best smoothed score of the stage... */
    static final double GUARD_DROP = 0.6;
    /** ...for this many windows in a row (a window = STATS_EVERY_EPISODES benchmark episodes). */
    static final int GUARD_PATIENCE = 4;
    /** Windows to wait after a rollback before another is allowed (lets learning resume). */
    static final int GUARD_COOLDOWN_WINDOWS = 12;
    /** Hard cap per stage, so a bad best-snapshot can never freeze training. */
    static final int GUARD_MAX_PER_STAGE = 3;
    static final double GUARD_EMA_ALPHA = 0.2;
    /** A window (STATS_EVERY_EPISODES benchmark episodes) must be at or below this win rate to be eligible for failure classification. */
    static final double GUARD_FAIL_WIN = 0.10;
    /** Eligible non-winning windows are failures only if at least this fraction of episodes are losses, or the policy is not fighting/out-traded. */
    static final double GUARD_FAIL_LOSS = 0.50;
    /** Minimum average real HP damage per episode; below this, the policy is considered to be fleeing/not engaging. */
    static final double GUARD_FAIL_MIN_DEALT = 1.0;
    /** If dealt HP is below this multiple of taken HP, the policy is clearly out-traded. */
    static final double GUARD_FAIL_TRADE = 0.50;
    /** ...this many failed windows in a row = the stage has collapsed: restore the weights it was entered with and go back one stage. */
    static final int GUARD_FAIL_WINDOWS = 5;
    /** Wilson upper bound: only demote when even the 95% upper confidence bound is below this win-rate gate. */
    static final double GUARD_WILSON_Z = 1.96;
    static final int GUARD_MIN_EVIDENCE_EPISODES = 30;
    static final int GUARD_EVIDENCE_WINDOW = 60;
    /** Collapse detection only where a win is meaningful (stages 1..AIM_GATE_MAX_STAGE are scored on aim). */
    static final int GUARD_DEMOTE_FROM_STAGE = AIM_GATE_MAX_STAGE + 1;
    /** A window scoring below this is never stored as the "best" checkpoint (it used to bless an already collapsed policy). */
    static final double GUARD_BEST_FLOOR = -0.5;
    /** Windows in a stage before a best snapshot may be stored. */
    static final int GUARD_MIN_WINDOWS = 3;

    // ---------------- symmetric policy ----------------
    /**
     * The policy is made exactly left/right symmetric: the network is run on the observation AND on its mirror image, and the
     * two answers are averaged (strafe sides swapped, yaw sign flipped). The agent can then no longer have a built-in favourite
     * side. Mirrored training episodes only make the world symmetric; they cannot stop the agent from always picking "left"
     * in its own frame. This can.
     */
    static final boolean SYMMETRIC_POLICY = true;

    // ---------------- HUD ----------------
    static final int HUD_EVERY_TICKS = 5;
}