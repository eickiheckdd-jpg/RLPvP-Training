package com.rlpvp;

import java.util.Random;

/**
 * A small TRAINABLE GRU cell (H = 8 units, X = 8 inputs): h' = (1 - z) h + z tanh(Wc x + Uc (r h) + bc), z / r = sigmoid gates.
 * Pure Java, no Minecraft classes.
 *
 * It starts from the seeded multi-timescale initialisation OpponentMemory used before (update-gate biases spread over ~3..100 ticks), so a fresh
 * cell behaves exactly like the old fixed memory. PpoAgent then trains it with truncated backprop through time (Config.GRU_BPTT ticks): for every
 * PPO sample it replays the preceding ticks of the rollout from the hidden state stored at the window start, feeds the recomputed state into the
 * policy / value inputs and pushes the gradient back through the window (windowStep / backWindow, Adam in step). Weights are saved in the
 * checkpoint (GRU1 trailer); a checkpoint without one starts from the default.
 */
final class GruCell {
    static final int H = 8, X = 8;
    // flat parameter layout
    static final int WZ = 0, WR = H * X, WC = 2 * H * X;
    static final int UZ = 3 * H * X, UR = UZ + H * H, UC = UZ + 2 * H * H;
    static final int BZ = UZ + 3 * H * H, BR = BZ + H, BC = BZ + 2 * H;
    static final int N = BC + H;

    /** Shared read-only default (used when no agent supplies its own trained cell). Never trained. */
    static final GruCell DEFAULT = new GruCell();

    final float[] w = new float[N];
    private final float[] g = new float[N], m = new float[N], v = new float[N];
    private int adamT;

    // truncated-BPTT window cache
    private static final int K = Math.max(1, Config.GRU_BPTT);
    private final float[][] hs = new float[K + 1][H], zs = new float[K][H], rs = new float[K][H], cs = new float[K][H], rhs = new float[K][H], xs = new float[K][X];
    private int len;
    private final float[] dh = new float[H], dhPrev = new float[H], dcp = new float[H], dzp = new float[H], drp = new float[H], drh = new float[H];

    GruCell() { initDefault(w); }

    static void initDefault(float[] w) {
        java.util.Arrays.fill(w, 0f);
        Random r = new Random(0x0BB0_5EEDL);
        for (int j = 0; j < H; j++) {
            double tau = 3.0 * Math.pow(2.0, j * 0.7);              // 3 .. ~100 ticks
            double z = 1.0 / tau;
            w[BZ + j] = (float) Math.log(z / (1.0 - z));
            w[BC + j] = (float) (r.nextGaussian() * 0.1);
            for (int i = 0; i < X; i++) {
                w[WZ + j * X + i] = (float) (r.nextGaussian() * 0.25); w[WR + j * X + i] = (float) (r.nextGaussian() * 0.5);
                w[WC + j * X + i] = (float) (r.nextGaussian() * 1.0);
            }
            for (int i = 0; i < H; i++) {
                w[UZ + j * H + i] = (float) (r.nextGaussian() * 0.1); w[UR + j * H + i] = (float) (r.nextGaussian() * 0.3);
                w[UC + j * H + i] = (float) (r.nextGaussian() * 0.6 / Math.sqrt(H));
            }
        }
    }

    void resetToDefault() { initDefault(w); java.util.Arrays.fill(g, 0f); java.util.Arrays.fill(m, 0f); java.util.Arrays.fill(v, 0f); adamT = 0; }

    private static float sig(float x) { return (float) (1.0 / (1.0 + Math.exp(-x))); }

    /** One step. z, r, c, rh are scratch (or the window cache); out may not alias h. */
    private void core(float[] h, float[] x, float[] z, float[] r, float[] c, float[] rh, float[] out) {
        for (int j = 0; j < H; j++) {
            float sz = w[BZ + j], sr = w[BR + j];
            int wx = j * X, uh = j * H;
            for (int i = 0; i < X; i++) { sz += w[WZ + wx + i] * x[i]; sr += w[WR + wx + i] * x[i]; }
            for (int i = 0; i < H; i++) { sz += w[UZ + uh + i] * h[i]; sr += w[UR + uh + i] * h[i]; }
            z[j] = sig(sz); r[j] = sig(sr); rh[j] = r[j] * h[j];
        }
        for (int j = 0; j < H; j++) {
            float sc = w[BC + j];
            int wx = j * X, uh = j * H;
            for (int i = 0; i < X; i++) sc += w[WC + wx + i] * x[i];
            for (int i = 0; i < H; i++) sc += w[UC + uh + i] * rh[i];
            c[j] = (float) Math.tanh(sc);
            out[j] = (1f - z[j]) * h[j] + z[j] * c[j];
        }
    }

    /** Acting path: advances the hidden state in place. Not thread-safe (one cell per acting thread's OpponentMemory call). */
    void step(float[] h, float[] x, float[] scratchOut) {
        float[] z = new float[H], r = new float[H], c = new float[H], rh = new float[H];
        core(h, x, z, r, c, rh, scratchOut);
        for (int j = 0; j < H; j++) h[j] = Float.isNaN(scratchOut[j]) ? 0f : Math.max(-1f, Math.min(1f, scratchOut[j]));
    }

    // ------------------------------------------------------------------ truncated BPTT
    void beginWindow(float[] h0) { len = 0; System.arraycopy(h0, 0, hs[0], 0, H); }

    /** Adds one tick to the window (at most K). */
    void windowStep(float[] x) {
        if (len >= K) throw new IllegalStateException("GRU window longer than Config.GRU_BPTT");
        System.arraycopy(x, 0, xs[len], 0, X);
        core(hs[len], xs[len], zs[len], rs[len], cs[len], rhs[len], hs[len + 1]);
        len++;
    }

    /** Hidden state after the last windowStep. */
    float[] windowH() { return hs[len]; }

    /** Back-propagates dhFinal (gradient w.r.t. the last hidden state) through the window, accumulating into the gradient buffer. */
    void backWindow(float[] dhFinal) {
        System.arraycopy(dhFinal, 0, dh, 0, H);
        for (int s = len - 1; s >= 0; s--) {
            float[] h = hs[s], z = zs[s], r = rs[s], c = cs[s], rh = rhs[s], x = xs[s];
            java.util.Arrays.fill(dhPrev, 0f);
            java.util.Arrays.fill(drh, 0f);
            for (int j = 0; j < H; j++) {
                float dz = dh[j] * (c[j] - h[j]);
                float dc = dh[j] * z[j];
                dhPrev[j] += dh[j] * (1f - z[j]);
                dcp[j] = dc * (1f - c[j] * c[j]);
                dzp[j] = dz * z[j] * (1f - z[j]);
            }
            for (int j = 0; j < H; j++) {                          // candidate path
                g[BC + j] += dcp[j];
                int wx = j * X, uh = j * H;
                for (int i = 0; i < X; i++) g[WC + wx + i] += dcp[j] * x[i];
                for (int i = 0; i < H; i++) { g[UC + uh + i] += dcp[j] * rh[i]; drh[i] += w[UC + uh + i] * dcp[j]; }
            }
            for (int i = 0; i < H; i++) {
                dhPrev[i] += drh[i] * r[i];
                drp[i] = drh[i] * h[i] * r[i] * (1f - r[i]);
            }
            for (int j = 0; j < H; j++) {                          // update / reset gate paths
                g[BZ + j] += dzp[j]; g[BR + j] += drp[j];
                int wx = j * X, uh = j * H;
                for (int i = 0; i < X; i++) { g[WZ + wx + i] += dzp[j] * x[i]; g[WR + wx + i] += drp[j] * x[i]; }
                for (int i = 0; i < H; i++) {
                    g[UZ + uh + i] += dzp[j] * h[i]; g[UR + uh + i] += drp[j] * h[i];
                    dhPrev[i] += w[UZ + uh + i] * dzp[j] + w[UR + uh + i] * drp[j];
                }
            }
            System.arraycopy(dhPrev, 0, dh, 0, H);
        }
    }

    /** Adam on the accumulated gradient / batch with norm clipping. A non-finite gradient is dropped. @return the pre-clip norm. */
    float step(float lr, float maxNorm, int batch) {
        float inv = 1f / Math.max(1, batch);
        double sq = 0;
        for (int i = 0; i < N; i++) { g[i] *= inv; sq += (double) g[i] * g[i]; }
        float norm = (float) Math.sqrt(sq);
        if (Double.isNaN(sq) || Double.isInfinite(sq)) { java.util.Arrays.fill(g, 0f); return Float.NaN; }
        float clip = norm > maxNorm ? maxNorm / (norm + 1e-6f) : 1f;
        adamT++;
        final float b1 = 0.9f, b2 = 0.999f, eps = 1e-8f;
        float c1 = 1f - (float) Math.pow(b1, adamT), c2 = 1f - (float) Math.pow(b2, adamT);
        for (int i = 0; i < N; i++) {
            float gi = g[i] * clip;
            m[i] = b1 * m[i] + (1f - b1) * gi;
            v[i] = b2 * v[i] + (1f - b2) * gi * gi;
            float nw = w[i] - lr * (m[i] / c1) / ((float) Math.sqrt(v[i] / c2) + eps);
            if (!Float.isNaN(nw) && !Float.isInfinite(nw)) w[i] = nw;
            g[i] = 0f;
        }
        return norm;
    }

    void clearGrad() { java.util.Arrays.fill(g, 0f); }

    /** Test hook: the gradient buffer. */
    float[] gradForTest() { return g; }

    void copyWeightsFrom(GruCell o) { System.arraycopy(o.w, 0, w, 0, N); }

    void write(java.io.DataOutputStream out) throws java.io.IOException {
        out.writeInt(N);
        for (int i = 0; i < N; i++) out.writeFloat(w[i]);
    }

    /** Reads weights written by write(); a different parameter count (a future layout) is skipped and the default kept. */
    void read(java.io.DataInputStream in) throws java.io.IOException {
        int n = in.readInt();
        if (n != N) { in.skipNBytes(4L * n); return; }
        for (int i = 0; i < N; i++) w[i] = in.readFloat();
        java.util.Arrays.fill(m, 0f); java.util.Arrays.fill(v, 0f); adamT = 0;
    }
}
