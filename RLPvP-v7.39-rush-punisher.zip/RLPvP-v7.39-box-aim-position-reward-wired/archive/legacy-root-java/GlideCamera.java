package com.rlpvp;

/**
 * Gliding display of the AI's camera. The mouse model (GameplayRotation) moves the authoritative rotation once per 20 Hz tick, and vanilla draws
 * the frames in between on a STRAIGHT line from last tick's angle to this tick's. Every tick boundary is then a corner: the speed jumps from one
 * tick's average speed to the next. A real mouse glides: its speed is continuous.
 *
 * This class replaces the straight line by a cubic Hermite curve through the same two angles whose slopes at both ends are the mouse's TRUE
 * velocities at the tick boundaries (the end velocity of tick N is the start velocity of tick N+1), so the displayed rotation is continuous in
 * position AND speed. The start and end angles of every tick are unchanged, so nothing the game uses changes: attacks, ray casts, observations
 * and the policy all keep using the authoritative angles; only the view between ticks is smoother.
 *
 * Usage: push() once per tick after the rotation was applied; offset(t) is ADDED to vanilla's own interpolated angle (so yaw wrapping and
 * vanilla's yRotO bookkeeping stay as they are: offset(0) = offset(1) = 0). The mixin (EntityViewMixin) does that for the local player.
 * Pure Java, no allocation. Display only: when the AI is not driving the camera, active() is false and nothing changes.
 */
final class GlideCamera {
    private GlideCamera() {}

    private static volatile boolean enabled = true;
    private static boolean valid;
    private static double dYaw, v0Yaw, v1Yaw, dPitch, v0Pitch, v1Pitch;
    private static long lastPushNanos;

    // ---- REAL rotation mode (Config.GLIDE_REAL_ROTATION): the player's actual yRot/xRot follow the curve every FRAME, like a real mouse ----
    private static boolean realOn;
    private static double sYaw, sPitch, eYaw, ePitch;
    /**
     * Frame-rate independence: the curve is played over (almost) the whole MEASURED tick interval (not a fixed 42.5 ms), so it ends on the tick's angle just
     * before the next tick whatever the tick rate, and it is sampled where the frame will actually be SHOWN (half a measured frame time ahead of the frame
     * start). With 20-50 fps that removes the "snap at the end of the curve" and the half-frame lag that read as stutter.
     */
    private static double tickNanos = 50_000_000.0, frameNanos = 16_000_000.0;
    private static long lastFrameNanos;
    private static double realNanos() { return Math.max(40_000_000.0, Math.min(60_000_000.0, tickNanos * 0.97)); }

    /** The AI stopped / started: forget the motion so the first segment does not use stale velocities. */
    static synchronized void reset() { realOn = false; valid = false; dYaw = v0Yaw = v1Yaw = dPitch = v0Pitch = v1Pitch = 0; }

    /** Master switch (Config.GLIDE_CAMERA), also turned off by the mixin if anything ever goes wrong. */
    static void setEnabled(boolean on) { enabled = on; }

    static boolean active() { return enabled && Config.GLIDE_CAMERA && valid && System.nanoTime() - lastPushNanos < 200_000_000L; }

    /**
     * @param turnYaw,turnPitch degrees turned during this tick (the displacement vanilla will interpolate over the next 50 ms)
     * @param endVelYaw,endVelPitch the mouse's velocity at the end of the tick, deg/tick
     */
    static synchronized void push(double turnYaw, double endVelYaw, double turnPitch, double endVelPitch) {
        v0Yaw = valid ? v1Yaw : endVelYaw;       // the previous tick's end velocity = this tick's start velocity (no corner)
        v0Pitch = valid ? v1Pitch : endVelPitch;
        dYaw = turnYaw; v1Yaw = endVelYaw;
        dPitch = turnPitch; v1Pitch = endVelPitch;
        valid = Double.isFinite(turnYaw + endVelYaw + turnPitch + endVelPitch);
        long now = System.nanoTime();
        if (lastPushNanos != 0) { double dt = now - lastPushNanos; if (dt > 30_000_000.0 && dt < 100_000_000.0) tickNanos += 0.1 * (dt - tickNanos); }
        lastPushNanos = now;
    }

    /**
     * Real-rotation mode: call right after push(). The authoritative angles of the tick are start -> end (what GameplayRotation computed). From now
     * until the next tick the mixin sets the player's real yaw / pitch from frame() so they move along the Hermite curve; at the end they sit exactly
     * on end. Also used when the pitch was clamped (end already contains the clamp).
     */
    static synchronized void markReal(double startYaw, double startPitch, double endYaw, double endPitch) {
        if (!(enabled && Config.GLIDE_REAL_ROTATION) || !valid || !Double.isFinite(startYaw + startPitch + endYaw + endPitch)) { realOn = false; return; }
        sYaw = startYaw; sPitch = startPitch; eYaw = endYaw; ePitch = endPitch; realOn = true;
    }

    /** The previous segment has to be complete before the next tick reads the angles (also with catch-up ticks): returns false if nothing is pending. */
    static synchronized boolean finishReal(double[] out) {
        if (!realOn) return false;
        realOn = false;
        out[0] = eYaw; out[1] = ePitch;
        return true;
    }

    /**
     * Per-frame angles for the real rotation. @return false when nothing is to be written (inactive / done). out = {yaw, pitch} in degrees (yaw wrapped).
     * After the curve has finished the end angles are written once more and the mode switches itself off, so nothing else is fought with.
     */
    static synchronized boolean frame(double[] out) {
        if (!(enabled && Config.GLIDE_REAL_ROTATION) || !realOn) return false;
        long now = System.nanoTime();
        if (lastFrameNanos != 0) { double dt = now - lastFrameNanos; if (dt > 1_000_000.0 && dt < 100_000_000.0) frameNanos += 0.2 * (dt - frameNanos); }
        lastFrameNanos = now;
        double lead = Math.min(25_000_000.0, 0.5 * frameNanos); // the frame is shown about half a frame after it starts
        double t = (now + lead - lastPushNanos) / realNanos();
        if (!(t < 1.0)) { out[0] = eYaw; out[1] = ePitch; realOn = false; return true; }
        if (t < 0) t = 0;
        out[0] = wrap(sYaw + hermite(dYaw, v0Yaw, v1Yaw, t));
        out[1] = Math.max(-90.0, Math.min(90.0, sPitch + hermite(dPitch, v0Pitch, v1Pitch, t)));
        return true;
    }

    private static double wrap(double d) { d %= 360.0; if (d >= 180.0) d -= 360.0; if (d < -180.0) d += 360.0; return d; }

    /** Cubic Hermite position at t in [0,1] for a segment of displacement d from start velocity v0 to end velocity v1 (deg, deg/tick). */
    static double hermite(double d, double v0, double v1, double t) {
        double t2 = t * t, t3 = t2 * t;
        return (t3 - 2 * t2 + t) * v0 + (-2 * t3 + 3 * t2) * d + (t3 - t2) * v1;
    }

    /** Speed (deg/tick) of the Hermite curve at t in [0,1]: v0 at t=0, v1 at t=1 (derivative of hermite()). Used by the simulator's frame model. */
    static double hermiteSpeed(double d, double v0, double v1, double t) {
        double t2 = t * t;
        return (3 * t2 - 4 * t + 1) * v0 + (-6 * t2 + 6 * t) * d + (3 * t2 - 2 * t) * v1;
    }

    /** Yaw offset to add to vanilla's linearly interpolated yaw at partial tick t. */
    static synchronized double yawOffset(double t) { return valid ? hermite(dYaw, v0Yaw, v1Yaw, clamp01(t)) - clamp01(t) * dYaw : 0.0; }

    static synchronized double pitchOffset(double t) { return valid ? hermite(dPitch, v0Pitch, v1Pitch, clamp01(t)) - clamp01(t) * dPitch : 0.0; }

    private static double clamp01(double t) { return t < 0 ? 0 : (t > 1 ? 1 : t); }
}
