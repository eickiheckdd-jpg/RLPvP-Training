package com.rlpvp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Random;

/**
 * Online one-step world model. It predicts the next observed combat frame from the current observation
 * and an action. It never contains technique labels or a list of preferred moves: its targets are the
 * next frame actually observed in the environment.
 *
 * v6 (measured in sim/ConsequenceProbe): the network predicts the CHANGE of every feature, scaled by that feature's
 * running residual size, instead of the absolute next frame. Regressing the absolute frame made the rare, small health
 * changes (a hit is ~0.1-0.3 of the scale) disappear under the identity-mapping error of the network: its health
 * prediction was ~7x worse than "nothing changes" and identical with or without a swing. The gradient-norm clip is 5
 * (was 1) because clip 1 damped exactly the rare hit samples.
 *
 * The planner uses these predictions only after enough held-out transitions have been seen AND the model beats the
 * persistence baseline (next = current) on health. A low average error over all 48 features is not enough: most
 * features barely change, so the old MAE gate passed a model that was worse than persistence on damage.
 * Pure Java, no Minecraft dependencies.
 */
final class ConsequenceModel {
    private static final int INPUTS = Config.OBS_SIZE + PpoAgent.N_ACT;
    private static final int OUTPUTS = Config.FRAME;
    private static final int[] SIZES = {INPUTS, 128, 128, OUTPUTS};
    private static final int MIN_TRANSITIONS_FOR_PLANNING = 20_000;
    private static final int MIN_VALIDATION_SAMPLES = 1_000;
    /** The model must beat 'health unchanged' by at least this fraction of squared error on held-out transitions. */
    private static final double MIN_HEALTH_SKILL = 0.02;
    private static final double SKILL_EMA_ALPHA = 0.005;
    private static final float SCALE_FLOOR = 0.02f;
    private static final double SCALE_EMA_ALPHA = 0.001;
    private static final float MAX_VALIDATION_MAE = 0.20f;
    private static final float LEARNING_RATE = 4e-4f;
    private static final float MAX_GRAD_NORM = 5.0f;
    private static final double EMA_ALPHA = 0.01;

    private Net net;
    private final float[] residualVar = new float[OUTPUTS];
    private double seModel = Double.NaN, sePersist = Double.NaN;
    private final float[] input = new float[INPUTS];
    private final float[] gradient = new float[OUTPUTS];
    private final float[] prediction = new float[OUTPUTS];
    private long transitions;
    private long trainedTransitions;
    private long validationTransitions;
    private double validationMae;
    private boolean validationInitialised;

    private final Random initRng;

    ConsequenceModel(Random rng) {
        initRng = rng;
        net = new Net(SIZES, 0.08f, rng);
        java.util.Arrays.fill(residualVar, SCALE_FLOOR * SCALE_FLOOR);
    }

    /** Train the world model on every n-th transition (1 = every tick, the old behaviour). -Drlpvp.conseqEvery=N overrides. */
    static final int TRAIN_EVERY = Math.max(1, Integer.getInteger("rlpvp.conseqEvery", 3));

    private float scale(int i) { return (float) Math.max(SCALE_FLOOR, Math.sqrt(residualVar[i])); }

    /** Learns from the real consequence of the action that was taken. */
    void observe(float[] observation, float[] action, float[] nextObservation) {
        if (observation == null || action == null || nextObservation == null
                || observation.length < Config.OBS_SIZE || action.length < PpoAgent.N_ACT
                || nextObservation.length < Config.FRAME) return;
        pack(observation, action);
        transitions++;
        if (transitions % 10 != 0 && Config.CONSEQUENCE_TRAIN_EVERY > 1 && transitions % Config.CONSEQUENCE_TRAIN_EVERY != 0) return; // cheaper: train on every Nth transition
        float[] pred = net.forward(input);
        if (transitions % 10 == 0) { // held-out sample: scored, never trained on
            double mae = 0, sm = 0, sp = 0;
            for (int i = 0; i < OUTPUTS; i++) {
                float t = clampTarget(nextObservation[i], i);
                float p = clampTarget(observation[i] + scale(i) * pred[i], i);
                mae += Math.abs(p - t);
                if (i == 0 || i == 15) { // own / enemy health: what the planner's damage term is built from
                    sm += (p - t) * (double) (p - t);
                    sp += (observation[i] - t) * (double) (observation[i] - t);
                }
            }
            mae /= OUTPUTS;
            validationMae = validationInitialised ? (1.0 - EMA_ALPHA) * validationMae + EMA_ALPHA * mae : mae;
            seModel = Double.isNaN(seModel) ? sm : (1.0 - SKILL_EMA_ALPHA) * seModel + SKILL_EMA_ALPHA * sm;
            sePersist = Double.isNaN(sePersist) ? sp : (1.0 - SKILL_EMA_ALPHA) * sePersist + SKILL_EMA_ALPHA * sp;
            validationInitialised = true;
            validationTransitions++;
            return;
        }
        for (int i = 0; i < OUTPUTS; i++) {
            float r = clampTarget(nextObservation[i], i) - observation[i];
            residualVar[i] = (float) ((1.0 - SCALE_EMA_ALPHA) * residualVar[i] + SCALE_EMA_ALPHA * r * r);
            gradient[i] = 2f * (pred[i] - r / scale(i)) / OUTPUTS;
        }
        net.backward(gradient);
        net.step(LEARNING_RATE, MAX_GRAD_NORM, 1);
        trainedTransitions++;
    }

    /** Predicts the next 48-float frame. Output is bounded to valid observation ranges. */
    void predict(float[] observation, float[] action, float[] outFrame) {
        pack(observation, action);
        float[] raw = net.forward(input);
        for (int i = 0; i < OUTPUTS; i++) outFrame[i] = clampTarget(observation[i] + scale(i) * raw[i], i);
    }

    private void pack(float[] observation, float[] action) {
        System.arraycopy(observation, 0, input, 0, Config.OBS_SIZE);
        System.arraycopy(action, 0, input, Config.OBS_SIZE, PpoAgent.N_ACT);
    }

    private static float clampTarget(float value, int feature) {
        if (Float.isNaN(value) || Float.isInfinite(value)) return 0f;
        // Health, cooldowns, timers and boolean flags are non-negative fractions.
        switch (feature) {
            case 0: case 4: case 5: case 6: case 7: case 15: case 19: case 20: case 22: case 23:
            case 24: case 25: case 26: case 34: case 35: case 36: case 37: case 38: case 39:
            case 42: case 43: case 44: case 45: case 46: case 48: case 49: case 50: // 48-50: sneak features (0/1)
                return Math.max(0f, Math.min(1f, value));
            default:
                return Math.max(-1f, Math.min(1f, value));
        }
    }

    boolean planningReady() {
        return transitions >= MIN_TRANSITIONS_FOR_PLANNING
                && validationTransitions >= MIN_VALIDATION_SAMPLES
                && validationInitialised && validationMae <= MAX_VALIDATION_MAE
                && healthSkill() >= MIN_HEALTH_SKILL;
    }

    /** 1 - (model squared error / persistence squared error) on health, held-out. >0 means better than 'nothing changes'. */
    double healthSkill() {
        return Double.isNaN(seModel) || Double.isNaN(sePersist) || sePersist <= 1e-12 ? Double.NaN : 1.0 - seModel / sePersist;
    }

    long transitions() { return transitions; }
    long trainedTransitions() { return trainedTransitions; }
    long validationTransitions() { return validationTransitions; }
    double validationMae() { return validationInitialised ? validationMae : Double.NaN; }

    void write(DataOutputStream out) throws IOException {
        out.writeLong(transitions);
        out.writeLong(trainedTransitions);
        out.writeLong(validationTransitions);
        out.writeBoolean(validationInitialised);
        out.writeDouble(validationMae);
        out.writeDouble(seModel);
        out.writeDouble(sePersist);
        for (int i = 0; i < OUTPUTS; i++) out.writeFloat(residualVar[i]);
        net.write(out);
    }

    /**
     * Consumes and DISCARDS the consequence section of a save with the layout before sneak (inputs and frame size differ, so the old weights
     * cannot be used); the model stays fresh and re-learns online within minutes. Actor and critic are migrated, not discarded.
     */
    void readDiscardingOldLayout(DataInputStream in, int version, int oldInputs, int oldOutputs) throws IOException {
        in.readLong(); in.readLong(); in.readLong(); in.readBoolean(); in.readDouble();
        if (version >= 6) {
            in.readDouble(); in.readDouble();
            for (int i = 0; i < oldOutputs; i++) in.readFloat();
        }
        int[] old = SIZES.clone();
        old[0] = oldInputs;
        old[old.length - 1] = oldOutputs;
        new Net(old, 0.08f, new Random(0)).read(in);
    }

    /** Consumes and discards a consequence model whose observation input layout predates optional OBS_V2 features. */
    void readDiscardingOldInputLayout(DataInputStream in, int version, int oldObsSize) throws IOException {
        in.readLong(); in.readLong(); in.readLong(); in.readBoolean(); in.readDouble();
        if (version >= 6) {
            in.readDouble(); in.readDouble();
            for (int i = 0; i < OUTPUTS; i++) in.readFloat();
        }
        int[] old = SIZES.clone(); old[0] = oldObsSize + PpoAgent.N_ACT;
        new Net(old, 0.08f, new Random(0)).read(in);
        // Keep the newly constructed model untrained; its input layout differs and its validation statistics are no longer comparable.
    }

    /** Reads the current layout (state v6 and v7 store the same section). */
    void read(DataInputStream in) throws IOException { read(in, 7); }

    /**
     * State v5 stored an absolute-target network whose weights mean something different now. Its statistics and weights are
     * read (to keep the stream aligned) and DISCARDED: the model restarts untrained and re-learns online within minutes.
     * The actor and critic are not affected.
     */
    void read(DataInputStream in, int version) throws IOException {
        long tr = in.readLong(), trained = in.readLong(), val = in.readLong();
        boolean init = in.readBoolean();
        double mae = in.readDouble();
        if (tr < 0 || trained < 0 || val < 0 || (init && (Double.isNaN(mae) || Double.isInfinite(mae) || mae < 0)))
            throw new IOException("invalid consequence-model statistics");
        if (version >= 6) {
            transitions = tr; trainedTransitions = trained; validationTransitions = val; validationInitialised = init; validationMae = mae;
            seModel = in.readDouble();
            sePersist = in.readDouble();
            for (int i = 0; i < OUTPUTS; i++) {
                residualVar[i] = in.readFloat();
                if (Float.isNaN(residualVar[i]) || residualVar[i] < 0f) throw new IOException("invalid consequence-model scale");
            }
            net.read(in);
        } else {
            net.read(in);                                   // consume the old weights
            net = new Net(SIZES, 0.08f, initRng);           // ...and start from a clean, untrained model
        }
    }
}
