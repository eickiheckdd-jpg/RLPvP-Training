package com.rlpvp;

import java.util.Arrays;
import java.util.Locale;

/**
 * Situational technique DISCOVERY bonuses (Config.TECH_DISCOVERY). Pure Java, shared by Trainer and PvpSim.
 *
 * Win / loss and damage stay the primary signals (Reward.tick / Reward.terminal). This class only adds small, temporary hints
 * that help the agent DISCOVER techniques; whether a technique is worth using is left to the outcome:
 *  - Every hit-based bonus needs a REAL, credited damaging hit, at most one event per landed swing (caller passes newHit), and at
 *    least TECH_MIN_EVENT_GAP_TICKS between events (vanilla hurt-invulnerability): no fake hits, no duplicate health updates.
 *  - EXCHANGE SETTLEMENT: a technique bonus is not paid when the hit lands. It is held for TECH_EXCHANGE_TICKS and paid only if the
 *    exchange was WON (HP dealt - HP taken since the hit > 0). A crit that gets traded back, or a sprint hit that walks into a combo,
 *    earns nothing. So the bonus is situational: it pays where the technique actually helped.
 *  - Diminishing returns per technique within an episode (1 / (1 + n)) and a hard per-episode cap (TECH_EPISODE_CAP).
 *  - Annealing: the bonus scale fades on a cosine from 1 to TECH_FLOOR over TECH_ANNEAL_TICKS of technique-stage training
 *    (PpoAgent.techTicks, saved), so guidance shrinks gradually instead of disappearing at once.
 *  - Penalties are NOT annealed: the existing pointless-whiff penalty (Reward.techBonus) is untouched, and a repeated miss within
 *    WHIFF_STREAK_WINDOW ticks adds WHIFF_STREAK_PENALTY.
 * Window statistics (events, exchanges won / lost per technique, bonus paid, duplicates, cap hits) are logged by the callers.
 */
final class TechniqueDiscovery {
    static final int CRIT = 0, SPRINT_HIT = 1, KB_FOLLOWUP = 2, COMBO = 3, FIRST_HIT = 4, PUNISH = 5, DODGE = 6, WTAP = 7, DENY = 8, N = 9;
    static final String[] NAMES = {"crit", "sprintHit", "kbFollowup", "combo", "firstHit", "punish", "dodge", "wtap", "deny"};
    private static final int MAX_PENDING = 4;
    private static final int FAR_PAST = -1_000_000;

    /** Per-tick input, filled by the caller from data it already computes. */
    static final class In {
        double techW;            // curriculum technique weight (0 = technique stages not reached)
        long techTicks;          // annealing clock (PpoAgent.techTicks)
        int tick;                // tick in episode
        float realDealt, taken;  // real credited damage dealt / damage taken this tick
        boolean newHit;          // first real damage credited to the latest landed swing
        boolean hitCrit, hitSprint, hitPunish; // state of the swing that landed (HitMemory type mask / punish window)
        double hitEnemyCharge;   // estimated enemy weapon charge when that swing was made (frame[42])
        boolean oppSwingStart, inTheirReach;
        double enemyFacing, mySpeed; // frame[21]; my horizontal speed in blocks/tick
        boolean mySprinting;     // my sprint flag now (frame[5]); a w-tap is a CLEAN drop and re-sprint between two sprint hits
        double dist;             // distance to the enemy (blocks); tells a knockback follow-up (enemy was pushed away, I closed in) from a hit that never separated
    }

    // episode state
    private int lastEventTick, lastSprintHitTick, lastWhiffTick, combo, dodgeTimer;
    private boolean firstHitDone, tookSinceSprintHit;
    private final int[] epCount = new int[N];
    private double epPaid;
    private final boolean[] pActive = new boolean[MAX_PENDING];
    private final double[][] pAmt = new double[MAX_PENDING][N];
    private final int[] pFlags = new int[MAX_PENDING];
    private final int[] pLeft = new int[MAX_PENDING];
    private final double[] pNet = new double[MAX_PENDING];
    private final double[] pTaken = new double[MAX_PENDING];
    private final int[] pDenied = new int[MAX_PENDING];
    private int dropRun, maxDrop;   // current / longest run of ticks without sprint since my last sprint hit

    // sprint-hit chain tracking (measurement; the only thing it feeds back is the pursuit multiplier of KB_FOLLOWUP)
    private boolean sprintPending, pendingConverted, chainActive;
    private int pendingTick, chainHits, chainLastTick;
    private double pendingDist, pendingMaxDist;
    private long wSprintHits, wConverted, wChains, wChainHitsSum, wChainMax, wInterrupted, wTimedOut, wPursuit, wUnresolved;

    // window statistics
    private final long[] wEvents = new long[N], wWon = new long[N], wLost = new long[N];
    private final double[] wPaid = new double[N];
    private long wDuplicates, wCapped;
    private double wForfeited, wWhiffPenalty;
    private double lastScale = 1.0;

    TechniqueDiscovery() { reset(); }

    /** New episode. Window statistics are kept. */
    void reset() {
        lastEventTick = lastSprintHitTick = lastWhiffTick = FAR_PAST;
        combo = 0; dodgeTimer = 0;
        firstHitDone = false; tookSinceSprintHit = true;
        Arrays.fill(epCount, 0);
        epPaid = 0;
        Arrays.fill(pActive, false);
        dropRun = maxDrop = 0;
        closeChain(0);
    }

    /** Bonus scale from the annealing clock: cosine from 1 down to TECH_FLOOR, then held at the floor. */
    static double anneal(long techTicks) {
        double floor = Math.max(0.0, Math.min(1.0, Config.TECH_FLOOR));
        if (Config.TECH_ANNEAL_TICKS <= 0 || techTicks >= Config.TECH_ANNEAL_TICKS) return floor;
        double x = Math.max(0L, techTicks) / (double) Config.TECH_ANNEAL_TICKS;
        return floor + (1.0 - floor) * 0.5 * (1.0 + Math.cos(Math.PI * x));
    }

    /** Call once per training tick. @return discovery reward to add this tick (already weighted, unscaled like Reward.tick). */
    double tick(In s) {
        double r = 0;
        boolean pursuit = chainStep(s);
        for (int p = 0; p < MAX_PENDING; p++) {          // 1. running exchanges
            if (!pActive[p]) continue;
            pNet[p] += s.realDealt - s.taken;
            pTaken[p] += s.taken;
            if (s.oppSwingStart && !s.inTheirReach) pDenied[p]++;   // it tried to hit me and could not reach
            if (--pLeft[p] <= 0) r += settle(p);
        }
        if (s.taken > 0f) { combo = 0; firstHitDone = true; tookSinceSprintHit = true; }
        if (s.mySprinting) dropRun = 0; else { dropRun++; maxDrop = Math.max(maxDrop, dropRun); }
        lastScale = anneal(s.techTicks);
        boolean on = Config.TECH_DISCOVERY && s.techW > 0;
        double scale = on ? lastScale * s.techW : 0.0;

        // 2. defensive movement: the enemy swung at me while I was in its reach and moving, and nothing landed
        if (dodgeTimer > 0) {
            if (s.taken > 0f) { dodgeTimer = 0; wLost[DODGE]++; }
            else if (--dodgeTimer == 0) {
                wWon[DODGE]++;
                double a = capped(Config.TECH_DODGE * scale / (1 + epCount[DODGE]));
                wPaid[DODGE] += a; r += a; epCount[DODGE]++;
            }
        } else if (Config.TECH_DISCOVERY && s.techW > 0 && s.taken <= 0f && s.oppSwingStart
                && s.inTheirReach && s.enemyFacing >= Config.TECH_DODGE_MIN_FACING
                && s.mySpeed >= Config.TECH_DODGE_MIN_SPEED && epCount[DODGE] < Config.TECH_DODGE_CAP) {
            dodgeTimer = Config.TECH_DODGE_WINDOW;
            wEvents[DODGE]++;
        }

        // 3. a new real hit: tag which techniques it used and open an exchange
        if (s.newHit) {
            combo++;
            boolean first = !firstHitDone;
            firstHitDone = true;
            int sinceSprint = s.tick - lastSprintHitTick;
            boolean followup = !tookSinceSprintHit && sinceSprint >= Config.TECH_FOLLOWUP_MIN_TICKS && sinceSprint <= Config.TECH_FOLLOWUP_MAX_TICKS;
            if (s.tick - lastEventTick < Config.TECH_MIN_EVENT_GAP_TICKS) {
                wDuplicates++;
            } else {
                int slot = -1, oldest = 0;
                for (int p = 0; p < MAX_PENDING; p++) {
                    if (!pActive[p]) { slot = p; break; }
                    if (pLeft[p] < pLeft[oldest]) oldest = p;
                }
                if (slot < 0) { r += settle(oldest); slot = oldest; }
                double[] amt = pAmt[slot];
                Arrays.fill(amt, 0.0);
                int flags = 0;
                if (s.hitCrit) flags |= note(CRIT, Config.TECH_CRIT, scale, amt);
                if (s.hitSprint) flags |= note(SPRINT_HIT, Config.TECH_SPRINT_HIT, scale, amt);
                if (followup) flags |= note(KB_FOLLOWUP, Config.TECH_KB_FOLLOWUP * (pursuit ? Config.TECH_PURSUIT_MULT : 1.0), scale, amt);
                if (combo >= 2) flags |= note(COMBO, Config.TECH_COMBO * Math.min(combo - 1, 3), scale, amt);
                if (combo >= 2) flags |= note(DENY, Config.TECH_DENY * Math.min(combo - 1, 3), scale, amt);
                if (s.hitSprint && followup && maxDrop >= 1 && maxDrop <= Config.TECH_WTAP_MAX_DROP) flags |= note(WTAP, Config.TECH_WTAP, scale, amt);
                if (first) flags |= note(FIRST_HIT, Config.TECH_FIRST_HIT, scale, amt);
                if (s.hitPunish && s.hitEnemyCharge <= Config.TECH_PUNISH_MAX_ENEMY_CHARGE) flags |= note(PUNISH, Config.TECH_PUNISH, scale, amt);
                if (flags != 0) {
                    pActive[slot] = true; pFlags[slot] = flags;
                    pLeft[slot] = Math.max(1, Config.TECH_EXCHANGE_TICKS);
                    pNet[slot] = s.realDealt - s.taken;
                    pTaken[slot] = s.taken; pDenied[slot] = 0;
                }
            }
            lastEventTick = s.tick;
            if (s.hitSprint) { lastSprintHitTick = s.tick; tookSinceSprintHit = false; maxDrop = dropRun = 0; }
        }
        return r;
    }

    /**
     * Chain metrics. A chain starts at a sprint hit and goes on while I keep landing hits without taking damage, each within
     * TECH_FOLLOWUP_MAX_TICKS of the previous one. A sprint hit is "converted" when a further real hit follows it inside that window
     * with nothing taken in between. A converted hit where the enemy was knocked apart (distance grew by TECH_PURSUIT_MIN_GAP) and I
     * closed in again is a pursuit follow-up. @return true if this tick's hit is such a pursuit follow-up.
     */
    private boolean chainStep(In s) {
        boolean pursuit = false;
        if (sprintPending) pendingMaxDist = Math.max(pendingMaxDist, s.dist);
        if (chainActive && s.taken > 0f) { wInterrupted++; resolvePending(false); closeChain(0); }
        else if (chainActive && s.tick - chainLastTick > Config.TECH_FOLLOWUP_MAX_TICKS) { wTimedOut++; resolvePending(false); closeChain(0); }
        if (s.newHit) {
            if (chainActive) {
                chainHits++; chainLastTick = s.tick;
                if (sprintPending && !pendingConverted) {
                    pendingConverted = true; wConverted++;
                    if (pendingMaxDist - pendingDist >= Config.TECH_PURSUIT_MIN_GAP && s.tick - pendingTick >= Config.TECH_FOLLOWUP_MIN_TICKS) { wPursuit++; pursuit = true; }
                }
            }
            if (s.hitSprint) {
                wSprintHits++;
                if (!chainActive) { chainActive = true; chainHits = 1; }
                sprintPending = true; pendingConverted = false; pendingTick = s.tick; pendingDist = s.dist; pendingMaxDist = s.dist; chainLastTick = s.tick;
            } else if (!chainActive) { /* an isolated normal hit: no chain */ }
        }
        return pursuit;
    }

    private void resolvePending(boolean ended) { sprintPending = false; }

    private void closeChain(int unused) {
        if (chainActive) {
            if (sprintPending && !pendingConverted) wUnresolved++;
            if (chainHits >= 2) { wChains++; wChainHitsSum += chainHits; wChainMax = Math.max(wChainMax, chainHits); }
        }
        chainActive = false; sprintPending = false; chainHits = 0;
    }

    /** Fraction of sprint hits that were followed by at least one more successful hit (no damage taken in between). NaN without sprint hits. */
    double comboConversion() { return wSprintHits == 0 ? Double.NaN : wConverted / (double) wSprintHits; }

    private int note(int t, double base, double scale, double[] amt) {
        wEvents[t]++;
        amt[t] = base * scale / (1 + epCount[t]);
        epCount[t]++;
        return 1 << t;
    }

    private double settle(int p) {
        pActive[p] = false;
        boolean won = pNet[p] > 0;
        double paid = 0;
        for (int t = 0; t < N; t++) {
            if ((pFlags[p] & (1 << t)) == 0) continue;
            boolean ok = won && (t != DENY || pTaken[p] <= 0.0);   // denial only pays if the enemy got nothing in
            if (ok) {
                double base = pAmt[p][t] * (t == DENY ? 1.0 + 0.5 * Math.min(pDenied[p], 2) : 1.0);
                wWon[t]++; double a = capped(base); wPaid[t] += a; paid += a;
            } else { wLost[t]++; wForfeited += pAmt[p][t]; }
        }
        return paid;
    }

    private double capped(double a) {
        if (a <= 0) return 0;
        double x = Math.min(a, Math.max(0.0, Config.TECH_EPISODE_CAP - epPaid));
        if (x < a) wCapped++;
        epPaid += x;
        return x;
    }

    /** Episode end: open exchanges are settled with the result so far. @return reward to add to the final transition. */
    double endEpisode() {
        double r = 0;
        for (int p = 0; p < MAX_PENDING; p++) if (pActive[p]) r += settle(p);
        dodgeTimer = 0;
        closeChain(0);
        return r;
    }

    /** Call when I swing. A miss shortly after another miss costs (not annealed). A landed swing clears the streak. */
    double onSwing(boolean landed, int tick, double techW) {
        if (!Config.TECH_DISCOVERY) return 0.0;
        if (landed) { lastWhiffTick = FAR_PAST; return 0.0; }
        double r = tick - lastWhiffTick <= Config.WHIFF_STREAK_WINDOW ? -Config.WHIFF_STREAK_PENALTY * Math.max(0.0, techW) : 0.0;
        lastWhiffTick = tick;
        wWhiffPenalty += r;
        return r;
    }

    double scale() { return lastScale; }

    /** One-line window summary: technique won/settled exchanges and bonus paid. */
    String summary() {
        StringBuilder sb = new StringBuilder(String.format(Locale.ROOT, "tech x%.2f", lastScale));
        for (int t = 0; t < N; t++) {
            if (wEvents[t] == 0) continue;
            sb.append(' ').append(NAMES[t]).append(' ').append(wWon[t]).append('/').append(wWon[t] + wLost[t])
              .append(String.format(Locale.ROOT, " +%.2f", wPaid[t]));
        }
        if (wSprintHits > 0) sb.append(String.format(Locale.ROOT, " | combo-conv %.0f%% (%d/%d sprint hits) chains %d avgLen %.1f max %d interrupted %d timeout %d pursuit %d",
            100.0 * wConverted / wSprintHits, wConverted, wSprintHits, wChains, wChains == 0 ? 0.0 : wChainHitsSum / (double) wChains, wChainMax, wInterrupted, wTimedOut, wPursuit));
        if (wDuplicates > 0) sb.append(" dup ").append(wDuplicates);
        if (wCapped > 0) sb.append(" capped ").append(wCapped);
        if (wWhiffPenalty != 0) sb.append(String.format(Locale.ROOT, " whiffStreak %.2f", wWhiffPenalty));
        return sb.toString();
    }

    static String csvHeader() {
        StringBuilder sb = new StringBuilder("ticks,stage,scale");
        for (String n : NAMES) sb.append(',').append(n).append("_events,").append(n).append("_won,").append(n).append("_lost,").append(n).append("_paid");
        return sb.append(",duplicates,capped,forfeited,whiffStreakPenalty,sprintHits,converted,comboConversion,chains,avgChainLen,maxChain,interrupted,timedOut,pursuit").toString();
    }

    String csvRow(long ticks, int stage) {
        StringBuilder sb = new StringBuilder(String.format(Locale.ROOT, "%d,%d,%.4f", ticks, stage, lastScale));
        for (int t = 0; t < N; t++) sb.append(String.format(Locale.ROOT, ",%d,%d,%d,%.4f", wEvents[t], wWon[t], wLost[t], wPaid[t]));
        sb.append(String.format(Locale.ROOT, ",%d,%d,%.4f,%.4f", wDuplicates, wCapped, wForfeited, wWhiffPenalty));
        return sb.append(String.format(Locale.ROOT, ",%d,%d,%.4f,%d,%.3f,%d,%d,%d,%d", wSprintHits, wConverted, wSprintHits == 0 ? 0.0 : wConverted / (double) wSprintHits,
            wChains, wChains == 0 ? 0.0 : wChainHitsSum / (double) wChains, wChainMax, wInterrupted, wTimedOut, wPursuit)).toString();
    }

    void clearWindow() {
        Arrays.fill(wEvents, 0); Arrays.fill(wWon, 0); Arrays.fill(wLost, 0); Arrays.fill(wPaid, 0);
        wDuplicates = wCapped = 0; wForfeited = wWhiffPenalty = 0;
        wSprintHits = wConverted = wChains = wChainHitsSum = wChainMax = wInterrupted = wTimedOut = wPursuit = wUnresolved = 0;
    }
}
