package com.rlpvp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Runs on the client thread, once per client tick (20 per second): observe, reward, act, and one
 * PPO gradient step (PpoAgent.learnTick). It learns continuously while you play; there are no
 * generations or population.
 *
 * The agent is YOUR local player. The opponent is any other player entity near you (a practice
 * bot on the server). Nothing is teleported or reset: an episode simply runs for a fixed number
 * of ticks, or ends early when someone dies or the opponent goes away. The next episode starts
 * as soon as an opponent is in range again.
 *
 * An 8-stage curriculum (Curriculum) changes the opponent, the reward weights and TEMPORARY action
 * locks (ActionMask) as the agent learns. In singleplayer the Carpet bot is placed and driven by
 * BotBrain; the learning agent's own camera and actions are never forced.
 */
final class Trainer {
    enum Mode { OFF, TRAIN, PLAY }

    static final Logger LOG = LoggerFactory.getLogger("rlpvp");

    /** null = pick the nearest other player automatically. */
    volatile String targetName = null;

    private Mode mode = Mode.OFF;
    private boolean inEpisode = false;
    private int respawnCooldown = 0;

    private PpoAgent agent;
    private long lastSaveTicks = 0;

    // curriculum, opponent control, HUD
    final Curriculum curriculum = new Curriculum();
    final BotBrain bots = new BotBrain();
    private final Random rng = new Random();
    private final SpamGuard spam = new SpamGuard();
    private final SpamGuard.In spamIn = new SpamGuard.In();
    private boolean prevJump, prevSneak;
    private final RollingStats stats = new RollingStats(10);
    private double entropyEma = 0;
    private final TechniqueReward techR = new TechniqueReward();
    private final TechniqueReward.In techIn = new TechniqueReward.In();
    private final CameraReward cam = new CameraReward();
    private final TechniqueDiscovery disc = new TechniqueDiscovery();
    private final TechniqueDiscovery.In discIn = new TechniqueDiscovery.In();
    private final JumpReset jr = new JumpReset();
    private final JumpReset.In jrIn = new JumpReset.In();
    private boolean hitConsumed = true;      // the latest landed swing has already produced its technique event
    private float lastHitEnemyCharge = 1f;   // enemy charge estimate (frame[42]) when that swing was made
    /** Entropy floor for the CURRENT locks (read by the HUD). */
    static volatile double entropyFloorNow = 0.3;
    private int epAim;               // ticks this episode spent on target (aim gate for stages 1-4)
    private double winLook;          // sum of |yaw delta| in degrees (diagnostic: how fast the camera turns)
    private int winLookN;
    private long lastSnapshotTicks = Long.MIN_VALUE / 2;
    /** Stage 8 league: frozen past versions of the agent. */
    private final ArrayList<FrozenPolicy> pool = new ArrayList<>();

    // collapse guard (best-checkpoint rollback)
    private CollapseGuard guard = new CollapseGuard();
    private final BotDifficulty botDiff = new BotDifficulty(); // adaptive strength of the AGGRESSIVE / STRONG bots
    private boolean benchmarkEpisode = true; // false while fighting a frozen self-play snapshot (its strength drifts)
    private boolean reviewEpisode; // captured per episode; shared Curriculum.lastReview is unsafe with concurrent simulators

    // technique bookkeeping
    private final float[] lastActEnc = new float[7];
    private boolean lastOppSwinging;
    private int sinceOppSwing = 40;
    private int combo;
    private boolean firstHitDone;
    private boolean lastHitCrit;
    private boolean lastHitSprint;
    private boolean lastHitFull;       // the last real-hit swing was made with a fully charged weapon
    private int lastHitGap = 99;       // ticks between that swing and my swing before it
    private boolean lastHitPunish;     // that swing came shortly after the enemy's swing
    private int sinceMySwing = 40;
    /** 4.8 s of fight history as summary inputs (last hit sizes / types, rolling counts); see HitMemory. */
    private final HitMemory mem = new HitMemory();
    private final MotionMemory motion = new MotionMemory();
    private final SprintHitFollowupMemory sprintFollowup = new SprintHitFollowupMemory();
    private final OpponentMemory oppMem = new OpponentMemory();
    private final float[] summary = new float[Config.SUMMARY];
    private int prevOppHitMask;        // how the enemy could hit me: crit / sprint state it was in last tick
    private double pendingTech;   // whiff penalty from last tick's swing, paid next tick
    private int winSwings, winWhiffs, winHits, winCrits, winSprintHits;
    private int winSprintFollowupOpps, winSprintFollowups, winSprintFollowupExpired, winSprintFollowupTicks;
    private boolean warnedNoServer = false;
    private int hudTimer = 0;
    private volatile RlHud.Data hud = RlHud.Data.OFF;

    // rolling statistics, printed every Config.STATS_EVERY_EPISODES episodes
    private double winDealt;
    private double winTaken;
    private double winReturn;
    private int winEpisodes;
    private int winWins;
    private int winLosses;
    private int winDraws;
    private int winNoContest;
    private String lastStats = "no episodes finished yet";

    // episode state
    private AbstractClientPlayer target;       // sticky opponent choice
    private AbstractClientPlayer episodeTarget;
    private int tickInEpisode;
    private double epFitness;
    private double epDealt;
    private double epTaken;
    private Vec3 prevMyPos;
    private Vec3 prevOppPos;
    private float prevMyHp;
    private float prevOppHp;
    private int sinceDealt;
    private int sinceTaken;
    private int lastHitTick;
    private double prevDist;
    private int sinceReal;         // ticks since my last REAL hit (anti-stalling)
    private float epSoft;          // soft credit paid this episode (capped)
    private float[] lastFrame;     // newest observation frame, read by the HUD
    private int epCount;
    private double lastWhiff, lastCrit, lastSprint; // newest window, for the HUD
    private String lastResult = "";
    private final float[] retHist = new float[40];
    private final byte[] resHist = new byte[20];
    private final float[] entHist = new float[40];
    private int retN, resN, entN;
    private float pendingSoft;   // soft hit credit from last tick's near-miss swing, paid out next tick
    private int warmup;          // ticks to wait after the bot was placed

    private final ObsStack obs = new ObsStack();
    private final ActionApplier act = new ActionApplier();

    // ------------------------------------------------------------ paths
    private static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("rlpvp");
    }

    private static Path stateFile() {
        return dir().resolve("state.bin");
    }

    private static Path logFile() {
        return dir().resolve("log2.csv");
    }

    // ------------------------------------------------------------ messages
    /** Prints a client-only chat line (nobody else on the server sees it) and logs it. */
    static void say(String msg) {
        LOG.info("rlpvp: {}", msg);
        LocalPlayer p = Minecraft.getInstance().player;
        if (p != null) p.displayClientMessage(Component.literal("[rl] " + msg), false);
    }

    // ------------------------------------------------------------ commands API
    String start(boolean fresh) {
        if (fresh || agent == null) {
            if (!fresh && Files.exists(stateFile())) {
                try {
                    agent = PpoAgent.load(stateFile(), System.nanoTime());
                } catch (IOException e) {
                    return "Could not load saved state: " + e.getMessage();
                }
            } else {
                agent = new PpoAgent(System.nanoTime());
            }
        }
        beginMode(Mode.TRAIN);
        resetStats();
        lastSaveTicks = agent.totalTicks;
        return "PPO training started (" + agent.totalTicks + " ticks learned so far). It learns every tick; "
            + "the first episode starts when an opponent is in range.";
    }

    String play() {
        if (agent == null && Files.exists(stateFile())) {
            try {
                agent = PpoAgent.load(stateFile(), System.nanoTime());
            } catch (IOException e) {
                return "Could not load saved state: " + e.getMessage();
            }
        }
        if (agent == null) return "Nothing trained yet. Run /rl start first.";
        beginMode(Mode.PLAY);
        return "Playing the current policy greedily (no learning, nothing saved).";
    }

    private void beginMode(Mode m) {
        act.release(Minecraft.getInstance());
        if (agent != null) agent.discardPending();
        mode = m;
        curriculum.restart();
        if (agent != null) curriculum.restore(agent.stage, agent.stageEnterTicks);
        guard = new CollapseGuard();
        bots.active = false;
        stats.clear();
        entropyEma = 0;
        warnedNoServer = false;
        hudTimer = 0;
        inEpisode = false;
        target = null;
        episodeTarget = null;
    }

    String stop() {
        boolean wasRunning = mode != Mode.OFF;
        if (agent != null) agent.discardPending();
        mode = Mode.OFF;
        bots.active = false;
        hud = RlHud.Data.OFF;
        inEpisode = false;
        target = null;
        episodeTarget = null;
        act.release(Minecraft.getInstance());
        return wasRunning ? "Stopped. " + save() : "Not running.";
    }

    String save() {
        if (agent == null) return "Nothing to save.";
        try {
            agent.save(stateFile());
            return "Saved (" + agent.totalTicks + " ticks learned) to " + stateFile();
        } catch (IOException e) {
            return "Save failed: " + e.getMessage();
        }
    }

    String load() {
        try {
            agent = PpoAgent.load(stateFile(), System.nanoTime());
            return "Loaded (" + agent.totalTicks + " ticks learned). Use /rl start or /rl play.";
        } catch (IOException e) {
            return "Load failed: " + e.getMessage();
        }
    }

    String status() {
        StringBuilder sb = new StringBuilder();
        sb.append("mode=").append(mode);
        sb.append(", opponent=").append(targetName == null ? "auto (nearest player)" : targetName);
        if (inEpisode && episodeTarget != null) {
            sb.append(" (fighting ").append(episodeTarget.getScoreboardName()).append(")");
        }
        if (agent != null) {
            sb.append("\nlearned ticks ").append(agent.totalTicks)
              .append(", finished updates ").append(agent.updates)
              .append(", cut short ").append(agent.skipped)
              .append(", shaping ").append(String.format(Locale.ROOT, "%.2f", Reward.shaping(agent.totalTicks)))
              .append("\nconsequence model: ").append(agent.consequenceStatus());
            sb.append("\ntechnique discovery: ").append(Config.TECH_DISCOVERY
                ? String.format(Locale.ROOT, "on, bonus scale %.2f (%d technique ticks)", TechniqueDiscovery.anneal(agent.techTicks), agent.techTicks)
                : "off");
        }
        sb.append("\ncurriculum: ").append(curriculum.describe())
          .append(", bot control ").append(bots.active ? "active" : "idle");
        sb.append("\nlast: ").append(lastStats);
        return sb.toString();
    }

    void saveNow() {
        if (agent != null) save();
    }

    // ------------------------------------------------------------ main tick
    void tick(Minecraft mc) {
        if (mode == Mode.OFF) return;
        // learn on every tick, even between episodes or while a menu is open
        if (mode == Mode.TRAIN && agent != null) agent.learnTick();
        syncCurriculum();
        if (++hudTimer >= Config.HUD_EVERY_TICKS) {
            hudTimer = 0;
            hud = buildHud();
        }

        LocalPlayer me = mc.player;
        if (me == null || mc.level == null) {
            inEpisode = false;
            episodeTarget = null;
            return;
        }

        // ---- death / respawn ----
        boolean dead = me.isDeadOrDying() || mc.screen instanceof DeathScreen;
        if (dead) {
            if (inEpisode) {
                AbstractClientPlayer o = episodeTarget;
                boolean oppDead = o != null && (o.getHealth() <= 0f || o.isDeadOrDying());
                boolean credited = oppDead && tickInEpisode >= lastHitTick && tickInEpisode - lastHitTick <= Config.HIT_CREDIT_TICKS;
                endEpisode(mc, EpisodeOutcome.classify(true, oppDead, credited, false), null);
            }
            act.release(mc);
            if (Config.AUTO_RESPAWN && --respawnCooldown <= 0) {
                me.respawn();
                respawnCooldown = 10;
            }
            return;
        }
        respawnCooldown = 0;

        // ---- never fight while a menu / chat / inventory is open ----
        if (mc.screen != null) {
            act.release(mc);
            return;
        }

        if (inEpisode) {
            AbstractClientPlayer opp = episodeTarget;
            if (opp == null || opp.isRemoved() || opp.isSpectator()
                    || me.distanceTo(opp) > Config.TARGET_LOSE_RANGE) {
                // Carpet removes dead bots quickly. A removed entity with zero health is a death; otherwise this is an abort/no-contest.
                boolean died = opp != null && (opp.getHealth() <= 0f || opp.isDeadOrDying());
                boolean credited = died && tickInEpisode >= lastHitTick && tickInEpisode - lastHitTick <= Config.HIT_CREDIT_TICKS;
                if (died && credited) {
                    // The finishing health drop may not have been observed by step() before the entity was removed.
                    double finishingDamage = Math.max(0.0, prevOppHp);
                    epDealt += finishingDamage;
                    if (mode == Mode.TRAIN && finishingDamage > 0) {
                        double r = finishingDamage / 20.0 * Config.W_DAMAGE;
                        agent.addReward(r);
                        epFitness += r;
                    }
                }
                endEpisode(mc, died ? EpisodeOutcome.classify(false, true, credited, false) : EpisodeOutcome.ABORTED, null);
                return;
            }
            step(mc, me, opp);
            return;
        }

        AbstractClientPlayer opp = findTarget(mc, me);
        if (opp == null) {
            act.release(mc);
            return;
        }
        startEpisode(mc, me, opp);
    }

    /** Sticky opponent choice: keep the current one while valid, else take the nearest player. */
    private AbstractClientPlayer findTarget(Minecraft mc, LocalPlayer me) {
        if (target != null && valid(me, target, Config.TARGET_LOSE_RANGE)) return target;
        AbstractClientPlayer best = null;
        double bestDist = Double.MAX_VALUE;
        for (AbstractClientPlayer p : mc.level.players()) {
            if (!valid(me, p, Config.TARGET_RANGE)) continue;
            double d = me.distanceTo(p);
            if (d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        target = best;
        return best;
    }

    private boolean valid(LocalPlayer me, AbstractClientPlayer p, double range) {
        if (p == me || p.isRemoved() || !p.isAlive() || p.isDeadOrDying() || p.isSpectator()) return false;
        String want = targetName;
        if (want != null && !p.getScoreboardName().equalsIgnoreCase(want)) return false;
        return me.distanceTo(p) <= range;
    }

    private void step(Minecraft mc, LocalPlayer me, AbstractClientPlayer opp) {
        if (warmup > 0) { // the bot was just placed; wait until its new position has reached the client
            warmup--;
            act.release(mc);
            if (warmup == 0) rebaseline(me, opp);
            return;
        }
        tickInEpisode++;
        sinceMySwing = Math.min(sinceMySwing + 1, 40);

        Vec3 myPos = me.position();
        Vec3 oppPos = opp.position();
        Vec3 myVel = myPos.subtract(prevMyPos);
        Vec3 oppVel = oppPos.subtract(prevOppPos);
        float myHp = me.getHealth();
        float oppHp = opp.getHealth();
        float myHpC = Math.max(0f, myHp), oppHpC = Math.max(0f, oppHp); // overkill is not real HP damage

        // Damage to the opponent only counts if I swung at it a moment ago.
        boolean credited = tickInEpisode - lastHitTick <= Config.HIT_CREDIT_TICKS;
        float realDealt = credited ? Math.max(0f, prevOppHp - oppHpC) : 0f;
        // Full reward for a real crosshair hit; a near-miss swing with decent aim earns a fraction of one.
        float dealt = realDealt + pendingSoft;
        pendingSoft = 0f;
        float taken = Math.max(0f, prevMyHp - myHpC);
        prevMyPos = myPos;
        prevOppPos = oppPos;
        prevMyHp = myHpC;
        prevOppHp = oppHpC;
        sinceDealt = realDealt > 0 ? 0 : Math.min(sinceDealt + 1, 40); // the observation only counts real hits
        sinceTaken = taken > 0 ? 0 : Math.min(sinceTaken + 1, 40);
        sinceReal = realDealt > 0 ? 0 : sinceReal + 1;
        epDealt += realDealt; // metric / guard sees actual HP damage, not soft hit credit
        epTaken += taken;
        boolean newHitEvent = realDealt > 0 && !hitConsumed; // one technique event per landed swing (split health updates cannot double-pay)
        if (realDealt > 0) hitConsumed = true;

        // enemy swing recency (its weapon is on cooldown right after a swing: a window to hit it)
        boolean oppSw = opp.swinging;
        boolean oppSwingStart = oppSw && !lastOppSwinging;
        sinceOppSwing = oppSwingStart ? 0 : Math.min(sinceOppSwing + 1, 40);
        lastOppSwinging = oppSw;
        mem.tick(realDealt, taken, oppSwingStart, prevOppHitMask);
        mem.fill(summary);
        boolean oppSprint = opp.isSprinting();
        prevOppHitMask = HitMemory.typeMask(true, !opp.onGround() && oppVel.y < 0 && !oppSprint, oppSprint, opp.onGround());

        // fighting-technique bookkeeping (bonuses are only paid together with real damage)
        if (taken > 0) {
            combo = 0;
            firstHitDone = true; // the enemy won the opening exchange: no first-hit bonus for me this episode
        }
        boolean firstHit = false;
        if (realDealt > 0) {
            combo++;
            firstHit = !firstHitDone;
            firstHitDone = true;
            winHits++;
            if (lastHitCrit) winCrits++;
            if (lastHitSprint) winSprintHits++;
        }
        double techW = curriculum.weights().tech;
        boolean resetGap = lastHitGap >= Config.RESET_GAP_MIN && lastHitGap <= Config.RESET_GAP_MAX;
        double tech = pendingTech + Reward.techBonus(realDealt > 0, lastHitCrit, lastHitSprint, combo, firstHit, false, techW,
            lastHitFull, resetGap, lastHitPunish, curriculum.weights().late);
        pendingTech = 0;

        // Compute distance before updating situational memory; MotionMemory uses this value every tick.
        double dist = myPos.distanceTo(oppPos);
        float[] frame = Observation.frame(me, opp, myVel, oppVel, sinceDealt, sinceTaken, lastActEnc, sinceOppSwing, sinceMySwing, curriculum.lockMask());
        motion.tick(frame, lastActEnc, dist, act.yawDelta(), act.pitchDelta()); // the turn applied since the last observation
        motion.fill(summary);
        int followupEvent = sprintFollowup.tick(realDealt > 0f && lastHitSprint, realDealt > 0f,
            frame[12] * 6f, frame[16], frame[17], frame[18]);
        if ((followupEvent & SprintHitFollowupMemory.SPRINT_HIT) != 0) winSprintFollowupOpps++;
        if ((followupEvent & SprintHitFollowupMemory.FOLLOWUP_HIT) != 0) {
            winSprintFollowups++;
            winSprintFollowupTicks += sprintFollowup.lastFollowupTicks();
        }
        if ((followupEvent & SprintHitFollowupMemory.EXPIRED) != 0) winSprintFollowupExpired++;
        sprintFollowup.fillSummary(summary);
        oppMem.useCell(agent == null ? null : agent.gruCell());
        oppMem.tick(frame, realDealt > 0f, taken > 0f);
        if (agent != null) agent.noteMemory(oppMem.hBefore(), oppMem.x());
        oppMem.fillSummary(summary);
        lastFrame = frame;

        // ---- reward (same function the offline simulator trains on) ----
        double yawErr = Math.abs(frame[13]);
        double pitchErr = Math.abs(frame[14]);
        long learned = agent.totalTicks;
        double reward = Reward.tick(dealt, taken, dist, prevDist, yawErr, pitchErr,
            mode == Mode.TRAIN ? Reward.shaping(learned) : 0.0, curriculum.pitchRamp(learned), curriculum.weights(),
            Reward.idleScale(curriculum.stage(), sinceReal), me.getAttackStrengthScale(0.5f), tech, (myHp - oppHp) / 20.0);
        final double distBefore = prevDist;
        prevDist = dist;
        boolean pitchFree = !ActionMask.pitchLocked(curriculum.lockMask());
        if (yawErr * 180.0 <= Config.ON_TARGET_DEG && (!pitchFree || pitchErr * 90.0 <= Config.ON_TARGET_DEG)) epAim++;
        if (mode == Mode.TRAIN) reward += cam.tick(frame[13] * 180.0, frame[14] * 90.0, pitchFree, frame[43] > 0.5f, frame[44] > 0.5f, me.getAttackStrengthScale(0.5f), curriculum.stage());
        if (mode == Mode.TRAIN) { // telemetry-compatible hook; intrinsic technique reward is disabled by default
            TechniqueReward.In t = techIn;
            t.lockMask = curriculum.lockMask(); t.stage = curriculum.stage(); t.techW = techW; t.idle = Reward.idleScale(curriculum.stage(), sinceReal);
            t.dist = dist; t.prevDist = distBefore; t.yawErrDeg = yawErr * 180.0;
            t.myHp01 = frame[0]; t.oppHp01 = frame[15]; t.myRight = frame[2] * 0.6; t.myFwd = frame[1] * 0.6;
            t.myGround = frame[4] > 0.5f; t.canCrit = frame[43] > 0.5f; t.enemyFacing = frame[21]; t.enemyCharge = frame[42];
            t.inMyReach = frame[44] > 0.5f; t.inTheirReach = frame[45] > 0.5f; t.oppSwingStart = oppSwingStart;
            t.realDealt = realDealt; t.taken = taken; t.hitSprint = lastHitSprint; t.hitCrit = lastHitCrit;
            t.myCharge = frame[6]; t.prevStrafe = Math.round(lastActEnc[3]); t.prevFwd = Math.round(lastActEnc[2]); t.prevSprint = lastActEnc[6] > 0.5f;
            reward += techR.tick(t);
        }
        if (mode == Mode.TRAIN) {
            if (techW > 0) agent.techTicks++;
            TechniqueDiscovery.In d = discIn;
            d.techW = techW; d.techTicks = agent.techTicks; d.tick = tickInEpisode;
            d.realDealt = realDealt; d.taken = taken; d.newHit = newHitEvent;
            d.hitCrit = lastHitCrit; d.hitSprint = lastHitSprint; d.hitPunish = lastHitPunish; d.hitEnemyCharge = lastHitEnemyCharge;
            d.oppSwingStart = oppSwingStart; d.inTheirReach = frame[45] > 0.5f; d.enemyFacing = frame[21];
            d.mySpeed = Math.hypot(frame[1], frame[2]) * 0.6;
            d.dist = dist; d.mySprinting = frame[5] > 0.5f;
            reward += disc.tick(d);
            JumpReset.In j = jrIn;
            j.hit = taken > 0f; j.jumpPrev = prevJump; j.onGround = frame[4] > 0.5f; j.mx = myPos.x; j.mz = myPos.z; j.ex = oppPos.x; j.ez = oppPos.z;
            j.enemySprint = oppSprint; j.techW = techW; j.techTicks = agent.techTicks; j.tick = tickInEpisode;
            reward += jr.tick(j);
            SpamGuard.In sp = spamIn;
            int locks = curriculum.lockMask();
            sp.jumpFree = (locks & ActionMask.LOCK_JUMP) == 0; sp.sneakFree = (locks & ActionMask.LOCK_SNEAK) == 0;
            sp.jumpPressed = prevJump; sp.onGround = frame[4] > 0.5f; sp.sneaking = prevSneak; sp.realHit = realDealt > 0;
            sp.moveFree = (locks & ActionMask.LOCK_MOVEMENT) != ActionMask.LOCK_MOVEMENT;
            sp.sprintFree = (locks & ActionMask.LOCK_SPRINT) == 0;
            sp.fwd = Math.round(lastActEnc[2]) - 1; sp.str = Math.round(lastActEnc[3]) - 1;
            sp.sprintKey = lastActEnc[6] > 0.5f; sp.speed = Math.hypot(myVel.x, myVel.z);
            sp.tookHit = taken > 0f; sp.comboWindow = sinceDealt <= Config.SPAM_COMBO_TICKS;
            reward += spam.tick(sp);
        }
        epFitness += reward;
        if (mode == Mode.TRAIN) agent.addReward(reward); // credit for the previous tick's action

        // ---- end conditions ----
        boolean oppDead = oppHp <= 0f || opp.isDeadOrDying();
        boolean meDead = myHp <= 0f || me.isDeadOrDying();
        boolean timeout = tickInEpisode >= Config.EPISODE_TICKS;
        float[] input = obs.push(frame, summary);
        if (oppDead || meDead || timeout) {
            endEpisode(mc, EpisodeOutcome.classify(meDead, oppDead, oppDead && credited, timeout), input);
            return;
        }

        // ---- think + act ----
        agent.setMask(ActionMask.withAttackGate(curriculum.lockMask(), dist, frame[13] * 180.0, frame[14] * 90.0));
        float[] a = mode == Mode.TRAIN ? agent.actTrain(input) : agent.actPlay(input);
        prevJump = a[5] == 1; prevSneak = a.length > 7 && a[7] == 1; // read by the SpamGuard on the next tick
        if (mode == Mode.TRAIN) entropyEma = entropyEma == 0 ? agent.lastEntropy() : 0.98 * entropyEma + 0.02 * agent.lastEntropy();
        // state at the moment of the swing (before this tick's keys change it): decides crit / sprint-hit
        boolean wasSprinting = me.isSprinting();
        boolean fallingCrit = !me.onGround() && myVel.y < 0 && !wasSprinting;
        float chargeNow = me.getAttackStrengthScale(0.5f);
        int gapAtSwing = sinceMySwing;
        int typeMask = HitMemory.typeMask(chargeNow >= Config.FULL_CHARGE, fallingCrit, wasSprinting, me.onGround());
        int oppAgeAtSwing = sinceOppSwing;
        float minCharge = curriculum.stage() >= Config.GATE_RELAX_STAGE ? Config.MIN_ATTACK_STRENGTH_LATE : Config.MIN_ATTACK_STRENGTH;
        act.setAimError(frame[13] * 180.0, frame[14] * 90.0, pitchFree); // the error the policy observes, for the camera braking envelope (AimBrake)
        int swing = act.apply(mc, me, a, opp, minCharge);
        if (swing != ActionApplier.SWING_NONE) sinceMySwing = 0;
        Observation.encodeAction(a, act.velYawNorm(), act.velPitchNorm(), lastActEnc);   // velocity STATE of the camera, after this tick's step
        cam.onAction(act.velYawNorm(), act.velPitchNorm());
        if (mode == Mode.TRAIN) { winLook += Math.abs(act.yawDelta()); winLookN++; }
        if (mode == Mode.TRAIN && swing != ActionApplier.SWING_NONE) pendingTech += techR.onSwing(swing == ActionApplier.SWING_HIT_TARGET, techW);
        if (mode == Mode.TRAIN && swing != ActionApplier.SWING_NONE) pendingTech += disc.onSwing(swing == ActionApplier.SWING_HIT_TARGET, tickInEpisode, techW);
        if (swing != ActionApplier.SWING_NONE) {
            winSwings++;
            mem.swing(typeMask, swing == ActionApplier.SWING_HIT_TARGET);
        }
        if (swing == ActionApplier.SWING_HIT_TARGET) {
            lastHitTick = tickInEpisode;
            hitConsumed = false;
            lastHitEnemyCharge = frame[42];
            lastHitCrit = (typeMask & HitMemory.CRIT) != 0;      // vanilla needs a full charge for crits and sprint knockback
            lastHitSprint = (typeMask & HitMemory.SPRINT) != 0;
            lastHitFull = chargeNow >= Config.FULL_CHARGE;
            lastHitGap = gapAtSwing;
            lastHitPunish = oppAgeAtSwing <= Config.PUNISH_WINDOW_TICKS;
        } else if (swing == ActionApplier.SWING_MISS) {
            winWhiffs++;
            if (mode == Mode.TRAIN) pendingTech -= Config.MISS_COST; // every missed swing costs a little (see Config.MISS_COST)
            if (mode == Mode.TRAIN && Reward.isPointlessWhiff(dist, yawErr, pitchErr)) {
                pendingTech += Reward.techBonus(false, false, false, 0, false, true, techW);
            }
            if (mode == Mode.TRAIN
                    && dist <= Config.SOFT_HIT_REACH && yawErr <= Config.SOFT_YAW_ERR && pitchErr <= Config.SOFT_PITCH_ERR
                    && curriculum.stage() <= Config.SOFT_MAX_STAGE && epSoft < Config.SOFT_EPISODE_CAP_HP) {
                pendingSoft = Config.SOFT_HIT_FRACTION * Config.SOFT_HIT_HP;
                epSoft += pendingSoft; // learning aid only: never auto-hits
            }
        }

        if (tickInEpisode % 20 == 0) {
            String bar = mode == Mode.TRAIN
                ? String.format(Locale.ROOT, "RL PPO  ticks %d  t %d/%d  dealt %.0f taken %.0f",
                    agent.totalTicks, tickInEpisode, Config.EPISODE_TICKS, epDealt, epTaken)
                : String.format(Locale.ROOT, "RL play  t %d/%d  dealt %.0f taken %.0f",
                    tickInEpisode, Config.EPISODE_TICKS, epDealt, epTaken);
            me.displayClientMessage(Component.literal(bar), true);
        }
    }

    // ------------------------------------------------------------ episode boundaries
    private void startEpisode(Minecraft mc, LocalPlayer me, AbstractClientPlayer opp) {
        episodeTarget = opp;
        inEpisode = true;
        reviewEpisode = false;
        tickInEpisode = 0;
        epFitness = 0;
        epDealt = 0;
        epTaken = 0;
        lastHitTick = -1000;
        pendingSoft = 0f;
        combo = 0;
        firstHitDone = false;
        lastHitCrit = false;
        lastHitSprint = false;
        lastHitFull = false;
        lastHitGap = 99;
        lastHitPunish = false;
        sinceMySwing = 40;
        pendingTech = 0;
        epAim = 0;
        warmup = setupBot(mc, me, opp) ? Config.HEAL_WARMUP_TICKS : 0; // heals in place, never teleports

        rebaseline(me, opp);
    }

    /** Resets the per-episode baselines (positions, health, distance, observation history). */
    private void rebaseline(LocalPlayer me, AbstractClientPlayer opp) {
        obs.reset();
        mem.reset(); motion.reset(); sprintFollowup.reset(); oppMem.reset();
        prevOppHitMask = 0;
        prevMyPos = me.position();
        prevOppPos = opp.position();
        prevMyHp = me.getHealth();
        prevOppHp = opp.getHealth();
        prevDist = prevMyPos.distanceTo(prevOppPos);
        sinceDealt = 40;
        sinceTaken = 40;
        sinceReal = 0;
        epSoft = 0f;
        sinceOppSwing = 40;
        lastOppSwinging = false;
        java.util.Arrays.fill(lastActEnc, 0f);
        cam.reset();
        techR.reset();
        spam.reset();
        disc.reset();
        jr.reset();
        hitConsumed = true;
        lastHitEnemyCharge = 1f;
    }

    /**
     * Hands the opponent to BotBrain (singleplayer only) and, in training, places the bot for this stage.
     * @return true if the bot was told to move (so we wait a few ticks before the episode starts)
     */
    private boolean setupBot(Minecraft mc, LocalPlayer me, AbstractClientPlayer opp) {
        if (mode != Mode.TRAIN) {
            bots.active = false; // /rl play leaves the bot entirely to you
            return false;
        }
        IntegratedServer srv = mc.getSingleplayerServer();
        if (srv == null) {
            if (!warnedNoServer) {
                warnedNoServer = true;
                say("Bot control (curriculum opponents, self-play) needs a singleplayer world. Training continues without it.");
            }
            bots.active = false;
            return false;
        }
        final String botName = opp.getScoreboardName();
        final String meName = me.getScoreboardName();
        bots.botName = botName;
        bots.agentName = meName;
        boolean[] review = new boolean[1];
        Curriculum.Opponent m = curriculum.sampleOpponent(rng, review); // opponent + review flag are one atomic choice
        reviewEpisode = review[0];
        benchmarkEpisode = !reviewEpisode;
        if (m == Curriculum.Opponent.SELF_PLAY) { // stage 9 league: a past snapshot, the strong fighter, or the aggressive bot
            double r = rng.nextDouble();
            if (!pool.isEmpty() && r < Config.LEAGUE_P_SNAPSHOT) {
                bots.policy = pool.get(rng.nextInt(pool.size()));
                benchmarkEpisode = false;
            } else {
                m = r < Config.LEAGUE_P_SNAPSHOT + Config.LEAGUE_P_STRONG ? Curriculum.Opponent.STRONG : Curriculum.Opponent.AGGRESSIVE;
            }
        }
        bots.mode = m;
        bots.difficulty = botDiff.value();
        bots.hopLevel = curriculum.hopLevel();
        bots.stage = curriculum.stage(); // stage 2-3: the stationary bot hops (pitch practice)
        bots.active = true;
        srv.execute(() -> bots.refresh(srv, botName, meName)); // heal + reset the script; nobody is teleported
        return true;
    }

    /** Applies the current stage: lock mask, entropy boost, opponent mode, self-play snapshot. */
    private void syncCurriculum() {
        if (agent == null) return;
        long ticks = agent.totalTicks;
        if (curriculum.update(ticks)) {
            int st = curriculum.stage();
            say("Stage " + st + "/" + Curriculum.STAGES + ": opponent " + Curriculum.opponentFor(st).label
                + ", locks " + ActionMask.label(Curriculum.lockMaskFor(st)));
        }
        if (mode == Mode.TRAIN) guard.noteStage(curriculum.stage(), agent);
        agent.setMask(curriculum.lockMask());
        if (mode == Mode.TRAIN) {
            agent.stage = curriculum.autoStage();            // saved with the agent
            agent.stageEnterTicks = curriculum.stageEnterTicks();
            float coef = Config.ENTROPY_COEF * curriculum.entropyScale(ticks);
            entropyFloorNow = Config.ENTROPY_FLOOR_FRAC * PpoAgent.maxEntropy(curriculum.lockMask());
            if (entropyEma > 0 && entropyEma < entropyFloorNow) coef *= Config.ENTROPY_FLOOR_BOOST; // anti-collapse
            agent.setEntropyCoef(coef);
            if (curriculum.opponent() == Curriculum.Opponent.SELF_PLAY
                    && (pool.isEmpty() || ticks - lastSnapshotTicks >= Config.SELF_PLAY_SNAPSHOT_TICKS)) {
                pool.add(new FrozenPolicy(agent.actor.w)); // frozen copy of the current policy joins the league
                while (pool.size() > Config.LEAGUE_POOL) pool.remove(0);
                lastSnapshotTicks = ticks;
            }
        }
    }

    RlHud.Data hud() {
        return hud;
    }

    /** @param result +1 success (kill, or on target in the aim stages), -1 death, 0 neither; @param label text for the HUD. */
    private void pushEpisode(double fitness, int result, String label) {
        epCount++;
        lastResult = label + String.format(Locale.ROOT, "  %+.1f  (dealt %.0f / took %.0f)", fitness, epDealt, epTaken);
        if (retN < retHist.length) retHist[retN++] = (float) fitness;
        else { System.arraycopy(retHist, 1, retHist, 0, retHist.length - 1); retHist[retHist.length - 1] = (float) fitness; }
        if (resN < resHist.length) resHist[resN++] = (byte) result;
        else { System.arraycopy(resHist, 1, resHist, 0, resHist.length - 1); resHist[resHist.length - 1] = (byte) result; }
    }

    private RlHud.Data buildHud() {
        if (mode == Mode.OFF || agent == null) return RlHud.Data.OFF;
        long ticks = agent.totalTicks;
        int st = Math.max(1, curriculum.stage());
        if (entropyEma > 0) {
            if (entN < entHist.length) entHist[entN++] = (float) entropyEma;
            else { System.arraycopy(entHist, 1, entHist, 0, entHist.length - 1); entHist[entHist.length - 1] = (float) entropyEma; }
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer me = mc.player;
        AbstractClientPlayer o = episodeTarget;
        boolean live = inEpisode && me != null && o != null && lastFrame != null;
        boolean has = stats.count() > 0;
        return new RlHud.Data(true, mode == Mode.PLAY, st, Curriculum.STAGES,
            Curriculum.opponentFor(st).label, ActionMask.label(curriculum.lockMask()), curriculum.lockMask(),
            ticks, agent.updates, epCount, curriculum.progress(ticks),
            entropyEma, stats.avgReturn(), stats.winRate(), has ? stats.lossRate() : 0, stats.avgDealt(), stats.avgTaken(), has,
            lastWhiff, lastCrit, lastSprint, guard.rollbacks, mode == Mode.TRAIN ? Reward.shaping(ticks) : 0.0,
            Reward.idleScale(st, sinceReal),
            live, tickInEpisode, Config.EPISODE_TICKS,
            live ? me.getHealth() : 20, live ? o.getHealth() : 20, live ? me.distanceTo(o) : 0,
            live ? me.getAttackStrengthScale(0.5f) : 1.0,
            live ? lastFrame[13] * 180.0 : 0, live ? lastFrame[14] * 90.0 : 0, live ? lastFrame[26] > 0.5f : true,
            java.util.Arrays.copyOf(retHist, retN), java.util.Arrays.copyOf(resHist, resN), java.util.Arrays.copyOf(entHist, entN), lastResult);
    }

    /** End a classified episode. An absent final observation is valid for death screens and removed opponents. */
    private void endEpisode(Minecraft mc, EpisodeOutcome outcome, float[] finalObs) {
        double terminal = Reward.terminal(outcome) + Reward.finishAdjust(outcome, tickInEpisode, Config.EPISODE_TICKS, curriculum.stage());
        epFitness += terminal;
        boolean win = outcome.win(), loss = outcome.loss(), decided = !outcome.noContest();

        inEpisode = false;
        episodeTarget = null;
        bots.active = false; // the bot is released until the next episode
        act.release(mc);

        if (mode == Mode.TRAIN) {
            double settled = disc.endEpisode(); // open technique exchanges are settled by the existing technique policy
            epFitness += settled;
            agent.addReward(terminal + settled);
            boolean aimStage = curriculum.stage() <= Config.AIM_GATE_MAX_STAGE;
            boolean success = false;
            if (decided) {
                success = win || Config.leadDecision(outcome == EpisodeOutcome.TIMEOUT, epDealt, epTaken) || (aimStage && curriculum.aimSuccess(epAim, tickInEpisode));
                curriculum.reportEpisode(success, reviewEpisode);
                if ((win || loss) && (bots.mode == Curriculum.Opponent.AGGRESSIVE || bots.mode == Curriculum.Opponent.STRONG || bots.mode == Curriculum.Opponent.ELITE)) botDiff.report(win);
            }
            // A timeout is time-limit truncation (bootstrap); any death, including a mutual KO or uncredited opponent death, is terminal.
            agent.endEpisode(outcome.terminal(), finalObs);
            String label = switch (outcome) {
                case WIN -> "WIN";
                case LOSS -> "LOSS";
                case MUTUAL_KO -> "MUTUAL KO";
                case TIMEOUT -> success ? "AIMED" : aimStage ? "OFF TARGET" : "DRAW (TIMEOUT)";
                case OPP_DIED_UNCREDITED -> "NO CONTEST (uncredited death)";
                case ABORTED -> "NO CONTEST (opponent left)";
            };
            int result = win ? 1 : loss ? -1 : 0;
            pushEpisode(epFitness, result, label);
            if (decided) {
                winDealt += epDealt;
                winTaken += epTaken;
                winReturn += epFitness;
                stats.add(epFitness, epDealt, epTaken, win, loss);
            }
            if (decided && guard.addEpisode(benchmarkEpisode && !reviewEpisode, win, loss, epDealt, epTaken, curriculum.stage(), agent)) {
                say("Performance collapsed: rolled back to the best weights of this stage (rollback #" + guard.rollbacks + ").");
            }
            if (guard.takeDemotion()) {
                int from = curriculum.autoStage();
                if (curriculum.demote(agent.totalTicks)) {
                    botDiff.set(0.0);
                    say("Stage " + from + " collapsed: restored saved weights and went back to stage " + curriculum.autoStage() + ". It must earn the promotion again against a higher gate.");
                }
            }
            if (decided) {
                winEpisodes++;
                if (win) winWins++;
                if (loss) winLosses++;
                if (outcome.draw()) winDraws++;
                if (winEpisodes >= Config.STATS_EVERY_EPISODES) reportStats();
            } else {
                winNoContest++;
            }
            int saveEvery = curriculum.stage() <= 3 ? Config.AUTOSAVE_EARLY_TICKS : Config.AUTOSAVE_EVERY_TICKS;
            if (agent.totalTicks - lastSaveTicks >= saveEvery) {
                save();
                lastSaveTicks = agent.totalTicks;
            }
        } else if (mode == Mode.PLAY) {
            say(String.format(Locale.ROOT, "play: %s, dealt %.1f HP, took %.1f HP", outcome, epDealt, epTaken));
        }
    }

    private void reportStats() {
        double n = Math.max(1, winEpisodes);
        double[] s = agent.takeStats(); // {steps, kl, entropy, clipFrac, valueLoss, gradNorm}
        double whiffRate = winWhiffs / (double) Math.max(1, winSwings);
        double critShare = winCrits / (double) Math.max(1, winHits);
        double sprintShare = winSprintHits / (double) Math.max(1, winHits);
        lastWhiff = whiffRate; lastCrit = critShare; lastSprint = sprintShare;
                appendLog(String.format(Locale.ROOT, "%d,%d,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.4f,%.3f,%.4f,%.3f,%d,%.3f,%.3f,%.3f,%d,%d,%d,%d,%.3f",
            agent.totalTicks, agent.updates, winDealt / n, winTaken / n, winWins / n, winLosses / n, winReturn / n,
            s[2], s[1], s[3], s[4], Reward.shaping(agent.totalTicks), curriculum.stage(),
            whiffRate, critShare, sprintShare, guard.rollbacks, winSprintFollowupOpps, winSprintFollowups,
            winSprintFollowupExpired, winSprintFollowups == 0 ? 0.0 : winSprintFollowupTicks / (double) winSprintFollowups));
        lastStats = String.format(Locale.ROOT,
            "ticks %d: win %.0f%%, loss %.0f%%, draw %.0f%%, no-contest %d, dealt %.1f HP, taken %.1f HP, return %.2f, entropy %.2f, kl %.4f, whiff %.0f%%, crit %.0f%%, sprint-hit %.0f%%, follow-up %.0f%% (%d/%d, expired %d, avg %.1f ticks), camera %.2f deg/tick",
            agent.totalTicks, 100.0 * winWins / n, 100.0 * winLosses / n, 100.0 * winDraws / n, winNoContest, winDealt / n, winTaken / n, winReturn / n,
            s[2], s[1], 100 * whiffRate, 100 * critShare, 100 * sprintShare,
            100.0 * winSprintFollowups / Math.max(1, winSprintFollowupOpps), winSprintFollowups, winSprintFollowupOpps,
            winSprintFollowupExpired, winSprintFollowups == 0 ? 0.0 : winSprintFollowupTicks / (double) winSprintFollowups,
            winLook / Math.max(1, winLookN));
        lastStats += " | " + disc.summary() + " | " + jr.summary();
        appendTechLog(disc.csvRow(agent.totalTicks, curriculum.stage()));
        disc.clearWindow();
        jr.clearWindow();
        say(lastStats);
        resetStats();
    }

    private void resetStats() {
        winLook = 0;
        winLookN = 0;
        winSwings = 0;
        winWhiffs = 0;
        winHits = 0;
        winCrits = 0;
        winSprintHits = 0;
        winSprintFollowupOpps = winSprintFollowups = winSprintFollowupExpired = winSprintFollowupTicks = 0;
        winDealt = 0;
        winTaken = 0;
        winReturn = 0;
        winEpisodes = 0;
        winWins = 0;
        winLosses = 0;
        winDraws = 0;
        winNoContest = 0;
    }

    private static void appendTechLog(String line) {
        try {
            Files.createDirectories(dir());
            Path f = dir().resolve("techlog.csv");
            if (!Files.exists(f)) Files.writeString(f, TechniqueDiscovery.csvHeader() + "\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            Files.writeString(f, line + "\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            LOG.warn("rlpvp could not write techlog.csv: {}", e.getMessage());
        }
    }

    private static void appendLog(String line) {
        try {
            Files.createDirectories(dir());
            Path f = logFile();
            if (!Files.exists(f)) {
                Files.writeString(f, "ticks,updates,avgDealtHp,avgTakenHp,winRate,lossRate,avgReturn,entropy,kl,clipFraction,valueLoss,shaping,stage,whiffRate,critShare,sprintHitShare,rollbacks,sprintFollowupOpps,sprintFollowupHits,sprintFollowupExpired,avgFollowupTicks\n",
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            }
            Files.writeString(f, line + "\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            LOG.warn("rlpvp could not write log.csv: {}", e.getMessage());
        }
    }

    /** Last-N-episode averages for the HUD. */
    private static final class RollingStats {
        private final double[] ret;
        private final double[] dealt;
        private final double[] taken;
        private final boolean[] win;
        private final boolean[] lost;
        private int n;
        private int idx;

        RollingStats(int cap) {
            ret = new double[cap];
            dealt = new double[cap];
            taken = new double[cap];
            win = new boolean[cap];
            lost = new boolean[cap];
        }

        void clear() {
            n = 0;
            idx = 0;
        }

        void add(double r, double d, double t, boolean w, boolean l) {
            lost[idx] = l;
            ret[idx] = r;
            dealt[idx] = d;
            taken[idx] = t;
            win[idx] = w;
            idx = (idx + 1) % ret.length;
            n = Math.min(n + 1, ret.length);
        }

        int count() {
            return n;
        }

        double avgReturn() {
            return avg(ret);
        }

        double avgDealt() {
            return avg(dealt);
        }

        double avgTaken() {
            return avg(taken);
        }

        double lossRate() {
            if (n == 0) return 0;
            int c = 0;
            for (int i = 0; i < n; i++) if (lost[i]) c++;
            return c / (double) n;
        }

        double winRate() {
            if (n == 0) return 0;
            int c = 0;
            for (int i = 0; i < n; i++) if (win[i]) c++;
            return c / (double) n;
        }

        private double avg(double[] a) {
            if (n == 0) return 0;
            double sum = 0;
            for (int i = 0; i < n; i++) sum += a[i];
            return sum / n;
        }
    }
}
