package com.rlpvp;

/**
 * Best-checkpoint rollback and stage-collapse detection shared by the simulator and the mod.
 * Only benchmark episodes are counted. A low win rate alone is insufficient to classify a collapse: timeouts/even trades are draws,
 * while a genuinely failing policy must also be losing badly, barely engaging, or substantially out-traded.
 */
final class CollapseGuard {
    private float[][] best;
    private double bestEma, ema;
    private boolean emaInit;
    private int windows, below, cooldown, stage = -1, stageRollbacks;
    private int n, wins, losses;
    private double dealt, taken;
    private final boolean[] evidenceWin = new boolean[Config.GUARD_EVIDENCE_WINDOW];
    private final boolean[] evidenceLoss = new boolean[Config.GUARD_EVIDENCE_WINDOW];
    private final double[] evidenceDealtSlot = new double[Config.GUARD_EVIDENCE_WINDOW];
    private final double[] evidenceTakenSlot = new double[Config.GUARD_EVIDENCE_WINDOW];
    private int evidenceHead, evidenceCount, evidenceWins, evidenceLosses;
    private double evidenceDealt, evidenceTaken;
    private double dealtEma, bestDealt;
    private int deadStreak;
    private final double alpha;
    private final int patience, failWindows;
    private float[][] entry;
    private int failStreak;
    private boolean demote;
    int demotions;
    int rollbacks;

    CollapseGuard() { this(Config.GUARD_EMA_ALPHA, Config.GUARD_PATIENCE, Config.GUARD_FAIL_WINDOWS); }
    CollapseGuard(double alpha, int patience) { this(alpha, patience, Config.GUARD_FAIL_WINDOWS); }
    CollapseGuard(double alpha, int patience, int failWindows) {
        this.alpha = alpha; this.patience = patience; this.failWindows = Math.max(1, failWindows);
    }

    /** True once if the guard restored weights and requests a curriculum demotion. */
    boolean takeDemotion() { boolean d = demote; demote = false; return d; }
    int stage() { return stage; }

    /** Call on curriculum synchronization; captures the weights at actual stage entry, not at a later first probe. */
    void noteStage(int curStage, PpoAgent agent) {
        if (curStage != stage) {
            reset(curStage);
            if (agent != null) entry = agent.exportWeights();
        } else if (entry == null && agent != null) {
            entry = agent.exportWeights();
        }
    }

    /** Wilson upper confidence bound for a binomial rate; robust against tiny noisy windows. */
    static double wilsonUpper(int successes, int trials, double z) {
        if (trials <= 0) return 1.0;
        double p = Math.max(0.0, Math.min(1.0, successes / (double) trials));
        double z2 = z * z, n = trials;
        double den = 1.0 + z2 / n;
        double center = p + z2 / (2.0 * n);
        double radius = z * Math.sqrt((p * (1.0 - p) + z2 / (4.0 * n)) / n);
        return Math.min(1.0, (center + radius) / den);
    }

    /** A non-winning window is a failure only when pooled evidence is large enough and the policy is genuinely failing. */
    static boolean failedWindow(int n, int wins, int losses, double dealtHp, double takenHp) {
        if (n <= 0 || wins / (double) n > Config.GUARD_FAIL_WIN) return false;
        double lossRate = losses / (double) n;
        double dealtAvg = dealtHp / n, takenAvg = takenHp / n;
        return lossRate >= Config.GUARD_FAIL_LOSS
            || dealtAvg < Config.GUARD_FAIL_MIN_DEALT
            || dealtAvg < Config.GUARD_FAIL_TRADE * takenAvg;
    }

    private static boolean statisticallyFailed(int n, int wins, int losses, double dealtHp, double takenHp) {
        return n >= Config.GUARD_MIN_EVIDENCE_EPISODES
            && wilsonUpper(wins, n, Config.GUARD_WILSON_Z) <= Config.GUARD_FAIL_WIN
            && failedWindow(n, wins, losses, dealtHp, takenHp);
    }

    /** Copy of the best non-failed in-stage checkpoint, or null if no valid best exists. */
    float[][] bestWeights() { return best == null ? null : copy(best); }
    private static float[][] copy(float[][] src) {
        float[][] dst = new float[src.length][];
        for (int i = 0; i < src.length; i++) dst[i] = src[i].clone();
        return dst;
    }

    /** Records one decided episode. No-contests must be filtered by the caller. */
    boolean addEpisode(boolean benchmark, boolean win, boolean loss, double dealtHp, double takenHp, int curStage, PpoAgent agent) {
        if (curStage != stage) noteStage(curStage, agent);
        if (entry == null && agent != null) entry = agent.exportWeights(); // compatibility fallback; production callers use noteStage()
        if (!benchmark) return false;
        if (win) loss = false; // outcomes cannot be both a win and a loss
        n++; if (win) wins++; if (loss) losses++;
        dealt += Math.max(0.0, dealtHp); taken += Math.max(0.0, takenHp);
        addEvidence(win, loss, Math.max(0.0, dealtHp), Math.max(0.0, takenHp));
        if (n < Config.STATS_EVERY_EPISODES) return false;

        boolean rawFailure = failedWindow(evidenceCount, evidenceWins, evidenceLosses, evidenceDealt, evidenceTaken);
        boolean failed = statisticallyFailed(evidenceCount, evidenceWins, evidenceLosses, evidenceDealt, evidenceTaken);
        double score = (wins - losses) / (double) n + (dealt - taken) / (n * 20.0);
        double dealtAvg = dealt / n;
        n = wins = losses = 0; dealt = taken = 0;

        boolean demoteStage = curStage >= Config.GUARD_DEMOTE_FROM_STAGE;
        boolean rolled = window(score, dealtAvg, agent, !(demoteStage && rawFailure), !(demoteStage && failed));
        if (rolled) {
            // Keep pooled failure evidence: rollback is a recovery attempt, not proof that the stage is healthy.
        }
        if (demoteStage && agent != null && (best != null || entry != null)) {
            failStreak = failed ? failStreak + 1 : 0;
            if (failStreak >= failWindows) {
                agent.importWeights(entry != null ? entry : best); // a demotion must restore the exact stage-entry policy, not a possibly degraded late snapshot
                agent.lrScale = Math.max(0.3f, agent.lrScale * 0.7f);
                demote = true; demotions++; failStreak = 0;
            }
        }
        return rolled;
    }


    private void addEvidence(boolean win, boolean loss, double dealtHp, double takenHp) {
        if (evidenceCount == Config.GUARD_EVIDENCE_WINDOW) {
            if (evidenceWin[evidenceHead]) evidenceWins--;
            if (evidenceLoss[evidenceHead]) evidenceLosses--;
            evidenceDealt -= evidenceDealtSlot[evidenceHead];
            evidenceTaken -= evidenceTakenSlot[evidenceHead];
        } else evidenceCount++;
        evidenceWin[evidenceHead] = win; evidenceLoss[evidenceHead] = loss;
        evidenceDealtSlot[evidenceHead] = dealtHp; evidenceTakenSlot[evidenceHead] = takenHp;
        if (win) evidenceWins++; if (loss) evidenceLosses++;
        evidenceDealt += dealtHp; evidenceTaken += takenHp;
        evidenceHead = (evidenceHead + 1) % Config.GUARD_EVIDENCE_WINDOW;
    }

    private void reset(int s) {
        stage = s; best = null; bestEma = Double.NaN; ema = 0; emaInit = false; windows = 0; below = 0; cooldown = 0; stageRollbacks = 0;
        entry = null; failStreak = 0; demote = false; deadStreak = 0; dealtEma = 0; bestDealt = 0;
        n = wins = losses = 0; dealt = taken = 0;
        java.util.Arrays.fill(evidenceWin, false); java.util.Arrays.fill(evidenceLoss, false);
        java.util.Arrays.fill(evidenceDealtSlot, 0); java.util.Arrays.fill(evidenceTakenSlot, 0);
        evidenceHead = evidenceCount = evidenceWins = evidenceLosses = 0; evidenceDealt = evidenceTaken = 0;
    }

    private boolean window(double score, double dealtAvg, PpoAgent agent, boolean mayBeBest, boolean allowRollback) {
        windows++;
        if (cooldown > 0) cooldown--;
        dealtEma = emaInit ? (1 - alpha) * dealtEma + alpha * dealtAvg : dealtAvg;
        ema = emaInit ? (1 - alpha) * ema + alpha * score : score;
        emaInit = true;
        if (agent != null && mayBeBest && windows >= Config.GUARD_MIN_WINDOWS && ema >= Config.GUARD_BEST_FLOOR
                && (best == null || ema > bestEma + 0.02)) {
            best = agent.exportWeights(); bestEma = ema; bestDealt = dealtEma; below = 0;
            return false;
        }
        boolean canRollback = allowRollback && agent != null && best != null && cooldown == 0 && stageRollbacks < Config.GUARD_MAX_PER_STAGE;
        boolean low = canRollback && ema < bestEma - Config.GUARD_DROP;
        below = low ? below + 1 : 0;
        boolean dead = canRollback && bestDealt >= 6.0 && dealtAvg < 0.35 * bestDealt;
        deadStreak = dead ? deadStreak + 1 : 0;
        if (agent == null || best == null || (below < patience && deadStreak < 2)) return false;
        agent.importWeights(best);
        agent.lrScale = Math.max(0.3f, agent.lrScale * 0.7f);
        deadStreak = 0; rollbacks++; stageRollbacks++;
        cooldown = Config.GUARD_COOLDOWN_WINDOWS; below = 0; emaInit = false; windows = 0;
        return true;
    }

    double bestScore() { return best == null ? Double.NaN : bestEma; }
}
