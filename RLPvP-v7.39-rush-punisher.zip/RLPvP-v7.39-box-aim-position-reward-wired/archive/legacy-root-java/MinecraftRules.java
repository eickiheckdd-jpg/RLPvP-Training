package com.rlpvp;

import java.util.Random;

/**
 * Vanilla (Java 1.21) melee-combat arithmetic, Minecraft-free, shared by the simulator. Written from knowledge of the game's formulas
 * (attack strength scaling, critical hits, armor / toughness, enchantment protection, Resistance, post-hit invulnerability, knockback resistance);
 * it has NOT been checked against a running game, so treat the numbers as a faithful model, not a guarantee.
 *
 * What the old simulator did: every fighter was an unarmoured player with a 7-damage weapon and any hit during the 10-tick invulnerability
 * window was ignored. Real PvP servers use kits, and vanilla lets a STRONGER hit through the window (only the excess over the last hit).
 */
final class MinecraftRules {
    private MinecraftRules() {}

    /** Equipment / status of one fighter. */
    static final class Kit {
        final String name;
        final double weaponDamage;        // attack damage with the weapon in hand (diamond sword 7, iron 6, netherite 8)
        final int sharpness;              // Sharpness level (0 = none): +0.5 * level + 0.5, scaled by the attack strength
        final double armor, toughness;    // armor points (0..20) and armor toughness
        final double protectionEpf;       // total enchantment protection factor (Protection IV on 4 pieces = 16); capped at 20
        final int resistanceAmp;          // Resistance effect amplifier, -1 = none
        final double knockbackResistance; // 0..1 (netherite 0.1 per piece)
        final float absorption;           // golden-apple hearts in hp (modelled as extra hp, not regenerating)
        final double regenPerTick;        // natural regeneration, hp per tick (0 = off, as on most practice servers)

        Kit(String name, double weaponDamage, int sharpness, double armor, double toughness, double protectionEpf, int resistanceAmp,
            double knockbackResistance, float absorption, double regenPerTick) {
            this.name = name; this.weaponDamage = weaponDamage; this.sharpness = sharpness; this.armor = armor; this.toughness = toughness;
            this.protectionEpf = protectionEpf; this.resistanceAmp = resistanceAmp; this.knockbackResistance = knockbackResistance;
            this.absorption = absorption; this.regenPerTick = regenPerTick;
        }
    }

    /** The old simulator behaviour: unarmoured, 7-damage sword (-Dsim.kit=naked). */
    static final Kit NAKED = new Kit("naked", 7, 0, 0, 0, 0, -1, 0, 0f, 0);
    static final Kit IRON = new Kit("iron", 6, 0, 15, 0, 0, -1, 0, 0f, 0);
    static final Kit DIAMOND = new Kit("diamond", 7, 0, 20, 8, 0, -1, 0, 0f, 0);
    static final Kit DIAMOND_PROT = new Kit("diamond+prot4+sharp3", 7, 3, 20, 8, 16, -1, 0, 0f, 0);
    /** Diamond sword (7) + full diamond armor (20 armor, 8 toughness) with Protection III on all 4 pieces (EPF 3 x 4 = 12, i.e. 48 % off after armor). Default sim kit for both fighters. */
    static final Kit DIAMOND_PROT3 = new Kit("diamond+prot3", 7, 0, 20, 8, 12, -1, 0, 0f, 0);
    static final Kit NETHERITE = new Kit("netherite+prot4+sharp5", 8, 5, 20, 12, 16, -1, 0.4, 0f, 0);

    private static final Kit[] POOL = {NAKED, NAKED, IRON, DIAMOND, DIAMOND_PROT, NETHERITE};

    static Kit byName(String n) {
        if (n == null) return DIAMOND_PROT3;
        switch (n.toLowerCase(java.util.Locale.ROOT)) {
            case "diamond_prot3": case "prot3": return DIAMOND_PROT3;
            case "naked": return NAKED;
            case "iron": return IRON;
            case "diamond": return DIAMOND;
            case "diamond_prot": case "prot": return DIAMOND_PROT;
            case "netherite": return NETHERITE;
            default: return DIAMOND_PROT3;
        }
    }

    /** Domain randomisation: a mixed pool of kits (roughly a third unarmoured). */
    static Kit random(Random r) { return POOL[r.nextInt(POOL.length)]; }

    /**
     * Damage of one attack BEFORE defence. {@code scale} = attack strength scale in [0,1] when the click was sent. Base damage scales with
     * 0.2 + s^2 * 0.8, the enchantment bonus with s, a critical hit multiplies only the base damage by 1.5 (like the game).
     */
    static double attackDamage(Kit attacker, double scale, boolean crit) {
        double base = attacker.weaponDamage * (0.2 + scale * scale * 0.8);
        double ench = attacker.sharpness > 0 ? (0.5 * attacker.sharpness + 0.5) * scale : 0.0;
        if (crit) base *= 1.5;
        return base + ench;
    }

    /** Armor + toughness reduction (CombatRules.getDamageAfterAbsorb). */
    static double armorAbsorb(double damage, double armor, double toughness) {
        double f = 2.0 + toughness / 4.0;
        double f1 = Math.min(20.0, Math.max(armor * 0.2, armor - damage / f));
        return damage * (1.0 - f1 / 25.0);
    }

    /** Everything between the raw damage and the hp lost: armor, Resistance, enchantment protection. */
    static double afterDefense(Kit defender, double damage) {
        double d = armorAbsorb(damage, defender.armor, defender.toughness);
        if (defender.resistanceAmp >= 0) d = Math.max(0.0, d * (25 - (defender.resistanceAmp + 1) * 5) / 25.0);
        if (d > 0 && defender.protectionEpf > 0) d *= 1.0 - Math.min(20.0, defender.protectionEpf) / 25.0;
        return Math.max(0.0, d);
    }

    /**
     * While the target is inside its post-hit invulnerability window (more than 10 ticks left) vanilla still lets a STRONGER hit through,
     * but only the part above the previous hit (raw damage compared before armor); there is no new window and no knockback.
     */
    static double invulnerableExtra(double rawDamage, double lastRawDamage) {
        return Math.max(0.0, rawDamage - lastRawDamage);
    }

    /** Knockback strength after the defender's knockback resistance (0 = none left). */
    static double knockbackStrength(double strength, Kit defender) {
        return strength * (1.0 - Math.max(0.0, Math.min(1.0, defender.knockbackResistance)));
    }

    /** Cooldown ticks needed for a full-charge strike using the same strength convention as E.scale(). */
    static final int FULL_CHARGE_TICKS = (int) Math.ceil(Config.ENEMY_CHARGE_TICKS - 0.5);
    /** Vanilla's hit-invulnerability window blocks another full strike for 10 ticks. */
    static final int INVUL_BLOCK_TICKS = 10;

    static double fullHitHp(Kit attacker, Kit defender) {
        return afterDefense(defender, attackDamage(attacker, 1.0, false));
    }

    static int hitsToKill(Kit attacker, Kit defender) {
        double hpPerHit = fullHitHp(attacker, defender);
        if (!(hpPerHit > 0.0) || !Double.isFinite(hpPerHit)) return Integer.MAX_VALUE;
        return (int) Math.ceil((20.0 + defender.absorption) / hpPerHit - 1e-9);
    }

    /** Theoretical minimum from spawn-in-reach with a charged weapon, no crits/regeneration, every hit landing. */
    static int perfectTicksToKill(Kit attacker, Kit defender) {
        int hits = hitsToKill(attacker, defender);
        if (hits == Integer.MAX_VALUE) return Integer.MAX_VALUE;
        return (hits - 1) * Math.max(FULL_CHARGE_TICKS, INVUL_BLOCK_TICKS);
    }

    /** Simulator-only timeout sized to both kits. The real mod retains Config.EPISODE_TICKS because server kits are not known reliably. */
    static int episodeTicks(Kit me, Kit opponent) {
        long ttk = Math.max((long) perfectTicksToKill(me, opponent), (long) perfectTicksToKill(opponent, me));
        if (ttk == Integer.MAX_VALUE) ttk = Config.EPISODE_TICKS_MAX;
        long raw = (long) Math.ceil(Config.EPISODE_KILL_TIME_FACTOR * Math.min(ttk, 100_000L));
        long rounded = ((raw + 19L) / 20L) * 20L;
        return (int) Math.max(Config.EPISODE_TICKS, Math.min(Config.EPISODE_TICKS_MAX, rounded));
    }
}
