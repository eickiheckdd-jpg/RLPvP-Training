package com.rlpvp;

import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Training HUD. Default is a small widget in the top-left corner.
 *
 *   MINI     one line: stage, win rate, distance, status dot
 *   COMPACT  (default) ~124 px wide: stage + opponent, both health bars, swing charge, distance gauge,
 *            win rate / return / entropy, return sparkline, result strip, alerts
 *   FULL     the compact widget plus a detail panel (technique stats, graphs, locks, counters)
 *
 * Commands: /rl hud [on|off|mini|compact|full]. Everything is client side and only uses fill/drawString.
 */
final class RlHud {
    private RlHud() {}

    /** Snapshot built by the Trainer every Config.HUD_EVERY_TICKS ticks. Immutable, safe to read on the render thread. */
    record Data(boolean active, boolean play, int stage, int stages, String opponent, String locks, int lockBits,
                long ticks, int updates, int episodes, double progress,
                double entropy, double ret, double winRate, double lossRate, double dealt, double taken, boolean hasStats,
                double whiffRate, double critShare, double sprintShare, int rollbacks, double shaping, double idleScale,
                boolean inEpisode, int epTick, int epTicks,
                double myHp, double oppHp, double dist, double charge, double yawErrDeg, double pitchErrDeg, boolean los,
                float[] retHist, byte[] resHist, float[] entHist, String lastResult) {
        static final Data OFF = new Data(false, false, 1, Curriculum.STAGES, "-", "none", 0,
            0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, false,
            0, 0, 0, 0, 1, 1,
            false, 0, Config.EPISODE_TICKS,
            20, 20, 0, 1, 0, 0, true,
            new float[0], new byte[0], new float[0], "");
    }

    enum Mode { MINI, COMPACT, FULL }

    static volatile boolean visible = true;
    static volatile Mode mode = Mode.COMPACT;

    private static final HudState STATE = new HudState();

    private static final int X = 4, Y = 4;       // corner anchor
    private static final int W = 124;            // compact width
    private static final int PAD = 4;
    private static final int GAP = 3;

    // ================================================================== entry point
    static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        Data d = RlPvpClient.TRAINER.hud();
        if (!visible || !d.active() || mc.player == null || mc.options.hideGui) return;
        Font font = mc.font;
        STATE.update(d);

        int bottom;
        switch (mode) {
            case MINI -> bottom = mini(g, font, d, X, Y);
            case FULL -> {
                bottom = compact(g, font, d, X, Y);
                bottom = detail(g, font, d, X, bottom + GAP);
            }
            default -> bottom = compact(g, font, d, X, Y);
        }
        if (d.inEpisode() && mode == Mode.FULL) { // never draw over the crosshair in the normal views
            HudDraw.aimDot(g, STATE.yawErr, STATE.pitchErr, d.los(),
                mc.getWindow().getGuiScaledWidth() / 2, mc.getWindow().getGuiScaledHeight() / 2, 12);
        }
        toast(g, font, mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight());
    }

    /** Parses the argument of /rl hud. @return a message for the chat, or null if the argument was not understood. */
    static String command(String arg) {
        if (arg == null) { visible = !visible; return "HUD " + (visible ? "on" : "off"); }
        switch (arg.toLowerCase(Locale.ROOT)) {
            case "on" -> { visible = true; return "HUD on (" + mode.name().toLowerCase(Locale.ROOT) + ")"; }
            case "off" -> { visible = false; return "HUD off"; }
            case "mini" -> { visible = true; mode = Mode.MINI; return "HUD: mini"; }
            case "compact" -> { visible = true; mode = Mode.COMPACT; return "HUD: compact"; }
            case "full" -> { visible = true; mode = Mode.FULL; return "HUD: full"; }
            default -> { return null; }
        }
    }

    // ================================================================== MINI
    private static int mini(GuiGraphics g, Font font, Data d, int x, int y) {
        String s = String.format(Locale.ROOT, "S%d  W %.0f%%  %s", d.stage(), STATE.winRate * 100,
            d.inEpisode() ? String.format(Locale.ROOT, "%.1fm", STATE.dist) : "idle");
        int w = font.width(s) + PAD * 2 + 8;
        HudDraw.panel(g, x, y, w, font.lineHeight + PAD * 2, d.play() ? HudTheme.GREEN : HudTheme.BLUE);
        g.fill(x + PAD, y + PAD + 2, x + PAD + 4, y + PAD + 6, STATE.alertColor(d));
        HudDraw.text(g, font, s, x + PAD + 8, y + PAD, HudTheme.TEXT);
        return y + font.lineHeight + PAD * 2;
    }

    // ================================================================== COMPACT
    /** The default corner widget. @return y just below it. */
    private static int compact(GuiGraphics g, Font font, Data d, int x, int y) {
        int lh = font.lineHeight + 1;
        List<HudState.Alert> alerts = STATE.alerts(d);
        int h = PAD * 2 + lh            // title row
            + 7                          // stage chips
            + 2 * 6 + 2                  // two hp bars
            + 8                          // charge + distance
            + lh                         // win / return / entropy
            + 12                         // sparkline + results
            + lh;                        // ONE fixed status line (first alert, or empty): the panel never changes height
        HudDraw.panel(g, x, y, W, h, d.play() ? HudTheme.GREEN : HudTheme.BLUE);
        int ix = x + PAD, iw = W - PAD * 2, cy = y + PAD;

        // title row: status dot, stage, opponent, mode badge
        g.fill(ix, cy + 2, ix + 4, cy + 6, STATE.alertColor(d));
        HudDraw.text(g, font, "S" + d.stage() + "/" + d.stages(), ix + 8, cy, HudTheme.WHITE);
        String badge = d.play() ? "PLAY" : "TRAIN";
        int bw = font.width(badge) + 6;
        HudDraw.badge(g, font, badge, ix + iw - bw, cy, d.play() ? HudTheme.GREEN : HudTheme.BLUE);
        int nameX = ix + 8 + font.width("S0/0") + 4;
        HudDraw.text(g, font, HudDraw.fit(font, shortName(d.opponent()), ix + iw - bw - 4 - nameX), nameX, cy, HudTheme.DIM);
        cy += lh;

        HudDraw.stageTrack(g, ix, cy + 1, iw, 3, d.stage(), d.stages());
        cy += 7;

        // health: yours on top, the enemy below
        hpBar(g, ix, cy, iw, STATE.myHp, HudTheme.GREEN);
        cy += 7;
        hpBar(g, ix, cy, iw, STATE.oppHp, HudTheme.RED);
        cy += 8;

        // swing charge (left) and distance gauge (right)
        int half = (iw - 4) / 2;
        HudDraw.barMarked(g, ix, cy + 1, half, 3, STATE.charge, STATE.charge >= Config.MIN_ATTACK_STRENGTH ? HudTheme.GREEN : HudTheme.YELLOW, Config.MIN_ATTACK_STRENGTH);
        HudDraw.distance(g, ix + half + 4, cy + 1, half, 3, STATE.dist, 6.0);
        cy += 8;

        // numbers
        String stats = d.hasStats()
            ? String.format(Locale.ROOT, "W%.0f%%  R%+.1f  H%.1f", STATE.winRate * 100, d.ret(), STATE.entropy)
            : "collecting...";
        HudDraw.text(g, font, stats, ix, cy, d.hasStats() ? HudTheme.rateColor(STATE.winRate) : HudTheme.DIM);
        cy += lh;

        // learning curve + last results
        int gw = iw * 55 / 100;
        HudDraw.sparkline(g, ix, cy, gw, 10, d.retHist(), HudTheme.BLUE, true);
        HudDraw.results(g, ix + gw + 4, cy + 1, iw - gw - 4, 8, d.resHist());
        cy += 12;

        if (!alerts.isEmpty()) HudDraw.text(g, font, alerts.get(0).text(), ix, cy, alerts.get(0).color());
        return y + h;
    }

    private static void hpBar(GuiGraphics g, int x, int y, int w, double hp, int base) {
        double frac = HudDraw.clamp(hp / 20.0, 0, 1);
        HudDraw.bar(g, x, y, w, 5, frac, frac > 0.5 ? base : frac > 0.25 ? HudTheme.YELLOW : HudTheme.RED);
        // a darker notch every 5 hp so damage taken per hit is readable at a glance
        for (int i = 1; i < 4; i++) g.fill(x + w * i / 4, y, x + w * i / 4 + 1, y + 5, HudTheme.alpha(0x000000, 0x70));
    }

    private static String shortName(String opp) {
        int i = opp.indexOf(" (");
        String s = i > 0 ? opp.substring(0, i) : opp;
        return s.replace(" + light attacks", "").replace("League / self-play", "League").replace("Strong fighter", "Strong");
    }

    // ================================================================== FULL: detail panel
    private static int detail(GuiGraphics g, Font font, Data d, int x, int y) {
        int lh = font.lineHeight + 2;
        int h = PAD * 2 + lh * 12 + 28;
        HudDraw.panel(g, x, y, W, h, HudTheme.PURPLE);
        int ix = x + PAD, iw = W - PAD * 2, cy = y + PAD;

        HudDraw.text(g, font, "DETAIL", ix, cy, HudTheme.PURPLE);
        HudDraw.textR(g, font, compactNumber(d.ticks()) + " ticks", ix + iw, cy, HudTheme.DIM);
        cy += lh;

        row(g, font, "Episodes / updates", d.episodes() + " / " + d.updates(), HudTheme.TEXT, ix, cy, iw); cy += lh;
        row(g, font, "Win / loss", d.hasStats() ? String.format(Locale.ROOT, "%.0f%% / %.0f%%", d.winRate() * 100, d.lossRate() * 100) : "--",
            HudTheme.rateColor(d.winRate()), ix, cy, iw); cy += lh;
        row(g, font, "HP dealt / taken", d.hasStats() ? String.format(Locale.ROOT, "%.1f / %.1f", d.dealt(), d.taken()) : "--",
            d.dealt() >= d.taken() ? HudTheme.GREEN : HudTheme.ORANGE, ix, cy, iw); cy += lh;
        row(g, font, "Whiff rate", d.hasStats() ? String.format(Locale.ROOT, "%.0f%%", d.whiffRate() * 100) : "--",
            HudTheme.ramp(1 - d.whiffRate()), ix, cy, iw); cy += lh;
        row(g, font, "Crit / sprint hits", d.hasStats() ? String.format(Locale.ROOT, "%.0f%% / %.0f%%", d.critShare() * 100, d.sprintShare() * 100) : "--",
            HudTheme.TEXT, ix, cy, iw); cy += lh;
        row(g, font, "Aim error", String.format(Locale.ROOT, "%+.0f / %+.0f deg", STATE.yawErr, STATE.pitchErr),
            HudTheme.aimColor(STATE.yawErr, STATE.pitchErr), ix, cy, iw); cy += lh;
        row(g, font, "Entropy", String.format(Locale.ROOT, "%.2f", d.entropy()), HudTheme.entropyColor(d.entropy()), ix, cy, iw); cy += lh;
        row(g, font, "Shaping / engaged", String.format(Locale.ROOT, "%.0f%% / %.0f%%", d.shaping() * 100, d.idleScale() * 100),
            d.idleScale() > 0.5 ? HudTheme.TEXT : HudTheme.ORANGE, ix, cy, iw); cy += lh;
        row(g, font, "Rollbacks", String.valueOf(d.rollbacks()), d.rollbacks() == 0 ? HudTheme.TEXT : HudTheme.ORANGE, ix, cy, iw); cy += lh;
        row(g, font, "Locked", HudDraw.fit(font, d.locks(), iw - font.width("Locked") - 6), d.lockBits() == 0 ? HudTheme.GREEN : HudTheme.ORANGE, ix, cy, iw); cy += lh;

        HudDraw.text(g, font, "Entropy (guide = floor)", ix, cy, HudTheme.DIM); cy += lh - 2;
        HudDraw.lineGraph(g, ix, cy, iw, 12, d.entHist(), 0, Math.max(6, STATE.entropy * 1.2), HudTheme.CYAN, Trainer.entropyFloorNow);
        cy += 14;
        HudDraw.bar(g, ix, cy + 1, iw, 3, d.progress(), HudTheme.BLUE);
        return y + h;
    }

    private static void row(GuiGraphics g, Font font, String label, String value, int color, int x, int y, int w) {
        HudDraw.text(g, font, label, x, y, HudTheme.DIM);
        HudDraw.textR(g, font, value, x + w, y, color);
    }

    private static String compactNumber(long n) {
        if (n >= 1_000_000) return String.format(Locale.ROOT, "%.2fM", n / 1_000_000.0);
        if (n >= 10_000) return String.format(Locale.ROOT, "%.1fk", n / 1000.0);
        return String.valueOf(n);
    }

    // ================================================================== toast
    private static void toast(GuiGraphics g, Font font, int sw, int sh) {
        if (!STATE.toastActive()) return;
        int a = STATE.toastAlpha();
        String t = STATE.toastText();
        int w = font.width(t) + 14, x = (sw - w) / 2, y = sh - 62;
        g.fill(x, y, x + w, y + font.lineHeight + 8, HudTheme.alpha(0x101018, Math.min(0xB0, a)));
        g.fill(x, y, x + w, y + 1, HudTheme.alpha(STATE.toastColor(), a));
        g.drawString(font, t, x + 7, y + 5, HudTheme.alpha(STATE.toastColor(), Math.max(a, 0x20)), true);
    }
}