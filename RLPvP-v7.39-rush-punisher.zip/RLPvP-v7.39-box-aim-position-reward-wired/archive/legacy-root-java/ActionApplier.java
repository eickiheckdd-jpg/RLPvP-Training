package com.rlpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Applies the sampled PPO action to YOUR real client player, the same way a human would:
 *  - Looking: continuous clamped yaw/pitch deltas per tick (like moving the mouse), no snapping.
 *  - Movement, jump, sprint: presses and releases the real W/A/S/D/Space/Sprint key bindings.
 *  - Attack: a normal left click on whatever the crosshair is on (so reach and aim matter),
 *    only when the weapon cooldown is charged. The swing always happens when the agent chooses to
 *    attack: a whiff swings at the air and costs the cooldown, like a real miss.
 */
final class ActionApplier {
    /** Results of apply(): what the attack head did this tick. */
    static final int SWING_NONE = 0;        // agent did not attack (or cooldown not charged)
    static final int SWING_HIT_TARGET = 1;  // crosshair was on the target: a real hit
    static final int SWING_HIT_OTHER = 2;   // crosshair was on some other entity
    static final int SWING_MISS = 3;        // swung at nothing

    /**
     * @param minCharge weapon charge needed before an attack click is sent (Config.MIN_ATTACK_STRENGTH, lowered from GATE_RELAX_STAGE)
     * @return one of the SWING_* codes for this tick's attack.
     */
    int apply(Minecraft mc, LocalPlayer me, float[] a, Entity target, float minCharge) {
        GlideReal.finish(me); // real-rotation mode: complete the last curve first, so the attack ray, the look step and the policy all start on the exact end angles of the last tick
        // a = {yaw delta, pitch delta (normalised mouse deltas), fwd (0 back/1 none/2 forward), strafe (0 left/1 none/2 right), attack, jump, sprint}
        int fwd = Math.round(a[2]) - 1;       // -1 back, 0 none, 1 forward
        int strafe = Math.round(a[3]) - 1;    // -1 left, 0 none, 1 right
        boolean attack = a[4] == 1;
        boolean jump = a[5] == 1;
        boolean sprint = a[6] == 1;
        boolean sneak = a.length > 7 && a[7] == 1; // sneak head (stage 6+); sneaking stops sprinting

        // ---- keys ----
        Options o = mc.options;
        o.keyUp.setDown(fwd > 0);
        o.keyDown.setDown(fwd < 0);
        o.keyLeft.setDown(strafe < 0);
        o.keyRight.setDown(strafe > 0);
        o.keyJump.setDown(jump);
        o.keySprint.setDown(sprint && fwd > 0 && !sneak);
        o.keyShift.setDown(sneak);

        // ---- attack (uses what the crosshair is on right now, before this tick's turn) ----
        // The target is tested with our own ray from the current eye position and rotation. mc.hitResult is
        // computed during rendering, so it can lag the rotation we set last tick (and depends on the frame rate).
        int result = SWING_NONE;
        if (attack && mc.gameMode != null && me.getAttackStrengthScale(0.5f) >= minCharge) {
            Entity hit = null;
            if (target != null && crosshairOn(me, target)) {
                hit = target;
            } else if (mc.hitResult instanceof EntityHitResult ehr && ehr.getEntity() != target) {
                hit = ehr.getEntity();
            }
            if (hit != null) {
                mc.gameMode.attack(me, hit);
                me.swing(InteractionHand.MAIN_HAND);
                result = hit == target ? SWING_HIT_TARGET : SWING_HIT_OTHER;
            } else {
                me.swing(InteractionHand.MAIN_HAND); // always swing when the agent chooses to attack
                me.resetAttackStrengthTicker();      // a whiff spends the cooldown, like a real click on air
                result = SWING_MISS;
            }
        }

        // ---- look ---- (all the maths is in GameplayRotation, shared with the simulator)
        double cy = filter(CameraMap.apply(GameplayRotation.sane(a[0])) * Config.YAW_SCALE, 0), cp = filter(CameraMap.apply(GameplayRotation.sane(a[1])) * Config.PITCH_SCALE, 1);
        float oldYaw = me.getYRot();
        float oldPitch = me.getXRot();
        rot.stepEffort(cy, cp, oldYaw, me.getXRot(), aimYawErr, aimPitchErr, aimErrKnown, aimPitchFree, Config.AIM_BRAKE);
        lastYawDelta = rot.dYaw;
        lastPitchDelta = rot.dPitch;
        GlideCamera.push(rot.dYaw, rot.yaw.vel(), rot.dPitch, rot.pitch.vel()); // display only: smooth curve between ticks (mixin EntityViewMixin)
        float wrapShift = rot.newYaw - (oldYaw + rot.dYaw); // multiple of 360 when yaw wrapped; apply it to yRotO too, so vanilla interpolates the short way
        me.setYRot(rot.newYaw);
        me.yRotO += wrapShift;
        me.setXRot(rot.newPitch);
        GlideCamera.markReal(oldYaw, oldPitch, rot.newYaw, rot.newPitch); // real-rotation mode: the frames until the next tick follow the curve (no-op when off)
        // NOTE: the per-tick delta is deliberately NOT added to yRotO / xRotO (no rendering changes here). Vanilla copies yRot into yRotO
        // at the start of every tick by itself.

        return result;
    }

    private final GameplayRotation rot = new GameplayRotation();
    private double aimYawErr, aimPitchErr;
    private boolean aimPitchFree, aimErrKnown;

    /** Yaw / pitch error to the enemy in degrees as the policy observes it (frame features 13 / 14); call before apply() each tick. */
    void setAimError(double yawErrDeg, double pitchErrDeg, boolean pitchFree) {
        aimYawErr = yawErrDeg; aimPitchErr = pitchErrDeg; aimPitchFree = pitchFree; aimErrKnown = true;
    }
    /** No enemy error known (the camera brake then assumes a free look). */
    void noAimError() { aimErrKnown = false; }
    private float lastYawDelta, lastPitchDelta;

    /** Stale observation / lost target this tick: no new effort, the mouse brakes smoothly (call instead of apply() for the look part). */
    void holdCamera(LocalPlayer me) {
        GlideReal.finish(me);
        float oldYaw = me.getYRot(), oldPitch = me.getXRot();
        rot.hold(oldYaw, oldPitch);
        GlideCamera.push(rot.dYaw, rot.yaw.vel(), rot.dPitch, rot.pitch.vel());
        me.setYRot(rot.newYaw);
        me.yRotO += rot.newYaw - (oldYaw + rot.dYaw);
        me.setXRot(rot.newPitch);
        GlideCamera.markReal(oldYaw, oldPitch, rot.newYaw, rot.newPitch);
    }

    /** Camera velocity state after the last apply(), normalised by the axis maximum speed (-1..1). */
    float velYawNorm() { return (float) (rot.yaw.vel() / Config.YAW_SCALE); }

    float velPitchNorm() { return (float) (rot.pitch.vel() / Config.PITCH_SCALE); }

    /** Degrees the camera actually turned in the last apply(). */
    float yawDelta() { return lastYawDelta; }

    float pitchDelta() { return lastPitchDelta; }

    private final float[][] lookState = new float[Math.max(1, Config.LOOK_SMOOTH_POLES)][2]; // [pole][yaw, pitch]

    /** Optional camera smoothing, see Config.LOOK_SMOOTH. axis 0 = yaw, 1 = pitch. */
    private float filter(float in, int axis) {
        if (Config.LOOK_SMOOTH >= 0.999f) return in;
        float x = in;
        for (float[] pole : lookState) {
            pole[axis] += Config.LOOK_SMOOTH * (x - pole[axis]);
            x = pole[axis];
        }
        return x;
    }

    /** True if a ray from my eyes along my view direction hits the entity's hitbox within vanilla reach, with nothing solid between. */
    private static boolean crosshairOn(LocalPlayer me, Entity e) {
        Vec3 eye = me.getEyePosition();
        Vec3 end = eye.add(me.getViewVector(1.0f).scale(Config.ATTACK_REACH));
        AABB box = e.getBoundingBox().inflate(e.getPickRadius());
        boolean onBox = box.contains(eye) || box.clip(eye, end).isPresent();
        return onBox && me.hasLineOfSight(e);
    }

    /** Let go of every key the agent might be holding. */
    void release(Minecraft mc) {
        for (float[] pole : lookState) { pole[0] = 0f; pole[1] = 0f; } // a new fight starts with a still camera
        rot.reset();
        GlideCamera.reset();
        aimErrKnown = false;
        Options o = mc.options;
        if (o == null) return;
        o.keyUp.setDown(false);
        o.keyDown.setDown(false);
        o.keyLeft.setDown(false);
        o.keyRight.setDown(false);
        o.keyJump.setDown(false);
        o.keySprint.setDown(false);
        o.keyShift.setDown(false);
    }
}