package com.rlpvp;

/**
 * Predictive braking for the physical mouse. The camera may only push toward the target if, after this tick's push, it can still stop
 * inside the angle that is left. "Can still stop" is computed with the REAL controller (CameraDynamics.predictMaxTravel: same
 * acceleration limit, jerk limit and drag, including the ticks the jerk limit needs to build up braking force), not with a
 * constant-deceleration formula. Earlier versions used vSafe = sqrt(2*aDec*err), which ignores the jerk-limited build-up and
 * overshot by tens of degrees.
 *
 * It never invents a target: the error is the yaw/pitch error the policy already observes (frame features 13 / 14). It never limits
 * movement away from the target, so the policy can always turn back and track a moving enemy.
 *
 * Order of attempts each tick (all cheap, a handful of 4-substep integrations):
 *   1. the policy's command if the stop-travel fits in |error| + slack;
 *   2. the same command scaled by 1/2, 1/4, 1/8 (smaller push, still toward the target: fine aiming without a dead zone);
 *   3. braking effort 0 (drag only), 1/8, 1/4, 1/2 of full: the gentlest one that still stops in time;
 *   4. full braking effort.
 * Pure Java, no game classes, no allocation. Used identically by PvpSim (training/eval) and ActionApplier (play).
 */
final class AimBrake {
    private AimBrake() {}

    /** Overshoot we tolerate before braking (degrees): keeps fine corrections from freezing in a Zeno approach. Production value from Config. */
    static double slackDeg = Config.AIM_BRAKE_SLACK_DEG;

    /**
     * @param cmd    hand effort after CameraMap, deg/tick units (what CameraDynamics.step receives)
     * @param dyn    this axis' controller (its state is read, not changed)
     * @param errDeg signed error to the target on this axis; positive = the target is in the positive turning direction
     * @param scale  axis maximum speed (Config.YAW_SCALE / PITCH_SCALE)
     * @return command to give to dyn.step()
     */
    static double limit(double cmd, CameraDynamics dyn, double errDeg, double scale) {
        return limit(cmd, dyn, errDeg, scale, 0.0);
    }

    /**
     * Same, with the target's own angular speed on this axis (deg/tick, positive = toward increasing angle), estimated by GameplayRotation from the
     * change of the observed error. A target moving AWAY from the camera gives AIM_BRAKE_TRACK_TICKS ticks of its own travel as extra room, so the
     * brake no longer holds back a camera chasing a hopping / strafing enemy. A target moving toward the camera never shrinks the room.
     */
    static double limit(double cmd, CameraDynamics dyn, double errDeg, double scale, double targetVel) {
        if (!Double.isFinite(cmd)) return 0.0;
        cmd = Math.max(-scale, Math.min(scale, cmd));
        if (!Double.isFinite(errDeg)) return cmd;
        double dir = Math.signum(errDeg), room = Math.abs(errDeg) + slackDeg;
        if (Double.isFinite(targetVel)) room += Math.max(0.0, targetVel * dir) * Config.AIM_BRAKE_TRACK_TICKS;
        if (dir == 0.0) return cmd;
        if (dyn.predictMaxTravel(cmd, scale, dir) <= room) return cmd;      // 1. safe as asked (also true when moving away: travel is negative)
        double c = cmd;
        for (int i = 0; i < 3; i++) {                                         // 2. a smaller push toward the target
            c *= 0.5;
            if (c * dir > 0.0 && dyn.predictMaxTravel(c, scale, dir) <= room) return c;
        }
        // 3. brake, as gently as still stops in time (full effort would also stop, but its build-up keeps pushing after the mouse has
        //    stopped and swings the camera back across the target)
        double bdir = -dir; // against the direction of the target: brakes motion toward it, also acceleration that is still building toward it
        for (double f = 0.0; f < 0.99; f = f == 0.0 ? 0.125 : f * 2.0) {
            double cb = bdir * scale * f;
            if (cb != 0.0 && dyn.predictMaxTravel(cb, scale, dir) <= room) return cb;
            if (cb == 0.0 && dyn.predictMaxTravel(0.0, scale, dir) <= room) return 0.0;
        }
        return bdir * scale; // nothing is gentle enough: brake as hard as the hand can
    }
}
