package com.rlpvp;

/** Colours and colour maths for the HUD. ARGB ints, no Minecraft classes. */
final class HudTheme {
    private HudTheme() {}

    static final int WHITE = 0xFFFFFFFF;
    static final int TEXT = 0xFFE6E8F0;
    static final int DIM = 0xFF8C93A8;
    static final int FAINT = 0xFF4A5068;
    static final int GREEN = 0xFF55FF77;
    static final int LIME = 0xFFB6F26A;
    static final int YELLOW = 0xFFFFDD55;
    static final int ORANGE = 0xFFFFAA33;
    static final int RED = 0xFFFF5566;
    static final int BLUE = 0xFF55AAFF;
    static final int CYAN = 0xFF55E6E6;
    static final int PURPLE = 0xFFB088FF;
    static final int PANEL_BG = 0xB0101018;
    static final int PANEL_EDGE = 0xFF2A3050;
    static final int TRACK = 0xFF23283C;
    static final int GRAPH_BG = 0xFF171B2B;

    static int alpha(int rgb, int a) {
        return ((Math.max(0, Math.min(255, a))) << 24) | (rgb & 0xFFFFFF);
    }

    /** Linear blend between two colours, t in 0..1. */
    static int lerp(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    /** Red (0) -> yellow (0.5) -> green (1). */
    static int ramp(double t) {
        t = Math.max(0, Math.min(1, t));
        return t < 0.5 ? lerp(RED, YELLOW, t * 2) : lerp(YELLOW, GREEN, (t - 0.5) * 2);
    }

    static int hpColor(double frac) {
        return frac > 0.5 ? GREEN : frac > 0.25 ? YELLOW : RED;
    }

    /** Entropy below the anti-collapse floor is a warning; very high means still exploring. */
    static int entropyColor(double e) {
        return e >= Trainer.entropyFloorNow ? GREEN : e >= Trainer.entropyFloorNow * 0.6 ? YELLOW : RED;
    }

    static int rateColor(double r) {
        return r >= 0.5 ? GREEN : r >= 0.25 ? YELLOW : RED;
    }

    /** Green inside sword reach, yellow just outside, red far away. */
    static int distColor(double dist) {
        return dist <= Config.ATTACK_REACH ? GREEN : dist <= Config.RETREAT_MAX ? YELLOW : RED;
    }

    /** Aim quality from yaw/pitch error in degrees (pitch counts a bit more, the hitbox is shorter than it is wide). */
    static int aimColor(double yawDeg, double pitchDeg) {
        double e = Math.max(Math.abs(yawDeg), Math.abs(pitchDeg) * 1.5);
        return e <= 6 ? GREEN : e <= 20 ? YELLOW : RED;
    }
}