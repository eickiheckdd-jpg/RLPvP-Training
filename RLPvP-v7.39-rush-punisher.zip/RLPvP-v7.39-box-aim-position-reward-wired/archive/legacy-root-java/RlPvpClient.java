package com.rlpvp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.resources.Identifier;

public class RlPvpClient implements ClientModInitializer {
    static final Trainer TRAINER = new Trainer();

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(TRAINER::tick);

        // "/rl ..." is handled on the client and never sent to the server.
        ClientSendMessageEvents.ALLOW_COMMAND.register(command -> !RlCommands.intercept(command));

        // Opponent (Carpet bot) logic runs on the integrated server thread; it does nothing unless a
        // singleplayer training episode is active.
        ServerTickEvents.END_SERVER_TICK.register(TRAINER.bots::serverTick);

        // Status panel, top-left. Toggle with /rl hud.
        // (HudRenderCallback is deprecated since Fabric API 0.116; HudElementRegistry is the supported way.)
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
            Identifier.fromNamespaceAndPath("rlpvp", "status"), (graphics, tickCounter) -> RlHud.render(graphics));

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> TRAINER.saveNow());
    }
}