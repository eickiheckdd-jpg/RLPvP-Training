package com.rlpvp;

/**
 * Shared result classification for the simulator and the Minecraft client.
 * A TIMEOUT is a time-limit truncation (bootstrap from the critic); deaths are true terminals.
 * Uncredited opponent deaths and aborted episodes are no-contests and must not affect curriculum/guard metrics.
 */
enum EpisodeOutcome {
    WIN, LOSS, MUTUAL_KO, TIMEOUT, OPP_DIED_UNCREDITED, ABORTED;

    static EpisodeOutcome classify(boolean meDead, boolean oppDead, boolean killCredited, boolean timeout) {
        if (meDead && oppDead) return MUTUAL_KO;
        if (meDead) return LOSS;
        if (oppDead) return killCredited ? WIN : OPP_DIED_UNCREDITED;
        return timeout ? TIMEOUT : ABORTED;
    }

    boolean win() { return this == WIN; }
    boolean loss() { return this == LOSS; }
    boolean draw() { return this == MUTUAL_KO || this == TIMEOUT; }
    boolean noContest() { return this == OPP_DIED_UNCREDITED || this == ABORTED; }
    /** True if no future reward should be bootstrapped from the next state. */
    boolean terminal() { return this == WIN || this == LOSS || this == MUTUAL_KO || this == OPP_DIED_UNCREDITED; }
}
