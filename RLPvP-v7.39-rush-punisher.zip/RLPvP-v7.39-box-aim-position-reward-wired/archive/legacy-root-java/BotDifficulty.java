package com.rlpvp;

/**
 * Adaptive opponent strength 0..1 for BotAI. Raised when the agent beats the scripted fighters, lowered when it is crushed, so the
 * opponent keeps pace with the agent instead of being either a wall (stage 7 used to stall) or a pushover that a single habit beats.
 * Only scripted-fighter episodes are reported (never frozen self-play snapshots). Minecraft-free; not saved (it re-adapts within ~100 episodes).
 */
final class BotDifficulty {
    static final double START = 0.0, MIN = 0.0, MAX = 1.0, STEP = 0.05;
    static final int WINDOW = 12;
    static final double RAISE_ABOVE = 0.65, LOWER_BELOW = 0.35;

    private double d = START;
    private int n, wins;

    double value() {
        return d;
    }

    void set(double v) {
        d = Math.max(MIN, Math.min(MAX, v));
    }

    void report(boolean agentWon) {
        n++;
        if (agentWon) wins++;
        if (n < WINDOW) return;
        double wr = wins / (double) n;
        if (wr > RAISE_ABOVE) d = Math.min(MAX, d + STEP);
        else if (wr < LOWER_BELOW) d = Math.max(MIN, d - STEP);
        n = wins = 0;
    }
}
