package com.rlpvp;

import java.lang.reflect.Method;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * Drives a Carpet fake player from the integrated server thread.
 *
 * Preferred: call Carpet's EntityPlayerActionPack directly (found by reflection, so this mod has no
 * compile-time dependency on Carpet or on a Carpet fork). If that is not reachable, or any call
 * fails, it falls back to "/player <name> ..." commands. It never throws: problems are logged once.
 * Looking is always set directly on the entity, which is exactly what Carpet's own look does.
 */
final class CarpetController {
    private boolean reflectTried;
    private boolean direct;
    private Method getActionPack;
    private Method setForward;
    private Method setStrafing;
    private Method setSprinting;
    private Method start;
    private Method onceFactory;
    private Object typeAttack;
    private Object typeJump;

    // command fallback state (only re-send movement when it changed)
    private int lastFwd = 99;
    private int lastStrafe = 99;

    /** fwd: -1 back, 0 none, 1 forward. strafe: -1 left, 0 none, 1 right. */
    void apply(MinecraftServer server, ServerPlayer bot, int fwd, int strafe,
               boolean sprint, boolean jump, boolean attack) {
        if (!reflectTried) initReflection(bot);
        if (direct) {
            try {
                Object pack = getActionPack.invoke(bot);
                setForward.invoke(pack, (float) fwd);
                setStrafing.invoke(pack, (float) -strafe); // Carpet: +1 = left
                setSprinting.invoke(pack, sprint && fwd > 0);
                if (jump && bot.onGround()) start.invoke(pack, typeJump, onceFactory.invoke(null));
                if (attack) start.invoke(pack, typeAttack, onceFactory.invoke(null));
                return;
            } catch (ReflectiveOperationException | RuntimeException e) {
                direct = false;
                Trainer.LOG.warn("rlpvp: direct Carpet control failed ({}); using /player commands instead", e.toString());
            }
        }
        applyCommands(server, bot, fwd, strafe, sprint, jump, attack);
    }

    /** Release everything the bot might be holding. */
    void stop(MinecraftServer server, ServerPlayer bot) {
        if (!reflectTried) initReflection(bot);
        lastFwd = 99;
        lastStrafe = 99;
        if (direct) {
            try {
                Object pack = getActionPack.invoke(bot);
                setForward.invoke(pack, 0f);
                setStrafing.invoke(pack, 0f);
                setSprinting.invoke(pack, false);
                return;
            } catch (ReflectiveOperationException | RuntimeException e) {
                direct = false;
            }
        }
        run(server, "player " + bot.getScoreboardName() + " stop");
    }

    /** Sets the bot's rotation directly (same thing Carpet's /player look does). */
    static void look(ServerPlayer bot, float yaw, float pitch) {
        bot.setYRot(yaw);
        bot.setXRot(pitch);
        bot.setYHeadRot(yaw);
    }

    static void run(MinecraftServer server, String command) {
        try {
            CommandSourceStack src = server.createCommandSourceStack().withSuppressedOutput();
            server.getCommands().performPrefixedCommand(src, command);
        } catch (RuntimeException e) {
            Trainer.LOG.warn("rlpvp: command '{}' failed: {}", command, e.toString());
        }
    }

    // ------------------------------------------------------------------ internals
    private void initReflection(ServerPlayer bot) {
        reflectTried = true;
        try {
            Class<?> pack = Class.forName("carpet.helpers.EntityPlayerActionPack");
            Class<?> type = Class.forName("carpet.helpers.EntityPlayerActionPack$ActionType");
            Class<?> action = Class.forName("carpet.helpers.EntityPlayerActionPack$Action");
            getActionPack = bot.getClass().getMethod("getActionPack");
            setForward = pack.getMethod("setForward", float.class);
            setStrafing = pack.getMethod("setStrafing", float.class);
            setSprinting = pack.getMethod("setSprinting", boolean.class);
            start = pack.getMethod("start", type, action);
            onceFactory = action.getMethod("once");
            typeAttack = type.getField("ATTACK").get(null);
            typeJump = type.getField("JUMP").get(null);
            direct = getActionPack.invoke(bot) != null;
            if (direct) Trainer.LOG.info("rlpvp: controlling the bot through Carpet's action pack directly");
        } catch (ReflectiveOperationException | RuntimeException | LinkageError e) {
            direct = false;
            Trainer.LOG.warn("rlpvp: Carpet action pack not reachable ({}); using /player commands", e.toString());
        }
    }

    private void applyCommands(MinecraftServer server, ServerPlayer bot, int fwd, int strafe,
                               boolean sprint, boolean jump, boolean attack) {
        String n = bot.getScoreboardName();
        if (fwd != lastFwd || strafe != lastStrafe) {
            run(server, "player " + n + " stop");
            if (fwd > 0) run(server, "player " + n + " move forward");
            else if (fwd < 0) run(server, "player " + n + " move backward");
            if (strafe < 0) run(server, "player " + n + " move left");
            else if (strafe > 0) run(server, "player " + n + " move right");
            lastFwd = fwd;
            lastStrafe = strafe;
        }
        boolean sprinting = bot.isSprinting();
        if (sprint && fwd > 0 && !sprinting) run(server, "player " + n + " sprint");
        else if ((!sprint || fwd <= 0) && sprinting) run(server, "player " + n + " unsprint");
        if (jump && bot.onGround()) run(server, "player " + n + " jump once");
        if (attack) run(server, "player " + n + " attack once");
    }
}