package com.rlpvp;

/**
 * One axis of a virtual physical mouse: policy output is hand effort, not an angle teleport or a camera target.
 *
 * The output acts like a force on the mouse/hand. A drag term opposes the current motion, acceleration is bounded, and acceleration
 * changes are jerk-limited. Velocity is integrated into relative mouse displacement; that displacement is converted to camera degrees
 * using the same axis scale used by the policy. When the hand stops pushing, drag gradually stops the mouse instead of snapping it to rest.
 * A command reversal first brakes existing motion and then accelerates in the opposite direction.
 *
 *     aTarget = drive * maxAcceleration - mouseDrag * velocity
 *     |a| <= CAM_ACC_MAX_FRAC * scale
 *     |change of a per tick| <= CAM_JERK_MAX_FRAC * scale
 *     |v| <= scale
 *
 * `scale` is the maximum camera-equivalent mouse speed (deg/tick). Four substeps are used so acceleration and displacement are integrated
 * smoothly within the 20 Hz policy loop. This class is shared by the client, self-play and offline simulator. Pure Java, no game classes.
 *
 * This changes action semantics from v9's spring/damper velocity-following controller: the policy must be trained with this controller.
 */
final class CameraDynamics {
    private final boolean enabled;
    private final double accFrac, jerkFrac, mouseDrag;
    private final int substeps;
    private double v, a, jerk;

    CameraDynamics() {
        this(Config.CAMERA_DYNAMICS, Config.CAM_ACC_MAX_FRAC, Config.CAM_JERK_MAX_FRAC,
                Config.CAM_MOUSE_DRAG, Config.CAM_SUBSTEPS);
    }

    /** Custom parameters for tests/experiments. */
    CameraDynamics(boolean enabled, double accFrac, double jerkFrac, double mouseDrag, int substeps) {
        this.enabled = enabled;
        this.accFrac = Math.max(0.0, accFrac);
        this.jerkFrac = Math.max(0.0, jerkFrac);
        this.mouseDrag = Math.max(0.0, mouseDrag);
        this.substeps = Math.max(1, substeps);
    }

    /** A new episode starts with the hand and mouse at rest. */
    void reset() {
        v = a = jerk = 0.0;
    }

    /** A hard pitch stop: kill movement so the controller does not keep pushing against the stop. */
    void halt() {
        v = a = jerk = 0.0;
    }

    /** Actual camera-equivalent mouse velocity after the last tick, in deg/tick. */
    double vel() { return v; }

    /** Mouse acceleration after the last tick, in deg/tick^2. */
    double acc() { return a; }

    /** Tick-to-tick change in acceleration, in deg/tick^3. */
    double lastJerk() { return jerk; }

    /**
     * Advance one policy tick.
     * @param cmd normalized hand effort in [-scale, scale], after CameraMap; not an instantaneous camera turn
     * @param scale maximum camera-equivalent mouse speed (Config.YAW_SCALE or Config.PITCH_SCALE)
     * @return relative mouse displacement expressed as camera rotation in degrees for this tick
     */
    double step(double cmd, double scale) {
        if (!(scale > 0.0) || !Double.isFinite(scale)) {
            reset();
            return 0.0;
        }
        cmd = Math.max(-scale, Math.min(scale, cmd));
        if (!enabled) {
            // Diagnostic fallback only: bypass physical mouse dynamics and apply an immediate relative step.
            v = cmd;
            a = jerk = 0.0;
            return v;
        }

        double turned = integrate(cmd / scale, scale, v, a);
        jerk = sa - a;
        v = sv; a = sa;
        return turned;
    }

    /** Gain of the velocity-nulling brake assumed by predictMaxTravel (Config.CAM_STOP_GAIN; package-private so sim/AimProbe can sweep it). */
    static double stopGain = Config.CAM_STOP_GAIN;

    // scratch results of integrate(): no allocation per tick
    private double sv, sa;

    /** One policy tick from state (v0, a0) with hand drive in [-1, 1]; writes the end state to sv/sa and returns the displacement. Does not touch v/a/jerk. */
    private double integrate(double drive, double scale, double v0, double a0) {
        final double dt = 1.0 / substeps;
        final double accMax = accFrac * scale;
        final double jerkStep = jerkFrac * scale * dt;
        double vv = v0, aa = a0, turned = 0.0;
        for (int i = 0; i < substeps; i++) {
            // The hand pushes in the requested direction; surface/hand drag opposes motion.
            double aTarget = drive * accMax - mouseDrag * vv;
            aTarget = Math.max(-accMax, Math.min(accMax, aTarget));
            // The hand cannot instantaneously change its applied force: limit how quickly acceleration changes.
            double aNew = aa + Math.max(-jerkStep, Math.min(jerkStep, aTarget - aa));
            aNew = Math.max(-accMax, Math.min(accMax, aNew));
            double vNew = vv + aNew * dt;
            if (Math.abs(vNew) > scale) vNew = Math.copySign(scale, vNew);
            turned += 0.5 * (vv + vNew) * dt; // trapezoidal integration of the mouse travel
            vv = vNew;
            aa = aNew;
        }
        sv = vv; sa = aa;
        return turned;
    }

    /**
     * Furthest the camera gets in direction `dir` (+1/-1, in degrees from now) if this tick's command is `cmd` and the hand afterwards
     * plays a velocity-nulling brake (effort = -CAM_STOP_GAIN * velocity) for up to 30 ticks. It runs the exact same integration as
     * step() (acceleration, jerk limit, drag), so it includes the ticks the jerk limit needs to build up braking force AND the extra
     * travel from acceleration that is still being unwound after the speed has reached zero. Pure prediction: state is not changed.
     */
    double predictMaxTravel(double cmd, double scale, double dir) {
        if (!enabled) return Math.max(-scale, Math.min(scale, cmd)) * dir;
        double pos = integrate(Math.max(-1.0, Math.min(1.0, cmd / scale)), scale, v, a);
        double best = pos * dir;
        for (int i = 0; i < 30; i++) {
            if (Math.abs(sv) < 1e-3 && Math.abs(sa) < 1e-3) break;
            pos += integrate(Math.max(-1.0, Math.min(1.0, -stopGain * sv / scale)), scale, sv, sa);
            double p = pos * dir;
            if (p > best) best = p;
        }
        return best;
    }
}
