package com.rlpvp;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Drawing primitives and small widgets for the HUD. Only uses GuiGraphics.fill / drawString so it survives version bumps. */
final class HudDraw {
    private HudDraw() {}

    // ------------------------------------------------------------------ text
    static void text(GuiGraphics g, Font f, String s, int x, int y, int color) {
        g.drawString(f, s, x, y, color, true);
    }

    static void textR(GuiGraphics g, Font f, String s, int xRight, int y, int color) {
        g.drawString(f, s, xRight - f.width(s), y, color, true);
    }

    static void textC(GuiGraphics g, Font f, String s, int xCenter, int y, int color) {
        g.drawString(f, s, xCenter - f.width(s) / 2, y, color, true);
    }

    /** Shortens s with an ellipsis so it fits in maxW pixels. */
    static String fit(Font f, String s, int maxW) {
        if (f.width(s) <= maxW) return s;
        String dots = "..";
        int dw = f.width(dots);
        int end = s.length();
        while (end > 0 && f.width(s.substring(0, end)) + dw > maxW) end--;
        return s.substring(0, Math.max(0, end)) + dots;
    }

    // ------------------------------------------------------------------ boxes
    static void panel(GuiGraphics g, int x, int y, int w, int h, int accent) {
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, HudTheme.PANEL_EDGE);
        g.fill(x, y, x + w, y + h, HudTheme.PANEL_BG);
        g.fill(x, y, x + w, y + 1, accent);
    }

    static void outline(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    /** Small filled tag with text, e.g. TRAIN / PLAY. @return the tag width. */
    static int badge(GuiGraphics g, Font f, String s, int x, int y, int color) {
        int w = f.width(s) + 6;
        g.fill(x, y - 1, x + w, y + f.lineHeight, HudTheme.alpha(color, 0x4A));
        text(g, f, s, x + 3, y, color);
        return w;
    }

    // ------------------------------------------------------------------ bars
    static void bar(GuiGraphics g, int x, int y, int w, int h, double frac, int color) {
        g.fill(x, y, x + w, y + h, HudTheme.TRACK);
        int n = (int) Math.round(w * clamp(frac, 0, 1));
        if (n > 0) g.fill(x, y, x + n, y + h, color);
    }

    /** Bar with a vertical marker at mark (0..1), e.g. the 0.9 attack threshold. */
    static void barMarked(GuiGraphics g, int x, int y, int w, int h, double frac, int color, double mark) {
        bar(g, x, y, w, h, frac, color);
        int mx = x + (int) Math.round(w * clamp(mark, 0, 1));
        g.fill(mx, y - 1, mx + 1, y + h + 1, HudTheme.WHITE);
    }

    /** Bar split into n cells; filled cells keep a 1px gap, so it reads well at tiny sizes. */
    static void segmented(GuiGraphics g, int x, int y, int w, int h, int cells, double frac, int color) {
        int gap = 1;
        int cw = Math.max(1, (w - gap * (cells - 1)) / cells);
        int lit = (int) Math.round(clamp(frac, 0, 1) * cells);
        for (int i = 0; i < cells; i++) {
            int cx = x + i * (cw + gap);
            g.fill(cx, y, cx + cw, y + h, i < lit ? color : HudTheme.TRACK);
        }
    }

    /** Two-sided bar from the centre: negative fills left in red, positive fills right in green (range -1..1). */
    static void centered(GuiGraphics g, int x, int y, int w, int h, double v, int neg, int pos) {
        g.fill(x, y, x + w, y + h, HudTheme.TRACK);
        int mid = x + w / 2;
        int n = (int) Math.round(Math.abs(clamp(v, -1, 1)) * (w / 2));
        if (v >= 0) g.fill(mid, y, mid + n, y + h, pos);
        else g.fill(mid - n, y, mid, y + h, neg);
        g.fill(mid, y - 1, mid + 1, y + h + 1, HudTheme.FAINT);
    }

    /**
     * 0..max block distance gauge. Faint green band = the spacing window the reward pays for,
     * white tick = sword reach, coloured marker = the enemy.
     */
    static void distance(GuiGraphics g, int x, int y, int w, int h, double dist, double max) {
        g.fill(x, y, x + w, y + h, HudTheme.TRACK);
        int a = x + (int) (w * Config.SPACING_MIN / max), b = x + (int) (w * Config.SPACING_MAX / max);
        g.fill(a, y, b, y + h, HudTheme.alpha(HudTheme.GREEN, 0x55));
        int reach = x + (int) (w * Config.ATTACK_REACH / max);
        g.fill(reach, y - 1, reach + 1, y + h + 1, HudTheme.WHITE);
        int mx = x + (int) (w * clamp(dist / max, 0, 1));
        g.fill(mx - 1, y - 1, mx + 2, y + h + 1, HudTheme.distColor(dist));
    }

    // ------------------------------------------------------------------ graphs
    /** Column sparkline. zeroLine draws a baseline where 0 sits and colours negative columns red. */
    static void sparkline(GuiGraphics g, int x, int y, int w, int h, float[] v, int color, boolean zeroLine) {
        g.fill(x, y, x + w, y + h, HudTheme.GRAPH_BG);
        if (v == null || v.length < 2) return;
        float lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
        for (float e : v) { lo = Math.min(lo, e); hi = Math.max(hi, e); }
        if (zeroLine) { lo = Math.min(lo, 0f); hi = Math.max(hi, 0f); }
        if (hi - lo < 1e-4f) hi = lo + 1e-4f;
        int n = v.length;
        double colW = (double) w / n;
        int base = y + h - 1;
        int zeroY = base - (int) Math.round((0 - lo) / (hi - lo) * (h - 2));
        if (zeroLine) g.fill(x, zeroY, x + w, zeroY + 1, HudTheme.FAINT);
        for (int i = 0; i < n; i++) {
            int x0 = x + (int) Math.round(i * colW);
            int x1 = Math.max(x0 + 1, x + (int) Math.round((i + 1) * colW) - 1);
            int vy = base - (int) Math.round((v[i] - lo) / (hi - lo) * (h - 2));
            if (zeroLine) g.fill(x0, Math.min(vy, zeroY), x1, Math.max(vy, zeroY) + 1, v[i] < 0 ? HudTheme.RED : color);
            else g.fill(x0, vy, x1, y + h, HudTheme.alpha(color, 0xB0));
        }
    }

    /** Line graph with a fixed value range (lo..hi), e.g. entropy against its floor. floor<0 disables the guide line. */
    static void lineGraph(GuiGraphics g, int x, int y, int w, int h, float[] v, double lo, double hi, int color, double guide) {
        g.fill(x, y, x + w, y + h, HudTheme.GRAPH_BG);
        if (guide >= lo && guide <= hi) {
            int gy = y + h - 1 - (int) Math.round((guide - lo) / (hi - lo) * (h - 2));
            for (int px = x; px < x + w; px += 3) g.fill(px, gy, px + 1, gy + 1, HudTheme.FAINT);
        }
        if (v == null || v.length < 2) return;
        int prev = -1;
        for (int i = 0; i < v.length; i++) {
            int px = x + (int) Math.round((double) i / (v.length - 1) * (w - 1));
            int py = y + h - 1 - (int) Math.round(clamp((v[i] - lo) / (hi - lo), 0, 1) * (h - 2));
            if (prev >= 0) g.fill(px, Math.min(py, prev), px + 1, Math.max(py, prev) + 1, color);
            else g.fill(px, py, px + 1, py + 1, color);
            prev = py;
        }
    }

    /** Last results as small squares: green success (kill / aimed), red loss, grey neither. Newest on the right. */
    static void results(GuiGraphics g, int x, int y, int w, int h, byte[] res) {
        int n = Math.min(res.length, 20);
        int cell = Math.max(2, Math.min(7, (w - (n - 1)) / Math.max(1, Math.min(20, n))));
        for (int i = 0; i < n; i++) {
            byte r = res[res.length - n + i];
            int cx = x + i * (cell + 1);
            g.fill(cx, y, cx + cell, y + h, r > 0 ? HudTheme.GREEN : r < 0 ? HudTheme.RED : HudTheme.FAINT);
        }
    }

    /** One chip per curriculum stage: past = dim blue, current = bright with outline, future = grey. */
    static void stageTrack(GuiGraphics g, int x, int y, int w, int h, int stage, int stages) {
        int gap = 2;
        int cw = Math.max(2, (w - gap * (stages - 1)) / stages);
        for (int i = 1; i <= stages; i++) {
            int cx = x + (i - 1) * (cw + gap);
            int col = i < stage ? HudTheme.alpha(HudTheme.BLUE, 0xA0) : i == stage ? HudTheme.BLUE : HudTheme.TRACK;
            g.fill(cx, y, cx + cw, y + h, col);
            if (i == stage) outline(g, cx - 1, y - 1, cw + 2, h + 2, HudTheme.WHITE);
        }
    }

    // ------------------------------------------------------------------ aim
    /** Dot that shows where the enemy sits relative to the crosshair. Drawn around (cx, cy). */
    static void aimDot(GuiGraphics g, double yawErrDeg, double pitchErrDeg, boolean los, int cx, int cy, int r) {
        double ex = clamp(yawErrDeg / 45.0, -1, 1), ey = clamp(pitchErrDeg / 30.0, -1, 1);
        // Minecraft yaw: a positive error means the enemy is to the left; a positive pitch error means below
        int px = cx + (int) Math.round(-ex * r), py = cy + (int) Math.round(ey * r);
        int ring = r + 3, tick = 3, faint = HudTheme.FAINT;
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sy = -1; sy <= 1; sy += 2) {
                int ox = cx + sx * ring, oy = cy + sy * ring;
                g.fill(Math.min(ox, ox - sx * tick), oy, Math.max(ox, ox - sx * tick) + 1, oy + 1, faint);
                g.fill(ox, Math.min(oy, oy - sy * tick), ox + 1, Math.max(oy, oy - sy * tick) + 1, faint);
            }
        }
        g.fill(px - 1, py - 1, px + 2, py + 2, HudTheme.aimColor(yawErrDeg, pitchErrDeg));
        if (!los) g.fill(cx - 6, cy + ring + 3, cx + 7, cy + ring + 4, HudTheme.RED);
    }

    // ------------------------------------------------------------------ maths
    static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}