package com.rlpvp;

import java.util.Random;

/**
 * Eight-stage curriculum: opponent behaviour, relative reward weights and TEMPORARY action locks.
 * No Minecraft classes here. The bot is never teleported.
 *
 * Progression is PURELY PERFORMANCE BASED (no timers): the agent leaves stage s when its success rate over the last
 * GATE_EPISODES episodes OF THAT STAGE is >= STAGE_GATE_WIN[s] (a full window is the minimum evidence; there is no minimum
 * time and no maximum time, so an unready agent is never pushed forward). From GREEDY_GATE_FROM_STAGE the simulator's
 * play-mode probe must also pass. If a stage is never mastered the agent simply stays there (describe() reports it as stalled).
 * The stage and the tick it was entered are saved with the agent (the tick is informational only).
 *
 * Locks (a locked head is not simulated, and the agent is told via the observation):
 *  1 STATIONARY bot, YAW ONLY: pitch, movement, jump, sprint AND attack locked (pure aiming)
 *  2 STATIONARY bot, + pitch unlocked (reward ramped in), attack still locked
 *  3 CIRCLING bot, yaw + pitch, ATTACK UNLOCKS; movement/jump/sprint still locked
 *  4 circling bot, + forward/back and sprint unlocked; strafe and jump still locked
 *  5 walking bot + light attacks, + strafe unlocked = ALL MOVEMENT free; jump still locked, technique bonuses start
 *  6 same bot, + JUMP unlocked (only after movement has been learned), closeness + progress rewards
 *  7 aggressive bot with realistic (turn-rate limited) aim, spacing + time pressure
 *  8 league: past snapshots of the agent + the strong scripted fighter + the aggressive bot
 */
final class Curriculum {
    static final int STAGES = 9;

    enum Opponent {
        STATIONARY("Stationary"),
        STRAFE("Strafing"),
        WALK("Walking + light attacks"),
        AGGRESSIVE("Aggressive"),
        STRONG("Strong fighter (w-tap, jump-crit, strafe)"),
        ELITE("Elite fighter (spacing, w-tap, jump reset, crits, unpredictable strafe, pressure)"),
        SELF_PLAY("League / self-play");

        final String label;

        Opponent(String label) {
            this.label = label;
        }
    }

    /** Relative multipliers on the dense reward terms. */
    static final class Weights {
        final float facing;
        final float pitch;
        final float closeness;
        final float progress;
        final float spacing;
        final float time;
        /** Multiplier on technique bonuses (crit / sprint hit / combo / first hit / whiff penalty). */
        final float tech;
        /** Multiplier on the timing bonuses (full-charge / reset / punish hits): 0 until the attack gate is relaxed (stage 6). */
        final float late;
        /** Multiplier on the small HP-advantage bonus (stage 7+). */
        final float hpAdv;

        Weights(float facing, float pitch, float closeness, float progress, float spacing, float time, float tech, float late, float hpAdv) {
            this.facing = facing;
            this.pitch = pitch;
            this.closeness = closeness;
            this.progress = progress;
            this.spacing = spacing;
            this.time = time;
            this.tech = tech;
            this.late = late;
            this.hpAdv = hpAdv;
        }
    }

    private static final Weights[] WEIGHTS = {
        new Weights(2.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1f, 0.0f, 0f, 0f), // 1 strong yaw facing only
        new Weights(1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1f, 0.0f, 0f, 0f), // 2 yaw + pitch
        new Weights(1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1f, 0.0f, 0f, 0f), // 3 full aim on a circling bot
        new Weights(1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1f, 0.5f, 0f, 0f), // 4 full aim + forward/back + jump: techniques (crits) start
        new Weights(1.0f, 1.0f, 0.0f, 0.0f, 0.5f, 1f, 1.0f, 0f, 0f), // 5 all movement, spacing starts (half weight)
        new Weights(0.6f, 1.0f, 1.5f, 1.5f, 1.0f, 1f, 1.0f, 1f, 0f), // 6 attack gate relaxed, timing bonuses, full spacing
        new Weights(0.5f, 1.0f, 1.5f, 1.0f, 1.0f, 2f, 1.0f, 1f, 1f), // 7 spacing + time pressure + HP advantage; closeness starts to fade
        new Weights(0.5f, 1.0f, 1.0f, 0.5f, 1.0f, 1f, 1.0f, 1f, 1f), // 8 elite scripted fighter: closeness faded so the agent does not camp face to face
        new Weights(0.5f, 1.0f, 1.0f, 0.5f, 1.0f, 1f, 1.0f, 1f, 1f), // 9 league / self-play (the old stage 8)
    };

    private static final Opponent[] OPPONENT = {
        Opponent.STATIONARY, Opponent.STATIONARY, Opponent.STRAFE, Opponent.STRAFE,
        Opponent.WALK, Opponent.WALK, Opponent.AGGRESSIVE, Opponent.ELITE, Opponent.SELF_PLAY,
    };

    // ------------------------------------------------------------------ static schedule
    static int lockMaskFor(int stage) {
        int m = lockMaskForStage(stage);
        return Config.SNEAK_ENABLED ? m : (m | ActionMask.LOCK_SNEAK);   // v7.20: sneak stays locked unless -Drlpvp.sneak=true
    }

    private static int lockMaskForStage(int stage) {
        final int J = ActionMask.LOCK_JUMP, SP = ActionMask.LOCK_SPRINT, MV = ActionMask.LOCK_MOVEMENT;
        final int A = ActionMask.LOCK_ATTACK, SN = ActionMask.LOCK_SNEAK;
        if (stage <= 1) return ActionMask.LOCK_PITCH | MV | J | SP | A | SN; // aim only: no pitch, no movement, no swinging
        if (stage == 2) return MV | J | SP | A | SN;        // pitch free, still aim only
        if (stage == 3) return MV | J | SP | SN;            // ATTACK UNLOCKS here: circling bot, still no movement
        if (stage == 4) return ActionMask.LOCK_STRAFE | SN;  // forward/back + sprint + JUMP free (jump-crits start here)
        if (stage == 5) return SN;                           // everything but sneak
        return 0;                                            // stage 6+: everything unlocked for good (sneak joins here)
    }

    static Opponent opponentFor(int stage) {
        return OPPONENT[Math.max(1, Math.min(STAGES, stage)) - 1];
    }

    static Weights weightsFor(int stage) {
        return WEIGHTS[Math.max(1, Math.min(STAGES, stage)) - 1];
    }

    // ------------------------------------------------------------------ live state
    private volatile int forced = 0; // 0 = automatic (performance gated)
    private volatile int current = 0;
    private int autoStage = 1;
    private long stageEnter = 0;
    private final boolean[] recent = new boolean[Config.GATE_EPISODES];
    private int recentN = 0;
    private int recentIdx = 0;
    private long episodesInStage = 0;
    private boolean lastReview;                            // the episode in progress replays an earlier stage's opponent: it must not count toward the gate
    private long reviewEpisodes;
    private double hop = 0.0;                              // hop level of the stationary bot (0 = none, 1 = most): rises with success, falls with failure
    private int hopN = 0, hopWins = 0;
    private int hold = 0;                                  // consecutive episodes with the window at/above the gate
    private final int[] collapses = new int[STAGES + 2];   // times stage i collapsed and the agent was sent back (not saved)
    private long boostStart = Long.MIN_VALUE / 2;
    private long pitchRampStart = Long.MIN_VALUE / 2;

    /** Forget the current stage so the next update() re-derives it silently (used when a mode starts). */
    synchronized void restart() {
        current = 0;
        boostStart = Long.MIN_VALUE / 2;
        pitchRampStart = Long.MIN_VALUE / 2;
    }

    /** Restores the saved automatic progress (stage + the learned tick it started at). */
    synchronized void restore(int stage, long enterTicks) {
        autoStage = Math.max(1, Math.min(STAGES, stage));
        stageEnter = enterTicks;
        clearRecent();
    }

    synchronized int autoStage() {
        return autoStage;
    }

    synchronized long stageEnterTicks() {
        return stageEnter;
    }

    private void clearRecent() {
        recentN = 0;
        recentIdx = 0;
        episodesInStage = 0;
        hold = 0;
        hopN = 0;
        hopWins = 0;
    }

    /** Training episode finished: legacy single-threaded path uses the remembered review flag. */
    synchronized void reportEpisode(boolean success) {
        boolean review = lastReview;
        lastReview = false;
        reportEpisode(success, review);
    }

    /**
     * Report one classified, decided episode. Callers in parallel training pass the review flag captured by sampleOpponent(rng, out)
     * for THIS episode; a shared mutable lastReview flag cannot safely associate outcomes with concurrent workers.
     */
    synchronized void reportEpisode(boolean success, boolean review) {
        if (review) { reviewEpisodes++; return; }
        recent[recentIdx] = success;
        recentIdx = (recentIdx + 1) % recent.length;
        recentN = Math.min(recentN + 1, recent.length);
        episodesInStage++;
        adaptHop(success);
        hold = forced == 0 && autoStage < STAGES && windowFull() && gateWinRate() + 1e-6 >= gateFor(autoStage) ? hold + 1 : 0;
    }

    synchronized long episodesInStage() { return episodesInStage; }

    /** How much the stationary bot hops right now, 0..1 (0 outside the hop stages or when BOT_HOP is off). Drives the bot in the simulator and the mod. */
    synchronized double hopLevel() {
        int s = stage();
        return hopStage(s) ? hop : 0.0;
    }

    /** Only the stationary bot hops, so the level only exists (and adapts) in hop stages whose opponent is STATIONARY. */
    private static boolean hopStage(int s) {
        return Config.BOT_HOP && s >= Config.BOT_HOP_MIN_STAGE && s <= Config.BOT_HOP_MAX_STAGE && opponentFor(s) == Opponent.STATIONARY;
    }

    /** Performance-driven difficulty of the pitch task: more hops while the agent keeps succeeding, fewer when it struggles. */
    private void adaptHop(boolean success) {
        if (!hopStage(stage())) return;
        hopN++;
        if (success) hopWins++;
        if (hopN < Config.BOT_HOP_WINDOW) return;
        double rate = hopWins / (double) hopN;
        if (rate >= Config.BOT_HOP_RAISE_AT) hop = Math.min(1.0, hop + Config.BOT_HOP_STEP);
        else if (rate < Config.BOT_HOP_LOWER_AT) hop = Math.max(0.0, hop - Config.BOT_HOP_STEP);
        hopN = 0;
        hopWins = 0;
    }

    /** Stage 2 is only left once the pitch task has been practised at a real level (the gate alone passes at hop level 0 within ~100 episodes). */
    private boolean hopReady() {
        return !hopStage(autoStage) || hop >= Config.BOT_HOP_REQUIRED_LEVEL - 1e-9;
    }

    /** Win rate needed to leave stage s: the configured gate plus a bump for every time the next stage collapsed. */
    static float gateFor(int s, int collapsesOfNext) {
        float bump = Math.min(Config.GATE_BUMP_MAX, Config.GATE_BUMP_PER_COLLAPSE * collapsesOfNext);
        return Math.min(0.95f, Config.STAGE_GATE_WIN[s - 1] + bump);
    }

    private float gateFor(int s) {
        return gateFor(s, s + 1 < collapses.length ? collapses[s + 1] : 0);
    }

    /**
     * The guard found stage {@code autoStage} collapsed: go back one stage (its weights are restored by the guard) and make the
     * promotion out of that stage harder next time. No effect on a forced stage or stage 1. @return true if the stage changed.
     */
    synchronized boolean demote(long ticks) {
        if (forced != 0 || autoStage <= 1) return false;
        collapses[autoStage]++;
        autoStage--;
        stageEnter = ticks;
        clearRecent();
        greedyPass = false;
        return true;
    }

    /** Required share of on-target ticks for an aim-stage success, relaxed while the stage is stalled. */
    synchronized double aimOnTargetFraction() {
        long windows = episodesInStage / Config.AIM_GATE_RELIEF_EPISODES;
        return Math.max(Config.AIM_GATE_FLOOR, Config.AIM_GATE_ON_TARGET - windows * Config.AIM_GATE_RELIEF_STEP);
    }

    /** Aim-stage success of one episode after the acquisition grace period. Shared by the mod (Trainer) and the simulator. */
    synchronized boolean aimSuccess(int onTargetTicks, int ticks) {
        int counted = ticks - Config.AIM_GATE_GRACE_TICKS;
        return counted > 0 && onTargetTicks >= aimOnTargetFraction() * counted;
    }

    /** Win rate over the last GATE_EPISODES episodes of this stage (0 until the window is full). */
    synchronized double gateWinRate() {
        if (recentN < recent.length) return 0.0;
        int c = 0;
        for (boolean b : recent) if (b) c++;
        return c / (double) recent.length;
    }

    /** True once GATE_EPISODES episodes of the current stage have been recorded. */
    synchronized boolean windowFull() {
        return recentN >= recent.length;
    }

    /** Gate check without the sustain requirement / bump (tests, simple callers). */
    static boolean mayAdvance(int s, double winRate, boolean windowFull) {
        return mayAdvance(s, winRate, windowFull, true, true, 0);
    }

    static boolean mayAdvance(int s, double winRate, boolean windowFull, boolean greedyOk) {
        return mayAdvance(s, winRate, windowFull, true, greedyOk, 0);
    }

    /**
     * Performance gate, no timers: a full window of recent episodes at the stage's win rate, HELD for GATE_HOLD_EPISODES more episodes
     * ({@code sustained}), plus the greedy probe from GREEDY_GATE_FROM_STAGE (the jump to the aggressive bots destroyed half-trained
     * policies, and sampled training stats looked fine while the played policy did not fight). The mod leaves greedyOk true.
     * @param collapsesOfNext how often the NEXT stage collapsed; each time raises the required win rate (see gateFor)
     */
    static boolean mayAdvance(int s, double winRate, boolean windowFull, boolean sustained, boolean greedyOk, int collapsesOfNext) {
        if (s >= STAGES || !windowFull || !sustained) return false;
        if (s >= Config.GREEDY_GATE_FROM_STAGE && !greedyOk) return false;
        float gate = gateFor(s, collapsesOfNext);
        return gate <= 0f || winRate + 1e-6 >= gate; // tolerance: 0.60f widens to 0.6000000238, so exactly 18/30 wins used to fail
    }

    private boolean greedyActive;
    private boolean greedyPass;

    /** Offline simulator: the latest probe of the played policy at the current stage. */
    synchronized void setGreedyResult(double hitsPerEpisode, double dealt, double taken) {
        greedyActive = true;
        greedyPass = hitsPerEpisode >= Config.GREEDY_GATE_HITS
            && (current < Config.GREEDY_HARD_FROM_STAGE || dealt >= Config.GREEDY_GATE_DAMAGE_RATIO * taken);
    }

    synchronized boolean greedyOk() {
        return !greedyActive || greedyPass;
    }

    /** /rl stage: 1..8 forces a stage, 0 returns to automatic. */
    synchronized void force(int stage) {
        forced = Math.max(0, Math.min(STAGES, stage));
    }

    synchronized int forcedStage() {
        return forced;
    }

    /** Call every tick with the agent's learned ticks. @return true if the stage changed (announce it). */
    synchronized boolean update(long ticks) {
        if (forced == 0 && hopReady() && mayAdvance(autoStage, gateWinRate(), windowFull(), hold >= Config.GATE_HOLD_EPISODES, greedyOk(), autoStage + 1 < collapses.length ? collapses[autoStage + 1] : 0)) {
            autoStage++;
            stageEnter = ticks;
            clearRecent();
            greedyPass = false; // unknown at the new stage until the next probe
        }
        int s = forced > 0 ? forced : autoStage;
        int old = current;
        if (s == old) return false;
        current = s;
        if (old == 0) {
            return false; // first assignment: nothing to announce, no entropy boost
        }
        if ((lockMaskFor(old) & ~lockMaskFor(s)) != 0) boostStart = ticks; // a lock was just lifted
        if (ActionMask.pitchLocked(lockMaskFor(old)) && !ActionMask.pitchLocked(lockMaskFor(s))) pitchRampStart = ticks; // pitch reward fades in
        if (s == 1) pitchRampStart = Long.MAX_VALUE / 2;                     // back to stage 1: pitch weight 0
        return true;
    }

    /** Current stage 1..8 (0 before the first update). */
    synchronized int stage() {
        return current;
    }

    synchronized int lockMask() {
        return lockMaskFor(Math.max(1, current));
    }

    synchronized Opponent opponent() {
        return opponentFor(Math.max(1, current));
    }

    /** True if no gate has been reached for a long time and the rate is under half of what is needed. */
    synchronized boolean stalled() {
        int s = Math.max(1, current);
        return forced == 0 && s < STAGES && episodesInStage >= Config.STALL_EPISODES && gateWinRate() < 0.5 * gateFor(s);
    }

    /** Share of episodes that replay earlier opponents right now (0 before REVIEW_FROM_STAGE, in the league stage and on a forced stage). */
    synchronized double reviewShare() {
        int s = Math.max(1, current);
        if (forced != 0 || s < Config.REVIEW_FROM_STAGE || s >= STAGES || s - 1 < Config.REVIEW_MIN_STAGE) return 0.0;
        return stalled() ? Config.REVIEW_SHARE_STALLED : Config.REVIEW_SHARE;
    }

    /**
     * Opponent for the next training episode: the current stage's, or (with probability reviewShare()) an earlier stage's, nearest stages most
     * often. Call ONCE per episode; the matching reportEpisode() then ignores review episodes. The action locks stay those of the current stage.
     */
    synchronized Opponent sampleOpponent(java.util.Random rng) {
        return sampleOpponent(rng, null);
    }

    /** Selects an opponent and returns this episode's review flag atomically, safe for parallel simulators sharing one curriculum. */
    synchronized Opponent sampleOpponent(java.util.Random rng, boolean[] reviewOut) {
        lastReview = false;
        double p = reviewShare();
        Opponent picked = opponent();
        if (p > 0 && rng.nextDouble() < p) {
            int s = Math.max(1, current), lo = Config.REVIEW_MIN_STAGE, hi = s - 1;
            double total = 0;
            for (int k = lo; k <= hi; k++) total += 1.0 / (s - k);
            double u = rng.nextDouble() * total;
            int pick = hi;
            for (int k = hi; k >= lo; k--) { u -= 1.0 / (s - k); if (u <= 0) { pick = k; break; } }
            lastReview = true;
            picked = opponentFor(pick);
        }
        if (reviewOut != null && reviewOut.length > 0) reviewOut[0] = lastReview;
        return picked;
    }

    /** True while the episode that sampleOpponent() most recently chose is a review (legacy single-threaded API). */
    synchronized boolean lastEpisodeWasReview() { return lastReview; }

    Weights weights() {
        return weightsFor(Math.max(1, current));
    }

    /** 0 in stage 1, ramps to 1 over PITCH_RAMP_TICKS after leaving it. Multiplies Weights.pitch. */
    synchronized double pitchRamp(long ticks) {
        if (ActionMask.pitchLocked(lockMaskFor(Math.max(1, current)))) return 0.0;
        double r = (ticks - pitchRampStart) / (double) Config.PITCH_RAMP_TICKS;
        return Math.max(0.0, Math.min(1.0, r));
    }

    /** Multiplier on the entropy bonus: ENTROPY_BOOST right after a lock is lifted, decaying to 1. */
    synchronized float entropyScale(long ticks) {
        long since = ticks - boostStart;
        if (since < 0 || since >= Config.ENTROPY_BOOST_TICKS) return 1f;
        float k = 1f - since / (float) Config.ENTROPY_BOOST_TICKS;
        return 1f + (Config.ENTROPY_BOOST - 1f) * k;
    }

    /** Progress toward the stage gate, 0..1 (HUD bar): how full the evidence window is times how close the win rate is to the gate. */
    synchronized double progress(long ticks) {
        int s = Math.max(1, current);
        if (forced > 0 || s >= STAGES) return forced > 0 ? 0.0 : 1.0;
        if (recentN == 0) return 0.0;
        int wins = 0;
        for (int k = 0; k < recentN; k++) if (recent[k]) wins++;
        float gate = gateFor(s);
        double rate = gate <= 0f ? 1.0 : Math.min(1.0, (wins / (double) recentN) / gate);
        return Math.max(0.0, Math.min(1.0, (recentN / (double) recent.length) * rate));
    }

    /** Short readout for training logs: the success rate the gate looks at (not the kill rate), and the hop level where it applies. */
    synchronized String status() {
        int s = Math.max(1, current);
        String g = forced == 0 && s < STAGES ? String.format(java.util.Locale.ROOT, "gate %.0f%%/%.0f%% (hold %d/%d, %d eps)", 100 * gateWinRate(), 100 * gateFor(s), Math.min(hold, Config.GATE_HOLD_EPISODES), Config.GATE_HOLD_EPISODES, episodesInStage) : "gate n/a";
        return g + (hopStage(s) ? String.format(java.util.Locale.ROOT, " hop %.1f/%.1f", hopLevel(), Config.BOT_HOP_REQUIRED_LEVEL) : "");
    }

    synchronized String describe() {
        int s = Math.max(1, current);
        String gate = (forced == 0 && s < STAGES)
            ? String.format(java.util.Locale.ROOT, ", gate win %.0f%%/%.0f%% (%d episodes in stage%s)", 100 * gateWinRate(), 100 * gateFor(s),
                episodesInStage, stalled() ? ", STALLED: gate not met, review share " + (int) (100 * reviewShare()) + " %" : "")
            : "";
        return "stage " + s + "/" + STAGES + (forced > 0 ? " (forced)" : " (auto)")
            + ", opponent " + opponentFor(s).label + ", locks " + ActionMask.label(lockMaskFor(s)) + gate;
    }
}