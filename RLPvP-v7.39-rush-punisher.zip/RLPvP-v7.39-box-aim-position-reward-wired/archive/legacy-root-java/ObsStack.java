package com.rlpvp;

import java.util.ArrayList;

/**
 * Stacks per-tick frames at the lags in Config.LAGS (up to MAX_LAG ticks back) and appends the HitMemory summary, see
 * ObsLayout. No Minecraft classes.
 */
final class ObsStack {
    private final ArrayList<float[]> hist = new ArrayList<>();
    private static final int[] OFFSET = new int[Config.LAGS.length];

    static {
        for (int k = 0; k < OFFSET.length; k++) OFFSET[k] = ObsLayout.offset(Config.LAGS, k, Config.FRAME, Config.FAR_FEATURES.length);
    }

    void reset() {
        hist.clear();
    }

    /** Adds this tick's frame and returns the stacked network input (a fresh array). */
    float[] push(float[] frame, float[] summary) {
        if (hist.isEmpty()) {
            // Start of an episode: fill the history with the first frame so lags are valid.
            for (int i = 0; i <= Config.MAX_LAG; i++) hist.add(frame);
        } else {
            hist.add(frame);
            if (hist.size() > Config.MAX_LAG + 1) hist.remove(0);
        }
        float[] out = new float[Config.OBS_SIZE];
        int n = hist.size();
        for (int k = 0; k < Config.LAGS.length; k++) {
            float[] fr = hist.get(Math.max(0, n - 1 - Config.LAGS[k]));
            if (ObsLayout.near(Config.LAGS[k])) {
                System.arraycopy(fr, 0, out, OFFSET[k], Config.FRAME);
            } else {
                for (int j = 0; j < Config.FAR_FEATURES.length; j++) out[OFFSET[k] + j] = fr[Config.FAR_FEATURES[j]];
            }
        }
        System.arraycopy(summary, 0, out, Config.OBS_SIZE - Config.SUMMARY, Config.SUMMARY);
        return out;
    }
}
