package com.rlpvp;

import java.util.Locale;

/**
 * Keeps two degenerate habits unprofitable without forbidding the techniques behind them. Pure Java, shared by Trainer and PvpSim.
 *
 *  JUMP: every jump costs a little (SPAM_JUMP_COST) and OPENS a window of SPAM_JUMP_WINDOW ticks. A real damaging hit inside the window
 *  refunds it (SPAM_JUMP_REFUND, once per hit, oldest window first), so a jump that leads to a crit / sprint-jump hit is net positive and a jump that
 *  leads nowhere is net negative. A window that closes without a hit is an UNJUSTIFIED jump: it costs SPAM_JUMP_UNJUST, and when the recent rate of
 *  unjustified jumps exceeds SPAM_JUMP_OK per tick an extra per-tick penalty (SPAM_RATE_W * excess) applies, so "always jumping" gets worse the longer it goes on.
 *
 *  SNEAK: sneaking slows to 30 % and cannot sprint. It costs a little per tick (SPAM_SNEAK_TICK) and per toggle (SPAM_SNEAK_TOGGLE), and when the
 *  recent fraction of time spent sneaking exceeds SPAM_SNEAK_OK a per-tick penalty (SPAM_SNEAK_RATE_W * excess) applies.
 *
 * These are permanent (not annealed) and small next to a real hit (about 0.35 * W_DAMAGE for 7 HP), so winning exchanges still decide what is worth
 * doing. Only heads that are unlocked by the curriculum are charged. Window statistics for the logs: statsAndReset().
 */
final class SpamGuard {
    /** Per-tick input, filled by the caller from data it already has. */
    static final class In {
        boolean jumpFree, sneakFree;   // heads unlocked by the curriculum
        boolean jumpPressed, onGround; // the last jump action and whether I stood on the ground when it was chosen
        boolean sneaking;              // the last sneak action
        boolean realHit;               // a real, credited damaging hit landed this tick
        // ---- movement keys (W/A/S/D/sprint): the previous tick's applied action and the speed it produced ----
        boolean moveFree, sprintFree;  // forward/back or strafe head unlocked / sprint head unlocked
        int fwd, str;                  // -1 / 0 / +1 (S / none / W, A / none / D) as chosen last tick
        boolean sprintKey;             // sprint head pressed last tick
        double speed;                  // horizontal speed this tick, blocks per tick
        boolean tookHit;               // real damage taken this tick: a jump chosen just before / after it is a jump-reset attempt, not spam
        boolean comboWindow;           // I landed a real hit within Config.SPAM_COMBO_TICKS: a W / sprint tap is a w-tap, not chatter
    }

    private static final int MAX_WINDOWS = 4;
    private final int[] age = new int[MAX_WINDOWS];
    private final boolean[] open = new boolean[MAX_WINDOWS], paid = new boolean[MAX_WINDOWS];
    private int cooldown;
    private boolean prevSneak;
    private double unjustRate, sneakRate;
    // window statistics (for the logs)
    private int jumps, refunds, unjust, sneakTicks, toggles, ticks;
    private double paidNet;

    void reset() {
        java.util.Arrays.fill(open, false); java.util.Arrays.fill(paid, false); java.util.Arrays.fill(age, 0);
        cooldown = 0; prevSneak = false; unjustRate = 0; sneakRate = 0;
        sinceTook = 1000; kFwd = kStr = 0; kSpr = false; ageFwd = ageStr = ageSpr = 1000; chatterRate = 0;
        prevFwd = prevStr = flipCool = stuck = 0; sinceHit = 1000; prevSprint = false; flipRate = sprintToggleRate = 0; epMove = 0; flipTimerF = flipTimerS = 0;
    }

    /** @return reward for this tick (usually <= 0; positive only as a refund for a jump that led to a real hit). */
    double tick(In s) {
        double r = 0;
        ticks++;
        final double alpha = 1.0 / Config.SPAM_EMA_TICKS;
        boolean unjustNow = false;
        if (s.jumpFree) {
            if (cooldown > 0) cooldown--;
            sinceTook = s.tookHit ? 0 : Math.min(sinceTook + 1, 1000);
            if (s.tookHit) {                                                // jump reset: the jump chosen right before the hit was not spam, refund it
                for (int i = 0; i < MAX_WINDOWS; i++) if (open[i] && !paid[i] && age[i] <= Config.JR_LOOKBACK) { paid[i] = true; r += Config.SPAM_JUMP_COST; resets++; }
            }
            if (s.jumpPressed && s.onGround && cooldown == 0 && (s.tookHit || (sinceTook > 0 && sinceTook <= Config.JR_POST_TICKS))) {
                cooldown = 10; jumps++; resets++;                           // a jump on the tick of a hit or right after it: free, opens no window
            } else if (s.jumpPressed && s.onGround && cooldown == 0) {      // a jump starts (vanilla also has a 10-tick delay between jumps)
                cooldown = 10; jumps++;
                r -= Config.SPAM_JUMP_COST;
                int slot = 0; // reuse a free slot, else the oldest
                for (int i = 0; i < MAX_WINDOWS; i++) { if (!open[i]) { slot = i; break; } if (age[i] > age[slot]) slot = i; }
                if (open[slot] && !paid[slot]) { unjust++; unjustNow = true; r -= Config.SPAM_JUMP_UNJUST; }
                open[slot] = true; paid[slot] = false; age[slot] = 0;
            }
            if (s.realHit) {                                               // refund the OLDEST unpaid window, once per hit
                int best = -1;
                for (int i = 0; i < MAX_WINDOWS; i++) if (open[i] && !paid[i] && (best < 0 || age[i] > age[best])) best = i;
                if (best >= 0) { paid[best] = true; refunds++; r += Config.SPAM_JUMP_REFUND; }
            }
            for (int i = 0; i < MAX_WINDOWS; i++) {
                if (!open[i]) continue;
                if (++age[i] >= Config.SPAM_JUMP_WINDOW) {
                    if (!paid[i]) { unjust++; unjustNow = true; r -= Config.SPAM_JUMP_UNJUST; }
                    open[i] = false;
                }
            }
            unjustRate += alpha * ((unjustNow ? 1.0 : 0.0) - unjustRate);
            if (unjustRate > Config.SPAM_JUMP_OK) r -= Config.SPAM_RATE_W * (unjustRate - Config.SPAM_JUMP_OK);
        }
        if (s.sneakFree) {
            if (s.sneaking) { r -= Config.SPAM_SNEAK_TICK; sneakTicks++; }
            if (s.sneaking != prevSneak) { r -= Config.SPAM_SNEAK_TOGGLE; toggles++; }
            sneakRate += alpha * ((s.sneaking ? 1.0 : 0.0) - sneakRate);
            if (sneakRate > Config.SPAM_SNEAK_OK) r -= Config.SPAM_SNEAK_RATE_W * (sneakRate - Config.SPAM_SNEAK_OK);
        }
        r += moveTick(s);
        prevSneak = s.sneaking;
        paidNet += r;
        return r;
    }

    // ---- movement-key spam (MOVE_*): bounded, rate-based, refunded by real hits, never permanent ----
    private int prevFwd, prevStr, flipCool, stuck, sinceHit = 1000;
    private boolean prevSprint;
    private double flipRate, sprintToggleRate;
    private double epMove;                       // penalty paid this episode (capped by Config.SPAM_MOVE_EPISODE_CAP)
    private int flips, stuckTicks, sprintToggles, sprintNoFwd;

    /**
     * Direction FLIPS (A<->D or W<->S within SPAM_FLIP_WINDOW ticks) are only charged when their recent RATE exceeds SPAM_FLIP_OK, so ordinary
     * strafing (a flip every half second or slower) is free; STAGNATION (a move key held but almost no speed for SPAM_STUCK_TICKS ticks:
     * running into a wall / a blocked path) costs a little per tick; SPRINT toggles are charged above a rate, and sprint pressed without
     * forward movement (it does nothing) costs a little. A real hit within SPAM_HIT_GRACE ticks makes all of it free (the movement was
     * productive); the penalty total per episode is capped (SPAM_MOVE_EPISODE_CAP, far below one win), and the rates decay (EMA), so a policy
     * that stops the habit recovers at once.
     */
    private double moveTick(In s) {
        double r = 0;
        final double alpha = 1.0 / Config.SPAM_EMA_TICKS;
        sinceHit = s.realHit ? 0 : Math.min(sinceHit + 1, 1000);
        boolean flip = false;
        if (s.moveFree) {
            if (flipCool > 0) flipCool--;
            boolean fwdFlip = s.fwd != 0 && prevFwd != 0 && s.fwd != prevFwd;
            boolean strFlip = s.str != 0 && prevStr != 0 && s.str != prevStr;
            if ((fwdFlip || strFlip) && flipCool == 0) { flip = true; flips++; }
            if (s.fwd != 0) prevFwd = s.fwd; else if (++flipTimerF > Config.SPAM_FLIP_WINDOW) prevFwd = 0;
            if (s.str != 0) prevStr = s.str; else if (++flipTimerS > Config.SPAM_FLIP_WINDOW) prevStr = 0;
            if (s.fwd != 0) flipTimerF = 0;
            if (s.str != 0) flipTimerS = 0;
            flipRate += alpha * ((flip ? 1.0 : 0.0) - flipRate);
            if (flipRate > Config.SPAM_FLIP_OK) r -= Config.SPAM_FLIP_W * (flipRate - Config.SPAM_FLIP_OK);
            boolean pressing = s.fwd != 0 || s.str != 0;
            stuck = pressing && s.speed < Config.SPAM_STUCK_SPEED ? stuck + 1 : 0;
            if (stuck > Config.SPAM_STUCK_TICKS) { r -= Config.SPAM_STUCK_COST; stuckTicks++; }
        }
        if (s.sprintFree) {
            boolean toggle = s.sprintKey != prevSprint;
            if (toggle) sprintToggles++;
            sprintToggleRate += alpha * ((toggle ? 1.0 : 0.0) - sprintToggleRate);
            if (sprintToggleRate > Config.SPAM_SPRINT_TOGGLE_OK) r -= Config.SPAM_FLIP_W * (sprintToggleRate - Config.SPAM_SPRINT_TOGGLE_OK);
            if (s.sprintKey && s.fwd <= 0) { r -= Config.SPAM_SPRINT_NOFWD_COST; sprintNoFwd++; } // sprint without moving forward does nothing
        }
        prevSprint = s.sprintKey;
        if (s.moveFree || s.sprintFree) {                                   // one-tick taps: a key that changes again before it was held MIN_HOLD ticks
            boolean ev = false;
            ageFwd++; ageStr++; ageSpr++;
            if (s.moveFree && s.fwd != kFwd) { if (ageFwd < Config.SPAM_CHATTER_MIN_HOLD && !s.comboWindow) ev = true; kFwd = s.fwd; ageFwd = 0; }
            if (s.moveFree && s.str != kStr) { if (ageStr < Config.SPAM_CHATTER_MIN_HOLD) ev = true; kStr = s.str; ageStr = 0; }
            if (s.sprintFree && s.sprintKey != kSpr) { if (ageSpr < Config.SPAM_CHATTER_MIN_HOLD && !s.comboWindow) ev = true; kSpr = s.sprintKey; ageSpr = 0; }
            if (ev) { chatter++; r -= Config.SPAM_CHATTER_COST; }
            chatterRate += alpha * ((ev ? 1.0 : 0.0) - chatterRate);
            if (chatterRate > Config.SPAM_CHATTER_OK) r -= Config.SPAM_CHATTER_W * (chatterRate - Config.SPAM_CHATTER_OK);
        }
        if (sinceHit < Config.SPAM_HIT_GRACE && !(chatterRate > Config.SPAM_CHATTER_OK)) r = 0;                       // productive: a real hit just landed
        r = Math.max(r, -Config.SPAM_MOVE_TICK_CAP);                       // bounded per tick
        double room = Math.max(0.0, Config.SPAM_MOVE_EPISODE_CAP - epMove);
        r = -Math.min(-r, room);                                            // bounded per episode
        epMove += -r;
        return r;
    }
    private int flipTimerF, flipTimerS;
    // key chatter
    private int sinceTook = 1000, kFwd, kStr, ageFwd = 1000, ageStr = 1000, ageSpr = 1000, resets, chatter;
    private boolean kSpr;
    private double chatterRate;

    /** One-line summary of what the guard saw since the last call (jump starts, refunded / unjustified, sneak share, net reward), then clears it. */
    String statsAndReset() {
        String t = String.format(Locale.ROOT, "spam: jumps %d (refunded %d, unjustified %d) sneak %.1f%% toggles %d net %.2f", jumps, refunds, unjust,
            ticks == 0 ? 0.0 : 100.0 * sneakTicks / ticks, toggles, paidNet);
        t += String.format(Locale.ROOT, " | move: flips %d stuck %d sprintToggles %d sprintNoFwd %d chatter %d jumpResets %d", flips, stuckTicks, sprintToggles, sprintNoFwd, chatter, resets);
        jumps = refunds = unjust = sneakTicks = toggles = ticks = 0; paidNet = 0; flips = stuckTicks = sprintToggles = sprintNoFwd = chatter = resets = 0;
        return t;
    }
}
