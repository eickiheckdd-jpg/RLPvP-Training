package com.rlpvp;

import java.util.Arrays;
import java.util.Locale;
import java.util.Random;

/** Reports selected policy size and a repeatable rough CPU inference benchmark. */
public final class ModelInfo {
    private ModelInfo() {}
    public static void main(String[] args) {
        int[] actorShape = new int[Config.HIDDEN.length + 2];
        actorShape[0] = Config.OBS_SIZE;
        System.arraycopy(Config.HIDDEN, 0, actorShape, 1, Config.HIDDEN.length);
        actorShape[actorShape.length - 1] = Config.ACTION_SIZE;
        int[] criticShape = actorShape.clone(); criticShape[criticShape.length - 1] = 1;
        long params = (long) Net.paramCount(actorShape) + Net.paramCount(criticShape);
        Net net = new Net(actorShape, 0.01f, new Random(7));
        float[] x = new float[Config.OBS_SIZE];
        for (int i = 0; i < x.length; i++) x[i] = (float) Math.sin(i * 0.13);
        for (int i = 0; i < 100; i++) net.forward(x);
        int reps = Config.MODEL.equals("base") ? 10_000 : 500;
        long t0 = System.nanoTime();
        double checksum = 0;
        for (int i = 0; i < reps; i++) checksum += net.forward(x)[i % Config.ACTION_SIZE];
        double ns = (System.nanoTime() - t0) / (double) reps;
        System.out.printf(Locale.ROOT, "model=%s hidden=%s obs=%d actions=%d actorParams=%d criticParams=%d totalParams=%d approxWeightMiB=%.2f avgForwardMs=%.4f checksum=%.5f%n",
            Config.MODEL, Arrays.toString(Config.HIDDEN), Config.OBS_SIZE, Config.ACTION_SIZE,
            Net.paramCount(actorShape), Net.paramCount(criticShape), params, params * 4.0 / (1024 * 1024), ns / 1e6, checksum);
    }
}
