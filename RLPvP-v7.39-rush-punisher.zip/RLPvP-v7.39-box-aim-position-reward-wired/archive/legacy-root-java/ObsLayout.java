package com.rlpvp;

/**
 * Layout of the network input. Recent lags carry the whole frame, far lags (older than Config.NEAR_LAG_MAX) only a
 * compact subset (Config.FAR_FEATURES), and the slowly changing summary (HitMemory) is appended once at the end:
 *
 *   [ lag0 frame | lag1 frame | ... | far lag0 subset | ... | summary ]
 *
 * No Minecraft classes.
 */
final class ObsLayout {
    private ObsLayout() {}

    static boolean near(int lag) {
        return lag <= Config.NEAR_LAG_MAX;
    }

    static int size(int[] lags, int frame, int farLen, int summary) {
        int n = summary;
        for (int lag : lags) n += near(lag) ? frame : farLen;
        return n;
    }

    /** First input index of lag slot {@code k}. */
    static int offset(int[] lags, int k, int frame, int farLen) {
        int o = 0;
        for (int i = 0; i < k; i++) o += near(lags[i]) ? frame : farLen;
        return o;
    }

    /** Input index of frame feature {@code f} at lag slot {@code k}, or -1 if that lag does not carry the feature. */
    static int position(int k, int f) {
        int off = offset(Config.LAGS, k, Config.FRAME, Config.FAR_FEATURES.length);
        if (near(Config.LAGS[k])) return f < Config.FRAME ? off + f : -1;
        for (int j = 0; j < Config.FAR_FEATURES.length; j++) if (Config.FAR_FEATURES[j] == f) return off + j;
        return -1;
    }

    /** Input count of the layout before sneak (48-feature frames; same lags, far features and summary). */
    static int sizePreSneak() {
        return size(Config.LAGS, Config.FRAME_PRE_SNEAK, Config.FAR_FEATURES.length, Config.SUMMARY_BASE);
    }

    /** Where each input of the pre-sneak layout (state versions 4-6 in the current lag layout) lives now: every kept input keeps its meaning. */
    static int[] preSneakMap() {
        int[] map = new int[sizePreSneak()];
        int o = 0;
        for (int k = 0; k < Config.LAGS.length; k++) {
            if (near(Config.LAGS[k])) { for (int f = 0; f < Config.FRAME_PRE_SNEAK; f++) map[o++] = position(k, f); }
            else { for (int j = 0; j < Config.FAR_FEATURES.length; j++) map[o++] = position(k, Config.FAR_FEATURES[j]); }
        }
        for (int s = 0; s < Config.SUMMARY_BASE; s++) map[o++] = summaryOffset() + s;
        return map;
    }

    /** Maps an older checkpoint's summary block into the current appended-summary layout. */
    static int[] summaryMap(int oldSummaryCount) {
        int oldSize = size(Config.LAGS, Config.FRAME, Config.FAR_FEATURES.length, oldSummaryCount);
        int[] map = new int[oldSize];
        int oldSummaryOffset = oldSize - oldSummaryCount;
        for (int i = 0; i < oldSummaryOffset; i++) map[i] = i;
        int keep = Math.min(oldSummaryCount, Config.SUMMARY);
        for (int i = 0; i < keep; i++) map[oldSummaryOffset + i] = summaryOffset() + i;
        return map;
    }

    /** Maps a checkpoint using the original 20 summary inputs into the current layout. */
    static int[] baseSummaryMap() { return summaryMap(Config.SUMMARY_BASE); }

    /** Input index where the summary starts. */
    static int summaryOffset() {
        return Config.OBS_SIZE - Config.SUMMARY;
    }

    /**
     * Where each input of an OLD layout (frames of {@code oldFrame} floats at the lags {@code oldLags}, no summary) lives in
     * the current layout; -1 = the current layout has no such input (it is dropped).
     */
    static int[] legacyMap(int oldFrame, int[] oldLags) {
        int[] map = new int[oldFrame * oldLags.length];
        for (int ko = 0; ko < oldLags.length; ko++) {
            int kn = -1;
            for (int i = 0; i < Config.LAGS.length; i++) if (Config.LAGS[i] == oldLags[ko]) kn = i;
            for (int f = 0; f < oldFrame; f++) map[ko * oldFrame + f] = kn < 0 ? -1 : position(kn, f);
        }
        return map;
    }
}
