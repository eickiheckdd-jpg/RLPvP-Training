# Archived root-level Java snapshots

The uploaded ZIP contained 45 loose `.java` files at the repository
root. They duplicate older snapshots of classes in `src/main/java/com/rlpvp` and were
not part of Gradle's standard Java source tree. They are preserved here for reference,
outside all active source sets. Do not copy them over the current mod sources without
reviewing a diff first.
