# v7.34 Target Selection and Aim Stability Patch

## Commands
- `/rl target select on`: loads the saved policy if needed, enables play mode, and prefers the player most recently attacked by the local player or the player who most recently damaged the local player.
- `/rl target select off`: disables the AI and lets the remembered combat target expire after 10 seconds.
- Existing `/rl target <name|auto>` behavior remains available.

When target-select mode is enabled, the AI does not time out. If its selected target dies or is removed, target-select mode turns off and releases the inputs. While disabled, target selection expires after 200 client ticks (10 seconds).

## Aim stability
`AimInputFilter` now uses stronger low-amplitude filtering, a small axis-scaled deadband for policy chatter, a slower response on small sign reversals, and a tighter per-tick slew limit. The existing `GameplayRotation` mouse-dynamics pipeline remains in place; legal mouse-count quantization and residual accumulation are preserved.

## Validation
The source archive is based on the uploaded v7.33 tactical-deck ZIP. A Gradle build was attempted, but the environment could not resolve `services.gradle.org`, so the build could not be completed here. Build and in-game verification are still required before treating this as release-ready.
