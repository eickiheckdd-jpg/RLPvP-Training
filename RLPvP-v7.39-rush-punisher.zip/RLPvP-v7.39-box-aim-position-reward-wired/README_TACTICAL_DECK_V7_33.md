# RLPvP v7.33 — Tactical Deck Experiment

A separate experiment based on the v7.32 situational-combat branch. It adds a configurable camera-input low-pass filter, routes attack requests through Minecraft's in-game attack key binding, and replaces the HUD with a neon tactical instrumentation deck. It preserves the PPO training path and situational stack design.

## Main changes

### Adaptive aim-input filter

`AimInputFilter.java` filters the controller's requested yaw and pitch command **in degrees per game tick** before those commands enter the mouse-like camera dynamics. Small commands get a smoother response; larger command changes get a faster coefficient so tracking does not become uniformly sluggish. A per-tick step limit reduces one-frame snaps. The shared `GameplayRotation` controller is used by both the live action applier and the simulator, so the filter is deterministic and has no per-tick allocations.

The downstream `CameraDynamics` still handles acceleration, drag, jerk and angular-speed limits. When a valid aim error is inside the configured precision envelope, the input filter goes into a pass-through state for the current command while predictive `AimBrake` handles the final deceleration; this avoids stacking two slow filters right at the target. The HUD distinguishes requested command, filtered command, and applied camera turn. They are different values and should not be interpreted as a raw OS mouse measurement.

Relevant settings are in `Config.java`: `AIM_INPUT_FILTER`, slow/fast alpha, error fraction for faster response, maximum per-tick input step, and precision-zone bypass angle.

### Attack input bridge

`ActionApplier` now requests a left-mouse click with the 1.21.11 static `KeyMapping.set/click(InputConstants.Key)` path, rather than calling `gameMode.attack()` directly. The curriculum charge gate is checked before adding a click. Vanilla consumes this as an in-game key-binding click on its ordinary input path. The HUD reports the binding pulse, queued click count, last event time and a best-effort swing label. Block-target clicks are suppressed to avoid mining an arena.

**Important input boundary:** this creates a synthetic *Minecraft key-binding click*, not a native operating-system/GLFW mouse event and not a claim of physical mouse hardware. Mods that observe Minecraft's key mapping can see the input; tools that only count raw device callbacks may not. This implementation does not try to bypass anti-cheat or spoof hardware input. The actual hit remains determined by Minecraft's normal target/raycast and attack-cooldown rules. The HUD's swing label is an estimate taken when the click is queued, not server-confirmed combat damage.

### Tactical Deck HUD

`RlHud.java`, `HudDraw.java`, `HudTheme.java` and `HudState.java` implement a dark-navy and neon-cyan/violet/lime deck inspired by instrument-panel styling while displaying different data from the screenshot reference:

- run mode, current target, stage progression and episode tick;
- self/enemy health bars;
- distance/reach gauge, line-of-sight badge and aim-angle error;
- current tactical intent and its confidence (or explicit PPO-learning state);
- requested / filtered / actual yaw and pitch in degrees per tick, camera velocity and filter alpha;
- attack-charge threshold, binding pulse, queued-click count and predicted swing label;
- win rate, whiff rate, damage delta, return sparkline, and recent episode outcomes;
- full-mode system telemetry for policy ticks/updates, entropy, motion, interventions, rejected attacks, sprint corrections, boundary corrections, action masks and recent result.

HUD modes: `/rl hud mini`, `/rl hud compact` (also `/rl hud deck`), `/rl hud full` (also `/rl hud diagnostics`), `/rl hud on`, `/rl hud off`. The default is compact. Rendering reads a snapshot and does not alter gameplay.

## Preserve the training baseline

This project is a separate directory and has the independent Fabric ID `rlpvp_tactical_deck`. The uploaded v7.32 archive and any v7.32 training process are not replaced by this package. Do not copy checkpoints across versions without first testing their observation layout and checkpoint compatibility.

## Validation and known limits

- `AimInputFilterCheck` passed, including response smoothing, convergence, reversal slew limit, finite values and reset behavior.
- `GameplayRotationCheck` passed, including mouse-like acceleration/jerk limits and target-braking cases.
- The Minecraft-free regression suite passed through the situational stack smoke test, then stopped at `CritSatiationCheck`'s existing assertion `late-stage entropy gradually decays at halfway`. The same assertion failed against the original v7.31 source and is unrelated to this HUD/input patch.
- `sim/regression.sh` now includes the new `AimInputFilter.java` dependency.
- A full Fabric Gradle build has not been verified in this environment: Gradle wrapper dependency download was unavailable due to network/DNS resolution of `services.gradle.org`. The Minecraft-dependent UI/input integration must be compiled and smoke-tested in a real 1.21.11 Fabric client with dependencies available.
- No measured combat-performance gain is claimed. In particular, the queued-key attack path changes input timing relative to the former direct call, so verify that hit/whiff labels match actual server events during a live test.

With Gradle dependencies available, run `./gradlew build`; for offline checks, run `sh tests/run.sh` (currently reaches the noted baseline assertion) and `sh sim/regression.sh`.
