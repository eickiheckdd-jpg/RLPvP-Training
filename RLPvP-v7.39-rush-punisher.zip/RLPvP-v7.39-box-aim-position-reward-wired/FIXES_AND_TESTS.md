# RLPvP v7.14 outcome, timeout, and collapse fixes

This patch was made in a separate copy of the uploaded v7.14 sim kit. It does not modify any existing training output directory or checkpoint.

## What changed

- Added `EpisodeOutcome`, a shared classification for wins, losses, mutual knockouts, timeouts, uncredited opponent deaths, and aborted episodes. Terminal rewards, PPO terminal/bootstrap flags, curriculum reporting, bot-difficulty adaptation, metrics, and collapse-guard inputs now use a consistent interpretation.
- Made simulator episode duration kit-aware. The theoretical hit-rate calculation is based on `MinecraftRules`; the limit is doubled and rounded up to 20 ticks, then clamped between 300 and 1200. `-Dsim.episodeTicks=N` can override it, including `300` for the old A/B condition. The actual Minecraft mod remains at 300 ticks because it cannot reliably infer server equipment.
- For the default diamond + Protection III kit, the model calculates 0.983 HP per full unenchanted hit, 21 full hits, a theoretical 240-tick time-to-kill, and a 480-tick simulator episode limit. The other same-kit limits are: naked 300, iron 300, plain diamond 300, diamond Prot IV + Sharpness III 520, and netherite Prot IV + Sharpness V 420. These are simulator arithmetic, not verified in a live Minecraft server.
- Fixed CollapseGuard so draw-only windows do not count as collapses based on win rate alone. A low-win window must also show heavy losses, very little real damage, or substantially worse trades. Failed windows are not stored as the stage's best snapshot. The entry weights are captured when the curriculum actually changes stage; demotion restores the best non-failed snapshot when available, otherwise stage-entry weights.
- Rejected simulated attack packets from dead attackers and packets targeting dead entities. Damage metrics now count actual HP damage, clamp health at zero to exclude overkill, and exclude soft/aim reward credit from damage telemetry.
- Captured review-episode flags per episode, avoiding reliance on shared `Curriculum.lastReview` in parallel training. Parallel probe demotions now propagate through the existing `DEMOTED` signal.
- Added draw and no-contest reporting to simulator progress/evaluation and bot-benchmark output; corrected adaptive bot difficulty so draws are not passed into its win/loss-only API as losses.
- Added `OutcomeRegressionTest` and wired it into `sim/regression.sh` and `tests/run.sh`. Updated two existing test expectations that contradicted existing intended behavior: consequence-model training subsampling, and `MinecraftRules.byName(null/unknown)` falling back to the documented Protection III default.

## Verified tests and smoke checks

All commands below were run against this separate source copy:

- `./sim/regression.sh` — **43 passed, 0 failed**.
- `./tests/run.sh` — **exit 0**; the regression suite plus the existing camera, memory, technique, consequence-model, guard, curriculum, combat arithmetic, spam-guard, glide, migration, aim-brake, rotation, and bot-AI checks passed.
- `./sim/run.sh 1000 /tmp/rlpvp-v714-fix-final-smoke.bin 42 -` — completed and wrote a 1,000-tick smoke checkpoint at stage 1. This only tests launch/checkpoint flow, not combat quality.
- `./sim/eval.sh /tmp/rlpvp-v714-fix-final-smoke.bin 1` — completed and printed win/loss/draw/no-contest columns. The checkpoint is deliberately only a 1,000-tick smoke model, so those combat results are not meaningful evidence of policy quality.
- `./sim/bench.sh 1` — completed the fixed-seed, one-episode-per-case bot-benchmark smoke test, with draw outcomes included in output. This is a compile/runtime smoke test, not a statistically meaningful benchmark.
- Manual `javac` compile of `PvpSim.java` plus `ParallelPvpTrain.java` and their Minecraft-free dependencies — passed.
- `git diff --check` — passed.

## Not verified / limitations

- The full Fabric/Minecraft mod build was not possible in this environment. The Gradle wrapper tried to download Gradle 9.5.1, but network DNS for `services.gradle.org` failed; the Gradle distribution and Minecraft dependencies are not locally available. Thus the changed Minecraft-facing `Trainer.java` was reviewed but not compiled against Fabric here.
- No in-game test was run. In particular, the Carpet bot-removal branch still depends on whether the removed entity exposes health zero/death state to the client at the time it is removed.
- A substantive 60,000-tick A/B training experiment was not completed. The smoke checks above do not prove that win rate improves or that long-run training is stable.
- `sim/consistency.sh` was also tried with the 1,000-tick smoke checkpoint and failed because that untrained checkpoint produced no camera movement, so the test's negative control could not distinguish the implementations. This is not presented as a passing test.
- Existing checkpoint serialization was left unchanged. Nevertheless, switching from 300 to kit-aware timeout lengths changes the episode horizon and thus training targets; a future resumed run may need some adaptation. Use `-Dsim.episodeTicks=300` for the old horizon in controlled A/B runs.

## Suggested commands

```sh
./sim/regression.sh
./tests/run.sh
./sim/pipeline.sh results/prot3-fixed 2000000 1 300000 150
```

The pipeline command starts a **new** run in a new output directory; it is not part of this patch's verification and was not run here.
