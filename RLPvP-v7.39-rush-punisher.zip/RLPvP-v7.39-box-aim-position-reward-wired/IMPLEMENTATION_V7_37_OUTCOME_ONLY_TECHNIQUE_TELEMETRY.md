# RLPvP v7.37 — Outcome-only technique learning and telemetry

## What changed

This patch removes technique-identity bonuses and penalties from the learning reward while preserving detection and audit logging. Technique names remain useful for measuring what the policy discovers; the labels themselves do not add value to PPO returns.

The reward switch is deliberately hard-off in `Config.java`:

- `OUTCOME_ONLY_REWARDS = true`
- `TECHNIQUE_REWARDS_ENABLED = false`
- `TECH_REWARD_SCALE = 0.0`

`techniqueRewardsEnabled()` requires all three conditions to permit rewards, so setting a scale alone cannot turn technique payouts back on.

The disabled channels include critical-hit, sprint-hit, combo, knockback-follow-up, first-hit, punish, dodge, jump-reset, spacing-exchange, bait, W-tap, S-tap, circle-strafe/orbit, crit-window camera, pointless-whiff, and repeated-whiff rewards/penalties. Legacy entry points are guarded too: `Reward.tick`, `Reward.techBonus`, `TechniqueReward`, `TechniqueDiscovery`, and `CameraReward` all return zero for these identity-based terms.

Two proxy signals were also retired so the model is not paid for an unconfirmed result: soft near-miss HP credit is zero in every stage, and the separate missed-swing cost is fixed at zero. Server-confirmed HP damage is the only damage amount used in the damage reward.

## What still teaches the policy

The policy still learns from actual HP dealt and taken, the terminal win/loss/draw result, and the existing PPO return/advantage learning. PPO exploration/entropy, the existing observation/action heads, learned aim control, opponent league, and the Minecraft-style simulator mechanics are unchanged.

General continuous aim/position shaping remains in place to avoid throwing away the existing aim and movement learning: facing/pitch error, closing progress, closeness, general striking/recharge spacing, HP lead, and time pressure. These are state/position signals, not bonuses triggered by a named technique event. The `spacing` event in the technique audit is diagnostic only; the independent continuous spacing potential remains.

`SpamGuard` no longer charges action-pattern costs for sneaking, directional reversals, strafing, sprint toggles, jump frequency, W/S taps, or sprint-reset patterns. Those choices remain available for the policy to discover and are logged as diagnostics. Two small generic waste guards remain: holding movement into a true obstruction with almost no movement, and sprinting without forward input. They are not assigned to any technique label and are bounded/waived around successful combat.

No technique frequency target, scripted combo, hardcoded dodge sequence, or aim correction was added.

## Technique logs

The technique detector now runs from the first training tick, even when the curriculum's technique weight is zero. Legacy per-episode reward caps and reward de-duplication no longer suppress telemetry while reward payouts are disabled.

Each v2 technique-audit row includes all 12 event categories:

`crit`, `sprintHit`, `kbFollowup`, `combo`, `firstHit`, `punish`, `dodge`, `jumpReset`, `spacing`, `bait`, `wTap`, and `sTap`.

For each category the CSV records:

- `*_events`, `*_won`, and `*_lost`
- `*_paid` (must remain `0.0000` in this build)
- `*_dealtHp`, `*_takenHp`, and `*_netHp` over its tagged exchange window

The row also records `techniqueRewardsEnabled=false`, `techniqueRewardScale=0`, swing attempts, client target selections, whiffs and repeated whiffs, sprint-hit chain conversions, and knockback-separation measurements. Swing target selection is not treated as authoritative hit confirmation. Per-technique HP totals describe the tagged exchange window, not causal attribution of every HP point to the technique.

A separate opportunity audit continues to report critical/sprint windows, whether the policy selected an attack, swing attempts, target selections, and server/HP-confirmed hits. This separates opportunity discovery from successful conversion.

### Output paths

For the parallel simulator, given checkpoint `path/to/model.bin`:

- `model.bin.technique-audit-v2.csv`
- `model.bin.technique-opportunity-audit.csv`
- `model.bin.reward-audit.csv`

For the Fabric client/mod:

- `config/rlpvp/techlog-v2.csv`
- `config/rlpvp/reward-audit.csv`

The `v2` suffix intentionally avoids appending the new schema to an existing v1 technique CSV. The audit is also printed in the parallel trainer's periodic progress summary.

## Compatibility and rollout

No observation dimension, action dimension, checkpoint tensor layout, or Minecraft-port combat formula was changed by this patch. Existing checkpoints remain loadable. The current JVM training process is not hot-patched by editing source: restart/rebuild the trainer from this source before expecting the new reward policy or v2 logs to take effect. Existing processes/checkpoints are not overwritten by this patch.

## Verification

- `sh sim/regression.sh` — passed after the implementation, including the technique-reward policy checks, technique opportunity audit, parallel persistence/path checks, network simulation, damage/kit, and combat-memory regressions.
- `TechniqueRewardPolicyCheck` — confirms every named technique's paid reward is zero, all 12 labels are logged, logging works with curriculum technique weight zero, dodge telemetry is not cut off by the old reward cap, and whiffs/near-misses add no separate technique reward.
- `MoveSpamCheck` and `SpamGuardCheck` — passed in the Minecraft-free suite run after the movement-pattern penalties were removed; W/S reversals, sprint toggles, strafing, and sneaking remain reward-neutral, while the two generic waste guards remain covered.
- The full `tests/run.sh` still has four failures in `GameplayRotationCheck` (small correction, large-turn overshoot, steady-state stability, and fine aiming). The same four failures appeared in the first full-suite run before the final movement-neutralization/soft-credit adjustments; this patch does not modify the gameplay-rotation controller. A follow-up run skipping that unrelated check passed `SpamGuardCheck` and `MoveSpamCheck` and progressed through later tests, but the long `JumpStartTelemetryCheck 6000` phase exceeded the available command runtime, so the entire suite is not claimed as fully green.
- The Fabric/Gradle `compileJava` task could not be run because the Gradle wrapper distribution could not be downloaded in this offline environment. The simulator regression build compiles the shared reward, technique, and simulation classes.
