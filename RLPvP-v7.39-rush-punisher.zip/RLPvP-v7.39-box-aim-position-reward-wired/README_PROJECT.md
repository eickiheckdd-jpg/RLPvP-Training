# RL PvP (sword): online PPO inside a Fabric client mod

Trains a small actor-critic MLP (78 inputs -> 64 -> 64 -> 29 policy logits, plus a separate
78 -> 64 -> 64 -> 1 value net, ~22k weights total) with **PPO that learns while you play**. It
controls your own client player and fights another player entity (a practice bot) on a server.

Replaces the old neuroevolution trainer: no generations, no population, no waiting 12 minutes
to find out whether anything improved.

> **Situational consequence update (state format v5):** The current branch includes an online learned next-frame model and a small model-based action look-ahead for `/rl play`. Technique-identity rewards are off by default (`OUTCOME_ONLY_REWARDS=true`); the AI is rewarded for combat outcomes, not for labels such as crit, sprint-hit, combo, or strafe. See [`docs/SITUATIONAL_PLANNER.md`](docs/SITUATIONAL_PLANNER.md) for migration, warm-up, and evaluation steps. Version-4 checkpoints load with the actor preserved; the new consequence model learns from transitions during `/rl start` and does not steer play until its validation gate passes.

> **Experimental physical-mouse branch:** this source tree replaces v9's spring/damper velocity follower with a mouse-style hand-effort model. Policy output drives acceleration, drag slows the mouse when effort is released, jerk limits smooth acceleration changes, and integrated relative displacement turns the camera. See [`docs/CAMERA_DYNAMICS.md`](docs/CAMERA_DYNAMICS.md). This changes camera-action semantics: train from a fresh policy; do not resume `models/experimental_state_smooth0.7_1300k.bin` as though it had learned the new controller. Pure-Java controller/tests pass, but this branch has not yet been freshly trained or evaluated for PvP quality.

## How the learning works
- **Every tick**: observe, compute reward for the previous action, sample an action, store the
  transition, and run one PPO minibatch step if a finished rollout is waiting.
- Experience is collected in 128-tick rollouts (double buffered). When one fills, GAE advantages
  are computed and the learner works through it (4 epochs x 4 minibatches of 32 = 16 gradient
  steps, one per tick on the next 16 ticks) while the next rollout is being collected. The game
  never stalls on a big update.
- Policy = 4 categorical heads (yaw, pitch, forward/back, strafe) + 3 Bernoulli heads
  (attack, jump, sprint). Clipped objective, entropy bonus, KL early stop, Adam, grad clipping.
- Memory: about 1 MB. Per-tick CPU: well under 1 ms on average. Fine inside 2 GB.

## Setup / run
Same as before (Fabric 1.21.11, Mojang mappings, Java 21, Fabric API; build with `./gradlew build`
or the GitHub Actions workflow). In game, near a practice bot:

`/rl start [fresh]`, `/rl play`, `/rl stop`, `/rl save`, `/rl load`, `/rl status`,
`/rl target <name|auto>`, `/rl hud [on|off|auto|combat|training|mini]`.
The split HUD places input keys, yaw/pitch rate dials and target status on the left; live range,
camera and real attack-cooldown telemetry plus a two-marker radar sit on the right. Training
statistics use a separate compact widget.

`/rl start fresh` is required once because old evolution `state.bin` files are not compatible.

## Files (in `config/rlpvp/`)
- `state.bin`: both networks + Adam state + tick counter, autosaved every 5 minutes and on exit
- `log.csv`: every 10 episodes: ticks, updates, dealt/taken HP, win/loss rate, return, entropy, KL

## What to watch
Entropy should fall slowly (from ~6-7 toward 2-3), win rate and dealt HP should rise. KL should stay
around 0.005 to 0.02. If KL is constantly above 0.045, lower `LR_ACTOR` in `Config.java`.

## Offline test (no Minecraft needed)
`sim/run.sh fighter 500000 1` compiles only the pure-Java PPO core, runs finite-difference gradient
checks, then trains against a crude simulated duel that uses the same 78-float observation, 29-logit
action layout and reward function as the mod. It checks that the learner works; it is not Minecraft
physics, so real in-game speed of learning will differ. At 20 TPS, 1M ticks is about 14 hours.

## Tuning (`Config.java`)
`ROLLOUT`, `MINIBATCH`, `EPOCHS`, `LR_*`, `ENTROPY_COEF`, `GAMMA`, `REWARD_SCALE`, plus the
reward weights and episode length. In the simulator, raising `EPOCHS` so a gradient step runs on
every tick made learning much worse (the KL early-stop kept firing), so the default is 4.
## Timing / technique update (observation 42 -> 48 floats, reward changes)
- **New inputs (frame 42..47):** enemy weapon charge (estimated from the time since its last swing), can-crit window, enemy in
  my reach, me in their reach, ticks since my last swing, closing speed. Old `state.bin` files are migrated on load: the new
  inputs start with zero weights, so the loaded policy behaves exactly as before (checked in `tests/`).
- **Stronger:** `CRIT_BONUS` 0.4 -> 0.8, `WHIFF_PENALTY` 0.12 -> 0.24, `W_DAMAGE` 12 -> 9, `SPACING_REWARD` 0.003 -> 0.004,
  `RETREAT_FRACTION` 0.5 -> 0.8; spacing weight now starts in stage 6; closeness fades in stages 7-9.
- **New, stage 6+ (`Weights.late`):** full-charge hit, reset-gap hit, punish-their-swing hit (all paid only with a REAL hit);
  **stage 7+:** small HP-lead bonus (stops paying when the agent stalls).
- **Attack gate:** hard gate 0.9 up to stage 5; from stage 6 it drops to 0.5 (`GATE_RELAX_STAGE`), otherwise the full-charge
  bonus would be paid on every hit and teach nothing. Bots keep the 0.9 gate.

## Camera reward + offline simulator (flicker fix)
- `CameraReward.java` (shared by the mod and the simulator): progress toward the target, a penalty for changing the mouse delta tick-to-tick while aimed, an overshoot penalty, a "stay still when on target" cost, a hold bonus, and a capped jump-crit setup bonus (stage 6+). Big flicks stay free while the target is far away.
- Camera sampling noise is capped (`LOOK_LOGSTD_MAX`), its entropy bonus is no longer boosted by the anti-collapse floor, and the agent no longer sees its own last camera deltas (frame 27/28 are zeroed).
- `sim/`: a Minecraft-like duel simulator (gravity, friction, knockback, hit invulnerability, 12.5-tick attack cooldown, crits, sprint knockback) that trains the real PpoAgent/Reward/Curriculum code. `sim/run.sh 1000000 out.bin` trains, `sim/eval.sh state.bin` runs a greedy (play-mode) evaluation including flicker metrics.
## 4.8 s memory + hit-type observations (network input 192 -> 378)
No recurrent layer: the memory is extra inputs, so PPO / `Net` are unchanged.
- **Longer history:** lags `{0,1,2,4,8,16,32,48,64,80,96}` ticks (up to 4.8 s). Lags up to 16 carry the whole 48-float frame;
  the five older ones carry 14 key features (`Config.FAR_FEATURES`), which keeps the network small (see `ObsLayout`).
- **Hit memory summary (20 floats, appended once, `HitMemory`):** size and type of my last hit (crit / sprint / sweep / weak),
  size of the last hit I took and how the enemy hit me (crit / sprint), damage dealt / taken over the last 4.8 s, counts of my hits,
  their hits, my crits, sprint hits, weak hits, enemy swings, my swings and whiffs, and both combo counters.
- **Hit types** are decided at swing time: weak = not fully charged; crit = full charge + falling + not sprinting; sprint = full charge
  while sprinting; sweep = full charge on the ground, not sprinting (in a 1v1 a sweep adds no extra damage; it is only a label).
  Crit / sprint rewards now also require a full charge, as in vanilla (no change while the 0.9 attack gate is on, stages 1-5).
- **Old saves** (42- and 48-float frames) migrate on load with zero weights for the new inputs, so the policy starts unchanged.
- Self-play snapshots get the same memory inputs (`BotBrain`). Tests: `tests/run.sh [old42 [old48]]`.
- Cost: a PPO step is about 1.6x heavier than before (measured 10.8 -> 17.5 ms on a slow test core). If your game stutters during the
  32 training ticks after each rollout, remove a far lag or lower `EPOCHS`.

## Technique measurement without technique rewards
Technique labels (critical hits, sprint hits, combos, reset-gap hits, punish hits, strafe patterns, and dodges) remain available for measuring what the policy discovered. With `OUTCOME_ONLY_REWARDS=true`, these labels do not directly add reward; combat outcomes, survival, wins/losses, and generic state shaping drive learning. `tests/TechniqueCheck.java` checks that changing only a technique label does not change the intrinsic reward.

## Opponents (BotAI)
`BotAI.java` is the AGGRESSIVE / STRONG fighter for both the mod and the simulator: lead aim, mirror-strafe, pursuit, punish-on-recharge, 3 styles, adaptive
difficulty (`BotDifficulty`). It stays fair (lag, turn cap, full-charge swings, real reach). `sim/bench.sh` compares old vs new bots against an idealized orbiter.

## v6 + symmetric policy (merged)
v6's training fixes (sampled play, per-head entropy floors, whiff penalty, probe-gated stages, faster collapse guard) plus the
left/right **symmetric policy** (`Symmetry.java`, `Config.SYMMETRIC_POLICY`). v6 alone still strafed 100% left on the 1M weights
(the policy itself had a favourite side); the symmetric policy removes that by construction. `tests/SymmetryCheck.java` proves it.
Existing `.bin` files load but behave differently under the symmetric policy: retrain from them.

## Camera smoothness (v7)
Fixed the 20 Hz stair-stepping (`ActionApplier` no longer moves `yRotO` / `xRotO`), added an optional look filter (`Config.LOOK_SMOOTH`,
off) with a simulator + `CamSmoothEval`, and measured it: see `docs/CAMERA.md`. Parse-checked only; not built against Minecraft here.

## PFSP league, human-style opponents, aim stability, and HUD optimization
The current upgrade adds a persistent Elo/PFSP opponent league with frozen policy snapshots and fixed BotAI styles, human-like reaction/aim/click variation, camera-command chatter suppression, and lower-allocation HUD rendering while retaining the existing HUD layout and styling. It also adds config-driven reward/observation tuning and a fixed-seed standing-evaluation workflow. See [`docs/LEAGUE_HUMAN_AIM_HUD_UPGRADE.md`](docs/LEAGUE_HUMAN_AIM_HUD_UPGRADE.md) for configuration, usage, validation results, and limitations. Exact MC 26.3 lookahead rollouts are not included because the simulator does not yet expose a safe exact-state fork for A/B combatbench validation.

## Stage 9 competitive self-play
Stage 9 is an open-ended training destination after a longer Stage 8 league-refinement period. It uses PFSP over frozen snapshots and all fixed `BotAI` styles, weighting styles that have historically beaten the learner more heavily and retaining deliberate coverage of aggressive specialists. The normal evaluation-probe/collapse-rollback path is disabled at Stage 9. In the offline parallel simulator trainer, a separate asynchronous held-out champion evaluator runs against all 11 scripted styles and never gates PPO updates; it saves a separate `.champion.bin`, leaving the latest learner checkpoint untouched. The live Fabric trainer uses the same league sampler and disables Stage 9 collapse rollback, but the offline evaluator is not run inside the live client. See [`docs/STAGE9_COMPETITIVE_LEAGUE.md`](docs/STAGE9_COMPETITIVE_LEAGUE.md).
