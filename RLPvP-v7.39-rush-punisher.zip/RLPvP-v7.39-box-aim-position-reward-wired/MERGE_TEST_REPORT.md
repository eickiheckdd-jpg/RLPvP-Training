# RLPvP v9 merge verification

## Merged inputs

- v9 Minecraft Java 26.3 formula/physics branch retained as the base.
- v7.35 measured combat-intelligence changes merged selectively: policy/planner/full stack toggles, component ablations, tradeable-hit state, measured combo-escape behavior, opponent identity memory, CombatBench harness, and v7.35 benchmark provenance.
- The v9 attack/cooldown/damage/armor/protection/knockback/movement formula classes were not overwritten with the older v7.34/v7.35 simulator implementation.

## Checks run after merge

- `sh sim/regression.sh`: PASS — 43 outcome, 12 sprint-follow-up, observation-memory, 25 physics, Minecraft rules, 27 Diamond Prot III kit, 34 exact combat, and measured tradeability checks.
- `sh sim/prediction.sh`: PASS — threat predictor and opposing-motion scoring fixture. The script explicitly sets `rlpvp.intelOff=0` because the test is specifically exercising candidate scoring, which is disabled by the measured default mask.
- `sh sim/aimstability.sh`: PASS — camera stability, rotation pipeline, render interpolation and aim-brake fixtures.
- `sh sim/combatbench.sh <checkpoint> 2 0.6`: PASS as a harness smoke test. It completed all policy/planner/full-stack cells. Two episodes per cell are only a wiring smoke test, not a statistically useful performance benchmark.
- `sh tests/run.sh`: MOSTLY PASS — the broad legacy harness passed the RL, memory, reward, curriculum, physics, guard, and other listed checks, but exited with four known `GameplayRotationCheck` camera assertions failing (small correction overshoot, one large-turn overshoot bound, steady-state stability, fine-aim tolerance). The focused `sim/aimstability.sh` suite passes.

## Not verified

- Full Fabric/Gradle compilation: not run successfully in this environment (installed JDK 21; project requires JDK 25, and the wrapper distribution cannot be fetched here).
- Live vanilla 26.3 server differential traces: not run. This is a simulator-side formula port; it is not the vanilla server runtime.
- The 3,000,000-tick fresh training run is separate from the source archive and its current progress is in `/mnt/data/rlpvp-v9-merged-fresh-3m.log`.
