# Client-side hit-registration fix (v7.39)

## Root cause addressed

The AI changed gameplay rotation and queued a left-click at `END_CLIENT_TICK`, but vanilla consumed that queued click later using `Minecraft.hitResult`. That cached crosshair result could still describe an earlier render frame. The AI could therefore believe the opponent was under its new aim while vanilla still had a `MISS`, block, or different entity selected. A click in that state can produce a swing animation without attacking the intended entity.

## Implementation

- `ActionApplier` now asks Minecraft's own `GameRenderer.pick(1.0f)` to refresh the crosshair result after applying the AI's actual gameplay rotation. It queues the click only when vanilla itself selects the intended target.
- `AttackHitRegistrationBridge` retains that target for one short-lived click pulse.
- `AttackHitRegistrationMixin` hooks `Minecraft.startAttack` at its entry. For an AI click, the bridge runs the same vanilla picker again immediately before vanilla processes the attack.
- If vanilla no longer selects the intended target, the stale AI click is cancelled rather than allowing a misleading miss/block/other-entity swing. If it still selects the intended target, the mixin leaves the freshly computed vanilla hit result in place and lets the normal attack code continue.
- Using `GameRenderer.pick` means Minecraft owns the exact raycast semantics, including the active item's `attack_range` component, vanilla entity hitboxes, block occlusion, and nearest-target selection. The fix does not maintain a competing custom reach calculation.
- Vanilla still owns its normal hands-busy and item restrictions, attack-range validation, cooldown logic, entity attack packet, local swing animation, and server-authoritative damage validation. No reach extension or custom attack packet was added.

## Important scope

This addresses the client-side stale-hit-result / wrong-target-selection path. It cannot force a multiplayer server to apply damage. Server rejection due to authoritative range, cooldown, protection, latency, or server-side rules remains separate. `SWING_HIT_TARGET` remains a client-side target-selection estimate, not proof of server-confirmed damage.

## Verification status

The source change was reviewed against the Minecraft 1.21.11 mapped API: `GameRenderer.pick(float)` is public and updates the player's vanilla hit result, while `Minecraft.startAttack()` is the vanilla click handler. The Gradle build could not run because the wrapper distribution is not cached and the environment could not resolve `services.gradle.org`. Compilation and in-game multiplayer testing therefore remain unverified.
