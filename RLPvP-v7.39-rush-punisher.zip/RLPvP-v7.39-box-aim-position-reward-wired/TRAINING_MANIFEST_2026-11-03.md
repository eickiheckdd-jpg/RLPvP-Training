# RLPvP v7.38 fresh input-spam candidate training manifest

## Run configuration
- Run type: fresh (no resume checkpoint)
- Target: 3,000,000 aggregate environment ticks
- Seed: 20261103
- Workers/environments: 2
- Observation mode: compact 126 observations
- Recurrent policy: GRU enabled (64 hidden channels, 18 recurrent input channels)
- GRU prefetch: enabled (`-Drlpvp.gruPrefetch=true`)
- Simulator kit: normal diamond sword vs full diamond armor with Protection III (`diamond_prot3`)
- Log interval: 25,000 aggregate ticks
- Start: 2026-11-03 11:21:43 UTC (launch time)

## Exact source behavior
This source includes the heavy GRU replay prefetch optimization and the input-spam guard candidate. The input guard keeps W/S and A/D direction changes outcome-driven; those are not penalized because they can be useful strafes, dodges, W/S-taps, and sprint resets. It applies a very small, per-tick and per-episode bounded penalty to repeated sprint/sneak toggling only when the agent is otherwise idle, outside recent-hit/recent-damage grace windows. Sprinting without forward input and staying stuck while pressing movement remain covered by existing tiny waste guards. Holding sneak and tactical use while moving are free. There is no blanket attack-button penalty.

No actor/critic/GRU architecture, observation layout, PPO objective, combat physics, aim or movement action outputs, curriculum, opponent league, or checkpoint format was changed by the spam regularizer.

## Pre-training checks
- Java 21 simulator/training sources compiled successfully with `javac`.
- `SpamGuardCheck`: passed.
- `MoveSpamCheck`: passed, including ordinary W/sprint, A/D strafing, W/S reversals, sprint toggling while moving, short sneak bursts, and bounded idle sneak-toggle penalty.
- `GruCellCheck`: passed exact copied-cache BPTT gradient equality and finite-difference gradient checks.
- `DiamondProt3KitTest`: 27 checks passed.
- `sim/regression.sh`: completed successfully, including network, combat outcome, sprint follow-up, simulator physics, kit, league/PFSP, and 126-observation/GRU migration checks.

The full Fabric/Gradle mod build was not part of this simulator-only training launch and has not been revalidated. The Gradle wrapper previously required an external distribution download.

## First live measurements (2026-11-03 UTC)
- Tick 26,626 at trainer elapsed 72 s.
- Tick 51,202 at trainer elapsed 142 s.
- Measured throughput between those samples: `(51,202 - 26,626) / (142 - 72) = 351.1 environment ticks/s`.
- Average from start to the second sample: `51,202 / 142 = 360.6 environment ticks/s`.
- This is an early Stage 1 measurement, not a guaranteed sustained 3-million-tick throughput.
- At the second sample: process was live, 2 environments, approximately 152% CPU, ~165 MB RSS, 22 Java threads; host had 3 logical CPUs and ~4.5 GB RAM available.
- JVM thread dump confirmed `rlpvp-gru-replay-prefetch` was running; JVM properties confirmed `obs126=true`, `gruPrefetch=true`, `trainLogInterval=25000`, and `sim.kit=diamond_prot3`.

See the run's external `stdout.log` and checkpoint files for subsequent progress. This manifest is a point-in-time record, not a completion claim.
