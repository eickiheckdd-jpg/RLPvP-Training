# RLPvP build-fix report

## Source inspected

`rlpvp-v7.20-sprint-followup.zip` (root project directory: `rlpvp-v7.17-merged`).

## Changes made

- `src/main/java/com/rlpvp/Trainer.java`
  - Moved `double dist = myPos.distanceTo(oppPos);` before `motion.tick(...)`, which uses `dist`. This fixes the definite `cannot find symbol: dist` compile error in this source snapshot.
- `src/main/java/com/rlpvp/MotionMemory.java`
  - Added `FEATURE_COUNT` as an alias for `Config.V2_FEATURES` so observation-layout code can refer to the declared number of motion features without duplicating the value.
- `tests/run.sh`
  - Added `SprintHitFollowupMemory.java` and `SprintHitFollowupMemoryTest.java` to the lightweight test compilation/run.
  - Runs `MotionMemoryCheck` with sprint-follow-up memory disabled for that test because it asserts the older 30-feature summary layout; sprint-follow-up memory is separately tested with its default enabled.
- `tests/NetCapacityCheck.java`
  - Updated the expected actor parameter counts to match this source snapshot's current default observation size.
- `BUILD_FIX_REPORT.md`
  - Added this report.

## Files deleted

None.

## Verification

- `sh tests/run.sh`: PASS (exit code 0).
- `sh sim/run.sh 5000 /tmp/rlpvp-buildfix-smoke.bin 123`: PASS; saved a 5,000-tick state at Stage 1.
- `./gradlew build --no-daemon`: NOT VERIFIED. Gradle could not download Gradle 9.5.1 because this environment could not resolve `services.gradle.org` (`curl: (6) Could not resolve host`). This is a network/bootstrap failure, not a successful Fabric build.

## Important source/log mismatch

The CI log provided by the user also reports errors in `CombatMemory.java` and references `Config.COMBAT_MEMORY`. Those symbols cannot be reproduced from the uploaded ZIP: this ZIP contains no `CombatMemory.java` and no `Config.COMBAT_MEMORY` reference. It uses `MotionMemory` and `SprintHitFollowupMemory` instead. I did not invent a `CombatMemory` class or add a speculative configuration switch, because that could create overlapping observation features or change the model input layout. To resolve those remaining CI errors specifically, the source revision that contains `CombatMemory.java` is needed.
