RLPvP v8 physics fidelity prototype

Start here:
- README.md
- CHANGELOG_V8_MINECRAFT26.md
- docs/MINECRAFT_26_3_REFERENCE_AUDIT.md

What changed:
- Added independent Minecraft26Physics helpers and integrated them into the offline PvpSim movement / knockback path.
- Added attack-speed-derived cooldown timing, correct jump velocity max behavior, friction modifiers, and air drag controls.
- Reused scratch arrays in per-tick physics operations to avoid temporary vector allocations.
- Added deterministic physics tests and fixed a couple of pre-existing test harness issues.

Quick checks:
  ./sim/regression.sh
  ./sim/prediction.sh
  ./sim/aimstability.sh
  ./sim/bench.sh 5

Smoke training:
  ./sim/run.sh 10000 smoke.bin 42

Optional physics profiles (set as JVM options):
  JAVA_TOOL_OPTIONS='-Dsim.blockFriction=0.98' ./sim/run.sh 10000 ice-smoke.bin 43
  JAVA_OPTS='-Dsim.blockFriction=0.98' ./sim/train_parallel.sh 1000000 ice-model.bin 43 - 4 -

Important limitations:
- This is a measured fidelity increment, not 99% parity.
- Full voxel/AABB block collision, fluids, all item components and complete server packet validation are still outstanding.
- Do not resume a large production training run on a changed physics profile without a controlled A/B evaluation.
- No trained-policy improvement or live Minecraft 26.3 parity has been established by the smoke tests.
