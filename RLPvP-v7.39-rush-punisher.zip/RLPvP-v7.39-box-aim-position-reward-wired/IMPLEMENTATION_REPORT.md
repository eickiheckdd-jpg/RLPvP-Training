# Implementation report — RLPvP v7.15

This package contains the implementation changes described in `docs/CHANGELOG_V7_15_IMPLEMENTED.md`.

## Verification performed

- Minecraft-free Java compilation for the simulator and regression checks succeeded.
- `RlTests`: passed, including parameter count, widened-network function preservation, Wilson bounds, and checkpoint save/load roundtrip.
- `MotionMemoryCheck`: passed with `-Drlpvp.obsV2=true`.
- `GuardCheck`: passed, including exact stage-entry restoration and no demotion at 20% wins.
- `SpamGuardCheck`: passed, including movement-penalty cap and no penalty for purposeful closing movement.
- Other regression checks in `tests/run.sh` passed through the camera test sequence; the full script hit the execution time limit during its long run. `GameplayRotationCheck` was then run separately and passed all checks.
- Default simulator smoke run saved a checkpoint at 5,000 ticks.
- Warm-start smoke run loaded a base checkpoint into `m10 + OBS_V2`, advanced to 5,001 ticks, and saved successfully. A subsequent resume of that checkpoint advanced to 5,002 ticks and saved successfully.
- `ModelInfo` ran for `base`, `m10 + OBS_V2`, and `m15`. Reported approximate weight-only memory: base 0.52 MiB, m10 10.06 MiB, m15 15.14 MiB.

## Not verified

- `./gradlew build --no-daemon` could not run because the Gradle wrapper distribution download failed (`Could not resolve host: services.gradle.org`). Therefore the Fabric/Minecraft mod build is **not confirmed** in this environment.
- No long training run was performed, so there is no claim of improved win rate or combat performance.
- `m15` has a different network depth and intentionally requires fresh training; the loader rejects automatic depth-changing transfers.
