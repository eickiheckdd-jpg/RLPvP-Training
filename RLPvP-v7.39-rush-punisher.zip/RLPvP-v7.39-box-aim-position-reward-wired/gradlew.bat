@echo off
rem Lightweight Gradle launcher. Downloads the distribution named in
rem gradle\wrapper\gradle-wrapper.properties (Gradle 9.5.1) and runs it.
rem Run "gradlew wrapper" once to replace this with the official wrapper files.
setlocal

set "APP_HOME=%~dp0"
set "PROPS=%APP_HOME%gradle\wrapper\gradle-wrapper.properties"
for /f "tokens=1,* delims==" %%a in ('findstr /b "distributionUrl=" "%PROPS%"') do set "URL=%%b"
set "URL=%URL:\=%"
set "NAME=%URL:*/distributions/=%"
set "NAME=%NAME:.zip=%"
set "FOLDER=%NAME:-bin=%"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "DIST_DIR=%GRADLE_USER_HOME%\wrapper\dists\%NAME%"
set "GRADLE_BIN=%DIST_DIR%\%FOLDER%\bin\gradle.bat"

if not exist "%GRADLE_BIN%" (
  if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"
  echo Downloading %URL%
  powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri '%URL%' -OutFile '%DIST_DIR%\dist.zip'; Expand-Archive -Force -Path '%DIST_DIR%\dist.zip' -DestinationPath '%DIST_DIR%'; Remove-Item '%DIST_DIR%\dist.zip'"
  if errorlevel 1 exit /b 1
)

call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
