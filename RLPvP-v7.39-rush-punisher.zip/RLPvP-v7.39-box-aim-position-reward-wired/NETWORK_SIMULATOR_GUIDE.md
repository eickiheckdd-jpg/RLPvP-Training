# V10 network and client/server simulation design

## 1. Model boundary

V10 keeps the existing 20 Hz (50 ms) combat/physics tick and PPO state/action layout. It now separates each participant into:

1. a locally predicted client entity (`me` / `bot`),
2. an authoritative server-side player replica (`serverMe` / `serverBot`),
3. a client→server packet stream, and
4. a server→client packet stream.

The player acts from its locally predicted state and the most recently received remote-entity snapshot. Changed input state, sprint commands, movement/rotation reports, and attack requests travel to the server on one ordered C2S stream. The server applies packets in stream order and makes hit decisions from its own replicas. Changed entity/player snapshots, knockback velocity, and corrections travel back on the client's ordered S2C stream. Health/damage rewards use authoritative server health; observation-side opponent/self health and hurt state use delivered snapshots.

This is a Minecraft-inspired standalone approximation. It does not invoke the supplied classes as a running game, nor does it embed Netty or a dedicated server.

## 2. Delay profile

At the full-lag curriculum stage, each client independently samples a round-trip ping from the configured 20–150 ms range (default). The RTT is split into asymmetric upstream/downstream delays, with each direction between roughly 42% and 58% of RTT. There is a 10% zero-lag episode probability. The upper RTT limit ramps with curriculum stage; early stages remain low-latency so basic control can be learned first.

Each packet then receives:

- Gaussian per-packet jitter (default standard deviation is approximately `1 + 0.035 × RTT`, capped at 10 ms),
- serialization time for an approximate payload plus 40 bytes of TCP/IP framing at 10 Mbps,
- delivery only at simulation tick boundaries,
- a small configured chance of a lost transport segment triggering a retransmission timeout (200 ms by default), and
- FIFO ordering / head-of-line blocking: later stream data cannot overtake the delayed segment.

The application payload is not silently discarded on simulated TCP loss. Instead, its delivery is delayed. This deliberately models reliable ordered TCP much better than an application-level random packet-drop switch.

## 3. Client movement packet behavior

The sender follows the supplied `LocalPlayer.sendChanges()` / `sendPosition()` ordering:

- changed `ServerboundPlayerInputPacket` key state is sent first;
- sprint transition is sent before the movement report;
- a positional report is sent when squared position delta exceeds `(2.0E-4)^2`, or after the 20-tick position reminder;
- rotation changes are sent even when position has not changed;
- on-ground state is carried by position/rotation/status-only reports;
- position and rotation can travel in combined or separate logical forms; and
- a `ServerboundClientTickEndPacket` marker closes each client tick on the same ordered stream, resetting the server's `receivedPositionThisTick` guard exactly where the supplied server handler does.

The V10 `MoveMessage` uses the relevant fields from the uploaded `ServerboundMovePlayerPacket` reference: optional position, optional rotation, on-ground, and horizontal-collision state. The current duel arena has no block collision geometry, so horizontal collision is always false.

The local client continues to integrate movement immediately. Its server replica is not updated until the movement packet arrives.

## 4. Server movement processing

The packet handler mirrors important `ServerGamePacketListenerImpl` checks for the supported duel:

- reject NaN position coordinates and non-finite rotations, then clamp coordinates to the reference world bounds;
- allow at most one positional update between ordered client-tick-end markers;
- apply a generous moved-distance versus expected-motion guard in the same form as the reference;
- accept rotation-only and status updates;
- send a corrective-position packet when this standalone model rejects a position update.

For training stability, an invalid second position packet before a client-tick-end marker is represented as a corrective-position response rather than actually disconnecting the simulated participant, although the reference server disconnects. With normal modeled client ordering, a tick-end marker follows each client tick's update and clears the guard before the next tick's position report. The corrective path is a fallback for invalid packet sequences, not the expected result of ordinary jitter.

The server replica currently snaps to the accepted reported location. It does not perform the full vanilla swept-AABB move/collision/teleport-acknowledgement path. A flat-floor duel is the supported environment.

## 5. Attack processing

A client decides whether the crosshair selected the opponent from its own view, then queues an attack packet on the same client→server stream as its movement and sprint state. That creates realistic ordering effects: a delayed movement/sprint packet can hold a later attack behind it, and a delayed attack is resolved against newer server state rather than the stale click-time picture.

At receipt, the server-side path:

- checks both server replicas are alive;
- checks whether the client selected an entity;
- checks current server-side distance using the configurable stand-alone attack-range guard;
- recomputes attack strength from the server ticker;
- evaluates critical/sprint-hit state from server player state;
- applies the V9 combat formula port to authoritative health; and
- sends the resulting knockback velocity to the victim through its server→client stream.

The default range guard (`3.0`) uses the same argument supplied by the uploaded `ServerGamePacketListenerImpl` to `Player.isWithinAttackRange`. It is still an AABB-distance approximation rather than a complete port of the item attack-range component, whose implementation was not among the supplied source files. The stand-alone client ray selection also remains simpler than the full vanilla client targeting path.

## 6. Server→client state

Knockback, movement corrections, and changed server entity/player snapshots are delivered through the victim's ordered server→client stream. Remote view interpolation starts only after a snapshot arrives. The snapshot payload is a coalesced approximation of the uploaded `ClientboundMoveEntityPacket` and related entity metadata updates; it does not serialize every exact vanilla relative movement delta or exact entity-data packet.

## 7. Uploaded reference source coverage

All 25 source files present in the workspace were copied into `reference/minecraft-26.3/network/` and are used as a behavioral reference only:

- `LocalPlayer.java`: client movement send threshold, position reminder, rotation-only update, sprint transition ordering.
- `ServerboundMovePlayerPacket.java`: move packet field structure (position/rotation/ground/collision).
- `ServerGamePacketListenerImpl.java`: server move packet validation, client-tick-end reset of the per-client-tick position guard, distance validation, and server attack target/range handling. The referenced `ServerboundClientTickEndPacket` class itself was not among the uploaded files; the protocol marker is modeled from the handler.
- `Player.java`: server-side attack method and attack ticker reset behavior; attack-range API entry point.
- `ClientPacketListener.java` and `ClientGamePacketListener.java`: clientbound packet listener flow.
- `ClientboundMoveEntityPacket.java`: remote entity movement update reference.
- `ClientboundSetEntityMotionPacket.java`: server-authoritative motion/knockback packet reference.
- `Connection.java` and `Packet.java`: connection send/packet ordering reference.
- `ServerPlayer.java`, `ServerLevel.java`, `MinecraftServer.java`, `ServerTickRateManager.java`, `TickRateManager.java`: player/server/tick context.
- `Entity.java`, `LivingEntity.java`, `Level.java`, `AABB.java`, `VoxelShape.java`: entity/world/collision API context.
- `Attributes.java`, `DamageSources.java`, `EnchantmentHelper.java`, `ItemStack.java`, `ServerboundPlayerActionPacket.java`: combat/player/action dependencies and related packet context.

These files are preserved verbatim as the supplied reference bundle; no Minecraft package is added as a build dependency.

## 8. Known gaps before claiming vanilla multiplayer parity

- no full TCP congestion control, ACK/window dynamics, exact retransmission state machine, segmentation, TLS/compression, Netty event loops, or real packet batching;
- no complete 1.21.11 server or 26.3 server runtime;
- no complete attack-range component and item-specific range formula;
- no full client raycast, entity-part selection, world border, arbitrary entity validity, or attack interaction checks;
- no swept-AABB block collision, collision correction, fluids, climbing, riding, teleport acknowledgements, or arbitrary movement modes;
- no exact server/client tick-phase synchronization or live ping-pong traces;
- no packet-by-packet differential comparison against a real Minecraft server.

V10 is meaningfully more network-aware than V9's earlier delayed-view/attack-queue approximation, but the remaining gaps must be closed and validated before claiming exact Minecraft networking.
