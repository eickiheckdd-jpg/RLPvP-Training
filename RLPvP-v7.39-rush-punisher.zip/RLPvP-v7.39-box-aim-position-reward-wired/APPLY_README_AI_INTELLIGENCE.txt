RLPvP AI — finalized intelligence implementation update (2026-10-31)

Apply this archive by extracting it over the existing RLPvP project root so the
included relative paths merge into the source tree. The archive contains only
modified source, tests, scripts, and documentation; it intentionally does not
contain training checkpoints or model weights.

Scope:
- Persistent per-opponent habit history in the actor's existing 8 habit inputs.
- Correct 2D radial opponent-motion memory.
- Causal applied-swing, hit-type, whiff, combo, follow-up, and punish telemetry.
- Actual queued-click feedback from the trainer and simulator action path.
- Stage-aware attack feasibility gate.
- Default learned-policy path leaves hand-authored strategy overrides/scoring/guidance off;
  reactive validity/safety checks remain on.
- No scripted aiming, combo, critical-hit, or dodge behavior.
- No changes to Minecraft combat formulas or the Fabric target (Minecraft 1.21.11).

Verification:
- `sh sim/regression.sh`: passed all included deterministic checks.
- `sh tests/run.sh`: stops with four GameplayRotationCheck failures; the camera/aim
  source was not modified in this update. See the implementation report.
- `bash gradlew compileJava --offline --no-daemon` could not complete because the
  Gradle 9.5.1 distribution was not cached and services.gradle.org was unreachable.

No training was run. No checkpoint weights are included or modified by this archive.
