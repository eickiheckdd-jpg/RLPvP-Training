# RLPvP v7.39 — simulator, HUD and PPO frame-time optimization

## Scope and safety

This is a separate source candidate. It does not modify an existing training process, checkpoint, or save file. The target Minecraft mod version is unchanged. The simulator's combat rules, kit, packet/latency model, action space, observation layout, opponent league, and normal PPO objective were not changed by the performance work.

The requested idle-action penalty is a deliberate reward-shaping change, described below. It is intentionally narrow and does not disable or mask any policy actions.

## Results measured against the uploaded v7.39 source

A same-machine, same-seed `ParallelPvpTrain` A/B run used the diamond Prot III kit, two environments, 8,192 requested ticks (the trainer completed at 8,194 ticks because it finishes full rollout batches), seed `765432`, and GRU prefetch enabled in both versions.

| Source | Wall time | User CPU | Peak RSS | Final checkpoint SHA-256 |
|---|---:|---:|---:|---|
| Uploaded v7.39 source | 28.19 s | 45.00 s | 138,908 KB | `01cedb188e2369a88a1712460563549d9b08b9cd5f1123e47429979c7722100c` |
| Optimized candidate | 25.68 s | 41.16 s | 147,840 KB | `01cedb188e2369a88a1712460563549d9b08b9cd5f1123e47429979c7722100c` |

This run measured about **9.8% less wall time** (about **1.10x throughput**) for the additional simulator changes. The final checkpoint hashes were identical, which is strong evidence that these queue/merge optimizations preserved the training result for this fixed workload. Peak memory was about 9 MB higher in this run.

The uploaded source already included a separate GRU replay-prefetch pipeline. Its existing `HEAVY_OPTIMIZATION_REPORT_2026-11-03.md` records a prior 8,192-tick test of about 22.5% more throughput versus synchronous GRU replay, also with byte-identical checkpoints. That is a previous benchmark, not a fresh measurement of this candidate against an unoptimized historical release. These measured gains do **not** establish a 2–3x speedup; the new A/B evidence supports about 1.10x over the uploaded source on this test.

## Simulator hot-path changes

- Per-channel packet delivery changed from a priority queue to FIFO. The simulator already serializes each TCP-like channel and clamps each next arrival to a strictly later time, so arrival order is monotonically increasing by sequence. The FIFO preserves that order while avoiding heap operations.
- Server packet collection changed from concatenate-and-sort to a two-stream linear merge. The tie rule retains the previous stable-sort ordering (the player's stream before the bot's on equal keys).
- The fixed-seed 8,194-tick checkpoint comparison above validates that these changes did not alter the resulting learner checkpoint for the tested run.

## PPO frame-time / 0-FPS mitigation

The Minecraft trainer previously called a complete 128-sample PPO minibatch synchronously from the client tick. That could put all policy, value, and recurrent backprop work into one rendered frame.

The Minecraft client path now calls `learnTickBudgeted()` with a default **2 ms foreground-work budget per client tick**. It accumulates samples in the original minibatch order over multiple frames and still performs exactly one optimizer step using the original full minibatch divisor. GRU forward replay is polled non-blockingly on the client path. The background replay task receives a snapshot of its short recurrent input window, so if the one-rollout queue is overrun the game thread does not wait for that worker; that rare fallback disables prefetch and uses the original synchronous replay path for subsequent batches.

The simulator/offline `learnTick()` API remains synchronous and keeps its prior call behavior. The time budget can be adjusted with `-Drlpvp.clientLearnBudgetNanos=<nanoseconds>`; the default is `2000000` (2 ms).

`PpoTimeSliceCheck` compared a full synchronous rollout update with the sliced update and passed exact equality checks for actor weights, critic weights, GRU weights and Adam moments, plus update/skip counters. This means the tested batch's learning math and resulting state were bit-identical; the client update is merely spread over more wall-clock frames. The next policy update becomes visible after the same complete minibatch, but later in wall-clock time.

This is a strong mitigation for long single-frame PPO stalls, not a guarantee of a fixed frame rate. One individual sample, the final optimizer step, GAE preparation, Minecraft rendering, GPU drivers, shaders and other mods are outside the 2 ms slicing guarantee. A live in-game frame-time capture is still needed to confirm the user's exact setup.

## HUD changes

- Replaced per-render alert-list/record construction and uppercase string creation with six reusable alert slots and constant uppercase labels.
- Reused the two HUD layout columns instead of allocating them every frame.
- Avoided rewriting unchanged HUD geometry and layout-status strings.
- Added `/rl hud preset fps` (or `low`), which switches to the very small MINI HUD. Added `/rl hud preset lite` for the six-widget combat layout. Other existing presets remain available.

These changes reduce HUD-side allocation and drawing work. No Minecraft client benchmark was available here, so no numerical FPS gain is claimed for the HUD. The mini preset should be the lightest option in this code.

## Requested input-spam penalties

The reward guard now charges only low-value, stationary idle behavior:

- Holding sneak while idle incurs a small duration cost after its EMA rate passes 20%.
- Repeated sneak toggles while idle are charged after a 16% toggle-rate threshold.
- Repeated sprint toggles while idle are charged after a 20% toggle-rate threshold.
- Sprint without forward input gets a very small cost.

Normal movement, strafing, W/S reversals, W-taps/S-taps, useful sprint resets, and movement shortly after real hits or taking damage remain exempt. No input is blocked, forced, or rewritten. The episode movement-penalty cap remains in place. This intentionally changes reward only for unnecessary idle spam, as requested; it is not a change to PPO's loss or optimizer.

## Validation

Passed:

- `bash sim/regression.sh` — simulator network, combat/outcome, physics/rules, diamond Prot III kit, league and related regression checks.
- `SpamGuardCheck` — idle sneak duration penalty and telemetry checks.
- `MoveSpamCheck` — idle sprint/sneak toggle penalties and exemptions for combat/movement patterns.
- `PpoTimeSliceCheck` — bit-identical synchronous vs budget-sliced learner state for the tested rollout.
- Same-seed 8,194-tick simulator checkpoint hash comparison — identical.

Limitations:

- A complete `tests/run.sh` invocation did not finish within the 420-second command limit, although the targeted tests above and `sim/regression.sh` completed successfully.
- `./gradlew compileJava` could not run because the wrapper needed to download Gradle 9.5.1 and this environment could not resolve `services.gradle.org`. Consequently, the Fabric/Minecraft client-side HUD integration was statically reviewed but not confirmed by a full Gradle compile in this environment.
- No in-game FPS/frametime benchmark was possible here. The 2 ms budget is a configurable target, not a measured frame-time guarantee.

## Rollback and tuning

- To disable the GRU replay prefetch path, use `-Drlpvp.gruPrefetch=false`.
- To change client PPO work per tick, use `-Drlpvp.clientLearnBudgetNanos=2000000` (2 ms); a lower value favors frame smoothness but can slow learner catch-up, while a higher value may increase training throughput at the cost of larger frame-time spikes.
- To use the very light HUD, run `/rl hud preset fps`. For a more detailed compromise, run `/rl hud preset lite`.
