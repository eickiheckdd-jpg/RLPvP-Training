# v7.34 implementation notes

## Added/changed

- Improved `AimInputFilter` and added `AimJitterSuppressor`; precision tracking is filtered instead of passed through.
- `GameplayRotation` now accepts live mouse sensitivity and quantizes each axis to whole sensitivity-correct mouse counts while preserving fractional remainder.
- Added `CombatIntelligenceSuite`, integrated into `SituationalCombatStack` candidate scoring, guidance, enforcement, and status telemetry. It composes threat assessment, opponent style/pattern estimation, combo-pattern/hurt-window tracking, combo-risk prediction, defensive action selection, anti-combo learning, opportunity detection, attack feasibility, risk evaluation, tactical confidence, predictive planning, strategic goal selection, action-sequence planning, spacing, movement coordination, resource control, and adaptive exchange evaluation.
- Fixed target-selection timeout behavior: the off-state countdown advances every tick even when Minecraft returns the same cached last-hurt entity; fresh damage/target interaction restarts the 10-second grace window.
- Made the target lock sticky while enabled, with immediate input release and AI shutdown when the selected target dies or is removed. It will not silently retarget another player after the selected opponent dies.
- Added target-selection status/remaining-grace telemetry to `/rl status`.
- Updated simulator scripts to compile the new pure-Java systems and added `sim/aimstability.sh` / `AimStabilityEval`.
- Updated mod version and README.

## Existing systems reused instead of duplicated

`SituationalStateInterpreter`, `OpponentBehaviorModel`, `EventDrivenCombatMemory`, `TacticalDecisionEngine`, `CounterfactualActionEvaluator`, `ReactiveCombatController`, `CameraDynamics`, `AimBrake`, and Trainer's sticky target lock already cover much of the earlier recommended architecture. Their existing responsibilities are extended/coordinated rather than duplicated with dozens of empty classes.

## Verification boundary

Pure-Java compile and tests ran. Full Gradle/Fabric compilation was blocked before compilation because the Gradle wrapper could not resolve `services.gradle.org`. No live Minecraft claim is made until that build and in-game tests are run.
- The existing v7.33 2.4-million-tick checkpoint was loaded by `sim/aimprobe.sh`; the policy/checkpoint format remained readable and the simulator completed all eight one-episode smoke matches.
