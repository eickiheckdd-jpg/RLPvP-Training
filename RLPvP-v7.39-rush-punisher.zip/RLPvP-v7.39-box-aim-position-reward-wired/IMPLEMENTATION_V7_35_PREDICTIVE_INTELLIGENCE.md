# v7.35 implementation notes — Predictive Combat Intelligence

## What changed

- Improved the existing `CombatIntelligenceSuite.OpponentPatternPredictor`; no duplicate planner or independent action controller was added.
- The prediction now blends the stored opponent attack/sprint tendencies with observed facing, distance, estimated weapon charge, approach velocity, close-range sprint commitment, and recent swing timing.
- Closing velocity is smoothed with a lightweight EMA to reduce one-tick physics noise. The predictor state resets at each episode boundary.
- The existing risk evaluator now includes a small bounded lateral-motion tie-breaker: when a threat is elevated and a facing enemy is clearly moving laterally, movement opposite the enemy's crossing direction receives a slight defensive preference. It does not override action masks or independent safety checks.
- Updated mod version/description and added `sim/prediction.sh` for deterministic predictive-threat and lateral-scoring checks.

## Verification completed

- `sh sim/prediction.sh` — PASS. Near closing threat 0.342 vs retreating/far threat 0.025; the crossing-direction tie-break preferred the evasive side; a live swing did not lower threat.
- `sh sim/aimstability.sh` — PASS. Jitter amplitude ratio 0.017; responsive turn 22.96 degrees/tick; mouse quantization and yaw wrapping OK.
- `sh sim/regression.sh` — PASS. 43 outcome assertions, 12 sprint-follow-up assertions, and combat-observation-memory test.
- `sh sim/bench.sh 10` — completed the simulator's short idealized-agent smoke benchmark. Results vary by scripted opponent and difficulty. This benchmark is not a trained-checkpoint comparison or a live-human benchmark.

## Verification boundary

No claim is made that the new heuristic has been proven to improve real-player win rate. Full Fabric/Gradle compilation and live Minecraft client testing are still required. Changes preserve the existing neural policy/checkpoint format; there are no new persisted fields and no changes to the model input/output layout.
