# RLPvP simulator primitives

This Gradle subproject contains the dependency-free simulator primitives that were
previously mixed into the Fabric mod's `src/main/java/com/rlpvp` source set:

- `Minecraft263Combat.java` — clean-room port of selected combat/damage arithmetic.
- `Minecraft263Trig.java` — Minecraft-style sine-table trigonometry.
- `Minecraft26Physics.java` — selected movement/physics formulas.
- `MinecraftRules.java` — equipment profiles and the simulator-facing rules adapter.
- `NetworkSimulation.java` — deterministic tick-based latency/jitter/retransmission model.

These classes use only the Java standard library. The module is a Java library and is
configured to compile independently of Fabric/Minecraft dependencies:

```bash
./gradlew :simulator:build
```

**Scope note:** this uploaded project contains simulator primitives, not a complete
standalone duel runner or training/evaluation CLI. The README's historical `sim/run.sh`
and `sim/eval.sh` instructions were stale because those scripts/directories are not
present in the uploaded archive. No full simulator runner has been invented here.

Minecraft target-version reference: 26.3 is used only for simulator formula ports.
The Fabric mod remains on Minecraft 1.21.11.
