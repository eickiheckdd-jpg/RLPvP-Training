package com.rlpvp;

/**
 * Dependency-free Java port of the Minecraft Java 26.3 PvP combat arithmetic used by this simulator.
 *
 * Ported from the user-supplied 26.3 reference methods (see docs/MINECRAFT_26_3_EXACT_PORT.md):
 * Player.getCurrentItemAttackStrengthDelay / getAttackStrengthScale / baseDamageScaleFactor / attack / canCriticalAttack,
 * LivingEntity.hurtServer / getDamageAfterArmorAbsorb / getDamageAfterMagicAbsorb / actuallyHurt / knockback,
 * and CombatRules.getDamageAfterAbsorb / getDamageAfterMagicAbsorb.
 *
 * Float operations and operation ordering are intentionally retained where the reference uses float. This class is
 * not a Mojang class and does not bundle or redistribute Minecraft server implementation code. The target profile
 * is an ordinary, unenchanted diamond-sword hit against ordinary diamond armor with Protection III on each piece.
 */
final class Minecraft263Combat {
    private Minecraft263Combat() {}

    static final float MAX_ARMOR = 20.0F;
    static final float ARMOR_PROTECTION_DIVIDER = 25.0F;
    static final float BASE_ARMOR_TOUGHNESS = 2.0F;
    static final float MIN_ARMOR_RATIO = 0.2F;

    static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    /** Player.getCurrentItemAttackStrengthDelay(): (float)(1.0 / attackSpeed * 20.0). */
    static float attackCooldownDelay(double attackSpeed) {
        if (!(attackSpeed > 0.0) || !Double.isFinite(attackSpeed)) return Float.POSITIVE_INFINITY;
        return (float)(1.0 / attackSpeed * 20.0);
    }

    /** Player.getAttackStrengthScale(partialTick), retaining the reference's float arithmetic. */
    static float attackStrengthScale(int attackStrengthTicker, float partialTick, float delay) {
        if (!(delay > 0.0F) || !Float.isFinite(delay)) return 0.0F;
        return clamp((attackStrengthTicker + partialTick) / delay, 0.0F, 1.0F);
    }

    /** Player.baseDamageScaleFactor(): 0.2F + scale * scale * 0.8F. */
    static float baseDamageScaleFactor(float attackStrengthScale) {
        return 0.2F + attackStrengthScale * attackStrengthScale * 0.8F;
    }

    /** Player.canCriticalAttack() conditions for the supported ordinary living-entity duel. */
    static boolean canCriticalAttack(boolean fullStrengthAttack, float fallDistance, boolean onGround,
                                     boolean onClimbable, boolean inWater, boolean mobilityRestricted,
                                     boolean passenger, boolean targetIsLivingEntity, boolean sprinting) {
        return fullStrengthAttack
            && fallDistance > 0.0F
            && !onGround
            && !onClimbable
            && !inWater
            && !mobilityRestricted
            && !passenger
            && targetIsLivingEntity
            && !sprinting;
    }

    /**
     * Player.attack() damage stage for a normal, unenchanted sword.
     * enchantedDamage is Player.getEnchantedDamage(...) (equal to baseAttackDamage for the base Player class);
     * itemAttackDamageBonus is Item.getAttackDamageBonus(...) (zero for the unenchanted diamond sword).
     */
    static float playerAttackDamage(float baseAttackDamage, float attackStrengthScale, boolean critical,
                                    float enchantedDamage, float itemAttackDamageBonus) {
        float baseDamage = baseAttackDamage;
        float magicBoost = attackStrengthScale * (enchantedDamage - baseDamage);
        baseDamage *= baseDamageScaleFactor(attackStrengthScale);
        baseDamage += itemAttackDamageBonus;
        if (critical) baseDamage *= 1.5F;
        return Math.max(0.0F, baseDamage + magicBoost);
    }

    /**
     * CombatRules.getDamageAfterAbsorb() for the unenchanted target weapon path. The item-specific
     * modifyArmorEffectiveness hook is identity for the requested unenchanted diamond sword.
     */
    static float damageAfterArmorAbsorb(float damage, float totalArmor, float armorToughness,
                                        boolean bypassesArmor) {
        if (bypassesArmor) return damage;
        float toughness = BASE_ARMOR_TOUGHNESS + armorToughness / 4.0F;
        float realArmor = clamp(totalArmor - damage / toughness,
            totalArmor * MIN_ARMOR_RATIO, MAX_ARMOR);
        float armorFraction = realArmor / ARMOR_PROTECTION_DIVIDER;
        float modifiedArmorFraction = clamp(armorFraction, 0.0F, 1.0F);
        float damageMultiplier = 1.0F - modifiedArmorFraction;
        return damage * damageMultiplier;
    }

    /** CombatRules.getDamageAfterMagicAbsorb() (Protection EPF, capped to 20). */
    static float damageAfterProtection(float damage, float totalMagicArmor) {
        float realArmor = clamp(totalMagicArmor, 0.0F, 20.0F);
        return damage * (1.0F - realArmor / 25.0F);
    }

    /** Resistance branch from LivingEntity.getDamageAfterMagicAbsorb(). */
    static float applyResistance(float damage, int resistanceAmplifier, boolean bypassesEffects,
                                 boolean bypassesResistance) {
        if (bypassesEffects || bypassesResistance || resistanceAmplifier < 0) return damage;
        int absorbValue = (resistanceAmplifier + 1) * 5;
        int absorb = 25 - absorbValue;
        float v = damage * absorb;
        return Math.max(v / 25.0F, 0.0F);
    }

    /**
     * Supported ordinary melee damage sequence from LivingEntity.actuallyHurt(): armor, resistance,
     * Protection, then absorption. Flags are exposed for deterministic tests of vanilla bypass tags.
     */
    static DamageResult resolveDamage(float incomingDamage, float totalArmor, float armorToughness,
                                      int resistanceAmplifier, float protectionEpf, float absorption,
                                      boolean bypassesArmor, boolean bypassesEffects,
                                      boolean bypassesResistance, boolean bypassesEnchantments) {
        float damage = incomingDamage < 0.0F ? 0.0F : incomingDamage;
        if (Float.isNaN(damage) || Float.isInfinite(damage)) damage = Float.MAX_VALUE;

        float afterArmor = damageAfterArmorAbsorb(damage, totalArmor, armorToughness, bypassesArmor);
        float afterResistance = applyResistance(afterArmor, resistanceAmplifier,
            bypassesEffects, bypassesResistance);
        float afterProtection;
        if (bypassesEffects || afterResistance <= 0.0F || bypassesEnchantments) {
            afterProtection = afterResistance;
        } else {
            afterProtection = damageAfterProtection(afterResistance, protectionEpf);
        }
        float afterAbsorption = Math.max(afterProtection - absorption, 0.0F);
        float absorbed = afterProtection - afterAbsorption;
        return new DamageResult(damage, afterArmor, afterResistance, afterProtection,
            Math.max(0.0F, afterAbsorption), Math.max(0.0F, absorbed));
    }

    /** LivingEntity.hurtServer() comparison: compare post-block raw damage before armor/effects/enchantments. */
    static float invulnerableExcess(float incomingRawDamage, float lastHurtRawDamage) {
        return Math.max(0.0F, incomingRawDamage - lastHurtRawDamage);
    }

    /** LivingEntity.knockback(): power *= 1 - KNOCKBACK_RESISTANCE. */
    static double knockbackPower(double power, double knockbackResistance) {
        double adjusted = power * (1.0 - knockbackResistance);
        return adjusted <= 0.0 ? 0.0 : adjusted;
    }

    static final class DamageResult {
        final float incoming;
        final float afterArmor;
        final float afterResistance;
        final float afterProtection;
        final float healthDamage;
        final float absorbedDamage;

        DamageResult(float incoming, float afterArmor, float afterResistance, float afterProtection,
                     float healthDamage, float absorbedDamage) {
            this.incoming = incoming;
            this.afterArmor = afterArmor;
            this.afterResistance = afterResistance;
            this.afterProtection = afterProtection;
            this.healthDamage = healthDamage;
            this.absorbedDamage = absorbedDamage;
        }
    }
}
