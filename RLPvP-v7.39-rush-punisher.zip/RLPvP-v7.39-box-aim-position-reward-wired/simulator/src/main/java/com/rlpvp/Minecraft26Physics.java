package com.rlpvp;

/**
 * Dependency-free ports of selected Minecraft Java 26.3 movement primitives.
 *
 * Float arithmetic, input normalization, and trigonometric lookup behavior follow the supplied Entity,
 * LivingEntity, and Mth reference methods. The full Entity.move collision solver, fluids, climbables, effects,
 * and arbitrary attribute/component resolution are not represented by these helpers.
 */
final class Minecraft26Physics {
    private Minecraft26Physics() {}

    static final double DEFAULT_GRAVITY = 0.08;
    static final double DEFAULT_JUMP_STRENGTH = 0.42;
    static final double DEFAULT_BLOCK_FRICTION = 0.6;
    static final double DEFAULT_AIR_DRAG = 0.91;
    static final double DEFAULT_VERTICAL_DRAG = 0.98;
    static final double DEFAULT_FRICTION_MODIFIER = 1.0;
    static final double DEFAULT_AIR_DRAG_MODIFIER = 1.0;
    static final double DEFAULT_SNEAKING_SPEED = 0.3;
    static final double DEFAULT_SPRINT_MULTIPLIER = 1.3;
    static final double DEFAULT_PLAYER_GROUND_SPEED = 0.1;
    static final double DEFAULT_PLAYER_AIR_SPEED = 0.02;
    static final double DEFAULT_PLAYER_SPRINT_AIR_SPEED = 0.026;

    /** Mirrors the 26.3 modified-friction attribute calculation. */
    static double modifiedFriction(double friction, double modifier) {
        // LivingEntity.computeModifiedFriction(float, float), with Java float rounding.
        float value = (float)(1.0F - (1.0F - (float)friction) * (float)modifier);
        return Minecraft263Combat.clamp(value, 0.0F, 1.0F);
    }

    /** Mirrors LivingEntity's ground speed adjustment for blocks with friction above 0.6. */
    static double frictionInfluencedSpeed(double speed, double blockFriction, boolean onGround) {
        if (!onGround) return speed;
        float fs = (float)speed;
        float ff = (float)blockFriction;
        return ff > 0.6F
            ? fs * (0.21600002F / (ff * ff * ff))
            : fs;
    }

    /** Horizontal drag after a movement step; ground drag includes the supporting block's friction. */
    static double horizontalDrag(boolean wasGrounded, double blockFriction, double airDragModifier) {
        float air = (float)modifiedFriction(0.91F, (float)airDragModifier);
        return wasGrounded ? (float)blockFriction * air : air;
    }

    /** Vertical drag used by ordinary air travel for a non-omnidirectional mover. */
    static double verticalDrag(double airDragModifier) {
        return modifiedFriction(0.98F, (float)airDragModifier);
    }

    /** Player attack cooldown derived from the attack-speed attribute (20 ticks / speed). */
    static double jumpVelocity(double currentVerticalVelocity, double jumpPower) {
        return Math.max(currentVerticalVelocity, jumpPower);
    }

    static double attackCooldownTicks(double attackSpeed) {
        return Minecraft263Combat.attackCooldownDelay(attackSpeed);
    }

    /** Entity.getInputVector(), retaining the float speed/yaw and Mth lookup-table trig. */
    static void inputVector(double strafe, double forward, double speed, double yawDegrees, double[] out) {
        double length = strafe * strafe + forward * forward;
        if (length < 1.0E-7) { out[0] = 0.0; out[1] = 0.0; return; }
        double scale = length > 1.0 ? 1.0 / Math.sqrt(length) : 1.0;
        double movementX = strafe * scale * (float)speed;
        double movementZ = forward * scale * (float)speed;
        float angle = (float)yawDegrees * (float)(Math.PI / 180.0);
        float sin = Minecraft263Trig.sin(angle);
        float cos = Minecraft263Trig.cos(angle);
        out[0] = movementX * cos - movementZ * sin;
        out[1] = movementZ * cos + movementX * sin;
    }

    /** LivingEntity.knockback horizontal/vertical velocity update, including the grounded 0.4 cap. */
    static void applyKnockback(double vx, double vy, double vz,
                               double directionX, double directionZ,
                               double power, boolean onGround, double[] out) {
        power = Math.max(0.0, power);
        double lenSq = directionX * directionX + directionZ * directionZ;
        if (lenSq < 1.0e-5) { out[0] = vx; out[1] = vy; out[2] = vz; return; }
        double invLen = 1.0 / Math.sqrt(lenSq);
        double nx = directionX * invLen * power;
        double nz = directionZ * invLen * power;
        out[0] = vx / 2.0 - nx;
        out[1] = onGround ? Math.min(0.4, vy / 2.0 + power) : vy;
        out[2] = vz / 2.0 - nz;
    }

    static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
