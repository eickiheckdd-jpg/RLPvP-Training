package com.rlpvp;

/**
 * Simulator-only configuration copied from the current RLPvP mod defaults.
 * Keep these values aligned with Config.java when changing combat or latency curriculum.
 * System properties preserve the existing command-line tuning switches.
 */
final class SimulatorConfig {
    private SimulatorConfig() {}

    static final int EPISODE_TICKS = 300;
    static final int EPISODE_TICKS_MAX = 1200;
    static final double EPISODE_KILL_TIME_FACTOR = 2.0;
    static final float ENEMY_CHARGE_TICKS = 12.5f;

    static final boolean LAG_RANDOMIZE = Boolean.parseBoolean(
        System.getProperty("rlpvp.lagRandomize", "true"));
    static final double LAG_MIN_MS = Double.parseDouble(
        System.getProperty("rlpvp.lagMinMs", "20"));
    static final double LAG_MAX_MS = Double.parseDouble(
        System.getProperty("rlpvp.lagMaxMs", "150"));
    static final double LAG_NONE_PROB = 0.1;
}
