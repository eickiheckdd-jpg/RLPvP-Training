package com.rlpvp;

/** Mojang Mth SIN lookup table and sin/cos indexing used by movement and sprint knockback. */
final class Minecraft263Trig {
    private Minecraft263Trig() {}
    private static final double SIN_SCALE = 10430.378350470453;
    private static final float[] SIN = new float[65536];
    static {
        for (int i = 0; i < SIN.length; i++) SIN[i] = (float)Math.sin(i / SIN_SCALE);
    }
    static float sin(double radians) {
        return SIN[(int)((long)(radians * SIN_SCALE) & 65535L)];
    }
    static float cos(double radians) {
        return SIN[(int)((long)(radians * SIN_SCALE + 16384.0) & 65535L)];
    }
}
