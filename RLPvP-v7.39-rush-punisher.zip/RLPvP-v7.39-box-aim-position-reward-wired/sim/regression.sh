#!/bin/sh
# Compile and run outcome/timeout/guard regression tests without Minecraft or Gradle dependencies.
set -eu
# Keep the pre-existing regression suite on its historical 8x8 GRU/lag-stack contract.
export JAVA_TOOL_OPTIONS="${JAVA_TOOL_OPTIONS:-} -Drlpvp.obs126=false -Drlpvp.gruHidden=8 -Drlpvp.gruInput=8"
cd "$(dirname "$0")/.."
S=src/main/java/com/rlpvp
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT
javac -d "$OUT" \
  $S/Net.java $S/Symmetry.java $S/ConsequenceModel.java $S/PpoAgent.java $S/SituationalStateInterpreter.java $S/OpponentBehaviorModel.java $S/EventDrivenCombatMemory.java $S/TacticalDecisionEngine.java $S/CounterfactualActionEvaluator.java $S/ReactiveCombatController.java $S/CombatIntelligenceSuite.java $S/SituationalCombatStack.java $S/GruCell.java $S/OpponentMemory.java $S/KbTiming.java $S/Config.java $S/MotionMemory.java $S/CombatObservationMemory.java $S/SprintHitFollowupMemory.java \
  $S/TechniqueDiscovery.java $S/TechniqueOpportunityAudit.java $S/SpamGuard.java $S/Minecraft263Combat.java $S/Minecraft263Trig.java $S/Minecraft26Physics.java $S/MinecraftRules.java $S/CameraMap.java $S/CameraDynamics.java \
  $S/AimBrake.java $S/AimJitterSuppressor.java $S/AimInputFilter.java $S/GameplayRotation.java $S/GlideCamera.java $S/EpisodeOutcome.java $S/Reward.java $S/Curriculum.java $S/OpponentLeague.java $S/RewardTuning.java $S/ObservationRegistry.java \
  $S/ActionMask.java $S/StrafeAction.java $S/ComboDefenseTracker.java $S/CombatPositionReward.java $S/AimGeometry.java $S/ObsStack.java $S/ObsLayout.java $S/HitMemory.java $S/FrozenPolicy.java $S/CameraReward.java \
  $S/CollapseGuard.java $S/TechniqueReward.java $S/BotAI.java $S/BotDifficulty.java \
  $S/NetworkSimulation.java sim/com/rlpvp/PvpSim.java sim/com/rlpvp/ChampionEvaluator.java sim/com/rlpvp/ParallelPvpTrain.java tests/NetworkSimulationTest.java tests/TechniqueOpportunityAuditCheck.java tests/TechniqueRewardPolicyCheck.java tests/PvpSimNetworkTest.java tests/OutcomeRegressionTest.java tests/SprintHitFollowupMemoryTest.java tests/CombatObservationMemoryTest.java tests/RewardAuditCheck.java tests/CombatPositionRewardCheck.java tests/AimGeometryCheck.java tests/Minecraft26PhysicsTest.java tests/MinecraftRulesCheck.java tests/DiamondProt3KitTest.java tests/Minecraft263CombatTest.java tests/MeasuredCombatMergeCheck.java tests/OpponentAdaptationCheck.java tests/EventDrivenCombatMemoryCheck.java tests/SituationalCombatStackCheck.java tests/ParallelLeaguePersistenceCheck.java tests/ParallelLeaguePathCheck.java tests/OpponentLeagueCheck.java tests/Stage9LeagueCheck.java tests/CompactCheckpointMigrationWrite.java tests/CompactObservation126Check.java tests/Compact126CheckpointMigrationCheck.java tests/StrafeActionCheck.java tests/ComboDefenseTrackerCheck.java tests/HoldStrafePolicyCheck.java
java -cp "$OUT" com.rlpvp.NetworkSimulationTest
java -cp "$OUT" com.rlpvp.TechniqueOpportunityAuditCheck
java -cp "$OUT" com.rlpvp.TechniqueRewardPolicyCheck
java -cp "$OUT" com.rlpvp.PvpSimNetworkTest
java -cp "$OUT" com.rlpvp.OutcomeRegressionTest
java -cp "$OUT" com.rlpvp.SprintHitFollowupMemoryTest
java -cp "$OUT" com.rlpvp.CombatObservationMemoryTest
java -cp "$OUT" com.rlpvp.RewardAuditCheck
java -cp "$OUT" com.rlpvp.CombatPositionRewardCheck
java -cp "$OUT" com.rlpvp.AimGeometryCheck
java -cp "$OUT" com.rlpvp.Minecraft26PhysicsTest
java -cp "$OUT" com.rlpvp.MinecraftRulesCheck
java -cp "$OUT" com.rlpvp.DiamondProt3KitTest
java -cp "$OUT" com.rlpvp.Minecraft263CombatTest
java -cp "$OUT" com.rlpvp.MeasuredCombatMergeCheck
java -cp "$OUT" com.rlpvp.OpponentAdaptationCheck
java -cp "$OUT" com.rlpvp.EventDrivenCombatMemoryCheck
java -cp "$OUT" com.rlpvp.StrafeActionCheck
java -cp "$OUT" com.rlpvp.ComboDefenseTrackerCheck
java -cp "$OUT" com.rlpvp.HoldStrafePolicyCheck
java -cp "$OUT" com.rlpvp.SituationalCombatStackCheck
java -cp "$OUT" com.rlpvp.OpponentLeagueCheck
java -cp "$OUT" com.rlpvp.Stage9LeagueCheck
java -cp "$OUT" com.rlpvp.ParallelLeaguePersistenceCheck
java -cp "$OUT" com.rlpvp.ParallelLeaguePathCheck

# Create an actual historical lag-stack checkpoint with the old 8x8 GRU, then load/migrate it in the new 128-input runtime.
java -cp "$OUT" com.rlpvp.CompactCheckpointMigrationWrite "$OUT/legacy-v737.bin"
java -Drlpvp.obs126=true -Drlpvp.gruHidden=64 -Drlpvp.gruInput=18 -cp "$OUT" com.rlpvp.CompactObservation126Check "$OUT/legacy-v737.bin"
java -Drlpvp.obs126=true -Drlpvp.gruHidden=64 -Drlpvp.gruInput=18 -cp "$OUT" com.rlpvp.Compact126CheckpointMigrationCheck
if [ -n "${RLPVP_TEST_COMPACT126_CHECKPOINT:-}" ]; then java -Drlpvp.obs126=true -Drlpvp.gruHidden=64 -Drlpvp.gruInput=18 -cp "$OUT" com.rlpvp.Compact126CheckpointMigrationCheck "$RLPVP_TEST_COMPACT126_CHECKPOINT"; fi
