#!/bin/sh
# Deterministic sanity test for predictive threat estimation and opponent-motion-aware defense.
set -eu
cd "$(dirname "$0")/.."
S=src/main/java/com/rlpvp
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT
javac -d "$OUT" \
  $S/Net.java $S/Symmetry.java $S/ConsequenceModel.java $S/PpoAgent.java \
  $S/SituationalStateInterpreter.java $S/OpponentBehaviorModel.java $S/EventDrivenCombatMemory.java \
  $S/TacticalDecisionEngine.java $S/CounterfactualActionEvaluator.java $S/ReactiveCombatController.java \
  $S/CombatIntelligenceSuite.java $S/SituationalCombatStack.java $S/GruCell.java $S/OpponentMemory.java \
  $S/KbTiming.java $S/Config.java $S/MotionMemory.java $S/CombatObservationMemory.java \
  $S/SprintHitFollowupMemory.java $S/TechniqueDiscovery.java $S/TechniqueOpportunityAudit.java $S/SpamGuard.java $S/Minecraft263Combat.java $S/Minecraft263Trig.java $S/Minecraft26Physics.java $S/MinecraftRules.java \
  $S/CameraMap.java $S/CameraDynamics.java $S/AimBrake.java $S/AimJitterSuppressor.java \
  $S/AimInputFilter.java $S/GameplayRotation.java $S/GlideCamera.java $S/EpisodeOutcome.java \
  $S/Reward.java $S/Curriculum.java $S/OpponentLeague.java $S/RewardTuning.java $S/ObservationRegistry.java $S/ActionMask.java $S/ObsStack.java $S/ObsLayout.java \
  $S/HitMemory.java $S/FrozenPolicy.java $S/CameraReward.java $S/CollapseGuard.java \
  $S/TechniqueReward.java $S/BotAI.java $S/BotDifficulty.java sim/com/rlpvp/CombatPredictionEval.java
java -Drlpvp.intelOff=0 -cp "$OUT" com.rlpvp.CombatPredictionEval
