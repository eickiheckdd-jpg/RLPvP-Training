#!/bin/sh
# Fresh-from-zero 1.5M tick training. Usage:
#   sim/train_fresh_1p5m.sh [output-checkpoint.bin] [seed] [workers]
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
OUT=${1:-"$ROOT/rlpvp-v7.35-fresh-1p5m.bin"}
SEED=${2:-20261029}
WORKERS=${3:-1}
exec "$ROOT/sim/train_parallel.sh" 1500000 "$OUT" "$SEED" - "$WORKERS" -
