#!/bin/sh
# usage: sim/combatbench.sh <state.bin> [episodes] [diffs]      A/B: plain policy vs planner vs full stack, same seeds
#        sim/combatbench.sh ablate <state.bin> [episodes] [diff]  (-Dbits=... to pick INTEL_OFF masks)
set -e
cd "$(dirname "$0")/.."
S=src/main/java/com/rlpvp
OUT=$(mktemp -d)
LIST=$(sed -n 's/^javac -d "\$OUT" //p' sim/bench.sh | sed 's# sim/com/rlpvp/BotBench.java##;s#sim/com/rlpvp/PvpEval.java#sim/com/rlpvp/CombatBench.java#')
eval javac -d "$OUT" $LIST
java $JOPTS -cp "$OUT" com.rlpvp.CombatBench "$@"
