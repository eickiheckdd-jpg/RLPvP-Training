#!/bin/sh
# One command for a reproducible experiment: train -> checkpoints -> final evaluation -> results README.
# usage: sim/pipeline.sh <outdir> <ticks> [seed] [checkpointEveryTicks] [evalEpisodes]
#   e.g. sim/pipeline.sh results/run1 1300000 1 300000 100
# Needs a JDK 21. Trains with the curriculum on performance (see Curriculum); resumes nothing, never overwrites an existing outdir.
set -e
OUTDIR=$1; TICKS=$2; SEED=${3:-1}; EVERY=${4:-300000}; EVALEP=${5:-100}
[ -n "$OUTDIR" ] && [ -n "$TICKS" ] || { echo "usage: $0 <outdir> <ticks> [seed] [checkpointEvery] [evalEpisodes]"; exit 1; }
[ -e "$OUTDIR" ] && { echo "refusing to overwrite $OUTDIR"; exit 1; }
cd "$(dirname "$0")/.."
mkdir -p "$OUTDIR"
S=src/main/java/com/rlpvp
CLS=$(mktemp -d)
javac -d "$CLS" $S/Net.java $S/Symmetry.java $S/ConsequenceModel.java $S/PpoAgent.java $S/SituationalStateInterpreter.java $S/OpponentBehaviorModel.java $S/EventDrivenCombatMemory.java $S/TacticalDecisionEngine.java $S/CounterfactualActionEvaluator.java $S/ReactiveCombatController.java $S/CombatIntelligenceSuite.java $S/SituationalCombatStack.java $S/GruCell.java $S/OpponentMemory.java $S/KbTiming.java $S/Config.java $S/MotionMemory.java $S/CombatObservationMemory.java $S/SprintHitFollowupMemory.java $S/TechniqueDiscovery.java $S/TechniqueOpportunityAudit.java $S/SpamGuard.java $S/Minecraft263Combat.java $S/Minecraft263Trig.java $S/Minecraft26Physics.java $S/MinecraftRules.java $S/CameraMap.java $S/CameraDynamics.java $S/AimBrake.java $S/AimJitterSuppressor.java $S/AimInputFilter.java $S/GameplayRotation.java $S/GlideCamera.java $S/EpisodeOutcome.java $S/Reward.java $S/Curriculum.java $S/OpponentLeague.java $S/RewardTuning.java $S/ObservationRegistry.java $S/ActionMask.java $S/StrafeAction.java $S/ComboDefenseTracker.java $S/CombatPositionReward.java $S/AimGeometry.java $S/ObsStack.java $S/ObsLayout.java $S/HitMemory.java $S/FrozenPolicy.java $S/CameraReward.java $S/CollapseGuard.java $S/TechniqueReward.java $S/BotAI.java $S/BotDifficulty.java $S/NetworkSimulation.java sim/com/rlpvp/PvpSim.java sim/com/rlpvp/PvpEval.java
DONE=0
STATE="$OUTDIR/state.bin"
while [ "$DONE" -lt "$TICKS" ]; do
  NEXT=$((DONE + EVERY)); [ "$NEXT" -gt "$TICKS" ] && NEXT=$TICKS
  if [ "$DONE" -eq 0 ]; then java -Xmx2g -cp "$CLS" com.rlpvp.PvpSim "$NEXT" "$STATE" "$SEED" - - >> "$OUTDIR/train.log" 2>&1
  else java -Xmx2g -cp "$CLS" com.rlpvp.PvpSim "$NEXT" "$STATE" "$SEED" "$STATE" - >> "$OUTDIR/train.log" 2>&1; fi
  cp "$STATE" "$OUTDIR/checkpoint-$NEXT.bin"
  DONE=$NEXT
done
java -Xmx2g -cp "$CLS" com.rlpvp.PvpEval "$STATE" "$EVALEP" > "$OUTDIR/eval.txt" 2>&1 || echo "evaluation failed, see $OUTDIR/eval.txt"
cat > "$OUTDIR/README.md" <<EOF
# Training run: $TICKS ticks, seed $SEED
Produced by sim/pipeline.sh (simulator only, not Minecraft). Files: train.log (progress incl. the gate success rate and hop level),
checkpoint-*.bin (every $EVERY ticks), state.bin (final), eval.txt (final evaluation, $EVALEP episodes per opponent).
EOF
echo "done: $OUTDIR"
