#!/bin/sh
# Fresh 3,000,000-tick Diamond Prot III run. Usage: sim/train_fresh_3m.sh [out.bin] [seed] [workers]
set -eu
cd "$(dirname "$0")/.."
OUT=${1:-rlpvp-v9-fresh-3m.bin}
SEED=${2:-20261030}
WORKERS=${3:-2}
exec sh sim/train_diamond_prot3.sh 3000000 "$OUT" "$SEED" - "$WORKERS" -
