#!/usr/bin/env bash
# Evaluate every .bin checkpoint in a directory tree against the same fixed bot styles/seeds.
# usage: sim/standing-eval-dir.sh <episodes-per-style-per-seed> <checkpoint-directory>
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
EPISODES=${1:?usage: sim/standing-eval-dir.sh <episodes-per-style-per-seed> <checkpoint-directory>}
DIR=${2:?usage: sim/standing-eval-dir.sh <episodes-per-style-per-seed> <checkpoint-directory>}
[[ -d "$DIR" ]] || { echo "checkpoint directory not found: $DIR" >&2; exit 2; }
mapfile -d '' CHECKPOINTS < <(find "$DIR" -type f -name '*.bin' -print0 | sort -z)
((${#CHECKPOINTS[@]} > 0)) || { echo "no .bin checkpoints found under $DIR" >&2; exit 2; }
cd "$ROOT"
exec bash sim/standing-eval.sh "$EPISODES" "${CHECKPOINTS[@]}"
