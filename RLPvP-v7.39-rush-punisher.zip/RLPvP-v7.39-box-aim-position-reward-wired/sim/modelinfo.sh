#!/bin/sh
# usage: JAVA_TOOL_OPTIONS='-Drlpvp.model=m10 -Drlpvp.obsV2=true' sh sim/modelinfo.sh
set -e
cd "$(dirname "$0")/.."
S=src/main/java/com/rlpvp
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT
javac -d "$OUT" \
  "$S/Net.java" "$S/Config.java" "$S/ObsLayout.java" "$S/ObsStack.java" "$S/ActionMask.java" \
  "$S/Symmetry.java" "$S/ConsequenceModel.java" "$S/PpoAgent.java" "$S/SituationalStateInterpreter.java" "$S/OpponentBehaviorModel.java" "$S/EventDrivenCombatMemory.java" "$S/TacticalDecisionEngine.java" "$S/CounterfactualActionEvaluator.java" "$S/ReactiveCombatController.java" "$S/CombatIntelligenceSuite.java" "$S/SituationalCombatStack.java" "$S/GruCell.java" \
  "$S/OpponentMemory.java" "$S/KbTiming.java" "$S/TechniqueDiscovery.java" "$S/TechniqueOpportunityAudit.java" "$S/SpamGuard.java" \
  "$S/Minecraft263Combat.java" "$S/Minecraft263Trig.java" "$S/Minecraft26Physics.java" "$S/MinecraftRules.java" "$S/CameraMap.java" "$S/CameraDynamics.java" "$S/AimBrake.java" "$S/AimJitterSuppressor.java" "$S/AimInputFilter.java" \
  "$S/GameplayRotation.java" "$S/GlideCamera.java" "$S/GlideBridge.java" "$S/EpisodeOutcome.java" \
  "$S/Reward.java" "$S/Curriculum.java" "$S/OpponentLeague.java" "$S/RewardTuning.java" "$S/ObservationRegistry.java" "$S/HitMemory.java" "$S/MotionMemory.java" \
  "$S/CombatObservationMemory.java" "$S/SprintHitFollowupMemory.java" "$S/FrozenPolicy.java" \
  "$S/CameraReward.java" "$S/CollapseGuard.java" "$S/TechniqueReward.java" "$S/BotAI.java" \
  "$S/BotDifficulty.java" "$S/ModelInfo.java"
java -cp "$OUT" com.rlpvp.ModelInfo
