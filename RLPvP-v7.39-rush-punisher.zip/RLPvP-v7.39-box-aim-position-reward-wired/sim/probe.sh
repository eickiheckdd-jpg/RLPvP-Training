#!/bin/sh
# usage: sim/probe.sh <state.bin> [trainTransitions] [testTransitions]
# Held-out, fixed-seed check of the consequence model against a persistence baseline (evaluation only, trains no policy).
set -e
cd "$(dirname "$0")/.."
S=src/main/java/com/rlpvp
OUT=$(mktemp -d)
javac -d "$OUT" $S/Net.java $S/Symmetry.java $S/ConsequenceModel.java $S/PpoAgent.java $S/SituationalStateInterpreter.java $S/OpponentBehaviorModel.java $S/EventDrivenCombatMemory.java $S/TacticalDecisionEngine.java $S/CounterfactualActionEvaluator.java $S/ReactiveCombatController.java $S/CombatIntelligenceSuite.java $S/SituationalCombatStack.java $S/GruCell.java $S/OpponentMemory.java $S/KbTiming.java $S/Config.java $S/MotionMemory.java $S/CombatObservationMemory.java $S/SprintHitFollowupMemory.java $S/TechniqueDiscovery.java $S/TechniqueOpportunityAudit.java $S/SpamGuard.java $S/Minecraft263Combat.java $S/Minecraft263Trig.java $S/Minecraft26Physics.java $S/MinecraftRules.java $S/CameraMap.java $S/CameraDynamics.java $S/AimBrake.java $S/AimJitterSuppressor.java $S/AimInputFilter.java $S/GameplayRotation.java $S/GlideCamera.java $S/EpisodeOutcome.java $S/Reward.java $S/Curriculum.java $S/OpponentLeague.java $S/RewardTuning.java $S/ObservationRegistry.java $S/ActionMask.java $S/StrafeAction.java $S/ComboDefenseTracker.java $S/CombatPositionReward.java $S/AimGeometry.java $S/ObsStack.java $S/ObsLayout.java $S/HitMemory.java $S/FrozenPolicy.java $S/CameraReward.java $S/CollapseGuard.java $S/TechniqueReward.java $S/BotAI.java $S/BotDifficulty.java $S/NetworkSimulation.java sim/com/rlpvp/PvpSim.java sim/com/rlpvp/PvpEval.java sim/com/rlpvp/BotBench.java sim/com/rlpvp/ConsequenceProbe.java
java -Xmx3g -cp "$OUT" com.rlpvp.ConsequenceProbe "$@"
