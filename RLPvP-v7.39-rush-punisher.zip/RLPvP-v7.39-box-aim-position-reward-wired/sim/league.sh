#!/bin/sh
# Two independent lineages (A = the agent you keep, B = its rival: other seed, other weights, other history) train in turns.
# While one trains, the other is frozen and is one of its league opponents. Resumable: run it again after a crash.
# usage: sim/league.sh <classes dir> <out dir>
CP=$1; OUT=$2; mkdir -p "$OUT"; cd "$OUT"
run() { # name target seed rival   (resumes from <name>.bin when it exists)
  [ -f "$OUT/ckpt_$1_$2.bin" ] && return
  if [ -f "$OUT/$1.bin" ]; then R="$OUT/$1.bin"; else R=-; fi
  java -cp "$CP" com.rlpvp.PvpSim "$2" "$OUT/$1.bin" "$3" "$R" "$4" >> "$OUT/$1_$2.log" 2>&1 && cp "$OUT/$1.bin" "$OUT/ckpt_$1_$2.bin"
}
run B 500000 2 -
run A 700000 1 B.bin
run B 750000 2 A.bin
run A 1000000 1 B.bin
java -cp "$CP" com.rlpvp.PvpEval A.bin 100 B.bin > "$OUT/eval_A.txt" 2>&1
echo done > "$OUT/DONE"
