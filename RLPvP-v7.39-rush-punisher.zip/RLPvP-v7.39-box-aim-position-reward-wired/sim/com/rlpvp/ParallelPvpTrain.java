package com.rlpvp;

import java.nio.file.Path;
import java.nio.file.Files;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * Multi-environment training: K simulators run in parallel threads (one acting copy of the agent each), then ONE learner updates on all their
 * rollouts, then the new weights go back to the copies. Same curriculum, rewards, collapse guard and checkpoint format as PvpSim.main, but
 * about K times the experience per second on a K-core machine.
 *
 * Round = (1) every worker plays until its rollout (Config.ROLLOUT ticks) is full, in parallel; (2) all workers are stopped; the learner takes
 * the rollouts one after another and runs the usual PPO epochs (learnTick); (3) the learner's weights are copied to the workers. Nothing writes
 * weights while a thread is reading them, so there are no locks apart from the shared curriculum (its methods are synchronized).
 *
 * Differences from the single-environment run, all deliberate:
 *  - the later rollouts of a round were collected by weights that are 1..K-1 updates old (PPO's clipping + stored log-probs absorb that);
 *  - probes and the collapse guard run on a separate probe copy between rounds, and a rollback/demotion is copied into the learner;
 *  - the consequence (world) model of the saved checkpoint is worker 0's (trained on 1/K of the transitions);
 *  - runs are not bit-reproducible (episode completion order across threads varies).
 * Usage: ParallelPvpTrain <totalTicks> <out.bin> [seed] [resume.bin|-] [workers] [rival.bin|-]
 */
public final class ParallelPvpTrain {
    private static final class Worker {
        final PpoAgent agent;
        final PvpSim sim;
        boolean inEp;
        long base;
        Worker(PpoAgent a, PvpSim s) { agent = a; sim = s; }
    }

    private static void collect(Worker w) {
        while (!Thread.currentThread().isInterrupted() && !w.agent.learnerBusy()) { // until rollout full or shutdown requested
            w.sim.syncCurriculum();
            if (!w.inEp) { w.sim.startEpisode(); w.inEp = true; }
            w.inEp = w.sim.step(true, null);
        }
    }

    public static void main(String[] args) throws Exception {
        long total = Long.parseLong(args[0]);
        Path out = Path.of(args[1]);
        long seed = args.length > 2 ? Long.parseLong(args[2]) : 1;
        Path resumePath = args.length > 3 && !args[3].equals("-") ? Path.of(args[3]) : null;
        Path leagueFile = configureLeagueStorage(out, resumePath);
        PpoAgent master = resumePath != null ? PpoAgent.load(resumePath, seed) : new PpoAgent(seed);
        int k = args.length > 4 ? Integer.parseInt(args[4]) : Math.max(1, Math.min(Integer.getInteger("sim.maxWorkers", 8), Runtime.getRuntime().availableProcessors() - 1)); // default cap 8; raise with -Dsim.maxWorkers=16 on a bigger CPU
        FrozenPolicy rival = args.length > 5 && !args[5].equals("-") ? new FrozenPolicy(PpoAgent.load(Path.of(args[5]), seed + 7)) : null;
        boolean mirror = !"false".equals(System.getProperty("sim.mirror"));
        double lookAlpha = Double.parseDouble(System.getProperty("sim.lookalpha", String.valueOf(Config.LOOK_SMOOTH)));

        Curriculum shared = new Curriculum();
        if (master.stage > 0) shared.restore(master.stage, master.stageEnterTicks);

        // All parallel environments must update the same synchronized Elo/PFSP ledger. Loading separate
        // copies caused last-writer-wins resets and races on the common ratings.csv/snapshot *.tmp files.
        OpponentLeague sharedLeague = new OpponentLeague();
        try { sharedLeague.load(leagueFile); }
        catch (Exception ex) { System.err.println("league ratings not loaded: " + ex.getMessage()); }
        sharedLeague.ensure("current");
        long persistedLeagueGames = sharedLeague.games("current");
        System.out.println("league persistence: " + leagueFile + " (one shared ledger; saved after completed parallel rounds)");

        List<Worker> workers = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            PpoAgent a = new PpoAgent(seed + 100 + i);
            a.adoptFrom(master);
            PvpSim s = new PvpSim(seed + 1 + i, a, sharedLeague, i == 0);
            s.cur = shared;
            s.weaknessStyles = true;
            s.mirrorOn = mirror; s.lookAlpha = lookAlpha; s.rival = rival;
            Worker w = new Worker(a, s);
            w.base = master.totalTicks;
            workers.add(w);
        }
        PpoAgent probeAgent = new PpoAgent(seed + 999);
        probeAgent.adoptFrom(master);
        PvpSim probeSim = new PvpSim(seed + 998, probeAgent, sharedLeague, false);
        probeSim.cur = shared; probeSim.mirrorOn = mirror; probeSim.lookAlpha = lookAlpha; probeSim.rival = rival;

        ExecutorService pool = Executors.newFixedThreadPool(k);
        ChampionEvaluator champion = new ChampionEvaluator(out);
        long logInterval = Long.getLong("rlpvp.trainLogInterval", 25_000L);
        if (logInterval < 1) throw new IllegalArgumentException("rlpvp.trainLogInterval must be >= 1");
        long start = System.currentTimeMillis(), nextLog = (master.totalTicks / logInterval + 1) * logInterval,
            nextProbe = master.totalTicks + Config.GREEDY_PROBE_TICKS;
        System.out.println("parallel training: " + k + " environments, learner at tick " + master.totalTicks + ", stage " + shared.stage());
        try {
            while (master.totalTicks < total) {
                // (1) experience, in parallel
                List<Future<?>> fs = new ArrayList<>();
                for (Worker w : workers) fs.add(pool.submit(() -> collect(w)));
                for (Future<?> f : fs) f.get();           // rethrows a worker's exception: never silently train on fewer environments

                // Worker episodes update the shared league concurrently. Once every rollout is joined,
                // persist any new decided matches so an exception/restart cannot discard the Elo results.
                long leagueGamesNow = sharedLeague.games("current");
                if (leagueGamesNow != persistedLeagueGames) {
                    sharedLeague.save(leagueFile);
                    persistedLeagueGames = leagueGamesNow;
                }

                // (2) learning, one thread, nobody else touches weights now
                long gained = 0;
                for (Worker w : workers) gained += w.agent.totalTicks - w.base;
                master.totalTicks += gained;
                shared.update(master.totalTicks);
                master.setMask(shared.lockMask());
                master.stage = shared.autoStage();
                master.stageEnterTicks = shared.stageEnterTicks();
                float ema = 0; for (Worker w : workers) ema += w.sim.entropyEma; ema /= workers.size();
                float coef = Config.ENTROPY_COEF * shared.entropyScale(master.totalTicks);
                double floor = Config.ENTROPY_FLOOR_FRAC * PpoAgent.maxEntropy(shared.lockMask());
                if (ema > 0 && ema < floor) coef *= Config.ENTROPY_FLOOR_BOOST;
                coef *= Config.stageEntropyScale(shared.stage(), master.totalTicks, shared.stageEnterTicks());
                master.setEntropyCoef(coef);
                for (Worker w : workers) {
                    if (w.agent.handRolloutTo(master)) { while (master.learnerBusy()) master.learnTick(); }
                }
                master.adoptConsequenceFrom(workers.get(0).agent);

                // Snapshot the probe guard at the stage transition, not at the first scheduled probe much later.
                if (probeSim.guard.stage() != shared.stage()) {
                    probeAgent.adoptFrom(master);
                    probeSim.guard.noteStage(shared.stage(), probeAgent);
                }

                // (3) probe + collapse guard on the probe copy (between rounds, single thread), then push the weights back
                if (master.totalTicks >= nextProbe && shared.stage() >= 3 && shared.stage() < 9) {
                    probeAgent.adoptFrom(master);
                    probeSim.syncCurriculum();
                    probeSim.probe();
                    nextProbe = master.totalTicks + Config.GREEDY_PROBE_TICKS;
                    String lp = probeSim.lastProbe == null ? "" : probeSim.lastProbe;
                    if (lp.contains("ROLLBACK") || lp.contains("DEMOTED")) {   // the guard restored weights: the learner takes them over
                        master.importWeights(probeAgent.exportWeights());
                        master.lrScale = probeAgent.lrScale;
                        master.stage = shared.autoStage();
                        master.stageEnterTicks = shared.stageEnterTicks();
                        if (lp.contains("DEMOTED")) for (Worker w : workers) w.sim.botDiff.set(0.0);
                    }
                }
                for (Worker w : workers) { w.agent.adoptFrom(master); w.base = master.totalTicks; }

                // Stage 9 evaluation is independent and non-gating. It benchmarks an immutable copy while
                // the workers continue collecting the next rollout; it never rolls back or blocks PPO updates.
                champion.poll();
                champion.maybeLaunch(master, shared.stage());

                if (master.totalTicks >= nextLog) {
                    nextLog += logInterval;
                    log(master, workers, probeSim, shared, sharedLeague, champion, out, (System.currentTimeMillis() - start) / 1000);
                    master.save(out);
                }
            }
        } finally {
            pool.shutdownNow();
            // collect() observes interruption between simulator steps. Join workers before the final
            // league save so no in-flight episode can update Elo after the ledger has been written.
            try {
                if (!pool.awaitTermination(30, TimeUnit.SECONDS)) {
                    System.err.println("WARNING: training workers did not terminate within 30 seconds; final league save may omit an in-flight episode");
                }
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                System.err.println("WARNING: interrupted while joining training workers; attempting final checkpoint and league saves");
            }
            try { master.save(out); }
            finally {
                try { sharedLeague.save(leagueFile); }
                finally { champion.close(); }
            }
        }
        System.out.println("saved " + out + " at " + master.totalTicks + " ticks, stage " + master.stage
            + " | " + champion.status());
    }

    /**
     * Parallel training uses a checkpoint-specific sidecar, matching PvpSim.main. On a resume, seed a new
     * output sidecar from the resume checkpoint's companion league rather than silently starting at 1200 Elo.
     * Only the ratings ledger and the newest LEAGUE_POOL policy snapshots are copied (older policies are pruned anyway).
     */
    static Path configureLeagueStorage(Path out, Path resume) throws IOException {
        String dirOverride = System.getProperty("sim.league.dir");
        String fileOverride = System.getProperty("sim.league.file");
        Path leagueDir;
        Path leagueFile;
        if (dirOverride == null && fileOverride == null) {
            Path absoluteOut = out.toAbsolutePath();
            leagueDir = absoluteOut.resolveSibling(absoluteOut.getFileName().toString() + ".league");
            if (!Files.exists(leagueDir) && resume != null) {
                Path absoluteResume = resume.toAbsolutePath();
                Path resumeDir = absoluteResume.resolveSibling(absoluteResume.getFileName().toString() + ".league");
                if (Files.isDirectory(resumeDir)) copyLeagueSeed(resumeDir, leagueDir);
            }
            Files.createDirectories(leagueDir);
            leagueFile = leagueDir.resolve("ratings.csv");
        } else {
            if (dirOverride != null) leagueDir = Path.of(dirOverride).toAbsolutePath();
            else leagueDir = Path.of(fileOverride).toAbsolutePath().getParent();
            if (leagueDir == null) leagueDir = Path.of(".").toAbsolutePath();
            leagueFile = fileOverride != null ? Path.of(fileOverride).toAbsolutePath() : leagueDir.resolve("ratings.csv");
            Files.createDirectories(leagueDir);
        }
        System.setProperty("sim.league.dir", leagueDir.toString());
        System.setProperty("sim.league.file", leagueFile.toString());
        return leagueFile;
    }

    private static void copyLeagueSeed(Path sourceDir, Path targetDir) throws IOException {
        Files.createDirectories(targetDir);
        Path sourceRatings = sourceDir.resolve("ratings.csv");
        if (Files.isRegularFile(sourceRatings)) Files.copy(sourceRatings, targetDir.resolve("ratings.csv"));
        Path sourceSnapshots = sourceDir.resolve("snapshots");
        if (!Files.isDirectory(sourceSnapshots)) return;
        List<Path> snapshots;
        try (var paths = Files.list(sourceSnapshots)) {
            snapshots = paths.filter(p -> p.getFileName().toString().matches("snapshot-[0-9]+\\.bin"))
                .sorted(Comparator.comparingLong(ParallelPvpTrain::snapshotTick)).toList();
        }
        Path targetSnapshots = targetDir.resolve("snapshots");
        Files.createDirectories(targetSnapshots);
        int first = Math.max(0, snapshots.size() - Config.LEAGUE_POOL);
        for (int i = first; i < snapshots.size(); i++) {
            Path src = snapshots.get(i);
            Files.copy(src, targetSnapshots.resolve(src.getFileName().toString()));
        }
    }

    private static long snapshotTick(Path path) {
        String name = path.getFileName().toString();
        try { return Long.parseLong(name.substring("snapshot-".length(), name.length() - ".bin".length())); }
        catch (RuntimeException ex) { return Long.MIN_VALUE; }
    }

    private static void log(PpoAgent master, List<Worker> ws, PvpSim probeSim, Curriculum shared,
                            OpponentLeague sharedLeague, ChampionEvaluator champion, Path checkpointOut, long sec) {
        int ep = 0, win = 0, loss = 0, draw = 0, noContest = 0, hits = 0, crit = 0, sprint = 0, swing = 0, whiff = 0, lookN = 0;
        double dealt = 0, taken = 0, ret = 0, look = 0, ent = 0, rtt = 0, c2s = 0, s2c = 0;
        long netMoves = 0, netAttacks = 0, netCorrections = 0, netRetries = 0;
        long netDuplicate = 0, netSpeedReject = 0, netInvalid = 0;
        String msg = "";
        Reward.Telemetry rewardAudit = new Reward.Telemetry();
        TechniqueDiscovery techniqueAudit = new TechniqueDiscovery();
        TechniqueOpportunityAudit techniqueOpportunityAudit = new TechniqueOpportunityAudit();
        for (Worker w : ws) {
            PvpSim s = w.sim;
            ep += s.wEp; win += s.wWin; loss += s.wLoss; draw += s.wDraw; noContest += s.wNoContest; hits += s.wHits; crit += s.wCrit; sprint += s.wSprint; swing += s.wSwing; whiff += s.wWhiff;
            dealt += s.wDealt; taken += s.wTaken; ret += s.wRet; look += s.wLook; lookN += s.wLookN; ent += s.entropyEma;
            rtt += s.networkProfileCount == 0 ? 0 : s.networkRttSumMs / s.networkProfileCount;
            c2s += s.networkProfileCount == 0 ? 0 : s.networkC2sSumMs / s.networkProfileCount;
            s2c += s.networkProfileCount == 0 ? 0 : s.networkS2cSumMs / s.networkProfileCount;
            netMoves += s.movementPackets; netAttacks += s.attackPackets; netCorrections += s.movementCorrections;
            netDuplicate += s.movementDuplicateRejections; netSpeedReject += s.movementSpeedRejections;
            netInvalid += s.movementInvalidRejections; netRetries += s.networkRetransmissions();
            if (!s.lastStageMsg.isEmpty() && msg.isEmpty()) msg = s.lastStageMsg;
            s.lastStageMsg = "";
            rewardAudit.mergeWindow(s.rewardTelemetry); s.rewardTelemetry.clearWindow();
            techniqueAudit.mergeWindow(s.disc); s.disc.clearWindow();
            techniqueOpportunityAudit.mergeWindow(s.techniqueOpportunityAudit); s.techniqueOpportunityAudit.clearWindow();
            s.wEp = s.wWin = s.wLoss = s.wDraw = s.wNoContest = s.wHits = s.wCrit = s.wSprint = s.wSwing = s.wWhiff = 0; s.wDealt = s.wTaken = s.wRet = s.wLook = 0; s.wLookN = 0;
        }
        int n = Math.max(1, ep);
        String rewardRow = rewardAudit.csvRow(master.totalTicks, ep);
        String techniqueRow = techniqueAudit.csvRow(master.totalTicks, shared.stage());
        String techniqueOpportunityRow = techniqueOpportunityAudit.csvRow(master.totalTicks, shared.stage());
        String rewardSummary = rewardAudit.summaryAndReset();
        String techniqueSummary = techniqueAudit.summary();
        String techniqueOpportunitySummary = techniqueOpportunityAudit.summary();
        appendAuditRow(checkpointOut.resolveSibling(checkpointOut.getFileName() + ".reward-audit.csv"),
            Reward.Telemetry.csvHeader(), rewardRow);
        appendAuditRow(checkpointOut.resolveSibling(checkpointOut.getFileName() + ".technique-audit-v2.csv"),
            TechniqueDiscovery.csvHeader(), techniqueRow);
        appendAuditRow(checkpointOut.resolveSibling(checkpointOut.getFileName() + ".technique-opportunity-audit.csv"),
            TechniqueOpportunityAudit.csvHeader(), techniqueOpportunityRow);
        System.out.printf(Locale.ROOT, "tick %7d [%4ds] stage %d | eps %3d win %3.0f%% loss %3.0f%% draw %3.0f%% no-contest %3.0f%% dealt %4.1f taken %4.1f ret %6.1f | hits %d crit %d sprint %d whiff %2.0f%% | cam %.2f deg/t | ent %.2f %s%n",
            master.totalTicks, sec, shared.stage(), ep, 100.0 * win / n, 100.0 * loss / n, 100.0 * draw / n, 100.0 * noContest / n, dealt / n, taken / n, ret / n, hits, crit, sprint,
            100.0 * whiff / Math.max(1, swing), look / Math.max(1, lookN), ent / ws.size(),
            msg + "  " + (shared.stage() < 9 ? probeSim.lastProbe + " | " : "") + shared.status() + " | league " + sharedLeague.summary("current")
                + (shared.stage() >= Config.WEAKNESS_FROM_STAGE ? " | " + sharedLeague.weaknessSummary("current") : "") + (shared.stage() >= 9 ? " | " + champion.status() : "") + " | " + ws.size() + " envs"
                + String.format(Locale.ROOT, " | NET RTT %.1fms C2S %.1f/S2C %.1fms move=%d atk=%d corr=%d retry=%d",
                    rtt / ws.size(), c2s / ws.size(), s2c / ws.size(), netMoves, netAttacks, netCorrections, netRetries)
                    + String.format(Locale.ROOT, " [dup=%d speed=%d invalid=%d]", netDuplicate, netSpeedReject, netInvalid)
                    + "\n    " + rewardSummary + "\n    " + techniqueSummary + "\n    " + techniqueOpportunitySummary);
        techniqueAudit.clearWindow();
        techniqueOpportunityAudit.clearWindow();
    }

    private static void appendAuditRow(Path file, String header, String row) {
        try {
            Path parent = file.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            if (!Files.exists(file)) Files.writeString(file, header + "\n", java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
            Files.writeString(file, row + "\n", java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
        } catch (IOException ex) {
            System.err.println("could not append audit file " + file + ": " + ex.getMessage());
        }
    }
}
