package com.rlpvp;

/** Deterministic sanity checks for predictive threat and lateral evasive tie-breaking. */
public final class CombatPredictionEval {
    private CombatPredictionEval() { }

    public static void main(String[] args) {
        float[] approaching = frame(2.6f, 0.88f, 0.85f, 0.96f, 0.9f, 1.0f, 1.0f);
        float[] retreating = frame(4.9f, -0.25f, -0.45f, 0.90f, 0.0f, 0.0f, 0.0f);
        SituationalStateInterpreter interpreter = new SituationalStateInterpreter();
        SituationalStateInterpreter.State near = interpreter.interpret(approaching, 0, 0, 0, false);
        SituationalStateInterpreter.State far = interpreter.interpret(retreating, 0, 0, 0, false);
        OpponentBehaviorModel.Profile profile = new OpponentBehaviorModel.Profile();
        profile.attackRate = 0.12;
        profile.sprintRate = 0.35;
        profile.samples = 100;
        EventDrivenCombatMemory.Snapshot memory = new EventDrivenCombatMemory.Snapshot(
            false, 0.5, 0.2, 0.0, -1, 0, 0, 0, 0, 0, 0, 0);
        TacticalDecisionEngine tactics = new TacticalDecisionEngine();

        CombatIntelligenceSuite nearSuite = new CombatIntelligenceSuite();
        nearSuite.update(approaching, near, profile, memory,
            tactics.choose(near, profile, memory, 0.2));
        CombatIntelligenceSuite farSuite = new CombatIntelligenceSuite();
        farSuite.update(retreating, far, profile, memory,
            tactics.choose(far, profile, memory, 0.0));

        double nearThreat = nearSuite.predictedThreat();
        double farThreat = farSuite.predictedThreat();
        require(Double.isFinite(nearThreat) && nearThreat >= 0 && nearThreat <= 1, "near threat must be finite and bounded");
        require(Double.isFinite(farThreat) && farThreat >= 0 && farThreat <= 1, "far threat must be finite and bounded");
        require(nearThreat > farThreat + 0.07,
            "closing, facing, charged opponent should be forecast as more dangerous (near=" + nearThreat + ", far=" + farThreat + ")");

        float[] left = new float[PpoAgent.N_ACT];
        float[] right = new float[PpoAgent.N_ACT];
        left[2] = right[2] = 1f;
        left[3] = 0f;
        right[3] = 2f;
        double leftScore = nearSuite.scoreCandidate(left, 0);
        double rightScore = nearSuite.scoreCandidate(right, 0);
        require(Double.isFinite(leftScore) && Double.isFinite(rightScore), "candidate scores must remain finite");
        require(leftScore > rightScore,
            "against a facing opponent crossing right, left evasive action should win the tie-break (left=" + leftScore + ", right=" + rightScore + ")");

        // A live swing should outrank the same non-swing state even if the opponent's base profile is unchanged.
        float[] swinging = approaching.clone();
        swinging[23] = 1f;
        SituationalStateInterpreter.State swingState = interpreter.interpret(swinging, 0, 0, 0, false);
        CombatIntelligenceSuite swingSuite = new CombatIntelligenceSuite();
        swingSuite.update(swinging, swingState, profile, memory,
            tactics.choose(swingState, profile, memory, 0.2));
        require(swingSuite.predictedThreat() >= nearThreat, "live swing cue must not lower predicted threat");

        System.out.printf(java.util.Locale.ROOT,
            "Combat prediction PASS: close-threat=%.3f retreat-threat=%.3f left-score=%.3f right-score=%.3f swing-threat=%.3f%n",
            nearThreat, farThreat, leftScore, rightScore, swingSuite.predictedThreat());
    }

    private static float[] frame(float distance, float facing, float closing, float charge,
                                 float sprint, float enemyReach, float selfInReach) {
        float[] o = new float[Config.OBS_SIZE];
        o[0] = 1f; o[6] = 1f; o[12] = distance / 6f;
        o[13] = 0f; o[14] = 0f; o[15] = 1f;
        o[16] = 0.2f; o[17] = 0.8f; o[19] = 1f;
        o[21] = facing; o[22] = sprint; o[23] = 0f;
        o[26] = 1f; o[34] = 0.2f; o[42] = charge;
        o[44] = enemyReach; o[45] = selfInReach; o[47] = closing;
        return o;
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
