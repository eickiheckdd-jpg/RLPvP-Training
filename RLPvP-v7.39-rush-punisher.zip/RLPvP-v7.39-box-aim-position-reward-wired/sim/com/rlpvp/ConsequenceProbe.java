package com.rlpvp;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Measures whether a one-step consequence model predicts what the simulator really does next, on HELD-OUT fixed-seed
 * transitions, against a persistence baseline (next frame = current frame). Evaluation only: never trains the policy.
 * Usage: ConsequenceProbe <state.bin> [trainTicks] [testTicks]
 */
public final class ConsequenceProbe {
    interface Model {
        String name();
        void observe(float[] obs, float[] act, float[] next);
        void predict(float[] obs, float[] act, float[] out);
    }

    /** The model exactly as shipped (absolute next-frame regression). */
    static final class Old implements Model {
        final ConsequenceModel m = new ConsequenceModel(new Random(5));
        public String name() { return "production ConsequenceModel"; }
        public void observe(float[] o, float[] a, float[] n) { m.observe(o, a, n); }
        public void predict(float[] o, float[] a, float[] out) { m.predict(o, a, out); }
    }

    /** Candidate: predicts the CHANGE of each feature, scaled by that feature's running residual size. */
    static final class Res implements Model {
        static final int IN = Config.OBS_SIZE + PpoAgent.N_ACT, OUT = Config.FRAME;
        final Net net = new Net(new int[]{IN, 128, 128, OUT}, 0.08f, new Random(5));
        final float[] x = new float[IN], g = new float[OUT], var = new float[OUT];
        final String label; final boolean normalize; final float floor, lr, clip; final int passes; long n;
        Res(String label, boolean normalize, float floor, float lr, int passes) { this(label, normalize, floor, lr, passes, 1.0f); }
        Res(String label, boolean normalize, float floor, float lr, int passes, float clip) {
            this.clip = clip; this.label = label; this.normalize = normalize; this.floor = floor; this.lr = lr; this.passes = passes;
            java.util.Arrays.fill(var, floor * floor);
        }
        public String name() { return label; }
        float scale(int i) { return normalize ? (float) Math.max(floor, Math.sqrt(var[i])) : 1f; }
        void pack(float[] o, float[] a) { System.arraycopy(o, 0, x, 0, Config.OBS_SIZE); System.arraycopy(a, 0, x, Config.OBS_SIZE, PpoAgent.N_ACT); }
        public void observe(float[] o, float[] a, float[] nx) {
            n++;
            if (n % 10 == 0) return; // same 90/10 train/validation split as the shipped model
            pack(o, a);
            for (int p = 0; p < passes; p++) {
                float[] pr = net.forward(x);
                for (int i = 0; i < OUT; i++) {
                    float r = nx[i] - o[i];
                    if (p == 0) var[i] = 0.999f * var[i] + 0.001f * r * r;
                    float s = scale(i);
                    g[i] = 2f * (pr[i] - r / s) / OUT;
                }
                net.backward(g);
                net.step(lr, clip, 1);
            }
        }
        public void predict(float[] o, float[] a, float[] out) {
            pack(o, a);
            float[] pr = net.forward(x);
            for (int i = 0; i < OUT; i++) out[i] = o[i] + scale(i) * pr[i];
        }
    }

    // ---------------------------------------------------------------- data
    static final class Data {
        final List<float[]> obs = new ArrayList<>(), act = new ArrayList<>(), next = new ArrayList<>();
        int size() { return obs.size(); }
    }

    static Data collect(PpoAgent agent, long seed, long ticks, double eps) {
        Data d = new Data();
        PvpSim sim = new PvpSim(seed, agent);
        sim.evalDifficulty = 1.0;
        agent.setMask(0);
        Random ex = new Random(seed * 31 + 7);
        final float[][] pend = new float[2][];
        sim.actionTap = (in, a) -> {
            float[] act = a.clone();
            if (eps > 0) { // exploration so the model also sees actions the policy rarely picks (the planner will ask about them)
                if (ex.nextDouble() < eps) act[2] = ex.nextInt(3);
                if (ex.nextDouble() < eps) act[3] = ex.nextInt(3);
                if (ex.nextDouble() < eps) act[4] = ex.nextBoolean() ? 1f : 0f;
                if (ex.nextDouble() < eps) act[5] = ex.nextBoolean() ? 1f : 0f;
                if (ex.nextDouble() < eps) act[6] = ex.nextBoolean() ? 1f : 0f;
            }
            if (pend[0] != null) { d.obs.add(pend[0]); d.act.add(pend[1]); d.next.add(java.util.Arrays.copyOf(in, Config.FRAME)); }
            pend[0] = in.clone(); pend[1] = act.clone();
            return act;
        };
        Curriculum.Opponent[] opps = {Curriculum.Opponent.STATIONARY, Curriculum.Opponent.STRAFE, Curriculum.Opponent.WALK,
            Curriculum.Opponent.AGGRESSIVE, Curriculum.Opponent.STRONG};
        PvpSim.EvalStats ev = new PvpSim.EvalStats();
        int k = 0;
        while (d.size() < ticks) {
            pend[0] = null; pend[1] = null;
            sim.startEpisodeFor(opps[k++ % opps.length]);
            while (sim.step(false, ev)) {}
        }
        return d;
    }

    // ---------------------------------------------------------------- metrics
    static final String[] GROUP_NAMES = {"health (own,enemy)", "hurt timers", "enemy swing/charge", "distance/rel pos/closing",
        "enemy motion", "own motion", "hit timers", "echo of my last action"};
    static final int[][] GROUPS = {{0, 15}, {7, 20}, {23, 34, 42}, {9, 10, 11, 12, 47}, {16, 17, 18, 19, 22}, {1, 2, 3, 4, 5}, {24, 25, 46, 6}, {27, 28, 29, 30, 31, 32, 33}};

    static double auc(double[] score, boolean[] pos) {
        int n = score.length; Integer[] idx = new Integer[n];
        for (int i = 0; i < n; i++) idx[i] = i;
        java.util.Arrays.sort(idx, (p, q) -> Double.compare(score[p], score[q]));
        double rankSum = 0; long np = 0;
        for (int r = 0; r < n; ) { // average ranks over ties
            int e = r; while (e + 1 < n && score[idx[e + 1]] == score[idx[r]]) e++;
            double avg = (r + e) / 2.0 + 1;
            for (int j = r; j <= e; j++) if (pos[idx[j]]) { rankSum += avg; np++; }
            r = e + 1;
        }
        long nn = n - np;
        return np == 0 || nn == 0 ? Double.NaN : (rankSum - np * (np + 1) / 2.0) / ((double) np * nn);
    }

    static void report(Model m, Data h, String tag) {
        int n = h.size();
        double[] mae = new double[Config.FRAME], per = new double[Config.FRAME];
        double seM = 0, seP = 0;
        double[] dropE = new double[n], dropM = new double[n];
        boolean[] evE = new boolean[n], evM = new boolean[n];
        float[] out = new float[Config.FRAME];
        double condPred = 0, condReal = 0, offPred = 0; int condN = 0;
        float[] alt = new float[PpoAgent.N_ACT], out2 = new float[Config.FRAME];
        double gate = Config.MIN_ATTACK_STRENGTH;
        for (int s = 0; s < n; s++) {
            float[] o = h.obs.get(s), a = h.act.get(s), t = h.next.get(s);
            m.predict(o, a, out);
            for (int i = 0; i < Config.FRAME; i++) { mae[i] += Math.abs(out[i] - t[i]); per[i] += Math.abs(o[i] - t[i]); }
            for (int hf : new int[]{0, 15}) { seM += (out[hf] - t[hf]) * (out[hf] - t[hf]); seP += (o[hf] - t[hf]) * (o[hf] - t[hf]); }
            dropE[s] = o[15] - out[15]; dropM[s] = o[0] - out[0];
            evE[s] = o[15] - t[15] > 0.02f; evM[s] = o[0] - t[0] > 0.02f;
            if (a[4] > 0.5f && o[44] > 0.5f && o[6] >= gate) { // I swing, enemy inside my reach, weapon charged
                condN++; condPred += dropE[s]; condReal += Math.max(0, o[15] - t[15]);
                System.arraycopy(a, 0, alt, 0, alt.length); alt[4] = 0f; // same state, no swing
                m.predict(o, alt, out2); offPred += o[15] - out2[15];
            }
        }
        double tm = 0, tp = 0;
        for (int i = 0; i < Config.FRAME; i++) { mae[i] /= n; per[i] /= n; tm += mae[i]; tp += per[i]; }
        System.out.printf(Locale.ROOT, "  [%s] %-26s overall MAE %.4f vs persistence %.4f  (skill %+.1f%%)%n", tag, m.name(), tm / Config.FRAME, tp / Config.FRAME, 100 * (1 - tm / tp));
        StringBuilder sb = new StringBuilder("      skill by group:");
        for (int g = 0; g < GROUPS.length; g++) {
            double a1 = 0, b1 = 0; for (int i : GROUPS[g]) { a1 += mae[i]; b1 += per[i]; }
            sb.append(String.format(Locale.ROOT, " %s %+.0f%%;", GROUP_NAMES[g].split(" ")[0], b1 < 1e-9 ? 0 : 100 * (1 - a1 / b1)));
        }
        System.out.println(sb);
        System.out.printf(Locale.ROOT, "      health squared-error skill vs persistence %+.1f%%%n", 100 * (1 - seM / seP));
        System.out.printf(Locale.ROOT, "      AUC(damage I deal) %.3f  AUC(damage I take) %.3f   | swing-in-reach states %d: predicted drop %.4f vs real %.4f, same states without swing %.4f%n",
            auc(dropE, evE), auc(dropM, evM), condN, condN == 0 ? 0 : condPred / condN, condN == 0 ? 0 : condReal / condN, condN == 0 ? 0 : offPred / condN);
    }

    public static void main(String[] a) throws Exception {
        long trainTicks = a.length > 1 ? Long.parseLong(a[1]) : 60_000, testTicks = a.length > 2 ? Long.parseLong(a[2]) : 15_000;
        PpoAgent agent = PpoAgent.load(Path.of(a[0]), 5);
        long t0 = System.currentTimeMillis();
        Data train = collect(agent, 101, trainTicks, 0.15), testOn = collect(agent, 202, testTicks, 0.0), testEx = collect(agent, 303, testTicks, 0.15);
        System.out.printf(Locale.ROOT, "collected train %d, held-out on-policy %d, held-out exploratory %d transitions in %.1fs%n", train.size(), testOn.size(), testEx.size(), (System.currentTimeMillis() - t0) / 1000.0);
        Model[] ms = System.getProperty("skip.old") != null ? new Model[]{
            new Res("norm f.02 clip1", true, 0.02f, 4e-4f, 1, 1f), new Res("norm f.02 clip5", true, 0.02f, 4e-4f, 1, 5f),
            new Res("norm f.10 clip1", true, 0.10f, 4e-4f, 1, 1f), new Res("norm f.10 clip5", true, 0.10f, 4e-4f, 1, 5f)}
          : new Model[]{new Old()};
        for (Model m : ms) {
            long t1 = System.currentTimeMillis();
            for (int i = 0; i < train.size(); i++) m.observe(train.obs.get(i), train.act.get(i), train.next.get(i));
            System.out.printf(Locale.ROOT, "%s trained in %.1fs%n", m.name(), (System.currentTimeMillis() - t1) / 1000.0);
            report(m, testOn, "held-out on-policy");
            report(m, testEx, "held-out exploratory");
        }
    }
}
