package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Fixed-seed, fixed-BotAI-profile checkpoint benchmark with 95% score confidence intervals. */
public final class StandingEval {
    private static final long[] SEEDS = {17, 41, 73, 109};
    private static final String[] STYLE_NAMES = {"COUNTER", "PRESSURE", "BAITER", "RUSHER", "WTAPPER", "CAMPER", "RESETTER", "SPACER", "SELECTOR", "TECHNICIAN", "HUMAN", "AIR_PUNISHER", "RUSH_PUNISHER"};
    private static final class Row {
        String checkpoint; double score, lower, upper, worstLower; int n; StringBuilder styles = new StringBuilder();
    }
    public static void main(String[] args) throws Exception {
        if (args.length < 1) throw new IllegalArgumentException("usage: StandingEval <episodes-per-style-per-seed> <checkpoint.bin> [checkpoint2.bin ...]");
        int perSeed = Integer.parseInt(args[0]);
        if (perSeed < 1) throw new IllegalArgumentException("episodes must be >= 1");
        List<Path> checkpoints = new ArrayList<>();
        for (int i = 1; i < args.length; i++) checkpoints.add(Path.of(args[i]));
        if (checkpoints.isEmpty()) throw new IllegalArgumentException("provide at least one checkpoint");
        List<Row> rows = new ArrayList<>();
        for (Path checkpoint : checkpoints) {
            Row row = new Row(); row.checkpoint = checkpoint.toString();
            double scoreSum = 0, scoreSquareSum = 0; int total = 0;
            double worst = 1.0;
            row.styles.append('[');
            for (int style = 0; style < STYLE_NAMES.length; style++) {
                double styleScore = 0, styleSq = 0; int styleN = 0;
                for (long seed : SEEDS) {
                    PpoAgent agent = PpoAgent.load(checkpoint, seed);
                    agent.setMask(0);
                    PvpSim sim = new PvpSim(seed * 17 + style, agent);
                    sim.mirrorOn = false;
                    PvpSim.EvalStats ev = sim.evaluateScriptStyle(style, perSeed);
                    int n = ev.wins + ev.losses + ev.draws;
                    // Episode score mean and its sample variance can be recovered from W/L/D.
                    styleScore += ev.wins + 0.5 * ev.draws;
                    styleSq += ev.wins + 0.25 * ev.draws;
                    styleN += n;
                }
                double mean = styleScore / Math.max(1, styleN);
                double variance = Math.max(0.0, (styleSq / Math.max(1, styleN)) - mean * mean);
                double half = 1.96 * Math.sqrt(variance / Math.max(1, styleN));
                double lo = Math.max(0.0, mean - half), hi = Math.min(1.0, mean + half);
                worst = Math.min(worst, lo);
                scoreSum += styleScore; scoreSquareSum += styleSq; total += styleN;
                if (style > 0) row.styles.append(';');
                row.styles.append(STYLE_NAMES[style]).append('=').append(String.format(Locale.ROOT, "%.3f[%.3f,%.3f]", mean, lo, hi));
                System.out.printf(Locale.ROOT, "%s | %-11s score %.3f (95%% CI %.3f..%.3f), n=%d%n", checkpoint, STYLE_NAMES[style], mean, lo, hi, styleN);
            }
            row.styles.append(']');
            row.score = scoreSum / Math.max(1, total); row.n = total; row.worstLower = worst;
            double v = Math.max(0.0, scoreSquareSum / Math.max(1, total) - row.score * row.score);
            double h = 1.96 * Math.sqrt(v / Math.max(1, total));
            row.lower = Math.max(0.0, row.score - h); row.upper = Math.min(1.0, row.score + h);
            rows.add(row);
            System.out.printf(Locale.ROOT, "TOTAL %s | score %.3f (95%% CI %.3f..%.3f) worst-style-lower %.3f n=%d%n", checkpoint, row.score, row.lower, row.upper, row.worstLower, total);
        }
        Row best = rows.stream().max((a, b) -> Double.compare(quality(a), quality(b))).orElseThrow();
        Path report = Path.of("standing-eval.csv");
        StringBuilder csv = new StringBuilder("checkpoint,score,ci95_low,ci95_high,worst_style_ci95_low,n,quality,style_results\n");
        for (Row r : rows) csv.append('"').append(r.checkpoint.replace("\"", "\"\"")).append("\",")
            .append(String.format(Locale.ROOT, "%.6f,%.6f,%.6f,%.6f,%d,%.6f,\"%s\"\n", r.score, r.lower, r.upper, r.worstLower, r.n, quality(r), r.styles));
        Files.writeString(report, csv.toString());
        Path bestPath = Path.of("best-checkpoint.bin");
        Files.copy(Path.of(best.checkpoint), bestPath, StandardCopyOption.REPLACE_EXISTING);
        Files.writeString(Path.of("best-checkpoint.txt"), "Selected by fixed-seed standing evaluation.\nCheckpoint: " + best.checkpoint
            + "\nMean score: " + best.score + "\n95% CI: " + best.lower + ".." + best.upper
            + "\nWorst style lower bound: " + best.worstLower + "\nSelection quality: " + quality(best) + "\n");
        System.out.printf(Locale.ROOT, "BEST %s | quality %.3f | copied to %s; report %s%n", best.checkpoint, quality(best), bestPath, report);
    }
    private static double quality(Row r) { return 0.70 * r.lower + 0.30 * r.worstLower; }
}
