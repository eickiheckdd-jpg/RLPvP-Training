package com.rlpvp;

import java.nio.file.Path;

/**
 * Test 13: the simulator's agent camera and the live controller agree. PvpSim and the mod's ActionApplier both call GameplayRotation;
 * this check REPLAYS the actions the simulator saw through a separate GameplayRotation instance (the code path ActionApplier uses)
 * and compares the turn (yaw), the camera velocity (yaw and pitch) tick by tick over full episodes. Hand-effort noise is switched
 * off for the comparison (the simulator adds it before the controller; the live mod adds none).
 * Usage: RotationConsistencyCheck <state.bin> [episodes]
 */
public final class RotationConsistencyCheck {
    public static void main(String[] a) throws Exception {
        PpoAgent agent = PpoAgent.load(Path.of(a[0]), 5);
        int episodes = a.length > 1 ? Integer.parseInt(a[1]) : 4;
        long ticks = 0; double worstTurn = 0, worstVelY = 0, worstVelP = 0;
        Curriculum.Opponent[] opps = {Curriculum.Opponent.STRAFE, Curriculum.Opponent.WALK, Curriculum.Opponent.AGGRESSIVE};
        for (Curriculum.Opponent opp : opps) {
            PvpSim sim = new PvpSim(11, agent);
            sim.evalDifficulty = 0.6;
            final GameplayRotation live = new GameplayRotation(), wrong = new GameplayRotation(); // `wrong` = negative control: brake switched off
            final boolean[] have = {false};
            final double[] exp = new double[3];
            sim.actionTap = (in, act) -> {
                if (have[0]) { // compare the previous tick: sim state now = after that tick
                    double dTurn = Math.abs(exp[0] - sim.lastYawTurn), dVy = Math.abs(exp[1] - sim.dynY.vel()), dVp = Math.abs(exp[2] - sim.dynP.vel());
                    synchronized (exp) { }
                    RotationConsistencyCheck.dT = Math.max(RotationConsistencyCheck.dT, dTurn); RotationConsistencyCheck.dVy = Math.max(RotationConsistencyCheck.dVy, dVy); RotationConsistencyCheck.dVp = Math.max(RotationConsistencyCheck.dVp, dVp);
                    RotationConsistencyCheck.n++;
                }
                sim.noiseYaw = 0f; sim.noisePitch = 0f;      // the sim adds hand noise before the controller; compare without it
                double cy = CameraMap.apply(act[0]) * Config.YAW_SCALE * sim.sens, cp = CameraMap.apply(act[1]) * Config.PITCH_SCALE * sim.sens;
                boolean pitchFree = !ActionMask.pitchLocked(sim.evalLock);
                live.stepEffort(cy, cp, 0f, sim.me.pitch, in[13] * 180.0, in[14] * 90.0, true, pitchFree, sim.aimBrake);
                wrong.stepEffort(cy, cp, 0f, sim.me.pitch, in[13] * 180.0, in[14] * 90.0, true, pitchFree, false);
                RotationConsistencyCheck.ctrl = Math.max(RotationConsistencyCheck.ctrl, Math.abs(wrong.yaw.vel() - live.yaw.vel()));
                RotationConsistencyCheck.maxV = Math.max(RotationConsistencyCheck.maxV, Math.abs(live.yaw.vel()));
                exp[0] = live.dYaw; exp[1] = live.yaw.vel(); exp[2] = live.pitch.vel();
                have[0] = true;
                return act;
            };
            agent.setMask(0);
            PvpSim.EvalStats ev = new PvpSim.EvalStats();
            for (int e = 0; e < episodes; e++) { have[0] = false; live.reset(); wrong.reset(); sim.startEpisodeFor(opp); while (sim.step(false, ev)) {} }
        }
        System.out.printf("compared %d ticks: worst |turn difference| %.3e deg, worst |yaw velocity diff| %.3e, worst |pitch velocity diff| %.3e%n", n, dT, dVy, dVp);
        System.out.printf("camera was moving (max |v| %.1f deg/tick); negative control (brake off) differs by up to %.1f deg/tick, so the comparison can detect divergence%n", maxV, ctrl);
        boolean ok = n > 500 && maxV > 3 && ctrl > 1 && dT < 1e-4 && dVy < 1e-4 && dVp < 1e-4;
        System.out.println(ok ? "RotationConsistencyCheck: OK" : "RotationConsistencyCheck: FAIL");
        if (!ok) System.exit(1);
    }
    static double ctrl, maxV;
    static long n; static double dT, dVy, dVp;
}
