package com.rlpvp;

import java.nio.file.Path;
import java.util.Locale;

/**
 * What does camera smoothing cost? Plays a state.bin with several smoothing coefficients (Config.LOOK_SMOOTH, 1.0 = off) and prints
 * how the fights go and how smooth the camera really is: "step jerk" = mean change of the APPLIED yaw delta between two ticks, in
 * degrees (lower = smoother camera), "turn" = mean degrees turned per tick.
 * Usage: CamSmoothEval <state.bin> [episodes]
 */
public final class CamSmoothEval {
    public static void main(String[] a) throws Exception {
        PpoAgent agent = PpoAgent.load(Path.of(a[0]), 5);
        int n = a.length > 1 ? Integer.parseInt(a[1]) : 80;
        agent.setMask(0);
        System.out.println("loaded: ticks " + agent.totalTicks + ", stage " + agent.stage);
        System.out.printf(Locale.ROOT, "%-28s %-7s %5s %5s | %5s %5s | %9s %8s %8s%n", "opponent", "smooth", "win%", "loss%", "dealt", "taken", "step jerk", "turn/tick", "flips/ep");
        Object[][] rows = {{Curriculum.Opponent.WALK, 1.0}, {Curriculum.Opponent.STRONG, 0.2}, {Curriculum.Opponent.AGGRESSIVE, 0.4}};
        for (Object[] r : rows) {
            for (double alpha : new double[] {1.0, 0.7}) {
                PvpSim sim = new PvpSim(77, agent);
                sim.evalDifficulty = (Double) r[1];
                sim.lookAlpha = alpha;
                PvpSim.EvalStats ev = sim.evaluate((Curriculum.Opponent) r[0], n);
                double e = Math.max(1, ev.eps);
                System.out.printf(Locale.ROOT, "%-28s %-7s %5.0f %5.0f | %5.1f %5.1f | %9.2f %8.2f %8.1f%n", r[0] + " d=" + r[1], alpha >= 0.999 ? "off" : String.format(Locale.ROOT, "%.2f", alpha),
                    100.0 * ev.wins / e, 100.0 * ev.losses / e, ev.dealt / e, ev.taken / e, ev.appJerk / Math.max(1, ev.nA), ev.look / Math.max(1, ev.n), ev.flip / e);
            }
        }
    }
}
