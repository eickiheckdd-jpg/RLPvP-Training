package com.rlpvp;

/** Pure-Java checks that the render view follows smoothed authoritative gameplay rotations without a second motion curve. */
public final class GlideCameraSmoothingCheck {
    private static int failures;

    private static void check(String name, boolean ok) {
        System.out.println((ok ? "ok   " : "FAIL ") + name);
        if (!ok) failures++;
    }

    public static void main(String[] args) {
        // If mouse-count quantization produces no authoritative movement, stale dynamics velocity must not animate a fake loop.
        GlideCamera.reset();
        GlideCamera.push(0.0, 8.0, 0.0, -7.0);
        boolean still = true;
        for (int i = 0; i <= 20; i++) {
            double t = i / 20.0;
            still &= Math.abs(GlideCamera.viewYaw(37.0, t) - 37.0) < 1.0e-9;
            still &= Math.abs(GlideCamera.viewPitch(12.0, t) - 12.0) < 1.0e-9;
        }
        check("zero applied rotation creates no hidden out-and-back wiggle", still);

        // Internal controller velocity must not create an independent rendered trajectory. The view follows the applied
        // gameplay displacement linearly, regardless of hidden/unquantized physical velocity.
        GlideCamera.reset();
        GlideCamera.push(12.0, 100.0, 6.0, 100.0);
        boolean monotone = true;
        double prevY = GlideCamera.viewYaw(12.0, 0.0);
        double prevP = GlideCamera.viewPitch(6.0, 0.0);
        for (int i = 1; i <= 100; i++) {
            double t = i / 100.0;
            double y = GlideCamera.viewYaw(12.0, t);
            double p = GlideCamera.viewPitch(6.0, t);
            monotone &= y >= prevY - 1.0e-8;
            monotone &= p >= prevP - 1.0e-8;
            prevY = y;
            prevP = p;
        }
        check("rendered view stays monotone on large turns", monotone);
        check("rendered view follows only applied gameplay displacement (no second motion curve)",
                Math.abs(GlideCamera.viewYaw(12.0, 0.25) - 3.0) < 1e-8
                && Math.abs(GlideCamera.viewYaw(12.0, 0.50) - 6.0) < 1e-8
                && Math.abs(GlideCamera.viewPitch(6.0, 0.50) - 3.0) < 1e-8);
        check("view reaches the exact authoritative endpoint", Math.abs(GlideCamera.viewYaw(12.0, 1.0) - 12.0) < 1e-8
                && Math.abs(GlideCamera.viewPitch(6.0, 1.0) - 6.0) < 1e-8);

        // After a sudden reversal, the visual curve should follow the new tick displacement without overshooting it.
        GlideCamera.push(-2.0, -100.0, -1.0, -100.0);
        double lastY = GlideCamera.viewYaw(10.0, 0.0);
        double lastP = GlideCamera.viewPitch(5.0, 0.0);
        boolean reversalMonotone = true;
        for (int i = 1; i <= 100; i++) {
            double t = i / 100.0;
            double y = GlideCamera.viewYaw(10.0, t);
            double p = GlideCamera.viewPitch(5.0, t);
            reversalMonotone &= y <= lastY + 1e-8;
            reversalMonotone &= p <= lastP + 1e-8;
            lastY = y;
            lastP = p;
        }
        check("direction reversal follows the new applied endpoint without overshoot", reversalMonotone
                && Math.abs(GlideCamera.viewYaw(10.0, 0.5) - 11.0) < 1e-8
                && Math.abs(GlideCamera.viewPitch(5.0, 0.5) - 5.5) < 1e-8);

        // Crossing +180 must remain a continuous absolute rotation in the rendered view (179 -> 183, not 179 -> -177).
        GlideCamera.reset();
        GlideCamera.push(4.0, 4.0, 0.0, 0.0);
        check("yaw boundary starts at the continuous prior angle", Math.abs(GlideCamera.viewYaw(183.0, 0.0) - 179.0) < 1e-8);
        check("yaw boundary ends at the continuous absolute endpoint", Math.abs(GlideCamera.viewYaw(183.0, 1.0) - 183.0) < 1e-8);

        System.out.println(failures == 0 ? "GlideCameraSmoothingCheck: ALL OK" : failures + " FAILED");
        if (failures > 0) System.exit(1);
    }
}
