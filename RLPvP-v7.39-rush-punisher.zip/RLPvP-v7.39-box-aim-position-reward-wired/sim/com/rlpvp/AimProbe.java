package com.rlpvp;

import java.nio.file.Path;
import java.util.Locale;

/**
 * Aim quality of a state.bin in the simulator (evaluation only). Uses what the agent sees: yaw error to the enemy (frame feature 13) and
 * its own camera velocity (feature 27). "snap" = camera faster than 20 deg/tick; "overshoot" = the error changes sign while moving fast;
 * "hunt" = camera velocity changes direction at speed (swinging back and forth). Usage: AimProbe <state.bin> [episodes] [brake: true|false|both]
 */
public final class AimProbe {
    static final int FRAMES_PER_TICK = 3; // frames drawn per 20 Hz tick at about 60 fps
    static final class M { double lastFrameSpeed; int haveFrame; final java.util.ArrayList<Double> hitch = new java.util.ArrayList<>(), frameJump = new java.util.ArrayList<>(); long ticks, onT, snap, fast, over, hunt, nearTicks; double absV, nearV, sumSignAgree; long agreeN; int eps, firstOn, firstOnN; double dealt, taken; int wins; }

    static M run(PpoAgent agent, Curriculum.Opponent opp, int episodes, boolean brake, double diff) {
        M m = new M();
        PvpSim sim = new PvpSim(77, agent);
        sim.evalDifficulty = diff; sim.aimBrake = brake;
        final float[] prev = new float[3]; // err, vel, valid
        final double[] lastTurn = new double[1];
        final int[] tickInEp = {0};
        final boolean[] got = {false};
        sim.actionTap = (in, act) -> {
            double err = in[13] * 180.0, vv = sim.yawVel(); // true camera velocity: the observation hides it (frame features 27/28 are zeroed)
            tickInEp[0]++;
            m.ticks++;
            if (Math.abs(err) <= Config.ON_TARGET_DEG) { m.onT++; if (!got[0]) { got[0] = true; m.firstOn += tickInEp[0]; m.firstOnN++; } }
            double av = Math.abs(vv);
            m.absV += av;
            if (av > 20) m.snap++;
            if (av > 8) m.fast++;
            if (Math.abs(err) < Config.ON_TARGET_DEG * 2) { m.nearTicks++; m.nearV += av; }
            if (Math.abs(err) > 8 && av > 1) { m.agreeN++; m.sumSignAgree += (vv * err > 0) ? 1 : 0; }
            if (prev[2] > 0) {
                if (prev[0] * err < 0 && Math.abs(prev[1]) > 5) m.over++;
                if (prev[1] * vv < 0 && Math.abs(prev[1]) > 3 && av > 3) m.hunt++;
            }
            if (prev[2] > 0) { // real-rotation frame model: speed change between consecutive FRAMES (FRAMES_PER_TICK per tick), tick boundaries included
                double last = m.lastFrameSpeed;
                for (int k = 0; k <= FRAMES_PER_TICK; k++) { double sp = sim.realYawSpeedAt((double) k / FRAMES_PER_TICK); if (!(k == 0 && m.haveFrame == 0)) m.frameJump.add(Math.abs(sp - last)); last = sp; m.haveFrame = 1; }
                m.lastFrameSpeed = last;
            }
            if (prev[2] > 0) { double d = sim.lastYawTurn; m.hitch.add(Math.abs(d - lastTurn[0])); lastTurn[0] = d; } else lastTurn[0] = sim.lastYawTurn;
            prev[0] = (float) err; prev[1] = (float) vv; prev[2] = 1;
            return act;
        };
        agent.setMask(0);
        PvpSim.EvalStats ev = new PvpSim.EvalStats();
        for (int e = 0; e < episodes; e++) {
            prev[2] = 0; tickInEp[0] = 0; got[0] = false;
            sim.startEpisodeFor(opp);
            while (sim.step(false, ev)) {}
        }
        m.eps = ev.eps; m.dealt = ev.dealt; m.taken = ev.taken; m.wins = ev.wins;
        return m;
    }

    static void printFrames(String name, String tag, M m) {
        double[] h = m.frameJump.stream().mapToDouble(Double::doubleValue).sorted().toArray();
        if (h.length == 0) return;
        System.out.printf(Locale.ROOT, "%-11s %-9s real-yaw speed change between frames (%s, deg/tick): median %5.2f  p95 %5.2f  p99 %5.2f  max %5.1f%n",
            name, tag, Config.GLIDE_REAL_ROTATION ? "glide curve" : "straight line", h[h.length / 2], h[(int) (h.length * 0.95)], h[(int) (h.length * 0.99)], h[h.length - 1]);
    }

    static void printVisual(String name, String tag, M m) {
        double[] h = m.hitch.stream().mapToDouble(Double::doubleValue).sorted().toArray();
        if (h.length == 0) return;
        long over3 = java.util.Arrays.stream(h).filter(x -> x > 3).count(), over8 = java.util.Arrays.stream(h).filter(x -> x > 8).count();
        System.out.printf(Locale.ROOT, "%-11s %-9s speed change at tick boundaries (deg/tick): median %5.2f  p95 %5.2f  p99 %5.2f  max %5.1f | ticks >3: %4.1f%%  >8: %4.1f%%%n",
            name, tag, h[h.length / 2], h[(int) (h.length * 0.95)], h[(int) (h.length * 0.99)], h[h.length - 1], 100.0 * over3 / h.length, 100.0 * over8 / h.length);
    }

    static void print(String name, String tag, M m) {
        double t = Math.max(1, m.ticks), e = Math.max(1, m.eps);
        System.out.printf(Locale.ROOT, "%-11s %-6s on-target %4.1f%% | mean|v| %5.2f deg/tick, near-target %5.2f | snap(>20) %4.1f%% fast(>8) %4.1f%% | overshoot %4.1f/ep hunt %5.1f/ep | acquire %5.1f ticks | win %3.0f%% dealt %4.1f taken %4.1f%n",
            name, tag, 100 * m.onT / t, m.absV / t, m.nearV / Math.max(1, m.nearTicks), 100 * m.snap / t, 100 * m.fast / t, m.over / e, m.hunt / e,
            m.firstOnN == 0 ? Double.NaN : (double) m.firstOn / m.firstOnN, 100.0 * m.wins / e, m.dealt / e, m.taken / e);
    }

    public static void main(String[] a) throws Exception {
        PpoAgent agent = PpoAgent.load(Path.of(a[0]), 5);
        int n = a.length > 1 ? Integer.parseInt(a[1]) : 30;
        String mode = a.length > 2 ? a[2] : "both";
        if (mode.equals("sweep")) {
            Object[][] opps = {{Curriculum.Opponent.STRAFE, 1.0}, {Curriculum.Opponent.WALK, 1.0}, {Curriculum.Opponent.AGGRESSIVE, 0.4}};
            for (double dec : new double[]{1.5, 3.0, 6.0}) for (double trk : new double[]{0.25, 0.5, 1.0, 2.0}) {
                CameraDynamics.stopGain = dec; AimBrake.slackDeg = trk;
                double on = 0, v = 0, snap = 0, over = 0, hunt = 0, win = 0, dealt = 0, taken = 0;
                for (Object[] r : opps) { M m = run(agent, (Curriculum.Opponent) r[0], n, true, (Double) r[1]); double t = m.ticks, e = m.eps;
                    on += 100 * m.onT / t / 3; v += m.absV / t / 3; snap += 100 * m.snap / t / 3; over += m.over / e / 3; hunt += m.hunt / e / 3; win += 100.0 * m.wins / e / 3; dealt += m.dealt / e / 3; taken += m.taken / e / 3; }
                System.out.printf(Locale.ROOT, "stopGain %.2f slack %.2f deg | on-target %4.1f%% mean|v| %5.2f snap %4.1f%% overshoot %4.1f/ep hunt %4.1f/ep | win %3.0f%% dealt %4.1f taken %4.1f%n", dec, trk, on, v, snap, over, hunt, win, dealt, taken);
            }
            return;
        }
        System.out.println("loaded: ticks " + agent.totalTicks + ", stage " + agent.stage);
        Object[][] rows = {{Curriculum.Opponent.STATIONARY, 1.0}, {Curriculum.Opponent.STRAFE, 1.0}, {Curriculum.Opponent.WALK, 1.0}, {Curriculum.Opponent.AGGRESSIVE, 0.4}};
        for (Object[] r : rows) {
            if (!mode.equals("true")) { M mo = run(agent, (Curriculum.Opponent) r[0], n, false, (Double) r[1]); print(r[0] + (((Double) r[1]) < 1 ? " d" + r[1] : ""), "brake-off", mo); if (mode.equals("visual")) { printVisual(r[0] + "", "brake-off", mo); printFrames(r[0] + "", "brake-off", mo); } }
            if (!mode.equals("false")) { M mn = run(agent, (Curriculum.Opponent) r[0], n, true, (Double) r[1]); print(r[0] + (((Double) r[1]) < 1 ? " d" + r[1] : ""), "brake-on", mn); if (mode.equals("visual")) { printVisual(r[0] + "", "brake-on", mn); printFrames(r[0] + "", "brake-on", mn); } }
        }
    }
}
