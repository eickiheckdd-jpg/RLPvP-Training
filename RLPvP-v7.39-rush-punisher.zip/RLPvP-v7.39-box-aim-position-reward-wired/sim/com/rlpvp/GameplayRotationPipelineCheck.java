package com.rlpvp;

/** Verifies that authoritative gameplay yaw is itself rate-shaped and target braking prevents a large aim overshoot. */
public final class GameplayRotationPipelineCheck {
    private static void check(String name, boolean ok) {
        System.out.println((ok ? "ok   " : "FAIL ") + name);
        if (!ok) throw new AssertionError(name);
    }

    public static void main(String[] args) {
        GameplayRotation rot = new GameplayRotation();
        float yaw = 0.0f, pitch = 0.0f;
        final double target = 60.0;
        double peakOvershoot = 0.0, largestTickTurn = 0.0;
        float firstTurn = 0.0f;
        for (int tick = 0; tick < 160; tick++) {
            double err = target - yaw;
            double command = Math.max(-Config.YAW_SCALE, Math.min(Config.YAW_SCALE, err * 2.0));
            rot.stepEffort(command, 0.0, yaw, pitch, err, 0.0, true, false, true);
            if (tick == 0) firstTurn = Math.abs(rot.dYaw);
            largestTickTurn = Math.max(largestTickTurn, Math.abs(rot.dYaw));
            yaw = rot.newYaw; pitch = rot.newPitch;
            peakOvershoot = Math.max(peakOvershoot, yaw - target);
            if (tick > 80 && Math.abs(target - yaw) < 0.7 && Math.abs(rot.yaw.vel()) < 0.8) break;
        }
        check("actual gameplay turn starts rate-limited (first tick " + String.format("%.2f", firstTurn) + " deg)", firstTurn < 3.0);
        check("actual gameplay yaw uses bounded per-tick displacement (max " + String.format("%.2f", largestTickTurn) + " deg)", largestTickTurn < 20.0);
        check("closed-loop gameplay aim avoids large target overshoot (" + String.format("%.2f", peakOvershoot) + " deg)", peakOvershoot <= 3.0);

        // Absolute yaw must remain continuous when a legitimate small movement crosses +180 degrees.
        GameplayRotation boundary = new GameplayRotation();
        float boundaryYaw = 179.0f;
        for (int tick = 0; tick < 80; tick++) {
            double error = GameplayRotation.shortestYawDelta(boundaryYaw, 181.0f);
            double command = Math.max(-Config.YAW_SCALE, Math.min(Config.YAW_SCALE, error * 2.0));
            boundary.stepEffort(command, 0.0, boundaryYaw, 0.0f, error, 0.0, true, false, true);
            boundaryYaw = boundary.newYaw;
        }
        check("small target turn through +180 preserves continuous absolute yaw (" + String.format("%.2f", boundaryYaw) + " deg)",
                boundaryYaw > 180.0f && Math.abs(GameplayRotation.shortestYawDelta(boundaryYaw, 181.0f)) < 2.0);
        System.out.println("GameplayRotationPipelineCheck: all ok");
    }
}
