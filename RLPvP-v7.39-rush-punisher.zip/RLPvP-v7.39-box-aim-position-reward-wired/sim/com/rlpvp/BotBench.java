package com.rlpvp;

import java.util.Locale;

/**
 * Opponent benchmark (no learning). An IDEALIZED agent fights each bot: perfect aim (no lag, up to 30 deg/tick), full-charge swings only when
 * its ray is on target, spacing control, and one fixed movement habit. If a habit can beat a bot, an RL agent will find it too.
 *  orbit-D / orbit-A : W-spacing + constant sprint strafe in one direction (the W+D orbit)
 *  orbit-flip        : same, but flips direction every 25 ticks
 *  trader            : stands still, swings when ready and on target (checks the bot is not an unfair wall)
 * Usage: BotBench [episodes]
 */
public final class BotBench {
    static double[] fight(boolean legacy, Curriculum.Opponent m, double diff, int habit, int eps, long seed) {
        PvpSim s = new PvpSim(seed, new PpoAgent(1));
        s.legacyBots = legacy; s.evalDifficulty = diff; s.mode = m;
        int wins = 0, losses = 0, draws = 0; double taken = 0, dealt = 0;
        for (int ep = 0; ep < eps; ep++) {
            PvpSim.E me = s.me, bot = s.bot;
            for (PvpSim.E e : new PvpSim.E[]{me, bot}) { e.vx = e.vy = e.vz = 0; e.y = 0; e.hp = 20f; e.ground = true; e.sprint = false; e.swinging = false; e.ticker = 100; e.hurtTime = e.invul = 0; e.fall = 0; e.fwd = e.str = 0; e.jump = e.sprintKey = false; }
            s.assignKits();
            double ang = s.rng.nextDouble() * 6.283;
            me.x = me.z = 0; bot.x = Math.cos(ang) * 3.5; bot.z = Math.sin(ang) * 3.5; me.yaw = (float) (s.rng.nextDouble() * 360 - 180); me.pitch = 0;
            bot.yaw = (float) (s.rng.nextDouble() * 360 - 180); bot.pitch = 0; me.snapPrev(); bot.snapPrev();
            s.bFwd = 0; s.bStr = 1; s.ticksLeft = 0; s.attackCd = 20; s.wtap = 0; s.critArm = false; s.aimHistN = 0; s.ai.reset();
            int dir = habit == 1 ? -1 : 1;
            for (int t = 0; t < s.episodeTicks && me.hp > 0 && bot.hp > 0; t++) {
                double dx = bot.x - me.x, dz = bot.z - me.z, horiz = Math.hypot(dx, dz);
                double wy = Math.toDegrees(Math.atan2(-dx, dz));
                me.yaw += (float) Math.max(-30, Math.min(30, PvpSim.wrap(wy - me.yaw)));
                double wp = -Math.toDegrees(Math.atan2((bot.y + 0.9) - me.eyeY(), Math.max(horiz, 1e-6)));
                me.pitch += (float) Math.max(-15, Math.min(15, wp - me.pitch));
                if (habit == 3) { me.fwd = 0; me.str = 0; me.sprintKey = false; }
                else {
                    if (habit == 2 && t % 25 == 0) dir = -dir;
                    me.str = dir; me.fwd = horiz > 2.7 ? 1 : (horiz < 1.9 ? -1 : 0); me.sprintKey = true;
                }
                if (me.scale() >= 0.9 && PvpSim.crosshairOn(me, bot)) { s.swingAnim(me); s.hit(me, bot); }
                s.botThink();
                s.move(me); s.move(bot); s.separate(); s.timers(me); s.timers(bot);
            }
            if (bot.hp <= 0 && me.hp > 0) wins++;
            else if (me.hp <= 0 && bot.hp > 0) losses++;
            else draws++;
            taken += 20 - Math.max(0, me.hp); dealt += 20 - Math.max(0, bot.hp);
        }
        return new double[]{100.0 * wins / eps, 100.0 * losses / eps, 100.0 * draws / eps, taken / eps, dealt / eps};
    }

    static void row(String label, boolean legacy, Curriculum.Opponent m, double diff, int eps) {
        StringBuilder sb = new StringBuilder(String.format(Locale.ROOT, "%-24s", label));
        String[] names = {"orbit-D", "orbit-A", "flip", "trader"};
        int[] habits = {0, 1, 2, 3};
        for (int i = 0; i < 4; i++) {
            double[] r = fight(legacy, m, diff, habits[i], eps, 7 + i);
            sb.append(String.format(Locale.ROOT, " | %s win %3.0f%% lose %3.0f%% draw %3.0f%% taken %4.1f", names[i], r[0], r[1], r[2], r[3]));
        }
        System.out.println(sb);
    }

    public static void main(String[] a) {
        int eps = a.length > 0 ? Integer.parseInt(a[0]) : 100;
        System.out.println("idealized agent (perfect aim, no lag) vs each bot; win/lose = the AGENT's results, taken = agent HP lost per episode");
        row("OLD aggressive", true, Curriculum.Opponent.AGGRESSIVE, 1.0, eps);
        row("OLD strong", true, Curriculum.Opponent.STRONG, 1.0, eps);
        for (double d : new double[]{0.3, 0.6, 1.0}) row(String.format(Locale.ROOT, "NEW aggressive d=%.1f", d), false, Curriculum.Opponent.AGGRESSIVE, d, eps);
        for (double d : new double[]{0.3, 0.6, 1.0}) row(String.format(Locale.ROOT, "NEW strong d=%.1f", d), false, Curriculum.Opponent.STRONG, d, eps);
    }
}
