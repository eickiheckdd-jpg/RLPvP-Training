package com.rlpvp;

import java.nio.file.Path;
import java.util.Locale;

/**
 * Greedy (what /rl play does) evaluation of a state.bin in the simulator, with network lag.
 * Usage: PvpEval <state.bin> [episodes] [rival state.bin]
 */
public final class PvpEval {
    static void line(String name, PvpSim.EvalStats ev) {
        double n = Math.max(1, ev.eps), h = Math.max(1, ev.hits), t = Math.max(1, ev.ticks);
        System.out.printf(Locale.ROOT, "%-22s win %3.0f%% loss %3.0f%% draw %3.0f%% no-contest %3.0f%% | dealt %4.1f taken %4.1f | hits/ep %.1f: crit %2.0f%% sprint %2.0f%% full-charge %2.0f%% reset-gap %2.0f%% punish %2.0f%% | whiff %2.0f%% | sprint follow-up %2.0f%% (%d/%d, expired %d, avg %.1f ticks) | strafe %2.0f%% (D %2.0f%% / A %2.0f%%) back %2.0f%% sprint %2.0f%% jump %2.0f%% | dist %.1f | jerk %.2f%n",
            name, 100.0 * ev.wins / n, 100.0 * ev.losses / n, 100.0 * ev.draws / n, 100.0 * ev.noContest / n, ev.dealt / n, ev.taken / n, ev.hits / n, 100.0 * ev.crits / h, 100.0 * ev.sprintHits / h,
            100.0 * ev.fullHits / h, 100.0 * ev.resetHits / h, 100.0 * ev.punishHits / h, 100.0 * ev.whiffs / Math.max(1, ev.swings),
            100.0 * ev.sprintFollowups / Math.max(1, ev.sprintFollowupOpps), ev.sprintFollowups, ev.sprintFollowupOpps, ev.sprintFollowupExpired,
            ev.sprintFollowups == 0 ? 0.0 : ev.sprintFollowupTicks / (double) ev.sprintFollowups,
            100.0 * ev.strafeT / t, 100.0 * ev.strafeR / Math.max(1, ev.strafeR + ev.strafeL), 100.0 * ev.strafeL / Math.max(1, ev.strafeR + ev.strafeL), 100.0 * ev.backT / t, 100.0 * ev.sprintT / t, 100.0 * ev.jumpT / t, ev.distSum / t, ev.jerk / Math.max(1, ev.nJ));
        if (ev.whiffs > 0) System.out.printf(Locale.ROOT, "      whiffs by cause: out of reach %.0f%%, off-aim (>6.3 deg yaw / 5.4 pitch) %.0f%%, near-miss (aimed, still missed) %.0f%% | swings/ep %.1f%n", 100.0 * ev.whiffFar / ev.whiffs, 100.0 * ev.whiffOff / ev.whiffs, 100.0 * ev.whiffNear / ev.whiffs, ev.swings / n);
        if (ev.nD > 0) System.out.printf(Locale.ROOT, "      camera dynamics (yaw): mean |vel| %.2f deg/tick, mean |acc| %.2f (peak %.1f, limit %.1f), mean |jerk| %.2f (peak %.1f, limit %.1f)%n",
            ev.velAbs / ev.nD, ev.accAbs / ev.nD, ev.accPeak, Config.CAM_ACC_MAX_FRAC * Config.YAW_SCALE, ev.jerkAbs / ev.nD, ev.jerkPeak, Config.CAM_JERK_MAX_FRAC * Config.YAW_SCALE);
    }

    public static void main(String[] a) throws Exception {
        PpoAgent agent = PpoAgent.load(Path.of(a[0]), 5);
        int n = a.length > 1 ? Integer.parseInt(a[1]) : 200;
        System.out.println("loaded: ticks " + agent.totalTicks + ", stage " + agent.stage + ", inputs " + Config.OBS_SIZE);
        System.out.println("policy: " + (Boolean.getBoolean("sim.strictGreedy") ? "STRICT GREEDY (argmax per head)" : "PLAY MODE (camera mean, discrete heads sampled at T=" + Config.PLAY_TEMPERATURE + ")"));
        PvpSim sim = new PvpSim(99, agent);
        sim.evalDifficulty = Double.parseDouble(System.getProperty("botdiff", "1.0")); // full-strength opponents unless -Dbotdiff=...
        sim.legacyBots = Boolean.getBoolean("legacybots");
        agent.setMask(0);
        Curriculum.Opponent[] opps = {Curriculum.Opponent.STATIONARY, Curriculum.Opponent.STRAFE, Curriculum.Opponent.WALK, Curriculum.Opponent.AGGRESSIVE, Curriculum.Opponent.STRONG};
        System.out.println("-- random network lag per episode (0..~6 ticks one way, jitter, stalls) --");
        for (Curriculum.Opponent o : opps) line(o.toString(), sim.evaluate(o, n));
        for (double lag : new double[]{0, 2, 4}) {
            sim.fixedLag = lag;
            line("STRONG, lag " + (int) lag + " ticks", sim.evaluate(Curriculum.Opponent.STRONG, n));
        }
        sim.fixedLag = null;
        System.out.println("-- bot strength sweep (BotAI difficulty; training adapts it to the agent) --");
        for (double d : new double[]{0.2, 0.4, 0.6, 0.8}) {
            sim.evalDifficulty = d;
            line("AGGRESSIVE d=" + d, sim.evaluate(Curriculum.Opponent.AGGRESSIVE, n));
            line("STRONG     d=" + d, sim.evaluate(Curriculum.Opponent.STRONG, n));
        }
        if (a.length > 2) {
            FrozenPolicy rival = new FrozenPolicy(PpoAgent.load(Path.of(a[2]), 6));
            line("RIVAL lineage", sim.evaluatePolicy(rival, n));
        }
    }
}
