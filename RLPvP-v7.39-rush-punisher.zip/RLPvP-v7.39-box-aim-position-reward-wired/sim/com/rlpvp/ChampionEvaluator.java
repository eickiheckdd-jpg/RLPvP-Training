package com.rlpvp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Non-gating, asynchronous held-out benchmark for Stage 9. It evaluates an immutable checkpoint against every
 * fixed scripted style with repeatable seeds. Training never waits for an evaluation result; a separate champion
 * file is replaced only when the fixed-suite score improves.
 */
final class ChampionEvaluator implements AutoCloseable {
    private static final long DEFAULT_INTERVAL_TICKS = 250_000L;
    private static final int DEFAULT_EPISODES_PER_STYLE = 5;

    private static final class StyleResult {
        final int style;
        final double score;
        final int valid, wins, losses, draws, noContest, hits, crits, sprintHits, swings, whiffs;
        final double dealt, taken;

        StyleResult(int style, PvpSim.EvalStats s) {
            this.style = style;
            valid = Math.max(0, s.eps - s.noContest);
            wins = s.wins; losses = s.losses; draws = s.draws; noContest = s.noContest;
            hits = s.hits; crits = s.crits; sprintHits = s.sprintHits; swings = s.swings; whiffs = s.whiffs;
            dealt = s.dealt; taken = s.taken;
            if (valid == 0) score = Double.NaN;
            else {
                double resultScore = (wins + 0.5 * draws) / valid;
                double damageBalance = clamp((dealt - taken) / (20.0 * valid), -1.0, 1.0);
                score = 0.80 * resultScore + 0.20 * (0.5 + 0.5 * damageBalance);
            }
        }
    }

    private static final class Result {
        final long ticks;
        final double score, mean, worst;
        final int valid, wins, losses, draws, noContest;
        final double dealt, taken;
        final List<StyleResult> styles;
        Result(long ticks, List<StyleResult> styles) {
            this.ticks = ticks;
            this.styles = styles;
            double sum = 0.0, min = Double.POSITIVE_INFINITY;
            int n = 0, v = 0, w = 0, l = 0, d = 0, nc = 0;
            double dh = 0.0, th = 0.0;
            for (StyleResult s : styles) {
                v += s.valid; w += s.wins; l += s.losses; d += s.draws; nc += s.noContest;
                dh += s.dealt; th += s.taken;
                if (Double.isFinite(s.score)) { sum += s.score; min = Math.min(min, s.score); n++; }
            }
            mean = n == 0 ? 0.0 : sum / n;
            worst = n == 0 ? 0.0 : min;
            score = n == 0 ? Double.NEGATIVE_INFINITY : 0.75 * mean + 0.25 * worst;
            valid = v; wins = w; losses = l; draws = d; noContest = nc; dealt = dh; taken = th;
        }
    }

    private final Path output;
    private final Path championPath;
    private final Path reportPath;
    private final Path bestPath;
    private final long intervalTicks;
    private final int episodesPerStyle;
    private final ExecutorService executor;
    private Future<Result> pending;
    private Path pendingCheckpoint;
    private long pendingTick;
    private long lastLaunchTick = Long.MIN_VALUE;
    private double bestScore = Double.NEGATIVE_INFINITY;
    private long bestTick = -1;

    ChampionEvaluator(Path output) {
        this.output = output.toAbsolutePath();
        String file = this.output.getFileName().toString();
        String stem = file.endsWith(".bin") ? file.substring(0, file.length() - 4) : file;
        Path parent = this.output.getParent() == null ? Path.of(".").toAbsolutePath() : this.output.getParent();
        championPath = parent.resolve(stem + ".champion.bin");
        reportPath = parent.resolve(stem + ".champion-evaluations.csv");
        bestPath = parent.resolve(stem + ".champion-best.txt");
        intervalTicks = Math.max(1L, Long.getLong("sim.championEvalEvery", DEFAULT_INTERVAL_TICKS));
        episodesPerStyle = Math.max(1, Math.min(10, Integer.getInteger("sim.championEpisodes", DEFAULT_EPISODES_PER_STYLE)));
        loadBest();
        executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "rlpvp-champion-evaluator");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY); // held-out work should yield CPU to learner workers
            return t;
        });
    }

    /** Called between PPO rounds. Stage 9 starts with an immediate benchmark, then repeats at fixed tick intervals. */
    synchronized void maybeLaunch(PpoAgent learner, int stage) {
        poll();
        if (stage < 9 || pending != null) return;
        if (lastLaunchTick != Long.MIN_VALUE && learner.totalTicks - lastLaunchTick < intervalTicks) return;
        long ticks = learner.totalTicks;
        Path parent = output.getParent() == null ? Path.of(".").toAbsolutePath() : output.getParent();
        Path candidate = parent.resolve(output.getFileName() + ".candidate-" + ticks + ".bin");
        try {
            learner.save(candidate); // immutable, exact checkpoint; the evaluator never reads the live learner
            pendingCheckpoint = candidate;
            pendingTick = ticks;
            lastLaunchTick = ticks;
            pending = executor.submit(() -> evaluate(candidate, ticks, episodesPerStyle));
            System.out.printf(Locale.ROOT, "  champion benchmark queued at tick %d (%d styles x %d episodes); training continues%n",
                ticks, BotAI.STYLES, episodesPerStyle);
        } catch (Exception ex) {
            // Avoid retrying a failed snapshot on every PPO round; retry at the next interval.
            lastLaunchTick = ticks;
            try { Files.deleteIfExists(candidate); } catch (IOException ignored) { }
            System.err.println("  champion benchmark could not snapshot tick " + ticks + "; training continues: " + ex);
        }
    }

    synchronized String status() {
        if (pending != null) return "champion eval tick " + pendingTick + (pending.isDone() ? " ready" : " running");
        return bestTick >= 0 ? String.format(Locale.ROOT, "champion %.4f @ %d", bestScore, bestTick) : "champion not evaluated yet";
    }

    synchronized void poll() {
        if (pending == null || !pending.isDone()) return;
        Result result;
        try { result = pending.get(); }
        catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            cleanupPending();
            return;
        } catch (ExecutionException ex) {
            System.err.println("  champion benchmark failed at tick " + pendingTick + ": " + ex.getCause());
            cleanupPending();
            return;
        }
        boolean improved = Double.isFinite(result.score) && result.score > bestScore + 1e-6;
        try {
            appendReport(result);
            if (improved) {
                atomicCopy(pendingCheckpoint, championPath);
                bestScore = result.score;
                bestTick = result.ticks;
                try { writeBest(); }
                catch (IOException ex) { System.err.println("  champion metadata could not be saved: " + ex); }
            }
        } catch (IOException ex) {
            System.err.println("  champion benchmark result could not be persisted at tick " + result.ticks + "; training continues: " + ex);
            improved = false;
        }
        System.out.printf(Locale.ROOT,
            "  champion benchmark tick %d: score %.4f (mean %.4f / worst-style %.4f), W/L/D %d/%d/%d, D/T %.1f/%.1f, %s%s%n",
            result.ticks, result.score, result.mean, result.worst, result.wins, result.losses, result.draws,
            result.dealt / Math.max(1, result.valid), result.taken / Math.max(1, result.valid),
            improved ? "NEW CHAMPION " + championPath : "not better than current champion",
            " | " + detail(result.styles));
        cleanupPending();
    }

    private Result evaluate(Path checkpoint, long ticks, int perStyle) throws Exception {
        long baseSeed = Long.getLong("sim.championSeed", 20261101L);
        PpoAgent policy = PpoAgent.load(checkpoint, baseSeed);
        OpponentLeague emptyLeague = new OpponentLeague();
        PvpSim sim = new PvpSim(baseSeed, policy, emptyLeague, false);
        sim.cur.force(9);
        sim.syncCurriculum();
        sim.mirrorOn = false; // fixed, reproducible held-out suite; mirrored variation belongs in training
        sim.evalDifficulty = 1.0;
        List<StyleResult> rows = new ArrayList<>();
        for (int style = 0; style < BotAI.STYLES; style++) {
            // Reuse identical per-style seeds for every checkpoint. Reset both simulator/bot randomness
            // and the policy's play-only sampler so changes in one style cannot perturb later styles.
            long styleSeed = baseSeed ^ (0x9e3779b97f4a7c15L * (style + 1L));
            sim.rng.setSeed(styleSeed);
            policy.resetPlayRandom(styleSeed ^ 0x5eed5eedL);
            PvpSim.EvalStats stats = sim.evaluateScriptStyle(style, perStyle);
            rows.add(new StyleResult(style, stats));
        }
        return new Result(ticks, rows);
    }

    private static String detail(List<StyleResult> styles) {
        StringBuilder b = new StringBuilder();
        for (StyleResult s : styles) {
            if (b.length() > 0) b.append(';');
            b.append(BotAI.styleName(s.style)).append('=');
            if (!Double.isFinite(s.score)) b.append("n/a");
            else b.append(String.format(Locale.ROOT, "%.2f", s.score));
            b.append("[W/L/D ").append(s.wins).append('/').append(s.losses).append('/').append(s.draws)
                .append(", hit ").append(s.hits).append(", crit ").append(s.crits)
                .append(", sprint ").append(s.sprintHits).append(", whiff ").append(s.whiffs).append('/').append(s.swings).append(']');
        }
        return b.toString();
    }

    private void appendReport(Result r) throws IOException {
        Path parent = reportPath.getParent();
        if (parent != null) Files.createDirectories(parent);
        boolean fresh = !Files.exists(reportPath);
        StringBuilder line = new StringBuilder();
        if (fresh) line.append("tick,score,mean_style_score,worst_style_score,valid_episodes,wins,losses,draws,no_contests,dealt,taken,champion\n");
        line.append(r.ticks).append(',').append(String.format(Locale.ROOT, "%.6f,%.6f,%.6f", r.score, r.mean, r.worst))
            .append(',').append(r.valid).append(',').append(r.wins).append(',').append(r.losses).append(',').append(r.draws)
            .append(',').append(r.noContest).append(',').append(String.format(Locale.ROOT, "%.3f,%.3f", r.dealt, r.taken))
            .append(',').append(r.score > bestScore + 1e-6 ? "candidate" : "not-best").append('\n');
        Files.writeString(reportPath, line.toString(), java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
    }

    private void loadBest() {
        if (!Files.isRegularFile(bestPath) || !Files.isRegularFile(championPath)) return;
        try {
            String[] p = Files.readString(bestPath).trim().split(",");
            if (p.length >= 2) { bestScore = Double.parseDouble(p[0]); bestTick = Long.parseLong(p[1]); }
        } catch (Exception ignored) { bestScore = Double.NEGATIVE_INFINITY; bestTick = -1; }
    }

    private void writeBest() throws IOException {
        Path tmp = Files.createTempFile(bestPath.getParent(), bestPath.getFileName().toString() + ".", ".tmp");
        try {
            Files.writeString(tmp, String.format(Locale.ROOT, "%.8f,%d%n", bestScore, bestTick));
            moveReplace(tmp, bestPath);
        } finally { Files.deleteIfExists(tmp); }
    }

    private static void atomicCopy(Path source, Path target) throws IOException {
        Path parent = target.getParent();
        if (parent != null) Files.createDirectories(parent);
        Path tmp = Files.createTempFile(parent, target.getFileName().toString() + ".", ".tmp");
        try {
            Files.copy(source, tmp, StandardCopyOption.REPLACE_EXISTING);
            moveReplace(tmp, target);
        } finally { Files.deleteIfExists(tmp); }
    }

    private static void moveReplace(Path from, Path to) throws IOException {
        try { Files.move(from, to, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
        catch (java.nio.file.AtomicMoveNotSupportedException ex) { Files.move(from, to, StandardCopyOption.REPLACE_EXISTING); }
    }

    private void cleanupPending() {
        try { if (pendingCheckpoint != null) Files.deleteIfExists(pendingCheckpoint); }
        catch (IOException ex) { System.err.println("could not remove temporary champion candidate: " + ex); }
        pendingCheckpoint = null;
        pending = null;
    }

    @Override public synchronized void close() {
        if (pending != null) {
            try { pending.get(); }
            catch (InterruptedException ex) { Thread.currentThread().interrupt(); }
            catch (ExecutionException ex) { System.err.println("champion benchmark failed during shutdown: " + ex.getCause()); }
            poll();
        }
        executor.shutdown();
    }

    private static double clamp(double x, double lo, double hi) { return Math.max(lo, Math.min(hi, x)); }
}
