package com.rlpvp;

import java.nio.file.Path;
import java.util.Locale;

/** Evaluation only: what happens in the 25 ticks AFTER each of my hits, by hit type (crit / sprint / plain), split by whether the enemy's sword was charged. Usage: HitTypeProbe state.bin episodes difficulty */
public final class HitTypeProbe {
    static final int WIN = 25;
    static final String[] T = {"crit", "sprint", "plain"};
    static double[][] n = new double[3][2], dealtAfter = new double[3][2], takenAfter = new double[3][2], hitsAfter = new double[3][2], first = new double[3][2], dist = new double[3][2];

    public static void main(String[] a) throws Exception {
        PpoAgent agent = PpoAgent.load(Path.of(a[0]), 5);
        int eps = Integer.parseInt(a[1]);
        PvpSim sim = new PvpSim(77, agent);
        sim.evalDifficulty = Double.parseDouble(a[2]);
        agent.setMask(0);
        for (Curriculum.Opponent o : new Curriculum.Opponent[]{Curriculum.Opponent.AGGRESSIVE, Curriculum.Opponent.STRONG}) {
            for (double[][] m : new double[][][]{n, dealtAfter, takenAfter, hitsAfter, first, dist}) for (double[] r : m) java.util.Arrays.fill(r, 0);
            PvpSim.EvalStats ev = new PvpSim.EvalStats();
            for (int e = 0; e < eps; e++) {
                sim.mode = o; sim.policy = null; sim.startEpisodeFor(o);
                int[] openType = new int[16]; int[] openCharged = new int[16]; int[] left = new int[16]; double[] dA = new double[16], tA = new double[16]; int[] hA = new int[16]; double[] dd = new double[16];
                int open = 0;
                float pMe = sim.me.hp, pBot = sim.bot.hp;
                boolean go = true;
                while (go) {
                    boolean botCharged = sim.bot.scale() >= 0.9;
                    double d0 = Math.hypot(sim.me.x - sim.bot.x, sim.me.z - sim.bot.z);
                    go = sim.step(false, ev);
                    float dBot = pBot - sim.bot.hp, dMe = pMe - sim.me.hp;
                    for (int i = 0; i < open; i++) { dA[i] += Math.max(0, dBot); tA[i] += Math.max(0, dMe); if (dBot > 0) hA[i]++; }
                    if (dBot > 0.01f) {
                        int t = sim.lastHitCrit ? 0 : sim.lastHitSprint ? 1 : 2;
                        if (open < 16) { openType[open] = t; openCharged[open] = botCharged ? 1 : 0; left[open] = WIN; dA[open] = 0; tA[open] = 0; hA[open] = 0; dd[open] = d0; open++; }
                    }
                    for (int i = 0; i < open; i++) left[i]--;
                    for (int i = 0; i < open; ) if (left[i] <= 0) {
                        int t = openType[i], c = openCharged[i];
                        n[t][c]++; dealtAfter[t][c] += dA[i]; takenAfter[t][c] += tA[i]; hitsAfter[t][c] += hA[i]; dist[t][c] += dd[i];
                        for (int j = i; j < open - 1; j++) { openType[j] = openType[j + 1]; openCharged[j] = openCharged[j + 1]; left[j] = left[j + 1]; dA[j] = dA[j + 1]; tA[j] = tA[j + 1]; hA[j] = hA[j + 1]; dd[j] = dd[j + 1]; }
                        open--;
                    } else i++;
                    pMe = sim.me.hp; pBot = sim.bot.hp;
                }
            }
            System.out.println("== " + o + " difficulty " + a[2] + ", " + eps + " episodes: next-" + WIN + "-tick outcome after each of my hits ==");
            for (int c = 1; c >= 0; c--) for (int t = 0; t < 3; t++) {
                double k = Math.max(1, n[t][c]);
                System.out.printf(Locale.ROOT, "  enemy sword %-9s after %-6s n=%4.0f | I deal +%.2f more, I take %.2f, my extra hits %.2f | net %+.2f | hit from dist %.2f%n",
                    c == 1 ? "CHARGED" : "recharging", T[t], n[t][c], dealtAfter[t][c] / k, takenAfter[t][c] / k, hitsAfter[t][c] / k, (dealtAfter[t][c] - takenAfter[t][c]) / k, dist[t][c] / k);
            }
        }
    }
}
