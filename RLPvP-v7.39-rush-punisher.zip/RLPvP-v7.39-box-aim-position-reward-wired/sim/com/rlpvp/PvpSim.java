package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Minecraft-like 1v1 sword duel (flat ground) that trains the REAL PpoAgent / Reward / Curriculum / ObsStack code and
 * writes a state.bin the mod can load. Physics follows vanilla Java: gravity 0.08 and 0.98 drag, jump 0.42, ground/air
 * friction (0.546 / 0.91), walk 0.1 / sprint x1.3, hit invulnerability (20 ticks, ignore hits while > 10), hurt knockback 0.4 +
 * sprint knockback 0.5, sword 7 dmg scaled by the attack cooldown (12.5 ticks) with the 1.5x jump-crit (falling, not sprinting),
 * reach 3.0 ray vs the 0.6 x 1.8 hitbox. The observation frame is a copy of Observation.frame (Minecraft-free).
 * Network model: each player has independent C2S/S2C TCP-like streams, RTT/asymmetry, jitter, ordered retransmission stalls,
 * position/rotation/action packets, server-authoritative attack checks, delayed knockback and correction packets. Clients predict own movement.
 * Usage: PvpSim <ticks> <out state.bin> [seed] [resume.bin|-] [rival state.bin|-]
 */
public final class PvpSim {
    // ------------------------------------------------------------------ entity
    static final class E {
        double x, y, z, vx, vy, vz, px, py, pz;
        float yaw, pitch, hp = 20f;
        boolean ground = true, sprint, swinging, jump, sprintKey, sneak;
        int ticker = 100, serverTicker = 100, hurtTime, invul, swingT, fwd, str, clientInputMask;
        MinecraftRules.Kit kit = MinecraftRules.DIAMOND_PROT3; // equipment (-Dsim.kit=...), see assignKits()
        int kbDelay, kbLeft;                             // desync: the victim's client applies the server's knockback packet kbDelay ticks late
        double kbVx, kbVy, kbVz;                         // the velocity the server computed, waiting to arrive
        final double[] motionScratch, knockbackScratch; // physics scratch exists only on live client/server entities
        E() { this(true); }
        E(boolean physicsScratch) {
            motionScratch = physicsScratch ? new double[2] : EMPTY_MOTION;
            knockbackScratch = physicsScratch ? new double[3] : EMPTY_KNOCKBACK;
        }
        private static final double[] EMPTY_MOTION = new double[0], EMPTY_KNOCKBACK = new double[0];
        int jumpDelay;                                   // vanilla noJumpDelay: 10 ticks between two jumps (holding space hops at 2 Hz)
        double lastHurt;                                 // raw damage of the last hit taken (vanilla compares a new hit with it during the invulnerability window)
        double fall;
        float scale() { return Minecraft263Combat.attackStrengthScale(ticker, 0.5F, (float)kit.attackCooldownTicks()); }
        float serverScale() { return Minecraft263Combat.attackStrengthScale(serverTicker, 0.5F, (float)kit.attackCooldownTicks()); }
        void copyFrom(E e) {
            x=e.x; y=e.y; z=e.z; vx=e.vx; vy=e.vy; vz=e.vz; px=e.px; py=e.py; pz=e.pz;
            yaw=e.yaw; pitch=e.pitch; hp=e.hp; ground=e.ground; sprint=e.sprint; swinging=e.swinging; kit=e.kit;
            sneak=e.sneak; jump=e.jump; sprintKey=e.sprintKey; ticker=e.ticker; serverTicker=e.serverTicker;
            hurtTime=e.hurtTime; invul=e.invul; swingT=e.swingT; fwd=e.fwd; str=e.str; clientInputMask=e.clientInputMask;
            jumpDelay=e.jumpDelay; lastHurt=e.lastHurt; fall=e.fall;
            kbDelay=e.kbDelay; kbLeft=e.kbLeft; kbVx=e.kbVx; kbVy=e.kbVy; kbVz=e.kbVz;
        }
        double eyeY() { return y + (sneak ? 1.27 : 1.62); }          // crouched eyes are lower
        double height() { return sneak ? 1.5 : 1.8; }                 // ...and so is the hitbox
        void snapPrev() { px = x; py = y; pz = z; }
    }


    static E copy(E e) {
        E c = new E();
        c.copyFrom(e);
        return c;
    }
    private static E copySnapshot(E e) {
        E c = new E(false); // snapshot views never run physics and therefore need no scratch arrays
        c.copyFrom(e);
        return c;
    }

    /** Client-side remote-entity interpolation and delayed self-status snapshot. */
    static final class Link {
        double ex, ey, ez, eyaw, epitch, tx, ty, tz, tyaw, tpitch;
        int steps;
        final E last = new E(false), selfSnapshot = new E(false);
        boolean initialized, ease = true;

        void begin(E other, E self) {
            last.copyFrom(other); selfSnapshot.copyFrom(self); initialized = true;
            ex = tx = other.x; ey = ty = other.y; ez = tz = other.z;
            eyaw = tyaw = other.yaw; epitch = tpitch = other.pitch; steps = 0;
        }

        /** A real S2C delivery updates the client's remote entity target and own health/status. */
        void accept(E other, E self) {
            tx = other.x; ty = other.y; tz = other.z;
            tyaw = eyaw + wrap(other.yaw - eyaw); tpitch = other.pitch;
            last.copyFrom(other);
            selfSnapshot.copyFrom(self);
            initialized = true;
            // Client-side entity interpolation occurs after the network packet is received.
            steps = 3;
        }

        void interpolate() {
            if (!ease) {
                ex = tx; ey = ty; ez = tz; eyaw = tyaw; epitch = tpitch; steps = 0;
            } else if (steps > 0) {
                double k = 1.0 / steps;
                ex += (tx - ex) * k; ey += (ty - ey) * k; ez += (tz - ez) * k;
                eyaw += (tyaw - eyaw) * k; epitch += (tpitch - epitch) * k;
                steps--;
            }
        }

        void otherInto(E c) {
            c.copyFrom(last);
            c.x = ex; c.y = ey; c.z = ez; c.yaw = (float)eyaw; c.pitch = (float)epitch;
        }

        void selfInto(E me, E c) {
            c.copyFrom(me);
            if (initialized) {
                c.hp = selfSnapshot.hp; c.hurtTime = selfSnapshot.hurtTime; c.invul = selfSnapshot.invul;
            }
        }

        E other() { E c = new E(); otherInto(c); return c; }
        E self(E me) { E c = new E(); selfInto(me, c); return c; }

    }

    /** Coalesced server replication update carried on the same S2C stream as corrections and velocity. */
    static final class SnapshotMessage {
        final E other, self;
        SnapshotMessage(E other, E self) { this.other = copySnapshot(other); this.self = copySnapshot(self); }
    }

    /** Avoids emitting unchanged entity state; movement/rotation or health/status changes trigger an update. */
    static final class SnapshotSender {
        final E lastOther = new E(false), lastSelf = new E(false);
        boolean initialized;
        void reset(E other, E self) { lastOther.copyFrom(other); lastSelf.copyFrom(self); initialized = true; }
        boolean changed(E a, E b) {
            return a.x != b.x || a.y != b.y || a.z != b.z || a.yaw != b.yaw || a.pitch != b.pitch
                || a.hp != b.hp || a.hurtTime != b.hurtTime || a.invul != b.invul
                || a.ground != b.ground || a.sprint != b.sprint || a.sneak != b.sneak
                || a.swinging != b.swinging || a.swingT != b.swingT;
        }
        boolean shouldSend(E other, E self) {
            if (!initialized || changed(other, lastOther) || changed(self, lastSelf)) {
                reset(other, self); return true;
            }
            return false;
        }
    }

    static final class MoveMessage {
        final boolean hasPosition, hasRotation, onGround, horizontalCollision;
        final double x, y, z;
        final float yaw, pitch;
        MoveMessage(E e, boolean hasPosition, boolean hasRotation) {
            this.hasPosition = hasPosition; this.hasRotation = hasRotation;
            this.x = e.x; this.y = e.y; this.z = e.z; this.yaw = e.yaw; this.pitch = e.pitch;
            this.onGround = e.ground; this.horizontalCollision = false;
        }
    }
    static final class SprintMessage { final boolean sprinting; SprintMessage(boolean value) { sprinting = value; } }
    /** Mirrors ServerboundPlayerInputPacket: the server records key state and shift state. */
    static final class InputMessage { final int mask; InputMessage(int mask) { this.mask = mask; } }
    /** ServerboundClientTickEndPacket: resets the server's per-client-tick movement guard. */
    static final class ClientTickEndMessage {}
    static final class AttackMessage { final boolean clientSelectedTarget; AttackMessage(boolean value) { clientSelectedTarget = value; } }
    static final class MotionMessage { final double vx, vy, vz; MotionMessage(E e) { vx=e.vx; vy=e.vy; vz=e.vz; } }
    static final class CorrectionMessage {
        final double x, y, z, vx, vy, vz; final float yaw, pitch; final boolean onGround;
        CorrectionMessage(E e) { x=e.x; y=e.y; z=e.z; vx=e.vx; vy=e.vy; vz=e.vz; yaw=e.yaw; pitch=e.pitch; onGround=e.ground; }
    }
    static final class ClientSender {
        double xLast, yLast, zLast; float yawLast, pitchLast;
        boolean wasSprinting, lastOnGround, lastHorizontalCollision, initialized;
        int positionReminder, lastInputMask = Integer.MIN_VALUE;
        void reset(E e) {
            xLast=e.x; yLast=e.y; zLast=e.z; yawLast=e.yaw; pitchLast=e.pitch;
            wasSprinting=e.sprint; lastOnGround=e.ground; lastHorizontalCollision=false;
            positionReminder=0; lastInputMask=Integer.MIN_VALUE; initialized=true;
        }
    }
    static final class ServerMotionState {
        boolean receivedPositionThisClientTick;
        double firstGoodX, firstGoodY, firstGoodZ;
        double lastGoodX, lastGoodY, lastGoodZ;
        int receivedMovePacketCount, knownMovePacketCount;
        void reset(E e) {
            firstGoodX=lastGoodX=e.x; firstGoodY=lastGoodY=e.y; firstGoodZ=lastGoodZ=e.z;
            receivedMovePacketCount=knownMovePacketCount=0; receivedPositionThisClientTick=false;
        }
        void finishServerTick(E e) {
            firstGoodX=e.x; firstGoodY=e.y; firstGoodZ=e.z;
            knownMovePacketCount=receivedMovePacketCount;
        }
    }

    boolean prevGroundFr = true;     // ground state at the moment the last action was chosen (frame[4] of the previous tick)
    final SpamGuard spam = new SpamGuard();
    final SpamGuard.In spamIn = new SpamGuard.In();
    final Link linkMe, linkBot;
    NetworkSimulation.Connection meNetwork, botNetwork;
    private static final java.util.Comparator<NetworkSimulation.Delivery> SERVER_PACKET_ORDER =
        java.util.Comparator.comparingDouble((NetworkSimulation.Delivery d) -> d.arrivedAtMs)
            .thenComparingLong(d -> d.sequence);
    // Each TCP stream is already ordered by arrival time. Keep the streams separate and
    // merge them linearly instead of concatenating and sorting every tick.
    private final ArrayList<NetworkSimulation.Delivery> meIncomingPackets = new ArrayList<>();
    private final ArrayList<NetworkSimulation.Delivery> botIncomingPackets = new ArrayList<>();
    E serverMe = new E(), serverBot = new E();
    final ClientSender meSender = new ClientSender(), botSender = new ClientSender();
    final ServerMotionState serverMeMotion = new ServerMotionState(), serverBotMotion = new ServerMotionState();
    final SnapshotSender meSnapshotSender = new SnapshotSender(), botSnapshotSender = new SnapshotSender();
    long movementCorrections, movementPackets, attackPackets;
    long movementDuplicateRejections, movementSpeedRejections, movementInvalidRejections;
    long networkRetransmissionBase, networkProfileCount;
    double networkRttSumMs, networkC2sSumMs, networkS2cSumMs;

    long networkRetransmissions() {
        return networkRetransmissionBase
            + meNetwork.clientToServer.retransmissions() + meNetwork.serverToClient.retransmissions()
            + botNetwork.clientToServer.retransmissions() + botNetwork.serverToClient.retransmissions();
    }
    String networkSummary() {
        double n = Math.max(1, networkProfileCount);
        return String.format(Locale.ROOT, "net RTT %.1fms C2S %.1f/S2C %.1fms pkts move=%d attack=%d corrections=%d TCP-retry=%d",
            networkRttSumMs / n, networkC2sSumMs / n, networkS2cSumMs / n,
            movementPackets, attackPackets, movementCorrections, networkRetransmissions());
    }
    /** Diagnostics: a hand-written policy (frame -> action) used instead of the network, to test what the environment allows. */
    java.util.function.Function<float[], float[]> hand;
    boolean ease = true;          // diagnostics: false = the client sees the enemy's exact position
    boolean latency = !"false".equals(System.getProperty("sim.latency"));
    Double fixedLag;              // evaluation compatibility: fixed one-way delay in ticks (converted to RTT milliseconds)
    long creditUntil = -1;
    float prevViewOppHp, prevViewMyHp, botPrevViewMeHp, botPrevViewSelfHp, botPrevMeHp, botPrevHp;
    final double[] prevBotView = new double[3], prevMeView = new double[3];
    // Per-simulator scratch buffers: consumed synchronously, never retained by policy/memory.
    // One set per PvpSim keeps parallel workers isolated from each other.
    private final E playerTargetView = new E(), playerSelfView = new E();
    private final E botTargetView = new E(), botSelfView = new E();
    private final double[] meVelocityScratch = new double[3], botVelocityScratch = new double[3];
    private final double[] playerRelativeVelocityScratch = new double[3], botRelativeVelocityScratch = new double[3];
    private final float[] playerFrameScratch = new float[Config.FRAME], botFrameScratch = new float[Config.FRAME];

    /** Server-side damage of an attack made with cooldown scale s (decided when the packet was sent). */
    int hitS(E a, E t, double s, boolean crit, boolean sprintAtClick) {
        return strike(a, t, s, crit, sprintAtClick && s > 0.9);
    }

    /**
     * One landed attack, with the vanilla maths (MinecraftRules): attack-strength scaling, crit, sharpness, armor/toughness/protection/resistance.
     * @return 0 = nothing happened, 1 = only the part above the previous hit went through (target inside its invulnerability window: no knockback,
     *         no new window), 2 = a full hit (damage, 20-tick window, knockback, sprint knockback)
     */
    int strike(E a, E t, double s, boolean crit, boolean sprintKb) {
        if (a.hp <= 0f || t.hp <= 0f) return 0;
        double raw = MinecraftRules.attackDamage(a.kit, s, crit);
        // Player.attack() calls onAttack()/resetOnlyAttackStrengthTicker() when the server handles a valid attack.
        a.serverTicker = 0;
        if (t.invul > 10) {
            double extra = MinecraftRules.invulnerableExtra(raw, t.lastHurt);
            if (extra <= 0) return 0;
            t.hp -= (float) MinecraftRules.afterDefense(t.kit, extra);
            t.lastHurt = raw;
            return 1;
        }
        t.lastHurt = raw;
        t.hp -= (float) MinecraftRules.afterDefense(t.kit, raw);
        t.invul = 20; t.hurtTime = 10;
        // LivingEntity.hurtServer -> dealDefaultKnockback(0.4F), using the DamageSource position.
        knock(t, a, 0.4, a.x - t.x, a.z - t.z);
        if (sprintKb) {
            // Player.attack -> causeExtraKnockback(getKnockback + 0.5F), using attacker yaw.
            float yawRadians = (float)a.yaw * (float)(Math.PI / 180.0);
            knock(t, a, 0.5, Minecraft263Trig.sin(yawRadians), -Minecraft263Trig.cos(yawRadians));
            a.vx *= 0.6; a.vz *= 0.6; a.sprint = false;
        }
        return 2;
    }

    /** Equipment per episode: -Dsim.kit=... (default: diamond_prot3 = diamond sword + full diamond armor, Protection III) | naked | iron | diamond | diamond_prot | netherite | random. */
    void assignKits() {
        String k = System.getProperty("sim.kit", "diamond_prot3");
        boolean rnd = k.equalsIgnoreCase("random");
        me.kit = rnd ? MinecraftRules.random(rng) : MinecraftRules.byName(k);
        bot.kit = rnd ? MinecraftRules.random(rng) : MinecraftRules.byName(k);
        me.hp += me.kit.absorption; bot.hp += bot.kit.absorption;
        me.lastHurt = bot.lastHurt = 0;
        disc.setTypicalHit(MinecraftRules.afterDefense(bot.kit, 7.0));   // the unit of net HP, kit scales and the near-miss credit: what a sword hit does to this kit
        episodeTicks = MinecraftRules.episodeTicks(me.kit, bot.kit);
        disc.setEpisodeTicks(episodeTicks);
        String limitOverride = System.getProperty("sim.episodeTicks");
        if (limitOverride != null) {
            try {
                episodeTicks = Integer.parseInt(limitOverride);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid -Dsim.episodeTicks value: " + limitOverride, e);
            }
            if (episodeTicks < 1) throw new IllegalArgumentException("-Dsim.episodeTicks must be >= 1");
        }
    }

    /** Receive client packets on the authoritative server thread in their TCP-stream order. */
    void processServerPackets() {
        meIncomingPackets.clear();
        botIncomingPackets.clear();
        meNetwork.clientToServer.drainInto(tick, meIncomingPackets);
        botNetwork.clientToServer.drainInto(tick, botIncomingPackets);
        int mi = 0, bi = 0;
        while (mi < meIncomingPackets.size() || bi < botIncomingPackets.size()) {
            NetworkSimulation.Delivery d;
            if (bi >= botIncomingPackets.size()) d = meIncomingPackets.get(mi++);
            else if (mi >= meIncomingPackets.size()) d = botIncomingPackets.get(bi++);
            else if (SERVER_PACKET_ORDER.compare(meIncomingPackets.get(mi), botIncomingPackets.get(bi)) <= 0)
                d = meIncomingPackets.get(mi++); // <= preserves the old stable-sort order on exact ties
            else d = botIncomingPackets.get(bi++);
            // The direction is identified by the payload's client id wrapper.
            if (d.payload instanceof ClientPacket cp) processClientPacket(cp.isMe, cp.message);
        }
    }

    static final class ClientPacket {
        final boolean isMe; final Object message;
        ClientPacket(boolean isMe, Object message) { this.isMe=isMe; this.message=message; }
    }

    void processClientPacket(boolean isMe, Object message) {
        E a = isMe ? serverMe : serverBot;
        E t = isMe ? serverBot : serverMe;
        ServerMotionState motion = isMe ? serverMeMotion : serverBotMotion;
        if (message instanceof MoveMessage move) {
            applyServerMove(isMe, a, motion, move);
        } else if (message instanceof InputMessage input) {
            a.clientInputMask = input.mask;
            a.sneak = (input.mask & 16) != 0;
            if (a.sneak) a.sprint = false;
        } else if (message instanceof SprintMessage sprint) {
            a.sprint = sprint.sprinting;
            a.sprintKey = sprint.sprinting;
        } else if (message instanceof ClientTickEndMessage) {
            // The uploaded server handler clears receivedPositionThisTick on this packet,
            // not at a global server-tick boundary. TCP order is important here.
            motion.receivedPositionThisClientTick = false;
        } else if (message instanceof AttackMessage attack) {
            attackPackets++;
            if (a.hp <= 0f || t.hp <= 0f) return;
            swingAnim(a);
            // handleAttack receives only an entity id. The ray selection happened client-side;
            // the server independently validates the target and its current attack range.
            double serverRange = Double.parseDouble(System.getProperty("rlpvp.serverAttackRange", "3.0"));
            if (attack.clientSelectedTarget && reachSq(a.x, a.eyeY(), a.z, t) <= serverRange * serverRange) {
                float serverCharge = a.serverScale();
                boolean fullStrength = serverCharge > 0.9F;
                boolean sprintAttack = a.sprint && fullStrength;
                boolean critical = Minecraft263Combat.canCriticalAttack(fullStrength, (float)a.fall,
                    a.ground, false, false, false, false, true, a.sprint);
                if (isMe && telemetryEnabled) rewardTelemetry.noteServerAttack(critical, sprintAttack);
                float hpBefore = t.hp;
                int result = hitS(a, t, serverCharge, critical, sprintAttack);
                if (result > 0) {
                    if (isMe) {
                        mySprintHitLandedThisTick |= result == 2 && sprintAttack;
                        myCritHitLandedThisTick |= critical;
                        if (telemetryEnabled) {
                            // Match the trainer's effective HP-delta metric; do not let lethal
                            // overkill inflate technique damage telemetry below zero HP.
                            double damageHp = Math.max(0.0, hpBefore - Math.max(0.0, t.hp));
                            rewardTelemetry.noteServerResolvedHit(critical, result == 2 && sprintAttack, damageHp);
                            techniqueOpportunityAudit.recordConfirmedHit(critical, result == 2 && sprintAttack, damageHp, true);
                        }
                    }
                    else { botHitLanded = true; botSprintHitLandedThisTick |= result == 2 && sprintAttack; }
                    if (result == 2) queueKnockbackToClient(!isMe, t);
                }
            }
        }
    }

    /** Server applies a received ServerboundMovePlayerPacket to its authoritative player replica. */
    void applyServerMove(boolean isMe, E server, ServerMotionState state, MoveMessage packet) {
        if (packet.hasPosition) {
            // ServerGamePacketListenerImpl rejects a second position packet before the
            // ServerboundClientTickEndPacket resets receivedPositionThisTick. This guard follows
            // that ordered per-client-tick protocol, rather than assuming a global server tick.
            if (state.receivedPositionThisClientTick) {
                movementCorrections++; movementDuplicateRejections++;
                queuePlayerCorrection(isMe, server);
                return;
            }
            double x = packet.x, y = packet.y, z = packet.z;
            if (Double.isNaN(x) || Double.isNaN(y) || Double.isNaN(z)
                    || !Float.isFinite(packet.yaw) || !Float.isFinite(packet.pitch)) {
                movementCorrections++; movementInvalidRejections++;
                queuePlayerCorrection(isMe, server);
                return;
            }
            // Match the handler's world-coordinate clamps before movement validation.
            x = Math.max(-29_999_999.0, Math.min(29_999_999.0, x));
            y = Math.max(-20_000_000.0, Math.min(20_000_000.0, y));
            z = Math.max(-29_999_999.0, Math.min(29_999_999.0, z));
            state.receivedPositionThisClientTick = true;
            state.receivedMovePacketCount++;
            int deltaPackets = state.receivedMovePacketCount - state.knownMovePacketCount;
            if (deltaPackets > 5) deltaPackets = 1;
            double dx = x - state.firstGoodX, dy = y - state.firstGoodY, dz = z - state.firstGoodZ;
            double expected = server.vx * server.vx + server.vy * server.vy + server.vz * server.vz;
            double moved = dx * dx + dy * dy + dz * dz;
            // Same broad threshold shape and packet-count multiplier as handlePlayerPositionChange.
            if (moved - expected > 100.0 * Math.max(1, deltaPackets)) {
                movementCorrections++; movementSpeedRejections++;
                queuePlayerCorrection(isMe, server);
                return;
            }
            double oldY = server.y;
            double oldX = server.x, oldZ = server.z;
            server.x = x; server.y = Math.max(0.0, y); server.z = z;
            double deltaX = server.x - oldX, deltaY = server.y - oldY, deltaZ = server.z - oldZ;
            server.vx = deltaX; server.vy = deltaY; server.vz = deltaZ;
            // Fall distance is positional distance, not a per-tick velocity; account for all delayed ticks.
            if (deltaY < 0.0 && !server.ground) server.fall += -deltaY;
            if (packet.onGround || server.y <= 0.0) { server.fall = 0.0; server.ground = true; }
            else server.ground = false;
            state.lastGoodX = server.x; state.lastGoodY = server.y; state.lastGoodZ = server.z;
            movementPackets++;
        }
        if (packet.hasRotation) {
            // Match vanilla's absolute rotation semantics: yaw is not modulo-360 normalized on receipt.
            // The client sends a continuous absolute yaw; wrapping it here would create a false near-360 delta
            // in the server replica and diverge from the real packet path. Pitch remains a physical [-90, 90] axis.
            server.yaw = packet.yaw;
            server.pitch = Math.max(-90.0f, Math.min(90.0f, packet.pitch));
        }
        // onGround/horizontalCollision are included on all ServerboundMovePlayerPacket variants.
        server.ground = packet.onGround || server.y <= 0.0;
    }

    void queuePlayerCorrection(boolean victimIsMe, E serverPlayer) {
        NetworkSimulation.Connection connection = victimIsMe ? meNetwork : botNetwork;
        connection.serverToClient.send(tick, new CorrectionMessage(serverPlayer), 40);
    }

    void queueKnockbackToClient(boolean victimIsMe, E serverVictim) {
        NetworkSimulation.Connection connection = victimIsMe ? meNetwork : botNetwork;
        connection.serverToClient.send(tick, new MotionMessage(serverVictim), 24);
    }

    void receiveClientboundPackets() {
        for (NetworkSimulation.Delivery d : meNetwork.serverToClient.drain(tick)) {
            if (d.payload instanceof MotionMessage m) { me.vx=m.vx; me.vy=m.vy; me.vz=m.vz; me.kbLeft=0; }
            else if (d.payload instanceof CorrectionMessage c) applyClientCorrection(me, meSender, c);
            else if (d.payload instanceof SnapshotMessage snapshot) linkMe.accept(snapshot.other, snapshot.self);
        }
        for (NetworkSimulation.Delivery d : botNetwork.serverToClient.drain(tick)) {
            if (d.payload instanceof MotionMessage m) { bot.vx=m.vx; bot.vy=m.vy; bot.vz=m.vz; bot.kbLeft=0; }
            else if (d.payload instanceof CorrectionMessage c) applyClientCorrection(bot, botSender, c);
            else if (d.payload instanceof SnapshotMessage snapshot) linkBot.accept(snapshot.other, snapshot.self);
        }
        linkMe.interpolate(); linkBot.interpolate();
    }

    /** Emit the server's changed entity/player status to each client over its real S2C stream. */
    void sendServerSnapshots() {
        if (meSnapshotSender.shouldSend(serverBot, serverMe)) {
            meNetwork.serverToClient.send(tick, new SnapshotMessage(serverBot, serverMe), 48);
        }
        if (botSnapshotSender.shouldSend(serverMe, serverBot)) {
            botNetwork.serverToClient.send(tick, new SnapshotMessage(serverMe, serverBot), 48);
        }
    }

    void applyClientCorrection(E client, ClientSender sender, CorrectionMessage c) {
        client.x = client.px = c.x; client.y = client.py = c.y; client.z = client.pz = c.z;
        client.vx = c.vx; client.vy = c.vy; client.vz = c.vz;
        client.yaw = c.yaw; client.pitch = c.pitch; client.ground = c.onGround;
        client.kbLeft = 0;
        sender.reset(client);
    }

    void sendClientMovement(E client, NetworkSimulation.Connection connection, ClientSender sender, boolean isMe) {
        if (!sender.initialized) sender.reset(client);
        // LocalPlayer.sendChanges sends changed player-input keys before sendPosition(); sprint
        // transitions are then queued by sendPosition() before its movement report.
        int inputMask = (client.fwd > 0 ? 1 : 0) | (client.fwd < 0 ? 2 : 0)
            | (client.str < 0 ? 4 : 0) | (client.str > 0 ? 8 : 0)
            | (client.sneak ? 16 : 0) | (client.jump ? 32 : 0);
        if (inputMask != sender.lastInputMask) {
            connection.clientToServer.send(tick, new ClientPacket(isMe, new InputMessage(inputMask)), 3);
            sender.lastInputMask = inputMask;
        }
        if (client.sprint != sender.wasSprinting) {
            connection.clientToServer.send(tick, new ClientPacket(isMe, new SprintMessage(client.sprint)), 3);
            sender.wasSprinting = client.sprint;
        }
        double dx = client.x - sender.xLast, dy = client.y - sender.yLast, dz = client.z - sender.zLast;
        double dYaw = client.yaw - sender.yawLast, dPitch = client.pitch - sender.pitchLast;
        sender.positionReminder++;
        boolean move = dx * dx + dy * dy + dz * dz > 4.0e-8 || sender.positionReminder >= 20;
        boolean rot = dYaw != 0.0 || dPitch != 0.0;
        boolean status = sender.lastOnGround != client.ground || sender.lastHorizontalCollision;
        if (move || rot || status) {
            connection.clientToServer.send(tick, new ClientPacket(isMe, new MoveMessage(client, move, rot)), move ? (rot ? 34 : 26) : 10);
            if (move) {
                sender.xLast=client.x; sender.yLast=client.y; sender.zLast=client.z; sender.positionReminder=0;
            }
            if (rot) { sender.yawLast=client.yaw; sender.pitchLast=client.pitch; }
            sender.lastOnGround=client.ground;
        }
    }
    void sendClientTickEnd(NetworkSimulation.Connection connection, boolean isMe) {
        connection.clientToServer.send(tick, new ClientPacket(isMe, new ClientTickEndMessage()), 1);
    }

    boolean botHitLanded;
    boolean mySprintHitLandedThisTick, botSprintHitLandedThisTick, myCritHitLandedThisTick;
    final Reward.Telemetry rewardTelemetry = new Reward.Telemetry();
    final Reward.Breakdown rewardBreakdown = new Reward.Breakdown();
    boolean telemetryEnabled;

    final Random rng;
    final E me = new E(), bot = new E();
    final PpoAgent agent;
    Curriculum cur = new Curriculum(); // not final: ParallelPvpTrain makes all of its environments share ONE (synchronized) curriculum
    final ObsStack obs = new ObsStack();
    final ObsStack botObs = new ObsStack();
    final List<FrozenPolicy> pool = new ArrayList<>();
    final List<Long> poolTick = new ArrayList<>();
    final List<String> poolId = new ArrayList<>();
    final OpponentLeague league;
    /** Only one environment in a parallel run may write the shared league/snapshot files. */
    final boolean leaguePersistenceOwner;
    final String leagueAgentId = "current";
    String activeLeagueOpponentId;
    int leagueStyle = -1;
    /** Training sims only: bias the pre-league random bot-style mix toward styles the agent is weak against (see Config.STYLE_WEAKNESS_FROM_STAGE). */
    boolean weaknessStyles = false;
    private int earlyStyle = -1;   // style drawn by that bias this episode, recorded at its end
    final Path leagueFile = Path.of(System.getProperty("sim.league.file", "league/ratings.csv"));
    final Path leagueDir = Path.of(System.getProperty("sim.league.dir", "league"));
    FrozenPolicy rival;                 // a DIFFERENT lineage (other seed / weights / history), frozen
    final CollapseGuard guard = new CollapseGuard(0.5, 2, 2); // watches play-mode probes: low noise, so smooth less and react after 2 windows
    final HitMemory mem = new HitMemory(), botMem = new HitMemory();
    final MotionMemory motion = new MotionMemory(), botMotion = new MotionMemory();
    final CombatObservationMemory combat = new CombatObservationMemory(), botCombat = new CombatObservationMemory();
    final float[] aimBoxScratch = new float[2], botAimBoxScratch = new float[2];
    final SprintHitFollowupMemory sprintFollowup = new SprintHitFollowupMemory(), botSprintFollowup = new SprintHitFollowupMemory();
    final OpponentMemory oppMem = new OpponentMemory(), botOppMem = new OpponentMemory();
    final KbTiming kbT = new KbTiming(), botKb = new KbTiming();
    final ComboDefenseTracker comboDefense = new ComboDefenseTracker();
    final CombatPositionReward positionReward = new CombatPositionReward();
    boolean botPrevGroundFr = true;
    boolean botLastHitSprint;
    final float[] summary = new float[Config.SUMMARY], botSummary = new float[Config.SUMMARY];
    int prevOppMask, botPrevMask;
    long lastSnap = 0;
    float entropyEma = 0;

    // bot script state
    Curriculum.Opponent mode = Curriculum.Opponent.STATIONARY;
    FrozenPolicy policy;
    int bFwd, bStr, ticksLeft, attackCd = 20, wtap, critTicks;
    int hopCd = 10;   // stationary bot hop timer (stages BOT_HOP_MIN_STAGE..MAX_STAGE): its height changes, so pitch has to be tracked
    boolean critArm;
    double[][] aimHist = new double[3][2];
    int aimHistN;
    double aimErrYaw;
    final float[] botLast = new float[7];
    int botSinceSwing = 40, botSinceOppSwing = 40, botSinceDealt = 40, botSinceTaken = 40;
    boolean botLastOppSw;
    double[] botPrevOpp = new double[3], botPrevSelf = new double[3];

    // trainer-style per-episode bookkeeping
    int tick, lastHitTick, sinceDealt, sinceTaken, sinceReal, sinceOppSwing, sinceMySwing, combo, epAim;
    int episodeTicks = Config.EPISODE_TICKS;
    float prevMyHp, prevOppHp, pendingSoft, epSoft, epDealt, epTaken;
    double prevDist, epFit, pendingTech;
    boolean lastOppSw, firstHitDone, lastHitCrit, lastHitSprint, lastHitGround, lastHitFull, lastHitPunish;
    double lastHitDist;                                  // centre distance when my last landed swing was made (SPACING)
    boolean reviewEp;
    EpisodeOutcome lastOutcome;
    int lastHitGap;
    int kickCd;     // ticks until the next stage-2 pitch kick (Config.PITCH_KICK)
    int panTicks;
    float panYaw, panPitch;
    final float[] lastAct = new float[7];
    /** Optional measurement hook (eval only): sees (stacked obs, chosen action) each tick and may return a replacement action. */
    java.util.function.BiFunction<float[], float[], float[]> actionTap;
    /** Braking envelope near the target (AimBrake) for the agent's camera; -Dsim.aimbrake=false disables it for A/B measurements. */
    /** Agent camera yaw velocity (deg/tick) after the previous tick; measurement only. */
    double yawVel() { return dynY.vel(); }
    /** Degrees the agent camera turned in its last tick (what vanilla interpolates linearly across the next 50 ms); measurement only. */
    double lastYawTurn, lastPitchTurn;
    /**
     * Frame model of the real-rotation glide (GlideCamera / MinecraftFrameMixin), agent space. The game ticks stay the only place where rotation
     * is decided (so attacks, packets, observations and training are exactly as before: the curve ends on the tick's angle); this only exposes
     * what the player's real yaw does BETWEEN ticks, for measurement. glideV0 = camera speed at the start of the last tick's segment, glideV1 =
     * at its end (the next segment starts with the same speed, as in ActionApplier / GlideCamera.push).
     */
    double glideV0, glideV1;
    /** Real yaw (deg, relative to the segment start) at fraction t of the last tick: glide curve when Config.GLIDE_REAL_ROTATION, else vanilla's straight line. */
    double realYawAt(double t) { return Config.GLIDE_REAL_ROTATION ? GlideCamera.hermite(lastYawTurn, glideV0, glideV1, t) : t * lastYawTurn; }
    /** Speed (deg/tick) of that real yaw at fraction t. */
    double realYawSpeedAt(double t) { return Config.GLIDE_REAL_ROTATION ? GlideCamera.hermiteSpeed(lastYawTurn, glideV0, glideV1, t) : lastYawTurn; }
    boolean aimBrake = Config.AIM_BRAKE && !"false".equals(System.getProperty("sim.aimbrake"));
    float lookYaw, lookYaw2, lookPitch, lookPitch2;
    final CameraReward cam = new CameraReward();
    static boolean probeGuard = true;
    int evalLock;
    String lastProbe = "";
    final boolean strictGreedy = Boolean.getBoolean("sim.strictGreedy"); // -Dsim.strictGreedy=true evaluates the argmax policy instead of the played one
    BotAI ai;
    final BotDifficulty botDiff = new BotDifficulty();
    Double evalDifficulty = null;   // fixed bot strength for evaluation / benchmarks (null = adaptive during training)
    boolean legacyBots = false;     // true = the old orbit-beatable AGGRESSIVE/STRONG scripts (benchmark baseline only)
    /** Training: each episode is randomly played in a MIRRORED world (left/right swapped in the observation and in the actions), so the agent cannot lock onto one strafe side. */
    /** Camera smoothing coefficient used by this simulator instance (default = Config.LOOK_SMOOTH, 1 = off), see Config. */
    double lookAlpha = Config.LOOK_SMOOTH;
    private final double[][] lookF = new double[Math.max(1, Config.LOOK_SMOOTH_POLES)][2];
    private double prevAppYaw;
    final GameplayRotation rotA = new GameplayRotation(); // the agent's camera: the SAME controller class the mod uses (ActionApplier)
    final CameraDynamics dynY = rotA.yaw, dynP = rotA.pitch, botDynY = new CameraDynamics(), botDynP = new CameraDynamics();
    boolean mirrorOn = false;
    boolean mirror;
    /** Per-episode mouse: sensitivity multiplier and random hand-effort noise; grows with the stage so the agent cannot rely on exact control inputs. */
    float sens = 1f, noiseYaw, noisePitch;
    final TechniqueReward techR = new TechniqueReward();
    final TechniqueReward.In techIn = new TechniqueReward.In();
    final TechniqueDiscovery disc = new TechniqueDiscovery();
    final TechniqueDiscovery.In discIn = new TechniqueDiscovery.In();
    final TechniqueOpportunityAudit techniqueOpportunityAudit = new TechniqueOpportunityAudit();
    boolean hitConsumed = true;
    float lastHitEnemyCharge = 1f;
    double relPX = Double.NaN, relPZ, distH1 = Double.NaN, distH2 = Double.NaN; // previous relative position (orbit reward) and the last two distances (sprint-reset momentum rule)

    // window stats
    int wEp, wWin, wLoss, wDraw, wNoContest, wHits, wCrit, wSprint, wSwing, wWhiff;
    int wSprintFollowupOpps, wSprintFollowups, wSprintFollowupExpired, wSprintFollowupTicks;
    int wIncomingCombos, wStrafeComboEscapes;
    double pendingComboDefenseReward;
    double wDealt, wTaken, wRet, wLook;
    long wLookN;
    String lastStageMsg = "";

    PvpSim(long seed, PpoAgent a) {
        this(seed, a, new OpponentLeague(), true, true);
    }

    /** Parallel environments share one synchronized in-memory league; only its owner persists snapshots and ratings. */
    PvpSim(long seed, PpoAgent a, OpponentLeague sharedLeague, boolean persistenceOwner) {
        this(seed, a, sharedLeague, persistenceOwner, false);
    }

    private PvpSim(long seed, PpoAgent a, OpponentLeague sharedLeague, boolean persistenceOwner, boolean loadLeague) {
        rng = new Random(seed);
        ai = new BotAI(rng);
        linkMe = new Link();
        linkBot = new Link();
        meNetwork = new NetworkSimulation.Connection(NetworkSimulation.Profile.offline(), seed * 101 + 3);
        botNetwork = new NetworkSimulation.Connection(NetworkSimulation.Profile.offline(), seed * 101 + 4);
        agent = a;
        rewardTelemetry.setServerTelemetryAvailable(true);
        league = java.util.Objects.requireNonNull(sharedLeague, "sharedLeague");
        leaguePersistenceOwner = persistenceOwner;
        if (loadLeague) {
            try { league.load(leagueFile); }
            catch (Exception ex) { System.err.println("league ratings not loaded: " + ex.getMessage()); }
        }
        league.ensure(leagueAgentId);
        if (java.nio.file.Files.isDirectory(leagueDir.resolve("snapshots"))) {
            try (var paths = java.nio.file.Files.list(leagueDir.resolve("snapshots"))) {
                for (Path path : paths.filter(f -> f.getFileName().toString().endsWith(".bin")).sorted().toList()) {
                    try {
                        PpoAgent old = PpoAgent.load(path, seed + path.getFileName().toString().hashCode());
                        String id = "snapshot:" + old.totalTicks;
                        pool.add(new FrozenPolicy(old)); poolTick.add(old.totalTicks); poolId.add(id);
                    } catch (Exception ex) { System.err.println("skipping damaged league snapshot " + path + ": " + ex.getMessage()); }
                }
            } catch (Exception ex) { System.err.println("league snapshots not loaded: " + ex.getMessage()); }
        }
        while (pool.size() > Config.LEAGUE_POOL) { pool.remove(0); poolTick.remove(0); poolId.remove(0); }
        cur.setLeagueRating(league.rating(leagueAgentId), league.games(leagueAgentId));
        cur.restart();
        cur.restore(a.stage, a.stageEnterTicks);
    }

    // ------------------------------------------------------------------ physics
    static double[] look(float yaw, float pitch) {
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        return new double[]{-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr)};
    }

    /** Ray from a's eyes along its view vs b's hitbox within vanilla reach. */
    static boolean crosshairOn(E a, E b) {
        double yr = Math.toRadians(a.yaw), pr = Math.toRadians(a.pitch);
        double dx = -Math.sin(yr) * Math.cos(pr), dy = -Math.sin(pr), dz = Math.cos(yr) * Math.cos(pr);
        double ox = a.x, oy = a.eyeY(), oz = a.z;
        double lx = b.x - 0.3, ly = b.y, lz = b.z - 0.3;
        double hx = b.x + 0.3, hy = b.y + b.height(), hz = b.z + 0.3;
        double tmin = 0, tmax = Config.ATTACK_REACH;
        if (Math.abs(dx) < 1e-9) { if (ox < lx || ox > hx) return false; }
        else {
            double t1 = (lx - ox) / dx, t2 = (hx - ox) / dx;
            tmin = Math.max(tmin, Math.min(t1, t2)); tmax = Math.min(tmax, Math.max(t1, t2));
            if (tmin > tmax) return false;
        }
        if (Math.abs(dy) < 1e-9) { if (oy < ly || oy > hy) return false; }
        else {
            double t1 = (ly - oy) / dy, t2 = (hy - oy) / dy;
            tmin = Math.max(tmin, Math.min(t1, t2)); tmax = Math.min(tmax, Math.max(t1, t2));
            if (tmin > tmax) return false;
        }
        if (Math.abs(dz) < 1e-9) { if (oz < lz || oz > hz) return false; }
        else {
            double t1 = (lz - oz) / dz, t2 = (hz - oz) / dz;
            tmin = Math.max(tmin, Math.min(t1, t2)); tmax = Math.min(tmax, Math.max(t1, t2));
            if (tmin > tmax) return false;
        }
        return true;
    }

    static double reachSq(double ex, double ey, double ez, E t) {
        double dx = Math.max(Math.max(t.x - 0.3 - ex, 0), ex - (t.x + 0.3));
        double dy = Math.max(Math.max(t.y - ey, 0), ey - (t.y + t.height()));
        double dz = Math.max(Math.max(t.z - 0.3 - ez, 0), ez - (t.z + 0.3));
        return dx * dx + dy * dy + dz * dz;
    }

    /**
     * Knockback with DESYNC. In vanilla the server computes the victim's new velocity and sends it as a packet; the victim's client applies it one
     * latency later and keeps walking in the meantime (typically INTO the attacker), which is what makes combos possible with ping. So with
     * kbDelay > 0 the velocity is computed now (a second knockback of the same hit builds on the first, like on the server) but only applied
     * kbDelay ticks later, replacing whatever the victim's own movement made of it (see timers()).
     */
    void knock(E t, E a, double str, double directionX, double directionZ) {
        str = MinecraftRules.knockbackStrength(str, t.kit);
        if (str <= 0) return;
        if (t.kbDelay <= 0) { knockNow(t, directionX, directionZ, str); return; }
        double ox = t.vx, oy = t.vy, oz = t.vz;
        if (t.kbLeft > 0) { t.vx = t.kbVx; t.vy = t.kbVy; t.vz = t.kbVz; }
        knockNow(t, directionX, directionZ, str);
        t.kbVx = t.vx; t.kbVy = t.vy; t.kbVz = t.vz;
        t.vx = ox; t.vy = oy; t.vz = oz;
        if (t.kbLeft <= 0) t.kbLeft = t.kbDelay;
    }

    void knockNow(E t, double dx, double dz, double str) {
        // LivingEntity.knockback re-rolls a nearly-zero horizontal direction until it is usable.
        while (dx * dx + dz * dz < 1.0E-5) {
            dx = (rng.nextDouble() - rng.nextDouble()) * 0.01;
            dz = (rng.nextDouble() - rng.nextDouble()) * 0.01;
        }
        Minecraft26Physics.applyKnockback(t.vx, t.vy, t.vz, dx, dz, str, t.ground, t.knockbackScratch);
        t.vx = t.knockbackScratch[0]; t.vy = t.knockbackScratch[1]; t.vz = t.knockbackScratch[2];
    }

    /** a swings and its ray hits t. Returns true if damage was dealt. */
    boolean hit(E a, E t) {
        double s = a.scale();
        boolean strong = s > 0.9;
        boolean sprintKb = a.sprint && strong;
        boolean crit = strong && a.fall > 0 && !a.ground && !a.sprint;
        a.ticker = 0;
        int r = strike(a, t, s, crit, sprintKb);
        if (r == 0) return false;
        lastCrit = crit; lastSprintKb = sprintKb && r == 2;
        return true;
    }
    boolean lastCrit, lastSprintKb;
    static final int[] DBG = new int[20];   // swing-state diagnostics for sim/com/rlpvp/SprintDiag (counters only)

    void swingAnim(E e) { e.swinging = true; e.swingT = 6; }

    void move(E e) {
        e.sprint = e.sprintKey && e.fwd > 0 && !e.sneak; // sneaking stops sprinting
        if (e.jumpDelay > 0) e.jumpDelay--; // vanilla noJumpDelay: 10 ticks between two jumps
        if (e.jump && e.ground && e.jumpDelay == 0) {
            e.jumpDelay = 10;
            e.vy = Minecraft26Physics.jumpVelocity(e.vy, JUMP_STRENGTH); // 26.3 jump uses max(jumpPower, existing vertical velocity)
            if (e.sprint) {
                // LivingEntity.jumpFromGround uses Mth's 65,536-entry float trig lookup.
                float angle = (float)e.yaw * (float)(Math.PI / 180.0);
                e.vx -= Minecraft263Trig.sin(angle) * 0.2F;
                e.vz += Minecraft263Trig.cos(angle) * 0.2F;
            }
            // vanilla: jumpFromGround does not clear onGround; the flag is updated by the movement below, so THIS tick still uses ground
            // acceleration and ground friction (0.546). That damping of the knocked-back velocity, plus the sprint boost aimed back at the attacker,
            // is what a jump reset exploits.
        }
        double zza = e.fwd * 0.98, xxa = -e.str * 0.98;
        if (e.sneak) { zza *= Minecraft26Physics.DEFAULT_SNEAKING_SPEED; xxa *= Minecraft26Physics.DEFAULT_SNEAKING_SPEED; }
        double sp = e.ground
            ? Minecraft26Physics.DEFAULT_PLAYER_GROUND_SPEED * (e.sprint ? Minecraft26Physics.DEFAULT_SPRINT_MULTIPLIER : 1.0)
            : (e.sprint ? Minecraft26Physics.DEFAULT_PLAYER_SPRINT_AIR_SPEED : Minecraft26Physics.DEFAULT_PLAYER_AIR_SPEED);
        sp = Minecraft26Physics.frictionInfluencedSpeed(sp, EFFECTIVE_BLOCK_FRICTION, e.ground);
        Minecraft26Physics.inputVector(xxa, zza, sp, e.yaw, e.motionScratch);
        e.vx += e.motionScratch[0];
        e.vz += e.motionScratch[1];
        boolean wasGround = e.ground;
        e.x += e.vx; e.z += e.vz;
        double dy = e.vy;
        e.y += dy;
        if (dy < 0 && !wasGround) e.fall += -dy;
        if (e.y <= 0) { e.y = 0; if (e.vy < 0) e.vy = 0; e.ground = true; e.fall = 0; } else e.ground = false;
        double f = Minecraft26Physics.horizontalDrag(wasGround, EFFECTIVE_BLOCK_FRICTION, AIR_DRAG_MODIFIER);
        e.vx *= f; e.vz *= f;
        e.vy = (e.vy - GRAVITY) * Minecraft26Physics.verticalDrag(AIR_DRAG_MODIFIER);
        if (e.ground) e.vy = Math.max(e.vy, -0.0784);
        if (ARENA > 0) { // walls of a round arena: stop at the wall, keep sliding along it (vanilla zeroes the velocity component that hits a block)
            double r = Math.sqrt(e.x * e.x + e.z * e.z);
            if (r > ARENA) {
                double nx = e.x / r, nz = e.z / r, vn = e.vx * nx + e.vz * nz;
                e.x = nx * ARENA; e.z = nz * ARENA;
                if (vn > 0) { e.vx -= vn * nx; e.vz -= vn * nz; }
                if (e.sprint) e.sprintKey = false; // vanilla: running into a wall ends the sprint
            }
        }
    }

    /** Radius of the round duel arena in blocks (0 = open flat ground). -Dsim.arena=N. Spawns are within ~8 blocks of the centre. */
    static final double ARENA = Double.parseDouble(System.getProperty("sim.arena", "20"));
    // Physics controls are explicit so flat-ground defaults remain compatible while ice/slime/custom-gravity tests are reproducible.
    static final double BLOCK_FRICTION = Double.parseDouble(System.getProperty("sim.blockFriction", "0.6"));
    static final double FRICTION_MODIFIER = Double.parseDouble(System.getProperty("sim.frictionModifier", "1.0"));
    static final double EFFECTIVE_BLOCK_FRICTION = Minecraft26Physics.modifiedFriction(BLOCK_FRICTION, FRICTION_MODIFIER);
    static final double AIR_DRAG_MODIFIER = Double.parseDouble(System.getProperty("sim.airDragModifier", "1.0"));
    static final double GRAVITY = Double.parseDouble(System.getProperty("sim.gravity", "0.08"));
    static final double JUMP_STRENGTH = Double.parseDouble(System.getProperty("sim.jumpStrength", "0.42"));

    void separate() {
        double dx = bot.x - me.x, dz = bot.z - me.z, d = Math.sqrt(dx * dx + dz * dz);
        if (d < 0.6 && Math.abs(bot.y - me.y) < 1.8) {
            if (d < 1e-6) { dx = 1; dz = 0; d = 1; }
            double push = (0.6 - d) / 2;
            me.x -= dx / d * push; me.z -= dz / d * push; bot.x += dx / d * push; bot.z += dz / d * push;
        }
    }

    void timers(E e) {
        e.ticker = Math.min(e.ticker + 1, 100);
        e.serverTicker = Math.min(e.serverTicker + 1, 100);
        if (e.hurtTime > 0) e.hurtTime--;
        if (e.kbLeft > 0 && --e.kbLeft == 0) { e.vx = e.kbVx; e.vy = e.kbVy; e.vz = e.kbVz; } // the knockback packet arrives; onGround stays until this tick's movement (vanilla), so a jump pressed now still executes
        if (e.kit.regenPerTick > 0 && e.hp < 20f) e.hp = (float) Math.min(20.0, e.hp + e.kit.regenPerTick);
        if (e.invul > 0) e.invul--;
        if (e.swingT > 0 && --e.swingT == 0) e.swinging = false;
    }

    // ------------------------------------------------------------------ observation (copy of Observation.frame)
    static float c(double v) { return Double.isNaN(v) ? 0f : (float) Math.max(-1.0, Math.min(1.0, v)); }
    static float ssqrt(float v) { return Math.signum(v) * (float) Math.sqrt(Math.abs(v)); }
    static double wrap(double a) { a %= 360; if (a >= 180) a -= 360; if (a < -180) a += 360; return a; }

    float[] frame(E m, E o, double[] mv, double[] ov, int sDealt, int sTaken, float[] la, int sOppSwing, int sMySwing, int lock) {
        return frameInto(m, o, mv, ov, sDealt, sTaken, la, sOppSwing, sMySwing, lock, new float[Config.FRAME]);
    }

    float[] frameInto(E m, E o, double[] mv, double[] ov, int sDealt, int sTaken, float[] la,
                      int sOppSwing, int sMySwing, int lock, float[] f) {
        java.util.Arrays.fill(f, 0f); // same zero-initialized contents as the former fresh frame
        double yr = Math.toRadians(m.yaw), fx = -Math.sin(yr), fz = Math.cos(yr), rx = -Math.cos(yr), rz = -Math.sin(yr);
        double dx = o.x - m.x, dy0 = o.y - m.y, dz = o.z - m.z, horiz = Math.sqrt(dx * dx + dz * dz), dist = Math.sqrt(horiz * horiz + dy0 * dy0);
        int i = 0;
        f[i++] = c(m.hp / 20.0);
        f[i++] = c((mv[0] * fx + mv[2] * fz) / 0.6);
        f[i++] = c((mv[0] * rx + mv[2] * rz) / 0.6);
        f[i++] = c(mv[1] / 0.8);
        f[i++] = m.ground ? 1f : 0f;
        f[i++] = m.sprint ? 1f : 0f;
        f[i++] = c(m.scale());
        f[i++] = c(m.hurtTime / 10.0);
        f[i++] = c(m.pitch / 90.0);
        f[i++] = c((dx * fx + dz * fz) / 6.0);
        f[i++] = c((dx * rx + dz * rz) / 6.0);
        f[i++] = c(dy0 / 3.0);
        f[i++] = c(dist / 6.0);
        double desiredYaw = Math.toDegrees(Math.atan2(-dx, dz));
        f[i++] = c(wrap(desiredYaw - m.yaw) / 180.0);
        double dyEye = (o.y + o.height() / 2) - m.eyeY();
        double desiredPitch = -Math.toDegrees(Math.atan2(dyEye, Math.max(horiz, 1e-6)));
        f[i++] = c((desiredPitch - m.pitch) / 90.0);
        f[i++] = c(o.hp / 20.0);
        f[i++] = c((ov[0] * fx + ov[2] * fz) / 0.6);
        f[i++] = c((ov[0] * rx + ov[2] * rz) / 0.6);
        f[i++] = c(ov[1] / 0.8);
        f[i++] = o.ground ? 1f : 0f;
        f[i++] = c(o.hurtTime / 10.0);
        double oyr = Math.toRadians(o.yaw), opr = Math.toRadians(o.pitch);
        double lk0 = -Math.sin(oyr) * Math.cos(opr), lk1 = -Math.sin(opr), lk2 = Math.cos(oyr) * Math.cos(opr);
        double facing = dist > 1e-6 ? (lk0 * -dx + lk1 * -dy0 + lk2 * -dz) / dist : 0;
        f[i++] = c(facing);
        f[i++] = o.sprint ? 1f : 0f;
        f[i++] = o.swinging ? 1f : 0f;
        f[i++] = c(sDealt / 40.0);
        f[i++] = c(sTaken / 40.0);
        f[i++] = 1f;
        for (int k = 0; k < 7; k++) f[i++] = c(la[k]);
        f[27] = 0f; f[28] = 0f;
        f[i++] = c(sOppSwing / 20.0);
        ActionMask.flags(lock, f, i);
        i += ActionMask.N_FLAGS;
        f[i++] = ssqrt(f[13]);
        f[i++] = ssqrt(f[14]);
        f[i++] = c((sOppSwing + 0.5) / o.kit.attackCooldownTicks());
        f[i++] = (!m.ground && mv[1] < 0 && !m.sprint) ? 1f : 0f;
        f[i++] = reachSq(m.x, m.eyeY(), m.z, o) <= Config.ATTACK_REACH * Config.ATTACK_REACH ? 1f : 0f;
        f[i++] = reachSq(o.x, o.eyeY(), o.z, m) <= Config.ATTACK_REACH * Config.ATTACK_REACH ? 1f : 0f;
        f[i++] = c(sMySwing / 20.0);
        double closing = horiz > 1e-6 ? ((mv[0] - ov[0]) * dx + (mv[2] - ov[2]) * dz) / horiz : 0;
        f[i++] = c(closing / 0.6);
        f[i++] = m.sneak ? 1f : 0f;                                   // 48: I am sneaking
        f[i++] = o.sneak ? 1f : 0f;                                   // 49: the enemy is sneaking (as seen through the link)
        f[i++] = (lock & ActionMask.LOCK_SNEAK) != 0 ? 1f : 0f;       // 50: my sneak head is locked
        return ObservationRegistry.apply(f);
    }

    static double[] vel(E e) { return vel(e, new double[3]); }
    static double[] vel(E e, double[] out) {
        out[0] = e.x - e.px; out[1] = e.y - e.py; out[2] = e.z - e.pz;
        return out;
    }

    // ------------------------------------------------------------------ opponent
    void botThink() {
        Curriculum.Opponent m = mode;
        if (m != Curriculum.Opponent.SELF_PLAY) bot.sneak = false; // scripted bots never sneak; a self-play rival uses its own sneak head
        if (m == Curriculum.Opponent.STATIONARY) { bot.fwd = 0; bot.str = 0; bot.sprintKey = false; bot.jump = stationaryHop(); return; }
        if (m == Curriculum.Opponent.SELF_PLAY) {
            if (policy == null) { scripted(Curriculum.Opponent.STRONG); return; }
            // the opponent is a client too: it sees ME through its own delayed link
            linkBot.otherInto(botTargetView); linkBot.selfInto(bot, botSelfView);
            E meV = botTargetView, botSelf = botSelfView;
            double[] mv = vel(bot, botVelocityScratch), ov = botRelativeVelocityScratch;
            ov[0] = meV.x - prevMeView[0]; ov[1] = meV.y - prevMeView[1]; ov[2] = meV.z - prevMeView[2];
            prevMeView[0] = meV.x; prevMeView[1] = meV.y; prevMeView[2] = meV.z;
            botSinceSwing = Math.min(botSinceSwing + 1, 40);
            boolean osw = meV.swinging, swStart = osw && !botLastOppSw;
            botSinceOppSwing = swStart ? 0 : Math.min(botSinceOppSwing + 1, 40);
            botLastOppSw = osw;
            botSinceDealt = meV.hp < botPrevViewMeHp ? 0 : Math.min(botSinceDealt + 1, 40);
            botSinceTaken = botSelf.hp < botPrevViewSelfHp ? 0 : Math.min(botSinceTaken + 1, 40);
            botPrevViewMeHp = meV.hp; botPrevViewSelfHp = botSelf.hp;
            float botDealtNow = Math.max(0f, botPrevMeHp - serverMe.hp);
            float botTakenNow = Math.max(0f, botPrevHp - serverBot.hp);
            botMem.tick(botDealtNow, botTakenNow, swStart, botPrevMask);
            botPrevMeHp = serverMe.hp; botPrevHp = serverBot.hp;
            botMem.fill(botSummary);
            botPrevMask = HitMemory.typeMask(true, !meV.ground && ov[1] < 0 && !meV.sprint, meV.sprint, meV.ground);
            float[] fr = Config.COMPACT_126
                ? frameInto(botSelf, meV, mv, ov, botSinceDealt, botSinceTaken, botLast, botSinceOppSwing, botSinceSwing, 0, botFrameScratch)
                : frame(botSelf, meV, mv, ov, botSinceDealt, botSinceTaken, botLast, botSinceOppSwing, botSinceSwing, 0);
            double botDist = Math.sqrt((meV.x - botSelf.x) * (meV.x - botSelf.x) + (meV.y - botSelf.y) * (meV.y - botSelf.y) + (meV.z - botSelf.z) * (meV.z - botSelf.z));
            botMotion.tick(fr, botLast, botDist); botMotion.fill(botSummary);
            AimGeometry.normalizedError(botSelf.x, botSelf.eyeY(), botSelf.z, botSelf.yaw, botSelf.pitch,
                meV.x - 0.3, meV.x + 0.3, meV.y, meV.y + meV.height(), meV.z - 0.3, meV.z + 0.3, botAimBoxScratch, 0);
            botCombat.tick(fr, botLast, botDist, Config.ATTACK_REACH - Math.sqrt(reachSq(botSelf.x, botSelf.eyeY(), botSelf.z, meV)),
                crosshairOn(botSelf, meV), botMem, botSinceDealt, botAimBoxScratch[0], botAimBoxScratch[1]);
            botSprintFollowup.tick(botDealtNow > 0f && botSprintHitLandedThisTick, botDealtNow > 0f,
                fr[12] * 6f, fr[16], fr[17], fr[18]);
            botSprintFollowup.fillSummary(botSummary);
            botOppMem.useCell(policy.gruCell());
            botOppMem.tick(fr, botDealtNow > 0f, botTakenNow > 0f);
            botOppMem.fillSummary(botSummary);
            botKb.tick(fr, botTakenNow > 0f, bot.jump && botPrevGroundFr && fr[4] <= 0.5f); botKb.fill(botSummary); botPrevGroundFr = fr[4] > 0.5f;
            botCombat.fillSummary(botSummary);
            float[] a = policy.act(botObs.pushReusable(fr, botSummary), 0);
            if (a[4] > 0.5f && bot.scale() >= Config.MIN_ATTACK_STRENGTH) {
                double sc = bot.scale();
                boolean onT = crosshairOn(bot, meV);
                boolean falling = !bot.ground && mv[1] < 0 && !bot.sprint;
                int botTypeMask = HitMemory.typeMask(sc >= Config.FULL_CHARGE, falling, bot.sprint, bot.ground);
                botMem.swing(botTypeMask, onT);
                botLastHitSprint = (botTypeMask & HitMemory.SPRINT) != 0;
                if (onT) {
                    botNetwork.clientToServer.send(tick, new ClientPacket(false, new AttackMessage(true)), 4);
                    bot.ticker = 0;
                }
                botSinceSwing = 0;
            }
            botCombat.noteAttack(a[4] > 0.5f, fr[20] > 0f);
            bot.yaw += (float) botDynY.step(CameraMap.apply(a[0]) * Config.YAW_SCALE, Config.YAW_SCALE);   // the bot's camera has the same dynamics as the agent's
            bot.pitch = Math.max(-90f, Math.min(90f, bot.pitch + (float) botDynP.step(CameraMap.apply(a[1]) * Config.PITCH_SCALE, Config.PITCH_SCALE)));
            if (bot.pitch <= -90f || bot.pitch >= 90f) botDynP.halt();
            bot.fwd = Math.round(a[2]) - 1;
            bot.str = StrafeAction.resolve(Math.round(a[3]), a.length > 8 && a[8] > 0.5f, bot.str);
            a[3] = StrafeAction.category(bot.str);
            bot.jump = a[5] > 0.5f; bot.sprintKey = a[6] > 0.5f && bot.fwd > 0; bot.sneak = a.length > 7 && a[7] > 0.5f;
            Observation_encode(a, botDynY.vel() / Config.YAW_SCALE, botDynP.vel() / Config.PITCH_SCALE, botLast);
            return;
        }
        scripted(m);
    }

    static void Observation_encode(float[] a, double velYaw, double velPitch, float[] out) {
        out[0] = ssqrt((float) Math.max(-1.0, Math.min(1.0, velYaw))); out[1] = ssqrt((float) Math.max(-1.0, Math.min(1.0, velPitch))); // camera VELOCITY STATE, like Observation.encodeAction
        out[2] = a[2] - 1; out[3] = a[3] - 1; out[4] = a[4]; out[5] = a[5]; out[6] = a[6]; if (out.length > 7 && a.length > 7) out[7] = a[7];
    }

    double difficultyFor(Curriculum.Opponent m) {
        double d = evalDifficulty != null ? evalDifficulty : botDiff.value();
        return m == Curriculum.Opponent.AGGRESSIVE ? 0.7 * d : d;
    }

    /** AGGRESSIVE / STRONG: the shared BotAI (lead aim, mirror strafe, pursuit, punish ...). */
    void smart(Curriculum.Opponent m) {
        if (!ai.ready()) {
            int fixed = m == Curriculum.Opponent.COMBO_PRESSURE
                ? (rng.nextBoolean() ? BotAI.PRESSURE : BotAI.WTAPPER) : leagueStyle;
            earlyStyle = -1;
            if (fixed < 0 && weaknessStyles && evalDifficulty == null && cur.stage() >= Config.STYLE_WEAKNESS_FROM_STAGE) {
                fixed = league.sampleStyle(BotAI.mixWeights(m == Curriculum.Opponent.STRONG), rng);
                earlyStyle = fixed;
            }
            ai.newEpisode(m == Curriculum.Opponent.STRONG || m == Curriculum.Opponent.COMBO_PRESSURE, difficultyFor(m), fixed);
        }
        BotAI.In s = ai.in;
        linkBot.otherInto(botTargetView); linkBot.selfInto(bot, botSelfView);
        E targetView = botTargetView, botSelf = botSelfView;
        s.bx = bot.x; s.by = bot.y; s.bz = bot.z; s.byaw = bot.yaw; s.bpitch = bot.pitch; s.eyeY = bot.eyeY(); s.bvy = bot.vy;
        s.bGround = bot.ground; s.hurtTime = botSelf.hurtTime; s.bScale = bot.scale(); s.bHp = botSelf.hp;
        s.tx = targetView.x; s.ty = targetView.y; s.tz = targetView.z; s.tScale = targetView.scale(); s.tHp = targetView.hp; s.tHurt = targetView.hurtTime;
        BotAI.Out o = ai.think(s);
        bot.yaw = o.yaw; bot.pitch = o.pitch; bot.fwd = o.fwd; bot.str = o.str; bot.sprintKey = o.sprint && o.fwd > 0; bot.jump = o.jump;
        if (o.attack) {
            boolean onTarget = crosshairOn(bot, targetView);
            swingAnim(bot);
            if (onTarget) {
                botNetwork.clientToServer.send(tick, new ClientPacket(false, new AttackMessage(true)), 4);
                bot.ticker = 0;
            }
        }
    }

    /** Stationary bot in stages 2-3: hops at the curriculum's current hop LEVEL (0 = never; see Config.BOT_HOP). A jump only happens when it stands on the ground. */
    boolean stationaryHop() {
        int st = cur.stage();
        double level = cur.hopLevel();
        if (!Config.BOT_HOP || st < Config.BOT_HOP_MIN_STAGE || st > Config.BOT_HOP_MAX_STAGE || level <= 0.0) return false;
        if (--hopCd > 0) return false;
        hopCd = (int) Math.round((Config.BOT_HOP_MIN_TICKS + rng.nextInt(Config.BOT_HOP_MAX_TICKS - Config.BOT_HOP_MIN_TICKS + 1)) / level);
        return true;
    }

    void scripted(Curriculum.Opponent m) {
        if (m == Curriculum.Opponent.COMBO_PRESSURE || (!legacyBots && (m == Curriculum.Opponent.AGGRESSIVE || m == Curriculum.Opponent.STRONG))) { smart(m); return; }
        linkBot.otherInto(botTargetView);
        E targetView = botTargetView;
        float turn = m == Curriculum.Opponent.STRONG ? Config.BOT_TURN_STRONG : m == Curriculum.Opponent.AGGRESSIVE ? Config.BOT_TURN_AGGRESSIVE : Config.BOT_TURN_WALK;
        float noise = m == Curriculum.Opponent.STRONG ? 1.5f : m == Curriculum.Opponent.AGGRESSIVE ? 2.5f : 1.0f;
        // aim at where the agent was 2 ticks ago
        if (aimHistN == 0) { for (double[] h : aimHist) { h[0] = targetView.x; h[1] = targetView.z; } aimHistN = 3; }
        else { aimHist[0] = aimHist[1]; aimHist[1] = aimHist[2]; aimHist[2] = new double[]{targetView.x, targetView.z}; }
        double sx = aimHist[0][0], sz = aimHist[0][1];
        double want = Math.toDegrees(Math.atan2(-(sx - bot.x), sz - bot.z));
        double err = wrap(want - bot.yaw);
        aimErrYaw = Math.abs(err);
        bot.yaw += (float) (Math.max(-turn, Math.min(turn, err)) + rng.nextGaussian() * noise * 0.3);
        double horiz = Math.hypot(targetView.x - bot.x, targetView.z - bot.z);
        double wantP = -Math.toDegrees(Math.atan2((targetView.y + targetView.height() / 2) - bot.eyeY(), Math.max(horiz, 1e-6)));
        bot.pitch = (float) Math.max(-90, Math.min(90, bot.pitch + Math.max(-20, Math.min(20, wantP - bot.pitch))));

        double dist = Math.sqrt((targetView.x - bot.x) * (targetView.x - bot.x) + (targetView.y - bot.y) * (targetView.y - bot.y) + (targetView.z - bot.z) * (targetView.z - bot.z));
        boolean ready = bot.scale() >= Config.MIN_ATTACK_STRENGTH;
        boolean aimed = aimErrYaw < 12.0;
        int f = bFwd;
        boolean sprint = false, jump = false, attack = false;
        if (m == Curriculum.Opponent.STRONG) {
            if (--ticksLeft <= 0) { bStr = rng.nextFloat() < 0.1f ? 0 : (rng.nextBoolean() ? -1 : 1); ticksLeft = 5 + rng.nextInt(9); }
            boolean cooling = bot.scale() < 0.6;
            if (dist > 3.2) f = 1; else if (dist < 1.9) f = -1; else f = cooling ? (rng.nextFloat() < 0.35f ? -1 : 0) : (rng.nextFloat() < 0.5f ? 1 : 0);
            if (bot.hurtTime >= 9 && bot.ground) jump = true;
            if (!critArm && bot.ground && ready && dist > 2.3 && dist < 3.8 && rng.nextFloat() < 0.04f) { jump = true; critArm = true; critTicks = 16; }
            if (critArm) {
                if (--critTicks <= 0) critArm = false;
                boolean falling = !bot.ground && bot.vy < 0;
                if (falling && dist <= Config.ATTACK_REACH && ready && aimed) { attack = true; critArm = false; }
            } else if (wtap > 0) { wtap--; f = 0; }
            else {
                sprint = f > 0 && dist > 2.2;
                if (dist <= Config.ATTACK_REACH && ready && aimed && rng.nextFloat() < 0.85f) { attack = true; wtap = 2; }
            }
        } else {
            if (--ticksLeft <= 0) {
                if (m == Curriculum.Opponent.STRAFE) { bStr = rng.nextBoolean() ? -1 : 1; bFwd = 0; ticksLeft = 8 + rng.nextInt(18); }
                else if (m == Curriculum.Opponent.WALK) { bFwd = rng.nextInt(3) - 1; bStr = rng.nextInt(3) - 1; ticksLeft = 10 + rng.nextInt(16); }
                else { bStr = rng.nextInt(3) - 1; ticksLeft = 6 + rng.nextInt(12); }
            }
            f = bFwd;
            if (m == Curriculum.Opponent.AGGRESSIVE) {
                f = dist > 2.4 ? 1 : (rng.nextFloat() < 0.15f ? -1 : 0);
                sprint = dist > 3.5; jump = rng.nextFloat() < 0.01f;
                attack = dist <= 3.1 && ready && aimed && rng.nextFloat() < 0.6f;
            } else if (m == Curriculum.Opponent.STRAFE) {
                f = dist > 4.0 ? 1 : (dist < 2.0 ? -1 : 0);
            } else {
                if (dist > 4.5) f = 1; else if (dist < 1.8) f = -1;
                if (--attackCd <= 0 && dist <= 3.1 && ready && aimed) { attack = true; attackCd = 40 + rng.nextInt(30); }
            }
        }
        bot.fwd = f; bot.str = bStr; bot.sprintKey = sprint && f > 0; bot.jump = jump;
        if (attack && m != Curriculum.Opponent.STRAFE) {
            boolean onTarget = crosshairOn(bot, targetView);
            swingAnim(bot);
            if (onTarget) {
                botNetwork.clientToServer.send(tick, new ClientPacket(false, new AttackMessage(true)), 4);
                bot.ticker = 0;
            }
        }
    }

    // ------------------------------------------------------------------ episode
    FrozenPolicy pickOld() {
        List<FrozenPolicy> ok = new ArrayList<>();
        for (int k = 0; k < pool.size(); k++) if (agent.totalTicks - poolTick.get(k) >= 50_000) ok.add(pool.get(k));
        return ok.isEmpty() ? null : ok.get(rng.nextInt(ok.size()));
    }

    void startEpisode() { startEpisodeInternal(true); }

    void startEpisodeInternal(boolean connectNetwork) {
        int st = cur.stage();
        boolean[] review = new boolean[1];
        mode = cur.sampleOpponent(rng, review); // outcome carries its own review flag, safe with a shared parallel curriculum
        reviewEp = review[0];
        policy = null;
        activeLeagueOpponentId = null;
        leagueStyle = -1;
        if (st >= 7 && mode == Curriculum.Opponent.SELF_PLAY) {
            // Stages 7–9 use PFSP across frozen snapshots and fixed, reproducible BotAI style profiles.
            List<String> candidates = new ArrayList<>();
            for (int k = 0; k < poolId.size(); k++) if (agent.totalTicks - poolTick.get(k) >= 50_000) candidates.add(poolId.get(k));
            if (rival != null) candidates.add("rival");
            for (int style = 0; style < BotAI.STYLES; style++) candidates.add("script:" + style);
            activeLeagueOpponentId = league.sample(leagueAgentId, candidates, rng, st >= Config.WEAKNESS_FROM_STAGE);
            if (activeLeagueOpponentId != null && activeLeagueOpponentId.startsWith("snapshot:")) {
                int idx = poolId.indexOf(activeLeagueOpponentId);
                if (idx >= 0 && idx < pool.size()) policy = pool.get(idx);
            } else if ("rival".equals(activeLeagueOpponentId)) policy = rival;
            else if (activeLeagueOpponentId != null && activeLeagueOpponentId.startsWith("script:")) {
                leagueStyle = Integer.parseInt(activeLeagueOpponentId.substring("script:".length()));
            }
            mode = policy != null ? Curriculum.Opponent.SELF_PLAY : Curriculum.Opponent.STRONG;
            reviewEp = false;
        } else if (mode == Curriculum.Opponent.SELF_PLAY) {
            // Early-stage cross-lineage exposure remains occasional, before PFSP formally starts at stage 7.
            double r = rng.nextDouble();
            FrozenPolicy old = pickOld();
            if (rival != null && r < 0.45) policy = rival;
            else if (old != null && r < (rival != null ? 0.60 : 0.40)) policy = old;
            else mode = r < 0.82 ? Curriculum.Opponent.STRONG : Curriculum.Opponent.AGGRESSIVE;
            if (policy != null) mode = Curriculum.Opponent.SELF_PLAY;
        } else if (mode != Curriculum.Opponent.COMBO_PRESSURE && rival != null && st >= 5 && rng.nextDouble() < 0.2) {
            policy = rival; mode = Curriculum.Opponent.SELF_PLAY;
        }
        double dist = st <= 2 ? 3.0 + rng.nextDouble() * 1.2 : st <= 4 ? 2.6 + rng.nextDouble() * 1.4 : 3.0 + rng.nextDouble() * 3.0;
        double ang = rng.nextDouble() * 6.283;
        for (E e : new E[]{me, bot}) { e.vx = e.vy = e.vz = 0; e.y = 0; e.hp = 20f; e.lastHurt = 0; e.jumpDelay = 0; e.kbLeft = 0; e.ground = true; e.sprint = false; e.sneak = false; e.swinging = false; e.ticker = 100; e.hurtTime = e.invul = 0; e.fall = 0; e.fwd = e.str = 0; e.jump = e.sprintKey = false; }
        assignKits(); // equipment for this episode (default naked = previous behaviour)
        me.x = me.z = 0; bot.x = Math.cos(ang) * dist; bot.z = Math.sin(ang) * dist;
        me.yaw = (float) (rng.nextDouble() * 360 - 180); me.pitch = (float) (rng.nextDouble() * 20 - 10);
        bot.yaw = (float) (rng.nextDouble() * 360 - 180); bot.pitch = 0;
        me.snapPrev(); bot.snapPrev();
        if (st <= 2) { // same camera pan the mod does in stages 1-2
            double dx = bot.x - me.x, dz = bot.z - me.z, horiz = Math.hypot(dx, dz);
            float wantYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            float wantPitch = (float) -Math.toDegrees(Math.atan2(0.9 - me.eyeY(), Math.max(horiz, 1e-6)));
            float yaw = wantYaw + (rng.nextBoolean() ? 1 : -1) * (30f + rng.nextFloat() * 120f);
            float pitch = st == 1 ? wantPitch : Math.max(-90f, Math.min(90f, wantPitch + (rng.nextFloat() * 2f - 1f) * 25f));
            panTicks = 15;
            panYaw = (float) wrap(yaw - me.yaw) / panTicks;
            panPitch = (pitch - me.pitch) / panTicks;
        } else panTicks = 0;
        // bot script reset
        kickCd = Config.PITCH_KICK_WARMUP + rng.nextInt(Config.PITCH_KICK_MAX_TICKS - Config.PITCH_KICK_MIN_TICKS + 1); hopCd = 6 + rng.nextInt(10); bFwd = 0; bStr = rng.nextBoolean() ? 1 : -1; ticksLeft = 0; attackCd = 20; wtap = 0; critArm = false; aimHistN = 0;
        ai.reset();
        java.util.Arrays.fill(botLast, 0f); botObs.reset(); botMotion.reset(); botCombat.reset(); botSinceSwing = botSinceOppSwing = botSinceDealt = botSinceTaken = 40; botLastOppSw = false;
        botMem.reset(); botSprintFollowup.reset(); botPrevMask = 0; botLastHitSprint = false;
        // trainer rebaseline
        comboDefense.startEpisode();
        positionReward.reset();
        pendingComboDefenseReward = 0.0;
        obs.reset(); mem.reset(); motion.reset(); combat.reset(); sprintFollowup.reset(); oppMem.reset(); botOppMem.reset(); kbT.reset(); botKb.reset(); botPrevGroundFr = true; prevOppMask = 0; tick = 0; lastHitTick = 1 << 30; creditUntil = -1; combo = 0; epAim = 0; epSoft = 0; pendingSoft = 0; pendingTech = 0; epFit = 0; epDealt = epTaken = 0;
        prevMyHp = me.hp; prevOppHp = bot.hp;
        prevDist = Math.hypot(Math.hypot(bot.x - me.x, bot.z - me.z), bot.y - me.y);
        sinceDealt = sinceTaken = 40; sinceReal = 0; sinceOppSwing = 40; sinceMySwing = 40; lastOppSw = false; firstHitDone = false;
        lastHitFull = lastHitCrit = lastHitSprint = lastHitGround = lastHitPunish = false; lastHitGap = 99;
        java.util.Arrays.fill(lastAct, 0f);
        lookYaw = lookYaw2 = lookPitch = lookPitch2 = 0f;
        for (double[] p : lookF) { p[0] = 0; p[1] = 0; }
        prevAppYaw = 0;
        dynY.reset(); dynP.reset(); botDynY.reset(); botDynP.reset(); glideV0 = glideV1 = 0.0; lastYawTurn = 0.0; lastPitchTurn = 0.0;
        cam.reset();
        techR.reset();
        relPX = distH1 = distH2 = Double.NaN; prevGroundFr = true; spam.reset(); disc.reset(); hitConsumed = true; lastHitEnemyCharge = 1f;
        mirror = mirrorOn && rng.nextBoolean();
        double hard = mirrorOn ? Math.max(0.0, Math.min(1.0, (st - 5) / 3.0)) : 0.0;
        sens = (float) (1.0 + (rng.nextDouble() - 0.4) * 0.45 * hard);
        noiseYaw = (float) (rng.nextDouble() * 0.8 * hard);
        noisePitch = (float) (rng.nextDouble() * 0.5 * hard);
        if (connectNetwork) beginLinks();
    }

    /** Evaluation can assign a stable key so opponent-habit memory persists across episodes. */
    String opponentKey = null;

    /** New per-episode client/server transport profile. fixedLag remains an old CLI in one-way ticks. */
    void beginLinks() {
        agent.resetSituationalEpisode(opponentKey != null ? opponentKey : String.valueOf(mode));
        int st = cur.stage();
        // Optional explicit latency override for controlled network training. When enabled,
        // configured RTT bounds apply from the first curriculum stage instead of waiting for stage 6.
        double ls = Boolean.getBoolean("rlpvp.latencyAlways") ? 1.25
            : st <= 5 ? 0.0 : st == 6 ? 0.4 : st == 7 ? 0.8 : 1.25;
        Double fixedRttMs = fixedLag == null ? null : fixedLag * 100.0;
        if (meNetwork != null && botNetwork != null) {
            networkRetransmissionBase += meNetwork.clientToServer.retransmissions() + meNetwork.serverToClient.retransmissions()
                + botNetwork.clientToServer.retransmissions() + botNetwork.serverToClient.retransmissions();
        }
        NetworkSimulation.Profile meProfile = NetworkSimulation.sample(rng, latency, ls, fixedRttMs);
        NetworkSimulation.Profile botProfile = NetworkSimulation.sample(rng, latency, ls, fixedRttMs);
        networkProfileCount += 2;
        networkRttSumMs += meProfile.rttMs() + botProfile.rttMs();
        networkC2sSumMs += meProfile.clientToServerMs() + botProfile.clientToServerMs();
        networkS2cSumMs += meProfile.serverToClientMs() + botProfile.serverToClientMs();
        long seed = rng.nextLong();
        meNetwork = new NetworkSimulation.Connection(meProfile, seed ^ 0x4D454E4554L);
        botNetwork = new NetworkSimulation.Connection(botProfile, seed ^ 0x424F544E4554L);
        serverMe = copy(me); serverBot = copy(bot);
        serverMe.kbDelay = serverMe.kbLeft = 0; serverBot.kbDelay = serverBot.kbLeft = 0;
        serverMeMotion.reset(serverMe); serverBotMotion.reset(serverBot);
        meSender.reset(me); botSender.reset(bot);
        linkMe.begin(serverBot, serverMe); linkBot.begin(serverMe, serverBot);
        meSnapshotSender.reset(serverBot, serverMe);
        botSnapshotSender.reset(serverMe, serverBot);
        linkMe.ease = linkBot.ease = ease;
        botHitLanded = false;
        prevBotView[0] = bot.x; prevBotView[1] = bot.y; prevBotView[2] = bot.z;
        prevMeView[0] = me.x; prevMeView[1] = me.y; prevMeView[2] = me.z;
        prevViewOppHp = serverBot.hp; prevViewMyHp = serverMe.hp;
        botPrevViewMeHp = serverMe.hp; botPrevViewSelfHp = serverBot.hp;
        botPrevMeHp = serverMe.hp; botPrevHp = serverBot.hp;
        prevMyHp = serverMe.hp; prevOppHp = serverBot.hp;
        // Network counters intentionally accumulate across episodes for the training telemetry.
    }

    /** One client tick. @param train true = sample + learn; false = greedy. @return true while the episode continues. */
    boolean step(boolean train, EvalStats ev) {
        tick++;
        telemetryEnabled = train;
        myCritHitLandedThisTick = false;
        mySprintHitLandedThisTick = false;
        botSprintHitLandedThisTick = false;
        sinceMySwing = Math.min(sinceMySwing + 1, 40);
        linkMe.ease = linkBot.ease = ease;
        // Server thread: process arrived TCP packets against authoritative player replicas.
        processServerPackets();
        receiveClientboundPackets();
        linkMe.otherInto(playerTargetView); linkMe.selfInto(me, playerSelfView);
        E botV = playerTargetView, meSelf = playerSelfView;
        double[] mv = vel(me, meVelocityScratch), ov = playerRelativeVelocityScratch;
        ov[0] = botV.x - prevBotView[0]; ov[1] = botV.y - prevBotView[1]; ov[2] = botV.z - prevBotView[2];
        prevBotView[0] = botV.x; prevBotView[1] = botV.y; prevBotView[2] = botV.z;
        me.snapPrev(); bot.snapPrev();
        float myHp = serverMe.hp, oppHp = serverBot.hp;
        boolean credited = tick >= lastHitTick && tick <= creditUntil;
        float myHpC = Math.max(0f, myHp), oppHpC = Math.max(0f, oppHp); // exclude overkill from damage metrics
        float realDealt = credited ? Math.max(0f, prevOppHp - oppHpC) : 0f;
        float softCreditNow = pendingSoft;
        float dealt = disc.rewardDamage(realDealt, lastHitCrit, lastHitEnemyCharge) + softCreditNow; // soft credit may shape reward but is not actual damage
        pendingSoft = 0f;
        float taken = Math.max(0f, prevMyHp - myHpC);
        // Track incoming server-confirmed hit chains separately from the legacy offensive combo counter.
        // Count sideways displacement only while the previous action was actually holding A/D.
        double yawRad = Math.toRadians(me.yaw);
        double lateralSpeed = Math.abs(mv[0] * Math.cos(yawRad) + mv[2] * Math.sin(yawRad));
        int defenseEvent = comboDefense.tick(taken > 0f, lateralSpeed, me.str != 0);
        if ((defenseEvent & ComboDefenseTracker.CHAIN_COMPLETED) != 0) {
            wIncomingCombos++;
            if ((defenseEvent & ComboDefenseTracker.STRAFE_ESCAPE) != 0) {
                wStrafeComboEscapes++;
                if (train) pendingComboDefenseReward = Config.COMBO_ESCAPE_REWARD;
            }
        }
        prevMyHp = myHpC; prevOppHp = oppHpC;
        sinceReal = realDealt > 0 ? 0 : sinceReal + 1;
        epDealt += realDealt; epTaken += taken; // probes, evaluation and guard use real HP damage only
        boolean newHitEvent = realDealt > 0 && !hitConsumed;
        if (newHitEvent && train) rewardTelemetry.noteClientLabelledHit(lastHitCrit, lastHitSprint, realDealt);
        if (realDealt > 0) hitConsumed = true;
        // observation timers come from what the client can SEE (delayed hp), rewards from the true server events
        sinceDealt = botV.hp < prevViewOppHp ? 0 : Math.min(sinceDealt + 1, 40);
        sinceTaken = meSelf.hp < prevViewMyHp ? 0 : Math.min(sinceTaken + 1, 40);
        prevViewOppHp = botV.hp; prevViewMyHp = meSelf.hp;
        boolean osw = botV.swinging, oppSwingStart = osw && !lastOppSw;
        sinceOppSwing = oppSwingStart ? 0 : Math.min(sinceOppSwing + 1, 40);
        lastOppSw = osw;
        mem.tick(realDealt, taken, oppSwingStart, prevOppMask);
        mem.fill(summary);
        prevOppMask = HitMemory.typeMask(true, !botV.ground && ov[1] < 0 && !botV.sprint, botV.sprint, botV.ground);
        if (taken > 0) { combo = 0; firstHitDone = true; }
        boolean firstHit = false;
        boolean resetGap = lastHitGap >= Config.RESET_GAP_MIN && lastHitGap <= Config.RESET_GAP_MAX;
        boolean tapOk = !Config.GROUNDED_TAP_ONLY || lastHitGround;   // w-tap / s-tap style bonuses need a grounded swing
        if (realDealt > 0) { combo++; firstHit = !firstHitDone; firstHitDone = true; wHits++;
            if (myCritHitLandedThisTick) wCrit++; if (mySprintHitLandedThisTick) wSprint++;
            if (ev != null) { ev.hits++; if (myCritHitLandedThisTick) ev.crits++; if (mySprintHitLandedThisTick) ev.sprintHits++; if (lastHitFull) ev.fullHits++; if (resetGap) ev.resetHits++; if (lastHitPunish) ev.punishHits++; } }
        double techW = cur.weights().tech;
        double tech = pendingTech + Reward.techBonus(realDealt > 0, lastHitCrit, lastHitSprint && tapOk, combo, firstHit, false, techW, lastHitFull, resetGap && tapOk, lastHitPunish, cur.weights().late);
        pendingTech = 0;

        float[] fr = Config.COMPACT_126
            ? frameInto(meSelf, botV, mv, ov, sinceDealt, sinceTaken, lastAct, sinceOppSwing, sinceMySwing, train ? cur.lockMask() : evalLock, playerFrameScratch)
            : frame(meSelf, botV, mv, ov, sinceDealt, sinceTaken, lastAct, sinceOppSwing, sinceMySwing, train ? cur.lockMask() : evalLock);
        if (mirror) { fr[2] = -fr[2]; fr[10] = -fr[10]; fr[13] = -fr[13]; fr[17] = -fr[17]; fr[40] = -fr[40]; } // world-derived left/right inputs (lastAct is already in the agent's own space)
        double dist = Math.sqrt((botV.x - me.x) * (botV.x - me.x) + (botV.y - me.y) * (botV.y - me.y) + (botV.z - me.z) * (botV.z - me.z));
        motion.tick(fr, lastAct, dist, lastYawTurn, lastPitchTurn);
        motion.fill(summary);
        AimGeometry.normalizedError(meSelf.x, meSelf.eyeY(), meSelf.z, meSelf.yaw, meSelf.pitch,
            botV.x - 0.3, botV.x + 0.3, botV.y, botV.y + botV.height(), botV.z - 0.3, botV.z + 0.3, aimBoxScratch, 0);
        if (mirror) aimBoxScratch[0] = -aimBoxScratch[0];
        combat.tick(fr, lastAct, dist, Config.ATTACK_REACH - Math.sqrt(reachSq(meSelf.x, meSelf.eyeY(), meSelf.z, botV)),
            crosshairOn(meSelf, botV), mem, sinceDealt, aimBoxScratch[0], aimBoxScratch[1]);
        int followupEvent = sprintFollowup.tick(realDealt > 0f && mySprintHitLandedThisTick, realDealt > 0f,
            fr[12] * 6f, fr[16], fr[17], fr[18]);
        if ((followupEvent & SprintHitFollowupMemory.SPRINT_HIT) != 0) {
            if (ev != null) ev.sprintFollowupOpps++; else if (train) wSprintFollowupOpps++;
        }
        if ((followupEvent & SprintHitFollowupMemory.FOLLOWUP_HIT) != 0) {
            if (ev != null) { ev.sprintFollowups++; ev.sprintFollowupTicks += sprintFollowup.lastFollowupTicks(); }
            else if (train) { wSprintFollowups++; wSprintFollowupTicks += sprintFollowup.lastFollowupTicks(); }
        }
        if ((followupEvent & SprintHitFollowupMemory.EXPIRED) != 0) {
            if (ev != null) ev.sprintFollowupExpired++; else if (train) wSprintFollowupExpired++;
        }
        sprintFollowup.fillSummary(summary);
        oppMem.useCell(agent.gruCell());
        oppMem.tick(fr, realDealt > 0f, taken > 0f);
        agent.noteMemory(oppMem.hBefore(), oppMem.x());
        oppMem.fillSummary(summary);
        kbT.tick(fr, taken > 0f, me.jump && prevGroundFr && fr[4] <= 0.5f); kbT.fill(summary);
        combat.fillSummary(summary);
        double yawErr = Math.abs(fr[13]), pitchErr = Math.abs(fr[14]);
        long learned = agent.totalTicks;
        double dmgScale = Reward.damageScale(disc.typicalHit());
        double reward = Reward.tick(dealt, taken, dist, prevDist, yawErr, pitchErr, train ? Reward.shaping(learned) : 0.0, cur.pitchRamp(learned), cur.weights(),
            Reward.idleScale(cur.stage(), sinceReal), me.scale(), tech, (myHp - oppHp) / 20.0,
            dmgScale, Reward.denseScale(episodeTicks), train ? rewardBreakdown : null);
        reward += pendingComboDefenseReward;
        if (pendingComboDefenseReward > 0.0) rewardTelemetry.addOther(pendingComboDefenseReward);
        pendingComboDefenseReward = 0.0;
        if (train) { // v7.38c: spacing band, look-away, combo-break, consecutive-hit and airborne-hit terms (stage >= CombatPositionReward.MIN_STAGE)
            if (realDealt > 0f) positionReward.noteHitType(lastHitFull, lastHitCrit, lastHitSprint, lastHitGround);
            double positionR = positionReward.tick(cur.stage(), dist, yawErr * 180.0, taken > 0f, !serverMe.ground, realDealt > 0f, mySprintHitLandedThisTick);
            reward += positionR; rewardTelemetry.addPositionReward(positionReward.lastTerms());
        }
        if (train) {
            double softReward = Math.max(0.0, softCreditNow) * Config.W_DAMAGE * dmgScale * RewardTuning.get("damage") / 20.0;
            rewardTelemetry.addBase(rewardBreakdown, softReward);
            double crx = me.x - bot.x, crz = me.z - bot.z;
            double orbitReward = !Double.isNaN(relPX) ? Reward.orbit(relPX, relPZ, crx, crz, yawErr * 180.0, dist, taken > 0f, cur.weights().orbit, Reward.denseScale(episodeTicks)) : 0.0;
            reward += orbitReward; rewardTelemetry.addOrbit(orbitReward);
            relPX = crx; relPZ = crz;
            rewardTelemetry.noteSprintLaneOpportunity(Reward.sprintLaneEligible(me.scale(), dist, yawErr * 180.0, me.sprint && me.fwd > 0, cur.weights().late));
        }
        final double distBefore = prevDist;
        prevDist = dist;
        boolean pitchFree = !ActionMask.pitchLocked(train ? cur.lockMask() : evalLock);
        if (train) { double cameraReward = cam.tick(fr[13] * 180.0, fr[14] * 90.0, pitchFree, fr[43] > 0.5f, fr[44] > 0.5f, me.scale(), cur.stage()); reward += cameraReward; rewardTelemetry.addCamera(cameraReward); rewardTelemetry.addCameraTerms(cam.lastTerms); }
        if (train) { // telemetry-compatible hook; intrinsic technique reward is disabled by default
            TechniqueReward.In t = techIn;
            t.lockMask = cur.lockMask(); t.stage = cur.stage(); t.techW = techW; t.idle = Reward.idleScale(cur.stage(), sinceReal);
            t.dist = dist; t.prevDist = distBefore; t.yawErrDeg = yawErr * 180.0;
            t.myCharge = fr[6]; t.myHp01 = fr[0]; t.oppHp01 = fr[15]; t.myRight = fr[2] * 0.6; t.myFwd = fr[1] * 0.6;
            t.myGround = fr[4] > 0.5f; t.canCrit = fr[43] > 0.5f; t.enemyFacing = fr[21]; t.enemyCharge = fr[42];
            t.inMyReach = fr[44] > 0.5f; t.inTheirReach = fr[45] > 0.5f; t.oppSwingStart = oppSwingStart;
            t.realDealt = realDealt; t.taken = taken; t.hitSprint = lastHitSprint && tapOk; t.hitCrit = lastHitCrit;
            t.prevStrafe = Math.round(lastAct[3]); t.prevFwd = Math.round(lastAct[2]); t.prevSprint = lastAct[6] > 0.5f;
            double techniqueReward = techR.tick(t); reward += techniqueReward; rewardTelemetry.addOther(techniqueReward);
        }
        if (train) {
            if (techW > 0) agent.techTicks++;
            TechniqueDiscovery.In d = discIn;
            d.techW = techW; d.techTicks = agent.techTicks; d.tick = tick;
            d.realDealt = realDealt; d.taken = taken; d.newHit = newHitEvent;
            d.hitCrit = myCritHitLandedThisTick; d.hitSprint = mySprintHitLandedThisTick; d.hitGrounded = lastHitGround; d.hitDist = lastHitDist; d.hpLead = (myHp - oppHp) / 20.0; d.hitPunish = lastHitPunish; d.hitEnemyCharge = lastHitEnemyCharge;
            d.oppSwingStart = oppSwingStart; d.inTheirReach = fr[45] > 0.5f; d.enemyFacing = fr[21];
            d.mySpeed = Math.hypot(fr[1], fr[2]) * 0.6;
            d.dist = dist;
            d.fwd = Math.round(lastAct[2]) - 1; d.sprintKey = lastAct[6] > 0.5f;
            d.airborne = !me.ground; d.airW = cur.weights().airPen; d.lateW = cur.weights().late;
            d.sepRate = Double.isNaN(distH2) ? 0.0 : distH1 - distH2;
            d.jumpStart = me.jump && prevGroundFr && fr[4] <= 0.5f;   // jump chosen on the ground last tick and I am airborne now (jump reset timing)
            if (d.jumpStart) rewardTelemetry.noteJumpStart();   // was never recorded in the simulator: audit CSV showed jump commands but 0 starts
            double discoveryReward = disc.tick(d); reward += discoveryReward; rewardTelemetry.addDiscovery(discoveryReward);
            distH2 = distH1; distH1 = dist;
            SpamGuard.In sp = spamIn;      // me.jump / me.sneak still hold the PREVIOUS tick's applied action here
            int locks = cur.lockMask();
            sp.jumpFree = (locks & ActionMask.LOCK_JUMP) == 0; sp.sneakFree = (locks & ActionMask.LOCK_SNEAK) == 0;
            sp.jumpPressed = me.jump; sp.onGround = prevGroundFr; sp.tookHit = taken > 0f; sp.sneaking = me.sneak; sp.realHit = realDealt > 0;
            sp.moveFree = (locks & ActionMask.LOCK_MOVEMENT) != ActionMask.LOCK_MOVEMENT;
            sp.sprintFree = (locks & ActionMask.LOCK_SPRINT) == 0;
            sp.fwd = Math.round(lastAct[2]) - 1; sp.str = Math.round(lastAct[3]) - 1;
            sp.sprintKey = lastAct[6] > 0.5f; sp.speed = Math.hypot(me.vx, me.vz);
            double spamReward = spam.tick(sp); reward += spamReward;
            rewardTelemetry.addJumpGuard(spam.lastJumpReward());
            rewardTelemetry.addMovementGuard(spam.lastMovementReward());
            rewardTelemetry.addOther(spam.lastOtherReward());
            prevGroundFr = fr[4] > 0.5f;   // the ground state the NEXT action is chosen from
        }
        if (yawErr * 180.0 <= Config.ON_TARGET_DEG && (!pitchFree || pitchErr * 90.0 <= Config.ON_TARGET_DEG)) epAim++;
        epFit += reward;
        if (train) agent.addReward(reward);

        boolean oppDead = serverBot.hp <= 0f, meDead = serverMe.hp <= 0f, timeout = tick >= episodeTicks;
        float[] input = obs.pushReusable(fr, summary);
        if (oppDead || meDead || timeout) {
            endEpisode(train, EpisodeOutcome.classify(meDead, oppDead, oppDead && credited, timeout), input, ev);
            return false;
        }

        agent.setMask(ActionMask.withAttackGate(train ? cur.lockMask() : evalLock, dist, fr[13] * 180.0, fr[14] * 90.0));
        float[] a = hand != null ? hand.apply(fr) : train ? agent.actTrain(input) : strictGreedy ? agent.actGreedy(input) : agent.actPlay(input);
        if (actionTap != null && !train && hand == null) a = actionTap.apply(input, a);
        if (train) entropyEma = entropyEma == 0 ? (float) agent.lastEntropy() : 0.98f * entropyEma + 0.02f * (float) agent.lastEntropy();
        // camera: policy output is hand effort; physical mouse dynamics convert it to relative displacement in the AGENT's own space
        double cmdY = lookFilter(CameraMap.apply(a[0]) * Config.YAW_SCALE * sens + (noiseYaw > 0 ? rng.nextGaussian() * noiseYaw : 0.0), 0);
        double cmdP = lookFilter(CameraMap.apply(a[1]) * Config.PITCH_SCALE * sens + (noisePitch > 0 ? rng.nextGaussian() * noisePitch : 0.0), 1);
        // errors are the agent's own observed yaw/pitch error (frame features 13 / 14), in its own space; brake + dynamics + pitch stop in GameplayRotation
        rotA.stepEffort(cmdY, cmdP, 0f, me.pitch, fr[13] * 180.0, fr[14] * 90.0, true, pitchFree, aimBrake && hand == null);
        double ay = rotA.dYaw;      // degrees turned this tick (agent space)
        glideV0 = glideV1; glideV1 = rotA.yaw.vel(); // next segment starts at the previous end speed (GlideCamera.push)
        lastYawTurn = ay;
        double apitch = rotA.dPitch;
        lastPitchTurn = apitch;
        double vY = dynY.vel(), vP = dynP.vel();
        if (ev != null) { ev.accAbs += Math.abs(dynY.acc()); ev.jerkAbs += Math.abs(dynY.lastJerk()); ev.accPeak = Math.max(ev.accPeak, Math.abs(dynY.acc())); ev.jerkPeak = Math.max(ev.jerkPeak, Math.abs(dynY.lastJerk())); ev.velAbs += Math.abs(vY); ev.nD++; }
        if (train) { wLook += Math.abs(ay); wLookN++; }
        if (ev != null) { ev.look += Math.abs(ay); ev.n++; if (yawErr * 180 < 5) { ev.lookOn += Math.abs(ay); ev.nOn++; } if (Math.abs(ay) > 20) ev.big++;
            if (yawErr * 180 < 5) { double c0 = vY / Config.YAW_SCALE; ev.jerk += Math.abs(c0 - lookYaw) * Config.YAW_SCALE; ev.nJ++; if (c0 * lookYaw < 0 && Math.abs(c0) > 0.04 && Math.abs(lookYaw) > 0.04) ev.flip++; }
            ev.ticks++; ev.distSum += dist; if (Math.round(a[3]) != 1) ev.strafeT++; if (Math.round(a[2]) == 0) ev.backT++; if (a[6] == 1 && Math.round(a[2]) == 2) ev.sprintT++; if (a[5] == 1 && me.ground) ev.jumpT++; }

        boolean wasSprint = me.sprint;
        boolean fallingCrit = !me.ground && mv[1] < 0 && !wasSprint;
        float chargeNow = (float) me.scale();
        if (train) techniqueOpportunityAudit.observeDecision((agent.mask() & ActionMask.LOCK_ATTACK) == 0,
            fr[26] > 0.5f, fr[44] > 0.5f, chargeNow, fr[43] > 0.5f,
            wasSprint, dist, yawErr * 180.0, pitchErr * 90.0, a[4] > 0.5f);
        int gap = sinceMySwing, oppAge = sinceOppSwing;
        // the same gate the mod's Trainer applies (a first version of the evaluation always used the relaxed 0.5 gate, which the agent was never trained for)
        float minCharge = cur.stage() >= Config.GATE_RELAX_STAGE ? Config.MIN_ATTACK_STRENGTH_LATE : Config.MIN_ATTACK_STRENGTH;
        int swing = 0; // 0 none, 1 hit, 2 miss
        if (a[4] == 1 && me.scale() >= minCharge) {
            if (train) rewardTelemetry.noteSwing(me.ground, mv[1], chargeNow >= Config.FULL_CHARGE, wasSprint);
            // the click is decided on the client's (delayed) picture of the enemy, then travels to the server
            double sc = me.scale();
            boolean onT = crosshairOn(me, botV);
            swing = onT ? 1 : 2;
            int mask = HitMemory.typeMask(chargeNow >= Config.FULL_CHARGE, fallingCrit, wasSprint, me.ground);
            if (train) {
                // Match the simulator server's strict > FULL_CHARGE check without changing the
                // existing policy/memory label used by the rest of the training pipeline.
                int auditMask = HitMemory.typeMask(chargeNow > Config.FULL_CHARGE, fallingCrit, wasSprint, me.ground);
                techniqueOpportunityAudit.recordSwing(auditMask, onT);
            }
            { int[] D = DBG; D[0]++;
              boolean wantSprint = a[6] == 1 && Math.round(a[2]) == 2;
              if (wasSprint) D[1]++; else if (fallingCrit) D[2]++; else {
                D[3]++;
                if (me.fwd <= 0) D[4]++; else if (!me.sprintKey) D[5]++; else D[6]++;
                if (!me.ground) D[7]++;
                if (wantSprint) D[8]++;
                if (dist < 2.0) D[9]++;
                if (sinceTaken < 8) D[10]++;
                if (me.fwd > 0 && me.sprintKey && me.ground) D[11]++;
              }
              if (!wasSprint && wantSprint) D[12]++;
              if (a[5] == 1) D[13]++;
              if (me.fwd < 0) D[14]++;
            }
            if (onT) meNetwork.clientToServer.send(tick, new ClientPacket(true, new AttackMessage(true)), 4);
            swingAnim(me); // local swing animation is immediate; an entity attack packet is sent only when the client selected a target
            if (onT) me.ticker = 0;
            sinceMySwing = 0; wSwing++;
            mem.swing(mask, onT);
            if (train) pendingTech += techR.onSwing(onT, techW);
            if (train) pendingTech += disc.onSwing(onT, tick, techW);
            if (ev != null) { ev.swings++; if (!onT) { ev.whiffs++; if (dist > Config.WHIFF_FAR_DIST) ev.whiffFar++; else if (yawErr > Config.WHIFF_OFFAIM_YAW || pitchErr > Config.WHIFF_OFFAIM_PITCH) ev.whiffOff++; else ev.whiffNear++; } if (me.scale() < 1.0) ev.partial++; }
            if (onT) {
                lastHitTick = tick; creditUntil = tick + meNetwork.profile.clientToServerTicks() + Config.HIT_CREDIT_TICKS;
                hitConsumed = false;
                lastHitEnemyCharge = fr[42];
                lastHitCrit = (mask & HitMemory.CRIT) != 0; lastHitSprint = (mask & HitMemory.SPRINT) != 0; lastHitGround = me.ground; lastHitDist = dist;
                lastHitFull = chargeNow >= Config.FULL_CHARGE; lastHitGap = gap; lastHitPunish = oppAge <= Config.PUNISH_WINDOW_TICKS;
            }
        }
        if (swing == 2) {
            wWhiff++;
            if (train) pendingTech -= Config.MISS_COST;
            if (train && Reward.isPointlessWhiff(dist, yawErr, pitchErr)) pendingTech += Reward.techBonus(false, false, false, 0, false, true, techW * disc.kitScale());
            if (train && dist <= Config.SOFT_HIT_REACH && yawErr <= Config.SOFT_YAW_ERR && pitchErr <= Config.SOFT_PITCH_ERR && cur.stage() <= Config.SOFT_MAX_STAGE && epSoft < Reward.softCapHp(disc.typicalHit())) {
                pendingSoft = Reward.softHp(disc.typicalHit()); epSoft += pendingSoft;
            }
        }
        combat.noteAttack(a[4] > 0.5f, fr[20] > 0f);
        // keys + look (pan from the stage 1-2 start is applied on top, like the mod)
        me.fwd = Math.round(a[2]) - 1;
        int previousAgentStrafe = mirror ? -me.str : me.str;
        me.str = StrafeAction.resolve(Math.round(a[3]), a.length > 8 && a[8] > 0.5f, previousAgentStrafe);
        a[3] = StrafeAction.category(me.str); // action-history features describe the input actually held
        me.jump = a[5] == 1; me.sprintKey = a[6] == 1 && me.fwd > 0; me.sneak = a.length > 7 && a[7] == 1;
        if (train) rewardTelemetry.noteAction(me.jump);
        if (ev != null) { if (me.str > 0) ev.strafeR++; else if (me.str < 0) ev.strafeL++; }
        if (mirror) { me.str = -me.str; ay = -ay; }
        if (ev != null) { ev.appJerk += Math.abs(ay - prevAppYaw); ev.nA++; }
        prevAppYaw = ay;
        me.yaw += (float) ay;
        me.pitch = Math.max(-90f, Math.min(90f, me.pitch + (float) apitch));
        if (me.pitch <= -90f || me.pitch >= 90f) dynP.halt();
        if (Config.PITCH_KICK && panTicks == 0 && cur.stage() == Config.PITCH_KICK_STAGE && mode == Curriculum.Opponent.STATIONARY && tick >= Config.PITCH_KICK_WARMUP && --kickCd <= 0) {
            double lvl = Math.max(0.0, Math.min(1.0, cur.hopLevel()));
            float amp = (float) (Config.PITCH_KICK_MIN_DEG + Config.PITCH_KICK_RANGE_DEG * lvl);
            panTicks = 4; panYaw = 0f; panPitch = (rng.nextBoolean() ? 1f : -1f) * (0.4f + 0.6f * rng.nextFloat()) * amp / panTicks;
            kickCd = Config.PITCH_KICK_MIN_TICKS + rng.nextInt(Config.PITCH_KICK_MAX_TICKS - Config.PITCH_KICK_MIN_TICKS + 1);
        }
        if (panTicks > 0) { panTicks--; me.yaw += panYaw; me.pitch = Math.max(-90f, Math.min(90f, me.pitch + panPitch)); }
        Observation_encode(a, vY / Config.YAW_SCALE, vP / Config.PITCH_SCALE, lastAct);   // velocity STATE (agent space, before the mirror)
        lookYaw2 = lookYaw; lookYaw = (float) (vY / Config.YAW_SCALE);
        lookPitch2 = lookPitch; lookPitch = (float) (vP / Config.PITCH_SCALE);
        cam.onAction((float) (vY / Config.YAW_SCALE), (float) (vP / Config.PITCH_SCALE));

        // Both clients predict their own movement locally. Position/rotation and state changes are
        // serialized onto their client->server TCP streams after the prediction step.
        botThink();
        move(me); move(bot); separate();
        sendClientMovement(me, meNetwork, meSender, true);
        sendClientTickEnd(meNetwork, true);
        sendClientMovement(bot, botNetwork, botSender, false);
        sendClientTickEnd(botNetwork, false);
        timers(me); timers(bot); timers(serverMe); timers(serverBot);
        serverMeMotion.finishServerTick(serverMe); serverBotMotion.finishServerTick(serverBot);
        sendServerSnapshots();
        return true;
    }

    void endEpisode(boolean train, EpisodeOutcome outcome, float[] input, EvalStats ev) {
        lastOutcome = outcome;
        double terminal = Reward.terminal(outcome);
        epFit += terminal;
        boolean win = outcome.win(), loss = outcome.loss();
        boolean decided = !outcome.noContest();
        if (ev != null) {
            ev.eps++;
            if (win) ev.wins++;
            if (loss) ev.losses++;
            if (outcome.draw()) ev.draws++;
            if (outcome.noContest()) ev.noContest++;
            ev.dealt += epDealt;
            ev.taken += epTaken;
        }
        if (!train) return;
        techniqueOpportunityAudit.finishEpisode();
        if (activeLeagueOpponentId != null && decided) {
            double score = win ? 1.0 : loss ? 0.0 : 0.5;
            league.result(leagueAgentId, activeLeagueOpponentId, score, epDealt, epTaken);
            cur.setLeagueRating(league.rating(leagueAgentId), league.games(leagueAgentId));
        } else if (earlyStyle >= 0 && decided) {
            league.styleResult(earlyStyle, win ? 1.0 : loss ? 0.0 : 0.5, epDealt, epTaken);
        }
        earlyStyle = -1;
        double settled = disc.endEpisode();
        epFit += settled;
        rewardTelemetry.addTerminal(terminal);
        rewardTelemetry.addDiscovery(settled);
        agent.addReward(terminal + settled);
        if (decided) {
            boolean onTarget = cur.aimSuccess(epAim, tick);
            boolean success = win || Config.leadDecision(outcome == EpisodeOutcome.TIMEOUT, epDealt, epTaken) || (cur.stage() <= Config.AIM_GATE_MAX_STAGE && onTarget);
            cur.reportEpisode(success, reviewEp);
            if ((win || loss) && (mode == Curriculum.Opponent.AGGRESSIVE || mode == Curriculum.Opponent.STRONG)) botDiff.report(win);
        }
        agent.endEpisode(outcome.terminal(), input);
        wEp++; if (win) wWin++; if (loss) wLoss++;
        if (outcome.draw()) wDraw++;
        if (outcome.noContest()) wNoContest++;
        wDealt += epDealt; wTaken += epTaken; wRet += epFit;
        if (!probeGuard && decided && guard.addEpisode(mode != Curriculum.Opponent.SELF_PLAY && !reviewEp,
                win, loss, epDealt, epTaken, cur.stage(), agent)) {
            System.out.println("  ! collapse guard: rolled back to the best weights of stage " + cur.stage() + " (#" + guard.rollbacks + ")");
        }
    }

    /** Cascaded one-pole camera filter (Config.LOOK_SMOOTH); axis 0 = yaw, 1 = pitch. */
    private double lookFilter(double in, int axis) {
        if (lookAlpha >= 0.999) return in;
        double x = in;
        for (double[] p : lookF) { p[axis] += lookAlpha * (x - p[axis]); x = p[axis]; }
        return x;
    }

    static final class EvalStats { double accAbs, jerkAbs, accPeak, jerkPeak, velAbs; int nD; double appJerk; int nA; int whiffFar, whiffOff, whiffNear, partial, strafeR, strafeL, eps, wins, losses, draws, noContest, hits, crits, sprintHits, fullHits, resetHits, punishHits, swings, whiffs, ticks, sprintFollowupOpps, sprintFollowups, sprintFollowupExpired, sprintFollowupTicks, strafeT, backT, sprintT, jumpT, n, nOn, big, nJ, flip; double jerk, distSum; double dealt, taken, look, lookOn; }

    void syncCurriculum() {
        long ticks = agent.totalTicks;
        if (cur.update(ticks)) lastStageMsg = "-> stage " + cur.stage() + " (" + Curriculum.opponentFor(cur.stage()).label + ") at tick " + ticks;
        guard.noteStage(cur.stage(), agent);
        cur.setLeagueRating(league.rating(leagueAgentId), league.games(leagueAgentId));
        agent.setMask(cur.lockMask());
        agent.stage = cur.autoStage();
        agent.stageEnterTicks = cur.stageEnterTicks();
        float coef = Config.ENTROPY_COEF * cur.entropyScale(ticks);
        double floor = Config.ENTROPY_FLOOR_FRAC * PpoAgent.maxEntropy(cur.lockMask());
        if (entropyEma > 0 && entropyEma < floor) coef *= Config.ENTROPY_FLOOR_BOOST;
        coef *= Config.stageEntropyScale(cur.stage(), ticks, cur.stageEnterTicks());
        agent.setEntropyCoef(coef);
        if (cur.opponent() == Curriculum.Opponent.SELF_PLAY && (pool.isEmpty() || ticks - lastSnap >= Config.SELF_PLAY_SNAPSHOT_TICKS)) {
            String id = "snapshot:" + ticks;
            pool.add(new FrozenPolicy(agent)); poolTick.add(ticks); poolId.add(id);
            // Multiple environments can reach this point on the same learner tick. Register the league row once,
            // and let only the designated owner touch disk. This prevents stale ledgers and colliding *.tmp files.
            league.snapshotIfAbsent(id, leagueAgentId);
            if (leaguePersistenceOwner) {
                Path snapshotPath = leagueDir.resolve("snapshots").resolve("snapshot-" + ticks + ".bin");
                try { java.nio.file.Files.createDirectories(snapshotPath.getParent()); agent.save(snapshotPath); }
                catch (Exception ex) { System.err.println("could not save league snapshot " + snapshotPath + ": " + ex.getMessage()); }
            }
            while (pool.size() > Config.LEAGUE_POOL) {
                pool.remove(0); poolTick.remove(0); String oldId = poolId.remove(0);
                if (leaguePersistenceOwner) {
                    try { java.nio.file.Files.deleteIfExists(leagueDir.resolve("snapshots").resolve(oldId.substring("snapshot:".length()) + ".bin")); }
                    catch (Exception ignored) { }
                }
            }
            if (leaguePersistenceOwner) {
                try { league.save(leagueFile); }
                catch (Exception ex) { System.err.println("could not save league ratings: " + ex.getMessage()); }
            }
            lastSnap = ticks;
        }
    }

    // ------------------------------------------------------------------ driver
    /**
     * Probe of the PLAYED policy (play mode) at the current stage. Feeds the stage gate (greedyOk) and the collapse guard: sampled training
     * stats can look healthy while the policy that ships does not fight.
     */
    void probe() {
        int stage = cur.stage();
        Curriculum.Opponent o = Curriculum.opponentFor(stage);
        if (o == Curriculum.Opponent.SELF_PLAY) o = Curriculum.Opponent.STRONG;
        evalLock = cur.lockMask();
        int hits = 0, wins = 0, draws = 0, noContests = 0, validEpisodes = 0, n = Config.GREEDY_PROBE_EPISODES;
        double dealt = 0, taken = 0;
        boolean rolled = false, demoted = false;
        for (int e = 0; e < n; e++) {
            EvalStats ev = new EvalStats();
            mode = o; policy = null;
            startEpisodeFor(o);
            while (step(false, ev)) {}
            // No-contests say nothing about gate quality or collapse. Keep them visible in the probe line, but out of probe decisions.
            noContests += ev.noContest;
            if (ev.noContest == 0) {
                validEpisodes++;
                hits += ev.hits; wins += ev.wins; draws += ev.draws; dealt += ev.dealt; taken += ev.taken;
                if (probeGuard && guard.addEpisode(true, ev.wins > 0, ev.losses > 0, ev.dealt, ev.taken, stage, agent)) rolled = true;
            }
            if (probeGuard && guard.takeDemotion()) demoted = true;
        }
        evalLock = 0;
        if (demoted) { // stage collapse: the guard restored the weights the stage was entered with; go back one stage and start its bot at the easiest setting
            int from = cur.autoStage();
            if (cur.demote(agent.totalTicks)) { botDiff.set(0.0); System.out.println("  ! stage " + from + " collapsed: restored the weights it was entered with, back to stage " + cur.autoStage() + " (collapse #" + guard.demotions + ")"); }
        }
        int probeDenom = Math.max(1, validEpisodes);
        if (validEpisodes > 0) cur.setGreedyResult(hits / (double) validEpisodes, dealt / validEpisodes, taken / validEpisodes);
        lastProbe = String.format(Locale.ROOT, "probe(%s) hits/ep %.1f dealt %.1f taken %.1f win %d/%d draw %d no-contest %d gate %s%s%s", o,
            hits / (double) probeDenom, dealt / probeDenom, taken / probeDenom, wins, validEpisodes, draws, noContests,
            cur.greedyOk() ? "ok" : "HOLD", rolled ? " ROLLBACK" : "", demoted ? " DEMOTED" : "");
    }

    EvalStats evaluate(Curriculum.Opponent opp, int episodes) {
        EvalStats ev = new EvalStats();
        for (int e = 0; e < episodes; e++) {
            int saveStageMode = 0;
            mode = opp; policy = null;
            startEpisodeFor(opp);
            while (step(false, ev)) {}
        }
        return ev;
    }

    /** Deterministic-style benchmark used by the standing evaluation suite. */
    EvalStats evaluateScriptStyle(int style, int episodes) {
        int previous = leagueStyle;
        leagueStyle = Math.max(0, Math.min(BotAI.STYLES - 1, style));
        evalDifficulty = 1.0;
        EvalStats ev = new EvalStats();
        evalLock = 0;
        for (int e = 0; e < episodes; e++) {
            startEpisodeFor(Curriculum.Opponent.STRONG);
            leagueStyle = Math.max(0, Math.min(BotAI.STYLES - 1, style)); // startEpisodeInternal resets the per-episode style
            mode = Curriculum.Opponent.STRONG; policy = null;
            while (step(false, ev)) { }
        }
        leagueStyle = previous;
        return ev;
    }

    void startEpisodeFor(Curriculum.Opponent opp) {
        startEpisodeInternal(false);
        reviewEp = false; // explicit probe/evaluation episodes never count as review samples
        mode = opp; policy = null;
        double ang = rng.nextDouble() * 6.283, d = 3.0 + rng.nextDouble() * 3.0;
        bot.x = Math.cos(ang) * d; bot.z = Math.sin(ang) * d; panTicks = 0;
        prevDist = d;
        beginLinks();
    }

    EvalStats evaluatePolicy(FrozenPolicy p, int episodes) {
        EvalStats ev = new EvalStats();
        for (int e = 0; e < episodes; e++) {
            startEpisodeFor(Curriculum.Opponent.SELF_PLAY);
            policy = p; mode = Curriculum.Opponent.SELF_PLAY;
            while (step(false, ev)) {}
        }
        return ev;
    }

    public static void main(String[] args) throws Exception {
        long total = Long.parseLong(args[0]);
        Path out = Path.of(args[1]);
        long seed = args.length > 2 ? Long.parseLong(args[2]) : 1;
        Path leagueDir = out.toAbsolutePath().resolveSibling(out.getFileName().toString() + ".league");
        System.setProperty("sim.league.dir", leagueDir.toString());
        System.setProperty("sim.league.file", leagueDir.resolve("ratings.csv").toString());
        PpoAgent agent = args.length > 3 && !args[3].equals("-") ? PpoAgent.load(Path.of(args[3]), seed) : new PpoAgent(seed);
        PvpSim sim = new PvpSim(seed + 1, agent);
        sim.weaknessStyles = true;
        // optional: -Dsim.forceStage=N trains a fixed stage (keeps the learned weights); by default the curriculum advances on performance
        if (System.getProperty("sim.forceStage") != null) sim.cur.force(Integer.parseInt(System.getProperty("sim.forceStage")));
        sim.mirrorOn = !"false".equals(System.getProperty("sim.mirror"));
        sim.lookAlpha = Double.parseDouble(System.getProperty("sim.lookalpha", String.valueOf(Config.LOOK_SMOOTH))); // camera smoothing used while training
        if (args.length > 4 && !args[4].equals("-")) { sim.rival = new FrozenPolicy(PpoAgent.load(Path.of(args[4]), seed + 7)); System.out.println("rival lineage loaded from " + args[4]); }
        ChampionEvaluator champion = new ChampionEvaluator(out);
        long start = System.currentTimeMillis(), nextLog = (agent.totalTicks / 25_000 + 1) * 25_000, nextProbe = agent.totalTicks + Config.GREEDY_PROBE_TICKS;
        boolean inEp = false;
        try {
            while (agent.totalTicks < total) {
                sim.syncCurriculum();
                if (!inEp && agent.totalTicks >= nextProbe && sim.cur.stage() >= 3 && sim.cur.stage() < 7) { sim.probe(); nextProbe = agent.totalTicks + Config.GREEDY_PROBE_TICKS; }
                if (!inEp) { sim.startEpisode(); inEp = true; }
                inEp = sim.step(true, null);
                agent.learnTick();
                champion.poll();
                champion.maybeLaunch(agent, sim.cur.stage());
                if (agent.totalTicks >= nextLog) {
                    nextLog += 25_000;
                    long sec = (System.currentTimeMillis() - start) / 1000;
                    int n = Math.max(1, sim.wEp);
                    System.out.printf(Locale.ROOT, "tick %7d [%4ds] stage %d | eps %3d win %3.0f%% loss %3.0f%% draw %3.0f%% no-contest %3.0f%% dealt %4.1f taken %4.1f ret %6.1f | hits %d crit %d sprint %d whiff %2.0f%% | follow-up %2.0f%% (%d/%d, expired %d, avg %.1f t) | def-combos %d, strafe-escapes %d | cam %.2f deg/t | ent %.2f %s%n",
                        agent.totalTicks, sec, sim.cur.stage(), sim.wEp, 100.0 * sim.wWin / n, 100.0 * sim.wLoss / n,
                        100.0 * sim.wDraw / n, 100.0 * sim.wNoContest / n, sim.wDealt / n, sim.wTaken / n, sim.wRet / n,
                        sim.wHits, sim.wCrit, sim.wSprint, 100.0 * sim.wWhiff / Math.max(1, sim.wSwing),
                        100.0 * sim.wSprintFollowups / Math.max(1, sim.wSprintFollowupOpps), sim.wSprintFollowups, sim.wSprintFollowupOpps,
                        sim.wSprintFollowupExpired, sim.wSprintFollowups == 0 ? 0.0 : sim.wSprintFollowupTicks / (double) sim.wSprintFollowups,
                        sim.wIncomingCombos, sim.wStrafeComboEscapes,
                        sim.wLook / Math.max(1, sim.wLookN), sim.entropyEma, sim.lastStageMsg + "  " + sim.lastProbe + " | " + sim.cur.status() + " | " + sim.disc.summary() + " | " + sim.spam.statsAndReset()
                            + (sim.cur.stage() >= Config.WEAKNESS_FROM_STAGE ? " | " + sim.league.weaknessSummary(sim.leagueAgentId) : "")
                            + (sim.cur.stage() >= 9 ? " | " + champion.status() : ""));
                    sim.lastStageMsg = "";
                    sim.disc.clearWindow();
                    sim.wEp = sim.wWin = sim.wLoss = sim.wDraw = sim.wNoContest = sim.wHits = sim.wCrit = sim.wSprint = sim.wSwing = sim.wWhiff = 0;
                    sim.wSprintFollowupOpps = sim.wSprintFollowups = sim.wSprintFollowupExpired = sim.wSprintFollowupTicks = 0;
                    sim.wIncomingCombos = sim.wStrafeComboEscapes = 0;
                    sim.wDealt = sim.wTaken = sim.wRet = sim.wLook = 0; sim.wLookN = 0;
                    agent.save(out);
                    sim.league.snapshot("checkpoint:" + agent.totalTicks, sim.leagueAgentId);
                    sim.league.save(sim.leagueFile);
                }
            }
        } finally {
            // Save the resumable learner before an optional held-out benchmark is allowed to finish.
            try {
                agent.save(out);
                sim.league.snapshot("checkpoint:" + agent.totalTicks, sim.leagueAgentId);
                sim.league.save(sim.leagueFile);
            } finally { champion.close(); }
        }
        System.out.println("saved " + out + " at " + agent.totalTicks + " ticks, stage " + agent.stage + " | " + champion.status());
    }
}
