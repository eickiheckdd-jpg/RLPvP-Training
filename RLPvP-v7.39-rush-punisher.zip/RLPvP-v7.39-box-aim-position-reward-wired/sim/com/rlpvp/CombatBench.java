package com.rlpvp;

import java.nio.file.Path;
import java.util.Locale;

/**
 * A/B benchmark of the play-time combat stack on the SAME checkpoint, same seeds, same opponents (no learning).
 *  stack 0 = plain policy, 1 = situational planner, 2 = + combat-intelligence suite.
 * Reports win rate with a Wilson 95% interval, HP differential (dealt - taken) with a paired-free standard error, hit / whiff stats.
 * Usage: CombatBench <state.bin> [episodes] [diff,diff,...]
 */
public final class CombatBench {
    static double[] wilson(int w, int n) {
        double z = 1.96, p = w / (double) Math.max(1, n), d = 1 + z * z / n;
        double c = (p + z * z / (2 * n)) / d, h = z * Math.sqrt(p * (1 - p) / n + z * z / (4.0 * n * n)) / d;
        return new double[]{c - h, c + h};
    }

    static PvpSim.EvalStats run(Path ck, int stack, Curriculum.Opponent opp, double diff, int eps, long seed) throws Exception {
        Config.PLAY_STACK = stack;
        if (stack == 2 && Config.INTEL_OFF == 0 && System.getProperty("rlpvp.intelOff") == null) Config.INTEL_OFF = Integer.getInteger("rlpvp.intelOff", 96);
        PpoAgent agent = PpoAgent.load(ck, 5);
        agent.setMask(0);
        PvpSim sim = new PvpSim(seed, agent);
        sim.evalDifficulty = diff;
        sim.opponentKey = opp + "@" + diff;     // one persistent "player": habit memory carries across the episodes
        PvpSim.EvalStats ev = new PvpSim.EvalStats();
        agent.resetSituationalEpisode(sim.opponentKey);
        for (int e = 0; e < eps; e++) { sim.mode = opp; sim.policy = null; sim.startEpisodeFor(opp); while (sim.step(false, ev)) {} }
        return ev;
    }

    /** Ablation: full stack with one component disabled at a time (bits as in Config.INTEL_OFF). Usage: CombatBench ablate <state.bin> [episodes] [diff] */
    static void ablate(Path ck, int n, double d) throws Exception {
        String[] names = {"none", "attack-gate", "movement", "spacing", "combo-escape", "resources", "scoring", "guidance", "ALL-OFF"};
        int[] bits = {0, 1, 2, 4, 8, 16, 32, 64, 127};
        if (System.getProperty("bits") != null) { String[] b = System.getProperty("bits").split(","); bits = new int[b.length]; names = new String[b.length]; for (int i = 0; i < b.length; i++) { bits[i] = Integer.parseInt(b[i]); names[i] = "bits" + b[i]; } }
        for (Curriculum.Opponent o : new Curriculum.Opponent[]{Curriculum.Opponent.AGGRESSIVE, Curriculum.Opponent.STRONG})
            for (int i = 0; i < bits.length; i++) {
                Config.INTEL_OFF = bits[i]; java.util.Arrays.fill(CombatIntelligenceSuite.DIAG, 0);
                PvpSim.EvalStats ev = run(ck, 2, o, d, n, 1234);
                double m = Math.max(1, ev.eps); long[] g = CombatIntelligenceSuite.DIAG; if (i == 0 && g[0] > 0) System.out.printf(Locale.ROOT, "  [threat>.55 %.0f%%, >.73 %.0f%%, comboRisk>.46 %.0f%% of ticks]%n", 100.0 * g[1] / g[0], 100.0 * g[2] / g[0], 100.0 * g[3] / g[0]);
                System.out.printf(Locale.ROOT, "%-11s d=%.1f off=%-13s win %5.1f%% dealt %5.1f taken %5.1f diff %+5.1f%n", o, d, names[i], 100.0 * ev.wins / m, ev.dealt / m, ev.taken / m, (ev.dealt - ev.taken) / m);
                System.out.flush();
            }
        Config.INTEL_OFF = 0;
    }

    public static void main(String[] a) throws Exception {
        if (a[0].equals("ablate")) { ablate(Path.of(a[1]), a.length > 2 ? Integer.parseInt(a[2]) : 60, a.length > 3 ? Double.parseDouble(a[3]) : 0.6); return; }
        Path ck = Path.of(a[0]);
        int n = a.length > 1 ? Integer.parseInt(a[1]) : 60;
        String[] ds = (a.length > 2 ? a[2] : "0.6,1.0").split(",");
        Curriculum.Opponent[] opps = {Curriculum.Opponent.AGGRESSIVE, Curriculum.Opponent.STRONG};
        System.out.println("checkpoint " + ck.getFileName() + ", " + n + " episodes per cell, same seeds across variants");
        System.out.printf("%-26s %-9s %6s %-13s %6s %6s %6s %5s %5s %5s%n", "opponent", "stack", "win%", "wilson95", "dealt", "taken", "diff", "hits", "spr%", "whf%");
        for (Curriculum.Opponent o : opps) for (String ds1 : ds) {
            double d = Double.parseDouble(ds1);
            for (int st = 0; st <= 2; st++) {
                PvpSim.EvalStats ev = run(ck, st, o, d, n, 1234);
                double m = Math.max(1, ev.eps), h = Math.max(1, ev.hits);
                double[] w = wilson(ev.wins, ev.eps);
                System.out.printf(Locale.ROOT, "%-26s %-9s %5.1f%% [%4.1f,%4.1f]%% %6.1f %6.1f %+6.1f %5.1f %5.0f %5.0f%n", o + " d=" + d,
                    st == 0 ? "policy" : st == 1 ? "planner" : "full", 100.0 * ev.wins / m, 100 * w[0], 100 * w[1], ev.dealt / m, ev.taken / m, (ev.dealt - ev.taken) / m, ev.hits / m,
                    100.0 * ev.sprintHits / h, 100.0 * ev.whiffs / Math.max(1, ev.swings));
                System.out.flush();
            }
        }
    }
}
