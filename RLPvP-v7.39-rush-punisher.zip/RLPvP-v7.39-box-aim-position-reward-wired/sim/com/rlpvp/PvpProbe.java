package com.rlpvp;

import java.util.Locale;

/** Diagnostic: how well does a simple HAND-WRITTEN aim-and-attack policy do in the simulator? (shows what the environment allows) */
public final class PvpProbe {
    static float[] aimbot(float[] fr, boolean sprintApproach, boolean strafe) {
        float yawErr = fr[13] * 180f, pitchErr = fr[14] * 90f, dist = fr[12] * 6f, charge = fr[6];
        float[] a = new float[7];
        a[0] = CameraMap.inverse((float) Math.max(-1, Math.min(1, yawErr / Config.YAW_SCALE))); // raw output that APPLIES the wanted turn
        a[1] = CameraMap.inverse((float) Math.max(-1, Math.min(1, pitchErr / Config.PITCH_SCALE)));
        a[2] = dist > 2.4f ? 2 : 1;                       // forward when far, stand when close
        a[3] = strafe ? 2 : 1;
        a[4] = (dist < 3.0f && Math.abs(yawErr) < 6 && Math.abs(pitchErr) < 12 && charge >= 0.9f) ? 1 : 0;
        a[5] = 0;
        a[6] = sprintApproach && dist > 4f ? 1 : 0;
        return a;
    }

    public static void main(String[] args) {
        int n = args.length > 0 ? Integer.parseInt(args[0]) : 60;
        PpoAgent agent = new PpoAgent(1);
        for (boolean ease : new boolean[]{false, true}) {
            for (double lag : new double[]{0, 2}) {
                for (Curriculum.Opponent o : new Curriculum.Opponent[]{Curriculum.Opponent.STRAFE, Curriculum.Opponent.WALK, Curriculum.Opponent.AGGRESSIVE, Curriculum.Opponent.STRONG}) {
                    PvpSim sim = new PvpSim(5, agent);
                    sim.ease = ease; sim.fixedLag = lag;
                    sim.hand = fr -> aimbot(fr, false, false);
                    PvpSim.EvalStats ev = sim.evaluate(o, n);
                    double e = Math.max(1, ev.eps);
                    System.out.printf(Locale.ROOT, "aimbot  eased-view=%-5b lag=%.0f vs %-10s win %3.0f%% loss %3.0f%% dealt %4.1f taken %4.1f hits/ep %.1f whiff %3.0f%%%n",
                        ease, lag, o, 100.0 * ev.wins / e, 100.0 * ev.losses / e, ev.dealt / e, ev.taken / e, ev.hits / e, 100.0 * ev.whiffs / Math.max(1, ev.swings));
                }
            }
        }
    }
}
