package com.rlpvp;

/** Deterministic smoke test for tracking jitter suppression and legal mouse-count deltas. */
public final class AimStabilityEval {
    public static void main(String[] args) {
        AimInputFilter filter = new AimInputFilter();
        double rawAbs = 0.0, filteredAbs = 0.0;
        int n = 400;
        for (int i = 0; i < n; i++) {
            double raw = (i & 1) == 0 ? 0.50 : -0.50; // a worst-case tiny left/right policy oscillation
            rawAbs += Math.abs(raw);
            filteredAbs += Math.abs(filter.step(raw, Config.YAW_SCALE, true));
        }
        double attenuation = filteredAbs / rawAbs;
        if (!(attenuation < 0.30)) throw new AssertionError("Aim jitter attenuation too weak: " + attenuation);

        filter.reset();
        double out = 0;
        for (int i = 0; i < 6; i++) out = filter.step(24.0, Config.YAW_SCALE, true);
        if (!(out > 15.0 && out <= Config.YAW_SCALE)) throw new AssertionError("Large turn did not remain responsive: " + out);
        if (!Double.isFinite(filter.step(Double.NaN, Config.YAW_SCALE, true))) throw new AssertionError("NaN escaped filter");

        GameplayRotation rot = new GameplayRotation();
        rot.setMouseSensitivity(0.5);
        float yaw = 0f, pitch = 0f;
        for (int i = 0; i < 300; i++) {
            rot.stepEffort((i % 30 < 15) ? 4.0 : -4.0, 1.3, yaw, pitch, 2.0, 1.0, true, true, true);
            double q = 1.2 * Math.pow(0.6 * 0.5 + 0.2, 3.0);
            double counts = rot.dYaw / q;
            if (Math.abs(counts - Math.rint(counts)) > 0.005)
                throw new AssertionError("Yaw delta was not quantized to a valid mouse count: " + rot.dYaw + " / " + q);
            counts = rot.dPitch / q;
            if (Math.abs(counts - Math.rint(counts)) > 0.005)
                throw new AssertionError("Pitch delta was not quantized to a valid mouse count: " + rot.dPitch + " / " + q);
            yaw = rot.newYaw; pitch = rot.newPitch;
        }
        if (GameplayRotation.shortestYawDelta(179f, -179f) != 2f)
            throw new AssertionError("Yaw wrap regression");
        System.out.printf(java.util.Locale.ROOT,
            "Aim stability PASS: jitter amplitude ratio=%.3f, responsive turn=%.2f deg/tick, mouse quantization and shortest-angle delta OK.%n",
            attenuation, out);
    }
}
