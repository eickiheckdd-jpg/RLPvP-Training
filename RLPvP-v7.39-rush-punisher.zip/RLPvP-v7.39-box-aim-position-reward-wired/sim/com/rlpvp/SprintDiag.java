package com.rlpvp;
import java.nio.file.Path;
public final class SprintDiag {
    public static void main(String[] a) throws Exception {
        PpoAgent agent = PpoAgent.load(Path.of(a[0]), 5);
        int eps = Integer.parseInt(a[1]);
        PvpSim sim = new PvpSim(55, agent);
        sim.evalDifficulty = Double.parseDouble(a[2]);
        agent.setMask(0);
        for (Curriculum.Opponent o : new Curriculum.Opponent[]{Curriculum.Opponent.WALK, Curriculum.Opponent.AGGRESSIVE, Curriculum.Opponent.STRONG}) {
            java.util.Arrays.fill(PvpSim.DBG, 0);
            PvpSim.EvalStats ev = sim.evaluate(o, eps);
            int[] D = PvpSim.DBG; double n = Math.max(1, D[0]);
            System.out.printf("%s: swings %d | at the click: sprinting %.0f%%, falling-crit %.0f%%, plain %.0f%% (%d)%n", o, D[0], 100.0*D[1]/n, 100.0*D[2]/n, 100.0*D[3]/n, D[3]);
            double p = Math.max(1, D[3]);
            System.out.printf("   plain swings: prev fwd<=0 %.0f%% | fwd>0 but sprint key off %.0f%% | fwd+sprint key but not sprinting (just hit / wall) %.0f%% | airborne %.0f%% | policy WANTS sprint+fwd now %.0f%% | dist<2 %.0f%% | within 8 ticks of taking a hit %.0f%%%n",
                100.0*D[4]/p, 100.0*D[5]/p, 100.0*D[6]/p, 100.0*D[7]/p, 100.0*D[8]/p, 100.0*D[9]/p, 100.0*D[10]/p);
            System.out.printf("   hits: crit %.0f%% sprint %.0f%% | jump pressed on %.0f%% of swings, S held on %.0f%% of swings%n", 100.0*ev.crits/Math.max(1,ev.hits), 100.0*ev.sprintHits/Math.max(1,ev.hits), 100.0*D[13]/n, 100.0*D[14]/n);
        }
    }
}
