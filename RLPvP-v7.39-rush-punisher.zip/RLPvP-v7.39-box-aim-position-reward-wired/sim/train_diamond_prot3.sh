#!/bin/sh
# Train the agent only in the requested kit: normal diamond sword vs full diamond armor, Protection III on all four pieces.
# Usage: sim/train_diamond_prot3.sh <totalTicks> <out.bin> [seed] [resume.bin|-] [workers] [rival.bin|-]
set -eu
cd "$(dirname "$0")/.."
export JAVA_OPTS="${JAVA_OPTS:-} -Dsim.kit=diamond_prot3"
echo "RLPvP kit locked: normal diamond sword vs full diamond armor / Protection III on all four pieces"
echo "Attributes: sword damage 7, attack speed 1.6 (12.5-tick charge); armor 20, toughness 8, melee EPF 12"
exec sh sim/train_parallel.sh "$@"
