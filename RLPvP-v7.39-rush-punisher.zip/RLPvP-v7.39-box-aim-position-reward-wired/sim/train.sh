#!/bin/sh
# Resumable training in segments (survives a restart: run it again). usage: sim/train.sh <classes dir> <out dir> [total ticks] [seed]
CP=$1; OUT=$2; TOTAL=${3:-1100000}; SEED=${4:-1}; mkdir -p "$OUT"; cd "$OUT"
for T in 300000 600000 900000 $TOTAL; do
  [ "$T" -gt "$TOTAL" ] && continue
  [ -f "$OUT/ckpt_$T.bin" ] && continue
  if [ -f "$OUT/state.bin" ]; then R="$OUT/state.bin"; else R=-; fi
  java -cp "$CP" com.rlpvp.PvpSim "$T" "$OUT/state.bin" "$SEED" "$R" - >> "$OUT/train.log" 2>&1 && cp "$OUT/state.bin" "$OUT/ckpt_$T.bin"
done
java -cp "$CP" com.rlpvp.PvpEval "$OUT/state.bin" 150 > "$OUT/eval.txt" 2>&1
echo done > "$OUT/DONE"
