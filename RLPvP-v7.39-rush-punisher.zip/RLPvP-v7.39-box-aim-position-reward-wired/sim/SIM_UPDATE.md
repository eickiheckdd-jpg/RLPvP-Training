# Simulator update (what changed)

**More faithful / realistic**
- **Network model per episode** (`PvpSim.Link`): random one-way delay 0..~3 ticks (20 % of episodes lag-free), jitter, rare TCP-like
  stalls. The enemy (and my own health / hurt timer) reach the agent through a delayed, in-order link; the enemy is eased toward its
  newest position over 3 ticks like a vanilla remote player. Own movement and aim stay immediate (client prediction).
- **Attack packets**: the click is decided on the client's delayed picture of the enemy, travels up the link, and the server applies it
  to the world as it is on arrival (reach 3.0 + the vanilla 1.0 leeway, damage from the cooldown at the click). Credit for rewards uses the
  true server events; the observation only contains what a client could see.
- **Self-play opponents are clients too**: they see you through their own lag and their attacks travel the same way.
- **Same inputs as the mod**: 11 lags up to 4.8 s, `HitMemory` summary (hit types, damage, counts), 378 inputs; `ObsStack.push(frame, summary)`.
- **Eval** (`PvpEval`) prints technique statistics (crit / sprint / full-charge / reset-gap / punish share, whiff, strafe / back / sprint /
  jump time, spacing) and tests fixed lags 0, 2, 4 plus a rival lineage.

**Curriculum / reward**
- Jump unlocks at **stage 4** (`Curriculum.lockMaskFor`); technique weights start there (stage 4: 0.5, stage 5: 1.0; crit-window bonus from stage 4).
- `CRIT_BONUS` 1.4 vs `SPRINT_HIT_BONUS` 0.15, so a jump-crit is clearly worth more than a sprint hit.

**Self-play against DIFFERENT versions** (never the same weights)
- Rival lineage: a second agent (other seed, other training history) frozen as an opponent: 20 % of episodes from stage 5, 45 % in stage 8.
- Own snapshots are used only if they are at least 50k ticks old. `sim/league.sh` trains the two lineages in turns, each against the
  other's latest weights.

Run: `sim/run.sh <ticks> <out.bin> [seed] [resume.bin|-] [rival.bin|-]`, `sim/league.sh <classes dir> <out dir>`, eval:
`java -cp <classes> com.rlpvp.PvpEval A.bin 150 B.bin`.
Still NOT modelled: walls / blocks, armor, real Carpet bots, vanilla entity pushing, rubber-banding / knockback desync.

## Collapse investigation (why the agent stopped hitting and fled at stage 5) and the fix
Symptom: after stage 4 the simulated agent's hits fell to ~0, whiff 99-100 %, it sprinted away (distance 17-29) and never hit.
What I checked: a hand-written aim bot (`sim/com/rlpvp/PvpProbe.java`) wins 100 % against the walking bot with and without lag and eased
view, so the simulator and the lag model are NOT the problem. The learned agent simply never learned to aim precisely, because
1. **Swinging blind was free**: a swing only counted as a "pointless whiff" if the aim was more than 45 degrees off (`WHIFF_OFFAIM_YAW` 0.25),
   while the hitbox is about +-6 degrees. Now 9 degrees (0.05).
2. **The aim shaping was gone before the agent could aim**: it decays with training ticks (`SHAPING_TAU_TICKS` 100k) but the 378-input network
   learns slower. Now tau 400k, floor 0.35.
3. **Stages advanced on a lenient aim gate and on max-ticks**: `ON_TARGET_DEG` 8 -> 6, `STAGE_MAX_TICKS` of stages 3-7 raised.
4. My own earlier tuning made it worse: attack gate relaxed at stage 6 (now off, `GATE_RELAX_STAGE` 99), closeness faded in stages 7-8 and
   spacing at 6 (reverted), `W_DAMAGE` 9 -> 12 and `WHIFF_PENALTY` back to 0.12, lag only from stage 6 (ramps 0.4 / 0.7 / 1.0 of the full range).
5. The simulator now also uses the mod's `CollapseGuard` (best-checkpoint rollback).
Check run (one lineage, no league, 450k ticks): stage 4 win 95 % (595 hits / 25k ticks, whiff 70 %), stage 5-6 win 95 %, no collapse;
stage 7 (aggressive bot) starts at win 16 % / loss 83 % and needs more training. Crits stay rare (6-9 per ~600 hits, sprint hits dominate).

## Technique rewards + CollapseGuard in the scripts (this update)
- **`TechniqueReward.java`** (new, shared by `Trainer` and `PvpSim`): outcome-based rewards for strafing while tracking, not standing still, sprint-hit chains
  (the result of W-tapping), counter-strafing vs an endless circle, not holding W forever in melee range, safe vs unsafe jump-crits (and crit-every-hit),
  dodging a swing (bait), disengaging when clearly behind + a re-peek bonus, and a cost for panic double-whiffs. No action is scripted or forced.
  Event bonuses are capped per episode and everything is scaled by the stage's technique weight (0 before stage 4) and skipped while the heads it needs are locked.
- **CollapseGuard**: `PvpSim` already created and fed it, but `sim/run.sh` and `sim/eval.sh` did not compile `CollapseGuard.java` (the build would fail). Fixed.
  `tests/GuardCheck.java` proves it: no rollback on a stable run, self-play episodes ignored, rollback to the best weights on a collapse, clean start on a new stage.
- `tests/TechniqueCheck.java` proves each reward pays for the good result and costs for the bad habit (12 checks).
- Not trained in this version: the technique rewards are untested for their effect on learning. Run `sim/run.sh` and watch the `PvpEval` technique statistics.

## Harder opponents that a W+D orbit cannot beat (BotAI)
The old AGGRESSIVE / STRONG bots aimed at where the agent WAS 2 ticks ago and only swung when that stale angle was within 12 degrees, so a fast
sprint-orbit stayed outside the aim window; they also measured reach center-to-center (about 3.0) while the real reach allows about 3.3, and a
jump-crit / jump-reset habit kept them in the air in exactly the window where they should swing. All fixed in the new shared `BotAI.java`
(used by `BotBrain` in the mod and `PvpSim` in the simulator; STATIONARY / STRAFE / WALK are unchanged because they are the easy curriculum):
- lead aim from delayed velocity (capped at 0.75 gain: full lead over-predicts a curving orbit and made the bot worse), swing only when its predicted crosshair is on target;
- mirror-strafe (follows the agent's sideways motion so an orbit cannot slide out of the crosshair), pursuit when the agent keeps away, rush + swing when the agent's weapon recharges;
- 3 styles per episode (COUNTER / PRESSURE / BAITER), w-tap, safe jump-crits, disengage + re-peek when behind, commits after 50 quiet ticks;
- fairness: reaction lag 1-2 ticks, turn cap <= 30 deg/tick plus noise, full-charge swings only, real ray reach 3.0 (a miss costs its cooldown). `tests/BotAICheck.java` checks this.
- `BotDifficulty` adapts the strength 0..1 to the agent's win rate against the scripted fighters (never against self-play snapshots), so stage 7 does not become a wall and the bot keeps pace.
Benchmark (`sim/bench.sh`, an IDEALIZED agent with perfect aim and no lag, 120 episodes): HP the agent loses per fight, old vs new at full strength:
orbit-D 1.6 -> 12.1 (strong), 2.9 -> 11.8 (aggressive); the idealized orbiter's win rate drops from 100% to 80-86%. A standing-still trader now loses 8-11 HP instead of 1-3.
The idealized agent is stronger than any learned agent, so these numbers are a stress test, not a prediction. Not trained yet in this version.

## v5 collapse fix (this update) - why the agent fled at stage 7 and what changed
Symptom (reproduced 3 times): stage 7 (BotAI) started at win 0 % / loss 100 %; hits fell to 0, whiff 100 %, the agent ran away.
Root cause: BotAI's EASIEST setting (difficulty 0.15, the old floor) was already far stronger than the stage-6 walking bot the agent had just
beaten 54 % (lead aim 0.37, 70 % fire rate, mirror-strafe 0.31, turn 21 deg/tick). A cliff of that size gives the agent no winning episodes to learn
from, and fleeing (-3 per episode) beats fighting and losing (-26). The collapse guard cannot fix a cliff: there is no good checkpoint to go back to.
Fix: `BotAI.newEpisode` now scales from a beatable bot at difficulty 0 (lead 0, noise 6 deg, fire 0.30, turn 9, no mirror) to the old full strength at 1;
`BotDifficulty` can go down to 0 (START 0.15). Training adapts it to the agent (up above 65 % wins, down below 35 %).
Also: `TechniqueReward` flee cost (running > 7 blocks away while not behind), overlap cost, stronger hold-W cost, crit-setup bonus;
mirrored episodes (left/right swapped in the observation and the actions), camera sensitivity / jitter that grows with the stage;
the simulator's evaluation now uses the SAME attack gate as the mod (it used the relaxed 0.5 gate, which the agent was never trained for);
`PvpEval` has a bot-strength sweep. `sim/train.sh` trains in resumable segments with the CollapseGuard active.
Result (1M ticks, one lineage, self-play = own snapshots >= 50k ticks old): reaches stage 8, no collapse; see docs/eval_1M.txt and docs/train_1M.log.
