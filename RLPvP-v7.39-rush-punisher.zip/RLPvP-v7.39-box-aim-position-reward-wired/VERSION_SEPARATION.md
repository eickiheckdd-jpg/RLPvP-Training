# Version separation correction

- **Fabric mod target:** Minecraft Java 1.21.11 (Fabric Loader 0.18.4, Fabric API 0.141.3+1.21.11, Java 21).
- **Standalone simulator reference:** Minecraft Java 26.3 decompiled source supplied for formula reference only.
- The simulator's Java combat model and PPO training code are independent of the Fabric mod's Minecraft dependency.
- No simulator formula, model checkpoint, or training state was changed by this mod-target correction.

The prior v9 packaging mistakenly configured the Fabric mod itself for Minecraft 26.3. This correction restores the known 1.21.11 settings from the supplied v7.34 project.
