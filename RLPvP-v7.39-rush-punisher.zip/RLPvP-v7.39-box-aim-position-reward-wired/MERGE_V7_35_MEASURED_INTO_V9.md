# RLPvP v7.35 measured combat-intelligence merge into v9

This merge keeps the v9 Minecraft-26.3 combat/physics implementation and incorporates selected measured v7.35 intelligence fixes. It does not overwrite v9's Minecraft combat formulas or PPO serialization.

Merged: configurable play stack and ablation mask; policy-only/planner/full-stack evaluation modes; measured default `INTEL_OFF=96` (candidate scoring/guidance disabled, remaining enforcement active); tradeable full-charge counterattack state; combo escape limited to confirmed multi-hit sequences; removal of broad anti-sprint/anti-forward combo penalties; persistent opponent keys across evaluation episodes; combat A/B harness and original v7.35 benchmark result provenance.

Kept from v9: Java 26.3 combat/physics code, independent client/server attack-strength tickers, newer short-horizon opponent pattern predictor, and predictor reset at episode boundaries.

Fresh training uses no resume checkpoint. The training output/log are written separately from all prior checkpoints. See the training log for the actual progress and completion status.
