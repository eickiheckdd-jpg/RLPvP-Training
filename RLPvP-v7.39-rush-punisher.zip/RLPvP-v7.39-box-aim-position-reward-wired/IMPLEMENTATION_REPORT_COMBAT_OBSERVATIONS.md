# Combat Observation Implementation Review

## Implemented

- Enabled `rlpvp.obsV2` by default; runtime override `-Drlpvp.obsV2=false` remains available.
- Added 11 appended combat observations, enabled by default; runtime override `-Drlpvp.combatObs=false` remains available.
- Wired the new features into the primary trainer, self-play bot, and Minecraft-free simulator.
- Added checkpoint input-column migration by summary-block meaning, so prior layouts can warm-start with new incoming columns zero-initialized.
- Fixed knockback timing placement so its 4-value block remains immediately before the new 11-value combat block rather than overlapping it.
- Added regression tests for feature values, event-pulse lifetime, observation dimensions, summary block placement, and old-layout migration.
- Documented feature definitions and their normalizations in `docs/COMBAT_OBSERVATIONS.md`.

## New features

1. `distance_delta_per_tick`
2. `reach_margin`
3. `intercept_angle`
4. `crosshair_on_target_box`
5. `miss_to_hit_ratio`
6. `crit_efficiency_ratio`
7. `sprint_hit_efficiency_ratio`
8. `damage_differential_trend`
9. `sprint_modifier_active`
10. `ticks_since_sprint_interruption`
11. `attack_during_iframe`

These are observations only: this change does not directly change the reward function or force the policy to choose any action. `sprint_modifier_active` is explicitly a proxy because the mod does not expose a direct engine flag for a primed sprint-knockback state.

## Verification

Passed:

- `./sim/regression.sh`: 43 outcome regressions passed, 12 sprint-follow-up tests passed, and `CombatObservationMemoryTest` passed.
- `./sim/modelinfo.sh`: observation layout built successfully; current default layout reports 445 inputs, 14 actions, and 149,135 total actor/critic parameters for the base model.
- `./sim/consistency.sh training-results-fresh-3m/state.bin 1`: legacy/current checkpoint input migration and rotation consistency passed over 1,136 ticks, with zero measured turn/velocity divergence.
- `./tests/run.sh`: its initial checks and many subsequent checks passed, including model, memory, reward, curriculum, Minecraft-rules, spam-guard, style, GRU, glide-camera, sneak-migration, and aim-brake checks. The script later timed out during the long `GameplayRotationCheck`, so the entire script is **not** claimed as fully passing.

Not verified:

- Full Fabric/Minecraft Gradle build. The Gradle wrapper requires downloading Gradle 9.5.1, but the environment could not resolve `services.gradle.org`; production-source compilation therefore remains unverified here.
- No fresh 3-million-tick training run or A/B performance evaluation was started as part of this code change. Better win rate or combat behavior is not claimed.

## Compatibility note

The observation vector is wider under the new defaults. Existing checkpoints can be migrated by semantic summary blocks, with new input connections initialized to zero, but this is a warm-start and does not guarantee the behavior will remain identical after further training. For the cleanest evaluation of the new inputs, start a fresh run and compare against the prior baseline.
