# RLPvP AI — Stage 8 Curriculum Crash Fix

Date: 2026-11-01

## Defect found in source

The curriculum has nine stages, but only stages 1–6 use the finite episode win-rate gate table. Stages 7 and 8 are PFSP/Elo league stages, and Stage 9 is continuous league training.

Before this fix, `Curriculum.reportEpisode()` tested `autoStage < STAGES`. That condition also admitted Stage 8, and after its 30th decided episode the method called `gateFor(8)`. The gate table had seven entries with valid indexes 0–6, so that call attempted index 7 and would throw `ArrayIndexOutOfBoundsException`. The same mismatch was exposed by the generic `mayAdvance()` helper.

The persisted training log currently available in this workspace does not contain that exception stack trace. The source path is deterministic and the regression test now covers the exact full-window boundary, but the saved logs do not prove that this was the cause of the earlier process disappearance at tick 800,780 (the checkpoint was Stage 6 and the old supervisor state did not record a child exit). The supervisor was therefore also improved to record child PIDs, exit codes, and received signals.

## Changes made

1. Added an explicit normal-gate stage predicate. Only stages 1–6 use the episode win-rate table.
2. Removed the unused seventh threshold from `Config.STAGE_GATE_WIN`; stages 7–9 are explicitly league-driven.
3. `reportEpisode()` no longer calculates normal-gate hold state in league stages.
4. `mayAdvance()` returns false for stages without a normal win-rate gate, and `gateFor()` throws a descriptive `IllegalArgumentException` for invalid stages instead of an array-bounds exception.
5. Parallel training now persists changed league match records after a completed worker round and saves the ledger during shutdown. Worker collection observes interruption and the trainer joins workers before the final save.
6. The 3M supervisor now records the launched child PID, child exit status, and supervisor signals, so a future stop is diagnosable from the logs.

No reward values, policy weights, PPO hyperparameters, simulator physics, kit settings, or checkpoint format were changed.

## Verification performed

- `CurriculumGateCheck`: PASS. Includes exactly 30 episode reports at Stages 7, 8, and 9; Stage 8 remains safe at the point where the old code would first have indexed past the gate array. It also verifies Stage 8 still advances to Stage 9 using its Elo/game requirements.
- `ParallelLeaguePersistenceCheck`: PASS.
- Parallel trainer compile: PASS.
- One-round resume smoke test: PASS; loaded the supplied checkpoint at tick 800,780 and wrote a smoke checkpoint at tick 801,806 using two workers.
- Exact launcher compile/load/save path: PASS.
- Live resumed run: PASS through Stage 8. It advanced to tick 875,534 (checkpoint stage 8, entered at tick 843,059); the latest log records 106 league games and Elo 1,333, with the Java trainer and supervisor still alive at the latest process check. This is well beyond the 30-episode boundary that used to expose the bad gate indexing.
- Full `tests/run.sh`: ran through the curriculum and many other checks, then stopped at four `GameplayRotationCheck` assertions (small-correction overshoot, brake overshoot test, stability test, and fine-aim test). Those camera files were not modified by this fix. Later tests in that script were not reached in that invocation.

## Resumed training

The existing 3M-tick run was restarted from the original checkpoint at tick 800,780, with the same seed (20261101), two workers, and `diamond_prot3` kit. At the latest verification it was at tick 875,534 / 3,000,000 (29.18%), Stage 8, with 106 league games and Elo 1,333. Supervisor PID 24738 and Java PID 24742 were alive. The supervisor/Java process IDs and subsequent exit information are recorded in `training/supervisor_state.log` and `training/fresh_3m_supervised.log`.
