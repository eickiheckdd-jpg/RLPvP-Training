# RLPvP v7.38 input-spam regularization candidate

## Scope
Adds small, bounded costs for pathological input churn in `SpamGuard` without changing the actor, critic, GRU, PPO loss, action encoding, checkpoint format, or combat simulator.

## Behavior
- Repeated W/S and A/D direction reversals remain outcome-driven; they are not directly penalized because they can represent W/S taps, sprint resets, strafing, dodging, or adaptation. Holding movement inputs while stuck at near-zero speed is covered by the existing tiny stuck guard.
- Rapid sprint toggles are penalized only when the agent is otherwise idle (no forward/strafe input and near-zero speed), outside recent-hit and recent-damage grace windows. Sprint use while moving remains free. Sprint without forward input retains its tiny waste cost.
- Rapid sneak toggles are penalized only when otherwise idle and outside combat grace windows. Holding sneak, short tactical sneak bursts, and sneak use while moving remain free.
- No generic attack-button tax is added; unproductive attacks remain governed by existing swing/whiff logic so the system does not suppress good attack timing.
- Added toggle costs share the existing per-tick and per-episode movement-guard caps.

## Learning-preservation safeguards
No hardcoded combat action, combo, dodge, aim, crit, W/S-tap, or sprint-hit behavior was introduced. No model architecture, observation layout, policy outputs, PPO math, reward for damage/wins, curriculum, or simulator physics changed. The penalties act only as a small idle-input regularizer; combat outcomes still determine whether an action is useful.

## Verification
- `SpamGuardCheck`: pass (holding sneak remains unpenalized).
- `MoveSpamCheck`: pass (ordinary movement, A/D strafing, W/S reversals, sprint toggles during movement, and short sneak bursts remain free; idle sneak-toggle spam is mildly and episode-boundedly penalized).
- `GruCellCheck`: pass (copied GRU replay cache gives identical BPTT gradients; finite-difference gradient and acting/window equivalence checks pass).
- `DiamondProt3KitTest`: 27 checks passed.
- Simulator regression suite is run separately before training.

## Limits
This ZIP remains a simulator/training-source candidate. A Fabric/Gradle mod build is not required for this simulator-only training run and has not been revalidated here. No claim is made that the full Minecraft mod build is verified.
