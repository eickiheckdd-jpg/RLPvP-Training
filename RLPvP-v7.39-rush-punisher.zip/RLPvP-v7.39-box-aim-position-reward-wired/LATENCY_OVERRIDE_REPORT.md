# Explicit 50–130 ms RTT training override

This candidate adds the opt-in JVM property `-Drlpvp.latencyAlways=true`.
With that property enabled, the simulator applies the configured `rlpvp.lagMinMs` and `rlpvp.lagMaxMs` RTT bounds from the first curriculum stage and suppresses the normal 10% lag-free episode sampling. Set `-Drlpvp.lagMinMs=50 -Drlpvp.lagMaxMs=130` to train with sampled RTT values in the requested interval. Existing stage-based lag curriculum and lag-free sampling remain unchanged when `rlpvp.latencyAlways` is false/unset.

This changes only simulator network-domain randomization; policy architecture, PPO/GRU learning math, rewards, action outputs, kit, and checkpoint input layout are unchanged.
