# v7.38 Learning-Preserving Performance Optimization

## Goal

Reduce avoidable allocation and per-tick overhead while preserving the existing training algorithm and its deterministic outputs. This is an engineering optimization pass, not a change to the AI's combat strategy or learning design.

## Changes

### `src/main/java/com/rlpvp/PpoAgent.java`

- Replaced three short-lived fixed-size arrays in `updateHeadEntropy()` with scalar selection through a `switch`.
- Cached the two constant logarithms used by the existing entropy normalization.
- Kept the same four entropy inputs, lock masks, update order, EMA equations, thresholds, and boost values.

### `src/main/java/com/rlpvp/NetworkSimulation.java`

- Added `Channel.drainInto(tick, destination)` so the simulator can append delivered packets into a reusable list instead of allocating a new list for each channel every tick.
- Kept `Channel.drain(tick)` and its historical sequence-order behavior for existing callers.
- The simulator still merges the two client streams and orders them by arrival time, then sequence, before processing.

### `sim/com/rlpvp/PvpSim.java`

- Reuses per-simulator entity views when reading delayed link snapshots instead of constructing new entity copies every tick.
- Reuses velocity and relative-velocity arrays.
- Reuses a per-simulator incoming-packet list and a static packet-order comparator.
- Adds `frameInto(...)` for simulator hot paths, using a per-simulator frame buffer. It zeroes the buffer before writing the same features. The existing `frame(...)` API continues to return a fresh array.
- Replaces temporary look-vector arrays in frame construction and ray/AABB checks with scalar calculations using the same formulas and axis order.
- Scratch state is owned by each `PvpSim` instance, not shared statically between parallel environments.

### Tests

- Added equivalence coverage for `drainInto(...)`, including append behavior, packet order, metadata, retransmissions, and queue counters.
- Added exact fresh-frame versus reused-frame comparisons, including a second call to catch stale values.

## Explicitly unchanged

This pass does not change:

- Observation count or layout (126 observations remain intact).
- GRU dimensions, recurrent sequence handling, or BPTT window.
- PPO losses, gradients, optimizer, entropy coefficients, sampling, or update cadence.
- Random-number call sites in policy/action sampling.
- Rewards, technique reward settings, curriculum, opponent league/PFSP, or rating rules.
- Minecraft combat formulas, kit, damage, armor, cooldown, knockback, or latency parameters.
- Aim behavior, movement decisions, combat actions, or target selection.

The compact `ObsStack` input still returns a fresh array, preserving its existing API/lifetime contract. A tentative reuse there was removed rather than risk aliasing an observation retained by a caller.

## Validation

### Regression

`bash sim/regression.sh` completed successfully. The run included:

- NetworkSimulationTest: 19 passed, 0 failed.
- PvpSimNetworkTest: 14 passed, 0 failed.
- OutcomeRegressionTest: 43 passed, 0 failed.
- SprintHitFollowupMemoryTest: 12 passed, 0 failed.
- Minecraft26PhysicsTest: 25 passed.
- DiamondProt3KitTest: 27 passed.
- Minecraft263CombatTest: 34 passed.
- OpponentLeagueCheck, Stage9LeagueCheck, ParallelLeaguePersistenceCheck, ParallelLeaguePathCheck, measured combat merge, opponent adaptation, situational stack, technique-audit/reward-policy checks, and compact-observation migration/GRU checks all passed.

### Same-seed training-output equivalence

Ran the baseline and optimized simulator from a fresh state for 4,096 ticks with identical seed and settings (126 observations, GRU 64x18, diamond Prot III kit). The two resulting checkpoint files were byte-for-byte identical:

`e1e0fcc8fa354c285e50ff7a18dae6e82e9a8b116d9739c24475376888e13d07`

A second direct-run pair also produced byte-identical checkpoints:

`b27551b3755894ea0c285de69c615d95856a42a5ca881ad055b6a4c1696d55be`

This is strong evidence that the tested training transitions, random stream, optimizer state, and resulting serialized model state were preserved for those controlled runs. It is not a formal proof for every possible seed, runtime, or code path.

### Throughput measurement

One completed direct 4,096-tick pair measured:

- Baseline: 12.94 seconds, peak RSS 95,196 KB.
- Optimized: 12.81 seconds, peak RSS 88,236 KB.

That is approximately 1% faster and 7.3% lower peak RSS in this single sample. The timing difference is small and within possible run-to-run noise; it should not be advertised as a proven sustained TPS increase. A longer multi-run benchmark did not complete within the execution window, so stage-9/two-worker throughput still needs a controlled benchmark before claiming a material speedup.

## Safety / rollout

- The original source directory and the stopped training checkpoint are not modified by this optimized copy.
- No training was started as part of this optimization work.
- Keep this as a candidate build. Before using it for the next long run, compare a short same-checkpoint resume against the baseline again and evaluate the resulting policies against the same held-out league opponents. If any metric or checkpoint diverges, use the baseline build and investigate before training further.
