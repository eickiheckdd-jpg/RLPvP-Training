RLPvP v8.1 — DIAMOND PROTECTION III KIT

Target duel (both participants):
  Weapon: unenchanted Minecraft Java 26.3 diamond sword
  Armor: full diamond (helmet/chestplate/leggings/boots), Protection III on all four pieces
  Status: no effects, shield, absorption, or regeneration
  World: flat combat arena; no blocks/UHC mechanics

Modeled attributes:
  Sword damage: player base 1 + sword modifier 6 = 7
  Sword attack speed: player base 4 - sword modifier 2.4 = 1.6
  Full charge: 20 / 1.6 = 12.5 ticks
  Armor: 3 + 8 + 6 + 3 = 20
  Toughness: 2 per piece = 8
  Protection: 3 EPF per piece = 12 EPF for ordinary melee

Reference damage stages:
  Full normal hit: 7.0 raw -> 1.89 after armor -> 0.9828 HP final
  Full critical hit: 10.5 raw -> 3.2025 after armor -> 1.6653 HP final
  Half-charge (0.5): 2.8 raw -> 0.6384 after armor -> 0.331968 HP final

Train:
  ./sim/train_diamond_prot3.sh 3000000 output-diamond-prot3.bin 20261030 - 4 -

Run focused regression tests:
  ./sim/regression.sh

The simulator implements equations independently, based on behavior in the supplied Minecraft 26.3 decompiled reference files and the linked CombatRules reference. It does not embed Mojang's server classes. Full movement/collision/packet fidelity is still incomplete, and live-server parity has not been established.
