# v7.3 (on top of v7.2). Written under "don't run tests or simulations": only compile checks were done; nothing below was run after the last edits.

## Sneak (action AND observation)
- **Action:** a 4th on/off head `sneak` (`Config.OFF_SNEAK`, action index 7). Effects in the simulator, as in vanilla: 30 % movement speed, no sprinting,
  eye height 1.27 (was 1.62), hitbox height 1.5 (was 1.8). In the mod: `keyShift`; sprint is cancelled while sneaking.
- **Observation:** 3 features APPENDED to the frame (no existing index moved): 48 = I am sneaking, 49 = the enemy is sneaking, 50 = my sneak head is locked.
  `Config.FRAME` 48 -> 51, `Config.ACTION_SIZE` 13 -> 14.
- **Curriculum:** sneak is locked until stage 6 (it matters once the agent moves and fights); lifting the lock triggers the usual exploration boost.
  New heads start rare (prior bias -3, p about 0.05).
- **Old checkpoints migrate** (state v4-6 -> v7): every learned weight keeps its meaning, the 3 new inputs and the new output start at 0 / the prior, so the policy
  behaves as before until it is trained; the consequence model (inputs changed) is discarded and re-learns online. Saves are now state v7 and older builds cannot read them.
- Not done: scripted bots never sneak (so the enemy-sneak feature is only non-zero against self-play rivals); the mod's self-play bot (`BotBrain`) ignores the sneak output.

## Gliding camera (display only)
`GlideCamera` + `mixin/EntityViewMixin`: between ticks the AI's camera is drawn on a cubic Hermite curve through the same angles, with the mouse's true velocities
at the tick boundaries as slopes, so the displayed speed is continuous (no corner every 50 ms). Authoritative angles, attacks, ray casts and observations are untouched.
Switch: `Config.GLIDE_CAMERA`. The mixin is fail-safe (`require = 0`, exceptions switch it off and fall back to vanilla). It targets `Entity.getViewYRot/getViewXRot`
with the official Mojang names; it could not be compiled here (no Minecraft jars) - if those names differ in your 1.21.11 build it just does nothing.

## Curriculum
- **Review mixing:** from stage 6, 20 % of training episodes (40 % while a stage is stalled) replay opponents of earlier stages (nearest most often). They never count toward the gate,
  the hop level or the collapse guard. Keeps old skills, and gives a learning signal while the current stage is too hard. `Config.REVIEW_*`, `Curriculum.sampleOpponent`.
- `Curriculum.stalled()` / `reviewShare()`; the status line shows `STALLED ... review share N %`.
- (v7.2, still in) sustained performance gate, adaptive hop level, collapse guard with entry-weight restore and demotion.

## New tests (written, NOT run): `GlideCameraCheck`, `SneakMigrationCheck <old save>` (runs on `training-results-v7.2/checkpoint-300000.bin`, a pre-sneak save), review mixing checks in `CurriculumGateCheck`.
The earlier suite (85 checks) passed after the sneak change and before the review-mixing / glide edits.

## Real rotation follows the curve (v7.3b, written under "no tests / sims": nothing below was run, and the Minecraft classes were never compiled)
`Config.GLIDE_REAL_ROTATION = true`: the player's REAL yaw/pitch (not just the drawn view) move along the same Hermite curve every frame, like a real mouse turning continuously between the 20 Hz ticks.
- `MinecraftFrameMixin` (inject at HEAD of `Minecraft.runTick`, require 0) calls `GlideBridge.frame(player)` once per frame BEFORE that frame's ticks. It sets `yRot/xRot` and `yRotO/xRotO` to the curve position (so vanilla adds no interpolation of its own; the display-only offset is switched off in this mode).
- The curve is played over 85% of a tick and ends EXACTLY on the tick's end angles, so by the time the next tick is due the angles equal what `GameplayRotation` computed. `ActionApplier.apply` also calls `GlideBridge.finish(me)` first, so the attack ray, the look step and the packets of a tick (also back-to-back catch-up ticks) start on the exact end angles. The policy, observations, rewards and the simulator see no change; checkpoints are unaffected.
- Fail-safe: exceptions turn the glide off (plain per-tick rotation); if `runTick` has a different name in your build the injector is skipped. Set the flag to false for the previous display-only glide.
- Known limits: the first frame right after a tick is still vanilla's straight line (partial tick is small); a tick that arrives <42 ms after the previous one (catch-up) sees the finished angles via `finish()`, but the vanilla player packet of that tick may carry a slightly earlier curve position; no in-game test.

## v7.6 review fixes (type-check only; no tests, sims or training were run)
- Found while reviewing v7.5: it did not contain the earlier aim-stage gate fix or the target-speed brake. Both are ported here (`Curriculum.aimSuccess` with acquisition grace + stall relief used by `Trainer` and `PvpSim`; `AimBrake.limit(..., targetVel)` + target-speed estimate in `GameplayRotation`; `Config.AIM_GATE_*`, `AIM_BRAKE_TRACK_TICKS`).
- `GlideCamera.yawOffset/pitchOffset` were changed in v7.5 to return 0 in real-rotation mode, which would have broken the existing `GlideCameraCheck`. They are pure again; `GlideBridge` now skips the display offset when `GLIDE_REAL_ROTATION` is on.

## v7.7: real-rotation glide in the simulator (measurement model; compile-checked only, nothing run)
- `PvpSim` keeps the agent camera speed at the start / end of every tick (`glideV0`, `glideV1`) and exposes `realYawAt(t)` / `realYawSpeedAt(t)`: what the player's real yaw does between ticks (Hermite curve with `Config.GLIDE_REAL_ROTATION`, vanilla's straight line otherwise). `GlideCamera.hermiteSpeed` is the new analytical derivative. The tick-level rotation, attacks, observations and training are unchanged, because the curve ends exactly on the tick's angle (same as in the mod).
- `sim/aimprobe.sh <state.bin> N visual` now also prints "real-yaw speed change between frames" (3 frames per tick), so the glide can be compared with the straight-line model by switching `GLIDE_REAL_ROTATION`.
- The Minecraft-facing code moved out of `GlideBridge` into `GlideReal` (used by the mixin and `ActionApplier`), so `GlideBridge`/`GlideCamera` stay pure Java for the sim and test builds.
- Not modelled: frame timing jitter, catch-up ticks, human mouse input.
