# Stage 9 — Competitive Self-Play League

## Intent

Stage 9 is the open-ended training destination for the existing PPO policy. It does not replace the model, recurrent memory, tactical stack, learned action heads, combat simulator, or Minecraft integration. It changes opponent sampling and evaluation discipline so the learner is exposed to challenging matchups without allowing a small probe to stop or roll back training.

## Curriculum path

- Stages 1–6 retain their existing skill curriculum and action locks.
- Stage 7 enters league self-play after the existing 30-game / 1225-Elo qualification.
- Stage 8 is a league-refinement phase. It advances to Stage 9 after at least 150 league games and a current league rating of at least 1275.
- Stage 9 is continuous PFSP self-play. It has no further promotion gate and does not use the periodic greedy probe or collapse-guard rollback as a training gate.

A manually forced stage remains available through the existing curriculum command. Stage 9 keeps all combat action heads unlocked.

## Opponent pool and PFSP

The training league draws from eligible frozen learner snapshots, an optional configured rival, and all 11 fixed `BotAI` styles. Styles include counter, pressure, baiter, rusher, w-tapper, camper, jump-resetter, spacer, hit-selector, technician, and human-mix.

The PFSP sampler first prefers opponents with an estimated learner win probability in the 50–70% band, with a Gaussian preference around 60%. If none qualify, it selects the closest available matchup. In Stage 9 only:

- historical learner losses and damage deficits increase an opponent's sampling weight;
- the matchup-weakness weight is confidence-scaled by prior games and capped at 2.0x;
- aggressive specialists receive a 1.35x coverage multiplier so pressure styles do not disappear behind aggregate Elo;
- 20% of Stage 9 match sampling is reserved for proven weak matchups whose estimated learner win chance has fallen to 35–50%, weighted toward repeat offenders. This corrective-play slice lets the learner revisit an opponent after Elo has recognized it as stronger, while 80% remains the normal 50–70% PFSP challenge pool.

The sampler does not force a particular learned action, aim correction, combo, jump, or dodge. Opponents continue to use the existing shared `BotAI` combat logic and its fair reaction/aim/attack constraints.

The ratings sidecar keeps backward compatibility with the previous six-column CSV; new matchup records are added to the expanded CSV format. Old CSVs load with zero matchup history, which is treated as neutral until new Stage 9 games accumulate. League Elo is an internal matchmaking rating, not a human ladder rating.

## Non-gating champion evaluation

`ChampionEvaluator` runs only once the curriculum reaches Stage 9. It saves an immutable copy of the learner checkpoint between PPO rounds and benchmarks that copy on a separate daemon executor while training continues. The held-out suite evaluates the candidate against each of the 11 fixed scripted styles, using repeatable per-style seeds and the play-only policy RNG reset for each style.

Default settings:

- `-Dsim.championEvalEvery=250000`: minimum learner-tick interval between evaluation launches.
- `-Dsim.championEpisodes=5`: episodes per fixed style, clamped to 1–10.
- `-Dsim.championSeed=20261101`: base seed for the held-out suite.

A score combines 80% match result (win + half draw) and 20% normalized damage balance for each style. The overall score is 75% mean style score and 25% worst-style score. This deliberately penalizes a checkpoint that dominates easy archetypes but has a severe weakness against one style. The champion is replaced only when the composite score improves.

Artifacts are written beside the learner output:

- `<name>.champion.bin` — best held-out checkpoint found by this evaluator.
- `<name>.champion-best.txt` — best score and checkpoint tick.
- `<name>.champion-evaluations.csv` — one row per completed benchmark.

The ordinary `<name>.bin` remains the latest learner checkpoint. Champion selection never overwrites it, changes PPO weights, changes the curriculum, or pauses training. If an evaluation is already running, later evaluation launches wait until it finishes; the training loop continues collecting and learning. This asynchronous evaluator is part of both offline simulator entry points, `sim/train_parallel.sh` and `sim/run.sh`. The live Fabric trainer shares the Stage 9 league sampling rules and disables Stage 9 collapse rollback, but it does not launch this scripted-simulator benchmark inside the client.

## Important interpretation limits

- Five matches per style is an initial automated regression signal, not a statistically definitive ranking. Increase `sim.championEpisodes` for stronger selection evidence or run a larger fixed-seed evaluation after training.
- The held-out suite currently evaluates the 11 fixed `BotAI` styles; it does not establish performance against human players or live Minecraft clients.
- Self-play Elo is only a matchmaking signal. Compare checkpoints on a fixed suite and, before claiming Minecraft transfer, compare paired combat traces in the simulator and Minecraft 1.21.11.
- Stage 9 cannot repair inaccurate simulator mechanics or a broken mod action/observation pipeline. Simulator-to-Minecraft parity remains a separate required validation step.

## Build and use

The updated parallel trainer is compiled by `sh sim/train_parallel.sh`. Its command line is unchanged:

```sh
sh sim/train_parallel.sh <absolute-total-ticks> <output.bin> [seed] [resume.bin|-] [workers] [rival.bin|-]
```

The target is an absolute learner tick count, not an additive number of ticks. Do not start another long run until the compiled source and checkpoint compatibility have been validated. Stage 9's held-out evaluator is non-gating; a weak evaluation is reported but does not interrupt training.
