# v6 fixes (code inspection only, nothing trained or simulated)

Root causes behind the 1M evaluation (A 100% / D 0%, no jumps/crits/back-steps, 65-95% whiffs, collapse in stage 7):

1. **The evaluation policy was argmax per head** (`actGreedy`). Argmax can never pick a minority action: jump starts at p = 0.12, "no strafe"
   and "back" are never the plurality. A policy that mixes them in training therefore showed 100% one-sided strafe, 0% jump, 0% crit when
   evaluated, and `/rl play` played that deterministic version. Fix: `PpoAgent.actPlay` (camera mean, discrete heads sampled at
   `Config.PLAY_TEMPERATURE`, own RNG) is used by `/rl play`, `PvpSim` evaluation and the probes. `actGreedy` stays for strict checks
   (`-Dsim.strictGreedy=true`; `Config.PLAY_STOCHASTIC=false` restores the old behaviour everywhere).
2. **Entropy floor was on the sum of the discrete heads**, which attack/sprint can satisfy while strafe collapses to one key. Added per-head
   floors for forward/back, strafe and jump (`HEAD_ENTROPY_FLOOR_FRAC`, `HEAD_ENTROPY_BOOST`); attack and sprint are excluded on purpose.
   Jump prior bias -2 -> -1.2 (p 0.12 -> 0.23) so jump-crits are actually tried. Nothing is forced; PPO still decides.
3. **Whiffs**: a swing only counted as pointless when 9 degrees off in yaw and pitch was ignored. Now 6.3 degrees (about the hitbox half-angle)
   and 5.4 degrees pitch; `WHIFF_PENALTY` 0.12 -> 0.2. Pitch is rewarded like yaw (camera progress/jerk/still, facing reward, aim scale).
4. **Stage advancement**: `Curriculum.mayAdvance(..., greedyOk)`. From stage 4 the gate needs the probe of the played policy to land >= 2 hits
   per episode (from stage 6 also dealt >= 0.5 x taken); entering stage 6, 7 or 8 can no longer be forced by the max-tick timer. Win-rate gates are
   unchanged. The mod never sets the probe, so its behaviour is unchanged.
5. **Collapse guard preserved and made faster** in the simulator: `PvpSim.probe()` runs 10 episodes every 15k ticks (play mode, stage opponent)
   and feeds the guard; `CollapseGuard(alpha, patience)` plus a "stopped hitting" rule (window damage < 35% of the best snapshot's, twice) and a
   learning-rate damping (x0.7, floor 0.3) after each rollback. The mod keeps the original constructor/behaviour.
6. **Spacing starts earlier** (stage 5 half weight, stage 6 full). Opponent diversity: the existing BotAI styles/difficulty and the 50k-tick
   minimum snapshot age are untouched.

Kept: 378-input layout, action layout, .bin format (an existing .bin loads: `tests/PlayGateCheck.java <state.bin>`), YAW/PITCH scales.
Checks: `tests/PlayGateCheck.java` (no training/simulation). The mod itself was not built here (Minecraft not available).
