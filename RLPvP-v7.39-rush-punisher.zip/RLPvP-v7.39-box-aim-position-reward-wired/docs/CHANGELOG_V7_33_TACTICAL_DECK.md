# v7.33 Tactical Deck Experiment

## Camera input
- Added `AimInputFilter`, an adaptive degree-per-tick command smoother for yaw and pitch.
- Kept mouse-like camera dynamics downstream (drag, acceleration, jerk, speed limit) and used the existing precision braking envelope to avoid excess lag near a known target.
- Exposed requested, filtered, applied turn and velocity telemetry to the HUD.
- Added standalone pure-Java filter tests and updated the simulation regression compile list.

## Attack input
- Replaced direct `gameMode.attack()` invocation with the 1.21.11 `KeyMapping.set/click(InputConstants.Key)` left-mouse input path; the curriculum charge gate is applied before queuing the click.
- Block-target clicks are suppressed; the HUD discloses the attack binding path and queued-event estimate.
- No OS-level mouse event synthesis or physical device spoofing is attempted. Vanilla still owns hit detection and attack timing.

## HUD
- Rebuilt the HUD into the Tactical Deck: high-contrast dark panel, neon accents, state/stage track, health bars, range/LOS/aim geometry, tactical intent/confidence, camera-filter rows, attack input status, performance metrics, return/results sparkline, toasts, and full diagnostics graphs.
- Added mini, compact/deck, and full/diagnostics display commands.
- Added situational safety/intervention counters and current episode telemetry to the HUD data snapshot.

## Validation
- `AimInputFilterCheck`: PASS.
- `GameplayRotationCheck`: PASS.
- `sh tests/run.sh`: stops at the known baseline `CritSatiationCheck` halfway entropy-taper assertion, also reproducible on v7.31.
- Full Fabric build: NOT VERIFIED because Gradle distribution download was blocked by this environment's DNS/network availability.
