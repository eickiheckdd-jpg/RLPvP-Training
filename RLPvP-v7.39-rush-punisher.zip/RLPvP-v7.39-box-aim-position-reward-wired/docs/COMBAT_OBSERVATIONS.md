# Appended combat observations

The runtime now enables `rlpvp.obsV2` by default and appends 11 combat observations by default. They are inputs only: they do not force actions or add reward bonuses. Override with `-Drlpvp.obsV2=false` or `-Drlpvp.combatObs=false` for controlled ablation tests.

The new features are appended after all existing summary blocks, so indices inside the original 51-value per-tick frame and the previous summary blocks retain their meanings.

| Index in new summary tail | Feature | Definition / scaling |
|---:|---|---|
| 0 | `distance_delta_per_tick` | `(current center distance - previous center distance) / 0.6`, clamped to `[-1, 1]`; positive means the gap widened. The first tick is 0. |
| 1 | `reach_margin` | `(attack reach - eye-to-nearest-hitbox distance) / 1.5`, clamped to `[-1, 1]`; positive means the target hitbox is within reach. |
| 2 | `intercept_angle` | Cosine of the angle between own and opponent horizontal velocity vectors; `+1` same direction, `-1` opposite directions, `0` if either speed is negligible. |
| 3 | `crosshair_on_target_box` | `1` when the current look ray reaches the opponent hitbox within attack reach and the target is visible; otherwise `0`. Uses the same ray/line-of-sight rule as the action applier. |
| 4 | `miss_to_hit_ratio` | Recent whiffs divided by recent landed hits plus one, clamped to `[0, 1]`. |
| 5 | `crit_efficiency_ratio` | Recent critical hits divided by recent swings plus one, clamped to `[0, 1]`. |
| 6 | `sprint_hit_efficiency_ratio` | Recent sprint hits divided by recent swings plus one, clamped to `[0, 1]`. |
| 7 | `damage_differential_trend` | `(recent damage dealt - recent damage taken) / 20`, clamped to `[-1, 1]` over the configured hit-memory window. |
| 8 | `sprint_modifier_active` | Observable proxy: actual sprinting + forward command + sprint command + positive forward velocity. It is **not** a direct engine flag or a guarantee of bonus knockback. |
| 9 | `ticks_since_sprint_interruption` | Ticks since a transition away from active sprint-forward movement, capped at 40 and divided by 40. It begins at the capped/unknown value. |
| 10 | `attack_during_iframe` | One-observation pulse when the policy selected attack while the observed opponent hurt timer was above zero. |

## Checkpoints and compatibility

The new summary inputs change the network input width. Checkpoint loading now maps the existing summary blocks by meaning (base hit memory, motion memory, sprint follow-up memory, opponent memory, knockback timing) and zero-initializes incoming weights for new input columns. This preserves as many existing inputs as possible, but is a warm-start rather than a guarantee of identical behavior. A fresh training run is recommended to learn useful weights for the new inputs.
