# v7.35 Smooth Aim / Minecraft Render Fix

## Findings

The live project had two integration problems that the simulator-only camera tests could not catch:

1. `Config.GLIDE_REAL_ROTATION` defaulted to `true`. `ActionApplier.apply()` writes the tick-end yaw/pitch to `LocalPlayer` immediately, while `MinecraftFrameMixin` interpolates the player fields at the head of a later `Minecraft.runTick()` call. That mixes an immediate tick-end write with a later render-frame animation, so the displayed camera can briefly show the endpoint and then move back onto the glide curve. This is a plausible source of the tick-boundary shake seen in Minecraft.
2. `EntityViewMixin` targeted `Entity`, but Minecraft 1.21.11's `LocalPlayer` declares its own `getViewYRot(float)` and `getViewXRot(float)` overrides. An injection only into the base implementation does not reliably intercept calls dispatched to those overrides, so the safer display-only path was not hooked at the class that owns the actual local-player method.
3. `GlideCamera.push()` passed the unquantized `CameraDynamics` velocity to the Hermite renderer even though its displacement was the quantized angle actually applied to the player. When a tick's applied rotation rounded to zero, a nonzero tangent could animate a tiny out-and-back loop even though the authoritative camera did not move. Large or opposite-sign tangents could also overshoot the tick endpoint.

## Changes

- Default to display-only rendering. The player's authoritative yaw/pitch, policy observations, raycasts, and attacks remain tick-end values; only the rendered local-player view is interpolated.
- Keep the older mutation-on-every-frame route available only as an explicit diagnostic opt-in: `-Drlpvp.glideRealRotation=true`.
- Inject directly into `LocalPlayer.getViewYRot(float)` and `LocalPlayer.getViewXRot(float)`.
- Build an absolute render angle from the tick endpoint and the stored displacement. This avoids assuming that `LocalPlayer`'s view getter is doing vanilla previous/current interpolation.
- Clamp Hermite tangents to the actual applied displacement and use a shape-preserving bound. Zero-displacement ticks have zero tangents, preventing phantom wiggles from residual internal velocity.
- Use preallocated slope buffers, avoiding per-tick array allocations in the hot render-controller path.
- Add `GlideCameraSmoothingCheck` to the aim-stability script, covering zero movement, monotonic large turns, reversal behavior, endpoint equality, and continuous absolute yaw at the ±180° boundary.

## Validation performed

Passed:

- `./sim/aimstability.sh` — existing aim stability check and new glide interpolation checks
- `./sim/prediction.sh` — predictive combat check
- `./sim/regression.sh` — 43 outcome assertions, 12 sprint-follow-up assertions, combat-observation memory check

Not verified:

- The full Fabric/Loom build could not start because the wrapper could not resolve `services.gradle.org` in this environment.
- The patch has not been visually tested inside a running Minecraft client. The fix addresses source-level timing/hook/tangent issues, but live FPS/TPS, graphics mods, other camera mods, and input mods may still affect perceived smoothness.

## References checked

- Fabric events documentation: https://docs.fabricmc.net/develop/events
- Yarn 1.21.11 `LocalPlayer` mappings, which list local-player view-rotation overrides: https://mappings.dev/1.21.11/net/minecraft/client/player/LocalPlayer.html
- Mojang-mapped 1.21.11 `Entity` methods for view yaw/pitch: https://mappings.dev/1.21.11/net/minecraft/world/entity/Entity.html
- Toronto Metropolitan University, PD control and noise sensitivity: https://pressbooks.library.torontomu.ca/controlsystems/chapter/9-3proportional-derivative-control/
- ISA, Fundamentals of PID Control (derivative behavior and noisy measurements): https://www.isa.org/intech-home/2023/june-2023/features/fundamentals-pid-control

## Overshoot / residual-drift correction

- `AimBrake.limit()` previously returned the policy command unchanged at exactly zero target error. If the virtual mouse still had momentum or residual acceleration, that bypass allowed the view to coast through the target at the zero crossing. The zero-error branch now brakes residual motion in the opposite direction, while preserving an already-opposing command.
- Reduced the predictive stop envelope's fixed slack from 0.50 degrees to 0.25 degrees (about 1-2 legal mouse-counts at common sensitivities), so it begins tapering the push closer to the target.
- Added `AimBrakeCheck` assertions to the regular aim-stability run. The tests exercise large target approaches, near-zero residual motion, a moving target, and the new zero-error brake path.

The deterministic simulator checks show sub-degree overshoot under the tested chase policies. This is not a guarantee for every Minecraft configuration or opponent; an in-client test is still needed.


## Gameplay-rotation-first integration

The live apply order is explicitly: policy effort -> adaptive command filter -> bounded CameraDynamics acceleration/jerk/drag -> predictive AimBrake (when target error is known) -> legal mouse-count displacement -> authoritative yaw/pitch write. Rendering never feeds back into gameplay.

The LocalPlayer view hook now linearly interpolates only the authoritative rotation delta already applied for that tick. It no longer uses Hermite tangents or hidden physical velocity to create a different rendered path. A gameplay-pipeline regression test now directly drives GameplayRotation with a hard target and checks the actual per-tick angles, start acceleration, and overshoot guard. This is intentional: gameplay is smoothed at the controller first; rendering merely displays those smoothed tick endpoints between frames. In particular, an internal velocity that produces zero legal applied rotation cannot animate the crosshair by itself. The Hermite utility remains available to simulator-only camera experiments but is no longer used by the live rendered view.

Additional checks verify exact linear interpolation of the applied yaw/pitch delta even when internal velocities are deliberately set far above the turn actually applied, along with zero-motion, endpoint, reversal, and continuous absolute-yaw boundary cases.
