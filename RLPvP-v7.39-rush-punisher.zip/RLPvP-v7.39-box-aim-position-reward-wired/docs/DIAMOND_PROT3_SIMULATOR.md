# RLPvP v8.1 — Diamond Sword + Full Diamond Protection III

## Requested duel setup

Both participants receive:

- Main hand: unenchanted `minecraft:diamond_sword`.
- Head: `minecraft:diamond_helmet` with Protection III.
- Chest: `minecraft:diamond_chestplate` with Protection III.
- Legs: `minecraft:diamond_leggings` with Protection III.
- Feet: `minecraft:diamond_boots` with Protection III.
- 20 HP, no potion effects, no shield, no absorption, no regeneration.
- Flat, block-free duel arena; UHC blocks and crafting are intentionally not simulated.

The per-piece armor values in the profile sum to 20 armor points and 8 toughness. For ordinary melee damage, the four Protection III levels contribute 12 EPF before the usual 0–20 cap.

## Source-reference mapping

The implementation is independently written and maps to the behavior in the supplied Java 26.3 reference files:

| Minecraft method / type | Implemented behavior |
|---|---|
| `Player.attack` | Attack-strength-scaled base damage; critical attack multiplies the base portion by 1.5 |
| `Player.getCurrentItemAttackStrengthDelay` | Full-charge interval of `20 / attackSpeed` ticks |
| `LivingEntity.hurtServer` | Damage-cooldown comparison before armor; only excess damage from a stronger hit is accepted during the cooldown |
| `LivingEntity.actuallyHurt` | Defense processing order: armor, Resistance, then enchantment protection |
| `LivingEntity.knockback` | Knockback power scaled by `1 - knockback_resistance`, horizontal old velocity halved, grounded vertical impulse capped at 0.4 |
| `EnchantmentHelper.getDamageProtection` | Protection totals are derived from the equipped armor pieces, rather than an undocumented magic constant |
| `CombatRules` | Armor-toughness reduction and magic-protection multiplier |

The current source browser's 26.3 `CombatRules` reference is available at:
https://mc-packet-reference.netlify.app/26.x/source/net/minecraft/world/damagesource/combatrules/

The source reference shows the armor equation using `2 + toughness / 4`, a minimum effective armor of 20% of total armor, a maximum of 20 effective armor, and a divider of 25; it then applies the magic-protection multiplier using the same 25-point scale. The repository code implements the equations in its own form and does not bundle copied Minecraft classes.

## Reference damage values

Using the model's double-precision arithmetic:

- Normal fully charged hit: 7 raw → 1.89 after diamond armor → 0.9828 HP after EPF 12.
- Full critical hit: 10.5 raw → 3.2025 after armor → 1.6653 HP after EPF 12.
- Half-charge hit (attack strength 0.5): 2.8 raw → 0.6384 after armor → 0.331968 HP after EPF 12.

These are ordinary-melee fixtures without effects, shielding, damage-type bypass tags, attack-side armor-breaking enchantments, or other item effects. The calculated damage is a reproducible reference value, not a substitute for an in-game test against the exact server build.

## Training command

```sh
./sim/train_diamond_prot3.sh <totalTicks> <out.bin> [seed] [resume.bin|-] [workers] [rival.bin|-]
```

Example:

```sh
./sim/train_diamond_prot3.sh 3000000 rlpvp-diamond-prot3-3m.bin 20261030 - 4 -
```

The wrapper explicitly sets `-Dsim.kit=diamond_prot3`. The current simulator uses a combat-first flat arena without blocks, matching the requested sword kit rather than UHC.

## Fidelity boundary

This version improves the accuracy and auditability of the weapon/armor/damage calculations. It does not embed or execute Mojang's server classes. Movement, collision, ray tests, client/server packet processing, and network effects are still custom simulator models, and full parity has not been validated against a running Java 26.3 server. The test suite proves the modeled fixtures and integration path, not a universal 99% accuracy claim.
