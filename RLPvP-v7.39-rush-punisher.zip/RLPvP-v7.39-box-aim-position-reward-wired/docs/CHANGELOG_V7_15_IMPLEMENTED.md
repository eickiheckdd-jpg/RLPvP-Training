# RLPvP v7.15 implementation notes

Implemented in the source tree in this ZIP:

- **Model selection:** `-Drlpvp.model=base|m10|m15`. `base` remains the default (`128x128`); `m10` uses `960x960`; `m15` uses `1024x1024x512`.
- **Checkpoint transfer:** same-depth widening warm-starts copy old weights into matching neurons and zero new connections, preserving the old network's function for added hidden units. Input-layout migration preserves the original 20 summary inputs. Shrinking hidden layers and changing depth are rejected explicitly. Consequently, `m15` must be trained from scratch; automatic transfer from the two-layer models is intentionally not supported.
- **Optional situational observations:** `-Drlpvp.obsV2=true` appends eight motion-memory features (aim-error trend, strafe run, movement-key change rate, movement efficiency, opponent direction-flip rate, opponent lateral speed, closing trend, and ticks since movement change). It is off by default. Old v7 checkpoints can warm-start into OBS_V2; the consequence/world model is discarded and retrained because its input layout changed.
- **Movement pathology reward guard:** small penalties for prolonged stagnant movement, forward input while overlapping, immediate strafe reversals, repeated sprint toggles, and strafe that worsens aim. These penalties are capped per episode and do not prohibit any action.
- **Adaptive PPO learning rate:** adjusts the LR scale once per rollout from the observed approximate KL, with configured lower/upper bounds.
- **Collapse guard:** failure classification uses a rolling 60-episode evidence window and a Wilson upper confidence bound, rather than demoting from a tiny noisy window. A demotion restores the exact stage-entry weights; a rollback does not erase the failure evidence. Best weights can be copied through `bestWeights()`.
- **Diagnostics/tests:** `ModelInfo` reports model dimensions, parameter count, approximate weight memory, and a CPU forward-pass timing. `RlTests` and `MotionMemoryCheck` cover parameter counting, widening transfer, Wilson statistics, and optional observation layout.

## Running

- Base: `sh sim/run.sh 5000 state.bin 123`
- Wider 2-layer model: `JAVA_TOOL_OPTIONS='-Drlpvp.model=m10' sh sim/run.sh 5000 state-m10.bin 123`
- Wider model + motion features: `JAVA_TOOL_OPTIONS='-Drlpvp.model=m10 -Drlpvp.obsV2=true' sh sim/run.sh 5000 state-m10-v2.bin 123`
- Diagnostics: `JAVA_TOOL_OPTIONS='-Drlpvp.model=m10 -Drlpvp.obsV2=true' sh sim/modelinfo.sh` (change properties as needed).
- Minecraft-free tests: `sh tests/run.sh`

`m10` has substantially higher CPU and memory cost than `base`; benchmark on the target device before long training. `m15` adds another hidden layer and is fresh-training only. These changes do not claim that the resulting policy has improved win rate; that requires a controlled training/evaluation run.
