# v7.35 – combat-intelligence, measured and repaired

## What was found (benchmark: `sim/combatbench.sh <state.bin> 200 0.6,1.0`, same checkpoint/seeds/opponents)
The v7.34 intelligence suite, as shipped, was HARMFUL on the c063057c checkpoint: win rate vs Aggressive d=0.6 fell 41% -> 7-15%,
vs Strong d=0.6 33% -> 5-15%. Ablation (`-Drlpvp.intelOff=<mask>` / `CombatBench ablate`) traced it to rules that fire on a threat
estimate that was >0.55 on ~25% of ticks and combo-risk >0.46 on ~28%: they zeroed forward/sprint, forced strafes and cancelled
our own swings whenever the enemy swung ("no opportunity" while trading), so we stopped trading hits.

## Changes (existing systems improved, nothing duplicated)
- Config.PLAY_STACK (0 policy / 1 planner / 2 full) and Config.INTEL_OFF ablation bits (-Drlpvp.stack, -Drlpvp.intelOff).
  Default INTEL_OFF=96: the suite's candidate scoring and candidate guidance are OFF (measured: guidance alone cost ~14 points vs Strong).
- SituationalStateInterpreter.State.tradeable: in reach, on target, fully charged. Suite penalties now target only speculative swings
  (`!tradeable`) instead of every swing during an exchange.
- ComboEscape: only inside a real multi-hit combo; it only steps out of the attacker's line (no sprint/forward removal).
- MovementIntentCoordinator: keeps sprint legality; leaves the line only when we cannot hit back and are in the enemy's reach.
- Risk evaluator: removed the anti-pressure and anti-sprint penalties.
- PvpSim.beginLinks now calls agent.resetSituationalEpisode (state used to leak across episodes); PvpSim.opponentKey lets evaluations model one
  persistent player so habit memory is exercised.
- New: sim/CombatBench.java, sim/combatbench.sh, diagnostics CombatIntelligenceSuite.DIAG.

## Result (200 episodes per cell, Wilson 95% in docs/combatbench_v7.35_result.txt)
Aggressive d=0.6: policy 41.0% -> planner 49.0% -> full 52.5%.  Strong d=0.6: 33.0% -> 35.0% -> 44.0%.
At d=1.0 (very strong bots) all variants are statistically tied (16-20%): the stack no longer hurts, but it does not fix a weak policy.
Aim jitter: AimStabilityEval PASS (jitter amplitude ratio 0.017) – existing AimInputFilter already meets it; unchanged.

## Not done / honest limits
- Gains are modest (+8..11 points at d=0.6, none at d=1.0); "superhuman" is not claimed. Only one checkpoint (c063057c, an older weak one) was benchmarked.
- The sim bots do not play like a specific human, so per-player habit adaptation is only exercised weakly.
- Trainer/BotBrain/HUD (Minecraft classes), real left-click simulation and the HUD rewrite from the earlier request were not touched or compiled; Gradle blocked.
