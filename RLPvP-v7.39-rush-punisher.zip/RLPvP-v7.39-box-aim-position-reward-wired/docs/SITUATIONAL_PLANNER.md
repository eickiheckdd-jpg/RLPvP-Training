# Situational consequence learning (state format v5)

This branch adds an online one-step dynamics model and uses it to rank candidate actions during `/rl play`.

## What changed

- **Consequence model:** learns `current observation + action -> next observed combat frame` from transitions collected during `/rl start`. Targets are the frame the environment actually returned, not labels such as "critical", "sprint hit", "strafe", or "combo".
- **Action look-ahead:** after enough transitions and an acceptable held-out prediction error, `/rl play` compares the current policy's action with a small, exploratory set of alternatives. Each is scored using predicted health advantage, terminal outcomes, and the value critic's estimate of future return in the predicted next state. This can prefer a different movement, attack, jump, sprint, or camera action depending on the current state.
- **No intrinsic technique bonus by default:** critical-hit, sprint-hit, combo, first-hit, reset-gap, punish, counter-strafe, dodge, disengage, and critical-setup reward bonuses are disabled when `OUTCOME_ONLY_REWARDS=true`. They can still be counted for evaluation/diagnostics. Damage, received damage, win/loss, and the generic aiming/progress shaping remain. The direct penalty for an obviously pointless swing remains too.
- **No scripted response table:** the model and policy do not contain rules such as "if opponent swings, strafe left". They receive the opponent's observed state and history and learn from the transition outcomes.
- **Checkpoint compatibility:** version-4 `state.bin` files load. The actor is preserved. The critic is reinitialized because it was trained on the previous technique-bonus objective. The new consequence model begins untrained and must collect transitions before it is allowed to control play. Newly saved checkpoints use version 5 and include its learned weights and validation statistics.

## How to use it

1. Back up `config/rlpvp/state.bin`.
2. Install/build this source. Load the existing state with `/rl start` (do **not** use `fresh` if keeping the learned actor matters).
3. Train in a safe, repeatable duel environment. `/rl status` reports the world-model transition count, validation MAE, and whether planning is on. The policy still learns normally while the model warms up.
4. Use `/rl save` or `/rl stop` to write the version-5 checkpoint. Then use `/rl play` to evaluate the policy and action look-ahead.
5. Compare it with the previous checkpoint on the same opponents and scenarios; track win rate, damage dealt/taken, whiff rate, and behavior under different opponent movement patterns.

Planning stays off until there are at least 20,000 transitions, at least 1,000 held-out samples, held-out MAE is at most 0.20 AND the model beats the persistence baseline (next frame = current frame) on health squared error by at least 2 % (v6). The old MAE-only gate was passed by a model that was worse than persistence on damage, because most of the 48 features barely change. This is still a guard, not a guarantee that every individual prediction is correct. If the model never passes the gate in a particular environment, it safely falls back to the PPO policy.

## Important limitations

- The model predicts one tick ahead, not an exact long-horizon future. The critic supplies the longer-term estimate.
- Candidate search is intentionally small to control per-tick CPU cost. It is not exhaustive search.
- Training dynamics on a simulator and deploying on a live server are different domains. Prefer collecting and validating transitions in the same kind of environment in which the model will be used.
- PPO training samples directly from the actor to preserve correct likelihood ratios. The look-ahead reranker is used in play mode after it has been trained. This means the planner is learned from training transitions, not hand-coded technique identities.
- Generic aim, camera smoothness, closeness/progress, spacing, and time shaping still exist. They are state-based assistance rather than named-technique bonuses, but they can still bias behavior. Run a controlled ablation before removing them, since a fully sparse reward from scratch can be difficult to learn.

## v6 update: residual targets (measured with `sim/probe.sh`)
- The consequence model now predicts the **change** of each feature (scaled by its running residual size) and the gradient-norm clip is 5 instead of 1.
- Held-out, fixed-seed simulator transitions (100k training transitions, shipped 1.3M-tick actor), same data before and after:
  health squared-error skill vs persistence -706 % -> +7.9 %; AUC for "damage I deal" 0.566 -> 0.942, for "damage I take" 0.486 -> 0.792;
  predicted enemy-health drop for a swing in reach vs the same state without a swing: -0.050 / -0.054 -> +0.015 / +0.0005 (real drop after a swing: 0.083).
- State version 6. v4 and v5 files load; a v5 consequence section is read and discarded (its weights meant something else), the actor is untouched.
- Known limits: damage magnitude is still ~5x too low (ranking is good, scale is not), and a one-tick horizon cannot see hits that land after network delay. Next step: multi-tick damage targets.
- Not measured yet: end-to-end win rate with planning ON vs OFF (needs the critic retrained first).
