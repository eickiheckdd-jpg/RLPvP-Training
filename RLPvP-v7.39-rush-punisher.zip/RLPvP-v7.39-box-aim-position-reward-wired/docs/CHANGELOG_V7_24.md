# v7.24 - techniques no longer fade as the curriculum advances
Cause: technique bonuses were annealed (cosine) down to 25% over 1.5M technique ticks while the damage reward stayed at full strength, so every technique
(sprint hit, w-tap/s-tap, jump reset, crit...) slowly stopped paying relative to plain trading, and the policy drifted away from them by stage 6-8.
- Config.TECH_FLOOR 0.25 -> 1.0: no fade (anneal() kept; set the floor lower again to bring it back).
- Anti-fade (TechniqueDiscovery.retain): each technique keeps a slow average (rate 5e-4/exchange) of its share of my exchanges. If its current share drops more than 25% (deadband) below that average it pays up to 1.6x - but only when the exchange is WON (same settlement as before), so it cannot be farmed and no style is forced.
  Dominance (monoculture slowdown) and advantage (press/safe by HP lead) still apply, so the choice stays situational.
Not run: tests, sims; Trainer.java (Minecraft classes) never compiled. Sim/agent classes compile.
- Bug: the sprint on/off head had no entropy floor (only fwd/back, strafe, jump did), so it could collapse to never/always sprint and take sprint hits and w-taps with it. Added SPRINT_ENTROPY_FLOOR_FRAC 0.2 (boost x3 on that head's entropy bonus, skipped while sprint is locked).
- Fix: first anti-fade draft used a high-water mark of a noisy EMA, which would have given every rare technique a permanent boost; replaced by the slow average + deadband.
- Crit vs sprint (from a v7.23 run log: 653 crits / 846 hits, 42 sprint hits at stage 8): in vanilla a crit is +50% damage and a sprint hit is base damage + knockback, so plain
  damage reward always preferred crits. Now, while crits dominate my recent exchanges, (a) the EXTRA crit damage in the reward is paid only dominance(CRIT) of its value
  (TechniqueDiscovery.rewardDamage; real HP/win/metrics untouched), and (b) won sprint-hit / knockback-follow-up exchanges pay up to 2x (complement). Dominance threshold 0.6 -> 0.5, floor 0.3 -> 0.2.
  When crits are the situational choice (share <= 50%) nothing changes. Not run (StyleCheck thresholds may need the new 0.5/0.2).
- Polish: the combined technique pay multiplier (dominance x anti-fade x complement x advantage) is capped at TECH_MULT_CAP 2.5; the window log shows "critDiscount -X HP" (crit damage removed from the reward) next to the style shares.

## Scripted bots rewritten around techniques (BotAI, shared by the sim and the mod)
The bots now FIGHT with the techniques the agent has to learn to beat and to use, instead of just orbiting and swinging:
- w-tap and s-tap after a swing (s-tap steps back and widens the gap), sprint hits forced at the click, combo chase (the bot stays on a knocked-back agent, using the new In.tHurt),
  bait feints (step out while the agent's sword is charged, punish the whiff), hit select (only trade when the agent is recharging / in hurt frames / the bot is ahead),
  far-edge spacing pokes, jump-crits from safe spots, and a small jump-reset habit in every style (RESETTER/TECHNICIAN strong).
- New styles SPACER (far-edge pokes + s-taps), SELECTOR (hit select + combo), TECHNICIAN (situational mix). STRONG mix: counter 9 / pressure 9 / baiter 10 / rusher 7 / wtapper 10 / camper 7 / resetter 8 / spacer 11 / selector 11 / technician 18 %.
- In.tHurt is wired in PvpSim and BotBrain (agent.hurtTime). Not run: tests/sims (BotAICheck, BotBench); BotBrain.java (Minecraft classes) never compiled.
