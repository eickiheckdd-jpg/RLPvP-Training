# v7.29 - audit: why techniques could go unused (includes v7.28 anti-jump bots)
Compile-checked only (sim + agent classes). No tests, sims or training run. Trainer.java / BotBrain.java (Minecraft classes) never compiled.

## Found and fixed
1. **Per-episode technique cap ran out (real bug).** TECH_EPISODE_CAP (max(2.5, 2 hits)) was a fixed total per episode, but kit-aware episodes are up to 4x longer than the 300-tick reference.
   In armor the first 3-4 paid exchanges used the whole cap, so every later sprint hit / spacing / bait / jump reset in the episode paid 0 - the late-episode techniques were unrewarded and faded.
   The cap now scales with the episode length (TechniqueDiscovery.setEpisodeTicks, up to 4x; called from PvpSim.assignKits).
2. **w-tap and s-tap had no reward at all.** Only crit / sprint hit / follow-up / combo / first hit / punish (= hit select) / dodge (= defensive) / jump reset / spacing / bait existed, and in the simulator a tap changes nothing
   mechanically (the sprint key re-sprints at once), so nothing ever pushed the policy to tap. New techniques W_TAP and S_TAP: after a GROUNDED hit, release W (w-tap) or tap S (s-tap) within 5 ticks, then press W + sprint again
   within 8 ticks. The tap joins the exchange the hit opened, so it pays only if that exchange is won (an s-tap also needs me to take nothing back): 0.30 / 0.35 of a typical hit, subject to the usual diminishing returns,
   dominance / anti-fade / advantage multipliers (w-tap is a pressure technique, s-tap a safe one). In.fwd / In.sprintKey are filled in PvpSim and Trainer. Logs / CSV show wTap and sTap.
3. (v7.28) Jump-crit loop counter: bots read the agent's jump and back out of reach (BotAI.antiJump), so crits need gamesense.

## Checked, no change needed
- SpamGuard does not punish taps: movement flips / sprint toggles are free within SPAM_HIT_GRACE (20) ticks of a real hit and SPAM_TAKEN_GRACE after being hit.
- Dense shaping (closeness / progress / spacing, <= 0.02 per tick) and the idle fade are tiny next to a hit (~1.2 in armor); they do not forbid backing off, baiting or waiting.
- Stage 6+ unlocks every action head; hit select and defensive play are already paid as PUNISH (hit while the enemy's sword is low) and DODGE.

## Noted, not changed
- DODGE is paid 166/166 in the logs (any movement while the enemy swings in reach and nothing lands), the biggest earner; it is capped at 3 per episode so it cannot dominate, but it is not selective. A candidate for tightening if the policy starts shuffling in reach.
