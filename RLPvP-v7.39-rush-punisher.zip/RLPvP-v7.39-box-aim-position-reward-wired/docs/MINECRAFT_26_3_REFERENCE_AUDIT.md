# RLPvP v8 physics update — Minecraft 26.3 reference audit

This update uses the user-supplied Minecraft 26.3 decompiled reference bundle as a behavioral reference. It does **not** copy Mojang source into the simulator.

## Implemented in this prototype

| Reference behavior | Reference class / method | Simulator implementation |
|---|---|---|
| Attack cooldown = 20 / attack-speed attribute | `Player.getCurrentItemAttackStrengthDelay()` | `Minecraft26Physics.attackCooldownTicks()`; `E.scale()` now reads the kit's sword attack speed (1.6 => 12.5 ticks) |
| Jump velocity is max(current Y velocity, jump power) | `LivingEntity.jumpFromGround()` | `Minecraft26Physics.jumpVelocity()`; jump reset no longer overwrites a stronger existing knockback lift |
| Knockback halves prior horizontal velocity, adds normalized push, and caps grounded Y at 0.4 | `LivingEntity.knockback()` | `Minecraft26Physics.applyKnockback()` |
| Attribute-modified friction = clamp(1 - (1 - friction) * modifier, 0, 1) | `LivingEntity.computeModifiedFriction()` | `Minecraft26Physics.modifiedFriction()` |
| Ground speed adjustment on blocks with friction > 0.6 | `LivingEntity.getFrictionInfluencedSpeed()` | `Minecraft26Physics.frictionInfluencedSpeed()` |
| Ground/air horizontal drag and vertical drag | `LivingEntity.travelInAir()` | `horizontalDrag()` and `verticalDrag()` |
| Input vector normalization and yaw transform | `Entity.getInputVector()` | `Minecraft26Physics.inputVector()` |

The normal flat-ground defaults remain compatible with the previous simulator: block friction 0.6, gravity 0.08, jump strength 0.42, horizontal drag 0.546 on ground / 0.91 in air, and vertical drag 0.98. This means the default benchmark should remain comparable rather than silently changing the learned task.

## New reproducible physics controls

These JVM system properties can be set when launching simulator scripts:

- `-Dsim.blockFriction=0.98` — ice-like supporting-block friction.
- `-Dsim.frictionModifier=1.0` — attribute modifier applied to block friction.
- `-Dsim.airDragModifier=1.0` — attribute modifier applied to horizontal / vertical air drag.
- `-Dsim.gravity=0.08` — gravity attribute.
- `-Dsim.jumpStrength=0.42` — jump-strength attribute.

The simulator reads these once at startup, so use separate processes for separate physics profiles.

## Performance note

The movement and knockback helpers write into per-entity scratch arrays reused across ticks. The hot path avoids allocating a new vector array every simulation tick.

## Still not implemented / not yet validated

This is a fidelity increment, **not a 99% Minecraft replica**. The following are still important gaps:

- Full `Entity.move()` swept AABB collision against block voxel shapes, step-up logic, edge backoff, and supporting-block checks.
- Per-block friction and per-block collision shapes in a generated world (the current duel remains a flat floor with its existing arena boundary).
- Fluids, ladders / climbables, powder snow, effects, and other movement modifiers.
- Complete 26.3 item component / attribute modifier resolution, including item-specific attack speed and damage.
- Full enchantment-driven armor effectiveness and all damage-source interactions.
- Exact server packet acceptance, teleport correction, and client interpolation behavior under live server load.

The supplied source bundle shows that 26.3 has attribute-driven movement and additional collision behavior. We should not claim accuracy until the simulator is tested against a running 26.3 server with deterministic movement, attack, and knockback fixtures.

## Validation performed

- `sim/regression.sh` — existing outcome, follow-up, and combat-observation checks pass; new physics formula checks pass.
- `sim/prediction.sh` — pass.
- `sim/aimstability.sh` — pass.
- `sim/bench.sh 5` — completes. Its output is the same as the unchanged baseline because the default flat-ground constants are intentionally preserved. This benchmark uses an idealized scripted agent and is not evidence of a trained-policy win-rate improvement.
- `sim/run.sh 10000 ...` — completes and writes a smoke checkpoint.

A full Fabric Gradle build and live Minecraft 26.3 server parity test have not been performed here.

The broad `tests/run.sh` harness now compiles successfully after its missing source dependencies were added. It passes the physics, memory, reward, curriculum, guard, camera-interpolation, and other checks reached before `GameplayRotationCheck`; that existing controller test currently reports four failures (small correction overshoot, large-turn overshoot, steady-state stability, and fine aiming). Those camera-controller failures are outside this physics patch and remain open. The focused simulator checks listed above pass.

## v8.1 target-kit combat fidelity update

The requested kit is now an explicit equipment profile (`MinecraftRules.DIAMOND_PROT3_EQUIPMENT`), rather than only aggregate magic numbers:

- `minecraft:diamond_sword`: player base attack damage 1 + item modifier 6 = 7; base attack speed 4 + item modifier -2.4 = 1.6.
- Diamond helmet / chestplate / leggings / boots: armor values 3 / 8 / 6 / 3 and toughness 2 each.
- Protection III on all four pieces: generic melee EPF 3 + 3 + 3 + 3 = 12.
- No sword enchantments, Resistance, shield, absorption, or regeneration.

`MinecraftRules.damageBreakdown()` now exposes the ordered stages: raw incoming damage, after armor/toughness, after Resistance, then after Protection. The armor equation and Protection multiplier were cross-checked against the 26.3 `CombatRules` reference: https://mc-packet-reference.netlify.app/26.x/source/net/minecraft/world/damagesource/combatrules/ . For this unenchanted sword profile, the attacker-side armor-effectiveness enchantment hook has no modifier.

Reproducible fixtures from the model:

- Full normal sword hit: 7.0 raw -> 1.89 after armor -> 0.9828 HP after Protection III.
- Full critical: 10.5 raw -> 3.2025 after armor -> 1.6653 HP after Protection III.
- 0.5 attack strength: 2.8 raw -> 0.6384 after armor -> 0.331968 HP after Protection III.

`tests/DiamondProt3KitTest.java` exercises those fixtures and the integrated `PvpSim.strike()` path. `sim/train_diamond_prot3.sh` explicitly pins this kit. After this update, `sim/regression.sh`, `sim/prediction.sh`, `sim/aimstability.sh`, and `sim/bench.sh 5` passed; a 1,026-tick, two-worker profile-specific training smoke run also completed and wrote a checkpoint.

These checks prove the simulator's internal fixtures and training launch work. They do **not** prove live-server parity: packet handling, full 26.3 movement semantics, ray selection, and the whole server tick remain custom/simplified, and no deterministic integration test against a live vanilla server was performed here.
