# Stage-7 collapse: cause and fix

Reproduced on a fresh simulator run (seed 1, current code, before this fix): stages 5 and 6 were passed on one 30-episode window each
(53 % win, 5/10 greedy probe), the agent entered stage 7 at tick ~100k, won 9 % -> 5 % -> 0 %, then fled (hits 0, whiff 100 %, damage taken 0.0,
return -0.6 instead of -21). The guard never fired: it discards the best weights at every stage change, and its first "best" was taken after
3 windows of the already collapsed stage. Removing the minimum-time rule had also removed the learning budget that used to sit between gates.

Fix (no timers; all performance based):
- Promotion must be SUSTAINED: the window stays at the gate for `GATE_HOLD_EPISODES` (30) consecutive episodes. Each collapse of stage s+1 raises the gate for leaving stage s by 5 % (max 15 %).
- A newly promoted agent meets the easiest bot first (`BotDifficulty.START` 0.15 -> 0.0); it still adapts upward on wins.
- `CollapseGuard` keeps the weights a stage was entered with. `GUARD_FAIL_WINDOWS` (5) windows in a row at <= `GUARD_FAIL_WIN` (10 %) wins (crushed or fleeing) restore them, damp the learning rate and call `Curriculum.demote()`: back one stage, earn the promotion again against the higher gate. Aim stages 1-4 are never demoted.
- A window scoring below `GUARD_BEST_FLOOR` is never stored as the "best" checkpoint.
- Wired into `Trainer` (mod) and `PvpSim`. Demotion counts are not saved across restarts.

Tests: `tests/GuardCheck` (entry restore + demotion, hard-but-not-collapsed stage is left alone, aim stages never demoted, no collapsed best), `tests/CurriculumGateCheck` (sustain, bump, demote).
NOT yet measured: a full fresh run with the fix (the baseline collapse log is the only end-to-end evidence so far). `Trainer.java` and `ActionApplier.java` were not compiled (no Minecraft jars here).
