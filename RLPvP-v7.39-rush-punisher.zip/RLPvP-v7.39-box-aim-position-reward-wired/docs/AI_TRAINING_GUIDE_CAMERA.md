# Training guide for AI agents: physical mouse controller

Audience: an AI/automation that will TRAIN and EVALUATE this project in the offline simulator. The code was patched and unit-checked but
**never trained**; your job is to find out whether it works and to report honestly. Read sections 1-3 before running anything.

## 1. What changed (and what did not)
| Item | State |
|---|---|
| Camera action = continuous relative control, never absolute camera targets | same output layout, new meaning: hand effort instead of direct delta |
| `CameraMap` response curve, `Config.CAMERA_EXPONENT = 3`, `CAMERA_LINEAR_MIX = 0` | **new**: applied = sign(a)·\|a\|^3 |
| Camera std limits (`LOOK_STD_INIT`, `LOOK_LOGSTD_MIN/MAX`) | derived from the effort curve; they bound policy exploration, not angle displacement |
| Observation layout (378 inputs), action layout (13 outputs), `.bin` format | unchanged. Old `.bin` files may load structurally but are semantically incompatible with the new controller; train from scratch (see 2) |
| `CameraDynamics`, `Config.CAMERA_DYNAMICS = true`: hand effort -> drag/acceleration/jerk limits -> relative mouse displacement | **new controller** (docs/CAMERA_DYNAMICS.md). Observation inputs 27/28 carry actual mouse velocity (layout unchanged) |
| Sensitivity-multiplier head | **not implemented** (docs/CAMERA.md explains why; section 8 says what it would take) |
| `LOOK_SMOOTH` low-pass filter | unchanged, **leave at 1.0 (off)** in the first experiments: docs/CAMERA.md measured that filtering a policy trained without it makes the camera worse |
| v6 items: play-mode policy (`actPlay`), per-head entropy floors, greedy stage gate + probes, collapse guard | unchanged, all active |

Every camera-control consumer maps policy effort through `CameraMap.apply` before it enters the controller: `ActionApplier`, `BotBrain` (self-play bot), `PvpSim`
(agent + self-play bot), and `PvpProbe` (which uses `CameraMap.inverse` for effort-space control). Every place that moves the camera also goes through `CameraDynamics` (`ActionApplier`, `BotBrain` self-play, `PvpSim` agent + self-play bot). If you add another consumer of `a[0]`/`a[1]`, route it through `CameraMap` too.

## 2. Rules
1. **Train from scratch.** Do not resume from a checkpoint trained with v9 spring/damper dynamics: its policy learned to output a desired velocity, whereas this version interprets output as hand effort. The binary format may still load, but the learned controller is mismatched. To create a direct-control baseline, set `CAMERA_DYNAMICS = false` and evaluate separately.
2. **One change per experiment, at least 3 seeds per variant.** Single runs differ by tens of points in this project (see docs/*.md); a
   win-rate difference below ~10 points on 50-60 episodes is noise.
3. **Report play-mode AND strict-greedy numbers** (section 5). Never report sampled training-window win rates as the result.
4. Do not tune several constants at once; do not edit the reward to hide a camera problem; do not add random jitter to the real camera.
5. Keep all logs. If a run collapses, say so and keep the log; do not restart silently.

## 3. Build and run (JDK 21, no Minecraft needed)
```sh
S=src/main/java/com/rlpvp; OUT=/tmp/cls; mkdir -p $OUT
javac -d $OUT $S/Net.java $S/Symmetry.java $S/PpoAgent.java $S/Config.java $S/CameraMap.java $S/CameraDynamics.java $S/Reward.java $S/Curriculum.java \
  $S/ActionMask.java $S/ObsStack.java $S/ObsLayout.java $S/HitMemory.java $S/FrozenPolicy.java $S/CameraReward.java \
  $S/CollapseGuard.java $S/TechniqueReward.java $S/BotAI.java $S/BotDifficulty.java sim/com/rlpvp/*.java tests/*.java
java -cp $OUT com.rlpvp.CameraMapCheck            # must print ALL OK before you train
java -cp $OUT com.rlpvp.CameraDynamicsCheck       # must print ALL OK before you train
java -cp $OUT com.rlpvp.PlayGateCheck             # play mode / gate / entropy-floor checks
sim/run.sh 1200000 out/A_seed1.bin 1               # train (about 10-15 min per 1M ticks); resumable: 4th arg = resume.bin
sim/train.sh $OUT out_dir 1200000 1                # same, in resumable segments (restart-safe)
java -cp $OUT com.rlpvp.PvpEval out/A_seed1.bin 60                       # play mode (default): camera mean, discrete heads sampled
java -Dsim.strictGreedy=true -cp $OUT com.rlpvp.PvpEval out/A_seed1.bin 60   # argmax per head, for comparison only
java -cp $OUT com.rlpvp.CamSmoothEval out/A_seed1.bin 60                 # step jerk / turn per tick / direction flips
```
`sim/run.sh` and the other scripts call `javac`; if only a JDK module compiler is available use `java -m jdk.compiler/com.sun.tools.javac.Main`.
Time budgets: if your environment kills long jobs, run `sim/run.sh <total> out.bin <seed> out.bin` repeatedly (it saves every 25k ticks and
resumes); the collapse guard's best snapshot and the league pool are not persisted across restarts (only the weights/stage are).

## 4. Experiment plan (in this order)
| ID | Change (edit `Config.java`, recompile) | Purpose |
|---|---|---|
| E0 | none (cubic effort curve, physical dynamics ON) | the candidate |
| E1 | `CAMERA_EXPONENT = 1f`, `CAMERA_DYNAMICS = false` | baseline = the old direct, linear camera, same seeds |
| E2 | `CAMERA_DYNAMICS = false` (cubic only) | isolates the response curve |
| E3 | `CAMERA_EXPONENT = 1f` (dynamics only) | isolates the dynamics |
| E4 | E0 with `CAMERA_LINEAR_MIX = 0.2f` | fallback if aim is slow to form |
| E5 | E0 with `CAM_ACC_MAX_FRAC = 0.85f` | experiment if movement accelerates too slowly; evaluate before keeping |
Run E0 and E1 first (3 seeds each). Run E2/E3 to attribute differences; E4/E5 only if E0 fails a check in section 6.
Each: seeds 1, 2, 3, >= 1.2M ticks.
Constants are `static final`, so each variant is a separate compile into its own classes dir; never mix classes from different variants.

## 5. What to log and report (per run, from the training log and PvpEval)
Training log line: `tick, stage, eps, win, loss, dealt, taken, ret, hits, crit, sprint, whiff, cam deg/t, ent, probe(...)`.
* `cam deg/t` = mean |applied yaw| per tick while training (sampled). Compare E0 vs E1 at the same stage.
* `probe(...) hits/ep ... gate ok|HOLD` = play-mode probe feeding the stage gate and the guard; note every `HOLD` and `ROLLBACK`.
* Stage timeline (tick at which each stage was entered). For reference the pre-change run in docs/train_1M.log entered stage 4/5/6/7/8 at
  ~344k/374k/432k/472k/536k ticks; the greedy gate may make yours slower, which is intended, not a failure.
PvpEval (play mode, then strict greedy), vs WALK / AGGRESSIVE / STRONG and the difficulty sweep: win/loss/draw, dealt/taken, hits/ep, whiff %,
strafe D/A split, back %, jump %, crit %, `jerk` (step-to-step change of the aimed yaw step near the target; lower = smoother).
CamSmoothEval: `step jerk`, `turn/tick`, `flips/ep` (direction reversals). Report E0 next to E1 for every seed.

Report format (a table, one row per run) and one paragraph of interpretation. State the number of episodes behind each cell.

## 6. Pass / fail checks for the camera change
Judge E0 against E1 (same seeds). All numbers in play mode.
1. **Aim forms.** Stages 1-2 should leave by the on-target gate (`AIM_GATE_ON_TARGET` = 60% of ticks on target) and not only by the timer
   (`STAGE_MAX_TICKS` 90k/100k). If stage 1 or 2 needs the timer in most seeds while E1 does not: FAIL -> run E2, then E3.
2. **Fighting quality is not worse.** win rate vs WALK/AGGRESSIVE/STRONG within noise of E1 (about 10 points), `hits/ep` not lower, whiff % not
   higher by more than about 10 points.
3. **Smoother.** `jerk` and `step jerk` lower than E1 at comparable win rate, `flips/ep` not higher, turns above 20 deg/tick rarer.
4. **No new collapse.** Compare rollback count and the stage-7/8 trajectory with E1.
5. **Dynamics respect their limits.** The `camera dynamics (yaw)` line of PvpEval: peak |acc| and peak |jerk| must not exceed the printed limits (they are hard limits in `CameraDynamics`; a violation is a bug, report it with the log).
Smoother but weaker fighting = not a success. Report that trade-off instead of declaring victory.

## 7. Failure modes and what they usually mean
* **Aim never forms / `cam deg/t` stays near 0 for 60k+ ticks.** Cubic response with a tiny std gives almost no gradient signal near 0.
  Fix in this order: `CAMERA_LINEAR_MIX = 0.2`, then exponent 2. Do not raise `LOOK_STD_INIT` by hand (it is derived).
* **Camera bang-bang (raw output saturates at +-1, large `jerk`, many flips).** The policy found that the cubic only moves when it
  saturates. Raise `CameraReward.JERK`/`OVERSHOOT`, or the linear mix; check the camera std is not pinned at `LOOK_LOGSTD_MAX`.
* **Entropy of the camera std pinned at a limit.** `LOOK_CLAMP_RESTORE` pushes it back; if it stays pinned for long, report it.
* **Win rate fine in training windows but the probe shows 0 hits (`HOLD`).** That is the sampled-vs-played mismatch the v6 notes describe;
  trust the probe.
* **Aim forms late or tracking of strafing bots is worse than E1/E2.** The camera now lags the command by about 2-3 ticks (90% of a full-speed command after 3 ticks). Compare E0 with E2 (cubic without dynamics) to see if the lag is the cause, then try E5 or `CAM_ACC_MAX_FRAC`/`CAM_JERK_MAX_FRAC` up; report the trade-off.
* **One-sided strafe / no jumps in strict-greedy output.** Expected argmax artifact; check play mode before calling it a bug.

## 8. If the response curve is not enough: sensitivity head (design only, not built)
Third camera output S in [0, 1] (sigmoid of a new logit) scaling BOTH axes: applied = CameraMap(a) x S x scale. Needed edits: `Config`
(`OFF_*` offsets, `ACTION_SIZE` +1, `N_ACT`), `PpoAgent` (sampling, `evalPolicy` log-prob and gradient, `actGreedy`/`actPlay`, prior bias),
`ActionMask`, `Symmetry` (S is mirror-invariant), `ActionApplier`, `BotBrain`, `PvpSim` (all camera sites listed in section 1),
`Observation.encodeAction` / the sim copy (keep 7 floats: encode the applied step, so layout stays 378), `Net` output size. Every old `.bin` stops
loading (output layer size), so old saves need a migration or a fresh start. Expect a flat valley in (a, S); consider parametrising S as a
bounded Gaussian in logit space with a small entropy bonus, and train it only after E0/E1 are understood.

## 9. Honesty checklist before you hand results back
- [ ] CameraMapCheck and PlayGateCheck passed on the exact classes you trained with
- [ ] same seeds for E0 and E1, number of episodes stated, noise level stated
- [ ] play-mode and strict-greedy results both given
- [ ] collapses, rollbacks, HOLDs and failed runs listed, not dropped
- [ ] no claim about real Minecraft behaviour: this is simulator-only evidence
