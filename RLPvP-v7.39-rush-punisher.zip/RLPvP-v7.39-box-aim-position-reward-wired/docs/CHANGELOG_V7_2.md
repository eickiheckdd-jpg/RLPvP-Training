# v7.2 (on top of v7.1 rotation-trained)

**Fixed (verified in the simulator)**
- **Stage-2 deadlock.** Fixed 12-30-tick hops made the stage-2 gate unreachable (0 % for 1M ticks; 73 % with hops off). Hop frequency is now an adaptive level
  that starts at 0 and rises with success; stage 2 requires the gate at level >= 0.7. A fresh run now leaves stage 2 at about tick 90k.
- **Hard-coded stage override.** `PvpSim.main` called `sim.cur.force(3)` ("user-requested override"), so every simulator run was forced to stage 3.
  Removed; use `-Dsim.forceStage=N` when you really want a fixed stage.
- **Misleading log.** The training line showed the kill rate (always 0 in aim stages). It now ends with the gate success rate, hold counter, episodes in stage and hop level.

**Added**
- `sim/pipeline.sh <outdir> <ticks> [seed] [checkpointEvery] [evalEpisodes]`: train, checkpoint, final evaluation (`eval.txt`) and a results README in one command; refuses to overwrite.
- Tests: adaptive hop level (rises, falls, capped, never below 0, only in the stationary stage), stage 2 not left on the gate alone.

**Not verified:** anything in the Minecraft mod (`BotBrain.hopLevel`, `Trainer`): I could not compile it here (no Minecraft jars). The changes are three small lines.
