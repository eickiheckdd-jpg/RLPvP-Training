# v7.9 (on top of v7.8 tech-discovery). Static work only: nothing was run (no tests, simulations, training); a compile-only `javac` pass over the pure-Java core, simulator and test sources was done, the mod-side files (Minecraft jars needed) were not compiled.

## 1. More faithful simulator (`MinecraftRules`, `PvpSim`)
- **Exact combat arithmetic** (from the game's formulas, not verified against a running game): attack-strength scaling (0.2 + s^2 * 0.8), Sharpness (+0.5 * level + 0.5, scaled by s, NOT multiplied by the crit), crit x1.5 on the base damage only, armor + toughness
  (`damage * (1 - clamp(armor - damage / (2 + toughness / 4), armor / 5, 20) / 25)`), Resistance, enchantment protection (EPF, cap 20), knockback resistance, absorption, optional regeneration.
- **Invulnerability window like vanilla**: during the 10 "protected" ticks a STRONGER hit now goes through with only the excess over the previous hit (no knockback, no new window). Before, any hit in the window was ignored.
- **Kits**: `-Dsim.kit=naked` (default = the previous behaviour, so old baselines stay comparable) | `iron` | `diamond` | `diamond_prot` | `netherite` | `random` (a mixed pool, per episode, per fighter).
- Not modelled (still): arena walls / other blocks, water, fall damage, shields, potions other than Resistance, ender pearls. The policy cannot observe armor, so under `random` it learns an average.

## 2. Faster learning
- **`sim/train_parallel.sh <ticks> <out.bin> [seed] [resume|-] [workers]`** (`ParallelPvpTrain`): K simulators in parallel threads + ONE learner. Strict barrier rounds (collect in parallel -> stop everything -> PPO updates -> copy weights back), so no concurrent weight writes. Same curriculum (now thread-safe: its methods are synchronized),
  rewards, collapse guard (runs on a probe copy between rounds; a rollback/demotion is copied into the learner) and checkpoint format. Expect up to about K x the experience per second on a K-core machine; this is the design intent, NOT a measurement.
  Caveats: later rollouts of a round come from weights 1..K-1 updates old (PPO clipping absorbs it); runs are not bit-reproducible; the saved world model is worker 0's.
- **Consequence model trains on every 2nd transition** (`Config.CONSEQUENCE_TRAIN_EVERY`): about half its per-tick cost, in the sim and in the mod (validation samples unaffected). Set to 1 to restore the old behaviour.

## 3. Detection range (instead of a search behaviour)
`Config.TARGET_RANGE` 16 -> 48 and `TARGET_LOSE_RANGE` 24 -> 64 (48 = the usual player tracking distance; farther players are not loaded on the client). An earlier draft had a scripted enemy search; it was removed again.
Caveat: the distance input is `dist / 6` (clamped), so beyond 6 blocks the policy only knows "far" and uses the yaw/pitch error to turn and approach; it was trained at 3-6 blocks. `EPISODE_TICKS` is still 300 (15 s): a long approach uses part of it.

## Tests added (written, not run): `tests/MinecraftRulesCheck.java` (combat formulas). `tests/ConsequenceModelCheck` trains 2x as many transitions to compensate for the stride.
