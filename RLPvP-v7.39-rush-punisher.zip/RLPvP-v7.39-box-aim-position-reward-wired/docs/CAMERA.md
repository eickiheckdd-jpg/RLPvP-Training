# Camera: why it looked robotic, what changed, what the numbers say

> **Historical measurements warning:** The numerical comparisons below were recorded before the physical mouse controller in this experimental branch. They are useful context about the old filter, but they are not performance results for the new hand-effort / drag model. The new model has passed pure-Java controller checks only; its camera smoothness and PvP performance still need fresh training and evaluation.

## Why it looked like a robot
1. **Stair-stepping at 20 Hz (the big one, fixed).** `ActionApplier` turned the camera once per game tick and then did
   `yRotO += dYaw`. Vanilla renders the camera by interpolating from `yRotO` (last tick) to `yRot` (now) over the 50 ms of the next
   tick. Moving `yRotO` along with `yRot` told the renderer "the camera was already there": it stood still for 50 ms and then
   jumped. At 60+ FPS that is 2-3 identical frames and a snap, 20 times a second. A real mouse moves every frame.
   **Now `yRotO` / `xRotO` are left alone**, so every 50 ms step is interpolated at your frame rate. No retraining is needed.
2. **A 20 Hz controller with no hand dynamics.** The policy picks a new look delta every tick with no acceleration or
   deceleration, and `/rl play` uses the noise-free mean. Direction can reverse in one tick and rates stay perfectly constant.
3. **Perfect centring.** A human crosshair drifts a few degrees and corrects; the agent holds it dead centre.

## What is in this build
* The render-interpolation fix (always on).
* `Config.LOOK_SMOOTH` / `LOOK_SMOOTH_POLES`: an optional low-pass filter on the look delta (1.0 = off, default). It keeps the total
  angle and spreads each flick over several ticks (bell-shaped speed, like a hand). The simulator has the same filter
  (`-Dsim.lookalpha=0.7`), and `sim/CamSmoothEval` measures it (`sim/eval.sh`-style: `java com.rlpvp.CamSmoothEval state.bin 60`).

## Measured (simulator, greedy / play mode, 50-60 episodes per cell, so about +-10 points of noise)
**1. Filter on a policy that was NOT trained with it: do not do this.**

| opponent | off | 0.8 | 0.6 | 0.45 |
|---|---|---|---|---|
| WALK win % | 80 | 70 | 50 | 12 |
| STRONG d=0.2 win % | 6 | 10 | 0 | 2 |
| AGGRESSIVE d=0.4 win % | 10 | 8 | 0 | 2 |

The policy does not know about the lag, over-turns to compensate (turn per tick 3.6 -> 14 deg) and the camera becomes *less* smooth
(step jerk 1.9 -> 3.7). Smoothing has to be part of what the policy trains against.

**2. Fine-tuned 300k ticks with the filter at 0.7** (`models/experimental_state_smooth0.7_1300k.bin`, trained from the 1M state):
training win rate recovered from 24 % to about 40 % (unfiltered training: 47-52 %), crits went up. Played with the filter:
WALK 80 %, STRONG d=0.2 5 %, AGGRESSIVE d=0.4 3 %, i.e. about equal on easy opponents and a little worse on the hard ones.
But its camera is not smoother by the jerk metric (step jerk 3.9-5.8 vs 1.9-2.7 for the original): it learned bigger turns to
compensate for the lag. So the filter alone does not buy a calmer camera; **do not enable it for the shipped model.**

## What I would do next (in this order)
1. Test the interpolation fix in game: it is the only change that should be visible at once.
2. If you still want a more human camera, change the REWARD, not the actuator: raise `CameraReward.JERK` / `OVERSHOOT`, and train
   for a long time (the 20 Hz decision loop is the real limit). A longer fine-tune with `LOOK_SMOOTH` 0.7-0.8 is the other option.
3. Do not add random jitter to the real camera: it costs aim and adds nothing the interpolation did not already fix.

## Action space and physical mouse control
* **Relative deltas, never absolute targets (already the case, unchanged).** The camera head outputs a change of yaw/pitch per tick
  (`ActionApplier`), not a target angle, so the agent cannot teleport the crosshair; the only way to a far target is several ticks of turning.
* **Response curve: `CameraMap`, `Config.CAMERA_EXPONENT = 3`.** applied = sign(a) * |a|^3 (optionally blended with a linear share,
  `CAMERA_LINEAR_MIX`). A raw output of 0.1 supplies 0.1% of the maximum hand effort, 0.5 supplies 12.5%, and 1.0 supplies full effort.
  The physical mouse model then converts effort into a limited acceleration, speed and relative displacement. Small raw outputs provide delicate effort control. Actual angle change is time-integrated by `CameraDynamics`, so it cannot be inferred from this curve alone. PPO optimises the RAW action; the curve is only
  applied where the action enters the mouse controller (`ActionApplier`, `BotBrain` self-play, and `PvpSim`).
* **Std limits are converted, not copied.** A cube amplifies tails, so equal 1-sigma noise would give frequent random full-speed flicks (the
  first version of this change did: about 5% of ticks at the largest std, found by `tests/CameraMapCheck`). Now the START std has the same
  MEAN applied hand effort as the old linear control (0.36 scale-equivalent units at yaw scale) and the LARGEST std is judged at 2 sigma (15% of maximum effort). Sampling effort
  above 20 scale-equivalent units is 0.4% of ticks at the largest std. Linear (`CAMERA_EXPONENT = 1`) reproduces the old constants exactly.
* **Not implemented: a separate "sensitivity" output S in [0, 1]** (movement = action x S x max speed). It would change `ACTION_SIZE`
  (every old `.bin` would stop loading), add a head to the PPO sampling / log-prob / gradient / mask / mirror code and to the action observation,
  and the two-factor product has a flat valley (many (a, S) pairs give the same turn), which makes PPO's ratio noisy. The response curve gives the
  same two regimes (fine control near 0, strong hand effort at the limits) with no layout change. If the curve is not enough, see
  `docs/AI_TRAINING_GUIDE_CAMERA.md` section 8 for what the sensitivity head would need.
* **Old saves:** the v9 binary may still load structurally, but its policy learned to command velocity rather than hand effort, so it is not a compatible starting checkpoint for the physical mouse controller. Train a fresh policy. `tests/CameraMapCheck.java` checks curve math only; it does not prove aim quality.

## Physical mouse dynamics
See `docs/CAMERA_DYNAMICS.md`. The camera head outputs hand effort; `CameraDynamics` models mouse acceleration, surface/hand drag, jerk limits and bounded speed, then integrates relative mouse displacement into camera rotation. This changes the action semantics from the v9 spring/damper controller, so a fresh checkpoint must be trained. Controller tests alone do not prove the learned aim is better.
