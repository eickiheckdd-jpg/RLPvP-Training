# v7.10 (on top of v7.9.1). Static work only: no tests, simulations or training were run; a compile-only `javac` pass covered the pure-Java core, simulator and test sources (not the mod files, which need the Minecraft jars).

## 1. Simulator desync: delayed knockback (combos with ping)
In vanilla the server computes the victim's new velocity and sends it as a packet; the victim's client applies it one latency later and keeps walking meanwhile (usually INTO the attacker). That gap is what lets an attacker chain hits.
`PvpSim.knock()` now models it: each fighter has `kbDelay` (about its link's one-way delay, 0-4 ticks, 0 while the curriculum's lag is off, i.e. stages <= 5); the velocity is computed at hit time (a second knockback of the same hit builds on the first) but applied `kbDelay` ticks later,
replacing the victim's own movement (`timers()`). The agent experiences this both as attacker and as victim. The existing link model (delayed views, jitter, stalls, delayed click packets) is unchanged. Not modelled: server-side position corrections / rubber-banding.

## 2. SpamGuard (jump and sneak), permanent, small
- **Jump:** each jump costs 0.006 and opens a 30-tick window; a real damaging hit inside it refunds 0.02 (once per hit), so a jump that leads to a hit is net +0.014, one that leads nowhere is net -0.016, and when unjustified jumps exceed about one per 33 ticks an extra per-tick penalty grows with the excess.
- **Sneak:** 0.0015 per tick, 0.008 per toggle, and a per-tick penalty once more than 12 % of recent time is spent sneaking.
- Only heads unlocked by the curriculum are charged (sneak is locked until stage 6). Sizes are about 20-50x smaller than a real 7 HP hit (about 0.35 x W_DAMAGE), so exchanges still decide what is worth doing; nothing forbids a technique.
- Applied in the simulator and the mod; the training log line ends with `spam: jumps N (refunded R, unjustified U) sneak X% toggles T net V` (all `Config.SPAM_*`).
- Existing technique-discovery bonuses (crit, sprint hit, knockback follow-up, combo, first hit, punish, dodge) are unchanged; the combo bonus pays on real consecutive hits.

## Tests added (written, not run): `tests/SpamGuardCheck.java`.
## Limits: the guard is a heuristic - a jump that avoids damage without a hit is not refunded (the dodge bonus in TechniqueReward pays that separately). Whether the delayed knockback produces more combos, and whether the spam costs are well sized, can only be seen by training and evaluating.
