# PFSP League, Humanized Opponents, Aim Stabilization, and HUD Optimization

This update is applied to the supplied RLPvP project. The Fabric mod remains on Minecraft Java **1.21.11**; the standalone simulator continues to use its Minecraft **26.3 reference implementation**. No checkpoint schema or network parameter dimensions were changed by the league, HUD, or config additions.

## 1. Stage 7 PFSP Elo league

Stage 7 no longer uses the old greedy-probe pass/fail gate. Stages 7 and 8 use the league opponent pool; the transition from stage 7 to stage 8 requires at least 30 decided league matches and a current rating of at least 1225 Elo.

The pool contains frozen policy snapshots (at least 50,000 learner ticks older than the current policy) and 11 fixed scripted profiles. PFSP computes the expected agent win probability from Elo, first restricts candidates to the 50–70% band, and samples with a preference centered on 60%. When no candidate is in-band, it uses the closest-rated candidate instead of returning no opponent. Elo uses K=24 and updates both sides after decided wins, losses, and draws.

Live mod data is stored under `config/rlpvp/league/ratings.csv` with frozen snapshots under `config/rlpvp/league/snapshots/`. The simulator stores its ledger and snapshots alongside the output checkpoint in `<output-name>.league/`. The ledger records the current player, each script, each frozen snapshot, and `checkpoint:<ticks>` rating snapshots. Manual `/rl save` also records a checkpoint rating.

The 50–70% range is an Elo-estimated expected score, not a promise that every opponent's next rolling sample will fall inside that range.

## 2. Human-oriented scripted bots

`BotAI` now supports fixed style IDs for PFSP sampling. The HUMAN profile includes 2–4 extra reaction ticks, aim drift, modest overshoot/momentum, pressure lapses, and click attempts paced at approximately 6.7–10 CPS. The actual attack cadence is still constrained by the simulator's / Minecraft's weapon cooldown. All 11 styles have fixed IDs so a league match is reproducible by profile.

These parameters are **plausible defaults, not calibrated player statistics**. No real-player fight telemetry was supplied in this task, so this update does not claim statistical calibration against a human dataset.

## 3. Repeated left/right camera movement

Two sources of unnecessary camera reversals are addressed:

- Play-time tactical candidate evaluation now preserves the policy's baseline yaw and pitch while it compares alternate discrete movement/attack actions. Candidate resampling can no longer silently replace the camera command every tick.
- The shared aim input filter damps the first moderate sign reversal while tracking near a target; a repeated second sample confirms the reversal and is allowed through. This is active in both the live mod and simulator because they share `GameplayRotation` / `AimInputFilter`.

This targets command chatter and planner-induced camera changes. It has passed the focused filter/candidate tests, but it still requires an in-game A/B check to confirm that the reported left/right motion is gone in the user's exact build and checkpoint.

## 4. HUD rendering cost

The existing HUD layout, text, colors, and visual elements are preserved. The changes reduce repeated rendering work:

- history traces read directly from the ring buffers instead of building ordered array copies every frame;
- arc sine/cosine values are cached once and reused;
- panel background rows that previously issued many draw calls are batched while retaining the same stepped-corner geometry.

No HUD element was intentionally removed or hidden. FPS improvement has not been measured in Minecraft yet, so this is a rendering-cost optimization, not a measured FPS claim.

## 5. Configurable reward and observation groups

`config/rlpvp-rewards.properties.example` documents per-term reward multipliers. The defaults are all `1.0`, preserving the existing reward function. Copy it to `config/rlpvp-rewards.properties` to override weights.

`config/rlpvp-observations.properties.example` documents observation groups. Existing groups can be zeroed with `observations.disable=...` or scaled using `observations.scale.<group>=...` (0–10). The observation vector length stays fixed so existing checkpoints remain loadable. This registry exposes existing features; it does **not** let a config file invent arbitrary new observation columns, which would require a checkpoint migration.

Both sidecars are read once at process startup. Restart the game/simulator after editing them.

## 6. Standing checkpoint evaluation

`sim/standing-eval.sh <episodes-per-style-per-seed> <checkpoint.bin> [other-checkpoints...]` benchmarks each supplied checkpoint against all 11 fixed styles and four fixed seeds. It reports per-style and aggregate 95% score confidence intervals, includes a worst-style lower-bound term in selection quality, writes `standing-eval.csv`, and copies the selected checkpoint to `best-checkpoint.bin`.

`sim/standing-eval-dir.sh <episodes-per-style-per-seed> <directory>` finds every `.bin` checkpoint under a directory and evaluates them together. For a simulator run, a typical directory to evaluate is `<output-name>.league/snapshots/`. The evaluation is deliberately a separate step; it is not silently run during every training tick because the full fixed-seed suite can be expensive.

## 7. Deliberately not included: exact-simulator lookahead

The proposed short multi-step lookahead evaluator was **not** merged. `PvpSim` currently mutates coupled client/server entities, network queues, attack validation, combat timers, and camera state in-place. A reliable exact rollout requires a complete fork/snapshot of that state (or deterministic replay) for every candidate action. The existing learned `ConsequenceModel` is not an exact Minecraft 26.3 rollout, so relabeling it as one would be misleading. No lookahead change should be retained until a real forked rollout is implemented and `combatbench` demonstrates a repeatable improvement.

## Verification notes

Verified in this workspace:

- Standalone simulator source compilation and a short PvpSim checkpoint smoke run.
- A forced stage-7 simulator smoke run produced league matches, updated match counts for the sampled scripted opponents, and persisted a `checkpoint:<ticks>` Elo row.
- Standing-evaluation smoke run completed all 11 styles × four seeds and wrote its CI/best-selection outputs (the smoke checkpoint was intentionally untrained; its score is not a performance result).
- Focused tests passed: `OpponentLeagueCheck`, `CameraCandidateCheck`, `ObservationRegistryCheck`, `AimInputFilterCheck`, `BotAICheck`, `PvpSimNetworkTest` (11/11), `CurriculumGateCheck`, `Minecraft26PhysicsTest` (25/25), and `Minecraft263CombatTest` (34/34), among others.

Known test caveats:

- `GameplayRotationCheck` still reports four failures (`small 2 deg correction`, `overshoot toward 120 deg`, `stability`, and `fine aiming`). I ran the same check against the original uploaded project and reproduced the same four failures there; they are pre-existing in the supplied base.
- `CritSatiationCheck` still reports its late-stage entropy halfway assertion. The same assertion fails against the original uploaded project too.
- The complete `tests/run.sh` run did not finish within the 240-second limit. Individual checks listed above were run separately.
- A Fabric/Gradle build could not be completed: the wrapper attempted to download Gradle 9.5.1 from `services.gradle.org`, but DNS/network access failed. This archive is therefore **not claimed to be a verified Fabric build**.
- No live Minecraft FPS, camera, or combatbench A/B result is claimed.
