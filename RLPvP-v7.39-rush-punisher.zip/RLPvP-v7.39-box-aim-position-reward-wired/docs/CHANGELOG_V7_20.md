# v7.20 (on v7.19)

## Added: target angular-velocity inputs (part of the optional OBS_V2 group, `-Drlpvp.obsV2=true`)
The v7.19 whiff diagnosis showed that against moving opponents most misses are near-misses (aimed within 6 degrees, target moved / was delayed). The agent had no explicit input for how fast the target crosses its crosshair. `MotionMemory` now outputs two more features (V2 group 8 -> 10 inputs, `Config.V2_FEATURES`): target yaw / pitch angular velocity = d(aim error) + own applied turn (deg/tick, +-10 / +-5 = +-1, yaw wrap-safe). Fed from `ActionApplier.yawDelta()/pitchDelta()` in the mod and `lastYawTurn/lastPitchTurn` in the simulator. Old checkpoints load with weight 0 on the new inputs (existing input-mapping). `OBS_V2` stays OFF by default.
Test: `MotionMemoryCheck` (run with `-Drlpvp.obsV2=true`): passes, incl. stationary target while turning = 0, moving target = its motion, +-180 wrap.

## Evidence (preliminary, one seed, training-log windows only)
500k ticks from scratch, seed 11, current sim (armored kit), same code except the flag:
- OBS_V2 on: stage 7 reached ~350k; training windows in stage 7 at 350k / 400k / 450k / 500k ticks: win 26 / 31 / 33 / 56 %, loss 55 / 54 / 48 / 31 %, dealt 15.5-18.5 HP.
- OBS_V2 off (v7.19 baseline run): stage 7 windows ended at win 19 -> 2 -> 0-4 %, dealt 8.6-12.7 HP (fell toward passivity).
This looks better but is ONE seed, ~60-episode windows, sampled training policy (not the controlled 30-episode evaluation: that run was cancelled before finishing). Treat it as a promising signal, not a proven improvement. Not verified: final `PvpEval`, other seeds, Gradle build, in-game behaviour (Trainer.java edit not compiled with Fabric).
Run it: `JAVA_TOOL_OPTIONS=-Drlpvp.obsV2=true sh sim/run.sh 500000 out.bin 11 -` then `JAVA_TOOL_OPTIONS=-Drlpvp.obsV2=true sh sim/eval.sh out.bin 30`.
