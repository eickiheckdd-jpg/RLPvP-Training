# v7.26 - stage-phased rewards (from the "adaptive PvP agent" notes) on top of the crit-satiation / sprint-reset / entropy build
Base: bf15d80d (v7.25-crit-sprint-entropy-updated). Compile-checked only (sim + agent classes); no tests, sims or training were run; Trainer.java (Minecraft classes) was never compiled.

## Fixed: the flat +2.0 / +0.2 / +3.5 per-hit bonus was out of proportion in armor
Those numbers are right for an unarmored 7 HP hit (= 4.2 reward) but a hit in diamond + prot 3 is worth ~1.2 reward, so a sprint hit paid ~2.9 hits and a crit ~1.7 hits on top of its damage, and it was
paid whether or not the exchange was won (sprint-only / crit-only hit spam). Now: bonus x SATIATION_SCALE 0.6 x (kit hit unit / 4.2) x curriculum technique weight (0 before the technique stage).
Same shape (crit healthy < 35 % density, satiated above it, sprint hit largest). Old 6-arg method kept for the existing check.

## Stage phases (Curriculum.Weights gets orbit and airPen)
- Phase 1, stages 1-3: damage / facing only (unchanged).
- Phase 2, stages 4-5: movement. Stage 5 adds the CIRCLE-STRAFE reward (Reward.orbit): bearing change of me around the enemy per tick (saturates at 0.06 rad/tick),
  only while facing it (< 20 deg), 1.5-5 blocks away and not hit this tick. Weight 1.0 at stages 5-6, 0.6 at 7, 0.4 at 8. Max ~0.012 per tick (x dense scale), so it cannot dominate.
- Phase 3, stages 6-8: advanced mechanics. Whiff-punish / bait, spacing, jump reset, w-tap/s-tap payouts (v7.22-25, hit-unit scaled, exchange-settled) plus:
  - AIR-HIT PENALTY: being hit while airborne costs 0.25 typical hits (weight 0.5 at stage 6, 1.0 at 7-8): jump-crit exposure.
  - SPRINT-RESET MOMENTUM: sprint-hit / follow-up pay shrinks by up to 50 % when the enemy was already separating from me in the ticks before the hit (no extra points for a hit on a fleeing target).
- Phase 4 (self-play, stage 8): unchanged league.
- Entropy: late-stage floor raised 0.4x -> 0.7x (the notes recommend MORE entropy against fixed styles; a low entropy before sprint hits are explored locks the crit habit in).

## Notes
- Sim and mod are mirrored (PvpSim / Trainer): orbit, air hit and separation history are in both. Trainer.java must be built in your Gradle environment to confirm.
- Existing checkpoints load unchanged (no observation or checkpoint layout change in this version).
