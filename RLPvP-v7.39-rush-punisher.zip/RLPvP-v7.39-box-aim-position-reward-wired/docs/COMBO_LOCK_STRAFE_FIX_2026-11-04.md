# RLPvP v7.38 — combo-lock and strafe-continuation patch

Date: 2026-11-04  
Target mod: Minecraft Java 1.21.11  
Branch patched: the v7.38 / compact-126-input PPO source archive. This is not the separate RLPvP-Next branch.

## What changed

### 1. The policy can express a sustained strafe

The prior action space could choose left, neutral, or right every tick, but it had no explicit continuation decision. The new v9 policy head adds a conditional Bernoulli `holdStrafe` output. When the normal strafe head chooses neutral, the policy may choose to retain the previous left/right input. An explicit left, right, or neutral decision still overrides it. The runtime releases the latched input when the AI is stopped/released.

The new head starts with a conservative bias (`-1.5`) so loading an existing policy does not suddenly cause it to hold a direction all the time. Existing v8 checkpoints with 14 output logits warm-start into the 15-logit v9 head; existing actor/critic weights are copied and the new head is initialized. Checkpoint version is now 9. The original 3M checkpoint is not overwritten.

This is an action capability, not a scripted A-D-A-D routine. The policy learns whether to continue, change side, or release through PPO.

### 2. Combo-pressure opponents enter the curriculum

A new `COMBO_PRESSURE` curriculum opponent reuses the existing pressure and W-tapper bot styles. It is sampled for 10% of non-review episodes at stage 6 and 15% at stages 7–9. The same opponent mode is wired into the in-mod trainer and standalone simulator. This is exposure to combo-maintaining attacks, not a new reach or damage cheat.

### 3. Defensive combo telemetry and a small outcome signal

Incoming chains are tracked separately from the AI's offensive combo counter. The tracker uses server-confirmed HP damage, and closes a chain after 12 ticks without another confirmed hit. A chain must contain at least two hits. A chain is labelled `strafe-assisted` only when the agent had active lateral input for at least three ticks and accumulated at least 0.35 blocks of lateral travel during the escape window.

A small one-time `0.04` training reward is paid only for that completed strafe-assisted event. There is no per-tick reward for pressing A/D, orbiting, or merely moving sideways. The simulator's periodic output now includes `def-combos` and `strafe-escapes` separately from offensive combo metrics.

The label is a useful training proxy, not proof that strafing alone caused the opponent to miss: knockback, aim error, spacing, and other events can also contribute. Held-out evaluation is still required.

### 4. Runtime and migration support

The simulator and helper shell scripts now compile the new action and combo-tracker classes. Checkpoint layout migration recognizes the immediately previous 14-output head across the older observation-layout paths too. Releasing the live AI clears the strafe latch.

## Validation performed

- `sh sim/regression.sh` — PASS. Includes simulator/network, outcome, kit, league, checkpoint migration, and the new `StrafeActionCheck`, `ComboDefenseTrackerCheck`, and `HoldStrafePolicyCheck` tests.
- A 5,000-tick simulator smoke fine-tune loaded `/mnt/data/rlpvp-v738-resumed-3m-20261103.bin`, forced stage 9, used the diamond Protection III kit, and sampled RTT in the 50–130 ms range. It saved a separate v9 checkpoint at tick 3,005,326. This confirms that the v8 checkpoint can be loaded and training can continue with the expanded action head.
- That smoke run also launched a fixed-bot benchmark (11 styles × 5 episodes) and reported 47 wins, 8 losses, 0 draws, composite score 0.6787. This is only a smoke benchmark on a short fine-tune; it is **not** a paired before/after result and must not be interpreted as proof the combo-lock problem is solved.
- `bash gradlew compileJava --no-daemon` could not run because the wrapper attempted to download Gradle 9.5.1 and the environment could not resolve `services.gradle.org`. The Fabric/Minecraft mod compile path, including `ActionApplier`, therefore remains unverified in this environment.

## What this does not prove or solve yet

- The 5,000-tick smoke run is not enough to learn robust combo escapes.
- The current tracker does not yet log full per-event observation age, action-send time, server-receive time, and action-application time. If the live mod has stale or reordered input/observation timing, that still needs a dedicated trace.
- This patch uses the existing observation contract and GRU history; it does not add new prediction features or replace the existing decision system.
- No win-rate claim against human Tier 1 players is made.

## Recommended next experiment

Fine-tune the v9 checkpoint for 100k–500k ticks at the same kit and 50–130 ms RTT, with the new combo-pressure exposure enabled. Evaluate the original v8 checkpoint and v9 checkpoint against identical held-out pressure, W-tap, adaptive-strafe, and mixed-style opponents with matched seeds. Compare incoming combo length, hits-to-escape, fraction of incoming chains broken, active lateral travel during pressure, damage taken per engagement, whiff rate, and win rate. Keep the original checkpoint as the rollback baseline.
