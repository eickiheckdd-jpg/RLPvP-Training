# v7.30 - bots that behave like real players (human layer in BotAI)
Context: the v7.29 status you pasted at 425k ticks: 22 sprint hits of 1,314 hits (1.7 %, down from 70 at 325k), 716 crits (54 %), 598 plain hits (45 %), sprint-hit follow-up conversion 27 %.
Plain hits at 45 % mean the agent is mostly NOT sprinting at the swing, and the scripted opponents were still too regular for "reading the opponent" to matter. Compile-checked only; no tests / sims / training run.

## What a human does that the old bots did not (all in BotAI, shared by the sim and the mod)
- Human reaction time and attention: lag 2-3 ticks for the HUMAN style (1-2 for others), random attention lapses (3-7 ticks, perception 2 ticks older, no swings) and a slow aim drift (wobble) instead of white noise.
- Click timing: a person does not click on the exact tick the sword is ready: 0-2 extra ticks (more at low difficulty).
- Fight PHASES: neutral -> PRESS (after landing two hits in a row, push for 20-40 ticks) and RESET (after being hit twice: back off 10-24 ticks, no swings unless the agent swings first, then punish). Streaks decay, so it is not a fixed loop.
- HABIT READING (the agent's last ~100 ticks): jump rate raises the anti-jump dodge probability (it punishes jump-crit spam), "lives in melee range" makes it step back and re-engage on its own terms,
  "keeps its distance" makes it commit and pursue earlier. All scaled by skill.adapt (0.2-0.5 normal, 0.55-0.95 HUMAN, and by difficulty).
- Strafing with a favourite side and longer holds (3-9 ticks) like a person, instead of a random flip every 2-5 ticks.
- New style HUMAN (30 % of STRONG, 22 % of AGGRESSIVE): a well-rounded fighter using all of the technique repertoire (w-tap / s-tap, sprint hits, bait, hit select, far-edge hits, combo chase, jump reset, anti-jump) chosen by the
  moment: phase, HP lead, the agent's charge, distance and habits. Other styles keep their signature but also read habits a little.
- Everything scales with BotDifficulty, so if the agent cannot win the bots ease off automatically.

## Why this helps gamesense
The agent now meets opponents whose behaviour depends on what the agent has been doing (jump spam gets dodged, point-blank trading gets backed off from, passivity gets pursued, two hits taken make the bot regroup).
A single habit stops being enough; what pays is reading the opponent's state and switching between crit, sprint hit, spacing, bait and tap lines. Together with v7.25-7.29 (hit-unit pay, satiation, w/s-tap rewards, cap fix).
Not verified: how often each behaviour fires (no sims run); BotBrain.java (Minecraft classes) not compiled, but BotAI is Minecraft-free and compiles with the sim.
