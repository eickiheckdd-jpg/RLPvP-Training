# Stage 2 pitch practice and smoother camera

**Pitch (stage 2).** A stationary bot on flat ground gives a constant pitch error, so there is nothing to learn on that axis. The bot therefore
hops (never teleported), in the simulator (`PvpSim.stationaryHop`) and in the mod (`BotBrain.stationaryHop`, a Carpet jump). A hop moves the target
up and down about 1.25 blocks, roughly +-13 degrees at 2.6 blocks.

**The hop is adaptive (v7.2).** v7.1 hopped every 12-30 ticks (airborne about half of the time) at all times. With the slower camera physics a fresh
policy could never reach the 60 % on-target gate: the gate read 0 % for 1,000,000 ticks (the same run without hops read 73 % within 84 episodes),
and since the stage timers are gone the run never left stage 2 (see `training-results-v7.1-stuck/`). Now the hop is a performance-driven LEVEL
(`Curriculum.hopLevel()`, 0..1; constants `Config.BOT_HOP_*`):

- it starts at 0 (no hops) so the static aim is learned first;
- after every `BOT_HOP_WINDOW` (10) episodes it rises by `BOT_HOP_STEP` if the success rate was >= 75 %, falls if it was < 50 %;
- level 1 means a grounded bot waits 30-60 ticks between hops (about 25 % airborne); lower levels wait proportionally longer;
- stage 2 is only left when the gate is held AND the level is >= `BOT_HOP_REQUIRED_LEVEL` (0.7): pitch tracking really is practised before attacks unlock.

The training log line shows what the gate sees: `gate 97%/60% (hold 30/30, 167 eps) hop 0.6/0.7` (the `win %` column is the kill rate, always 0 in the
aim-only stages, so it is not the gate). Turn the hop off with `BOT_HOP = false`.

**Camera.** The physical-mouse limits allowed rest -> 31 deg/tick in one tick. The game shows the camera at 20 Hz with straight-line interpolation
between ticks, so every big velocity change is a visible jolt. Limits: `CAM_ACC_MAX_FRAC` 0.30, `CAM_JERK_MAX_FRAC` 0.12, `CAM_MOUSE_DRAG` 0.30 (equal
to the acceleration fraction, so full push = full speed). A flick needs about 3-4 ticks to reach high speed and coasts down gently. A true per-frame
(60+ Hz) smooth display would need a Mixin into the renderer, which this project does not have.
