# RLPvP Split HUD Redesign

This visual update replaces the single large Tactical Deck panel with independent, compact, chamfered instruments. It is a client-side rendering change and does not change PPO policy architecture, policy weights, optimizer state, observation layout, reward logic, simulator combat rules, or checkpoint serialization.

## Combat HUD

- Left column: AI input keycaps (W/A/S/D, sneak, sprint, jump, and attack), twin yaw/pitch tracking dials, and a target card with both health bars and line-of-sight state.
- Right column: live range, applied camera deltas, true local-player attack cooldown percentage, and a player-centric radar. The radar intentionally contains only the local player and current target; it does not render terrain or unrelated entities.
- Input keycaps turn yellow on an input event and fade back to blue after release.
- Attack charge is read from the local player's live `getAttackStrengthScale(1.0f)` value during rendering, rather than relying on the HUD's cached training snapshot. It therefore updates smoothly from 0% through 100%.

## Separate training HUD

In automatic mode, training appears in a separate compact panel. It shows total learned ticks, curriculum stage, stage progress, PPO updates, win rate, entropy, episode count, and average return. It does not merge training statistics into the combat input widgets.

## Commands

- `/rl hud` — toggle visibility
- `/rl hud auto` — show combat instruments and, while training, the separate training panel
- `/rl hud combat` — show combat instruments only
- `/rl hud training` — show only the training panel
- `/rl hud mini` — show a compact status strip
- `/rl hud off` — hide the HUD

## Live refresh

The immutable HUD data snapshot refreshes once per client tick (20 Hz) instead of every five ticks. The attack cooldown percentage is sampled directly while drawing.

## Compatibility / safety boundary

- Fabric mod target remains Minecraft Java 1.21.11, Java 21.
- No Mixin files were edited.
- No `.bin` checkpoint files were edited, converted, or included in this source update.
- The full Fabric/Gradle build could not be run in this environment because the Gradle distribution was not cached and network DNS was unavailable. HUD rendering classes were syntax-checked against minimal Minecraft API stubs.
