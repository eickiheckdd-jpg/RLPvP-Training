# Physical mouse controller experiment

This experimental branch implements choice A: movement inspired by a person sliding a physical mouse across a mousepad. It does not use a separate target-following or PvP-specific aim controller.

## Behavior model

- The policy produces signed hand effort.
- The command passes through `CameraMap` for fine force control near zero.
- `CameraDynamics` integrates the force with drag, bounded acceleration, bounded acceleration-change (jerk), and bounded speed.
- Releasing the command lets drag slow the mouse naturally; reversing direction first brakes and then accelerates the other way.
- The returned relative displacement is the camera rotation for that game tick.
- The same controller is used in the live mod, self-play and the offline simulator.

This is an approximation of hand/mouse motion, not a literal model of mouse-pad millimetres, friction variation, lifting/recentering, or a particular person's motor control.

## Controller checks

`tests/CameraDynamicsCheck.java` checks speed/acceleration/jerk limits, monotonic startup, release-to-stop behavior, reversals, left/right symmetry, yaw/pitch scaling and small movements. `tests/run.sh` passes. The pure-Java simulator classes also compile.

These checks prove the mathematics and source compile only. They do not prove the trained agent produces convincing mouse movements or fights better. A fresh training run and camera-motion evaluation are required.

## Checkpoints

Action semantics differ from v9's spring/damper controller, whose output meant desired angular velocity. Here the output is hand effort. A v9 checkpoint may load at the file-format level, but it is not an appropriate training resume point; keep it as a legacy backup and train from scratch under this model.

## Parameters

See `Config.java`:

- `CAM_ACC_MAX_FRAC`: maximum acceleration relative to each axis's scale.
- `CAM_JERK_MAX_FRAC`: bound on the tick-to-tick change in acceleration.
- `CAM_MOUSE_DRAG`: how quickly existing motion is opposed when effort is released.
- `CAM_SUBSTEPS`: integration resolution within one 20 TPS policy step.

Treat the defaults as experiment settings, not measured human-motor values. Compare several parameter sets at identical seeds and episode counts before selecting one.
