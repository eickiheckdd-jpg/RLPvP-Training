# v7.27 - stronger pitch learning in stage 2
The build already had your idea: in stages 2-3 the stationary bot hops at an adaptive level (Curriculum.hopLevel, gate: level >= 0.7 to leave stage 2). Two weaknesses: at level 1 the bot waited 30-60 ticks between hops
(airborne ~25 % of the time), and a fixed-height target at 3-4.2 blocks needs one constant pitch (~12 deg), which a policy can learn as a bias without ever reading its pitch error.
- Hops are more frequent: BOT_HOP_MIN/MAX_TICKS 30-60 -> 18-40 (airborne ~40 % of the time at level 1; lower levels are still proportionally slower, and the level still adapts to the success rate).
- PITCH KICKS (simulator only; the mod never forces the agent's camera, so the mod side is unchanged): in stage 2 a random vertical camera push every 40-90 ticks (after a 30-tick warm-up), spread over 4 ticks,
  size 6 deg + 20 deg x hop level (random sign). Pitch error keeps reappearing at random sizes and the only fix is to read the observed pitch error and correct it. Config.PITCH_KICK = false disables.
- The gate to leave stage 2 is unchanged (hop level >= 0.7), so the agent must hold its aim while the target hops AND the camera is being kicked.
Not run: tests, sims, training. Sim/agent classes compile; Trainer/BotBrain (Minecraft classes) untouched in this version. Includes v7.26 (stage-phased rewards).
