# Physical mouse dynamics: hand effort, drag, acceleration and jerk

## What it is

The policy output is interpreted as **hand effort applied to a physical mouse**, not an immediate camera rotation and not a target that the camera is pulled toward. `CameraMap` turns the raw policy output into a signed effort value. `CameraDynamics` models the mouse's relative motion with acceleration, drag, a maximum speed, and a limit on how quickly acceleration can change:

    drive = cmd / scale
    aTarget = drive * (CAM_ACC_MAX_FRAC * scale) - CAM_MOUSE_DRAG * v
    |a| <= CAM_ACC_MAX_FRAC * scale
    |change of a per tick| <= CAM_JERK_MAX_FRAC * scale
    |v| <= scale
    displacement = integral(v dt)

The drive term represents the hand pushing the mouse; drag opposes movement. When input is released, drag brings the mouse to a stop. When input reverses, the mouse first brakes its current motion, then travels in the opposite direction. Acceleration and jerk limits prevent instant speed changes. Four substeps per game tick integrate the trajectory and displacement.

`scale` is the maximum camera-equivalent mouse speed in degrees per tick (`YAW_SCALE` / `PITCH_SCALE`). The actual displacement integrated over a tick is what changes camera rotation. This is still a model—not a literal simulation of mouse-pad millimetres or human muscles—but its motion is force/drag-based rather than a spring that chases a desired angular velocity.

The same class is used by the mod (`ActionApplier`), self-play bot (`BotBrain`) and simulator (`PvpSim` for both sides) to keep training and play dynamics consistent. In-game render interpolation remains separate: `ActionApplier` leaves vanilla's previous-angle fields untouched so intermediate render frames can interpolate the tick movement.

## Constants (`Config`)

| Name | Default | Meaning |
|---|---:|---|
| `CAMERA_DYNAMICS` | `true` | Enables the physical mouse model. `false` is a diagnostic bypass only. |
| `CAM_ACC_MAX_FRAC` | `0.7` | Maximum acceleration relative to the axis scale per tick² (yaw: 31.5 deg/tick²). |
| `CAM_JERK_MAX_FRAC` | `1.0` | Maximum acceleration change per tick relative to the axis scale (yaw: 45 deg/tick³). |
| `CAM_MOUSE_DRAG` | `0.7` | Drag coefficient per tick; matched to the acceleration fraction so full input balances at top speed. |
| `CAM_SUBSTEPS` | `4` | Integration substeps per game tick. |

## What the policy sees

The observation layout remains at 378 inputs. The two camera-state inputs (frame indices 27/28) carry actual camera-equivalent mouse velocity (`v / scale`, through the existing encoding), not the raw effort command. The stacked observations give the policy recent velocity history as well. `CameraReward` receives actual normalised velocity from the controller so movement costs are based on the motion produced by the mouse model.

## Verification

`tests/CameraDynamicsCheck` checks acceleration and jerk bounds, speed limits, symmetrical left/right behavior, reversals, reset/stop behavior and micro-movement. Those are mathematical/controller checks only. They do **not** establish that the policy has learned to aim well or that the movement looks human in the Minecraft renderer; evaluate with `CamSmoothEval` and recorded gameplay before claiming improvement.

## Checkpoint compatibility

This changes action semantics compared with the v9 spring/damper version. In v9, an action was a desired camera-equivalent velocity. Here it is mouse-hand effort that produces acceleration and movement through drag. A checkpoint trained under the old interpretation should not be treated as compatible with this controller. Retrain a fresh policy using the new controller, or preserve the original v9 project/checkpoint separately. Do not assume continuing the old 1.3M state will teach the new dynamics correctly.

## AimBrake: braking envelope near the target (smooth aim without hunting)

`AimBrake` limits how fast the mouse may move toward the target so it can still stop in the angle that is left (`vSafe = sqrt(2*aDec*left) + vTrack`, `left` = remaining error minus `AIM_BRAKE_LOOKAHEAD` ticks of own motion). It only uses what the policy already observes (yaw/pitch error, frame features 13/14) plus the TRUE camera velocity, which the policy cannot see. Moving away from the target is never limited; a push toward it fades with the remaining error (`AIM_BRAKE_PUSH_GAIN`), so a policy slamming full effort left/right cannot flip-flop around the crosshair. It is part of the mouse physics: `PvpSim` and `ActionApplier` (via `Trainer`) apply it identically; scripted bots and frozen self-play opponents do not use it. `Config.AIM_BRAKE = false` or `-Dsim.aimbrake=false` turns it off.

Measured on `models/experimental_state_smooth0.7_1300k.bin` (`sim/aimprobe.sh`, fixed seeds, 30 episodes per opponent):

| | brake off | brake on |
|---|---|---|
| on-target time (error <= `ON_TARGET_DEG`) | 14-18 % | 34-68 % |
| ticks with camera faster than 20 deg/tick | 41-50 % | 2-5 % |
| mean camera speed | 17-20 deg/tick | 4.7-6.2 deg/tick |
| overshoots / episode | 9-35 | 0.3-1.1 |
| back-and-forth hunts / episode | 6-25 | 0.1-0.2 |
| win rate vs WALK / AGGRESSIVE (d=0.4) | 23 % / 0 % | 97 % / 3 % |

Closed-loop unit test (`tests/AimBrakeCheck`): with a full-effort bang-bang chaser the brake overshoots 1-5 deg instead of 45-73 deg, and a proportional chaser settles within 13 ticks with <= 3 reversals.

### Known problem this exposes: the policy cannot see its own camera velocity
`Observation.frame` sets features 27/28 (own camera velocity) to 0 (`f[27] = 0f; f[28] = 0f`), although this document and the README say they carry the actual mouse velocity. With an inertial mouse the policy therefore cannot know its own momentum. AimBrake compensates from outside the policy; a fresh policy trained for these dynamics should either see the velocity (change the observation, then retrain) or keep relying on the brake. The shipped 1.3M checkpoint was trained for the old velocity-follower camera (see above), so its camera head is still mismatched: expect it to lose to strong bots until it is retrained with the brake on.

### Visual smoothness (what vanilla renders), measured in the simulator
`ActionApplier` turns the camera once per 20 Hz tick and leaves `yRotO` alone, so vanilla draws the frames in between as a straight line from last tick's angle to the new one (one tick = 50 ms behind). The camera is therefore continuous, but its SPEED changes abruptly at every tick boundary. `sim/aimprobe.sh <state.bin> 20 visual` reports that change (|turn(tick N) - turn(tick N-1)|, deg/tick; shipped 1.3M checkpoint, 20 episodes per opponent):

| | median | p95 | ticks > 3 deg/tick | ticks > 8 deg/tick | max |
|---|---|---|---|---|---|
| brake off | 7.8-11.3 | 24-26 | 76-85 % | 49-60 % | 37-51 |
| brake on | 0.5-0.9 | 5.3-6.7 | 10-19 % | 2.6-4.3 % | 18.6 |

This is a model of the renderer's interpolation, not a screen recording: frame pacing, mouse smoothing and other mods are not covered. A cubic (Hermite) interpolation of the camera angle at render time would remove the speed jumps at tick boundaries completely; it needs a render hook (mixin) and has not been implemented or tested.

## v7.1 update: shared GameplayRotation + predictive AimBrake
- Historical v7.1 behavior wrapped the accumulated yaw to `[-180, 180)` and shifted `yRotO` by a 360-degree multiple. This absolute-angle wrapping has since been removed: current `GameplayRotation` retains continuous vanilla yaw and wraps only target-minus-current differences.
- `AimBrake` was rewritten: it predicts the real stopping travel with the actual dynamics (`CameraDynamics.predictMaxTravel`, includes the jerk-limited brake build-up) instead of a constant-deceleration formula. The old one failed its own test (41.5 deg overshoot).
- Doc numbers above (acc 0.7 / jerk 1.0) were stale; Config is acc 0.30, jerk 0.12, drag 0.30. `CameraDynamicsCheck` 90%-speed threshold changed 6 -> 10 ticks accordingly (it was already failing).
- New: `tests/GameplayRotationCheck` (tests 1-12, 14), `sim/consistency.sh` (test 13), `AIM_BRAKE_SLACK_DEG`, `CAM_STOP_GAIN`.
- NOT re-measured after the last brake-direction bug fix: the before/after aim numbers in the report were taken just before it. The 1.3M checkpoint was trained for an older camera; no retraining was done. No in-game test, no Gradle build (Fabric/Maven repos unreachable).

## v7.1 update: shared GameplayRotation + predictive AimBrake
- `GameplayRotation` is the single controller (sanitize, CameraMap, AimBrake, CameraDynamics, pitch stop, continuous absolute yaw) used by `ActionApplier`, `BotBrain` and `PvpSim`. Only angular differences are wrapped. See `AIM_ROTATION_CONTINUITY_FIX.md` for the correction and regression tests.
- `AimBrake` now predicts stopping travel with the real dynamics (`CameraDynamics.predictMaxTravel`) instead of a constant-deceleration formula.
- New: `tests/GameplayRotationCheck`, `sim/consistency.sh`, `AIM_BRAKE_SLACK_DEG`, `CAM_STOP_GAIN`. `CameraDynamicsCheck` 90%-speed threshold changed 6 to 10 ticks (it was already failing with the retuned Config).
- Not re-run after the final brake-direction fix: full `tests/run.sh` and the aim probe. No in-game test, no Gradle build, no retraining.
