# v7.22 - bait, spacing, mixed playstyle, latency randomisation (on top of v7.21-memory-merged)

NOTHING WAS RUN: no tests, sims or training. Everything compiles (javac, simulator + Minecraft-free classes); Trainer.java (Minecraft classes) is not compiled here and mirrors the sim.
tests/StyleCheck.java is new and was NOT run; the pattern checks in tests/JumpResetCheck.java were adjusted for the new summary text and also not re-run.

## Spacing (learned, outcome-settled)
TechniqueDiscovery.SPACING: a real hit whose swing was made from the far edge of my reach (centre distance >= 2.5) that is paid only if the exchange was WON and I took NO damage
during it, i.e. I landed it and stayed out of the enemy's swing. Same neutral base (0.20), net-HP factor, kit scale, annealing and caps as the other techniques. Hit distance is fed from Trainer and PvpSim (lastHitDist).

## Bait (learned, outcome-settled)
TechniqueDiscovery.BAIT: the enemy swung at me (facing me) while I stood just OUTSIDE its reach (<= 4.2): it overcommitted and whiffed. A real hit of mine within 14 ticks after that swing is the counter
and is paid only if the exchange was won with no damage taken. Nothing tells the agent to offer the bait; it has to discover that standing at the edge pays when the enemy commits. DODGE (inside reach) is unchanged.

## Mixed playstyle (no fixed style, no forced technique)
Habit techniques (crit, sprint hit, knockback follow-up, spacing) keep a running share of my recent exchanges (rate 0.02, kept across episodes). While one of them makes up more than 60 % of them its bonus
shrinks linearly to 0.3x. Nothing is paid MORE for rarity, reactive techniques (jump reset, bait, dodge, punish, combo, first hit) are exempt, and the base values are still neutral, so situations decide;
only a monoculture stops paying. The log line shows `style share crit x% sprintHit y% kbFollowup z% spacing w%`.
The grounded rule for w-tap / s-tap (v7.21) is unchanged.

## Latency domain randomisation (sim only)
Config.LAG_* (-Drlpvp.lagRandomize=false restores the old model; -Drlpvp.lagMinMs / lagMaxMs, default 20 / 150): per episode the one-way link delay is log-uniform in [20 ms, hi], hi growing
with the lag curriculum (none up to stage 5, ~75 ms at stage 6, ~115 at 7, 150 from stage 8); 10 % of episodes keep zero lag; half the episodes DRIFT (the delay follows a moving target, retargeted ~1 %/tick) and
may SPIKE (+20 % above the max for 10-30 ticks, 0.2 %/tick); jitter scales with the delay; server TPS drops are the existing stalls. The knockback packet delay follows the drifting link each tick (capped at 4 ticks).
Evaluation with a fixed lag (fixedLag) is unchanged. The real mod trains on its real connection, so nothing is injected there.
Reading: ms values are one-way delay (the link's `base`, 50 ms per tick); the observed round trip is about twice that.

## Not done / watch
- Whether the agent actually finds bait: it needs enemies that swing at the edge of reach. Watch `baitArmed` vs `bait won/settled` in the tech log.
- The dominance rule only reshapes pay; if one habit still dominates after its pay is cut to 0.3x, that technique is really what wins in the sim.
- CSV header now has two more technique blocks (spacing, bait): start a new CSV.

# v7.22 part 2 (nothing run; compile-checked only. Trainer.java / BotBrain.java are Minecraft classes and were not compiled here)

## Reward scale for armor, critic loss
- Damage reward x clamp((7 / typical hit)^0.5, 1, 2) (Reward.damageScale; typical hit = TechniqueDiscovery running average): about x2 in diamond + prot 3, x1 unarmored. The finishing-damage reward in Trainer uses it too.
- Dense shaping x clamp(300 / episode length, 0.25, 1) in the sim (Reward.denseScale): kit-aware episodes are up to 4x longer, so the per-episode shaping total grew 4x. The mod's episode length is fixed: no rescale there.
- Critic Huber delta = 0.5 x std of the rollout's returns (smoothed, 1..8) instead of 1: returns of 10-20 made the value loss plain L1. Adam keeps the step size; only the loss shape changes. Config.VALUE_HUBER_*.

## Opponent styles (BotAI)
Seven styles per episode instead of three: COUNTER, PRESSURE, BAITER plus RUSHER (spacing 2.1, never backs off), WTAPPER (1-tick taps, sprints from 2.8 blocks: chained sprint hits), CAMPER (holds 3.7 blocks, commits only after 110 quiet ticks)
and RESETTER (jumps + sprints toward you when hit, probability 0.35 + 0.6 x difficulty). STRONG: 17/15/15/13/14/13/13 %; AGGRESSIVE: pressure 40, rusher 22, counter 18, w-tapper 20 %. Fairness limits unchanged (BotAICheck invariants).
Self-play against past versions already exists (the stage-9 league / FrozenPolicy pool).

## Knockback timing inputs (KbTiming)
4 new summary inputs, the LAST block: incoming (1 from my hit until the knockback lands, <= 8 ticks), pulse (velocity change my keys cannot make), ticks since the last pulse, and a reset-window flag (incoming or <= 2 ticks since it landed, on the ground).
Filled in Trainer, PvpSim (agent AND frozen opponent) and BotBrain (self-play). -Drlpvp.kbTiming=false restores the old layout. A checkpoint without the block loads (new column weights start at zero, consequence model restarts, like earlier blocks);
the v7.19 pre-memory branch now accounts for the extra block. tests/CheckpointCompatCheck and MemoryCheck were NOT re-run for the new layout.

## Mixed playstyle by situation and advantage
Exchange pay of risky pressure techniques (crit, sprint hit, follow-up, combo) x (1 - 0.3 x lead), of safe lines (spacing, bait, dodge, punish) x (1 + 0.3 x lead); lead = clamp((my HP - enemy HP) / 20 / 0.35, -1, 1).
Ahead: the safe lines pay a little more; behind: pressure does. Bounded +-30 %, on top of the neutral bases, outcome settlement and the anti-monoculture dominance rule. Config.TECH_ADV_*.

## Aim: no snap, no stop; easing; legal mouse steps
- AimBrake: the stepwise ladder (push x1/2, 1/4, 1/8, then braking in steps) is replaced by a continuous taper: bisection for the largest push (then the smallest braking effort) that still stops inside the angle that is left. The speed eases down into the target instead of jumping between levels = no stop-and-go.
- Ease-in (GameplayRotation.Ease, Config.AIM_EASE_TICKS; DEFAULT OFF after measurement, see 'Stuck run' below): a push that starts from rest is scaled by smoothstep(age / 3) (0.26, 0.74, 1): slow start, fast middle, and with the taper a soft end. A push that continues a moving mouse is not slowed, so tracking stays quick.
- Legal mouse step (Config.MOUSE_QUANTIZE, MOUSE_DEG_PER_COUNT = 0.15, vanilla at 50 % sensitivity: 1.2 x (0.6 s + 0.2)^3): every tick's camera turn is a whole number of counts, the remainder is carried like mouse hardware.
  Set -Drlpvp.mouseDegPerCount to your sensitivity. Training and play use the same filter.
- Not measured: whether the 3-tick ease costs reaction speed on fast strafers; if the aim gate suffers, set -Drlpvp.aimEaseTicks=2 or 0.


## Stuck run (stage 3, 100 % whiff, 0 damage at 600k ticks): found and fixed
Measured / found without running a training or a sim (one camera-controller probe, a few ms):
1. NEAR-MISS CREDIT WAS WORTH MORE THAN A HIT IN ARMOR (the likely cause of the 100 % whiff). A near-miss swing (inside reach, aim within ~10 deg) paid a fixed 0.25 x 7 HP = 1.75 HP-equivalent (cap 3.5 per episode), but a REAL hit
   in diamond + prot 3 is only ~1 HP (0.6 reward). Two near misses beat three hits, so the agent learned to near-miss and never convert. v7.22 part 2 doubled the damage term, which doubled this too.
   Now Reward.softHp / softCapHp: a fraction (0.25) of the kit's TYPICAL hit (cap scaled the same way): a near miss is always worth less than a hit. The sim seeds the typical hit from the kit each episode (MinecraftRules.afterDefense(kit, 7)); the mod uses the running average.
2. My ease-in (smoothstep over 3 ticks) COST AIM. Tracking a sinusoidal strafe with a P controller: on-target (6 deg) 75 % without it, 59-67 % with it, because every sign flip of a tracking correction restarted the ease. It is now OFF by default
   (-Drlpvp.aimEaseTicks=N to try it; only commands >= 50 % of the axis speed are eased, -Drlpvp.aimEaseMinFrac). The jerk-limited mouse already starts a push smoothly.
3. The new AimBrake taper is BETTER than the old ladder on the same probe: 75 % on target vs 65 % (v7.21), same controller. The legal mouse step (0.15 deg counts) is harmless (identical on-target within 1 %).
4. tests/GameplayRotationCheck: two checks were phase-sensitive / exact-equality (fine aim final error after 200 ticks of a P-controller limit cycle, per-axis equality) and now allow the mouse count and the brake slack. The suite passed with the final code (GameplayRotationCheck: ALL OK).
NOT verified: that the stuck run recovers. Check the next log for `whiff` falling below 100 % and hits > 0 per window after ~100k ticks; if the agent still does not aim at stage 3, the aim gate line (on-target share) is the number to look at.
