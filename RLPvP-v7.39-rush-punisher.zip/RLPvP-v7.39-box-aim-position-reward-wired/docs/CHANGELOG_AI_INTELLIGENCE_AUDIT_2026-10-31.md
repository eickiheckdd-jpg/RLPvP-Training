# AI-intelligence audit and learned-only play path — 2026-10-31

> Historical note: this document records the earlier configuration/learned-only-path audit. The subsequent per-opponent history, causal event-memory, applied-click telemetry, confidence-window, and runtime-overhead fixes are documented in `docs/AI_INTELLIGENCE_IMPLEMENTATION_2026-10-31.md`, which is the authoritative implementation and verification report for the finalized follow-up.

## Scope

This change targets AI decision-making integration and configuration correctness. It does not modify Minecraft combat formulas, attack timing, hit detection, knockback, camera/aim control, or the Fabric mod's Minecraft 1.21.11 target. The existing simulator combat port is retained.

## Findings and fixes

1. `Config.INTEL_OFF=96` is documented as disabling candidate scoring (bit 32) and candidate guidance (bit 64). `SituationalCombatStack.guideCandidate` previously applied its own intent-conditioned action rewrites before consulting the suite, so bit 64 did not fully disable guidance. The stack now returns before those rewrites when bit 64 is set.
2. The same ablation was incomplete for scoring: `SituationalCombatStack.scoreCandidate` always applied `CounterfactualActionEvaluator`, even when bit 32 was set. It now returns the supplied learned world-model score unchanged when bit 32 is set. The nested intelligence-suite scorer already honored bit 32.
3. Added opt-in `PLAY_STACK=3` learned-only operation. It skips the hand-authored contextual candidate scorer/guidance, the intelligence suite's strategic enforcement, and its unused per-tick heuristic action-control updates. It retains policy sampling, opponent/event perception memory, the validated learned consequence-model candidate search when its validation gate is satisfied, and the reactive feasibility guard for invalid action combinations. Default mode remains `PLAY_STACK=2`; no default behavior switch is made without stronger benchmark evidence.
4. Extended `CombatBench` with stack 3 so policy, planner, full, and learned-only paths can be compared on the same checkpoint and scenario seeds.

## Verification

- Compiled the Minecraft-free core sources and `SituationalCombatStackCheck`: PASS.
- `SituationalCombatStackCheck`: PASS, including checks that INTEL_OFF bits 32/64 bypass top-level heuristic scoring/guidance, that clearing them restores the legacy planner path, and that learned-only mode bypasses heuristic scoring, guidance, and intelligence-suite action updates.
- Loaded the untouched 5M checkpoint and verified its learned consequence model is planning-ready: 4,999,992 world-model samples, validation MAE 0.020 (`planning=ON`).
- Pilot `CombatBench` with 2 episodes per cell at difficulty 0.6 completed all eight cells. The sample is too small for conclusions; see the raw report below.

### Completed 2-episode-per-cell pilot (difficulty 0.6)

| Opponent | Mode | Win rate | Dealt | Taken | Damage diff | Hits/episode | Sprint-hit % | Whiff % |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| Aggressive | Policy | 100% | 20.0 | 9.2 | +10.8 | 21.5 | 93 | 26 |
| Aggressive | Planner | 100% | 20.0 | 11.1 | +8.9 | 19.5 | 77 | 26 |
| Aggressive | Full | 100% | 20.0 | 15.7 | +4.3 | 21.0 | 86 | 21 |
| Aggressive | Learned-only | 100% | 20.0 | 12.5 | +7.5 | 19.5 | 82 | 22 |
| Strong | Policy | 100% | 20.0 | 12.2 | +7.8 | 20.5 | 80 | 39 |
| Strong | Planner | 50% | 19.9 | 17.8 | +2.2 | 20.5 | 80 | 42 |
| Strong | Full | 100% | 20.0 | 9.5 | +10.5 | 20.5 | 76 | 27 |
| Strong | Learned-only | 50% | 18.8 | 14.9 | +3.9 | 18.5 | 78 | 16 |

These are only two episodes per cell; Wilson 95% intervals are extremely wide. They are a smoke-test of the final benchmark path, not evidence that one mode is stronger. Keep the existing default unchanged until a larger, multi-style benchmark can be completed.

## Preserved state and outstanding work

- The 5,000,000-tick source checkpoint `training/state.bin` was not modified. No training process was started.
- A pre-change source backup was created at `/mnt/data/RLPvP_AI_pre_intelligence_changes_2026-10-31.zip`.
- The full legacy `tests/run.sh` suite still stops at four pre-existing `GameplayRotationCheck` failures. Camera/aim was intentionally left untouched; this audit did not claim those failures were repaired.
- Next, run a longer fixed-seed benchmark of modes 0–3 against multiple opponent styles/difficulties, and only then decide whether any play-mode default should change.
