# RLPvP v9 — Minecraft Java 26.3 exact combat-formula port

## Scope

The target duel is vanilla-style Java 26.3 Sword PvP:

- Unenchanted diamond sword (attack damage attribute 7.0, attack speed 1.6).
- Full diamond armor (20 armor, 8 toughness).
- Protection III on helmet, chestplate, leggings, and boots (12 generic-melee EPF for this source type).
- No shield, absorption, Resistance, regeneration, weapon enchantment, or world blocks.

`Minecraft263Combat` is a dependency-free port of the relevant arithmetic from the user-supplied decompiled 26.3 reference classes. It is not Mojang's source code or the Minecraft server runtime. It deliberately keeps float arithmetic and operation order where the reference uses `float`.

## Ported reference methods

| Minecraft 26.3 reference | RLPvP v9 implementation | Behavior preserved |
|---|---|---|
| `Player.getCurrentItemAttackStrengthDelay()` | `Minecraft263Combat.attackCooldownDelay` | `(float)(1.0 / attackSpeed * 20.0)` |
| `Player.getAttackStrengthScale(float)` | `Minecraft263Combat.attackStrengthScale` | `(ticker + partialTick) / delay`, clamped to `[0,1]` |
| `Player.baseDamageScaleFactor()` | `Minecraft263Combat.baseDamageScaleFactor` | `0.2F + scale * scale * 0.8F` |
| `Player.attack(Entity)` | `Minecraft263Combat.playerAttackDamage` | Scaled base damage, enchanted-damage delta, item damage bonus, then critical multiplier in source order |
| `Player.canCriticalAttack(Entity)` | `Minecraft263Combat.canCriticalAttack` | Fall distance, airborne, not climbing/in water/mobility-restricted/passenger/sprinting, living target |
| `LivingEntity.hurtServer(...)` | `PvpSim.strike` + `Minecraft263Combat.invulnerableExcess` | `damageCooldownTime > 10` compares pre-armor raw damage; only the excess applies, without a new cooldown or knockback |
| `CombatRules.getDamageAfterAbsorb(...)` | `Minecraft263Combat.damageAfterArmorAbsorb` | Exact toughness/effective-armor expression and float order; unenchanted sword's armor-effectiveness hook is identity |
| `LivingEntity.getDamageAfterMagicAbsorb(...)` | `Minecraft263Combat.applyResistance` / `damageAfterProtection` | Resistance first, then Protection unless damage-source tags bypass those stages |
| `CombatRules.getDamageAfterMagicAbsorb(...)` | `Minecraft263Combat.damageAfterProtection` | EPF clamped to `[0,20]`; multiplier `1 - EPF/25` |
| `LivingEntity.actuallyHurt(...)` | `Minecraft263Combat.resolveDamage` | Armor → Resistance → Protection → absorption |
| `LivingEntity.knockback(...)` | `Minecraft263Combat.knockbackPower` + `Minecraft26Physics.applyKnockback` | Knockback resistance, normalized horizontal direction, velocity halving, grounded vertical cap |
| `LivingEntity.computeModifiedFriction(...)` | `Minecraft26Physics.modifiedFriction` | Float expression and clamp |
| `LivingEntity.getFrictionInfluencedSpeed(...)` | `Minecraft26Physics.frictionInfluencedSpeed` | Ground speed adjustment for supporting-block friction above 0.6 |
| `LivingEntity.travelInAir(...)` | `Minecraft26Physics.horizontalDrag` / `verticalDrag` | Air and vertical drag factors |
| `Entity.getInputVector(...)` + `Mth.sin/cos` | `Minecraft26Physics.inputVector` + `Minecraft263Trig` | Input normalization, float yaw/speed, 65,536-entry sine lookup |
| `LivingEntity.jumpFromGround()` | `Minecraft26Physics.jumpVelocity` + `PvpSim.move` | `max(jumpPower, currentVerticalVelocity)` and sprint jump impulse |

### Server-side attack charge

The attack packet contains the target entity ID; the server calls `Player.attack()` when it handles the packet. The attack strength, critical eligibility, and sprint state are therefore evaluated from the server-side player state at packet handling time, not copied from client click metadata. RLPvP now has separate client and server attack-strength tickers. The server ticker is reset when an accepted attack packet is handled. This is a more faithful attack timing model than carrying the client-calculated damage through the network queue.

The offline duel still uses a simplified network/position model; this change does not claim to reproduce every Netty, packet-ordering, or server-tick edge case.

## Exact target-kit arithmetic

For an ordinary unenchanted melee hit:

- Attack cooldown: `20 / 1.6 = 12.5` ticks.
- Diamond armor: `20` armor and `8` toughness.
- Armor stage at 7.0 raw damage: `1.89`.
- Protection EPF: `3 + 3 + 3 + 3 = 12`.
- Final full normal-hit damage: `1.89 * (1 - 12/25) = 0.9828` HP.
- Final full critical-hit damage: `1.6653` HP.
- Final half-strength non-critical hit: `0.331968` HP.

These displayed decimals are rounded; implementation values are produced with the reference's float operations.

## Validation in this package

- `sh sim/regression.sh`: PASS; 43 outcome checks, 12 sprint-follow-up checks, combat-observation memory, 25 movement/trig checks, kit/rules checks, 27 target-kit checks, and 34 exact-combat checks.
- `sh sim/run.sh 1026 <output.bin> 20261030 -`: PASS; writes a stage-1 checkpoint after 1,026 training ticks.
- `sh sim/train_parallel.sh 1026 <output.bin> 20261030 - 2 -`: PASS; two parallel environments complete the 1,026-tick smoke training run.
- `Minecraft263CombatTest`: validates cooldown/charge, attack scaling, critical conditions, armor/toughness, Resistance, Protection, bypass order, absorption, hurt-window excess, knockback resistance, integrated damage, and server-side charge recalculation.

A passing formula test establishes parity of the tested calculations with the supplied reference expressions. It is not a 99% whole-game parity claim.

## Remaining fidelity gaps

1. The offline arena still does not port the complete `Entity.move()` collision solver: swept AABB block collisions, step-up, edge backoff, supporting-block rules, and per-block voxel shapes are not fully implemented.
2. Water, lava, climbing, powder snow, effects, movement modifiers, and arbitrary item-component/attribute resolution are not fully modeled.
3. The attack packet path models target selection and reach but is not a complete vanilla client raycast + server packet integration. The server's full item-dependent attack-range object and packet/tick ordering need differential fixtures.
4. Enchantment behavior is restricted to the requested unenchanted sword and ordinary Protection III armor. The supplied bundle did not include all enchantment implementation/effect classes; alternate sharpness/weapon-effect kits are compatibility profiles rather than a claim of 26.3 parity.
5. No deterministic trace comparison has yet been run against a live Minecraft 26.3 dedicated server. The formula port has unit/integration tests, but full live-server parity remains unverified.

The correct fidelity statement is: **exact-formula port for the explicitly supported combat path, with the surrounding offline environment still simplified**.
