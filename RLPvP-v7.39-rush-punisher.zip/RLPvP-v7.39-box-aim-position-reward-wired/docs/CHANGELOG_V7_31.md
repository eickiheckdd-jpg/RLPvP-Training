# v7.31 - low sprint hits: diagnosed from the policy's own swing states, then fixed
Diagnostic (evaluation only, no training): training-results-fresh-3m/state.bin (600k ticks, stage 8), 25 episodes per opponent at bot difficulty 0.5, new tool sim/com/rlpvp/SprintDiag.java.
At the moment of each full-charge click:
- sprinting 23-30 %, falling-crit 34-40 %, PLAIN 36-40 % (no crit, no sprint knockback).
- Of the plain swings 85-94 % had no forward key held the tick before, 62-86 % were made airborne (rising / at the apex, so not a crit yet), the agent was holding S on 40-56 % of all swings, and in 8-16 % of plain swings
  it pressed sprint + W on the same tick as the click (the engine, like vanilla, uses last tick's sprint state for the click, so the knockback needs W + sprint one tick EARLIER).
So sprint hits were rare because the agent mostly swung while backing off or mid-jump, not because the payout was missing: nothing rewarded being in a position where a sprint hit is available.
## Fixes
1. SPRINT LANE (dense, stage 6+): while my weapon is charged (>= 0.9), the enemy is 2.0-4.4 blocks away and in front of me (< 15 deg) and I am sprinting forward, a small per-tick reward (0.008 x shaping x idle scale): the position a sprint hit comes from.
   It fades with the idle scale like other dense terms, so standing in the lane without ever swinging stops paying.
2. MISTIMED JUMP HIT (stage 6+): a landed hit made in the air before the fall (no crit, no sprint knockback, not part of a jump reset) costs 0.2 typical hits: the jump was wasted. Pushes the agent either to wait for the fall (a real
   crit) or to stay on the ground and sprint-hit.
3. Earlier in this tree: w-tap / s-tap re-sprint rewards (v7.29: the s-tap only pays if W + sprint is pressed again within 8 ticks, which also pushes the agent back into the sprint lane), anti-jump and human-layer bots.
Not run: tests, training. Sim and agent classes compile; Trainer/BotBrain (Minecraft classes) not compiled. SprintDiag usage: java -cp <classes> com.rlpvp.SprintDiag state.bin 25 0.5
