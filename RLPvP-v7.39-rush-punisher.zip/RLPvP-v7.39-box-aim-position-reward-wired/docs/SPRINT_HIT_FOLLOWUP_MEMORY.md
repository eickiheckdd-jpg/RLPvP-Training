# Sprint-hit follow-up memory

## Implementation

Added `SprintHitFollowupMemory`, a descriptive temporal state used by the learned policy. It does not choose actions, change the action mask, add rewards, or force a combo sequence.

The eight appended observation features are:

1. Follow-up opportunity active.
2. Ticks since the confirmed sprint hit, normalized to a 20-tick window.
3. Change in separation since the sprint hit (normalized over 3 blocks; positive means farther apart).
4. Enemy forward velocity.
5. Enemy lateral velocity.
6. Enemy vertical velocity.
7. Short pulse indicating a follow-up hit was landed.
8. Short pulse indicating the opportunity expired without a follow-up.

The memory begins only from a confirmed full sprint-knockback hit in the simulator. A subsequent confirmed damage event inside the 20-tick window is counted as a conversion; a new sprint hit can both convert the previous opportunity and begin a new one. The model is free to pursue, re-aim, sprint-reset, or disengage.

## Integration

- `Config`: appends the eight features by default. Use `-Drlpvp.sprintFollowup=false` to use the previous input layout.
- `ObsLayout` / `PpoAgent`: map old 20-summary checkpoints into the extended input layout; older OBS_V2 layouts are also mapped when OBS_V2 is enabled.
- `Trainer`: updates memory from the current observation and adds opportunity/conversion/expiry/timing metrics to status output and `log.csv`.
- `PvpSim`: updates the agent and self-play opponent memories; the simulator uses the actual attack result to identify full sprint-knockback hits.
- `PvpEval`: reports follow-up conversion rate, opportunities, expirations, and average ticks to follow-up.
- Simulator build scripts include the new source file.

## Verification performed

- `sh sim/regression.sh`: **43 existing regression checks passed**; **12 SprintHitFollowupMemory checks passed**.
- `sh sim/run.sh 5000 /tmp/rlpvp-sprint-followup-smoke4.bin 123`: completed and saved a 5,000-tick smoke checkpoint.
- `sh sim/modelinfo.sh`: compiled and reported `obs=404` with the default settings.
- Resumed `/mnt/data/checkpoint-2600000.bin` with the new observation layout for 100 ticks; saved at 2,600,100 ticks, stage 8. This verifies the existing base-summary checkpoint can be warm-started.
- `sh sim/eval.sh ... 1`: compiled and emitted the new follow-up evaluation columns. This was a smoke evaluation with one episode per matchup, not a meaningful performance benchmark.

## Limitations

- The full Fabric/Minecraft Gradle build could not be completed because the wrapper attempted to download Gradle 9.5.1 and the environment could not resolve `services.gradle.org`. The Minecraft mod integration is therefore source-reviewed but not full-build-verified here.
- No long training run was completed with the new features. Existing checkpoints can load, but the newly added input weights start without learned semantics; meaningful use requires additional training and controlled evaluation.
- Follow-up timing uses a 20-tick measurement window. This is observation/metric bookkeeping only, not an action rule.
