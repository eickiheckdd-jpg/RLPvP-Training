# v7.11 (nothing run: no tests, sims or training; type-checked only, Minecraft classes not compiled)

## Sprint-hit chains (TechniqueDiscovery)
- New measurement: sprint-hit combo conversion = sprint hits followed by >= 1 further real hit (within TECH_FOLLOWUP_MAX_TICKS, nothing taken in between) / all sprint hits.
- Also logged per window: chains (>= 2 hits), average / max chain length, interrupted (damage taken), timed out, pursuit follow-ups.
  Shown in the technique summary line (`combo-conv ...`) and as extra CSV columns at the END of the technique log
  (delete an old technique CSV, or its rows will not match the new header).
- Pursuit follow-up: the enemy was knocked >= TECH_PURSUIT_MIN_GAP (0.8) blocks farther than at the sprint hit and I closed in again.
  KB_FOLLOWUP pays x TECH_PURSUIT_MULT (1.6) for it. Still settled by the exchange (paid only if the trade was won), annealed, capped
  and diminishing, so sprint-hit spam and running after the enemy earn nothing. Observation layout unchanged (checkpoints stay compatible;
  own / enemy sprint, last sprint action and the hit memory are already inputs).

## Target detection range
- Config.TARGET_RANGE 48 -> 96 blocks, TARGET_LOSE_RANGE 64 -> 112 (enemy search was tried and removed).

## Simulator
- 10-tick jump delay (vanilla), round arena wall (-Dsim.arena=N, 0 = open ground; wall hit ends sprint).

## v7.13: frame-rate independent glide (stutter at 20-50 fps)
- GlideCamera real rotation: curve length = measured tick interval (EMA, x0.97, clamped 40-60 ms) instead of fixed 42.5 ms, and it is sampled half a measured frame ahead (where the frame is shown). Removes the snap-at-end and one-frame lag at low / uneven fps.
- Note: at 20 fps there are only ~1 frame per tick, so smoothness is limited by frames actually drawn; cap/raise fps (e.g. fps limit 60+, lower render distance) for best results.

## v7.14: sim kit
- Both fighters now always have a diamond sword (7) + full diamond armor (20 / toughness 8) + Protection III on all pieces (EPF 12). Default `-Dsim.kit=diamond_prot3`; `naked`, `random` etc. still selectable. Damage taken is lower (about 52% after armor), so fights are longer than the old naked baseline: numbers are not comparable with older logs.
