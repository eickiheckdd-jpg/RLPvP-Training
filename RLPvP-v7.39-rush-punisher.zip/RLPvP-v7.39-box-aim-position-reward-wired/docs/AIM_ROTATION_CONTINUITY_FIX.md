# Aim rotation continuity fix

## Scope

This change corrects the representation of absolute player yaw. It does not change Grim, suppress alerts, imitate a detector's thresholds, or add logic intended to disguise automation.

## Root cause

The live controller previously wrapped the accumulated absolute yaw after every tick into `[-180, 180)`. For example, a legitimate small turn from `179°` to `181°` was written as `179°` to `-179°`. The orientation is mathematically equivalent, but the outgoing movement packet contains an **absolute** yaw value, so the numerical change appears to be approximately `-358°` rather than `+2°`.

Minecraft's Java protocol documents yaw as an absolute float and does not clamp it to `[0, 360]`; negative values and values greater than `360` are valid. The correct distinction is:

- Wrap **angular differences** to the shortest signed arc when calculating target error.
- Keep the **accumulated absolute player yaw** continuous when applying, rendering, and transmitting rotation.

Grim's public `AimModulo360` source describes the class as checking clients that modulo their rotation and labels it as a large yaw snap. This project does not attempt to work around the check; it now uses the same continuous absolute-angle semantics as vanilla Minecraft.

## Changes

- `GameplayRotation` keeps `newYaw = currentYaw + appliedYawDelta`; `shortestYawDelta()` remains the wrapped difference helper.
- `ActionApplier` no longer applies a 360-degree wrap correction to `yRotO`; the prior/current yaw values remain on the same continuous angle track.
- `GlideCamera` and the optional real-rotation glide preserve continuous yaw values rather than wrapping the absolute rendered angle.
- `BotBrain` and the scripted `BotAI` retain continuous absolute yaw while continuing to wrap target-error calculations.
- `PvpSim` preserves the absolute yaw sent in a movement packet rather than modulo-normalizing it on the simulated server. Pitch remains clamped to its physical range.
- Regression checks cover short-path target tracking across `+180°`, continuous accumulation across repeated turns, render interpolation across the boundary, and a client-to-server packet carrying `183°`.

## Validation

- `PvpSimNetworkTest`: passed, including the new assertion that the simulated server preserves `183°` rather than rewriting it as `-177°`.
- `GameplayRotationCheck`: the new absolute-yaw continuity cases pass. The complete check still reports four previously documented controller-tuning failures (small 2-degree correction, overshoot, long-tail stability, and fine aim); they are not introduced by the absolute-yaw representation change and were present in the reward-audit baseline.
- `GlideCameraSmoothingCheck` was added to `tests/run.sh` so the continuous render-boundary behavior is covered by the regular pure-Java test run.
- Full Fabric/Minecraft 1.21.11 compilation and a live server packet trace still need to be run in an environment with the Gradle dependencies available.

## Operational note

No training was started and no checkpoint was modified. This corrects an angle-representation bug, but it cannot guarantee that a server will never flag or ban the client: server rules, Grim version/configuration, other checks, and whether automated gameplay is permitted remain separate issues.
