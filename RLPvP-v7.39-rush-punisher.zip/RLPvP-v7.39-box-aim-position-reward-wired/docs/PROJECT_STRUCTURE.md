# Project structure

```text
rlpvp-main/
├── src/                         # Fabric client mod (Minecraft 1.21.11)
├── simulator/                   # Java library for simulator primitives
│   └── src/main/java/com/rlpvp/
├── docs/                        # Project and technical documentation
├── archive/                     # Preserved legacy snapshots, not compiled
├── build.gradle                 # Fabric Loom mod build
└── settings.gradle              # Multi-project Gradle settings
```

The mod remains in `src` and keeps its existing package names. Only the five
dependency-free simulator-specific source files were moved into `:simulator`.
The root-level duplicate Java snapshots were moved into `archive/legacy-root-java`
so they cannot be mistaken for active project sources.

Build commands:

- Fabric mod: `./gradlew build`
- Simulator primitives: `./gradlew :simulator:build`
