# v7.19 (on v7.18)

## Measured diagnosis (current sim: diamond + Protection III, 480-tick episodes)
- Whiff causes added to `PvpEval` ("whiffs by cause"), from the v7.2 checkpoint + 80k ticks, 20 episodes per opponent:
  - vs STATIONARY / STRAFE / WALK: whiff 19-27 %, mostly OFF-AIM swings (59-88 % of whiffs).
  - vs AGGRESSIVE: whiff 64 %, 73 % of them NEAR-MISSES (aimed within the 6.3 degree cone, crosshair still not on the hitbox: the target moves / the picture is delayed), only 13 % off-aim.
  So against moving opponents the problem is tracking and timing, not swinging blindly; a flat per-miss cost (v7.18) cannot fix that.
- Against this kit a kill needs ~21 full hits; a policy dealing ~10-15 HP per episode never wins within the limit (even vs a stationary bot), so wins stay 0 % in evaluation although the policy fights.

## Experiment: HP-lead gate decision (`-Drlpvp.leadDecision=true`, new, OFF by default)
A timeout counts as a stage-gate success if dealt >= 6 HP and dealt - taken >= 5 HP. 500k ticks from scratch, seed 11, same code otherwise, 30-episode eval at the end:
- kills-only gate: reached stage 7, final policy still fights (dealt 15.5 / 14.7 / 15.0 HP vs stationary / strafe / walk; 0 wins, all timeouts; vs AGGRESSIVE loss 87 %, dealt 6.3).
- lead gate: promoted faster (stage 7 at ~272k vs later) but the final policy had become PASSIVE (dealt 0.0-0.3 HP vs stationary / strafe / walk). Not an improvement, so it stays off.
One seed each: indicative, not conclusive.

## Other
- `tests/LeadDecisionCheck.java` (passes). No full test suite run on this version; Trainer.java changes not compiled with Fabric.
- Not done: aim-aware attack head, multi-seed comparisons, tracking/timing improvements for the near-miss problem (the evidence above points there next: e.g. target-velocity / lead-aim features or a longer horizon in training vs AGGRESSIVE).
