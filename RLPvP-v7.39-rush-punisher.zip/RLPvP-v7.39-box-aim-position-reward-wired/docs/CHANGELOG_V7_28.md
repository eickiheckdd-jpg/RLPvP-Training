# v7.28 - the jump-crit loop gets a counter (gamesense), not just a smaller reward
The attached v7.27 is identical to the v7.27 I sent and carries no logs or checkpoint, so this is a structural fix, not a log-based one.
Why crit spam persists: jump -> swing while falling is free against bots that stand still in reach, so no reward tuning can make "read the enemy" worth more than "always jump". The agent only needs gamesense
if the opponent can punish the pattern.
- BotAI ANTI-JUMP: on the rising edge of the agent's jump (from its lagged position, like every other bot perception) the bot rolls skill.antiJump; on success it backs out of reach for the length of the jump
  (max 14 ticks, stops when the agent lands or is > 4.6 away, 24-tick cooldown so it cannot retreat forever). The agent's falling swing then whiffs (a miss costs its cooldown) and the existing punish rule rushes it
  while its weapon recharges. antiJump by style: rusher 0, pressure / w-tapper / resetter 0.15-0.4, spacer / counter / selector / technician / baiter 0.45-0.9, others 0.3-0.6 (scaled by difficulty).
- Result for the policy: crit on a target that stays in reach is still good, but jumping at a bot that is already backing off loses the exchange, so it has to read distance / enemy movement and mix ground hits, sprint hits
  and crits. This works together with v7.25-7.26 (hit-unit pay, satiation, air-hit penalty).
Not run: tests, sims, training. Sim and agent classes compile; BotBrain/Trainer (Minecraft classes) not compiled (BotAI is shared and Minecraft-free).
