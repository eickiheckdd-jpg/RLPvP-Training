# v7.21 - learned jump reset, grounded w-tap / s-tap, less key spam (on top of v7.20 sprint-followup-buildfix)

NOTHING WAS RUN: no tests, sims or training. Only the Minecraft-free classes + sim/ were type-checked with javac.
Trainer.java (Minecraft classes) was edited to mirror the sim and has NOT been compiled.

## Jump reset (a learned technique, not a script)
- TechniqueDiscovery.JUMP_RESET (index 7, N=8). Event: a grounded jump starts within TECH_JR_WINDOW (8) ticks after I took damage
  (covers the delayed knockback packet). It is paid only if I then land a real hit within TECH_JR_EXCHANGE (30) ticks AND the exchange is won,
  annealed / capped / diminishing like the other techniques. The amount is scaled by the knockback separation (max distance gained within
  TECH_JR_SEP_TICKS): full pay up to 1.2 blocks, 30 % from 3.0 blocks - so reduced knockback is what is rewarded, and a jump that is too early
  (overwritten by the late packet) or too late pays less. The agent is never told when to jump.
- Log line `kb-sep after hit: with jump-reset X (n) without Y (n)` and CSV columns jrSepReset / jrSepNone measure the reduction.
- Sim physics (PvpSim): vanilla keeps onGround until the movement step. (1) The knockback packet no longer clears onGround on arrival,
  so a jump pressed on that tick executes and overwrites the knockback lift (vy 0.42). (2) The jump tick keeps ground friction (0.546)
  and the sprint-jump boost points back at the attacker. A jump before the packet arrives is wiped by it (latency timing matters).
  This changes sprint-jump physics slightly for everyone (also the STRONG bot, which already jump-resets on hurtTime >= 9).

## Combos / w-tap with latency
Unchanged mechanics, kept: the sim's kbDelay desync lets the victim keep walking into the attacker, so combos exist; SPRINT_HIT, KB_FOLLOWUP, COMBO
and the chain metrics measure them. New: w-tap / s-tap are only rewarded when grounded (below).

## Grounded techniques
- Config.TECH_GROUNDED_MASK (default SPRINT_HIT | KB_FOLLOWUP) lists the discovery techniques that need the swing to be made on the ground
  (bit = 1 << index; extend it freely). CRIT is air by definition, JUMP_RESET is a grounded jump start by definition.
- Config.GROUNDED_TAP_ONLY (true): Reward.techBonus sprint-hit bonus, the swing-gap tap signal (RESET_HIT_BONUS) and TechniqueReward sprint chain need a grounded swing.
- An airborne sprint hit still deals damage and knockback; it only earns no sprint / follow-up / tap bonus.

## Key spam
- SpamGuard: a grounded jump within SPAM_JR_WINDOW (8) ticks after taking damage is free and never "unjustified"; movement flips and sprint toggles are free
  for SPAM_TAKEN_GRACE (6) ticks after taking damage (re-sprint / recover). Stats show `reset N`.
- Fix: SpamGuard now gets the ground state from when the jump was CHOSEN (prevGround). Before, it used the post-move state, which was
  already airborne on the jump tick, so real jump starts were not seen as such.

## Not done
No A/B training, no in-game test, no Gradle build. Existing tests (TechniqueCheck etc.) were not run or adapted for N=8; old technique CSV files have a different header.

## Hand shake (opt-in, default OFF: -Drlpvp.camShake=true)
- Lives in CameraDynamics (the physical hand), not in the policy action, so the policy cannot learn to cancel its own noise.
- Seeded (-Drlpvp.camShakeSeed, separate stream per axis), smoothly varying AR(1) hand-angle offset: sd 0.10 deg at rest + 0.02 deg per deg/tick of mouse speed, hard cap 0.30 deg
  (ON_TARGET_DEG is 6). The camera turns by the CHANGE of the offset each tick, so it wobbles without drifting. Correlation 0.6 per tick; the stream keeps running across episodes.
- Deviation from the proposal: the noise is added as a bounded angle offset on the hand's output (not as extra force on the effort), so the 0.1-0.3 deg size is exact
  and does not depend on the controller's gains. The controller state (v, a) and the AimBrake prediction stay noise-free; the policy sees the shake through aim error.
- Same code path in training, eval and play; the glide camera smooths the per-tick wobbles. Not run or tuned; only type-checked.

## Situational technique payout (replaces the earlier crit/sprint rebalance, which only swapped one built-in style for another)
- Neutral base amounts: TECH_CRIT = TECH_SPRINT_HIT = TECH_KB_FOLLOWUP = 0.20 (COMBO 0.15 per extra hit, unchanged). No crit-in-chain cut.
- A won exchange pays base * clamp(net HP won / TECH_NET_REF (6), 0.25, 1.5), the same rule for every technique (TechniqueDiscovery.netFactor). So a technique earns more
  exactly where it wins bigger exchanges; lost exchanges still pay nothing. Annealing, diminishing returns and the episode cap are unchanged.
- The grounded rule (w-tap / s-tap family) stays: it defines when that technique counts, not which one is preferred.
- Not run. To check the preference, compare per-technique won/settled and paid in the tech log lines.

## Polish
- TECH_JUMP_RESET base 0.20, the same neutral base as the other techniques.
- New tests/JumpResetCheck (added to tests/run.sh): jump reset needs a won exchange with a follow-up hit, a late jump is not a reset, airborne sprint hits earn no sprint-hit bonus,
  a jump right after taking damage is free in SpamGuard (and costs otherwise), payout factors are bounded. This ONE check was run (passes). The rest of the suite was only compiled, not run.

## Review fixes (issues that would have hurt or collapsed learning)
1. FIXED, serious: the net-HP payout reference was a fixed 6 HP. In full diamond + protection 3 one hit is only ~1 HP, so every won exchange would have been clamped to the
   minimum factor (x0.25) and all techniques would have paid the same: the situational signal gone and all technique guidance 4x weaker. The unit is now one TYPICAL hit of
   the current kit (running average of damage per landed hit, TechniqueDiscovery.emaHit), so a single hit ~ x1 and a combo / bigger win up to x1.5, for any kit or armor.
2. FIXED: the JUMP_RESET separation factor could read the separation window of a LATER hit (the shared sepBase/sepMax were overwritten); it now uses the separation captured for the jump's own hit.
3. NOTED, not changed: jumpStart is "jump key down while grounded at choice and airborne now"; a knockback lift while holding jump with the vanilla jump delay still running counts as a jump.
   It still needs a won exchange with my own follow-up hit to pay, so the effect is small.
4. NOTED: sim kbDelay > 0 knockback now decays with ground friction on its first tick (onGround stays until movement, as in vanilla), so delayed knockback travels a bit less than in v7.20 sims;
   sim results are not comparable with older runs. Old checkpoints are unaffected (no observation / network change).
5. NOTED: the sprint-chain metrics (combo-conv) now count a chain only from grounded sprint hits; the follow-up hit itself is not required to be grounded for the metric, but is for the bonus.

## Deep review, round 2
FIXED
6. Technique bonuses / whiff penalties were ~7x too strong relative to a hit in armor. The damage reward is a fraction of the HP bar (W_DAMAGE/20 per HP): a hit is ~4.2 unarmored but
   only ~0.6 in diamond + prot 3 (about 1 HP per hit). The technique bonuses, DODGE, the whiff-streak penalty and the pointless-whiff penalty (not annealed) were tuned for the unarmored size, so
   in armor they could rival the damage signal (and the penalties push toward not swinging). All are now multiplied by TechniqueDiscovery.kitScale() = clamp(typical hit HP / 7, 0.35, 1)
   (Config.TECH_HIT_REF, TECH_KIT_SCALE_MIN). Callers pass techW * disc.kitScale() to Reward.techBonus.
7. Trainer: the grounded flag of a swing was read after the action was applied; it now uses the state before the keys are applied (same moment as the sprint / crit test and as the sim).
NOT CHANGED (risks to watch)
- Critic: Huber gradient is clipped at +-1 while returns reach ~10-20 (W_WIN 15): value learning is slow but stable. If the value loss stays high, scale rewards or raise the Huber delta.
- Per-hit damage reward in armor is small (~0.6) next to the dense shaping (~0.025 per tick at full shaping): the SHAPING_TAU decay matters more in armor. Watch that dealt/taken keeps improving while shaping fades.
- emaHit is one running average per trainer: with mixed kits in one run (sim kit pool) the technique scale blends; with the default fixed kit it is stable.
- Trainer.java (Minecraft classes) is still uncompiled here; its edits mirror the sim line by line.
