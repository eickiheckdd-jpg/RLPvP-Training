# Parallel League Persistence Bug Fix — 2026-10-31

## Summary

The 7M-tick training process was stopped at the user's request. No training process is running. The parallel-training persistence path contained two confirmed bugs that made the league ratings file unreliable and caused repeated snapshot/ratings save warnings. The fixes below are applied to the source tree and covered by regression tests.

## Root causes found

### 1. Each environment owned a separate league ledger

`ParallelPvpTrain` created one `PvpSim` per worker. Before this fix, each simulator independently loaded and saved the same `league/ratings.csv` and snapshot directory. `OpponentLeague` synchronization was instance-local, so it did not serialize writes across separate worker instances. A worker with stale in-memory data could overwrite another worker's newer ratings, and workers could collide on identical fixed `.tmp` names during concurrent snapshot/ratings writes.

### 2. Parallel resume ignored the checkpoint's league sidecar

The single-environment entry point associates league state with the checkpoint path (`<checkpoint>.league`). Parallel training instead used the process working directory's default `league/ratings.csv`. It therefore failed to resume the Elo history next to the supplied checkpoint and could initialize a fresh 1200-rated `current` row even when the checkpoint had a populated companion league.

### 3. Fixed temporary filenames were unsafe for concurrent or interrupted saves

The old save paths used predictable temporary names such as `ratings.csv.tmp` and `<snapshot>.bin.tmp`. Multiple independent writers could collide, and interrupted writes could leave stale temporary artifacts.

## Changes applied

### Shared, single-owner league persistence

- `ParallelPvpTrain` loads one `OpponentLeague` instance and injects it into every training environment and the probe simulator.
- All workers update the same ledger through synchronized league methods.
- Worker 0 is the sole persistence owner for league ratings and policy-snapshot files; other environments only update the shared in-memory ledger and maintain their local opponent pools.
- Snapshot Elo records are registered with `snapshotIfAbsent`, so the same snapshot ID is seeded only once even if multiple environments reach the same curriculum tick.
- The trainer log includes a league summary so the persisted/current rating can be monitored alongside training metrics.

### Checkpoint-specific sidecar and resume seeding

- Parallel training now uses `<output-checkpoint>.league/ratings.csv` and `<output-checkpoint>.league/snapshots/`, matching the single-environment checkpoint convention.
- When creating a new output sidecar, the newest up to `LEAGUE_POOL` snapshots and the ratings CSV are copied from the resumed checkpoint's companion sidecar.
- Explicit `sim.league.dir` / `sim.league.file` overrides are respected.
- A smoke test verifies the resumed checkpoint's Elo record is inherited rather than reset to 1200.

### Safer file replacement

- `OpponentLeague.save` uses a unique temporary file in the destination directory and atomic replacement where supported, with a non-atomic replacement fallback.
- `PpoAgent.save` uses the same unique-temp/atomic-move pattern for checkpoints and policy snapshots.
- Temporary files are removed in `finally` blocks.

## Regression coverage

Added or expanded:

- `OpponentLeagueCheck`: concurrent result updates retain the full expected game count; snapshot registration preserves the original rating snapshot exactly once.
- `ParallelLeaguePersistenceCheck`: two simulators share one league, write through the single owner, preserve the expected ratings and snapshot, and leave no `.tmp` files.
- `ParallelLeaguePathCheck`: a new output sidecar inherits the resume checkpoint's rating ledger and only the latest configured pool of policy snapshots.

`sh sim/regression.sh` was rerun after the fix and passed all included checks, including the new concurrency and sidecar-path checks.

The broader `sh tests/run.sh` suite still has four `GameplayRotationCheck` failures concerning small-angle correction/overshoot/stability. Camera and aiming code were deliberately not changed because the requested scope was AI intelligence and persistence bugs, not scripted aiming behavior. Other checks reached by that runner passed. The Fabric Gradle build was not verified because the environment previously could not download its Gradle distribution; this update does not change the Fabric mod target (Minecraft 1.21.11).

## What could be recovered from the stopped run

- The main learner checkpoint at `training/intelligence_7m.bin` decodes successfully at **6,050,626 ticks**, stage 8, **1,088 updates**. Its file size is 2,771,723 bytes.
- Policy snapshots in the stopped run's league directory include later files through `snapshot-6244162.bin`. These have zero optimizer/update state and are frozen opponent policies, **not resumable learner checkpoints**. They must not be mistaken for the main learner's tick count.
- The companion sidecar at `training/intelligence_7m.bin.league/` has been reconstructed with the original 5M checkpoint's saved league ledger and the eight latest valid frozen policy snapshots from the stopped run.
- The recovered `current` rating is the **5M baseline**: Elo 7,905.746; 9,811 games; 4,472 wins; 2,188 losses; 3,151 draws. It is not the rating at 6M or 7M.
- The stopped 7M run's post-5M league match totals cannot be reconstructed reliably because the workers overwrote each other's ledger files. We do not claim that those matches were recovered. The old working-directory `league/ratings.csv` remains for forensic inspection and should not be used as the resumed checkpoint's league ledger.
- The original 5M `training/state.bin` checkpoint and its original sidecar were left untouched.

## No training was restarted

The fix and smoke tests did not launch a training run. The training process remains stopped. To resume later, use `training/intelligence_7m.bin` as the learner checkpoint and keep its companion directory `training/intelligence_7m.bin.league/` beside it. The corrected parallel trainer will share and persist that sidecar safely.
