# v7.32 Situational Combat Experiment

- Added a situation interpreter for distance/range, aim, weapon charge, opponent threat/recovery, follow-up windows and optional boundary context.
- Added tactical intent selection, a confidence-weighted per-opponent behavior model and a counterfactual action evaluator.
- Added a reactive last-mile controller for impossible current-tick attacks, contradictory sprint/sneak inputs and known world-border traps.
- Added event-driven memory for observed hit/whiff outcomes, repeat misses, sprint-hit opportunities and follow-up conversions/expirations.
- Integrated the stack only into play-time action selection; the PPO training sampling/log-probability path is unchanged.
- Added an optional backward-compatible `SIT1` checkpoint trailer and situational status output.
- Renamed the mod ID to `rlpvp_situational_experiment` for side-by-side testing.
