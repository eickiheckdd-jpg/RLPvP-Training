# V7.20.1 memory integration merged into V7.21

This merge restores the omitted `GruCell` trainable recurrent memory and `OpponentMemory` opponent-habit features into V7.21. The GRU has 8 hidden units and 8 fight-signal inputs; PPO trains it using a 16-tick truncated-BPTT window. The GRU weights are persisted in an optional checkpoint trailer, and checkpoints that predate the appended 16 memory inputs are warm-started through the existing input-layout migration.

The live Minecraft `Trainer`, standalone `PvpSim`, parallel-training scripts, and frozen self-play opponent observations now populate these features. Frozen policies carry a snapshot of the matching GRU weights so their recurrent summary inputs match their actor. Explicit `javac` lists and `tests/run.sh` have been updated. V7.21's optimized `Net` forward path is retained; only the input-slice gradients required to train the GRU were added.

## Jump-reset handling

The old V7.20.1 `JumpReset.java` was **not** reintroduced as a second reward path. V7.21 already replaced it with the newer outcome-settled `TechniqueDiscovery` jump-reset logic, and `tests/JumpResetCheck.java` tests that implementation. Running both would risk duplicate / conflicting jump-reset rewards. V7.21's grounded-only W-tap/S-tap gating and the current `SpamGuard` changes are preserved.

## Validation

Run `tests/run.sh` for the Minecraft-free regression checks. `sim/pipeline.sh` and `sim/train_parallel.sh` compile the newly integrated memory components. This merge itself does not start a training run.

## Frozen in-game self-play observation parity

`BotBrain` now populates the optional situational-motion and sprint-hit-follow-up summary blocks as configured, as well as opponent memory. It resets these memories per self-play episode and tracks the last sprint swing only for the bounded hit-credit window, avoiding stale indefinite sprint-hit labels.

## Build environment limitation

The standalone simulator and regression checks compile and pass. A full Fabric/Gradle `compileJava` check could not be completed in this environment because the Gradle wrapper needed to download Gradle 9.5.1 and network DNS resolution for `services.gradle.org` was unavailable. The merge has not been verified inside a running Minecraft client/server.
