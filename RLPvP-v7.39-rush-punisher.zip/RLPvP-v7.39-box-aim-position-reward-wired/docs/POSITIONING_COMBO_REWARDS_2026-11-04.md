# Positioning and combo-pressure rewards (v7.38 + v9 strafe patch)

**v7.39 update:** `sh sim/regression.sh` passes, including reward CSV alignment, positioning-reward lifecycle, bounding-box aim geometry, 126→128 compact-checkpoint migration, simulator/network regressions and league persistence. A 200-tick simulator smoke saved a 128-input checkpoint successfully. No long training run was started. The full Gradle/Fabric build remains unverified because the wrapper could not resolve `services.gradle.org` in this environment.

## 1. Movement and action space: no change needed
- **W/S taps** are already possible: the forward head has S/none/W and sprint is separate. The sim already clears the attacker's sprint after a sprint-knockback hit, so re-sprinting after a tap gives the next hit full knockback again.
- **W+A / W+D** is already possible: forward and strafe are independent heads and `ActionApplier` sets both keys. The v9 patch adds a hold-strafe head on top of that.
- I did **not** add a "tapped after a hit" reward. This project keeps technique rewards outcome-only (`TECH_REWARD_SCALE=0`), and a key-pattern reward is easy to farm. Taps are instead rewarded through their consequences: fewer consecutive hits taken, better spacing, and combo breaks.

## 2. New reward terms (`CombatPositionReward`, wired into `PvpSim`, stage >= 5, training only)
| Term | Default | Meaning |
|---|---|---|
| Space band | +0.005 per tick | opponent 2.5-3.0 blocks away (in addition to the existing 2.0-3.2 charged-spacing term) |
| Look away | -0.03 per tick, episode cap -1.5 | opponent within 3.0 blocks and yaw error over 30 deg |
| Combo break | +0.6, +0.4 more for a sprint-knockback hit; once per chain | agent lands a hit after taking 2+ consecutive hits |
| Consecutive hits | -0.25 x min(streak-1, 3) | each further hit taken without hitting back inside 20 ticks |
| Airborne hit | -0.2 | hit taken while airborne, as the second or later hit of a chain |

- **Scale:** at `W_DAMAGE=12` a normal hit is worth about 0.6 or more, so these are meaningful but smaller than the damage signal. The PPO reward normalization applies afterwards.
- **0.5 s window:** I used 20 ticks, not 10. Vanilla hit invulnerability means two hits on the same target can never be closer than about 10 ticks, so a 10-tick window would almost never fire.
- **Jump penalty:** it targets being hit while airborne in a chain, not pressing jump. Jump-reset (SpamGuard's "justified reaction") stays free, and only its bad outcomes are charged.
- **Tuning:** every constant is overridable with `-Drlpvp.pos.<name>=...` (`band`, `bandMin`, `bandMax`, `lookDist`, `lookDeg`, `lookPenalty`, `lookCap`, `breakReward`, `breakKbBonus`, `consecWindow`, `consecPenalty`, `consecSteps`, `airbornePenalty`, `minStage`). `-Drlpvp.positionReward=false` turns the whole class off.

## 3. Trainer wiring fix (v7.39)
- `Trainer.java` now calls `CombatPositionReward.tick(...)` in TRAIN mode, adds the returned sum to the same per-tick reward passed into `agent.addReward(reward)`, and sends the class's five `lastTerms()` values to `Reward.Telemetry`. This closes the previous simulator-only wiring gap.
- The same change is preserved in `PvpSim`, so simulator and mod training apply the same term set, stage gate, and per-tick outcome inputs.
- The audit CSV has five matching columns: `positionBandReward`, `positionLookAwayPenalty`, `positionComboBreakReward`, `positionConsecutiveHitsPenalty`, and `positionAirborneHitPenalty`.
- The Trainer resets the reward state at episode rebaseline, matching the simulator reset. This wiring is source-implemented; a complete Fabric build is still needed to validate it against the actual Minecraft/Fabric dependency graph.
- The reward magnitudes are my estimates from the existing config, not tuned. Watch `lookAway` and `band` in the reward audit: if the agent starts kiting at 2.5-3.0 instead of fighting, lower `band` or raise the fight rewards.
- The new class was added to every `javac` list that already contained `ComboDefenseTracker.java` (`sim/*.sh`, `tests/run.sh`). Scripts that did not include it (aim stability, model info, prediction, combat bench) were not changed.

## 4. Airborne target-box observations and pitch response
- Compact observations are now 128-wide. The two appended fields encode target-centre yaw/pitch error divided by the projected half-width/half-height of the player's bounding box, then smoothly squashed to a bounded range. The target AABB comes from `Player.getBoundingBox()` in the mod; the simulator uses its player hitbox dimensions.
- The existing `MotionMemory` target angular-velocity estimates remain in place, as do self/opponent vertical velocity and on-ground observations. The new two fields are added to the GRU policy input, including horizontal mirror symmetry.
- The live and simulator pitch action scale was raised from 15 to 30; yaw stays at 45. This makes the existing physical camera controller more responsive vertically without issuing any aim command or replacing the policy's action. The policy should be retrained/evaluated under the matched new camera scale before treating the checkpoint as final.
- There is no hard-coded crosshair steering, forced pitch correction, scripted target-centre snap, or airborne aim rule.
