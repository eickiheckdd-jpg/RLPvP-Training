# Tuning pass (nothing was run; javac compile check of the sim file list only)
- ROLLOUT 1024 -> 2048 (more episodes per GAE/advantage batch; MINIBATCH/EPOCHS/LR unchanged, so cost per sample is unchanged).
- SHAPING_MIN 0.35 -> 0.15 (facing/closeness floor lowered; the shaping is already small next to win 3.0 / damage 2.4 after REWARD_SCALE).
- Spam: SPAM_SNEAK_RATE_W 0.003->0.012, SPAM_TOGGLE_RATE_W 0.0045->0.02, SPAM_SNEAK_TOGGLE 0->0.002, SPAM_MOVE_EPISODE_CAP 0.8->1.2. Hit/taken grace and idle gate kept.
- NOT done: no hyperparameter sweep. A real sweep needs runs (e.g. 3 seeds x LR/rollout/entropy grid, compare win-rate at fixed ticks).
- Rewards now differ from earlier checkpoints: expect a short readjustment period.

## Weak / sweep hit penalties
- CombatPositionReward: new terms weakHit (-0.30, hit swung below FULL_CHARGE) and sweepHit (-0.15, full-charge grounded non-sprint non-crit hit), episode cap 2.0, active from the same stage as the other position terms (5). Wired in PvpSim and Trainer via noteHitType() before tick(). Override with -Drlpvp.pos.weakPenalty / sweepPenalty / hitQualityCap.
- Caveat: the sweepHit penalty pushes the agent toward sprint hits and crits; if it cannot sprint (cornered, sneaking) its only hits are penalised. Lower it if hit rate drops.

## Parallel training throughput
- ParallelPvpTrain worker cap is now -Dsim.maxWorkers (default 8, unchanged); train_parallel.sh adds -XX:+UseParallelGC. Launch: `JAVA_OPTS="-Dsim.maxWorkers=16" sim/train_parallel.sh 5000000 out.bin 1 - 12`.
- Round structure is collect (parallel) then learn (serial). With collect share c and learn share l of single-env time, speedup with K workers = K(c+l)/(c+K*l). Example c=0.6,l=0.4: K=3 -> 1.7x, K=7 -> 2.1x, ceiling 2.5x. Shares are ASSUMED, not measured here.

## Sneak flicking while moving
- SpamGuard.moveTick: the sneak-TOGGLE-rate penalty (threshold 0.16, weight 0.02) now also applies while moving; still waived for SPAM_HIT_GRACE after a hit and SPAM_TAKEN_GRACE after damage; still bounded by the per-tick (0.01) and per-episode (1.2) caps. Steady sneak holding remains idle-only. No input is blocked.

## Strafe jitter
- New Config.STRAFE_ENTROPY_FLOOR_FRAC = 0.18 (-Drlpvp.strafeFloor), used only for the strafe head in PpoAgent.updateHeadEntropy; fwd/back and jump keep 0.35, sprint 0.2. Rationale: the 0.35 floor forces ~0.38 nats of noise per tick on a 3-way head. Unmeasured; if strafe collapses to one side, raise it back toward 0.25.

## Weak-matchup opponent sampling (stages 7-8 added)
- OpponentLeague already sampled opponents the agent is weak against (matchup W/L/D + damage deficit, confidence-smoothed over 12 games, weight capped at 2x, 20 % corrective share, needs >= 3 matchup games and Elo-expected win 35-50 %) but only at stage 9. Config.WEAKNESS_FROM_STAGE (default 7, -Drlpvp.weaknessFromStage=99 disables) now enables it for stages 7-8 in PvpSim and Trainer; weakness log line printed from that stage.
- A 1/4/0 record = 5 games, score rate 0.2, confidence 0.42 -> weight about 1.3-1.5 and eligible for the 20 % corrective pool. Side effect: from stage 7 aggressive specialists also get the existing 1.35x coverage weight.
- Not applied below stage 7: those stages pick styles randomly per episode and gate promotion on win rate, so over-sampling hard styles would bias the gate.

## Crit + sprint mix (no new shaping)
- No reward added. Opponent bots already adapt to jump spam (BotAI antiJump + adapt) and the jump/sprint heads keep entropy floors. Monitor the crit/sprint/sweep/weak hit shares in the telemetry; if one dominates, add an opponent that punishes it, not a reward.

## Architecture
- Left at MLP 128x128 + GRU H=64 (changing it breaks checkpoints and cuts TPS). -Drlpvp.hidden=256,256 is supported with widening transfer for the MLP; the GRU size has no migration.

## AIR_PUNISHER bot (style 11, BotAI.STYLES 11 -> 12)
- Fair like every BotAI style (same lag/aim/cooldown). Reads the agent's jump (antiJump 0.95) and steps out of reach so the falling crit whiffs, rushes the landing (existing punish rule), and if the agent is airborne inside reach it strikes FIRST with a sprint hit (airPunish 0.55-0.95 per tick, skips the click delay/fire roll). Other styles have airPunish=0 and draw no extra random numbers.
- Enters the league pool automatically (candidates loop to BotAI.STYLES, so stage >= 7, weakness-weighted) and the ChampionEvaluator loop; also a 5 % (strong) / 7 % (aggressive) slice of the random per-episode mix, taken from HUMAN's tail with no extra RNG draw.
- Why the opponents sometimes do not swing when charged and in range: the swing needs ALL of: dist <= 3.2, charge >= 0.9, readyAge > clickWait (0-2 ticks), no attention lapse, per-tick fire roll (0.30+0.65*difficulty), HUMAN click cooldown, phase != regroup (unless agent recharging), predicted crosshair on target (lagged), SELECTOR hold-back, SPACER too-close rule, and not in a w/s-tap or crit-arm tick. Deliberate "human" behaviour, unchanged.

## Weakness-biased bot styles below the league stages (stages 3-6)
- Config.STYLE_WEAKNESS_FROM_STAGE (default 3, -Drlpvp.styleWeaknessFromStage=99 off). Training sims only (PvpSim.main and ParallelPvpTrain workers set weaknessStyles=true; probes, evals and benchmarks keep the original random mix).
- The per-episode random style draw becomes OpponentLeague.sampleStyle(BotAI.mixWeights(strong)): base share x matchup weight (1..2, from W/L/D + damage deficit, confidence-smoothed over 12 games). Styles are never made rarer than base before normalising; nothing is forced. Results are recorded with styleResult() (matchup counters only: no Elo, no games count) and persist in the league CSV.
- Known trade-off: the stage gate is a win rate, so over-sampling weak styles lowers it slightly and can delay promotion a little. mixWeights duplicates the thresholds in BotAI.newEpisode; keep them in sync if those change. Mod (Trainer) path not changed.
- In-game trainer: Trainer.startOpponent now draws the scripted style with the same bias (stage >= STYLE_WEAKNESS_FROM_STAGE, STRONG/AGGRESSIVE only, TRAIN mode only), passes it via bots.leagueStyle, and records the result with styleResult() at episode end (league CSV saved right after, like the Elo update). NOT compiled (needs Minecraft/Fabric): only a parse check with javac, which showed no syntax errors.

## League: new opponents get played (needed at stage 7-9)
- Problem found in my own change: PFSP only samples opponents whose Elo-expected agent win rate is 50-70 %. A NEW style (AIR_PUNISHER, script:11) starts at Elo 1200; a stage-9 agent rated well above that is outside the band, so it would almost never be sampled and its rating could never be measured.
- Fix (OpponentLeague.sample): a candidate with fewer than 12 Elo games stays eligible and gets a minimum weight of 0.6 (NEW_OPPONENT_GAMES / NEW_OPPONENT_MIN_WEIGHT). Snapshots copy the current games count, so they are unaffected; only genuinely new ids (new styles, a new rival) get the exploration share until measured.
- tests/Stage9LeagueCheck puts every entry at 1200 with 0 games, so its distribution assertions may need updating; not run.

## RUSH_PUNISHER bot (style 12, BotAI.STYLES 12 -> 13)
- Rusher + air punisher: spacing 2.3 (inside reach), antiJump 0 (never backs off from a jump), airPunish 0.70-1.00 per tick (strikes first with a sprint hit the moment the agent is airborne inside reach), rusher fire bonus, sprint threshold 2.8, counts as an aggressive specialist (1.35x coverage weight in the league).
- Why: the AIR_PUNISHER's retreat and its strike range (<= 3.2) work against each other and its ring (3.4) sits outside its own strike range; the hybrid stays in range. Not measured.
- Random mix shares (stages 3-6): strong HUMAN 27 / AIR 4 / RUSH_PUNISHER 5 %, aggressive HUMAN 12 / AIR 5 / RUSH_PUNISHER 5 %; BotAI.mixWeights updated to match. League pool and ChampionEvaluator pick it up through the STYLES loop; new entries get the new-opponent exploration weight.
- sim/StandingEval.java style list extended with AIR_PUNISHER and RUSH_PUNISHER (it printed only the first 11 styles): `sim/standing-eval.sh` now reports a score with a 95 % CI for each, which is the way to measure how hard they are.
