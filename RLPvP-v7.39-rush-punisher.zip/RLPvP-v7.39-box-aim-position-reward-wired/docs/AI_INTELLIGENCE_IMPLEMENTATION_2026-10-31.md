# RLPvP AI intelligence implementation and bug review — 2026-10-31

## Intent and non-goals

This implementation prioritizes learned opponent adaptation and reliable combat feedback without replacing the policy with a hand-authored fighting script. It does not change Minecraft combat formulas, the simulator's Minecraft 26.3 combat port, attack reach/cooldown/knockback physics, camera rotation, aiming filters, or the Fabric mod's Minecraft 1.21.11 target. It does not change PPO actor/critic/world-model dimensions or edit checkpoint weights.

The actor retains its existing action space. No fixed combo sequence, forced critical pattern, scripted dodge, hard-coded aim correction, or mandatory attack/retreat rule was added.

## Implemented changes

### 1. Persistent opponent adaptation

`OpponentBehaviorModel` now stores a bounded set of up to 16 named opponent profiles and persists them in the existing situational checkpoint trailer. The in-game episode hook supplies the opponent scoreboard name. The profile tracks the same eight habit meanings already present in `OpponentMemory`:

- strafe activity and direction-flip rate;
- sprint and airborne shares;
- swing-start rate;
- preferred distance;
- radial approach/retreat pressure;
- counter-hit rate after the agent lands a hit.

Before play-policy inference, the active opponent profile overlays the matching eight existing habit inputs in a scratch observation. A newly encountered profile only replaces episode-local habit inputs after 80 fresh observations (four seconds at 20 TPS); a previously stored profile is available immediately. This avoids letting a short, noisy opening sample overwrite the current-episode estimate. The profile table is bounded to 16 entries and uses least-recently-used eviction. The trained observation shape and network weights remain unchanged; the learned actor decides what to do with the remembered tendencies. The recurrent eight-feature memory remains episode-local and unchanged.

The profile uses a dedicated `OPM2` trailer record. It reads the older `OPM1` six-stat layout. Since the old layout did not measure the new policy habits with matching definitions, migrated profiles keep their legacy tactical values but start the new policy-facing habits neutral and wait for fresh samples before overlaying them. This avoids injecting guessed/semantically mismatched history into the actor.

### 2. Correct radial opponent-motion memory

The episode-local `OpponentMemory` previously estimated approach pressure primarily from forward velocity and the sign of relative forward position. That discarded lateral position/velocity and could mistake diagonal movement. It now projects the opponent's two-dimensional horizontal velocity onto the full relative-position vector:

`approach = -dot(enemyVelocity, enemyRelativePosition) / distance`

Positive values mean the opponent is moving toward the agent; negative values mean retreating. The persistent profile uses the same radial definition. The persistent strafe activity threshold also matches the episode-local habit encoder.

### 3. Causal combat-event memory

`EventDrivenCombatMemory` now keeps each emitted attack pulse pending for the configured `HIT_CREDIT_TICKS` window instead of immediately calling an unresolved swing a whiff on the next frame. Multiple nearby pending attempts are tracked independently; a confirmed damage event is attributed to the newest still-creditable attempt, and older uncredited attempts expire separately.

When the opponent's health actually decreases, hit type comes from the current `HitMemory` summary. This fixes two incorrect proxies in the earlier implementation: `canCrit` eligibility is not itself a confirmed critical hit, and the agent's sprint state is not proof that a sprint hit landed. A stored swing-context estimate is used only as a fallback when there is no health-damage confirmation (for example, on a hurt-animation-only server); such a fallback is an estimate, not an exact hit-type claim.

The memory also records confirmed normal/critical/sprint/sweep/weak hit categories, applied attack attempts, range/aim whiffs, follow-up opportunities and conversions, combo length, interrupted combos, and punish-window conversions. `Trainer` reports the actual `ActionApplier` result after the click path: an attack intent suppressed by a GUI, block ray or cooldown is not logged as an emitted swing. A target-ray click with no subsequent damage is retained as an unsuccessful attempt, but is not mislabeled as an aim/range miss. Combo chains close after a 20-tick gap or incoming damage, so unrelated hits are not merged into one indefinitely growing combo. Punish windows are counted on their opening edge rather than once per tick. The event trailer uses `EVM2` and still reads the old `EVM1` counter layout.

### 4. Learned decision path stays in control

`PpoAgent.actPlay` updates the situational and opponent memories before policy inference, so the policy sees the current observation and the persistent opponent profile together. A cleared scratch observation is used to prevent stale data if a shorter observation is ever passed.

The default play stack remains `PLAY_STACK=2`, while the default `INTEL_OFF` mask is `127`. This disables the hand-authored strategic action enforcement, candidate scoring and candidate guidance channels by default. The optional `PLAY_STACK=3` mode also skips the unused heuristic intelligence-suite update path. The policy and validated learned consequence-model candidate search remain available. The reactive controller remains as a last-mile feasibility guard for invalid attack timing/rays, contradictory sprint combinations, non-finite actions and boundary traps. Situational attack telemetry now receives the actual `ActionApplier` click result from `Trainer`; a policy attack intent suppressed by a block ray, GUI, cooldown or unavailable game mode is no longer falsely counted as an emitted swing. A target-ray click that causes no health change remains an unsuccessful attempt but is not misdiagnosed as an aim/range error. An older enforcement-enabled behavior can still be selected explicitly with `-Drlpvp.intelOff=96`; `=0` is available for heuristic ablations.

This is intentionally not a hard-coded defensive or combo planner. Defensive reasoning, spacing, combo continuation and timing remain decisions for the trained policy/model, using the existing observations and learned memory features.

## Bug and compatibility review

| Area | Finding | Resolution |
|---|---|---|
| Opponent motion memory | Forward-only approximation lost lateral/radial movement information. | Use full 2D radial projection in both local and persistent habit memory. |
| Persistent profile migration | Old six-field profiles did not contain the new policy habits. | Migrate old diagnostics, neutralize new habit fields, and require 80 fresh observations before overlay. |
| Persistent profile isolation | A profile could otherwise leak across opponents if keyed incorrectly. | Store and restore by sanitized scoreboard name; tests verify separate names. |
| Runtime profile overhead | The first draft copied a profile into the lookup map every observation tick, allocated a profile snapshot every tick, and allocated an 8-value array for policy injection. | Persist only at episode/checkpoint boundaries, use a read-only active-profile view inside the stack, and write the eight encoded inputs directly into the scratch observation. |
| Profile confidence / eviction | Short opening samples could replace the current-episode habit estimate; a fixed insertion-order cache could evict repeatedly used profiles. | Require 80 fresh samples for a new profile overlay and use a bounded 16-entry least-recently-used profile table. |
| Hit classification | `canCrit` and own sprint state were being treated as if a crit/sprint hit had landed. | Prefer `HitMemory`'s confirmed last-hit category on a health-damage event; explicitly label the state-based fallback as an estimate. |
| Hit/whiff timing | A swing could be called a miss before the six-tick credit window had elapsed. | Delay whiff resolution until the credit window expires. |
| Attempt accounting | A policy attack request could be counted even when `ActionApplier` suppressed the click. | Confirm the queued click through a post-application feedback hook before starting its hit-credit window. |
| Overlapping attacks | A single pending slot could drop a later attack around the relaxed charge threshold. | Track bounded independent pending attack pulses and match the newest eligible pulse. |
| Punish telemetry | A single recovery window could be counted repeatedly on every tick. | Count the transition into the window once. |
| Combo continuity | Current combo length could remain open indefinitely across long gaps. | Close combo after a 20-tick gap or incoming damage. |
| Scripted overrides / unused planner work | Default mask `96` left lower strategic action-enforcement bits enabled; even with all layers disabled the intelligence suite still updated per tick. | Default mask `127` disables all hand-authored strategic enforcement/scoring/guidance and skips the unused suite update while retaining reactive feasibility. |
| Observation scratch | A shorter input could leave stale values in the copied play observation. | Zero the scratch observation before copying. |

## Verification performed

`sh sim/regression.sh` completed successfully after the changes:

- `NetworkSimulationTest`: 15 passed.
- `PvpSimNetworkTest`: 11 passed.
- `OutcomeRegressionTest`: 43 passed.
- `SprintHitFollowupMemoryTest`: 12 passed.
- `CombatObservationMemoryTest`: passed.
- `Minecraft26PhysicsTest`: 25 passed.
- `MinecraftRulesCheck`: all checks passed.
- `DiamondProt3KitTest`: 27 passed.
- `Minecraft263CombatTest`: 34 passed.
- `MeasuredCombatMergeCheck`: passed.
- New `OpponentAdaptationCheck`: passed (profile update, radial pressure, policy overlay, OPM2 round-trip, OPM1 migration, opponent separation).
- New `EventDrivenCombatMemoryCheck`: passed (actual-click gating, delayed hit credit, hit categories, follow-up conversion, overlapping attack windows, saturated hit counter, combo-gap reset, delayed whiff resolution, and no false range/aim diagnosis after a target-ray click).
- `SituationalCombatStackCheck`: passed (default strategic overrides disabled, explicit ablation paths, learned-only mode, safety guard and checkpoint trailer).

These are deterministic regression tests, not an in-game win-rate benchmark. No training was run, no checkpoint weights were modified, and no improvement in win rate is claimed from these code tests alone. A larger fixed-seed multi-style standing evaluation is still required to quantify gameplay impact.

## Files / boundaries

Main implementation files:

- `OpponentBehaviorModel.java`
- `OpponentMemory.java`
- `SituationalStateInterpreter.java`
- `EventDrivenCombatMemory.java`
- `SituationalCombatStack.java`
- `PpoAgent.java`
- `Config.java`

Tests and script registration:

- `tests/OpponentAdaptationCheck.java`
- `tests/EventDrivenCombatMemoryCheck.java`
- `tests/SituationalCombatStackCheck.java`
- `sim/regression.sh`
- `tests/run.sh`

The 5M checkpoint remains unchanged. This update is a source-code change only; install/build it against the existing project and keep the mod targeting Minecraft 1.21.11.
