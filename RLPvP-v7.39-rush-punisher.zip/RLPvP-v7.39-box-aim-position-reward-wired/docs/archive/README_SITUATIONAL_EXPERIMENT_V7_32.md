# RLPvP v7.32 — Situational Combat Experiment

This is a **separate experimental copy** based on the uploaded v7.31 project. It does not edit or share files with the v7.31 3M training run.

## What was added

1. **Situational state interpreter** (`SituationalStateInterpreter.java`) translates the current observation into range, aim, cooldown, threat, recovery, follow-up and boundary context.
2. **Tactical decision engine** (`TacticalDecisionEngine.java`) selects a high-level intent each play tick: ENGAGE, PURSUE, PUNISH, DEFEND, REPOSITION, COMBO_FOLLOWUP, BAIT or DISENGAGE. Intent changes candidate scores; it is not a fixed per-state action script.
3. **Reactive combat controller** (`ReactiveCombatController.java`) validates attack feasibility and key combinations, and can move away from an exposed world-border edge when boundary direction is available.
4. **Opponent behavior model** (`OpponentBehaviorModel.java`) estimates attack/sprint/jump/retreat/strafe/counter tendencies, with confidence that grows with observations. Compact profiles are keyed per opponent and saved with the agent.
5. **Counterfactual action evaluator** (`CounterfactualActionEvaluator.java`) compares estimated hit probability, damage opportunity, counter risk, movement/range, follow-up chance, and resource/whiff costs. It composes with the existing learned consequence model when that model passes its validation gate.
6. **Event-driven combat memory** (`EventDrivenCombatMemory.java`) records observed hit/whiff outcomes, out-of-range/off-aim failures, recent failed actions, sprint-hit opportunities, follow-up conversions and expirations. Aggregate metrics persist across saves; transient event windows reset between matches.

## Action/training safety

The stack is called only from `PpoAgent.actPlay()`. **`actTrain()` still samples directly from PPO and stores the exact sampled action/log-probability**. This prevents tactical overrides from corrupting PPO's likelihood ratios. The existing reward and evaluation code remains in place; technique names do not receive new intrinsic reward bonuses from this layer.

The checkpoint format adds an optional `SIT1` trailer after the existing trailers. Old checkpoints still load; new checkpoints retain per-opponent behavior profiles and aggregate situational diagnostics. The Fabric ID is `rlpvp_situational_experiment`, so the experimental build can coexist with the original mod.

## Boundary limitation

The client attempts to use the Minecraft **world border** as a boundary signal by reflection. Many PvP arenas have their own walls that are not the world border; those arena-specific bounds are not inferred without a dedicated arena geometry source. When no trustworthy bound is available, boundary handling is neutral rather than fabricated.

## Validation performed

- All new situational classes and `PpoAgent.java` compiled with `javac` against the existing simulator classes.
- A synthetic 100-tick exercise checked finite actions, sprint/key consistency, saving, and reloading the situational trailer.
- A short simulator evaluation started and emitted normal episode statistics, but the broad evaluation sweep exceeded this environment's command time limit before all cases completed; no performance improvement is claimed yet.
- `sh sim/regression.sh` passed, and a 250-tick simulator smoke run saved a checkpoint successfully.
- `sh tests/run.sh` passed through the new situational stack smoke test, then failed at the existing `CritSatiationCheck` assertion `late-stage entropy gradually decays at halfway`. I independently ran that test against the original v7.31 checkout and observed the same failure; `Config.java` is byte-identical between v7.31 and this experiment. The situational changes do not fix or alter that unrelated baseline issue.
- The full Fabric/Gradle build could not be run here because the Gradle wrapper attempted to download Gradle and this environment could not resolve `services.gradle.org`. The Minecraft-dependent `Trainer` integration therefore still needs a full Gradle build in an environment with dependencies cached or network access.

## Build/evaluation

With Gradle dependencies available, build with `./gradlew build`. The simulator-only scripts were updated to compile the new source files. Run `sh tests/run.sh` for the existing Minecraft-free regression suite, then compare a held-out checkpoint on the same opponents with and without the situational layer before making it the production version.
