# v7.18 (on v7.17-merged)

## Fixed (verified)
- 10 sim scripts (eval, bench, probe, aimprobe, consistency, pipeline, regression, train_parallel and others) could not compile: `MotionMemory.java` was missing from their javac lists (run.sh / tests/run.sh / modelinfo.sh had it). Added. After the fix `sim/run.sh` and `sim/eval.sh` ran. NOT fixed/checked: `sim/league.sh` and `sim/train.sh` do not use the same javac line (they take a prebuilt classes dir) and were not run.

## Experiment (measured, small)
Resume from `training-results-v7.2/checkpoint-300000.bin`, seed 7, 80k ticks (to 380k), current default sim (diamond + Protection III kit, kit-aware episode limit), then `sim/eval.sh` 30 episodes. Same code, only `-Drlpvp.missCost` differs.
- A (miss cost 0): train whiff 83 % -> 75 %, damage dealt ~5-8 HP/ep, stayed in stage 7.
- B (miss cost 0.12 per missed swing): train whiff 79 % -> 81 %, dealt 8.5 -> 6.6, ended back in stage 6.
Single seed, ~55 episodes per window: the cost did not reduce whiffs. The option stays in the code (`Config.MISS_COST`) but is OFF by default.

## Findings
- The v7.2 checkpoint was trained in the OLD simulator (unarmored, 300-tick episodes). In the current default sim (diamond + Prot III) it mostly times out (draw 60-98 %) and wins 0 %, so old win-rate numbers do not transfer. Train from scratch or from an early checkpoint under the current kit to get comparable results.
- Whiff stays 75-90 % in every evaluation: the policy swings without being on target. A reward tweak on misses was not enough in 80k ticks; the likely lever is a longer run under the new kit, or gating the attack head with the observed aim error (not tried).

## Not done
No Gradle/mod build, no long training, no multi-seed comparison; Trainer.java edit (miss cost, default off) not compiled.
