# Stage-8 problem fixes (2026-11-01) and handoff

Base: RLPvP_AI_STAGE8_CURRICULUM_FIX_2026-11-01.zip. No checkpoint was in the zip, so none of the behavioural effects below were measured on your trained policy. A 600k-tick fresh run on the 2-core build box could not reach stage 8.

## Fixed and verified (new tests, all pass)
1. **Jump telemetry (3,197 commands, 0 starts).** Root cause: `PvpSim` computed `d.jumpStart` but never called `rewardTelemetry.noteJumpStart()` (only `Trainer` did). Fixed in `sim/com/rlpvp/PvpSim.java`. `tests/JumpStartTelemetryCheck`: 1496 commands / 460 starts after fix; negative control without the fix reproduces 1496 / 0.
2. **Camera penalty.** `CameraReward` STILL charged full mouse speed even while tracking a strafing target. It now charges only speed beyond what the target's own motion requires (`-Drlpvp.trackingStill=false` = old behaviour). `tests/CameraTrackingRewardCheck`: perfect tracker of a 3 deg/tick target cost -0.534 (old) vs -0.002 (new); jitter still costs about -5.0 via STILL+JERK. Also added per-term camera totals (progress/overshoot/jerk/still/hold/critWindow) to the training log line ("camera terms ..."), so the -101.9 can be attributed next run.
3. **Whiff gate.** Attack mask distance 4.0 -> 3.7 (max real hit is about 3.42 between centres). Yaw limit is now range-dependent, atan((0.42+0.5)/dist) clamped to 10..45 deg. `tests/AttackGateGeometryCheck` against exact ray/box geometry: legacy gate masked 233 real-hit configurations; new gate masks 0. Trade-off: more swings are offered up close (misses offered 3230 -> 4267 in that grid), fewer at range. Legacy: `-Drlpvp.attackGateLegacy=true`.

## Investigated, not bugs (no code change)
- **Spacing 163 vs 530:** "success" = exchange won AND no hit taken back (TechniqueDiscovery.settle). It is not a plain success rate, and failures include winning exchanges where you got hit back.
- **Combo conversion 32/125:** strict definition (a further real hit within 6-30 ticks with nothing taken). Interrupted/timeout counts are in the log; it reflects behaviour, not a counting error.
- **Champion gap:** `ChampionEvaluator` uses 5 episodes x 11 styles, so scores are noisy. No change made.
- **Damage taken 17.4 vs dealt 19.1:** no change; reward is already outcome-first.

## Test status
`tests/run.sh` (new tests registered) stops at `GameplayRotationCheck`: 4 FAILs (cases 2, 7, 8, fine aiming). These fail identically on the untouched original zip and `GameplayRotation.java` is unchanged, so they are pre-existing. Tests after it in run.sh were therefore not run in the full script (the three new tests were run individually and pass).
Not compiled here: Minecraft-side classes (Trainer, ActionApplier, BotBrain, RlHud). The one-line Trainer edit (`addCameraTerms`) is unverified.

## To continue
1. Retrain or resume from your stage-8 checkpoint and compare the log: whiff %, "camera terms", jump cmd/start.
2. Decide whether to fix or update `GameplayRotationCheck` (AimBrake/rotation expectations vs current controller).
3. If whiff stays high, use the whiff split (far / off-aim / near) from `PvpSim.EvalStats`; that shows whether aim or timing is the cause.
4. Consider more episodes or confidence intervals in `ChampionEvaluator`.
