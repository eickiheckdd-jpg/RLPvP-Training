# RLPvP reward-balance audit and implementation

Date: 2026-11-01  
Target mod version: Minecraft 1.21.11  
Scope: reward shaping, hit/technique telemetry, and controlled evaluation instrumentation. This update does not change the target Minecraft version, the stopped training checkpoint, or start training.

## Executive decision

The default reward objective is now **outcome-first**. The policy is paid for real credited HP damage, avoiding damage, and winning the episode. Crit, sprint-hit, jump-reset, combo, W-tap/S-tap, and other named technique labels are recorded for analysis but do not carry standalone positive reward. A critical hit still receives its genuine extra Minecraft damage through the normal HP-damage reward; that damage is never discounted because of crit frequency.

This is deliberately conservative. The previous reward had several overlapping sprint incentives and jump/airborne disincentives. Without measured reward mass and held-out combat results, adding another compensating crit bonus would risk replacing one arbitrary preference with another. The new audit first measures each reward source and each technique's real exchange outcomes; any later technique shaping should be introduced only as a paired, same-checkpoint experiment.

## Root-cause review of the previous code

The previous code had multiple incentives pointing toward sprint hits:

- `Reward.critSatiationBonus` granted `+3.5` for a sprint hit. A critical hit received `+2.0` only below a 35% crit-density threshold and `+0.2` above it. `sprintDensity` was calculated but unused, so there was no matching sprint-hit saturation.
- `Config.TECH_SPRINT_HIT` was `0.45`, compared with `TECH_CRIT` at `0.10` (4.5 times larger). Sprint also had a `+0.6` charged-opponent multiplier while crit had a `-0.3` charge adjustment.
- `SPRINT_LANE_W=0.008` added a repeatable dense reward while a charged sprint attack was available at a favorable distance and facing angle.
- Jump/airborne behavior had several costs: `TECH_AIR_HIT_PENALTY=0.25`, `TECH_MISTIMED_HIT=0.20`, and SpamGuard's unjustified-jump cost/rate terms. These could discourage exploration before the agent learned falling-phase timing.
- A crit-excess discount could reduce actual crit damage in the reward path.
- New policy initialization strongly skewed the action biases toward sprint (`+1.0`) and away from jump (`-1.2`). This affected newly initialized agents, not an already-trained checkpoint.

The old `OUTCOME_ONLY_REWARDS=true` setting did not disable all of these systems: the per-hit satiation, technique-discovery rewards, and sprint-lane reward had separate code paths.

## Changes implemented

### Reward objective and balance

- Retired direct per-hit crit/sprint satiation bonuses. `sprintDensity` no longer has an unused/one-sided role; hit identity is not independently paid.
- Set technique-discovery reward scale to zero by default. Discovery remains enabled so technique events, exchange wins/losses, and damage outcomes are measured.
- Set crit and sprint technique bases to equal neutral compatibility values; removed sprint-only charge uplift, crit charge cut, and rarity/complement uplift from the active reward path.
- Disabled sprint-lane shaping. Eligible sprint-lane ticks are counted as opportunities only.
- Removed generic jump-frequency refunds/costs, airborne-hit penalties, and mistimed-air-hit identity penalties from default reward. A bad jump should be judged by the damage it causes and the episode it loses, not by the fact that it was a jump.
- Removed crit-damage discounting. Server-model-confirmed crit damage is credited as actual damage.
- Retired legacy direct crit, sprint, combo, and first-hit bonuses in `Reward.techBonus` configuration. The default remains outcome-first.
- Neutralized newly initialized jump/sprint action biases (both output biases start at zero, rather than a sprint-heavy prior). This changes initialization only; it does not rewrite logits in an already loaded checkpoint.

The actual per-HP damage reward and terminal win/loss reward remain intact. Existing non-technique terms (aim/camera, approach, spacing, time and movement-quality terms) remain visible in the new reward decomposition so their magnitude can be evaluated rather than guessed.

### Reward-contribution telemetry

`Reward.Telemetry` records the raw, pre-PPO-scale contribution of:

- real HP damage dealt and taken;
- capped soft-hit credit (separated from actual damage reward);
- facing, pitch, closeness, approach progress, spacing, and HP-lead shaping;
- time, legacy technique, discovery, orbit, camera, jump guard, movement guard, terminal, and other reward;
- signed net reward plus gross positive, gross negative magnitude, and gross absolute reward, so positive and negative camera/shaping terms cannot hide one another through cancellation.

The breakdown is assembled from the exact values returned by `Reward.tick` and the additional reward components added by the trainer/simulator. `RewardAuditCheck` verifies that the base decomposition sums to the returned base reward and that the audit CSV columns remain aligned.

### Jump / critical-hit opportunity telemetry

The reward-audit CSV records:

- jump command rising edges and observed jump starts;
- actual swing attempts, falling-phase swing attempts, and full-charge/non-sprinting/falling crit-candidate swings;
- client-labelled crit and sprint hits and their associated credited HP damage;
- simulated-server-model attack attempts, crit-eligible attempts, sprint-eligible attempts, confirmed crit hits, and sprint-knockback-confirmed hits;
- crit and sprint conversion rates, plus sprint-lane opportunity ticks.

The simulator's `PvpSim` telemetry is authoritative **within its own simulated server model**: it observes the server-side attack processing branch and only counts a crit/sprint hit after that modeled server accepts the attack. This is not a live Minecraft server packet trace and should not be described as real-server confirmation. `Trainer` running inside the Fabric client cannot inspect the server's internal knockback branch, so it records client labels and explicitly marks server confirmation unavailable rather than inventing it.

The simulator's server-attempt denominator is limited to attacks that reach the modeled server, have a selected target, and pass its independent range check. It is not a denominator for every raw attack-button press. `swingAttempts` is the client-side gated swing-attempt count.

### Exchange and sprint-follow-up telemetry

`TechniqueDiscovery` records technique-tagged exchange event counts, won/lost outcomes, exchange damage dealt/taken/net HP, jump-reset/knockback separation diagnostics, and sprint-hit follow-up conversion / interruption / timeout statistics.

Exchange HP is attached to the event's shared exchange window (20 ticks by default). If multiple technique labels are active in the same window, the same exchange HP can appear in more than one technique row. These columns are diagnostic association, **not causal per-hit attribution**. Use the separate simulated-server-confirmed crit/sprint hit HP columns for direct hit-type HP totals.

### Files produced during future training

For the parallel simulator trainer, audit sidecars are written next to the chosen checkpoint:

- `<checkpoint>.reward-audit.csv`
- `<checkpoint>.technique-audit.csv`

The Fabric trainer writes `training/reward-audit.csv` alongside the existing training and technique logs. These files contain measurements only; they do not change training decisions or automatically promote a checkpoint.

## How to interpret the audit

1. Compare `positiveReward`, `negativeRewardMagnitude`, and `absoluteReward` as well as each component's net total. Camera and other signed components can cancel across a log window.
2. Check whether actual dealt/taken HP reward and terminal outcomes remain materially represented relative to dense shaping, camera, and movement terms. The audit reports raw reward contributions before `Config.REWARD_SCALE`; PPO later forms GAE advantages and normalizes advantages across a rollout. The CSV therefore diagnoses reward mass, but does not pretend to be a direct decomposition of the final normalized policy gradient.
3. Inspect `critCandidateSwings / swingAttempts` first. If candidates are rare, the problem is action exploration/timing rather than crit reward value.
4. In the simulator, compare `serverCritAttempts` to `serverCritConfirmed` and `serverSprintAttempts` to `serverSprintKnockbackConfirmed`. Compare these with client labels to spot timing/classification drift.
5. Compare technique exchange win/loss and net HP, plus sprint follow-up conversion. Do not infer that a more common technique is better merely because it appears more often.
6. Compare actual win rate, dealt HP, and taken HP against the same held-out opponent set. Training reward is not a performance score.

## Controlled A/B protocol before any further reward tuning

- Fork the same stopped checkpoint into two independent copies. Do not share a mutable checkpoint or optimizer state between runs.
- Arm A uses the pre-change reward implementation; Arm B uses this outcome-first implementation. Both start from byte-identical model/optimizer state and use the same kit, simulator settings, tick budget, and opponent sampling distribution.
- Use matched random seeds where possible and evaluate both arms against the same fixed, held-out opponent suite at fixed intervals. Keep those evaluation opponents out of training.
- Report paired win rate, damage dealt/taken, crit candidate/attempt/conversion rates, server-confirmed sprint-knockback conversion, sprint follow-up conversion, and each reward component's signed and gross mass.
- Only after the outcome-first arm is measured should any auxiliary technique shaping be reintroduced. If it is, change one term at a time and cap its measured contribution relative to actual damage/outcome reward rather than choosing a constant in isolation.

## Verification / limits

- The Minecraft-free test suite passes when the existing `GameplayRotationCheck` is skipped. The normal suite still has four failures in that separate camera/rotation test (small 2-degree correction, overshoot-to-120-degree case, stability case, and fine-aim 0.1-degree case). Those failures are not in the reward code and were already present in the project's rotation checks; this reward update does not claim to fix them.
- `bash ./gradlew compileJava` could not run because the Gradle wrapper could not resolve `services.gradle.org` in this environment. The offline Minecraft-free Java tests compile the reward classes, `PvpSim`, and simulator support classes, but do not compile Fabric's `Trainer` against Minecraft/Fabric dependencies.
- No training run or A/B experiment was started. No checkpoint was edited. Therefore no win-rate improvement or reduction in sprint-hit preference is claimed yet.
