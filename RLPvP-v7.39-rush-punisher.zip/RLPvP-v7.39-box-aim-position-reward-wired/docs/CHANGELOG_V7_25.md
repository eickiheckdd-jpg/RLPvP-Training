# v7.25 - why the agent chose crits over sprint hits, and the fix
Evaluation of c063057c-final-state.bin (stage 8, 1.35M ticks, sim, play mode): crit 49-85 % of hits depending on the opponent, sprint hits 1-8 % (20 % only against the stationary bot);
the agent jumps once per swing cycle (jump 8 % of ticks) and swings while falling. Sprint follow-ups mostly expire (e.g. 15/39, 2/14, 0/3).

## Root cause (numbers)
A crit is +50 % damage on every hit, certain, no setup. A sprint hit is base damage + knockback, whose value only shows up if the exchange is won - paid through technique bonuses.
Those bonuses were fixed 0.2 x kitScale (>= 0.35) x netFactor: ~0.07 in diamond + prot 3 (kit of the run), while the extra damage of ONE crit is worth ~0.5 x one hit ~ 0.6 reward there,
and the old annealing (floor 0.25) cut the bonuses to ~0.02. So the technique pay was ~5-10 % of the crit advantage: sprint hits / taps / resets could not compete and faded (and the
v7.23 crit discount + 2x complement were still far below that gap).

## Fix: pay techniques in units of a hit
- TechniqueDiscovery.hitUnit() = typical hit HP / 20 * W_DAMAGE * damageScale = what a real hit is worth. All TECH_* bases are now FRACTIONS OF A HIT:
  sprint hit 0.45, follow-up 0.35, jump reset 0.40, bait 0.40, spacing 0.35, punish 0.30, dodge 0.30, combo 0.20/step, first hit 0.15, crit 0.10 (its +50 % damage is already in the reward).
  Still exchange-settled (paid only when the exchange is won, x netFactor), diminishing 1/(1+n), dominance / anti-fade / advantage / complement as before, combined multiplier capped 2.5.
- Per-episode technique cap = max(2.5, 2 hits).
- Situational valuation (not a fixed style): sprint hit / follow-up pay x(1 + 0.6 * enemy sword charge at my swing) - knockback denies a charged enemy's swing; the discounted part of a crit's extra
  damage grows with the enemy's charge (a jump leaves me exposed): rewardDamage(real, crit, enemyCharge). Enemy recharging -> crit stays the cheap safe choice.
- Also in this tree (from v7.23/7.24): no bonus annealing (floor 1.0), anti-fade payout, sprint-head entropy floor, crit-monoculture discount + sprint complement, technique bots.

## Tooling
sim/com/rlpvp/HitTypeProbe.java (evaluation only): outcome of the next 25 ticks after each of my hits by type (crit / sprint / plain) and by enemy charge. Usage:
java -cp <classes> com.rlpvp.HitTypeProbe state.bin 40 0.5
Measured on the checkpoint: sprint-hit cells had n = 4-11 against 64-234 for crits, so the policy simply never samples sprint hits enough to learn their value (exploration collapse), which the payout change addresses.

Not run: training, Trainer.java (Minecraft classes) never compiled. Run once: PvpEval (30/12 episodes), HitTypeProbe (40 episodes), StyleCheck (passed). An existing checkpoint keeps its crit habit; the change takes effect when training resumes.


## Crit satiation, sprint-reset observation, and late-stage entropy taper

- Added a single reward event for each newly confirmed hit: critical-hit reward is 2.0 while recent crit density is at most 0.35 and 0.2 above that threshold; sprint hits receive 3.5. The existing damage, exchange, and terminal rewards remain active.
- Appended `sprint_reset_ready` to the combat observation block. It requires sprinting, a hit age greater than 10 ticks (or -1), and a forward-key release since the latest hit. This is a policy-visible proxy, not a guarantee of server-side sprint knockback.
- Added a gradual late-stage entropy taper from 1.0x to 0.4x over 300,000 ticks starting in stage 8 (the checked-in curriculum has eight stages; the setting also covers future stage 9+). Applied consistently to standard and parallel Java PPO training, including the Gaussian camera head.
- Old checkpoints retain their existing input meanings; the new appended feature is initialized through the existing observation-layout migration.
