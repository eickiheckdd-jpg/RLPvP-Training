# RLPvP v7.38 — 126 observations, trainable GRU memory, PPO update

## Scope

Applied to the uploaded `rlpvp-v7.37-outcome-only-technique-telemetry.zip` source project. This is an architecture/training update to that project, not a new combat script and not a claim that the agent is already stronger. Minecraft Fabric target remains **1.21.11**. Minecraft 26.3 files remain simulator reference material only.

No training process was started as part of this code change.

## Policy observation: exactly 126 floats

The default compact observation contract is:

| Indices | Count | Meaning |
|---|---:|---|
| `0..50` | 51 | Current observation frame (existing frame schema, including sneak state) |
| `51..114` | 64 | Current hidden state from the trainable GRU |
| `115..122` | 8 | Opponent behavior/habit features |
| `123` | 1 | Normalized recent damage differential |
| `124` | 1 | Four-bit packed recent hit-type mask (lossless for the four-bit mask) |
| `125` | 1 | Measured reach margin |
| **Total** | **126** | |

`Config.OBS_SIZE` defaults to 126. The previous explicit multi-lag input can still be selected for legacy regression/diagnostic runs with `-Drlpvp.obs126=false`. Compact mode enforces GRU shape H=64 and X=18.

## Recurrent memory

- A trainable GRU has 64 hidden channels and consumes 18 normalized combat/fight-state signals per tick.
- The 18 input signals cover spacing/range, closing/lateral/vertical motion, opponent attack/sprint/facing pressure, own cooldown/hurt state, opponent hurt state, ground/crit eligibility, confirmed damage, line-of-sight, and relative reach threat.
- PPO replays contiguous sequence context and backpropagates through a 32-tick truncated-BPTT window, never crossing a recorded episode boundary.
- The recurrent state is recomputed with current GRU weights during PPO updates rather than treating stale hidden-state features as fixed inputs.
- GRU updates use a separate Adam optimizer at learning rate `3e-4`, max gradient norm `0.5`.
- New GRU2 checkpoint trailer stores recurrent weights plus Adam first/second moments and optimizer step. Existing weights-only GRU1 trailers remain readable.

## PPO update

| Setting | Value |
|---|---:|
| Rollout length | 1,024 ticks |
| Minibatch | 128 samples |
| Epochs | 4 |
| Discount gamma | 0.995 |
| GAE lambda | 0.97 |
| Policy clip | 0.15 |
| Value clip | 0.20 |
| Actor learning rate | 0.00025 |
| Critic learning rate | 0.0005 |
| Target KL | 0.02 |
| Actor/critic max gradient norm | 0.5 |

The critic uses a clipped value objective and Huber loss whose delta is smoothed from rollout-return scale. Rollout KL is used to adjust learning-rate scale, and an update can stop early if minibatch KL moves too far. Non-finite gradients/updates are guarded in the network optimizer so a bad update is skipped instead of contaminating parameters.

## Old checkpoint compatibility

The included migration test writes a representative v7.37 checkpoint with 446 input columns, a 70-float summary and the prior small recurrent shape. The loader migrates compatible current-frame columns and eight stable opponent-habit columns into the compact input. Reach and damage context are mapped where the source fields are available.

This is intentionally described as a **warm-start**, not exact conversion:

- Explicit old temporal lag columns are not copied into unrelated GRU slots.
- The old small GRU hidden state/trace is not equivalent to the new 64-dimensional memory and is not copied as though it were.
- The new 64x18 GRU starts from its seeded initialization when loading a legacy checkpoint.
- New checkpoints persist its optimizer state so a later resume can continue the GRU Adam trajectory.

## What was not changed

This update does not add fixed aim directions, scripted combos, hardcoded dodge/crit sequences, or reward bonuses for technique labels. It does not change the Minecraft target version, combat kit rules, outcome-first reward policy, or camera action semantics.

## Validation

### Passed

`sh sim/regression.sh` completed successfully after the final source changes. It included:

- Existing network simulation and outcome regression checks.
- Technique opportunity audit and outcome-only reward policy checks.
- Combat observation memory, sprint follow-up, opponent adaptation, situational stack, opponent league, Stage 9 league and parallel league persistence checks.
- Minecraft combat formula and diamond Protection III kit checks.
- New exact 126-input layout and slot-semantic tests.
- Compact mirror-symmetry test.
- GRU2 recurrent optimizer-state serialization and deterministic continuation test.
- PPO clipped value-loss and gradient checks.
- v7.37 legacy checkpoint migration and input-column transfer checks.

A compact-mode simulator smoke run advanced 4,096 ticks and saved a checkpoint.

### Not fully verified

- `tests/run.sh` exceeded a 120-second execution window before its full suite completed. This is not a full-suite pass.
- A complete Fabric/Loom build was attempted through `bash gradlew compileJava`, but Gradle 9.5.1 could not be downloaded because the environment could not resolve the Gradle distribution host. The Minecraft 1.21.11 Fabric build is therefore **not verified** here.
- No live Minecraft client/server playtest, differential rotation trace, multi-worker training run, or 3-million-tick learning evaluation was performed.
- Passing simulator tests confirms tested mechanics and code paths, not that the policy will necessarily outperform the previous model. A fresh evaluation and learning run are still needed.

## Artifacts

- Main source: `src/main/java/com/rlpvp/`
- Observation contract: `src/main/java/com/rlpvp/ObsStack.java`, `Config.java`
- GRU: `src/main/java/com/rlpvp/GruCell.java`, `OpponentMemory.java`
- PPO and checkpoint migration: `src/main/java/com/rlpvp/PpoAgent.java`, `ObsLayout.java`
- Focused test: `tests/CompactObservation126Check.java`
- Legacy checkpoint fixture: `tests/CompactCheckpointMigrationWrite.java`
