# Implementation report — RLPvP v7.17 merge

This folder is built from the v7.15 implemented source, then merged with the v7.16 capacity/widening and movement-spam implementation. The original v7.15 MotionMemory and CollapseGuard safeguards were retained rather than replaced by the simpler v7.16 versions.

## Code changes
- `Config.java`: supports existing `base/m10/m15` presets plus custom `-Drlpvp.hidden=...` and explicit `-Drlpvp.transferFrom=...`; merged movement SpamGuard settings while retaining optional `OBS_V2` and Wilson guard thresholds.
- `Net.java`: added function-preserving `widenFrom` that copies existing weights, zeroes outgoing links from new units, and resets optimizer moments.
- `PpoAgent.java`: recognizes configured source layer shapes and uses function-preserving widening for compatible same-depth checkpoints. Depth changes remain rejected intentionally.
- `SpamGuard.java`: upgraded to v7.16 rate-based movement checks with caps, hit grace and curriculum locks.
- `Trainer.java` and `sim/com/rlpvp/PvpSim.java`: feed actual movement unlock state, direction, sprint state and horizontal speed to the upgraded guard.
- `tests/`: combined the motion-memory, collapse/outcome, capacity/widening and movement-spam regressions. Added an end-to-end small-checkpoint widening run to `tests/run.sh`.

## Verification performed
- Simulator + Minecraft-free regression target compilation succeeded.
- `RlTests`, `MotionMemoryCheck` with `-Drlpvp.obsV2=true`, `OutcomeRegressionTest` (43 checks), `MoveSpamCheck`, `NetCapacityCheck`, `GuardCheck`, `CurriculumGateCheck`, `MinecraftRulesCheck`, `SpamGuardCheck`, `GlideCameraCheck`, `AimBrakeCheck`, and `GameplayRotationCheck` passed when run individually.
- `sim/run.sh 5000 ... 123` succeeded and saved a checkpoint.
- A separate 10-tick base checkpoint was loaded into a wider `[256,256]` model using `-Drlpvp.transferFrom=128,128`; the log confirmed function-preserving widening and the run saved its output checkpoint. A base checkpoint also resumed successfully with `-Drlpvp.obsV2=true`.

## Not verified
- The complete `tests/run.sh` did not finish within the available execution window; `ConsequenceModelCheck` was still running when the timeout was reached. Do not interpret the individual passing checks as proof that the entire suite passed.
- No Fabric/Gradle build result is claimed.
- No long training run or controlled A/B combat evaluation is claimed. Performance improvements are hypotheses pending evaluation.
