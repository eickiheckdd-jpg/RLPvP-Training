# v7.62 (from v7.61) - polish: real bugs and rotten tests. Mod not compiled here; sim/trainer + Minecraft-free tests only.

## Bugs fixed
- Shared `rival` opponent (ParallelPvpTrain arg 6): all workers drove ONE FrozenPolicy (scratch buffers + Random), a data race. Measured with 4 threads on one policy: its favourite action was chosen 18-67% of the time vs 58-99.9% from an isolated copy. Each worker (and the probe sim) now gets its own `FrozenPolicy.copy()`; with private copies the numbers match the isolated ones. Only affects runs that pass a rival checkpoint.
- sim/modelinfo.sh could not compile (three source files glued into one quoted argument). Now lets javac find dependencies; it runs.
- League version marker: `league.version` next to ratings.csv. A league with ratings but no marker (v7.53 or older, or a copy that lost it) or an older marker prints one warning at start (old Elos earned against weaker frozen cameras / before hard starts were unrated may be inflated). Nothing is deleted or changed; the marker is then written so the warning shows once. Seed copies carry the marker.

## Tests that were stale are corrected, not hidden
- NetCapacityCheck: expected parameter counts are computed from the layer sizes (they were typed in for an older observation/action size).
- CritSatiationCheck: the late-stage entropy checks use the configured decay (4M ticks) and floor (0.5), not 300k / 0.7.
- GameplayRotationCheck: the 4 AimBrake threshold checks print SKIP unless -Drlpvp.aimBrake=true. HONEST NOTE: with the brake on they still fail (the brake drifted after the input filter/easing were added); it is off by default since v7.59, so re-enabling it is unsupported until re-tuned.
- SymmetryCheck: its training check now runs until a real update happens; it passes in both symmetric and plain mode (evidence that plain-mode training updates weights).
- ExploiterCheck: the snapshot-pool check compared against "empty or <= 1" (could not fail); now compares size before/after.
- SymmetryTrailerCheck (v7.61) was never compiled into tests/run.sh and so did not run in the v7.61 suite (it passed when run directly); it and the new PolishV762Check are now compiled and run there.

## Cleanup
- ~50 old reports moved from the project root to docs/history/ (nothing in code or scripts referenced them).

## Results
- tests/run.sh: 0 failures (4 brake checks SKIP). sim/regression.sh: 193 PASS, 0 FAIL. ExploiterCheck ok. 60k-tick 2-worker run with a rival checkpoint: no errors (it does not prove the rival was used in that run; the race measurement above is the evidence).

## Deliberately NOT done
- The inactive hand-written tactical suite (CombatIntelligenceSuite and helpers) was NOT deleted: it is off by default (INTEL_OFF=127, PLAY_STACK=0), the mod code can reference it, and the mod cannot be compiled here, so deleting classes risks breaking your build for no behaviour gain.
- Technique-discovery reward: already scaled to 0 (TECH_REWARD_SCALE=0), nothing to turn off. HP-difference shaping and the auxiliary forecaster: left on; removing them needs a long A/B run, which I can't do here.
- Not fixed: bot difficulty is not saved in checkpoints (with the v7.57 faster schedule it climbs back in roughly 80 episodes); multi-thread learner still unported; long-run behaviour of v7.57-v7.62 changes is unmeasured.
