# v7.42 speed pass (compile-checked only, nothing was run)

1. World-model training only on worker 0 (ParallelPvpTrain). The consequence model feeds PLAY_STACK>0 planning only, never PPO, and
   only worker 0's copy was saved; workers 1..K-1 trained theirs for nothing. Saved checkpoint and PPO are unchanged.
   Extra: -Drlpvp.conseqTrain=false skips it everywhere (the checkpoint keeps its existing world model; only matters for stack>0).
2. Bug fix: the parallel learner never received the head-entropy boosts (strafe/jump/sprint/fwd floors), because only workers' actTrain
   updates them. syncHeadBoostFrom() derives them from the workers' smoothed entropies. This DOES change training (restores the intended
   floors). -Drlpvp.parallelHeadBoost=false restores the old behaviour.
3. Log line "timing: collect Xs, learner Ys (Z%)" every log interval, to show whether the single learner thread is the bottleneck.

4. v7.43 airborne penalty: any hit taken while airborne now pays the airborne penalty (it used to apply only from the 2nd hit of a chain,
   so a lone punished jump cost nothing). Default raised 0.2 -> 0.3 (-Drlpvp.pos.airbornePenalty). -Drlpvp.pos.airborneSingle=false = old chain-only rule.
   Compile-checked only; tests/CombatPositionRewardCheck has a new assertion that was not run.

5. v7.44 miss + stall penalties (both small, both flagged, compile-checked only):
   - Miss: a swing that did not connect now costs 0.05 (new reward term "missSwing", cap 1.0 per episode, stage >= CombatPositionReward.MIN_STAGE).
     -Drlpvp.pos.missPenalty=0 disables, -Drlpvp.pos.missCap=N. Before this, Config.MISS_COST was a hard-coded 0 and also fed the technique channel,
     which outcome-only mode switches off, so no miss cost ever reached the reward. The attack gate already masks swings that cannot connect, so this charges real in-cone misses.
     Caution: an old 80k A/B with a 0.12 miss cost did not lower the whiff rate and fell back a stage. 0.05 with a cap is much milder, but unproven.
   - Stall: after IDLE_FREE_TICKS (60) with no real hit landed, the dense-reward fade (idleScale) is mirrored by a per-tick cost up to 0.002 (-Drlpvp.stallPenalty=N, 0 disables).
     Stage 6+ only, because idleScale is 1 below it. "Idle" means I have not landed a hit, so it also charges being beaten without hitting back.
   - Correction to my audit: the HP-lead bonus is faded by the same idle fade, so it can only pay for stalling for the first ~180 ticks.

6. v7.45 parallel-learner KL fix (compile-checked only):
   With K workers, every rollout after the first of a round is stale: the learner already moved on the earlier workers' data, so its KL against the
   acting policy starts above 0 before any learning on it. The KL early stop (1.5 x TARGET_KL) then cut those rollouts short after a few minibatches
   and the adaptive learning rate read the staleness as "updates too big" and shrank lrScale. PpoAgent.staleKlBaseline (set by ParallelPvpTrain)
   measures KL above each rollout's own first-minibatch KL instead. Single-environment training is unchanged (its baseline is ~0).
   -Drlpvp.staleKlBaseline=false restores the old behaviour.
   Consequence: stale rollouts now train fully, so learner time per round goes UP and ticks/second can go DOWN. That is the honest number if those
   rollouts were being thrown away. The log's timing line now prints "rollouts trained / cut short / lrScale": if "cut short" is already ~0, this
   change does nothing.
7. Removed the dead ConsequenceModel.TRAIN_EVERY / -Drlpvp.conseqEvery property (observe() uses Config.CONSEQUENCE_TRAIN_EVERY).
