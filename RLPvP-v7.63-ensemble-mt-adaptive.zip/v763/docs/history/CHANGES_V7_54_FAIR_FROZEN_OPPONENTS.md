# v7.54 fair frozen opponents (opt-in `-Dsim.fairFrozen=true`) + exploiter fixes

## The problem (found in a real v7.53 run: ratings.csv, 5,134 league games)
The main agent won EVERY game against every frozen opponent except one scripted style: 111/111 vs each of the 4 exploiters, ~100% vs every snapshot (even ones only
25k ticks old), main Elo 9386. All 76 losses of the whole ledger were against script:15. A frozen copy of the agent should score ~50%.
Direct test (tests nothing but the simulator): your checkpoint (stage 9, 7.55M ticks) vs a frozen copy of ITSELF, 40 episodes, play mode:
  old simulator:   40 wins, 0 losses, dealt 20.0 / taken 3.1 per episode
  fairFrozen=true: 33 wins, 7 losses, dealt 19.6 / taken 17.1 per episode
Cause: the agent's camera goes through the full pipeline (look smoothing, input filter, easing, AimBrake, legal step: GameplayRotation.stepEffort) but a frozen
self-play opponent used raw CameraDynamics only. A policy trained with the brake overshoots without it, so every frozen opponent aimed far worse than the agent.
Consequences: self-play / league snapshots were much weaker than they look, the Elo is inflated, and exploiter admission (beat the frozen main agent) was passed
automatically, which is why 3 of 3 were admitted and why they then lost 111/111 as league opponents.

## The fix
`-Dsim.fairFrozen=true`: the frozen opponent's camera uses its own GameplayRotation (same smoothing, filter, easing, brake, legal step, same errors the policy sees).
Default false = the old behaviour exactly. It makes every frozen opponent (snapshots, rival, exploiters) much stronger, so training results WILL change: expect lower win rates
and a deflating Elo at first. That is the point, but it is why it is not on by default.
After enabling it on an existing run, the old ratings.csv Elos are meaningless (they were earned against weak opponents). Start a fresh league dir (or accept a slow re-rating).

## Exploiter changes
- admission defaults raised: admitWin 0.65, minEpisodes 40 (a copy of the main agent scores ~50% by luck; at 24 episodes 55% was passed ~30% of the time by chance).
- the periodic `exploiters:` line now prints the main agent's W/L/D against every kept exploiter, and warns if fairFrozen is off.
- OpponentLeague.matchupLine(id).

## Verification
RUN: the symmetry probe above (both settings), ExploiterCheck (all ok, with and without fairFrozen), a short parallel burst showing the new log line.
Raw speed with fairFrozen in the burst: 820-866 ticks/s vs ~890 before (2 cores, noisy).
NOT RUN: a long training run with fairFrozen; the exploiters it will produce; the remaining gap (33-7 instead of ~50%) is probably play-mode (temperature 0.8) vs frozen
sampling and the opponent's delayed view, not investigated. The in-game Trainer is untouched.
