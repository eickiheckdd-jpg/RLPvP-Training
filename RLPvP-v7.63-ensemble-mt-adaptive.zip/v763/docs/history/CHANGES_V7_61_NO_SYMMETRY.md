# v7.61 (from your v7.60) - no forced left/right symmetry for new agents. Mod not compiled here; sim/trainer + Minecraft-free tests only.

## Changed
- `Config.SYMMETRIC_POLICY` default true -> false, and it now only decides NEW agents (`-Drlpvp.symmetric=true` brings the old behaviour back for fresh training).
- Each agent carries `symmetric`. Every checkpoint records it in a new optional trailer (SYM1, 1 byte, last). A checkpoint WITHOUT the trailer (v7.60 and older) was trained symmetrised and loads as symmetric, so your existing checkpoints keep playing exactly as before; resuming one keeps training it symmetric.
- FrozenPolicy (league snapshots, exploiters, rival) plays the way its source agent was trained; `adoptFrom` copies the mode (parallel workers, probe agents).
- Kept: mirrored-world training episodes (`-Dsim.mirror`, free; with no symmetric policy they are the only left/right balancing, so they matter more now), the Symmetry class and its tests (SymmetryCheck now sets the mode explicitly).

## Measured (short runs, NOT a long-run result)
- 60k ticks, 2 workers, 2 cores, stage 1: learner 31 s with symmetry vs 28 s without (about 11%), total 82 s vs 81 s.

## Verified
- New SymmetryTrailerCheck: new agent default off; plain and symmetric checkpoints reload in their own mode; trailer-less file loads symmetric; same weights give different logits in the two modes; adoptFrom copies the mode. All ok.
- Real runs: fresh 60k-tick run saves symmetric=false; resuming a v7.59 symmetric checkpoint (210k ticks) stays symmetric=true. No exceptions.
- tests/run.sh: same pre-existing failures as v7.60 (4 aim/camera lines, 3 NetCapacity param counts, 1 entropy assert). sim/regression.sh: 193 PASS, 0 FAIL.
- SymmetryCheck's last check ("training runs through both passes", 5 episodes + learnTick) fails on your untouched v7.60 too (stale premise, no update happens in that tiny run); it is not part of any suite script. Training itself is covered by the real runs above.

## Caveats
- A checkpoint trained WITHOUT symmetry played in v7.60 or older will be played symmetrised (they do not read SYM1) and will act wrongly. Use v7.61 for the mod when playing such checkpoints.
- Unmeasured: whether the agent plays better/worse or strafes more cleanly without symmetry. That needs a long run; compare strafe flip rate and win rate at stage 6+. No side-bias test exists for the non-symmetric policy yet.
