# v7.48 hybrid bots

Three new scripted opponent styles (`BotAI`, shared by the mod and the simulator). They are fair like every other style: same aim model, turn cap, reach, cooldown and charge gate.

| id | name | what it combines |
|---|---|---|
| 13 | `crit-reset-rush` | crit spammer + jump resetter + aggressive: lives inside reach, starts a jump-crit from melee whenever charged (`critSpam`), jumps and sprints in the moment it is hit (`reset` 0.85-1.0) |
| 14 | `wtap-combo-spacer` | w-tap + good distancing + comboing: 2.4 ring, far-edge pokes, hit selection, pure one-tick w-tap sprint-hit chains, 11-tick combo chase, commits after 20 quiet ticks |
| 15 | `crit-punisher-plus` | stronger rush-punisher: `airPunish` 1.0 (strikes first every time the agent is airborne inside reach), `intercept` (steps in toward an airborne agent so a jump from outside reach is still met), no attention lapses, lag 1, no click delay, full fire, 14-tick landing rush |

Flag: `-Drlpvp.hybridShare` (default 0.09 in v7.48, raised to 0.30 in v7.50 - see CHANGES_V7_50; = 9% of random-mix episodes, split evenly; `mixWeights` stays in sync). `0` restores the previous mix exactly (no extra random draw).
The league (`script:<id>`), `ChampionEvaluator`, `StyleReport` and per-style telemetry loop over `BotAI.STYLES`, so the three hybrids appear there automatically (the champion evaluation now includes them, so its scores are not comparable with older runs). `StandingEval` keeps its fixed 13-style list on purpose, for comparability.

Measured (BotBench punishers 60, idealized agent, 1.8 s): vs the crit-spam habit all three beat or match the best old punishers (crit-reset-rush and crit-punisher-plus: agent loses 100%; wtap-combo-spacer: agent loses 72%, wins 10%).
Versus the orbit / trader habits wtap-combo-spacer went from losing 50-62% to losing 85-97% after tuning.
crit-reset-rush kills about 12-15% faster than the rusher / rush-punisher (fight length 231-257 vs 263-303 ticks); crit-punisher-plus is level with rush-punisher on this bench (both are at its ceiling).

Test change: `tests/BotAICheck.java` reach invariant. The original all-or-nothing limit (+0.9) only passed because of the random draw: the ORIGINAL baiter and rush-punisher also swing from 4.15 / 4.40 on other draws. It is now "never beyond +1.4 and beyond +0.9 for < 1.5% of swings" (1 of 224 in this run; 0 of 225 with hybridShare=0).

Not verified: how the new bots play in the full game against your agent, and whether 9% is the right share. Run the same HT4 / tier-3 comparisons as before, and watch the per-style tally ("by style:" line).
