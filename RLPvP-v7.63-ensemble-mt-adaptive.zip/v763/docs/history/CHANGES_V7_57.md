# v7.57 (built from v7.56; the Minecraft mod itself was NOT compiled here, only the Java sim/trainer and the Minecraft-free tests)

## Your list
| Item | What it does now | Switch |
|---|---|---|
| Hard starts | 12% of training episodes (stage >= 6, never evaluation, never an exploiter phase) start in a bad spot: airborne with the opponent in reach, mid-combo (just hit, knockback in flight, opponent on top, 2-8 hp lost), or low health (4-10 hp vs 12-20). Only the start state differs. Probe: 12.3% at stage 7, 0% at stage 5, evenly split. | `-Dsim.hardStart.share=0.12` (0 = off), `-Dsim.hardStart.minStage=6` |
| Drop styles it beats ~always | A league opponent with >= 40 games vs the main agent and >= 98% agent wins is left out of the draw, except 5% of draws that use the whole list (so a regression reappears). Never drops if fewer than 3 opponents would remain. | `-Drlpvp.masteredWin=0.98` (2 = off), `-Drlpvp.masteredMinGames=40`, `-Drlpvp.masteredKeep=0.05` |
| fairFrozen | Already the default since v7.54/7.56 (verified). | `-Dsim.fairFrozen=false` = old |
| Exploiters | Already default (share 0.10, admission 65% over >= 40 episodes) since v7.56 (verified). | `-Dsim.exploiter.share=0` = off |
| Hybrids | The code default has been 0.30 since v7.50 (the v7.48 doc's 0.09 is stale). 13-15 are 30% of every random mix. | `-Drlpvp.hybridShare=N` |
| Faster difficulty | Window 12 -> 8 episodes, step 0.05 -> 0.08, start 0.00 -> 0.20. Not saved in the checkpoint (as before). | `-Drlpvp.botDiff.start/.window/.step/.raise/.lower` (12 / 0.05 / 0 / 0.65 = old) |
| Stable strafing | New "wasted strafing" cost: charged only when the A/D keys flip often (flip rate > 0.20) AND the body is not moving sideways relative to the opponent (< 0.04 blocks/tick, 20-tick average). Real orbiting/dodging moves sideways, so it is never charged. Max 0.01/tick, inside the existing per-tick/episode move caps, waived right after a hit. Telemetry: `wastedStrafe` in the move line. | `-Drlpvp.strafeWaste=0` = off |

## Batch A items done
- Troublemaker sampling (styles that beat the agent keep >= 15% of draws; ledger test: script:15 14.4% vs 0.0%). `-Drlpvp.troubleShare=0` = off.
- Brake strength is saved in the checkpoint (new optional BRK1 trailer; old builds ignore it). THE BUG you heard about: the brake fade kept its strength in a side file named after the output .bin and only wrote it at log windows, and the checkpoint did not hold it, so a copied/renamed/mid-window checkpoint lost it and the MOD played a faded agent at strength 1.0 (a brake level it was not trained for). Now trainer and loaders restore it from the checkpoint.
- Pooled world model: every worker trains its own replica; replicas are averaged into the master model each round (weights + Adam moments averaged, counters summed with no double counting). Before, only worker 0's model (1/K of the data) was kept and every resume overwrote the checkpoint's model with a fresh one. `-Dsim.poolWorld=false` = old.
- Latency randomization already existed (NetworkSimulation.sample, stage-scaled from stage 6) - not changed.

## NOT done yet (next)
- Randomized reach/knockback per episode, held-out never-trained bot styles, and the Batch B ensemble planner (play-time reranking, new world-model format).

## Tests
New: ConsequencePoolCheck, V757BatchCheck, TroubleSamplingCheck, BrakeTrailerCheck (all pass, in tests/run.sh). Full suite: same 8 failures as the untouched v7.56 (AimBrake/GameplayRotationCheck numbers x4, NetCapacityCheck x3, one entropy assert) - not caused by this version.
Ran: 150k-tick 2-worker parallel training smoke (pooling active, no crash), 40k-tick single-sim at forced stage 7. NOT run: a long real training run, the mod build, Trainer.java (rename + one lateral-speed line, uncompiled).
