# v7.56 exploiters, fair frozen opponents and brake fade are now ON by default (parallel trainer)

| feature | default now | turn off with |
|---|---|---|
| learner exploiters (v7.53) | share 0.10, from stage 7 | -Dsim.exploiter.share=0 |
| fair frozen opponents (v7.54) | on | -Dsim.fairFrozen=false |
| brake fade (v7.55) | 3,000,000 ticks to floor 0.5, from stage 7 | -Dsim.brakeFade.ticks=0 |
The brake fade now also waits for -Dsim.brakeFade.minStage (default 7): before that the strength stays 1.00 and the baseline is not measured, so a young agent keeps its full brake while it learns to aim.
Everything else is exactly v7.55 (see CHANGES_V7_53 / 54 / 55 for details, thresholds and limits).

## Things that change because they are on
- Training results will not match earlier runs: frozen opponents are stronger, about 10% of rounds train exploiters (the main tick counter runs ~10% slower than the raw simulator rate, see the `exploiters:` log line), and from stage 7 the brake slowly weakens.
- Any league folder from before v7.54 has Elos earned against weak opponents. Start a fresh `<out>.league` (or expect a slow re-rating).
- AN AGENT TRAINED WITH THE FADE NEEDS THE MATCHING STRENGTH TO PLAY: the log prints it (`-Drlpvp.brakeStrength=0.xx`). The checkpoint does not store it. Standalone eval scripts (sim/eval.sh etc.) also run at strength 1 unless you pass the same flag.
- If aim quality drops, the fade holds / retreats by itself; you can also stop it with -Dsim.brakeFade.ticks=0 (the strength then returns to 1 on the next start).
RUN: compile, ExploiterCheck, a stage-1 burst with defaults (the fade waits for stage 7, no exploiter phase), a burst with the stage gates lowered (fade runs, log lines print).
NOT RUN: a real stage 7+ run with all three on together.
