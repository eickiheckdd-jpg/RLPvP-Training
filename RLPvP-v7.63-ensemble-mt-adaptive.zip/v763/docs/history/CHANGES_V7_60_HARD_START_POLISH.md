# v7.60 (from v7.59) - hard-start polish. Mod not compiled here; sim/trainer + Minecraft-free tests only.

## Findings
Hard starts (v7.57: 12% of stage >= 6 training episodes begin airborne / mid-combo / low health) trained the policy fine, but their results were counted in
everything else too. Those episodes are unwinnable on purpose some of the time, so they biased:
- league ratings, PFSP weights and the v7.57 "mastered opponent" drop (an opponent the agent beats ~always can never reach 98% while ~12% of the games are hard starts),
- curriculum promotion (win-rate gates), bot difficulty ramp, the collapse guard's best-weights tracking,
- the headline window win/loss/draw and the by-style tally.
Also: the health-difference shaping (v7.49) assumed every episode starts level. A low-health start paid a one-off phantom penalty on tick 0 (about -1.9 pre-scale)
and, worse, an action-dependent gamma*Phi(next) term on the first step (valid potential-based shaping needs Phi(s0)).

## Changed
- Hard-start episodes still train the policy (rewards, GAE, agent.endEpisode unchanged) but are excluded from: league results / style results, curriculum
  `reportEpisode`, bot difficulty, collapse guard, window counters (wEp/wWin/...), by-style tally.
- Own tally per kind (airborne / mid-combo / low-hp): episodes, W%, L%, damage dealt / taken per episode, in the training log
  (`hard starts: ...`, also in the parallel trainer, summed over workers).
- `HealthDifferenceReward.reset(startLead)`: the potential starts from the real first state (hard starts). Over a terminal episode the shaping now sums to
  the constant -w*Phi(start) from ANY start. `reset()` (level start) is unchanged, so the in-game trainer is unaffected.

## Tests
- New `HardStartPolishCheck` (in sim/regression.sh): shaping from off-level starts, no phantom tick-0 penalty, window/league gating, tally line.
- `sim/regression.sh`: 190 PASS. `tests/run.sh`: identical result to v7.59 (167 PASS, the same 4 aim/camera FAIL lines).
- Smoke: 26k-tick stage-6 run with `-Dsim.hardStart.share=0.5`: no errors; 28 normal episodes in the window vs 25 hard starts tallied separately.

## Not done / unmeasured
- No long run: whether hard starts improve the agent (or what share is best) is unmeasured. The per-kind tally is what you need to see it:
  a kind where W% stays ~0 for a long time is too hard, ~100% is too easy.
- Not changed: the spawn geometry itself (positions are not clamped to any arena edge), the share (0.12) and the stage gate (6).
- The multi-threaded learner (data-parallel PPO minibatches) is NOT in this tree.
