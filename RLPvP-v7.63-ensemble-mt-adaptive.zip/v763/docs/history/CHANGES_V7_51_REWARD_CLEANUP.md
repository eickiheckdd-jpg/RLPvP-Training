# v7.51 reward cleanup (items 1-5 plus lookAway removed, defaults set to 0)

Removed because they do not depend on winning the fight and bias behaviour (all still overridable to restore the old value):

| term | old | now | restore with |
|---|---|---|---|
| sweepHit (plain full-charge grounded hit) | -0.15 | 0 | `-Drlpvp.pos.sweepPenalty=0.15` |
| weakHit (hit before recharge) | -0.30 | 0 | `-Drlpvp.pos.weakPenalty=0.30` |
| band (2.5-3.0 blocks, per tick, never faded) | +0.005 | 0 | `-Drlpvp.pos.band=0.005` |
| lookAway (per tick while >30 deg off-target inside 3 blocks, capped) | -0.03 | 0 | `-Drlpvp.pos.lookPenalty=0.03` |
| hp_advantage (per-tick bonus for any lead) | 0.004 | 0 | `-Drlpvp.hpAdvantage=0.004` |
| closeness | 0.0025 | 0 | `-Drlpvp.closeness=0.0025` |
| progress | 0.02 | 0 | `-Drlpvp.progress=0.02` |

Why: sweepHit taxed only the plain hit, leaving crit/sprint hits free (a hidden crit reward); weakHit double-counted the lower damage of an early
swing; band paid for hovering and duplicated the fading spacing reward; hp_advantage paid for stalling on a lead and v7.49's potential-based
health-difference term already covers it; closeness/progress paid for closing distance regardless of safety (chasing into charged swords).
lookAway was removed too: it duplicated the fading facing reward as a permanent penalty (and can fire right after knockback, when the agent cannot control its view).
Kept: damage dealt/taken, win/loss, health-difference, airborneHit, consecutiveHits, comboBreak, time/stall, aim/camera terms, spacing.

Files: Config.java (3 constants), CombatPositionReward.java (3 defaults). Reward.java is unchanged.
Verification: sim/regression.sh output identical to the untouched v7.50 tree (no failures in either).
Not verified: the effect on learning (needs an A/B training run with the same seeds; compare HP dealt minus HP taken per style in StyleReport).
