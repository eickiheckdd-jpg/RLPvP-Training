# v7.49 health-difference reward (on top of v7.48 hybrid bots)

New `HealthDifferenceReward` (training only, simulator and in-game `Trainer`):
- potential Phi(lead) = tanh(2.5 * lead), lead = (my HP - enemy HP) / 20
- per tick: F = w * (gamma * Phi(lead_now) - Phi(lead_prev))
- true death (any terminal): the remaining potential is removed (-w * gamma * Phi), so over a terminal episode the shaping sums to exactly 0
  (discounted). Time-limit truncation is not cancelled (the critic bootstraps through it).
- w = `Config.HP_DIFF_REWARD` (default 2.0, `-Drlpvp.hpDiff=N`, 0 = off) x `RewardTuning` key `hp_difference`.

Why potential-based and not "reward = current lead": a per-tick reward on the current lead pays for sitting on an advantage (stalling) and punishes
being behind every tick (fleeing / hiding). This form cannot change the optimal policy; it re-weights the damage signal by the state of the fight:
a 7 HP hit from level adds about +1.4 (w=2) on top of its damage reward, a hit when already far ahead adds about 0.15, a comeback hit when behind about 0.7.

Related, unchanged: the older one-sided `hp_advantage` dense term (bonus for any positive lead, faded by idle/dense scale) still exists. Both can be active.
Telemetry: the shaping is counted in the "other" reward bucket (not a separate column).
Caveat: W_DAMAGE's comment records that a stronger damage penalty made the agent flee at stage 5. This term also raises the weight of damage TAKEN near
an even fight (same +33-40% as damage dealt). If flee/hide behaviour shows up, lower `-Drlpvp.hpDiff` (1.0) or set it to 0.
Verification: tests/HealthDifferenceRewardCheck (telescoping, symmetry, weighting), full regression passes (175 checks), 26k-tick stage-5 run finite.
Not verified: the effect on learning (needs an A/B run), `Trainer.java` edits (parse-level only, not compiled against Minecraft).
