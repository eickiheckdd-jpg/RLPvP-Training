# v7.58 (from v7.57) - reward cleanup. Mod not compiled here; sim/trainer + Minecraft-free tests only.

Removed (outcome-first: hits and wins decide the style):
- facing + pitch rewards (0.01/tick each), spacing reward (0.004/tick), orbit reward (0.012/tick): paid ONLY in stages 1-4 (they bootstrap aiming/moving; with them off from stage 1 a fresh agent gets no signal at all - verified), OFF from stage 5. `-Drlpvp.denseOffStage=N` (99 = old schedule).
  While facing was paid at all times the agent could not look away on purpose (baiting).
- combo-break reward (0.6 + 0.4), consecutive-hit penalty (0.25/step), airborne-hit penalty (0.3): 0. Restore: -Drlpvp.pos.breakReward=0.6 -Drlpvp.pos.breakKbBonus=0.4 -Drlpvp.pos.consecPenalty=0.25 -Drlpvp.pos.airbornePenalty=0.3
Kept: win/loss, damage, time + stall penalties, anti-spam costs (incl. wasted-strafe), camera reward.
Not changed: camera reward (progress/jerk/overshoot/hold) - fade it with the brake in a later step.
Tests: new V758RewardCheck; full suite = same 8 pre-existing failures as v7.56/v7.57. Fresh 80k-tick smoke: stage-1 return +2.3 (bootstrap intact). NOT run: a long run - whether win rate holds after stage 5 is unmeasured.
