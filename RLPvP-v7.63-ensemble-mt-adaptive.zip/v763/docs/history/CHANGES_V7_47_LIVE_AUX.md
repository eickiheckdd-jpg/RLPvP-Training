# v7.47 live-aux note

Finding: the auxiliary forecast heads already train live. In-game `Trainer.tick()` calls `agent.learnTickBudgeted(...)` every tick in TRAIN
mode, and that shared learner runs `aux.accumulate`, `aux.blendIntoGruGrad` and `aux.step`; labels are built in `finishRollout` from the
agent's own observations (frame indices 0/12/15/17/19/22/23 match `Observation.frame`).

What was missing was visibility: nothing in the mod printed whether the heads were learning. Added:
- `/rl status` now prints `forecast heads: aux n=... skill: swing ... outcome ...` (`Trainer.status()`).
- The per-window training log line (`say(lastStats)`) now ends with the same aux skill report.

Not changed: training behaviour, checkpoint format, flags (`-Drlpvp.aux=false` still switches the feature off).
Cost note: the heads add per-sample compute to the live learner; if the client learner is cut short more often, lower `-Drlpvp.auxHidden1/2` or use `-Drlpvp.aux=false`.
Verification: Trainer.java parse-checked only (errors are Minecraft/Fabric symbols only, none involving aux). Not run in Minecraft.
