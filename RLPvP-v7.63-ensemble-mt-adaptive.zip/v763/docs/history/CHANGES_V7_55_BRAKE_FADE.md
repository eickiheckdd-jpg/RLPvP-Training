# v7.55 brake fade (opt-in; default behaviour unchanged)

Goal: let the agent learn to brake its own camera instead of relying on the AimBrake helper (GameplayRotation / AimBrake), by fading the helper out during training.

## How
`Config.AIM_BRAKE_STRENGTH` / `GameplayRotation.brakeStrength` (1 = full brake, the default): the brake output is blended with the policy's own command,
`cmd + strength * (braked - cmd)`. At 1.0 the code path is the old one.
The simulator trainer fades it: `ParallelPvpTrain.BrakeFade`.
    JAVA_OPTS="-Dsim.brakeFade.ticks=3000000" sim/train_parallel.sh ...
| flag | default | meaning |
|---|---|---|
| sim.brakeFade.ticks | 0 (off) | main-agent ticks for the whole fade, from strength 1 to the floor |
| sim.brakeFade.floor | 0.5 | lowest strength (0 = no brake at all). Start conservative |
| sim.brakeFade.guard | 1.25 | the safety rule (below) |
Progress is counted in main-agent ticks (exploiter phases do not move it) and saved in `<out>.brake.properties`, so a resume continues where it stopped.
Safety rule: the first two log windows run at full strength to measure the baseline swing-miss rate. After that, if a window's miss rate exceeds guard x baseline (+2 points) the
fade HOLDS; if it exceeds guard x 1.3 it RETREATS 2% of the fade. The log prints a `brake fade:` line every window.

## Playing an agent trained at a lower strength
The mod does not know the training strength (it is not in the checkpoint). Start the game with the strength the trainer printed: `-Drlpvp.brakeStrength=0.7`.
A stronger brake than the agent was trained with is safe; a weaker one makes it overshoot. The in-game files were not compiled (they need the Minecraft toolchain); the only shared
code that changed is GameplayRotation (which ActionApplier already calls) and Config.

## What the probes say (read before using)
Regression: a 4000-tick camera trajectory through GameplayRotation gives the SAME hash in v7.54 and in v7.55 at strength 1 (-6418498149241291803).
A naive proportional aiming policy (not your agent) overshoots a 20-80 degree target by: strength 1.00: 11 deg, 0.95: 17, 0.90: 34, 0.80: 54, 0.70: 67, 0.50: 96, 0.00: 188.
So the cliff starts immediately: even a 5% weaker brake hurts a policy that depends on it. A trained policy can adapt (that is the whole idea) but only gradually; that is why the
fade is slow, why the floor defaults to 0.5, and why there is a guard. Whether your agent can reach 0.5 or lower with aim intact is UNKNOWN until it is run.

## Verification
RUN: compile; the regression hash; the overshoot probe; a 70k-tick burst showing baseline windows, the fade to the floor, the state file, and a resume that continued from the saved progress.
NOT RUN: the hold / retreat branches (the burst had no swings, miss rate 0); any long run; the exploiter interplay (frozen opponents use the CURRENT strength, not the strength they were
trained at; with fairFrozen their aim is only as good as their brake); the effect on win rate. Parallel trainer only.
