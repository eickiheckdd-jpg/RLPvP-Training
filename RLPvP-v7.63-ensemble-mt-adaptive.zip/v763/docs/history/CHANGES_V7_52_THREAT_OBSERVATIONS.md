# v7.52 threat / timing observations (5 new network inputs, 128 -> 133)

Descriptive inputs only: no reward and no action logic changed. All five are appended at the END of the compact input (slots 128..132), so no
existing input moved. Class: `ThreatObservation` (pure Java, shared by Trainer, PvpSim, BotBrain).

| slot | input | definition |
|---|---|---|
| 128 | enemy crit-ready | 1 while the enemy is airborne, falling (vy < 0) and not sprinting (same rule as the agent's own frame[43]) |
| 129 | ticks since my jump | ticks since MY jump left the ground / 20; 1.0 = none in the last 20. Only a self-initiated takeoff counts (jump commanded on the ground, airborne now), not knockback or walking off an edge |
| 130 | ticks since enemy sprint reset | ticks since the enemy's sprint dropped and restarted within 4 ticks (a w-tap) / 40; 1.0 = none lately. A longer stop is not a reset |
| 131 | signed enemy reach margin | ATTACK_REACH - distance(enemy eye, MY hitbox), /1.5 clamped to [-1, 1]; positive = I am inside its reach. Sign always agrees with the old frame[45] flag |
| 132 | measured ping | RTT ms / 200 clamped to [0, 1]. Sim: the episode's simulated RTT. Live client: the tab-list latency (reflective lookup, 0 if unavailable). Self-play bot: 0 |

## Checkpoints
128-input (v7.38-v7.51) and 126-input checkpoints load in place: every old column keeps its position, the new columns start at zero weights.
Verified: a checkpoint trained on the untouched v7.51 gives identical actor logits (6 decimals) in the 133-input build whatever the new slots contain.
As with the earlier 126 -> 128 widening, the consequence (world) model and the aux-forecaster heads are re-initialised on the first load (their input layout changed).
Mirror symmetry is unchanged: none of the five inputs has a left/right sign.

## Files
New: ThreatObservation.java, tests/ThreatObservationCheck.java. Changed: Config (COMPACT_OBS_SIZE 133), ObsStack (slots + push overloads),
PpoAgent (migration from 128/126), PvpSim, Trainer, BotBrain (feed the tracker), tests (128 -> 133, migration test covers both sources), tests/run.sh and sim/*.sh (source lists).

## Verification
tests/run.sh vs the untouched v7.51 tree: identical results except the new ThreatObservationCheck (33 assertions, passes).
Pre-existing failures, unchanged: GameplayRotationCheck (4), NetCapacityCheck (3), CritSatiationCheck.
Live simulator (stage-1 checkpoint, all 16 scripted styles): every slot varies; signed margin sign matched frame[45] on every tick; ping 20-146 ms in training.
NOT verified: Trainer.java / BotBrain.java (need the Minecraft toolchain; the edits mirror the existing KbTiming / CombatObservationMemory calls),
the reflective ping lookup on a live server, and any effect on learning strength (needs an A/B training run).
