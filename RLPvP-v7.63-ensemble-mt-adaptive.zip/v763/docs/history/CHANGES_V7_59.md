# v7.59 (from v7.58) - AimBrake removed. Mod not compiled here; sim/trainer + Minecraft-free tests only.

- `Config.AIM_BRAKE` default true -> false. One switch drives the mod (ActionApplier) and the simulator (agent and frozen opponents), so train and play agree. `-Drlpvp.aimBrake=true` restores the brake.
- The agent now brakes with its own mouse effort. It sees its aim error, how that error changed, and its own applied turn (MotionMemory), and the virtual mouse still has drag and bounded acceleration/jerk.
- The brake-fade (v7.55) switches itself off when there is no brake; the BRK1 checkpoint strength is not applied when the brake is off (it is still written, so old builds are unaffected).
- Kept: AimInputFilter, glide camera, camera reward, AimJitterSuppressor (the jitter suppressor is the remaining mild aim help; say if it should go too).
- IMPORTANT: a checkpoint trained WITH the brake (v7.56-v7.58 default) will aim worse without it until retrained; train fresh or continue training for a while. A v7.59 agent played in an older build gets the brake back and is only safer.
- Tests: full suite = same 8 pre-existing failures as v7.56; BrakeTrailerCheck now runs with -Drlpvp.aimBrake=true (run.sh). 150k-tick fresh 2-worker smoke without the brake: no errors, reached stage 2 (return +3). NOT run: a long run, so whether the agent learns good braking and how much slower aim learning is are unmeasured.
