# v7.46 changes (from v7.45 parallel-kl-fix)

## Speed (about 1.9x on a 1-core sandbox, 25k-tick stage-1 run: 77s -> 40s at full 32-tick backprop)
- Net.tanhF replaces Math.tanh (software fdlibm) in Net.forward and GruCell.core.
- GruCell.backWindow restructured (bit-identical gradients at full window).
- Config.GRU_BPTT_BACK (default 32, -Drlpvp.gruBpttBack=32 restores full BPTT): backward truncated, forward replay unchanged.
  This changes training slightly; quality impact not measured.

## Bugs
- OpponentLeague: new-opponent floor swallowed the 1.35x aggressive-specialist bonus; floor now scaled by the target band;
  "new" now requires no real matchup record (isUnproven). Fixed three failing Stage9LeagueCheck assertions
  (aggressive exposure, PFSP upweighting, bounded corrective share).

## Tactical engine
- TacticalDecisionEngine learns intent and per-head action values from health-swing outcomes; old rules are only a fading prior.
- Advice is probabilistic (cap 60%), diagnostics report advice agreement and ignored attack openings.
- Only active when the play stack is enabled. Learned weights are not saved in checkpoints.

## Rush punisher (BotAI)
- Spacing 2.0, always commits, higher sprint-hit/combo/s-tap, air-punish chance grows with the agent's measured jump rate,
  landing rush after the agent lands, mix share 5% -> 9%. Strength not benchmarked against v7.45.

## HUD
- Two automatic modes (EVAL / TRAIN), compact top-left box: mini map (AI centre, arrow to enemy), opponent/self health bars with
  numbers, keystroke strip. /rl hud now: on|off|flip|opacity|reset|status. Compiled against stubs only, not in Minecraft.

## Auxiliary prediction heads (AuxForecaster) -- added after the first v7.46 delivery
- 24 prediction units (36 logits) on a shared multi-task network that sees the policy's own 128-value input incl. the GRU state:
  opponent forecast at +1/+4/+10 ticks (swing, sprint, airborne, strafe L/none/R, closing/holding/backing off), damage-taken and
  damage-dealt hazards within 5/10/20 ticks, and 20-tick dealt / taken / swing regression.
- Labels come from the agent's OWN future observations inside the rollout (no simulator internals), so the same heads can train from live play.
  Right-censoring: a window cut off by an episode/rollout end only yields a label if the event was already seen.
- Uncertainty-weighted multi-task loss (learned log-variance per task); gradient into the GRU is scaled to a fraction of the RL gradient's
  running norm (-Drlpvp.auxGruRatio, default 0.5), conflict-projected (PCGrad, -Drlpvp.auxProject), and warmed up (-Drlpvp.auxWarmup updates).
- Per-task skill score vs the best constant predictor is printed in the training log ("aux n=... skill: ..."). Forecasts are used by the tactical
  stack (threat estimate and two engine features) only once the heads are trusted (>=20k samples, hazard skill >= 0.03).
- Checkpoint: optional length-prefixed AUX1 trailer; older checkpoints load and the heads start fresh. -Drlpvp.aux=false disables everything.
- Measured on this sandbox (stage 5, 50k ticks): +12% training time; skills after 25k ticks: swing +0.56, sprint +0.96, air +0.96, lateral +0.20,
  radial +0.06, taken +0.24, dealt +0.93, outcome +0.22.
- Not done: left/right mirror-equivariance of the heads, aux labels from live in-game play (the pipeline supports it; no trainer hook added).

## Tools added
- sim/stylereport.sh <state.bin> [eps] : per opponent style win/loss, damage, crit% / sprint-hit%, whiff, jump/sprint use.
- Training log line now ends with "by style: ..." (episodes, wins, crit%, sprint%, damage taken per style in the window).
- BotBench: "crit-spam" habit, "punishers" mode, and a harness fix (bots could never damage the agent in the old bench). The bench is
  saturated for the rush punisher (agent loses 100% against old and new), so it cannot show the v7.46 punisher change as stronger.
- Tactical engine weights are saved in the checkpoint (length-prefixed TAC1 block inside the situational trailer).
