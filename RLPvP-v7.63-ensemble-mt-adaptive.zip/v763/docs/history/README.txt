Older version notes and reports, moved out of the project root in v7.62 (nothing in the code or scripts refers to them).
The current version's notes are CHANGES_V7_*.md in the project root; docs/ has the topic documents.
