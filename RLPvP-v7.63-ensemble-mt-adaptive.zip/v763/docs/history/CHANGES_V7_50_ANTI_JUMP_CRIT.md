# v7.50 jump-crit spam fix (no new reward terms)

Problem: the agent spam-jumps and jump-crits, gets hit while airborne, rarely combos, and trades crits while losing the HP difference.
Constraint: no hard-coded reward for any technique (it would just follow that playstyle). Reward code is unchanged.

Changes (2 constants, both overridable):
1. `BotAI.HYBRID_SHARE` default 0.09 -> 0.30 (`-Drlpvp.hybridShare=N`). Hybrid bots 13/14/15 (crit-reset-rush, wtap-combo-spacer, crit-punisher-plus)
   are now 30% of random-mix episodes instead of 9%, so a jump-crit has a real expected cost (airborne punishes) and combos become the way to beat them.
2. `Config.JUMP_ENTROPY_FLOOR_FRAC` default 0.35 -> 0.15 (`-Drlpvp.jumpFloor=N`). The 0.35 floor (3x entropy boost below it) kept the jump head noisy
   even though jumps cost nothing (SPAM_JUMP_REWARD_SCALE = 0), producing random airborne exposure.

Verification: full tests/run.sh suite run on the original and the modified tree: identical results (same 58 checks, same pass/fail).
Pre-existing failures, unchanged by this patch: GameplayRotationCheck (4), NetCapacityCheck (3), CritSatiationCheck.
Not verified: the effect on learning. Needs an A/B training run. Watch jump starts per episode, serverCritConversionRate, comboBreaks,
and HP dealt minus HP taken per style (StyleReport). If the agent starts avoiding jumps entirely, raise -Drlpvp.jumpFloor to ~0.25.
Revert either change with -Drlpvp.hybridShare=0.09 -Drlpvp.jumpFloor=0.35.
