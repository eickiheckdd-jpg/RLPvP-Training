package com.rlpvp;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** v7.57 pooled world model: weights are the replicas' average, counters are old total + each replica's own additions, and a second round does not double count. */
public final class ConsequencePoolCheck {
    static void feed(ConsequenceModel m, long seed, int n) {
        Random rng = new Random(seed);
        float[] obs = new float[Config.OBS_SIZE], act = new float[PpoAgent.N_ACT], next = new float[Config.FRAME];
        for (int k = 0; k < n; k++) {
            for (int i = 0; i < obs.length; i++) obs[i] = rng.nextFloat() * 2f - 1f;
            for (int i = 0; i < act.length; i++) act[i] = rng.nextFloat() * 2f - 1f;
            for (int i = 0; i < next.length; i++) next[i] = rng.nextFloat() * 2f - 1f;
            m.observe(obs, act, next);
        }
    }
    static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); }

    public static void main(String[] a) {
        ConsequenceModel master = new ConsequenceModel(new Random(1));
        feed(master, 100, 50);
        long base = master.transitions();
        List<ConsequenceModel> reps = new ArrayList<>();
        for (int r = 0; r < 3; r++) { ConsequenceModel c = new ConsequenceModel(new Random(10 + r)); c.copyPersistedStateFrom(master); reps.add(c); }
        long[] added = {40, 70, 25};
        for (int r = 0; r < 3; r++) feed(reps.get(r), 200 + r, (int) added[r]);
        float[][] w = new float[3][];
        for (int r = 0; r < 3; r++) w[r] = reps.get(r).debugWeights().clone();
        check(!java.util.Arrays.equals(w[0], w[1]), "replicas should have diverged");
        ConsequenceModel.pool(master, reps);
        float[] mw = master.debugWeights();
        for (int i = 0; i < mw.length; i++) {
            float e = (w[0][i] + w[1][i] + w[2][i]) / 3f;
            check(Math.abs(mw[i] - e) < 1e-6f, "weight " + i + " is not the average");
        }
        check(master.transitions() == base + 40 + 70 + 25, "transitions " + master.transitions());
        for (ConsequenceModel c : reps) c.copyPersistedStateFrom(master);
        for (int r = 0; r < 3; r++) check(java.util.Arrays.equals(reps.get(r).debugWeights(), mw), "copy back");
        // second round with only replica 1 adding data: nothing from round one may be counted again
        feed(reps.get(1), 999, 10);
        long t = master.transitions();
        ConsequenceModel.pool(master, reps);
        check(master.transitions() == t + 10, "double counting: " + (master.transitions() - t));
        try { ConsequenceModel.pool(master, List.of(master)); check(false, "dst in replicas accepted"); } catch (IllegalArgumentException ok) { }
        System.out.println("ConsequencePoolCheck: ok (average, counters, no double count)");
    }
}
