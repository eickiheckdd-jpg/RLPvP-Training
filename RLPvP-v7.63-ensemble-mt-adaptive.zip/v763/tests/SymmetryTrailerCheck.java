package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Random;

/** v7.61: symmetry is recorded per checkpoint; files from v7.60 and older (no SYM1 trailer) load as symmetric; frozen copies follow their source. */
public final class SymmetryTrailerCheck {
    static int fails = 0;
    static void check(String n, boolean ok) { System.out.printf("%-100s %s%n", n, ok ? "ok" : "FAIL"); if (!ok) fails++; }

    public static void main(String[] a) throws Exception {
        Path dir = Files.createTempDirectory("symtrailer");
        Random r = new Random(5);
        check("a new agent follows Config.SYMMETRIC_POLICY (default off)", new PpoAgent(1).symmetric == Config.SYMMETRIC_POLICY && !Config.SYMMETRIC_POLICY);
        PpoAgent plain = new PpoAgent(2); plain.symmetric = false;
        for (int i = 0; i < plain.actor.w.length; i++) plain.actor.w[i] += (float) (r.nextGaussian() * 0.05);
        Path p1 = dir.resolve("plain.bin"); plain.save(p1);
        PpoAgent back = PpoAgent.load(p1, 9);
        check("plain checkpoint reloads as NOT symmetric", !back.symmetric);
        PpoAgent sym = new PpoAgent(3); sym.symmetric = true;
        Path p2 = dir.resolve("sym.bin"); sym.save(p2);
        check("symmetric checkpoint reloads as symmetric", PpoAgent.load(p2, 9).symmetric);
        // a v7.60 file: same bytes without the final SYM1 trailer (4 tag + 4 length + 1 byte)
        byte[] bytes = Files.readAllBytes(p1);
        Path legacy = dir.resolve("legacy.bin");
        Files.write(legacy, java.util.Arrays.copyOf(bytes, bytes.length - 9));
        check("a file without the SYM1 trailer (v7.60 and older) loads as symmetric", PpoAgent.load(legacy, 9).symmetric);
        float[] o = new float[Config.OBS_SIZE];
        for (int i = 0; i < o.length; i++) o[i] = (float) (r.nextDouble() * 2 - 1);
        float[] zPlain = plain.logitsFor(o).clone();
        PpoAgent asLegacy = PpoAgent.load(legacy, 9);
        float[] zLegacy = asLegacy.logitsFor(o);
        double d = 0; for (int i = 0; i < zPlain.length; i++) d = Math.max(d, Math.abs(zPlain[i] - zLegacy[i]));
        check("same weights give different logits plain vs symmetrised (so the marker matters), diff " + String.format("%.3f", d), d > 1e-3);
        PpoAgent adopted = new PpoAgent(4); adopted.symmetric = false; adopted.adoptFrom(asLegacy);
        check("adoptFrom copies the symmetry mode", adopted.symmetric);
        System.out.println(fails == 0 ? "SymmetryTrailerCheck: all ok" : "SymmetryTrailerCheck: " + fails + " FAILED");
        if (fails != 0) System.exit(1);
    }
}
