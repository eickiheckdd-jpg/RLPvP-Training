package com.rlpvp;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** v7.57: the league must keep sampling an opponent that actually beats the agent, using the numbers of a real stage 9 ledger. */
public final class TroubleSamplingCheck {
    static int fails = 0;
    static void check(String n, boolean ok) { System.out.printf("%-100s %s%n", n, ok ? "ok" : "FAIL"); if (!ok) fails++; }

    static OpponentLeague ledger() {
        OpponentLeague l = new OpponentLeague();
        l.ensure("current");
        l.seedRating("current", 9386.0);
        // 15 scripted styles the agent beats ~always (3 games each), one that beats it 24% of the time (310 games), 10 snapshots the agent beats ~always
        for (int s = 0; s < 15; s++) for (int g = 0; g < 3; g++) l.result("current", "script:" + s, 1.0, 20.0, 3.0);
        for (int g = 0; g < 310; g++) l.result("current", "script:15", g % 100 < 24 ? 0.0 : 1.0, g % 100 < 24 ? 12.0 : 20.0, 12.0);
        for (int k = 0; k < 10; k++) for (int g = 0; g < 100; g++) l.result("current", "snapshot:" + (6000000 + k * 25000), g < 2 ? 0.0 : 1.0, 20.0, 3.0);
        // the real ledger always had fresh snapshots near the agent's own rating (in the PFSP band), which is why the bully was NOT picked as the 'closest' fallback
        for (int k = 0; k < 3; k++) { l.ensure("snapshot:" + (7600000 + k * 25000)); l.seedRating("snapshot:" + (7600000 + k * 25000), 9300.0); }
        return l;
    }

    static double share(OpponentLeague l, String id, boolean stage9, int draws) {
        List<String> cands = new ArrayList<>();
        for (int s = 0; s < 16; s++) cands.add("script:" + s);
        for (int k = 0; k < 10; k++) cands.add("snapshot:" + (6000000 + k * 25000));
        for (int k = 0; k < 3; k++) cands.add("snapshot:" + (7600000 + k * 25000));
        Random r = new Random(5);
        int hit = 0;
        for (int i = 0; i < draws; i++) if (id.equals(l.sample("current", cands, r, stage9))) hit++;
        return hit / (double) draws;
    }

    public static void main(String[] a) {
        OpponentLeague l = ledger();
        double s9 = share(l, "script:15", true, 20000), s7 = share(l, "script:15", false, 20000);
        System.out.printf("script:15 share of league draws: stage 9 %.1f%%, stage 7/8 %.1f%% (trouble share %.0f%%)%n", 100 * s9, 100 * s7, 100 * OpponentLeague.TROUBLE_SHARE);
        if (OpponentLeague.TROUBLE_SHARE > 0.0) {
            check("without the fix this ledger would hardly sample it (see the run with -Drlpvp.troubleShare=0): share below the fix's floor is not asserted here", true);
            check("the style that beats the agent 24% of the time gets at least the trouble share at stage 9", s9 >= OpponentLeague.TROUBLE_SHARE * 0.9);
            check("... and at stage 7/8", s7 >= OpponentLeague.TROUBLE_SHARE * 0.9);
            check("the 15 styles the agent always beats are not turned into troublemakers",
                l.sampleTroublemaker("current", List.of("script:0", "script:1", "script:2", "snapshot:6000000"), new Random(1)) == null);
            check("a 2% loss rate against a snapshot is not a troublemaker (baseline-relative)",
                l.sampleTroublemaker("current", List.of("snapshot:6000000"), new Random(1)) == null);
            check("script:15 is the troublemaker", "script:15".equals(l.sampleTroublemaker("current", List.of("script:0", "script:15", "snapshot:6000000"), new Random(1))));
        }
        OpponentLeague young = new OpponentLeague();
        young.ensure("current");
        for (int g = 0; g < 8; g++) young.result("current", "script:15", 0.0);
        check("fewer than TROUBLE_MIN_GAMES games is not enough evidence", young.sampleTroublemaker("current", List.of("script:15"), new Random(1)) == null);
        System.out.println(fails == 0 ? "TroubleSamplingCheck: all ok" : "TroubleSamplingCheck: " + fails + " FAILED");
        if (fails != 0) System.exit(1);
    }
}
