package com.rlpvp;

import java.io.*;
import java.nio.file.*;
import java.util.Random;

/** v7.46 auxiliary heads: labels (censoring, episode edges), learning, GRU-gradient blending, and checkpoint compatibility. */
public final class AuxForecasterCheck {
    static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); System.out.println("PASS " + msg); }

    static int unit(int task, int param) {
        // locate a unit by (task, param) via the label table order used by buildTargets: scan with probes
        for (int u = 0; u < AuxForecaster.NUNITS; u++) if (UNIT_TASK[u] == task && UNIT_PARAM[u] == param) return u;
        throw new IllegalArgumentException("no unit " + task + "/" + param);
    }
    static final int[] UNIT_TASK = new int[AuxForecaster.NUNITS], UNIT_PARAM = new int[AuxForecaster.NUNITS];
    static {
        int u = 0;
        for (int t : new int[]{AuxForecaster.T_SWING, AuxForecaster.T_SPRINT, AuxForecaster.T_AIR}) for (int h : AuxForecaster.OPP_H) { UNIT_TASK[u] = t; UNIT_PARAM[u++] = h; }
        for (int t : new int[]{AuxForecaster.T_LAT, AuxForecaster.T_RAD}) for (int h : AuxForecaster.OPP_H) { UNIT_TASK[u] = t; UNIT_PARAM[u++] = h; }
        for (int k : AuxForecaster.HAZ_K) { UNIT_TASK[u] = AuxForecaster.T_TAKEN; UNIT_PARAM[u++] = k; }
        for (int k : AuxForecaster.HAZ_K) { UNIT_TASK[u] = AuxForecaster.T_DEALT; UNIT_PARAM[u++] = k; }
        for (int o = 0; o < 3; o++) { UNIT_TASK[u] = AuxForecaster.T_OUTCOME; UNIT_PARAM[u++] = o; }
    }

    static float[][] blank(int n) {
        float[][] o = new float[n][Config.OBS_SIZE];
        for (float[] r : o) { r[AuxForecaster.F_OWN_HP] = 1f; r[AuxForecaster.F_TGT_HP] = 1f; r[AuxForecaster.F_TGT_GROUND] = 1f; r[AuxForecaster.F_DIST] = 0.5f; }
        return o;
    }

    static void labels() {
        int n = 60;
        float[][] obs = blank(n); boolean[] done = new boolean[n];
        done[24] = true;                                   // episode A = ticks 0..24, episode B = 25..59
        obs[10][AuxForecaster.F_TGT_SWING] = 1f;           // opponent swings at tick 10
        obs[26][AuxForecaster.F_TGT_SWING] = 1f;           // ... and in the NEXT episode at 26
        for (int j = 24; j < n; j++) obs[j][AuxForecaster.F_OWN_HP] = 0.7f;   // I lose health at tick 24 (the last tick of episode A)
        float[][] tg = new float[n][AuxForecaster.NUNITS], mk = new float[n][AuxForecaster.NUNITS];
        AuxForecaster.buildTargets(obs, done, n, tg, mk);
        int sw4 = unit(AuxForecaster.T_SWING, 4), sw10 = unit(AuxForecaster.T_SWING, 10), tk5 = unit(AuxForecaster.T_TAKEN, 5), out = unit(AuxForecaster.T_OUTCOME, 1);
        check(mk[5][sw4] == 1f && tg[5][sw4] == 0f, "swing label: no swing in the next 4 ticks, window complete -> valid negative");
        check(mk[8][sw4] == 1f && tg[8][sw4] == 1f, "swing label: swing at tick 10 is seen from tick 8 (+4) -> positive");
        check(tg[5][sw10] == 1f && mk[5][sw10] == 1f, "swing label (+10 window) sees the swing");
        check(mk[22][sw4] == 0f, "censoring: truncated window (episode ends at 24) with nothing seen is masked, not a negative");
        check(mk[23][sw4] == 0f && tg[23][sw4] == 0f, "episode boundary: the next episode's swing at 26 is never used for tick 23");
        check(mk[22][tk5] == 1f && tg[22][tk5] == 1f, "censoring: a hit on the final tick is a certain positive even in a truncated window");
        check(mk[23][tk5] == 1f && tg[23][tk5] == 1f, "hazard positive seen at the last tick");
        check(mk[10][out] == 0f, "outcome needs the complete 20-tick window: masked near the episode end");
        check(mk[30][out] == 1f && tg[30][out] == 0f, "outcome regression: complete window after the hit, no further damage -> 0");
        check(mk[n - 1][sw4] == 0f && mk[n - 3][unit(AuxForecaster.T_SPRINT, 10)] == 0f, "rollout end acts like an episode end (labels masked)");
    }

    static void learning() {
        Random rng = new Random(11);
        AuxForecaster aux = new AuxForecaster(rng, ObsStack.GRU_START, GruCell.H);
        int su = unit(AuxForecaster.T_SWING, 1), la = unit(AuxForecaster.T_LAT, 4), tk = unit(AuxForecaster.T_TAKEN, 10), ou = unit(AuxForecaster.T_OUTCOME, 2);
        for (int it = 0; it < 900; it++) {
            for (int b = 0; b < 64; b++) {
                float[] obs = new float[Config.OBS_SIZE];
                for (int i = 0; i < obs.length; i++) obs[i] = (float) (rng.nextGaussian() * 0.5);
                float[] tg = new float[AuxForecaster.NUNITS], mk = new float[AuxForecaster.NUNITS];
                java.util.Arrays.fill(mk, 1f);
                tg[su] = obs[ObsStack.GRU_START + 3] > 0 ? 1f : 0f;                                  // predictable from a GRU slot
                float v = obs[ObsStack.GRU_START + 5]; tg[la] = v < -0.3f ? 0f : v > 0.3f ? 2f : 1f;
                tg[tk] = obs[7] > 0.2f ? 1f : 0f;
                tg[ou] = 2f * obs[9];
                aux.clearInputGrad(); aux.accumulate(obs, tg, mk);
            }
            aux.step(3e-3f, 64);
        }
        check(aux.skill(AuxForecaster.T_SWING) > 0.5, "binary head learns a predictable opponent signal (skill " + String.format("%.2f", aux.skill(AuxForecaster.T_SWING)) + ")");
        check(aux.skill(AuxForecaster.T_LAT) > 0.3, "3-class head learns (skill " + String.format("%.2f", aux.skill(AuxForecaster.T_LAT)) + ")");
        check(aux.skill(AuxForecaster.T_TAKEN) > 0.3, "hazard head learns (skill " + String.format("%.2f", aux.skill(AuxForecaster.T_TAKEN)) + ")");
        check(aux.skill(AuxForecaster.T_OUTCOME) > 0.3, "Huber regression head learns (skill " + String.format("%.2f", aux.skill(AuxForecaster.T_OUTCOME)) + ")");
        float[] hi = new float[Config.OBS_SIZE], lo = new float[Config.OBS_SIZE];
        hi[ObsStack.GRU_START + 3] = 1f; lo[ObsStack.GRU_START + 3] = -1f;
        AuxForecaster.Forecast f1 = new AuxForecaster.Forecast(), f2 = new AuxForecaster.Forecast();
        aux.predict(hi, f1); aux.predict(lo, f2);
        check(f1.swing[0] > 0.8f && f2.swing[0] < 0.2f, "forecast responds to the hidden-state signal (" + f1.swing[0] + " vs " + f2.swing[0] + ")");
        check(Math.abs(f1.lateral[0][0] + f1.lateral[0][1] + f1.lateral[0][2] - 1f) < 1e-4f, "3-class forecast is a probability distribution");
        check(aux.trusted() == (aux.samples() >= Config.AUX_TRUST_SAMPLES && aux.skill(AuxForecaster.T_TAKEN) >= Config.AUX_TRUST_SKILL), "trust gate follows samples and hazard skill");
        // task log-variances moved (uncertainty weighting is live) and stayed bounded
        double mx = 0; for (int k = 0; k < AuxForecaster.TASKS; k++) mx = Math.max(mx, Math.abs(aux.logVariance(k)));
        check(mx > 1e-3 && mx <= 2.5 + 1e-6, "learned task log-variances adapt and stay bounded (max |s| = " + String.format("%.2f", mx) + ")");
    }

    static void blend() {
        Random rng = new Random(5);
        AuxForecaster aux = new AuxForecaster(rng, ObsStack.GRU_START, GruCell.H);
        float[] obs = new float[Config.OBS_SIZE]; for (int i = 0; i < obs.length; i++) obs[i] = (float) rng.nextGaussian();
        float[] tg = new float[AuxForecaster.NUNITS], mk = new float[AuxForecaster.NUNITS]; java.util.Arrays.fill(mk, 1f); tg[0] = 1f;
        int conflictsSeen = 0, tested = 0;
        for (int trial = 0; trial < 200; trial++) {
            aux.clearInputGrad(); aux.accumulate(obs, tg, mk);
            float[] g = new float[GruCell.H]; for (int q = 0; q < g.length; q++) g[q] = (float) rng.nextGaussian();
            float[] before = g.clone();
            aux.blendIntoGruGrad(g, 0f);
            for (int q = 0; q < g.length; q++) if (g[q] != before[q]) throw new AssertionError("ramp 0 changed the gradient");
            aux.blendIntoGruGrad(g, 1f);
            double dot = 0, nb = 0, na = 0;
            for (int q = 0; q < g.length; q++) { double add = g[q] - before[q]; dot += add * before[q]; nb += before[q] * before[q]; na += add * add; }
            tested++;
            if (Config.AUX_PROJECT) {
                if (dot < -1e-4 * Math.sqrt(nb * Math.max(na, 1e-12))) throw new AssertionError("added auxiliary gradient still opposes the RL gradient (dot " + dot + ")");
            }
            if (aux.conflicts() > 0) conflictsSeen = (int) aux.conflicts();
        }
        System.out.println("PASS warm-up ramp 0 leaves the RL gradient untouched (200 random gradients)");
        check(tested == 200 && conflictsSeen > 0, "random RL gradients conflict with the heads' gradient sometimes (" + conflictsSeen + "/200) and the added part never opposes the RL gradient");
    }

    static void persistence() throws Exception {
        Random rng = new Random(3);
        AuxForecaster a = new AuxForecaster(new Random(1), ObsStack.GRU_START, GruCell.H);
        for (int it = 0; it < 50; it++) {
            float[] obs = new float[Config.OBS_SIZE]; for (int i = 0; i < obs.length; i++) obs[i] = (float) rng.nextGaussian();
            float[] tg = new float[AuxForecaster.NUNITS], mk = new float[AuxForecaster.NUNITS]; java.util.Arrays.fill(mk, 1f);
            for (int b = 0; b < 16; b++) { a.clearInputGrad(); a.accumulate(obs, tg, mk); }
            a.step(1e-3f, 16);
        }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bo)) { a.write(out); }
        AuxForecaster b = new AuxForecaster(new Random(99), ObsStack.GRU_START, GruCell.H);
        b.read(new DataInputStream(new ByteArrayInputStream(bo.toByteArray())));
        float[] probe = new float[Config.OBS_SIZE]; for (int i = 0; i < probe.length; i++) probe[i] = (float) rng.nextGaussian();
        AuxForecaster.Forecast fa = new AuxForecaster.Forecast(), fb = new AuxForecaster.Forecast();
        a.predict(probe, fa); b.predict(probe, fb);
        check(fa.taken[1] == fb.taken[1] && fa.swing[2] == fb.swing[2] && fa.swing20 == fb.swing20 && a.samples() == b.samples(), "aux block round-trips exactly (weights, Adam state, statistics)");
        byte[] bad = bo.toByteArray().clone(); bad[3] ^= 0x7f;   // corrupt the format word
        AuxForecaster c = new AuxForecaster(new Random(99), ObsStack.GRU_START, GruCell.H);
        long before = c.samples();
        c.read(new DataInputStream(new ByteArrayInputStream(bad)));
        check(c.samples() == before, "a block with an unknown layout is ignored without touching the fresh heads");

        // whole-agent checkpoint: save, reload, and a file from before the aux trailer
        Path dir = Files.createTempDirectory("auxck"), f = dir.resolve("state.bin");
        PpoAgent agent = new PpoAgent(7);
        agent.save(f);
        PpoAgent back = PpoAgent.load(f, 7);
        check(back.auxForecaster() != null, "checkpoint with the aux trailer loads");
        byte[] all = Files.readAllBytes(f);
        int magic = 0x41555831, at = -1;
        for (int i = all.length - 4; i >= 0; i--) if (((all[i] & 255) << 24 | (all[i + 1] & 255) << 16 | (all[i + 2] & 255) << 8 | (all[i + 3] & 255)) == magic) { at = i; break; }
        check(at > 0, "saved checkpoint contains the AUX1 trailer");
        Path old = dir.resolve("old.bin");
        Files.write(old, java.util.Arrays.copyOf(all, at));
        PpoAgent legacy = PpoAgent.load(old, 7);
        check(legacy.auxForecaster() != null && legacy.auxForecaster().samples() == 0, "a checkpoint written before the aux heads still loads; heads start fresh");
    }

    public static void main(String[] args) throws Exception {
        check(AuxForecaster.NUNITS == 24 && AuxForecaster.NLOGITS == 36, "head layout: 24 prediction units over 36 logits");
        labels(); learning(); blend(); persistence();
    }
}
