package com.rlpvp;

import java.util.Arrays;
import java.util.UUID;

/** v7.52 threat / timing inputs: semantics of each of the five values, their place in the 133-input layout, mirror invariance, ping lookup. */
public final class ThreatObservationCheck {
    private static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }
    private static boolean near(float a, double b) { return Math.abs(a - b) < 1e-5; }

    /** A frame with only the fields ThreatObservation reads. */
    private static float[] frame(boolean myGround, boolean jumpCmd, boolean enemyGround, float enemyVy, boolean enemySprint) {
        float[] f = new float[Config.FRAME];
        f[4] = myGround ? 1f : 0f; f[32] = jumpCmd ? 1f : 0f;
        f[19] = enemyGround ? 1f : 0f; f[18] = enemyVy; f[22] = enemySprint ? 1f : 0f;
        return f;
    }

    public static void main(String[] args) {
        check("compact mode, 133 inputs, threat block is the last 5", Config.COMPACT_126 && Config.OBS_SIZE == 133
            && ObsStack.THREAT_START == 128 && ObsStack.PING_SLOT == 132 && ThreatObservation.FEATURES == 5);

        // ---- 1. enemy crit-ready: airborne, falling, not sprinting ----
        ThreatObservation t = new ThreatObservation();
        t.tick(frame(true, false, false, -0.2f, false), 0, 0);
        check("enemy falling, not sprinting -> crit-ready", t.values()[ThreatObservation.ENEMY_CRIT] == 1f);
        t.tick(frame(true, false, false, -0.2f, true), 0, 0);
        check("enemy falling but sprinting -> not crit-ready", t.values()[ThreatObservation.ENEMY_CRIT] == 0f);
        t.tick(frame(true, false, false, 0.3f, false), 0, 0);
        check("enemy still rising -> not crit-ready", t.values()[ThreatObservation.ENEMY_CRIT] == 0f);
        t.tick(frame(true, false, true, -0.2f, false), 0, 0);
        check("enemy on the ground -> not crit-ready", t.values()[ThreatObservation.ENEMY_CRIT] == 0f);

        // ---- 2. ticks since my own jump ----
        t = new ThreatObservation();
        check("fresh episode: no recent jump (age 1.0)", t.values()[ThreatObservation.MY_JUMP_AGE] == 1f);
        t.tick(frame(true, true, true, 0f, false), 0, 0);   // jump commanded, still on the ground (e.g. jump delay): not a takeoff
        check("jump commanded but still grounded does not start the timer", t.values()[ThreatObservation.MY_JUMP_AGE] == 1f);
        t.tick(frame(false, true, true, 0f, false), 0, 0);  // grounded last tick + jump command + airborne now = takeoff
        check("takeoff resets the age to 0", t.values()[ThreatObservation.MY_JUMP_AGE] == 0f);
        for (int i = 1; i <= 12; i++) t.tick(frame(false, false, true, 0f, false), 0, 0);
        check("12 ticks later the age is 12/20 (the punish window is visible)", near(t.values()[ThreatObservation.MY_JUMP_AGE], 12 / 20.0));
        for (int i = 0; i < 30; i++) t.tick(frame(true, false, true, 0f, false), 0, 0);
        check("age saturates at 1.0", t.values()[ThreatObservation.MY_JUMP_AGE] == 1f);
        t.tick(frame(false, false, true, 0f, false), 0, 0);  // launched by knockback: airborne without a jump command
        check("knockback launch is not my jump", t.values()[ThreatObservation.MY_JUMP_AGE] == 1f);

        // ---- 3. ticks since the enemy's sprint reset (w-tap) ----
        t = new ThreatObservation();
        t.tick(frame(true, false, true, 0f, true), 0, 0);   // sprint starts from standing still: not a reset
        check("first sprint from a standstill is not a reset", t.values()[ThreatObservation.ENEMY_RESET] == 1f);
        for (int i = 0; i < 5; i++) t.tick(frame(true, false, true, 0f, true), 0, 0);
        for (int i = 0; i < 3; i++) t.tick(frame(true, false, true, 0f, false), 0, 0);   // sprint dropped for 3 ticks
        t.tick(frame(true, false, true, 0f, true), 0, 0);                                  // and straight back on: a reset
        check("sprint dropped 3 ticks then restarted -> reset just happened (age 0)", t.values()[ThreatObservation.ENEMY_RESET] == 0f);
        for (int i = 1; i <= 10; i++) t.tick(frame(true, false, true, 0f, true), 0, 0);
        check("10 ticks after the reset the age is 10/40", near(t.values()[ThreatObservation.ENEMY_RESET], 10 / 40.0));
        for (int i = 0; i < 6; i++) t.tick(frame(true, false, true, 0f, false), 0, 0);    // sprint off 6 ticks (stopping / backing off), then on
        t.tick(frame(true, false, true, 0f, true), 0, 0);
        check("a 6-tick stop before the restart is not a w-tap", t.values()[ThreatObservation.ENEMY_RESET] > 0.2f);
        t = new ThreatObservation();
        for (int i = 0; i < 5; i++) t.tick(frame(true, false, true, 0f, true), 0, 0);
        t.tick(frame(true, false, true, 0f, false), 0, 0); t.tick(frame(true, false, true, 0f, true), 0, 0);
        check("a 1-tick release is a w-tap", t.values()[ThreatObservation.ENEMY_RESET] == 0f);
        for (int i = 0; i < 30; i++) t.tick(frame(true, false, true, 0f, false), 0, 0);   // long pause, then sprint again
        t.tick(frame(true, false, true, 0f, true), 0, 0);
        check("a restart after a long pause is not a reset", t.values()[ThreatObservation.ENEMY_RESET] > 0.5f);

        // ---- 4. signed enemy reach margin ----
        t = new ThreatObservation();
        t.tick(frame(true, false, true, 0f, false), 0.75, 0);
        check("inside the enemy's reach by 0.75 -> +0.5", near(t.values()[ThreatObservation.ENEMY_REACH], 0.5));
        t.tick(frame(true, false, true, 0f, false), -0.3, 0);
        check("0.3 outside its reach -> -0.2 (more than a yes/no flag)", near(t.values()[ThreatObservation.ENEMY_REACH], -0.2));
        t.tick(frame(true, false, true, 0f, false), -9.0, 0);
        check("far outside clamps to -1", t.values()[ThreatObservation.ENEMY_REACH] == -1f);
        t.tick(frame(true, false, true, 0f, false), Double.NaN, 0);
        check("non-finite margin becomes 0", t.values()[ThreatObservation.ENEMY_REACH] == 0f);

        // ---- 5. ping ----
        t.tick(frame(true, false, true, 0f, false), 0, 75);
        check("75 ms -> 0.375", near(t.values()[ThreatObservation.PING], 75 / 200.0));
        t.tick(frame(true, false, true, 0f, false), 0, 900);
        check("very high ping clamps to 1", t.values()[ThreatObservation.PING] == 1f);
        t.tick(frame(true, false, true, 0f, false), 0, -5);
        check("negative / unknown ping clamps to 0", t.values()[ThreatObservation.PING] == 0f);

        // ---- layout: ObsStack writes the block at 128..132 and touches nothing else ----
        float[] fr = new float[Config.FRAME];
        for (int i = 0; i < fr.length; i++) fr[i] = (i - 20) / 100f;
        float[] summary = new float[Config.SUMMARY];
        for (int i = 0; i < summary.length; i++) summary[i] = 0.01f * (i % 7);
        float[] threat = {1f, 0.25f, 0.5f, -0.4f, 0.3f};
        ObsStack st = new ObsStack();
        float[] with = st.push(fr, summary, threat), without = st.push(fr, summary);
        boolean placed = true;
        for (int i = 0; i < 5; i++) placed &= with[128 + i] == threat[i];
        check("ObsStack places the five values at 128..132", placed);
        boolean restSame = true;
        for (int i = 0; i < 128; i++) restSame &= with[i] == without[i];
        check("the first 128 inputs are unchanged by the threat block", restSame);
        float[] neutral = Arrays.copyOfRange(without, 128, 133);
        check("no tracker -> neutral values (no recent events, no ping)", Arrays.equals(neutral, ThreatObservation.NEUTRAL));
        float[] reuse = new ObsStack().pushReusable(fr, summary, threat);
        check("pushReusable carries the block too", reuse[128] == 1f && reuse[132] == 0.3f);
        float[] nanThreat = {Float.NaN, 0f, 0f, 0f, Float.POSITIVE_INFINITY};
        float[] safe = new ObsStack().push(fr, summary, nanThreat);
        check("non-finite values never reach the network", safe[128] == 0f && safe[132] == 0f);

        // ---- mirror invariance: Symmetry must not flip any threat slot ----
        boolean flipped = false;
        for (int p : Symmetry.positions()) if (p >= 128) flipped |= p <= 132;
        check("threat slots carry no left/right sign (Symmetry leaves them alone)", !flipped);
        float[] mirrored = new float[with.length];
        Symmetry.obs(with, mirrored);
        boolean same = true;
        for (int i = 128; i < 133; i++) same &= mirrored[i] == with[i];
        check("mirrored observation keeps the threat block unchanged", same);

        // ---- ping lookup (reflective, no Minecraft types) ----
        UUID id = UUID.randomUUID();
        check("measured ping read through connection -> player info -> latency", ThreatObservation.measuredPingMs(new FakeMc(new FakeConn(id, 42)), id) == 42.0);
        check("no connection (offline / main menu) -> 0", ThreatObservation.measuredPingMs(new FakeMc(null), id) == 0.0);
        check("unknown player -> 0", ThreatObservation.measuredPingMs(new FakeMc(new FakeConn(id, 42)), UUID.randomUUID()) == 0.0);
        check("object without the methods -> 0, no exception", ThreatObservation.measuredPingMs(new Object(), id) == 0.0);
        check("null arguments -> 0", ThreatObservation.measuredPingMs(null, id) == 0.0 && ThreatObservation.measuredPingMs(new FakeMc(null), null) == 0.0);
        System.out.println("ThreatObservationCheck: all ok");
    }

    public static final class FakeMc {
        private final FakeConn c; FakeMc(FakeConn c) { this.c = c; }
        public FakeConn getConnection() { return c; }
    }
    public static final class FakeConn {
        private final UUID id; private final int ms; FakeConn(UUID id, int ms) { this.id = id; this.ms = ms; }
        public FakeInfo getPlayerInfo(UUID u) { return id.equals(u) ? new FakeInfo(ms) : null; }
    }
    public static final class FakeInfo {
        private final int ms; FakeInfo(int ms) { this.ms = ms; }
        public int getLatency() { return ms; }
    }
}
