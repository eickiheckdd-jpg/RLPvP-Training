package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

/** v7.62: FrozenPolicy copies are independent and agree with the original; the league version marker warns once and never touches ratings. */
public final class PolishV762Check {
    static int fails = 0;
    static void check(String n, boolean ok) { System.out.printf("%-104s %s%n", n, ok ? "ok" : "FAIL"); if (!ok) fails++; }

    public static void main(String[] a) throws Exception {
        // --- FrozenPolicy.copy
        PpoAgent src = new PpoAgent(21); src.symmetric = (a.length > 0);
        Random r = new Random(4);
        for (int i = 0; i < src.actor.w.length; i++) src.actor.w[i] += (float) (r.nextGaussian() * 0.05);
        FrozenPolicy f = new FrozenPolicy(src), c = f.copy();
        float[] obs = new float[Config.OBS_SIZE];
        for (int i = 0; i < obs.length; i++) obs[i] = (float) (r.nextDouble() * 2 - 1);
        float[] x = f.act(obs, 0), y = c.act(obs, 0);
        check("a copy returns its own action buffer", x != y);
        float[] keep = x.clone();
        for (int i = 0; i < 50; i++) c.act(obs, 0);
        check("driving the copy does not disturb the original's buffer", java.util.Arrays.equals(keep, x));
        // many threads, each with its own copy, versus the same sampling done on one thread: every action must be a valid action row
        final int threads = 4, calls = 20000;
        AtomicInteger bad = new AtomicInteger();
        Thread[] ts = new Thread[threads];
        for (int t = 0; t < threads; t++) {
            final FrozenPolicy mine = f.copy();
            final float[] myObs = obs.clone();
            ts[t] = new Thread(() -> {
                for (int i = 0; i < calls; i++) {
                    float[] act = mine.act(myObs, 0);
                    for (float v : act) if (!Float.isFinite(v)) bad.incrementAndGet();
                    int fwd = Math.round(act[2]), str = Math.round(act[3]);
                    if (fwd < 0 || fwd > 2 || str < 0 || str > 2) bad.incrementAndGet();
                }
            });
            ts[t].start();
        }
        for (Thread t : ts) t.join();
        check("4 threads, one copy each, 80000 actions: all finite and in range", bad.get() == 0);
        check("a copy keeps the symmetry mode", ((Boolean) field(c, "symmetric")) == src.symmetric);

        // --- league version marker
        Path dir = Files.createTempDirectory("leaguever");
        Path ratings = dir.resolve("ratings.csv");
        check("empty league: no warning, marker written", OpponentLeague.checkVersion(dir, ratings) == null && Files.readString(dir.resolve("league.version")).trim().equals(Integer.toString(OpponentLeague.LEAGUE_VERSION)));
        Path old = Files.createTempDirectory("leagueold");
        Files.writeString(old.resolve("ratings.csv"), "id,rating,games,wins,losses,draws\n\"current\",1500,10,5,5,0\n");
        String before = Files.readString(old.resolve("ratings.csv"));
        String w1 = OpponentLeague.checkVersion(old, old.resolve("ratings.csv"));
        check("ratings without a marker: warns", w1 != null && w1.contains("no version marker"));
        check("the warning never changes the ratings file", before.equals(Files.readString(old.resolve("ratings.csv"))));
        check("second start: no repeated warning", OpponentLeague.checkVersion(old, old.resolve("ratings.csv")) == null);
        Files.writeString(old.resolve("league.version"), "1");
        String w2 = OpponentLeague.checkVersion(old, old.resolve("ratings.csv"));
        check("older marker: warns with both versions", w2 != null && w2.contains("version 1"));
        Files.writeString(old.resolve("league.version"), Integer.toString(OpponentLeague.LEAGUE_VERSION + 5));
        String w3 = OpponentLeague.checkVersion(old, old.resolve("ratings.csv"));
        check("newer marker: warns and does not downgrade it", w3 != null && w3.contains("NEWER") && Files.readString(old.resolve("league.version")).trim().equals(Integer.toString(OpponentLeague.LEAGUE_VERSION + 5)));
        System.out.println(fails == 0 ? "PolishV762Check: all ok" : "PolishV762Check: " + fails + " FAILED");
        if (fails != 0) System.exit(1);
    }

    static Object field(Object o, String name) throws Exception {
        java.lang.reflect.Field f = o.getClass().getDeclaredField(name); f.setAccessible(true); return f.get(o);
    }
}
