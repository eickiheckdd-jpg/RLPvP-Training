package com.rlpvp;

import java.io.*;
import java.util.Arrays;

/** v7.63: -Drlpvp.learnThreads=N must produce (numerically) the same PPO update as 1 thread. Usage: ShardedLearnerCheck out.bin [reference.bin]  (run once with threads=1, once with N). */
public final class ShardedLearnerCheck {
    static void collect(PpoAgent agent) {
        float[] obs = new float[Config.OBS_SIZE], h = new float[GruCell.H], x = new float[GruCell.X];
        for (int t = 0; t < Config.ROLLOUT; t++) {
            for (int i = 0; i < obs.length; i++) obs[i] = (float) Math.sin((t + 1) * (i + 3) * 0.001);
            for (int i = 0; i < x.length; i++) x[i] = (float) Math.cos((t + 2) * (i + 1) * 0.017);
            for (int i = 0; i < h.length; i++) h[i] = (float) Math.sin((t + 4) * (i + 1) * 0.009);
            agent.noteMemory(h, x);
            agent.actTrain(obs);
            agent.addReward(Math.sin(t * 0.031) * 0.25);
            if (t % 97 == 96) agent.endEpisode(true, null);
        }
        agent.endEpisode(true, null);
    }

    public static void main(String[] a) throws Exception {
        PpoAgent agent = new PpoAgent(0x739L);
        agent.symmetric = Boolean.getBoolean("sym");
        collect(agent);
        agent.learnTick();
        double[] first = agent.takeStats();   // ONE minibatch step: all samples are evaluated at identical weights, so these must match across thread counts
        System.out.printf("first minibatch: kl %.6f ent %.6f clip %.4f vloss %.6f gradNorm %.6f%n", first[1], first[2], first[3], first[4], first[5]);
        long t0 = System.nanoTime(); int steps = 0;
        while (agent.learnerBusy()) { agent.learnTick(); steps++; }
        double sec = (System.nanoTime() - t0) / 1e9;
        float[][] w = agent.exportWeights();
        System.out.printf("threads=%d steps=%d learn %.2fs updates=%d%n", PpoAgent.LEARN_THREADS, steps, sec, agent.updates);
        try (DataOutputStream o = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(a[0])))) {
            o.writeInt(agent.updates);
            for (float[] arr : new float[][]{w[0], w[1]}) { o.writeInt(arr.length); for (float f : arr) o.writeFloat(f); }
        }
        if (a.length > 1) {
            try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(a[1])))) {
                int upd = in.readInt(); double worst = 0, scale = 0; boolean finite = true;
                for (int k = 0; k < 2; k++) {
                    int n = in.readInt(); if (n != w[k].length) throw new AssertionError("length mismatch");
                    for (int i = 0; i < n; i++) { float ref = in.readFloat(); worst = Math.max(worst, Math.abs(ref - w[k][i])); scale = Math.max(scale, Math.abs(ref)); if (!Float.isFinite(w[k][i])) finite = false; }
                }
                System.out.printf("max |weight - reference| = %.3g (largest weight %.3g); updates %d vs %d; finite=%b%n", worst, scale, agent.updates, upd, finite);
                if (!finite || upd != agent.updates || worst > 1e-3) { System.out.println("FAIL"); System.exit(1); }
                System.out.println("PASS");
            }
        }
    }
}
