package com.rlpvp;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** v7.57: mastered-style drop, wasted-strafe cost, faster bot difficulty. */
public final class V757BatchCheck {
    static int fails = 0;
    static void check(String n, boolean ok) { System.out.printf("%-100s %s%n", n, ok ? "ok" : "FAIL"); if (!ok) fails++; }

    public static void main(String[] a) {
        OpponentLeague l = new OpponentLeague();
        l.ensure("current");
        for (int g = 0; g < 100; g++) l.result("current", "script:0", 1.0, 20.0, 3.0);          // beaten 100/100
        for (int s = 1; s < 6; s++) for (int g = 0; g < 100; g++) l.result("current", "script:" + s, g % 2 == 0 ? 1.0 : 0.0, 14.0, 10.0); // 50%
        for (int g = 0; g < 100; g++) l.result("current", "script:6", g < 97 ? 1.0 : 0.0, 20.0, 3.0); // 97% < 98%: not mastered
        for (int g = 0; g < 10; g++) l.result("current", "script:7", 1.0, 20.0, 3.0);           // beaten always but only 10 games: not enough evidence
        List<String> c = new ArrayList<>();
        for (int s = 0; s < 8; s++) c.add("script:" + s);
        Random r = new Random(3);
        int without0 = 0, n = 4000, has6 = 0, has7 = 0;
        for (int i = 0; i < n; i++) {
            List<String> k = l.dropMastered("current", c, r);
            if (!k.contains("script:0")) without0++;
            if (k.contains("script:6")) has6++;
            if (k.contains("script:7")) has7++;
        }
        System.out.printf("draws without the mastered style: %.1f%% (keep share %.0f%%)%n", 100.0 * without0 / n, 100 * OpponentLeague.MASTERED_KEEP);
        if (OpponentLeague.MASTERED_WIN <= 1.0) {
            check("a style beaten 100/100 is left out of about (1 - keep) of the draws", Math.abs(without0 / (double) n - (1 - OpponentLeague.MASTERED_KEEP)) < 0.03);
            check("a style beaten 97% stays in", has6 == n);
            check("a style with only 10 games stays in", has7 == n);
        }
        OpponentLeague few = new OpponentLeague();
        few.ensure("current");
        for (int g = 0; g < 100; g++) few.result("current", "script:0", 1.0, 20.0, 3.0);
        for (int g = 0; g < 100; g++) few.result("current", "script:1", 1.0, 20.0, 3.0);
        boolean untouched = true;
        for (int i = 0; i < 200; i++) if (few.dropMastered("current", List.of("script:0", "script:1", "script:2"), r).size() != 3) untouched = false;
        check("if fewer than three opponents would remain, nothing is dropped", untouched);

        // wasted strafing: same flips, different outcome
        double flipNoMove = run(1, 0.0), flipMoves = run(1, 0.15);
        double slowNoMove = run(12, 0.0);
        System.out.printf("per-episode cost: twitch/no sideways motion %.3f, twitch/real sideways motion %.3f, slow strafe/no motion %.3f%n", flipNoMove, flipMoves, slowNoMove);
        check("A/D twitching with no sideways motion costs something", Config.STRAFE_WASTE_W <= 0.0 || flipNoMove < -0.05);
        check("the same flips with real sideways motion are free", flipMoves > -1e-9);
        check("slow deliberate strafing is free", slowNoMove > -1e-9);

        BotDifficulty d = new BotDifficulty();
        for (int i = 0; i < 40; i++) d.report(true);
        System.out.printf("bot difficulty after 40 straight wins: %.2f (start %.2f, window %d, step %.2f)%n", d.value(), BotDifficulty.START, BotDifficulty.WINDOW, BotDifficulty.STEP);
        check("difficulty starts at START and climbs", d.value() > BotDifficulty.START + 0.2);
        System.out.println(fails == 0 ? "V757BatchCheck: all ok" : "V757BatchCheck: " + fails + " FAILED");
        if (fails != 0) System.exit(1);
    }

    /** 400 ticks of pressing W plus strafe, flipping direction every {@code period} ticks, sideways speed {@code lat}. */
    static double run(int period, double lat) {
        SpamGuard g = new SpamGuard();
        g.reset();
        SpamGuard.In s = new SpamGuard.In();
        s.moveFree = true; s.fwd = 1; s.speed = 0.2; s.enemyDist = 4.0; s.latSpeed = lat;
        double total = 0;
        for (int t = 0; t < 400; t++) { s.str = ((t / period) % 2 == 0) ? 1 : -1; total += g.tick(s); }
        return total;
    }
}
