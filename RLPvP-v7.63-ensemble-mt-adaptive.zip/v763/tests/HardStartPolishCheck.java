package com.rlpvp;

import java.util.Random;

/** v7.60: hard-start episodes train the policy but never feed league / window statistics; the health-difference shaping starts from the real potential. */
public final class HardStartPolishCheck {
    static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); System.out.println("PASS " + msg); }

    public static void main(String[] args) {
        // ---- shaping from an off-level start
        double g = Config.GAMMA, w = Config.HP_DIFF_REWARD * RewardTuning.get("hp_difference");
        Random rng = new Random(9);
        double worst = 0;
        for (double startLead : new double[]{-0.8, -0.35, 0.0, 0.4}) {
            for (int ep = 0; ep < 50; ep++) {
                int n = 30 + rng.nextInt(200); double lead = startLead; double disc = 1, sum = 0;
                HealthDifferenceReward h = new HealthDifferenceReward(); h.reset(startLead);
                for (int t = 0; t < n; t++) {
                    lead = Math.max(-1, Math.min(1, lead + (rng.nextDouble() - 0.5) * 0.1));
                    double r = h.tick(lead); if (t == n - 1) r += h.terminal();
                    sum += disc * r; disc *= g;
                }
                worst = Math.max(worst, Math.abs(sum - (-w * HealthDifferenceReward.phi(startLead))));
            }
        }
        check(worst < 1e-9, "from any start the shaping sums to the constant -w*Phi(start) over a terminal episode (worst " + worst + "), so it cannot favour any action");
        HealthDifferenceReward lowStart = new HealthDifferenceReward(); lowStart.reset(-0.8);
        double first = lowStart.tick(-0.8);
        HealthDifferenceReward oldStyle = new HealthDifferenceReward(); oldStyle.reset();
        double firstOld = oldStyle.tick(-0.8);
        check(Math.abs(first) < 0.05 * Math.abs(firstOld), "a low-health start no longer pays a one-off phantom penalty on tick 0 (" + String.format("%.3f", first) + " vs " + String.format("%.2f", firstOld) + ")");

        // ---- statistics gating
        PvpSim s = new PvpSim(5, new PpoAgent(5));
        float[] in = new float[Config.OBS_SIZE];
        s.hardStartKind = 1;
        s.endEpisode(true, EpisodeOutcome.LOSS, in, null);
        check(s.wEp == 0 && s.wLoss == 0, "a lost hard start does not enter the window win/loss counts");
        check(s.hsEp[1] == 1 && s.hsLoss[1] == 1 && s.hsWin[1] == 0, "...but is tallied under its own kind");
        s.hardStartKind = 2;
        s.endEpisode(true, EpisodeOutcome.WIN, in, null);
        check(s.wEp == 0 && s.wWin == 0 && s.hsWin[2] == 1, "a won hard start is not counted as a normal win either");
        s.hardStartKind = -1;
        s.endEpisode(true, EpisodeOutcome.LOSS, in, null);
        check(s.wEp == 1 && s.wLoss == 1, "a normal episode still counts");
        String line = s.hardStartTallyAndReset();
        check(line.contains("mid-combo 1 ep") && line.contains("low-hp 1 ep") && s.hsEp[1] == 0, "the tally line reports each kind and resets: " + line);
        check(s.hardStartTallyAndReset().equals("hard starts: -"), "an empty window prints a placeholder");

        // league ratings: a hard-start result must not touch them, a normal one must
        PvpSim t = new PvpSim(6, new PpoAgent(6));
        t.activeLeagueOpponentId = "script:3";
        long before = t.league.games(t.leagueAgentId);
        t.hardStartKind = 0;
        t.endEpisode(true, EpisodeOutcome.LOSS, in, null);
        check(t.league.games(t.leagueAgentId) == before, "a hard start never moves league ratings / matchup records");
        t.activeLeagueOpponentId = "script:3"; t.hardStartKind = -1;
        t.endEpisode(true, EpisodeOutcome.LOSS, in, null);
        check(t.league.games(t.leagueAgentId) == before + 1, "a normal episode does");
    }
}
