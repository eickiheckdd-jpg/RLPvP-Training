package com.rlpvp;

import java.util.Random;

/** v7.49 health-difference shaping: potential-based (telescopes to zero over a terminal episode), two-sided, situation-weighted. */
public final class HealthDifferenceRewardCheck {
    static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); System.out.println("PASS " + msg); }

    static double[] lead(Random r, int n) {
        double[] l = new double[n]; double v = 0;
        for (int t = 0; t < n; t++) { if (r.nextInt(9) == 0) v += (r.nextBoolean() ? 1 : -1) * (0.05 + 0.3 * r.nextDouble()); v = Math.max(-1, Math.min(1, v)); l[t] = v; }
        return l;
    }

    public static void main(String[] args) {
        check(Config.HP_DIFF_REWARD > 0f, "health-difference shaping is on by default (weight " + Config.HP_DIFF_REWARD + ")");
        double g = Config.GAMMA;
        Random rng = new Random(4);
        double worstTerminal = 0, worstTrunc = 0;
        for (int ep = 0; ep < 300; ep++) {
            double[] l = lead(rng, 40 + rng.nextInt(400));
            HealthDifferenceReward h = new HealthDifferenceReward(); h.reset();
            double sum = 0, disc = 1;
            for (int t = 0; t < l.length; t++) { double r = h.tick(l[t]); if (t == l.length - 1 && ep % 2 == 0) r += h.terminal(); sum += disc * r; disc *= g; }
            if (ep % 2 == 0) worstTerminal = Math.max(worstTerminal, Math.abs(sum));
            else worstTrunc = Math.max(worstTrunc, Math.abs(sum - Math.pow(g, l.length) * Config.HP_DIFF_REWARD * RewardTuning.get("hp_difference") * HealthDifferenceReward.phi(l[l.length - 1])));
        }
        check(worstTerminal < 1e-9, "terminal episodes: discounted shaping telescopes to exactly 0 (worst " + worstTerminal + "), so it cannot change the optimal policy");
        check(worstTrunc < 1e-9, "time-limit truncation keeps gamma^T * Phi (the critic bootstraps through it), no cancellation");

        HealthDifferenceReward even = new HealthDifferenceReward(); even.reset();
        double up = even.tick(0.35), down; HealthDifferenceReward d2 = new HealthDifferenceReward(); d2.reset(); down = d2.tick(-0.35);
        check(up > 0 && down < 0 && Math.abs(up + down) < 1e-9, "two-sided and symmetric: +/-7 HP from level gives +/-" + String.format("%.2f", up));
        HealthDifferenceReward ahead = new HealthDifferenceReward(); ahead.reset(); ahead.tick(0.6);
        double lateGain = ahead.tick(0.95);
        check(up > 3 * lateGain, "a hit matters most in a close fight: " + String.format("%.2f", up) + " from level vs " + String.format("%.2f", lateGain) + " when already far ahead");
        HealthDifferenceReward behind = new HealthDifferenceReward(); behind.reset(); behind.tick(-0.6);
        double comeback = behind.tick(-0.25);
        check(comeback > lateGain * 3, "a comeback hit when behind is worth much more than padding a big lead (" + String.format("%.2f", comeback) + ")");
        HealthDifferenceReward sit = new HealthDifferenceReward(); sit.reset(); sit.tick(0.5);
        double hold = 0; for (int i = 0; i < 1000; i++) hold += sit.tick(0.5);
        check(Math.abs(hold) < 1000 * (1 - g) * Config.HP_DIFF_REWARD * 1.0 * 1.0001, "sitting on a lead earns nothing: only the (1-gamma) leak, a slight cost (1000 ticks: " + String.format("%.2f", hold) + ", bound " + String.format("%.2f", 1000 * (1 - g) * Config.HP_DIFF_REWARD) + ")");
        sit.reset();
        check(sit.lastPotential() == 0.0, "reset starts every episode level");
    }
}
