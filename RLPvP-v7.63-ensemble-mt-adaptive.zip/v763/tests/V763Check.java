package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Random;

/** v7.63: bot difficulty trailer, adaptive hard-start mix, randomized physics, exploiter recipes, world-model ensemble + planner. */
public final class V763Check {
    static int fails = 0;
    static void check(String n, boolean ok) { System.out.printf("%-110s %s%n", n, ok ? "ok" : "FAIL"); if (!ok) fails++; }

    public static void main(String[] a) throws Exception {
        Path dir = Files.createTempDirectory("v763");
        // ---- DIF1
        PpoAgent p = new PpoAgent(3);
        p.save(dir.resolve("nodif.bin"));
        check("no difficulty recorded -> none restored", Float.isNaN(PpoAgent.loadMain(dir.resolve("nodif.bin"), 1).botDifficulty));
        p.botDifficulty = 0.47f; p.save(dir.resolve("dif.bin"));
        check("difficulty trailer round-trips", Math.abs(PpoAgent.loadMain(dir.resolve("dif.bin"), 1).botDifficulty - 0.47f) < 1e-6);

        // ---- adaptive hard-start mix
        PvpSim.HardStartMix m = new PvpSim.HardStartMix();
        check("fresh mix: base share, equal weights", m.shareScale() == 1.0 && Math.abs(m.weights()[0] - m.weights()[2]) < 1e-9);
        for (int i = 0; i < 400; i++) { m.report(0, 1.0); m.report(1, i % 2 == 0 ? 1.0 : 0.0); m.report(2, 0.0); }
        double[] w = m.weights();
        check("a kind won ~always and a kind lost ~always get little weight, the 50% kind most (" + String.format("%.2f/%.2f/%.2f", w[0], w[1], w[2]) + ")", w[1] > 2 * w[0] && w[1] > 2 * w[2] && w[0] >= 0.14 && w[2] >= 0.14);
        int[] picks = new int[3]; Random r = new Random(1);
        for (int i = 0; i < 6000; i++) picks[m.pickKind(r)]++;
        check("picks follow the weights but never starve a kind", picks[1] > picks[0] && picks[1] > picks[2] && picks[0] > 200 && picks[2] > 200);
        PvpSim.HardStartMix easy = new PvpSim.HardStartMix();
        for (int i = 0; i < 600; i++) for (int k = 0; k < 3; k++) easy.report(k, 1.0);
        check("everything mastered -> share tapers to ~x0.5 (" + String.format("%.2f", easy.shareScale()) + ")", easy.shareScale() < 0.6 && easy.shareScale() >= 0.5 - 1e-9);

        // ---- randomized physics (nominal outside normal training)
        PpoAgent ag = new PpoAgent(5);
        PvpSim sim = new PvpSim(7, ag);
        sim.rollPhysics(3);
        check("stage < 6: nominal physics", sim.reachJitter == 0.0 && sim.kbScale == 1.0);
        double minR = 9, maxR = -9, minK = 9, maxK = -9; int rolled = 0;
        for (int i = 0; i < 2000; i++) { sim.rollPhysics(7); minR = Math.min(minR, sim.reachJitter); maxR = Math.max(maxR, sim.reachJitter); minK = Math.min(minK, sim.kbScale); maxK = Math.max(maxK, sim.kbScale); rolled++; }
        check("stage 7 training: reach within +-" + PvpSim.RAND_REACH + ", knockback within +-" + PvpSim.RAND_KB + " and actually varying",
            minR >= -PvpSim.RAND_REACH - 1e-9 && maxR <= PvpSim.RAND_REACH + 1e-9 && maxR - minR > 0.2 && minK >= 1 - PvpSim.RAND_KB - 1e-9 && maxK <= 1 + PvpSim.RAND_KB + 1e-9 && maxK - minK > 0.3);
        sim.evalDifficulty = 0.5;
        sim.rollPhysics(7);
        check("evaluation: nominal physics", sim.reachJitter == 0.0 && sim.kbScale == 1.0);
        sim.evalDifficulty = null; sim.opponentKey = "x";
        sim.rollPhysics(7);
        check("cross-play: nominal physics", sim.reachJitter == 0.0 && sim.kbScale == 1.0);

        // ---- exploiter recipes
        int[] seen = new int[3];
        ParallelPvpTrain.Exploiters ex = ParallelPvpTrain.Exploiters.fromProperties(11);
        for (int i = 0; i < 9; i++) seen[ex.variantOf(i)]++;
        check("exploiter phases cycle evenly through the three recipes", seen[0] == 3 && seen[1] == 3 && seen[2] == 3);
        double meanLen = (ParallelPvpTrain.Exploiters.V_LEN[0] + ParallelPvpTrain.Exploiters.V_LEN[1] + ParallelPvpTrain.Exploiters.V_LEN[2]) / 3;
        check("mean recipe length is 1.0 so the phase share is unchanged", Math.abs(meanLen - 1.0) < 1e-9);

        // ---- ensemble
        PpoAgent e = new PpoAgent(9);
        check("fresh agent: ensemble present but not ready, planner silent", e.consequencesEnsembleMembers() == ConsequenceModel.ENSEMBLE && !e.consequencesEnsembleReady());
        float[] obs = new float[Config.OBS_SIZE], next = new float[Config.OBS_SIZE], act = new float[PpoAgent.N_ACT];
        Random rr = new Random(2);
        for (int i = 0; i < 70000; i++) {
            for (int k = 0; k < obs.length; k++) obs[k] = (float) (rr.nextDouble() * 0.6);
            obs[0] = 0.5f + (float) rr.nextDouble() * 0.5f; obs[15] = 0.5f + (float) rr.nextDouble() * 0.5f;
            act[4] = rr.nextBoolean() ? 1f : 0f; act[2] = rr.nextInt(3); act[3] = rr.nextInt(3);
            System.arraycopy(obs, 0, next, 0, obs.length);
            if (act[4] > 0.5f && rr.nextDouble() < 0.5) next[15] = Math.max(0f, obs[15] - 0.15f);   // swings land half the time: enemy health drops
            e.feedConsequence(obs, act, next);
        }
        System.out.println("  " + e.consequencesEnsembleStatus());
        check("after 70k transitions every member validates and the ensemble is ready", e.consequencesEnsembleReady());
        int changed = 0; boolean camMoved = false;
        for (int i = 0; i < 300; i++) {
            for (int k = 0; k < obs.length; k++) obs[k] = (float) (rr.nextDouble() * 0.6);
            obs[0] = 0.9f; obs[15] = 0.9f; obs[6] = 1f; obs[12] = 0.3f;
            float[] base = new float[PpoAgent.N_ACT]; base[4] = 0f;
            float[] before = base.clone();
            if (e.planEnsembleForTest(obs, base)) changed++;
            if (base[0] != before[0] || base[1] != before[1]) camMoved = true;
        }
        check("the planner never touches the camera command", !camMoved);
        check("planner ran and (with swings clearly paying) changed some actions", e.planTicks == 300 && changed > 0);
        // ---- trailer round trip + old-format compat
        e.save(dir.resolve("ens.bin"));
        PpoAgent back = PpoAgent.loadMain(dir.resolve("ens.bin"), 1);
        check("ensemble members survive save/load and stay ready", back.consequencesEnsembleReady());
        PpoAgent plain = new PpoAgent(10);
        plain.save(dir.resolve("fresh.bin"));
        check("a checkpoint with an untrained ensemble loads and the planner stays off", !PpoAgent.loadMain(dir.resolve("fresh.bin"), 1).consequencesEnsembleReady());
        System.out.println(fails == 0 ? "ALL OK" : fails + " FAILED");
        if (fails > 0) System.exit(1);
    }
}
