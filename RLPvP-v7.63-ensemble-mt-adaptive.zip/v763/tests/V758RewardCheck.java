package com.rlpvp;

/** v7.58: facing, pitch, spacing and orbit rewards pay in stages 1-4 only; the rest of the reward is untouched. */
public final class V758RewardCheck {
    static int fails = 0;
    static void check(String n, boolean ok) { System.out.printf("%-96s %s%n", n, ok ? "ok" : "FAIL"); if (!ok) fails++; }
    static double dense(int stage, double yawErr) {
        Curriculum.Weights w = Curriculum.weightsFor(stage);
        Reward.Breakdown b = new Reward.Breakdown();
        Reward.tick(0f, 0f, 3.0, 3.0, yawErr, 0.0, 1.0, 1.0, w, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, b);
        return b.facing + b.pitch + b.spacing;
    }
    public static void main(String[] a) {
        for (int s = 1; s < Config.DENSE_OFF_STAGE; s++) check("stage " + s + ": looking at the opponent still pays (bootstrap)", dense(s, 0.0) > 0.0 || s == 1 && dense(s, 0.0) > 0.0);
        for (int s = Config.DENSE_OFF_STAGE; s <= Curriculum.STAGES; s++) {
            check("stage " + s + ": facing/pitch/spacing pay nothing", dense(s, 0.0) == 0.0);
            check("stage " + s + ": orbit weight is zero", Curriculum.weightsFor(s).orbit == 0f && Curriculum.weightsFor(s).facing == 0f);
        }
        check("stage 5 keeps the original time/tech/late weights", Curriculum.weightsFor(7).time == 2f && Curriculum.weightsFor(7).hpAdv == 1f && Curriculum.weightsFor(7).tech == 1f);
        System.out.println(fails == 0 ? "V758RewardCheck: all ok" : "V758RewardCheck: " + fails + " FAILED");
        if (fails != 0) System.exit(1);
    }
}
