package com.rlpvp;

import java.nio.file.Files;
import java.nio.file.Path;

/** v7.57: the AimBrake strength travels inside the checkpoint (trailer BRK1). */
public final class BrakeTrailerCheck {
    static int fails = 0;
    static void check(String n, boolean ok) { System.out.printf("%-96s %s%n", n, ok ? "ok" : "FAIL"); if (!ok) fails++; }

    public static void main(String[] a) throws Exception {
        Path dir = Files.createTempDirectory("brk");
        Path f = dir.resolve("a.bin");
        PpoAgent agent = new PpoAgent(3);
        agent.totalTicks = 12345;
        GameplayRotation.brakeStrength = 0.62f;
        agent.save(f);
        GameplayRotation.brakeStrength = 1f;

        PpoAgent plain = PpoAgent.load(f, 1);
        check("load() reads the strength but changes nothing global", Math.abs(plain.savedBrakeStrength - 0.62f) < 1e-6 && GameplayRotation.brakeStrength == 1f);
        check("the rest of the checkpoint is intact (ticks " + plain.totalTicks + ")", plain.totalTicks == 12345);

        PpoAgent main = PpoAgent.loadMain(f, 1);
        check("loadMain() applies it to the camera controller", Math.abs(GameplayRotation.brakeStrength - 0.62f) < 1e-6 && main.savedBrakeStrength > 0.6f);

        GameplayRotation.brakeStrength = 1f;
        System.setProperty("rlpvp.brakeStrength", "0.9");
        PpoAgent forced = PpoAgent.loadMain(f, 1);
        check("an explicit -Drlpvp.brakeStrength wins over the checkpoint", GameplayRotation.brakeStrength == 1f && forced.savedBrakeStrength > 0.6f);
        System.clearProperty("rlpvp.brakeStrength");

        // a save from before v7.57 has no trailer: drop the last 12 bytes (tag + length + float)
        byte[] all = Files.readAllBytes(f);
        Path old = dir.resolve("old.bin");
        Files.write(old, java.util.Arrays.copyOf(all, all.length - 12));
        PpoAgent o = PpoAgent.load(old, 1);
        check("a checkpoint without the trailer loads, strength unknown (NaN), nothing applied", Float.isNaN(o.savedBrakeStrength) && o.totalTicks == 12345);
        GameplayRotation.brakeStrength = 0.7f;
        PpoAgent.loadMain(old, 1);
        check("... and loadMain leaves the current strength alone", GameplayRotation.brakeStrength == 0.7f);

        // a trailer from a newer build that this build does not know must not break loading
        Path future = dir.resolve("future.bin");
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        bo.write(all, 0, all.length - 12);
        java.io.DataOutputStream d = new java.io.DataOutputStream(bo);
        d.writeInt(0x46555431); d.writeInt(0);   // "FUT1", empty
        Files.write(future, bo.toByteArray());
        check("an unknown trailing tag ends the scan without an error", Float.isNaN(PpoAgent.load(future, 1).savedBrakeStrength));

        // round trip at full strength
        GameplayRotation.brakeStrength = 1f;
        agent.save(f);
        check("saving at the default strength stores 1.0", PpoAgent.load(f, 1).savedBrakeStrength == 1f);
        System.out.println(fails == 0 ? "BrakeTrailerCheck: all ok" : "BrakeTrailerCheck: " + fails + " FAILED");
        if (fails != 0) System.exit(1);
    }
}
