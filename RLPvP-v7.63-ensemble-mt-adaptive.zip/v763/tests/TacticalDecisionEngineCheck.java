package com.rlpvp;

import java.util.Random;

/** v7.46: the tactical engine must LEARN which choices pay off from health-swing outcomes, never force them, and stay bounded. */
public final class TacticalDecisionEngineCheck {
    static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); System.out.println("PASS " + msg); }

    static SituationalStateInterpreter.State state(float own, float enemy) {
        SituationalStateInterpreter.State s = new SituationalStateInterpreter.State();
        s.ownHealth = own; s.enemyHealth = enemy; s.distance = 2.2f; s.ownCharge = 1f; s.lineOfSight = 1f;
        s.attackOpportunity = true; return s;
    }

    public static void main(String[] args) {
        TacticalDecisionEngine fresh = new TacticalDecisionEngine();
        TacticalDecisionEngine.Decision d = new TacticalDecisionEngine.Decision(TacticalDecisionEngine.Intent.DEFEND, 0.8, new double[8]);
        check(fresh.advise(state(1f, 1f), d, 2) < 0, "fresh engine has no opinion on attack under DEFEND (no hard-coded command)");

        // Environment: swinging (attack=1) costs the enemy health a bit later; not swinging slowly costs us health.
        TacticalDecisionEngine e = new TacticalDecisionEngine();
        Random rng = new Random(7);
        float own = 1f, enemy = 1f;
        for (int t = 0; t < 20000; t++) {
            if (own < 0.15f || enemy < 0.15f) { own = enemy = 1f; e.beginEpisode(); }
            SituationalStateInterpreter.State s = state(own, enemy);
            e.observe(s);
            float[] a = new float[8];
            a[2] = 1f; a[3] = 1f; a[4] = rng.nextBoolean() ? 1f : 0f;
            e.record(s, TacticalDecisionEngine.Intent.DEFEND, a);
            if (a[4] > 0.5f) enemy -= 0.06f; else own -= 0.02f;
        }
        SituationalStateInterpreter.State probe = state(0.8f, 0.8f);
        check(e.advise(probe, d, 2) == 1, "engine learns from outcomes that attacking pays off in this situation");
        double p = e.applyProbability(d, 2), pFresh = fresh.applyProbability(d, 2);
        check(p > pFresh, "apply probability grows with learned evidence (" + pFresh + " -> " + p + ")");
        check(p <= 0.60 + 1e-9, "advice never exceeds the 60% application cap (" + p + ")");
        double v = e.actionValue(probe, d, new float[]{0, 0, 1, 1, 1, 0, 0, 0});
        double w = e.actionValue(probe, d, new float[]{0, 0, 1, 1, 0, 0, 0, 0});
        check(Double.isFinite(v) && Double.isFinite(w) && v > w, "learned action value ranks the paying choice higher (" + v + " > " + w + ")");
        check(e.learnedSamples() > 1000 && e.summary().contains("tactics:"), "diagnostic summary reports learned samples");

        // persistence: learned weights survive a write/read, a mismatched block is ignored, and a stack block without the trailer still loads
        try {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            try (java.io.DataOutputStream out = new java.io.DataOutputStream(bo)) { e.write(out); }
            TacticalDecisionEngine restored = new TacticalDecisionEngine();
            restored.read(new java.io.DataInputStream(new java.io.ByteArrayInputStream(bo.toByteArray())));
            check(restored.advise(probe, d, 2) == 1 && restored.learnedSamples() == e.learnedSamples(), "learned tactical weights round-trip through write/read");
            byte[] bad = bo.toByteArray().clone(); bad[3] ^= 0x55;
            TacticalDecisionEngine fresh2 = new TacticalDecisionEngine();
            fresh2.read(new java.io.DataInputStream(new java.io.ByteArrayInputStream(bad)));
            check(fresh2.learnedSamples() == 0, "a block with a different layout is ignored (engine stays fresh)");
        } catch (java.io.IOException ex) { throw new AssertionError(ex); }
    }
}
