package com.rlpvp;

import java.io.DataOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Random;

/** Ensures an original 126-input or a v7.38-v7.51 128-input compact checkpoint retains its policy when widened to the current 133-input layout (new columns start at zero). */
public final class Compact126CheckpointMigrationCheck {
    private static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }

    public static void main(String[] args) throws Exception {
        check("target runtime is 133-input compact mode", Config.COMPACT_126 && Config.OBS_SIZE == 133);
        run(126, args);
        run(128, new String[0]);
    }

    private static void run(int srcObs, String[] args) throws Exception {
        int[] actorShape = new int[Config.HIDDEN.length + 2];
        int[] criticShape = new int[Config.HIDDEN.length + 2];
        actorShape[0] = criticShape[0] = srcObs;
        System.arraycopy(Config.HIDDEN, 0, actorShape, 1, Config.HIDDEN.length);
        System.arraycopy(Config.HIDDEN, 0, criticShape, 1, Config.HIDDEN.length);
        actorShape[actorShape.length - 1] = Config.ACTION_SIZE;
        criticShape[criticShape.length - 1] = 1;

        Net oldActor = new Net(actorShape, 0.01f, new Random(11));
        Net oldCritic = new Net(criticShape, 1.0f, new Random(12));
        // Set distinct known weights for the final old feature and leave the new two columns absent.
        oldActor.w[srcObs - 1] = 0.375f;
        Path checkpoint = Files.createTempFile("rlpvp-compact126-", ".bin");
        try {
            try (DataOutputStream out = new DataOutputStream(Files.newOutputStream(checkpoint))) {
                out.writeInt(0x524C5050); // RLPP
                out.writeInt(4);          // old checkpoint format: weights, no optional trailers
                out.writeInt(oldActor.w.length);
                out.writeInt(oldCritic.w.length);
                out.writeLong(12345L);
                out.writeInt(7);
                out.writeInt(5);
                out.writeLong(10000L);
                oldActor.write(out);
                oldCritic.write(out);
            }
            PpoAgent loaded = PpoAgent.load(checkpoint, 99L);
            check(srcObs + "-input checkpoint: final old input column is preserved", Math.abs(loaded.actor.w[srcObs - 1] - 0.375f) < 1e-7f);
            boolean zero = true;
            for (int i = srcObs; i < Config.OBS_SIZE; i++) zero &= loaded.actor.w[i] == 0f;
            check(srcObs + "-input checkpoint: every newer input column (" + srcObs + ".." + (Config.OBS_SIZE - 1) + ") starts at zero", zero);
            check(srcObs + "-input checkpoint: widened actor has " + Config.OBS_SIZE + " inputs", loaded.actor.sizes[0] == Config.OBS_SIZE);
            check("old compact checkpoint ticks and curriculum stage are retained",
                loaded.totalTicks == 12345L && loaded.stage == 5 && loaded.stageEnterTicks == 10000L);
        } finally {
            Files.deleteIfExists(checkpoint);
        }
        if (args.length > 0) {
            PpoAgent realCheckpoint = PpoAgent.load(Path.of(args[0]), 100L);
            check("real prior compact checkpoint migrates through its full current-format trailers",
                realCheckpoint.actor.sizes[0] == Config.OBS_SIZE && realCheckpoint.totalTicks > 0);
            check("real checkpoint zero-initializes the newer input columns",
                realCheckpoint.actor.w[Config.OBS_SIZE - 1] == 0f && realCheckpoint.actor.w[Config.OBS_SIZE - 5] == 0f);
        }
    }
}
