package com.rlpvp;

/**
 * Adaptive opponent strength 0..1 for BotAI. Raised when the agent beats the scripted fighters, lowered when it is crushed, so the
 * opponent keeps pace with the agent instead of being either a wall (stage 7 used to stall) or a pushover that a single habit beats.
 * Only scripted-fighter episodes are reported (never frozen self-play snapshots). Minecraft-free; not saved (it re-adapts within ~100 episodes).
 */
final class BotDifficulty {
    // v7.57: faster and tunable. Before: start 0.0, 12 episodes per decision, steps of 0.05 (about 0.4 per 100 episodes at best); now 8 episodes, steps of 0.08, start 0.20.
    // -Drlpvp.botDiff.start / .window / .step / .raise / .lower   (window 12, step 0.05, start 0 and raise 0.65 give the old behaviour)
    static final double START = prop("start", 0.20), MIN = 0.0, MAX = 1.0, STEP = prop("step", 0.08);
    static final int WINDOW = Math.max(2, (int) prop("window", 8));
    static final double RAISE_ABOVE = prop("raise", 0.65), LOWER_BELOW = prop("lower", 0.35);
    private static double prop(String k, double dflt) { return Double.parseDouble(System.getProperty("rlpvp.botDiff." + k, Double.toString(dflt))); }

    private double d = START;
    private int n, wins;

    double value() {
        return d;
    }

    void set(double v) {
        d = Math.max(MIN, Math.min(MAX, v));
    }

    void report(boolean agentWon) {
        n++;
        if (agentWon) wins++;
        if (n < WINDOW) return;
        double wr = wins / (double) n;
        if (wr > RAISE_ABOVE) d = Math.min(MAX, d + STEP);
        else if (wr < LOWER_BELOW) d = Math.max(MIN, d - STEP);
        n = wins = 0;
    }
}
