package com.rlpvp;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Random;

/**
 * High-level combat intent selection and soft action advice.
 *
 * v7.46: the engine no longer ships fixed "if distance > X then press W" rules as the thing that decides. Its old hand-written
 * scores survive only as a PRIOR that every intent / action choice starts from; as real outcomes arrive the prior is blended out in
 * favour of two small online models that learn from what actually happened in this run:
 *
 *  - an intent-value model: expected health swing over the next HORIZON ticks given the intent that was active and the situation;
 *  - a per-head action-value model (forward/back, strafe, attack, jump, sprint): expected health swing over the next HORIZON ticks
 *    for each discrete choice given the situation, regardless of what the engine "thought" was right.
 *
 * Health swing = (own health change) - (enemy health change), so it is the same outcome signal PPO already trains on, with no
 * technique bonuses and no named-move rewards. Advice is never a command: {@link #advise} returns a suggested choice only when
 * the learned (or prior) preference is clear, and the caller applies it stochastically with a probability that is capped well below 1,
 * so the policy remains the primary decision maker. The same machinery produces agreement / idle-opportunity diagnostics that make
 * wiring bugs (a masked head, a dead attack path, a policy ignoring clear openings) visible during learning and evaluation.
 */
final class TacticalDecisionEngine {
    enum Intent { ENGAGE, PURSUE, PUNISH, DEFEND, REPOSITION, COMBO_FOLLOWUP, BAIT, DISENGAGE }

    static final class Decision {
        final Intent intent;
        final double confidence;
        final double[] scores;
        Decision(Intent intent, double confidence, double[] scores) { this.intent = intent; this.confidence = confidence; this.scores = scores; }
        double score(Intent i) { return scores[i.ordinal()]; }
    }

    /** Action-vector slots of the discrete heads this engine can advise on: fwd, strafe, attack, jump, sprint. */
    static final int[] HEAD_SLOT = {2, 3, 4, 5, 6};
    static final int[] HEAD_CHOICES = {3, 3, 2, 2, 2};
    static final int HEADS = HEAD_SLOT.length;
    static final String[] HEAD_NAME = {"fwd", "strafe", "attack", "jump", "sprint"};

    private static final int F = 16;                 // features (14 situation values + 2 learned forecasts)
    private static final int HORIZON = 20;           // ticks an outcome is observed for (1 s)
    private static final double INTENT_TRUST_SAMPLES = 200.0;
    private static final double HEAD_TRUST_SAMPLES = 400.0;
    private static final double MAX_LEARNED_WEIGHT = 0.90;
    private static final double MAX_APPLY_PROBABILITY = 0.60;   // advice never takes over from the policy

    private final int nIntents = Intent.values().length;
    private final double[][] intentW = new double[nIntents][F];
    private final long[] intentN = new long[nIntents];
    private final double[][][] headW = new double[HEADS][][];
    private final long[][] headN = new long[HEADS][];
    private double baseline;                          // EMA of health swing, so weights learn advantage rather than raw outcome
    private final Random noise = new Random(0x7AC71C5L);

    private static final class Pending {
        final double[] phi; final int intent; final int[] choice = new int[HEADS];
        final float own, enemy; int age;
        Pending(double[] phi, int intent, float own, float enemy) { this.phi = phi; this.intent = intent; this.own = own; this.enemy = enemy; }
    }
    private final ArrayDeque<Pending> pending = new ArrayDeque<>();

    // ---- diagnostics (evaluation / bug-hunting) ----
    private long diagTicks, diagAdvised, diagAgreed, diagOpenings, diagIgnoredOpenings, diagMaxIgnoredRun, diagRun;
    private final long[] diagHeadAdvised = new long[HEADS], diagHeadAgreed = new long[HEADS];

    TacticalDecisionEngine() {
        for (int h = 0; h < HEADS; h++) { headW[h] = new double[HEAD_CHOICES[h]][F]; headN[h] = new long[HEAD_CHOICES[h]]; }
    }

    /** New episode: pending outcomes belong to the previous fight and are dropped; learned weights are kept. */
    void beginEpisode() { pending.clear(); diagRun = 0; }

    // ------------------------------------------------------------------ features
    // Learned forecasts from the auxiliary heads (AuxForecaster). Both are 0 until the heads have proven they beat the base rate.
    private double forecastRisk, forecastSwing;

    /** Called every tick by the stack: probability of taking damage within 10 ticks and the expected 20-tick health swing (-1..1). */
    void setForecast(boolean trusted, double riskTaken10, double swing20) {
        forecastRisk = trusted ? Math.max(0.0, Math.min(1.0, riskTaken10)) : 0.0;
        forecastSwing = trusted ? Math.max(-1.0, Math.min(1.0, swing20)) : 0.0;
    }

    private double[] features(SituationalStateInterpreter.State s) {
        double[] f = new double[F];
        f[0] = 1.0;
        f[1] = Math.min(1.5, s.distance / 6.0);
        f[2] = s.ownHealth; f[3] = s.enemyHealth; f[4] = s.ownHealth - s.enemyHealth;
        f[5] = s.ownCharge; f[6] = s.enemyCharge; f[7] = s.ownHurt; f[8] = s.enemyHurt;
        f[9] = s.incomingThreat ? 1.0 : 0.0; f[10] = s.opponentRecovering ? 1.0 : 0.0;
        f[11] = s.followupWindow ? 1.0 : 0.0; f[12] = s.lineOfSight; f[13] = s.boundaryProximity;
        f[14] = forecastRisk; f[15] = forecastSwing;
        return f;
    }

    private static double dot(double[] w, double[] x) { double r = 0; for (int i = 0; i < F; i++) r += w[i] * x[i]; return r; }

    /** Normalised-LMS step on one linear model: stable for any feature scale, weights clamped so a bad streak cannot blow up. */
    private static void update(double[] w, double[] x, double target, long n) {
        double err = target - dot(w, x);
        double norm = 1.0; for (int i = 0; i < F; i++) norm += x[i] * x[i];
        double lr = 0.6 / Math.sqrt(1.0 + n / 150.0);
        for (int i = 0; i < F; i++) w[i] = Math.max(-4.0, Math.min(4.0, w[i] + lr * err * x[i] / norm));
    }

    // ------------------------------------------------------------------ learning from outcomes
    /** Call once per tick BEFORE choose(): ages pending decisions and learns from those whose horizon has elapsed. */
    void observe(SituationalStateInterpreter.State now) {
        if (now == null) return;
        for (Pending p : pending) p.age++;
        while (!pending.isEmpty() && pending.peekFirst().age >= HORIZON) {
            Pending p = pending.pollFirst();
            double swing = 4.0 * ((now.ownHealth - p.own) - (now.enemyHealth - p.enemy));
            swing = Math.max(-4.0, Math.min(4.0, swing));
            baseline += 0.002 * (swing - baseline);
            double adv = swing - baseline;
            update(intentW[p.intent], p.phi, adv, intentN[p.intent]); intentN[p.intent]++;
            for (int h = 0; h < HEADS; h++) {
                int c = p.choice[h];
                update(headW[h][c], p.phi, adv, headN[h][c]); headN[h][c]++;
            }
        }
    }

    /** Call once per tick AFTER the final action is known: stores the situation, intent and the choices actually made. */
    void record(SituationalStateInterpreter.State s, Intent intent, float[] action) {
        if (s == null || intent == null || action == null || action.length <= HEAD_SLOT[HEADS - 1]) return;
        Pending p = new Pending(features(s), intent.ordinal(), s.ownHealth, s.enemyHealth);
        for (int h = 0; h < HEADS; h++) p.choice[h] = Math.max(0, Math.min(HEAD_CHOICES[h] - 1, Math.round(action[HEAD_SLOT[h]])));
        pending.addLast(p);
        while (pending.size() > HORIZON + 2) pending.pollFirst();
        diagTicks++;
        // Opening ignored: a clear, ready attack chance while the policy did not swing. Long runs usually mean a wiring or masking bug.
        boolean opening = s.attackOpportunity && s.weaponReady() && s.aimedEnough();
        if (opening) {
            diagOpenings++;
            if (p.choice[2] == 0) { diagIgnoredOpenings++; diagRun++; diagMaxIgnoredRun = Math.max(diagMaxIgnoredRun, diagRun); }
            else diagRun = 0;
        } else diagRun = 0;
    }

    // ------------------------------------------------------------------ intent selection
    Decision choose(SituationalStateInterpreter.State s, OpponentBehaviorModel.Profile p,
                    EventDrivenCombatMemory.Snapshot memory, double predictedThreat) {
        double[] prior = priorScores(s, p, predictedThreat);
        double[] phi = features(s);
        double[] v = new double[prior.length];
        for (int i = 0; i < v.length; i++) {
            double lw = Math.min(MAX_LEARNED_WEIGHT, intentN[i] / (intentN[i] + INTENT_TRUST_SAMPLES));
            double learned = 0.5 + 0.5 * Math.tanh(dot(intentW[i], phi));
            double jitter = lw > 0 ? noise.nextGaussian() * 0.04 / Math.sqrt(1.0 + intentN[i] / 100.0) : 0.0;
            v[i] = (1.0 - lw) * prior[i] + lw * learned + jitter;
        }
        double confidence = p.confidence();
        boolean urgentThreat = s.incomingThreat || predictedThreat > 0.58;
        int best = 0; double bestV = -Double.MAX_VALUE, second = -Double.MAX_VALUE;
        for (int i = 0; i < v.length; i++) {
            if (v[i] > bestV) { second = bestV; bestV = v[i]; best = i; }
            else if (v[i] > second) second = v[i];
        }
        double margin = bestV - Math.max(0.0, second);
        double certainty = Math.max(0.0, Math.min(1.0, 0.45 * margin + 0.45 * (urgentThreat || s.followupWindow || s.opponentRecovering ? 1.0 : confidence)));
        return new Decision(Intent.values()[best], certainty, v);
    }

    /** The original hand-written estimates. Now only the starting point that learned values replace as evidence accumulates. */
    private static double[] priorScores(SituationalStateInterpreter.State s, OpponentBehaviorModel.Profile p, double predictedThreat) {
        double[] v = new double[Intent.values().length];
        double confidence = p.confidence();
        boolean far = s.distance > 3.0;
        boolean close = s.distance < 2.0;
        boolean clearAim = s.aimedEnough();
        boolean urgentThreat = s.incomingThreat || predictedThreat > 0.58;

        v[Intent.ENGAGE.ordinal()] = far ? 0.45 + Math.min(0.25, (s.distance - 3.0) * 0.08) : 0.18;
        v[Intent.PURSUE.ordinal()] = far ? 0.48 + p.retreatRate * 0.20 * confidence : 0.05;
        v[Intent.PUNISH.ordinal()] = (s.opponentRecovering && s.ownCharge > 0.55f && s.distance < 4.2f ? 0.66 : 0.0)
            + (s.attackOpportunity ? 0.20 : 0.0);
        v[Intent.DEFEND.ordinal()] = urgentThreat ? 0.50 + (s.meInEnemyReach > 0.5f ? 0.24 : 0.0) : 0.08;
        v[Intent.REPOSITION.ordinal()] = (!clearAim ? 0.30 : 0.0) + (s.lineOfSight < 0.5f ? 0.38 : 0.0)
            + (close ? 0.18 : 0.0) + (Math.abs(s.enemySideVelocity) > 0.2f ? 0.10 : 0.0);
        v[Intent.COMBO_FOLLOWUP.ordinal()] = s.followupWindow ? 0.64 + (s.distance < 3.8f ? 0.14 : 0.0) : 0.0;
        v[Intent.BAIT.ordinal()] = (!urgentThreat && !s.opponentRecovering && s.distance >= 2.4f && s.distance <= 4.0f
            && p.attackRate < 0.10 && confidence > 0.30 ? 0.35 + confidence * 0.10 : 0.0);
        v[Intent.DISENGAGE.ordinal()] = (s.lowHealthDisadvantage && s.ownHealth < 0.45f ? 0.70 : 0.0)
            + (s.ownHurt > 0.65f && s.distance < 2.4f ? 0.28 : 0.0)
            + (s.boundaryProximity > 0.8f ? 0.10 : 0.0);
        if (urgentThreat && s.ownHurt > 0.55f && s.ownCharge < 0.5f) v[Intent.DEFEND.ordinal()] += 0.14;
        if (s.followupWindow && !urgentThreat) v[Intent.COMBO_FOLLOWUP.ordinal()] += 0.08;
        if (s.boundaryProximity > 0.78f) v[Intent.REPOSITION.ordinal()] += 0.12;
        return v;
    }

    // ------------------------------------------------------------------ soft action advice
    /** Soft prior preference in [-0.3, 0.3] for one head choice under an intent. Faded out by learned values. */
    private static double priorPreference(SituationalStateInterpreter.State s, Intent intent, int head, int c) {
        switch (head) {
            case 0: { // forward / neutral / back (choice 2 = forward)
                int dir = c - 1;
                switch (intent) {
                    case PURSUE: case ENGAGE: return s.distance > 2.8f ? 0.25 * dir : 0.0;
                    case PUNISH: case COMBO_FOLLOWUP: return s.distance > 1.7f ? 0.25 * dir : 0.0;
                    case DEFEND: return s.distance < 2.9f ? -0.15 * dir : 0.0;
                    case DISENGAGE: return s.distance < 3.4f ? -0.25 * dir : 0.0;
                    case BAIT: return s.distance > 2.3f ? 0.10 * dir : 0.0;
                    default: return 0.0;
                }
            }
            case 1: return (intent == Intent.DEFEND || intent == Intent.REPOSITION) && c != 1 ? 0.15 : 0.0;
            case 2: { // attack
                if (c == 0) return 0.0;
                boolean ok = s.attackOpportunity && s.ownCharge >= Config.MIN_ATTACK_STRENGTH_LATE;
                if (intent == Intent.PUNISH || intent == Intent.COMBO_FOLLOWUP) return ok ? 0.30 : -0.10;
                if (intent == Intent.DEFEND || intent == Intent.BAIT) return s.attackOpportunity ? 0.0 : -0.15;
                return ok ? 0.10 : -0.05;
            }
            case 4: return c == 1 && s.distance > 2.8f && (intent == Intent.PURSUE || intent == Intent.ENGAGE || intent == Intent.PUNISH) ? 0.15 : 0.0;
            default: return 0.0;
        }
    }

    /** Blended (prior + learned) value of one head choice in this situation, roughly in health-swing units. */
    private double choiceValue(SituationalStateInterpreter.State s, Intent intent, double[] phi, int head, int c) {
        long n = headN[head][c];
        double lw = Math.min(MAX_LEARNED_WEIGHT, n / (n + HEAD_TRUST_SAMPLES));
        return (1.0 - lw) * priorPreference(s, intent, head, c) + lw * 0.5 * Math.tanh(dot(headW[head][c], phi));
    }

    /**
     * Suggests a choice for one discrete head, or -1 for "no clear advice". The caller decides whether to apply it using
     * {@link #applyProbability}; this method itself never edits an action.
     */
    int advise(SituationalStateInterpreter.State s, Decision d, int head) {
        if (s == null || d == null) return -1;
        double[] phi = features(s);
        int best = -1; double bestV = -Double.MAX_VALUE, second = -Double.MAX_VALUE;
        for (int c = 0; c < HEAD_CHOICES[head]; c++) {
            double q = choiceValue(s, d.intent, phi, head, c);
            if (q > bestV) { second = bestV; bestV = q; best = c; } else if (q > second) second = q;
        }
        return bestV - second >= 0.04 ? best : -1;
    }

    /** Probability that advice for a head is applied: grows with how much has been learned about that head, never above 0.60. */
    double applyProbability(Decision d, int head) {
        long n = 0; for (long x : headN[head]) n += x;
        double lw = Math.min(MAX_LEARNED_WEIGHT, n / (n + HEAD_TRUST_SAMPLES));
        return Math.min(MAX_APPLY_PROBABILITY, (0.20 + 0.45 * lw) * (0.4 + 0.6 * (d == null ? 0.0 : d.confidence)));
    }

    /** Learned value of a full candidate action in this situation (sum over the advisable heads); used as an additive candidate-score term. */
    double actionValue(SituationalStateInterpreter.State s, Decision d, float[] a) {
        if (s == null || d == null || a == null || a.length <= HEAD_SLOT[HEADS - 1]) return 0.0;
        double[] phi = features(s);
        double sum = 0.0;
        for (int h = 0; h < HEADS; h++) {
            int c = Math.max(0, Math.min(HEAD_CHOICES[h] - 1, Math.round(a[HEAD_SLOT[h]])));
            long n = headN[h][c];
            double lw = Math.min(MAX_LEARNED_WEIGHT, n / (n + HEAD_TRUST_SAMPLES));
            sum += lw * 0.5 * Math.tanh(dot(headW[h][c], phi));   // learned part only: no hand-written prior leaks into scoring
        }
        return sum;
    }

    /** Evaluation hook: did the final action follow the engine's advice? Pure bookkeeping, never changes behaviour. */
    void auditAgreement(SituationalStateInterpreter.State s, Decision d, float[] action) {
        if (s == null || d == null || action == null || action.length <= HEAD_SLOT[HEADS - 1]) return;
        for (int h = 0; h < HEADS; h++) {
            int adv = advise(s, d, h);
            if (adv < 0) continue;
            diagAdvised++; diagHeadAdvised[h]++;
            if (Math.round(action[HEAD_SLOT[h]]) == adv) { diagAgreed++; diagHeadAgreed[h]++; }
        }
    }

    // ------------------------------------------------------------------ persistence
    private static final int FORMAT = 1;

    /** Learned weights, sample counts and baseline. Pending outcomes and diagnostics are per-session and are not saved. */
    void write(DataOutput out) throws IOException {
        out.writeInt(FORMAT); out.writeInt(nIntents); out.writeInt(F); out.writeInt(HEADS);
        out.writeDouble(baseline);
        for (int i = 0; i < nIntents; i++) { out.writeLong(intentN[i]); for (int k = 0; k < F; k++) out.writeDouble(intentW[i][k]); }
        for (int h = 0; h < HEADS; h++) {
            out.writeInt(HEAD_CHOICES[h]);
            for (int c = 0; c < HEAD_CHOICES[h]; c++) { out.writeLong(headN[h][c]); for (int k = 0; k < F; k++) out.writeDouble(headW[h][c][k]); }
        }
    }

    /**
     * Loads weights written by {@link #write}. All-or-nothing: if the layout does not match this build (different intents, features
     * or heads) or any value is not finite, the engine keeps its fresh state and the file is simply ignored.
     */
    void read(DataInput in) throws IOException {
        if (in.readInt() != FORMAT || in.readInt() != nIntents || in.readInt() != F || in.readInt() != HEADS) return;
        double base = in.readDouble();
        double[][] iw = new double[nIntents][F]; long[] in_ = new long[nIntents];
        double[][][] hw = new double[HEADS][][]; long[][] hn = new long[HEADS][];
        boolean ok = Double.isFinite(base);
        for (int i = 0; i < nIntents; i++) {
            in_[i] = Math.max(0, in.readLong());
            for (int k = 0; k < F; k++) { iw[i][k] = in.readDouble(); ok &= Double.isFinite(iw[i][k]) && Math.abs(iw[i][k]) <= 4.0 + 1e-9; }
        }
        for (int h = 0; h < HEADS; h++) {
            if (in.readInt() != HEAD_CHOICES[h]) return;
            hw[h] = new double[HEAD_CHOICES[h]][F]; hn[h] = new long[HEAD_CHOICES[h]];
            for (int c = 0; c < HEAD_CHOICES[h]; c++) {
                hn[h][c] = Math.max(0, in.readLong());
                for (int k = 0; k < F; k++) { hw[h][c][k] = in.readDouble(); ok &= Double.isFinite(hw[h][c][k]) && Math.abs(hw[h][c][k]) <= 4.0 + 1e-9; }
            }
        }
        if (!ok) return;
        baseline = base;
        for (int i = 0; i < nIntents; i++) { intentN[i] = in_[i]; System.arraycopy(iw[i], 0, intentW[i], 0, F); }
        for (int h = 0; h < HEADS; h++) for (int c = 0; c < HEAD_CHOICES[h]; c++) { headN[h][c] = hn[h][c]; System.arraycopy(hw[h][c], 0, headW[h][c], 0, F); }
        pending.clear();
    }

    // ------------------------------------------------------------------ reporting
    long learnedSamples() { long n = 0; for (long x : intentN) n += x; return n; }

    String summary() {
        StringBuilder sb = new StringBuilder(String.format(java.util.Locale.ROOT, "tactics: learned samples=%d baseline=%.2f | ", learnedSamples(), baseline));
        double[] ref = new double[F]; ref[0] = 1.0;
        for (int i = 0; i < nIntents; i++)
            sb.append(Intent.values()[i].name().toLowerCase(java.util.Locale.ROOT)).append('=').append(String.format(java.util.Locale.ROOT, "%.2f(n=%d) ", dot(intentW[i], ref), intentN[i]));
        sb.append(String.format(java.util.Locale.ROOT, "| advice agreement %.0f%% (%d), openings ignored %d/%d (longest run %d)",
            diagAdvised == 0 ? 0.0 : 100.0 * diagAgreed / diagAdvised, diagAdvised, diagIgnoredOpenings, diagOpenings, diagMaxIgnoredRun));
        return sb.toString();
    }

    long ignoredOpenings() { return diagIgnoredOpenings; }
    long openings() { return diagOpenings; }
    long longestIgnoredOpeningRun() { return diagMaxIgnoredRun; }
}
