package com.rlpvp;

/**
 * v7.52 threat / timing inputs. Five descriptive values appended to the END of the compact network input (slots 128..132), so no existing
 * input moved and every older checkpoint keeps its columns (the new ones start at zero weights, see PpoAgent.load). Pure Java, shared by
 * Trainer (real client), PvpSim (offline simulator) and BotBrain (self-play bot). Nothing here is rewarded or scripted.
 *
 *   0 ENEMY_CRIT    1 while the ENEMY is falling and not sprinting (same rule as my own frame[43]): a hit from it now is a jump-crit
 *   1 MY_JUMP_AGE   ticks since MY jump left the ground / JUMP_CAP, 1 = no jump in the last JUMP_CAP ticks (a jump lasts about 12 ticks: the punish window)
 *   2 ENEMY_RESET   ticks since the enemy's last sprint reset (sprint dropped, then restarted within RESET_GAP = 4 ticks: a w-tap) / RESET_CAP, 1 = none lately
 *   3 ENEMY_REACH   SIGNED margin: attack reach minus the distance from the enemy's eye to MY hitbox, /1.5 clamped to [-1, 1]
 *                   (positive = I am inside its reach, negative = how far outside). The old frame[45] flag was only the sign of this.
 *   4 PING          measured round-trip time in ms / PING_SCALE_MS, clamped to [0, 1]
 *
 * All five are mirror-invariant (no left/right sign), so Symmetry stays exactly equivariant and needs no change.
 */
final class ThreatObservation {
    static final int FEATURES = 5;
    static final int ENEMY_CRIT = 0, MY_JUMP_AGE = 1, ENEMY_RESET = 2, ENEMY_REACH = 3, PING = 4;

    static final int JUMP_CAP = 20;          // ticks; a jump airs for ~12
    static final int RESET_CAP = 40;         // ticks
    static final int RESET_GAP = 4;          // max ticks the enemy's sprint may stay off for the restart to count as a reset: a w-tap releases forward for 1-3 ticks, a longer drop is just stopping or backing off
    static final double REACH_SCALE = 1.5;   // blocks; same scale as CombatObservationMemory.REACH_MARGIN
    static final double PING_SCALE_MS = 200.0;

    /** What the network sees when no tracker feeds the observation (episode start / tests): nothing recent, no ping. */
    static final float[] NEUTRAL = {0f, 1f, 1f, 0f, 0f};

    private final float[] f = NEUTRAL.clone();
    private int jumpAge = JUMP_CAP, resetAge = RESET_CAP, sprintOffAge = 1 << 20;
    private boolean prevEnemySprint, prevGround = true;

    void reset() {
        System.arraycopy(NEUTRAL, 0, f, 0, FEATURES);
        jumpAge = JUMP_CAP; resetAge = RESET_CAP; sprintOffAge = 1 << 20; prevEnemySprint = false; prevGround = true;
    }

    /**
     * @param frame             this tick's observation frame (4 my ground contact, 18 enemy vertical velocity / 0.8, 19 enemy on ground,
     *                          22 enemy sprinting, 32 my last jump command). My own jump = jump commanded last tick from the ground and
     *                          airborne now, so knockback launches and walking off an edge do not count.
     * @param enemyReachMargin  Config.ATTACK_REACH - distance from the ENEMY's eye to the nearest point of MY hitbox (blocks, signed)
     * @param pingMs            measured round-trip time in ms (0 when unknown / offline)
     */
    void tick(float[] frame, double enemyReachMargin, double pingMs) {
        boolean enemyAir = frame[19] < 0.5f, enemyFalling = frame[18] < 0f, enemySprint = frame[22] > 0.5f;
        f[ENEMY_CRIT] = enemyAir && enemyFalling && !enemySprint ? 1f : 0f;

        boolean ground = frame[4] > 0.5f;
        boolean selfJump = frame[32] > 0.5f && prevGround && !ground;
        prevGround = ground;
        jumpAge = selfJump ? 0 : Math.min(JUMP_CAP, jumpAge + 1);
        f[MY_JUMP_AGE] = jumpAge / (float) JUMP_CAP;

        if (prevEnemySprint && !enemySprint) sprintOffAge = 0;
        else sprintOffAge = Math.min(1 << 20, sprintOffAge + 1);
        if (!prevEnemySprint && enemySprint && sprintOffAge <= RESET_GAP) resetAge = 0;   // sprint dropped and came straight back: a w-tap / sprint reset
        else resetAge = Math.min(RESET_CAP, resetAge + 1);
        prevEnemySprint = enemySprint;
        f[ENEMY_RESET] = resetAge / (float) RESET_CAP;

        f[ENEMY_REACH] = clamp(enemyReachMargin / REACH_SCALE, -1.0, 1.0);
        f[PING] = clamp(pingMs / PING_SCALE_MS, 0.0, 1.0);
    }


    private static volatile java.lang.reflect.Method mConn, mInfo, mLatency;

    /**
     * Round-trip time in ms the client currently shows for {@code playerId} (the tab-list ping; 0 if unknown, offline or on any failure).
     * Looked up reflectively so this class stays free of Minecraft types: Minecraft.getConnection().getPlayerInfo(uuid).getLatency().
     */
    static double measuredPingMs(Object minecraft, java.util.UUID playerId) {
        if (minecraft == null || playerId == null) return 0.0;
        try {
            if (mConn == null) mConn = minecraft.getClass().getMethod("getConnection");
            Object conn = mConn.invoke(minecraft);
            if (conn == null) return 0.0;
            if (mInfo == null) mInfo = conn.getClass().getMethod("getPlayerInfo", java.util.UUID.class);
            Object info = mInfo.invoke(conn, playerId);
            if (info == null) return 0.0;
            if (mLatency == null) mLatency = info.getClass().getMethod("getLatency");
            Object ms = mLatency.invoke(info);
            return ms instanceof Number n ? Math.max(0.0, n.doubleValue()) : 0.0;
        } catch (ReflectiveOperationException | RuntimeException e) {
            return 0.0;
        }
    }

    /** The five values for ObsStack (an internal array: copy it, do not keep it). */
    float[] values() { return f; }

    private static float clamp(double v, double lo, double hi) {
        if (!Double.isFinite(v)) return 0f;
        return (float) Math.max(lo, Math.min(hi, v));
    }
}
