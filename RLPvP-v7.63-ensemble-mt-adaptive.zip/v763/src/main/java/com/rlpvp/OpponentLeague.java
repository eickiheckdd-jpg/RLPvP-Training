package com.rlpvp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/** Elo ledger and performance-focused PFSP sampler shared by the live trainer and simulator. */
final class OpponentLeague {
    static final double INITIAL_RATING = 1200.0;
    static final double TARGET_WIN_RATE = 0.60;
    static final double MIN_TARGET_WIN = 0.50;
    static final double MAX_TARGET_WIN = 0.70;
    static final int PROMOTION_GAMES = 30;
    static final double PROMOTION_RATING = 1225.0;
    /** Stage 8 requires a deeper competitive sample before the open-ended Stage 9 league begins. */
    static final int ADVANCED_PROMOTION_GAMES = 150;
    static final double ADVANCED_PROMOTION_RATING = 1275.0;
    static final double K_FACTOR = 24.0;
    /** Stage 9 reserves a small share for proven problem matchups, even after their Elo rises above the main PFSP band. */
    static final double WEAKNESS_CHALLENGE_SHARE = 0.20;
    /**
     * v7.57 TROUBLEMAKERS (evidence: a real stage 9 ledger, 5,134 games, 76 losses, ALL 76 against one scripted style that won 24% of its 310 games; every other opponent won 0-2%).
     * The old corrective sampling only fired for opponents the agent scores BELOW 50% against, so a style that beats the agent a quarter of the time never qualified, and because the
     * agent's Elo was far above every script it was also out of the PFSP band. An opponent is a troublemaker when, over at least TROUBLE_MIN_GAMES games, it beats the agent at least
     * TROUBLE_MIN_LOSS of the time AND at least TROUBLE_RATIO x the agent's loss rate against everything else. Troublemakers get TROUBLE_SHARE of the league draws regardless of Elo,
     * split by how often they win. -Drlpvp.troubleShare=0 switches it off.
     */
    static final double TROUBLE_SHARE = Math.max(0.0, Math.min(0.5, Double.parseDouble(System.getProperty("rlpvp.troubleShare", "0.15"))));
    static final int TROUBLE_MIN_GAMES = Integer.getInteger("rlpvp.troubleMinGames", 20);
    static final double TROUBLE_MIN_LOSS = Double.parseDouble(System.getProperty("rlpvp.troubleMinLoss", "0.10"));
    static final double TROUBLE_RATIO = Double.parseDouble(System.getProperty("rlpvp.troubleRatio", "2.0"));
    static final double MIN_WEAKNESS_EXPECTED_WIN = 0.35;
    /** A candidate with fewer Elo games than this has an unmeasured rating (new styles start at 1200): it stays eligible and gets a floor weight so it is actually played and rated. */
    static final long NEW_OPPONENT_GAMES = 12;
    static final double NEW_OPPONENT_MIN_WEIGHT = 0.6;

    static final class Entry {
        final String id;
        double rating;
        long games, wins, losses, draws;
        // Matchup diagnostics from the learner's point of view when this entry is sampled as its opponent.
        // These are deliberately separate from Elo's symmetric record.
        long matchupGames, matchupWins, matchupLosses, matchupDraws;
        double agentDealt, agentTaken;
        Entry(String id) { this.id = id; rating = INITIAL_RATING; }
    }

    private final Map<String, Entry> entries = new LinkedHashMap<>();

    synchronized Entry ensure(String id) {
        return entries.computeIfAbsent(id, Entry::new);
    }

    synchronized double rating(String id) { return ensure(id).rating; }

    /** v7.54: the main agent's record against {@code id} as "W/L/D over N games" (matchup counters, main agent's point of view). */
    synchronized String matchupLine(String id) {
        Entry e = ensure(id);
        return e.matchupWins + "/" + e.matchupLosses + "/" + e.matchupDraws + " over " + e.matchupGames;
    }

    /** v7.53: a brand-new opponent that has played no rated game starts at {@code r} (an exploiter starts at the agent's own rating instead of the flat 1200). */
    synchronized void seedRating(String id, double r) {
        Entry e = ensure(id);
        if (e.games == 0 && Double.isFinite(r)) e.rating = r;
    }
    synchronized long games(String id) { return ensure(id).games; }

    /**
     * PFSP selection: first restrict to opponents for which the estimated agent win probability is 50–70%,
     * then draw with a Gaussian preference around 60%. If the pool has no in-band member, choose the closest.
     */
    synchronized String sample(String agentId, List<String> candidates, Random rng) {
        return sample(agentId, candidates, rng, false);
    }

    /**
     * Stage 9 keeps PFSP's 50-70% predicted-win band but increases sampling for opponents that previously exposed
     * matchup weaknesses. Aggressive specialists receive a modest coverage bonus so combo/pressure styles do not
     * disappear behind a single aggregate Elo estimate.
     */
    synchronized String sample(String agentId, List<String> candidates, Random rng, boolean stage9) {
        if (candidates == null || candidates.isEmpty()) return null;
        candidates = dropMastered(agentId, candidates, rng);
        double own = ensure(agentId).rating;
        if (TROUBLE_SHARE > 0.0) {   // no random number is drawn unless a troublemaker exists, so a ledger without one samples exactly as before v7.57
            double[] tw = troubleWeights(agentId, candidates);
            if (tw != null && rng.nextDouble() < TROUBLE_SHARE) return pickWeighted(candidates, tw, rng);
        }
        List<String> inBand = new ArrayList<>();
        List<String> weaknessChallenges = new ArrayList<>();
        String closest = null;
        double closestDistance = Double.POSITIVE_INFINITY;
        for (String id : candidates) {
            if (id == null || id.equals(agentId)) continue;
            Entry e = ensure(id);
            double p = expected(own, e.rating);
            double distance = Math.abs(p - TARGET_WIN_RATE);
            if (distance < closestDistance) { closestDistance = distance; closest = id; }
            if ((p >= MIN_TARGET_WIN && p <= MAX_TARGET_WIN) || isUnproven(e)) inBand.add(id);
            if (stage9 && e.matchupGames >= 3 && p >= MIN_WEAKNESS_EXPECTED_WIN && p < MIN_TARGET_WIN) {
                double learnerScoreRate = (e.matchupWins + 0.5 * e.matchupDraws) / e.matchupGames;
                if (learnerScoreRate < 0.50) weaknessChallenges.add(id);
            }
        }
        // A small corrective-play share keeps a repeatedly troublesome opponent in rotation after Elo has
        // correctly recognized it as stronger than the learner. Main PFSP still supplies the majority of games.
        if (stage9 && !weaknessChallenges.isEmpty() && rng.nextDouble() < WEAKNESS_CHALLENGE_SHARE)
            return sampleWeaknessChallenge(agentId, weaknessChallenges, rng);
        if (inBand.isEmpty()) return closest;
        double total = 0.0;
        double[] weights = new double[inBand.size()];
        for (int i = 0; i < inBand.size(); i++) {
            Entry e = ensure(inBand.get(i));
            double p = expected(own, e.rating);
            double target = Math.exp(-0.5 * Math.pow((p - TARGET_WIN_RATE) / 0.075, 2.0));
            double uncertainty = 0.65 + 0.35 / Math.sqrt(1.0 + e.games / 8.0);
            double weakness = stage9 ? matchupWeaknessWeight(e) : 1.0;
            double pressureCoverage = stage9 && isAggressiveSpecialist(inBand.get(i)) ? 1.35 : 1.0;
            double w = target * uncertainty * weakness;
            // v7.46 bug fix: the new-opponent floor used to be applied AFTER the coverage multiplier, so for every opponent with
            // fewer than NEW_OPPONENT_GAMES games (all of them early in stage 9) the floor swallowed the 1.35x aggressive-specialist
            // bonus and rushers/pressure bots were sampled no more than anything else (Stage9LeagueCheck: 46.7% vs the required 49%).
            // The floor is also scaled by the target band: a flat 0.6 was larger than a typical established weight (~0.4), so one
            // brand-new opponent outweighed a proven weakness (PFSP check: 61% vs the required 68%).
            if (isUnproven(e)) w = Math.max(w, NEW_OPPONENT_MIN_WEIGHT * Math.max(target, 0.5));
            weights[i] = Math.max(1e-6, w * pressureCoverage);
            total += weights[i];
        }
        double pick = rng.nextDouble() * total;
        for (int i = 0; i < weights.length; i++) {
            pick -= weights[i];
            if (pick <= 0.0) return inBand.get(i);
        }
        return inBand.get(inBand.size() - 1);
    }

    /**
     * Pre-league stages: record the agent's result against a scripted bot style (matchup counters only: no Elo, no games count, so promotion is untouched).
     * Episodes that go through result() above are not recorded here, so nothing is counted twice.
     */
    synchronized void styleResult(int style, double agentScore, double dealt, double taken) {
        Entry b = ensure("script:" + style);
        if (agentScore > 0.5) b.matchupWins++; else if (agentScore < 0.5) b.matchupLosses++; else b.matchupDraws++;
        b.matchupGames++;
        if (Double.isFinite(dealt) && dealt >= 0.0) b.agentDealt += dealt;
        if (Double.isFinite(taken) && taken >= 0.0) b.agentTaken += taken;
    }

    /** Draw a style from the base mix, each weight multiplied by 1..2 for styles the agent is weak against (a style is never made rarer than its base share before normalising). */
    synchronized int sampleStyle(double[] base, Random rng) {
        double[] w = new double[base.length];
        double total = 0.0;
        for (int i = 0; i < base.length; i++) {
            if (base[i] <= 0.0) continue;
            w[i] = base[i] * matchupWeaknessWeight(ensure("script:" + i));
            total += w[i];
        }
        double pick = rng.nextDouble() * total;
        int last = 0;
        for (int i = 0; i < w.length; i++) {
            if (w[i] <= 0.0) continue;
            last = i;
            pick -= w[i];
            if (pick <= 0.0) return i;
        }
        return last;
    }

    synchronized void result(String agentId, String opponentId, double agentScore) {
        result(agentId, opponentId, agentScore, Double.NaN, Double.NaN);
    }

    synchronized void result(String agentId, String opponentId, double agentScore, double agentDamageDealt, double agentDamageTaken) {
        if (opponentId == null || opponentId.equals(agentId)) return;
        Entry a = ensure(agentId), b = ensure(opponentId);
        double score = Math.max(0.0, Math.min(1.0, agentScore));
        double ea = expected(a.rating, b.rating);
        double eb = 1.0 - ea;
        double delta = K_FACTOR * (score - ea);
        a.rating += delta;
        b.rating -= delta;
        a.games++; b.games++;
        if (score > 0.5) { a.wins++; b.losses++; b.matchupWins++; }
        else if (score < 0.5) { a.losses++; b.wins++; b.matchupLosses++; }
        else { a.draws++; b.draws++; b.matchupDraws++; }
        b.matchupGames++;
        if (Double.isFinite(agentDamageDealt) && agentDamageDealt >= 0.0) b.agentDealt += agentDamageDealt;
        if (Double.isFinite(agentDamageTaken) && agentDamageTaken >= 0.0) b.agentTaken += agentDamageTaken;
    }

    /** The agent's loss rate over every matchup except {@code skip}'s (so a bully does not dilute its own baseline). */
    private double baselineLossRate(String skip) {
        long games = 0, losses = 0;
        for (Entry e : entries.values()) {
            if (e.id.equals(skip) || e.matchupGames <= 0) continue;
            games += e.matchupGames; losses += e.matchupLosses;
        }
        return games <= 0 ? 0.0 : losses / (double) games;
    }

    /** v7.57: an opponent the main agent beats essentially always only wastes samples. Once it has played at least MASTERED_MIN_GAMES games against the main agent and lost at least MASTERED_WIN of them it is left out of the draw,
     *  except for a MASTERED_KEEP share of draws that use the whole list (so a regression shows up again), and never if fewer than three others would remain. -Drlpvp.masteredWin=2 turns it off. A random number is drawn only if something was dropped. */
    static final double MASTERED_WIN = Double.parseDouble(System.getProperty("rlpvp.masteredWin", "0.98"));
    static final int MASTERED_MIN_GAMES = Integer.getInteger("rlpvp.masteredMinGames", 40);
    static final double MASTERED_KEEP = Double.parseDouble(System.getProperty("rlpvp.masteredKeep", "0.05"));
    synchronized List<String> dropMastered(String agentId, List<String> candidates, Random rng) {
        if (MASTERED_WIN > 1.0) return candidates;
        List<String> kept = null;
        for (String id : candidates) {
            Entry e = id == null ? null : entries.get(id);
            boolean mastered = e != null && !id.equals(agentId) && e.matchupGames >= MASTERED_MIN_GAMES && e.matchupWins >= MASTERED_WIN * e.matchupGames;
            if (mastered) { if (kept == null) { kept = new ArrayList<>(); for (String c : candidates) { if (c == id) break; kept.add(c); } } }
            else if (kept != null) kept.add(id);
        }
        if (kept == null || kept.size() < 3) return candidates;
        if (rng.nextDouble() < MASTERED_KEEP) return candidates;
        return kept;
    }

    /** @return per-candidate weights (its win rate against the agent) when at least one candidate is a troublemaker, else null. Draws no random numbers. */
    private double[] troubleWeights(String agentId, List<String> candidates) {
        double[] w = new double[candidates.size()];
        double total = 0.0;
        for (int i = 0; i < w.length; i++) {
            String id = candidates.get(i);
            if (id == null || id.equals(agentId)) continue;
            Entry e = entries.get(id);
            if (e == null || e.matchupGames < TROUBLE_MIN_GAMES) continue;
            double loss = e.matchupLosses / (double) e.matchupGames;
            if (loss >= TROUBLE_MIN_LOSS && loss >= TROUBLE_RATIO * baselineLossRate(id)) { w[i] = loss; total += loss; }
        }
        return total > 0.0 ? w : null;
    }

    private static String pickWeighted(List<String> candidates, double[] w, Random rng) {
        double total = 0.0;
        for (double x : w) total += x;
        double pick = rng.nextDouble() * total;
        for (int i = 0; i < w.length; i++) { pick -= w[i]; if (w[i] > 0.0 && pick <= 0.0) return candidates.get(i); }
        for (int i = w.length - 1; i >= 0; i--) if (w[i] > 0.0) return candidates.get(i);
        return null;
    }

    /** @return a candidate that beats the agent clearly more than the agent's baseline (weighted by its win rate), or null when there is none. */
    synchronized String sampleTroublemaker(String agentId, List<String> candidates, Random rng) {
        double[] w = troubleWeights(agentId, candidates);
        return w == null ? null : pickWeighted(candidates, w, rng);
    }

    private String sampleWeaknessChallenge(String agentId, List<String> candidates, Random rng) {
        double own = ensure(agentId).rating;
        double total = 0.0;
        double[] weights = new double[candidates.size()];
        for (int i = 0; i < candidates.size(); i++) {
            String id = candidates.get(i);
            Entry e = ensure(id);
            double p = expected(own, e.rating);
            double challengeBand = Math.exp(-0.5 * Math.pow((p - 0.42) / 0.12, 2.0));
            double pressureCoverage = isAggressiveSpecialist(id) ? 1.35 : 1.0;
            weights[i] = Math.max(1e-6, challengeBand * matchupWeaknessWeight(e) * pressureCoverage);
            total += weights[i];
        }
        double pick = rng.nextDouble() * total;
        for (int i = 0; i < weights.length; i++) {
            pick -= weights[i];
            if (pick <= 0.0) return candidates.get(i);
        }
        return candidates.get(candidates.size() - 1);
    }

    /**
     * v7.46: an opponent only counts as new while it has neither many games nor a real matchup record against the learner.
     * Previously a few games of clear losses still kept a bully opponent in the normal band at the new-opponent floor,
     * so it was over-sampled instead of getting the bounded corrective share (check: ~46% vs the intended 15-25%).
     */
    private static boolean isUnproven(Entry e) { return e.games < NEW_OPPONENT_GAMES && e.matchupGames < 3; }

    private static double matchupWeaknessWeight(Entry e) {
        if (e.matchupGames <= 0) return 1.0;
        double confidence = Math.min(1.0, e.matchupGames / 12.0);
        double scoreRate = (e.matchupWins + 0.5 * e.matchupDraws) / e.matchupGames;
        double deficit = (e.agentTaken - e.agentDealt) / Math.max(12.0, e.agentTaken + e.agentDealt);
        double weakness = 1.0 + 0.90 * (1.0 - scoreRate) * confidence + 0.45 * Math.max(0.0, Math.min(1.0, deficit)) * confidence;
        // v7.57: how often it actually BEATS the agent counts too (the score-rate term above barely moves when the agent still wins 75% of the games, as against the only style that ever beat it)
        double lossRate = e.matchupLosses / (double) e.matchupGames;
        if (TROUBLE_SHARE > 0.0) weakness += 2.5 * Math.max(0.0, lossRate - 0.08) * confidence;
        return Math.max(1.0, Math.min(TROUBLE_SHARE > 0.0 ? 2.5 : 2.0, weakness));
    }

    private static boolean isAggressiveSpecialist(String id) {
        if (id == null || !id.startsWith("script:")) return false;
        try { return BotAI.isAggressiveSpecialist(Integer.parseInt(id.substring("script:".length()))); }
        catch (NumberFormatException ex) { return false; }
    }

    synchronized String weaknessSummary(String agentId) {
        List<Entry> weak = new ArrayList<>();
        for (Entry e : entries.values()) if (!e.id.equals(agentId) && e.matchupGames >= 3) weak.add(e);
        weak.sort((x, y) -> Double.compare(matchupWeaknessWeight(y), matchupWeaknessWeight(x)));
        if (weak.isEmpty()) return "weak-vs: insufficient matchup data";
        StringBuilder out = new StringBuilder("weak-vs:");
        for (int i = 0; i < Math.min(3, weak.size()); i++) {
            Entry e = weak.get(i);
            if (i > 0) out.append(';');
            String displayId = e.id;
            if (e.id.startsWith("script:")) {
                try { displayId = BotAI.styleName(Integer.parseInt(e.id.substring("script:".length()))); }
                catch (NumberFormatException ignored) { /* keep the stable raw id */ }
            }
            out.append(' ').append(displayId).append(' ')
                .append(e.matchupWins).append('/').append(e.matchupLosses).append('/').append(e.matchupDraws)
                .append(" D/T ").append(String.format(Locale.ROOT, "%.1f/%.1f", e.agentDealt / e.matchupGames, e.agentTaken / e.matchupGames));
        }
        return out.toString();
    }

    synchronized void snapshot(String id, String sourceId) {
        Entry src = ensure(sourceId), dst = ensure(id);
        copyRecord(src, dst);
    }

    /** Register an immutable policy snapshot exactly once when several training environments share this league. */
    synchronized boolean snapshotIfAbsent(String id, String sourceId) {
        if (entries.containsKey(id)) return false;
        Entry src = ensure(sourceId);
        Entry dst = new Entry(id);
        copyRecord(src, dst);
        entries.put(id, dst);
        return true;
    }

    private static void copyRecord(Entry src, Entry dst) {
        dst.rating = src.rating;
        dst.games = src.games;
        dst.wins = src.wins;
        dst.losses = src.losses;
        dst.draws = src.draws;
    }

    synchronized boolean promotionReady(String agentId) {
        Entry e = ensure(agentId);
        return e.games >= PROMOTION_GAMES && e.rating >= PROMOTION_RATING;
    }

    synchronized String summary(String agentId) {
        Entry e = ensure(agentId);
        return String.format(Locale.ROOT, "Elo %.0f (%d games; W/L/D %d/%d/%d)", e.rating, e.games, e.wins, e.losses, e.draws);
    }

    synchronized void save(Path path) throws IOException {
        Path parent = path.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
        List<Entry> sorted = new ArrayList<>(entries.values());
        sorted.sort(Comparator.comparing(x -> x.id));
        StringBuilder out = new StringBuilder("id,rating,games,wins,losses,draws,matchup_games,matchup_wins,matchup_losses,matchup_draws,agent_dealt,agent_taken\n");
        for (Entry e : sorted) out.append(csv(e.id)).append(',').append(String.format(Locale.ROOT, "%.3f", e.rating))
            .append(',').append(e.games).append(',').append(e.wins).append(',').append(e.losses).append(',').append(e.draws)
            .append(',').append(e.matchupGames).append(',').append(e.matchupWins).append(',').append(e.matchupLosses).append(',').append(e.matchupDraws)
            .append(',').append(String.format(Locale.ROOT, "%.3f", e.agentDealt)).append(',').append(String.format(Locale.ROOT, "%.3f", e.agentTaken)).append('\n');
        Path target = path.toAbsolutePath();
        Path tmp = Files.createTempFile(parent, path.getFileName().toString() + ".", ".tmp");
        try {
            Files.writeString(tmp, out.toString());
            try {
                Files.move(tmp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ex) {
                Files.move(tmp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    synchronized void load(Path path) throws IOException {
        if (!Files.isRegularFile(path)) return;
        List<String> lines = Files.readAllLines(path);
        for (int i = 1; i < lines.size(); i++) {
            String[] p = lines.get(i).split(",", -1);
            if (p.length < 6) continue; // v1 six-column files remain readable
            try {
                Entry e = ensure(unCsv(p[0]));
                e.rating = Double.parseDouble(p[1]); e.games = Long.parseLong(p[2]);
                e.wins = Long.parseLong(p[3]); e.losses = Long.parseLong(p[4]); e.draws = Long.parseLong(p[5]);
                if (p.length >= 12) {
                    e.matchupGames = Long.parseLong(p[6]); e.matchupWins = Long.parseLong(p[7]);
                    e.matchupLosses = Long.parseLong(p[8]); e.matchupDraws = Long.parseLong(p[9]);
                    e.agentDealt = Double.parseDouble(p[10]); e.agentTaken = Double.parseDouble(p[11]);
                }
            } catch (RuntimeException ignored) { /* ignore damaged rows, retain the rest of the ledger */ }
        }
    }

    /** v7.62: generation of the rating semantics. 1 = before v7.54 (frozen opponents aimed worse than the agent), 2 = fair frozen opponents (v7.54+), 3 = hard-start episodes are not rated (v7.60+). Bump when a change makes old ratings mean something else. */
    static final int LEAGUE_VERSION = 3;
    static final String VERSION_FILE = "league.version";

    /**
     * Compares the league directory's marker with {@link #LEAGUE_VERSION}, then writes the current one (so a warning is shown once). Never deletes or changes ratings.
     * @return a warning to print, or null when the league is new/empty or already current
     */
    static String checkVersion(Path leagueDir, Path ratingsFile) {
        Path marker = leagueDir.resolve(VERSION_FILE);
        String warning = null;
        try {
            boolean hasRatings = Files.isRegularFile(ratingsFile) && Files.size(ratingsFile) > 0;
            int found = 0;
            if (Files.isRegularFile(marker)) {
                try { found = Integer.parseInt(Files.readString(marker).trim()); } catch (RuntimeException bad) { found = 0; }
            }
            if (hasRatings && found == 0) {
                warning = "league: " + ratingsFile.getFileName() + " has no version marker, so it was built by v7.53 or older (or a copy lost the marker). Its ratings were earned against frozen opponents with a weaker camera and before hard starts were excluded, so old Elos may be inflated and 'mastered' styles may not be. Start a fresh league (-Dsim.league.dir=<new folder>) if you want clean ratings; nothing was changed.";
            } else if (hasRatings && found < LEAGUE_VERSION) {
                warning = "league: ratings were written under rating-semantics version " + found + " (now " + LEAGUE_VERSION + "); old Elos may not be comparable with new ones. Start a fresh league (-Dsim.league.dir=<new folder>) for clean ratings; nothing was changed.";
            } else if (found > LEAGUE_VERSION) {
                warning = "league: ratings were written by a NEWER build (version " + found + " > " + LEAGUE_VERSION + "); they may mean something different here.";
            }
            if (found < LEAGUE_VERSION) Files.writeString(marker, Integer.toString(LEAGUE_VERSION));
        } catch (IOException | RuntimeException ignored) { /* a read-only folder just means no marker */ }
        return warning;
    }

    static double expected(double own, double opponent) { return 1.0 / (1.0 + Math.pow(10.0, (opponent - own) / 400.0)); }
    private static String csv(String s) { return '"' + s.replace("\"", "\"\"") + '"'; }
    private static String unCsv(String s) { return s.length() >= 2 && s.charAt(0) == '"' ? s.substring(1, s.length() - 1).replace("\"\"", "\"") : s; }
}
