package com.rlpvp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Auxiliary prediction heads (v7.46): a multi-task network trained alongside PPO that forecasts what is about to happen, so the recurrent
 * state has to model the OPPONENT instead of only whatever helps the next reward.
 *
 * Inputs are exactly what the policy sees (the 128-value observation, including the 64 GRU values). The labels come from the agent's OWN
 * future observations inside the rollout, never from simulator internals, so the identical heads can be trained from live play too.
 *
 *  Opponent forecast at +1, +4 and +10 ticks (3 horizons x 5 units):
 *      swing    - does the opponent swing at any point in the next h ticks?          (binary)
 *      sprint   - is it sprinting at t+h?                                            (binary)
 *      air      - is it airborne at t+h (jump / crit attempt / knockback)?           (binary)
 *      lateral  - strafing left / not / right at t+h, in MY frame                    (3-class)
 *      radial   - closing in / holding / backing off between now and t+h             (3-class)
 *  Hazard (survival style, right-censored): taken(k) = do I lose health within k ticks, dealt(k) = does the opponent, k = 5, 10, 20.
 *  Outcome at +20 ticks: damage dealt, damage taken and the health swing, as Huber regressions.
 *
 * What makes this more than "add some outputs":
 *  - Censoring-aware labels. A window cut short by the end of an episode or rollout only yields a label if the event was already seen
 *    (a positive is certain); an unseen event in a truncated window is masked, not counted as "nothing happened". This removes the bias
 *    that would otherwise make deadly situations look safe, because the lethal hit is the last thing an episode contains.
 *  - Uncertainty-weighted multi-task loss (Kendall et al.): every task owns a learned log-variance, so the tasks balance themselves
 *    and no fixed loss coefficients have to be tuned per head.
 *  - The gradient the heads send into the GRU is rescaled to a fixed fraction of the RL gradient's running norm and, when it points against
 *    the RL gradient, its conflicting component is projected out (PCGrad), so the auxiliary tasks shape the memory without being able
 *    to fight the policy objective. A warm-up lets the heads learn before they influence the GRU at all.
 *  - Self-evaluation: every task tracks a skill score against the best constant (base-rate) predictor. Skill above zero is evidence that
 *    the observation + hidden state carry information about the opponent; {@link #trusted()} gates the use of the forecasts elsewhere.
 *
 * No Minecraft classes.
 */
final class AuxForecaster {
    // ---- frame feature indices inside the observation (see PvpSim.frameInto / ObservationRegistry) ----
    static final int F_OWN_HP = 0, F_DIST = 12, F_TGT_HP = 15, F_TGT_LAT = 17, F_TGT_GROUND = 19, F_TGT_SPRINT = 22, F_TGT_SWING = 23;

    static final int[] OPP_H = {1, 4, 10};
    static final int[] HAZ_K = {5, 10, 20};
    static final int OUT_H = 20;

    // ---- tasks ----
    static final int T_SWING = 0, T_SPRINT = 1, T_AIR = 2, T_LAT = 3, T_RAD = 4, T_TAKEN = 5, T_DEALT = 6, T_OUTCOME = 7, TASKS = 8;
    static final String[] TASK_NAME = {"swing", "sprint", "air", "lateral", "radial", "taken", "dealt", "outcome"};

    // ---- unit table: one entry per prediction target ----
    private static final int K_BCE = 0, K_CE3 = 1, K_HUBER = 2;
    static final int NUNITS, NLOGITS;
    private static final int[] U_TASK, U_KIND, U_OFF, U_PARAM;   // PARAM = horizon (opp / hazard) or outcome index
    private static final int[] TASK_UNITS = new int[TASKS];
    static {
        List<int[]> u = new ArrayList<>();   // {task, kind, param}
        for (int t : new int[]{T_SWING, T_SPRINT, T_AIR}) for (int h : OPP_H) u.add(new int[]{t, K_BCE, h});
        for (int t : new int[]{T_LAT, T_RAD}) for (int h : OPP_H) u.add(new int[]{t, K_CE3, h});
        for (int k : HAZ_K) u.add(new int[]{T_TAKEN, K_BCE, k});
        for (int k : HAZ_K) u.add(new int[]{T_DEALT, K_BCE, k});
        for (int o = 0; o < 3; o++) u.add(new int[]{T_OUTCOME, K_HUBER, o});   // 0 dealt20, 1 taken20, 2 swing20
        NUNITS = u.size();
        U_TASK = new int[NUNITS]; U_KIND = new int[NUNITS]; U_OFF = new int[NUNITS]; U_PARAM = new int[NUNITS];
        int off = 0;
        for (int i = 0; i < NUNITS; i++) {
            int[] e = u.get(i);
            U_TASK[i] = e[0]; U_KIND[i] = e[1]; U_PARAM[i] = e[2]; U_OFF[i] = off;
            off += e[1] == K_CE3 ? 3 : 1;
            TASK_UNITS[e[0]]++;
        }
        NLOGITS = off;
    }

    // ---- thresholds that turn observed frames into labels ----
    private static final float HP_DROP = 0.01f;        // frame hp units (hp / 20): about half a heart
    private static final float LAT_DEAD_ZONE = 0.12f;  // |lateral velocity| / 0.6 below this counts as "not strafing"
    private static final float RAD_DEAD_ZONE = 0.025f; // distance / 6 change below this counts as "holding"
    private static final float OUT_SCALE = 5f;         // frame hp units -> regression target (1.0 = 4 hp)
    private static final float HUBER_DELTA = 1f;

    // =================================================================================================== label construction
    /**
     * Builds the targets of every tick of a finished rollout from the rollout's own future observations.
     * tgt[t][u] is the label (class index for 3-class units), msk[t][u] is 1 when the label is trustworthy, 0 when censored / unavailable.
     */
    static void buildTargets(float[][] obs, boolean[] done, int n, float[][] tgt, float[][] msk) {
        int[] end = new int[n];   // last index that belongs to tick t's episode inside this rollout
        for (int t = n - 1; t >= 0; t--) end[t] = (done[t] || t == n - 1) ? t : end[t + 1];
        for (int t = 0; t < n; t++) {
            float[] now = obs[t];
            for (int u = 0; u < NUNITS; u++) {
                float label = 0f; boolean valid = false;
                int p = U_PARAM[u], last = end[t];
                switch (U_TASK[u]) {
                    case T_SWING: {
                        boolean seen = false;
                        for (int j = t + 1; j <= Math.min(t + p, last) && !seen; j++) seen = obs[j][F_TGT_SWING] > 0.5f;
                        label = seen ? 1f : 0f; valid = seen || t + p <= last; break;
                    }
                    case T_SPRINT: if (t + p <= last) { label = obs[t + p][F_TGT_SPRINT] > 0.5f ? 1f : 0f; valid = true; } break;
                    case T_AIR: if (t + p <= last) { label = obs[t + p][F_TGT_GROUND] < 0.5f ? 1f : 0f; valid = true; } break;
                    case T_LAT: if (t + p <= last) {
                        float v = obs[t + p][F_TGT_LAT];
                        label = v < -LAT_DEAD_ZONE ? 0f : v > LAT_DEAD_ZONE ? 2f : 1f; valid = true;
                    } break;
                    case T_RAD: if (t + p <= last) {
                        float d = obs[t + p][F_DIST] - now[F_DIST];
                        label = d < -RAD_DEAD_ZONE ? 0f : d > RAD_DEAD_ZONE ? 2f : 1f; valid = true;
                    } break;
                    case T_TAKEN: case T_DEALT: {
                        int f = U_TASK[u] == T_TAKEN ? F_OWN_HP : F_TGT_HP;
                        boolean seen = false;
                        for (int j = t + 1; j <= Math.min(t + p, last) && !seen; j++) seen = now[f] - obs[j][f] > HP_DROP;
                        label = seen ? 1f : 0f; valid = seen || t + p <= last; break;
                    }
                    default: // T_OUTCOME: needs the complete window
                        if (t + OUT_H <= last) {
                            float dealt = Math.max(0f, now[F_TGT_HP] - obs[t + OUT_H][F_TGT_HP]) * OUT_SCALE;
                            float taken = Math.max(0f, now[F_OWN_HP] - obs[t + OUT_H][F_OWN_HP]) * OUT_SCALE;
                            label = p == 0 ? dealt : p == 1 ? taken : dealt - taken; valid = true;
                        }
                }
                tgt[t][u] = label; msk[t][u] = valid ? 1f : 0f;
            }
        }
    }

    // =================================================================================================== model + training
    final Net net;
    private final Net inference;   // shares weights with {@link #net} but has its own activation buffers, so play-time forecasts never disturb a minibatch
    private final float[] dz = new float[NLOGITS];
    private final float[] logS = new float[TASKS];     // learned log-variance per task
    private final double[] gS = new double[TASKS];     // accumulated d loss / d logS for the current minibatch
    private long samples, conflicts, blended;
    private double emaNormRL, emaNormAux;
    private final double[] lossEma = new double[TASKS], baseEma = new double[TASKS];
    private final double[] rate = new double[NUNITS];  // running base rate (BCE) / mean (Huber) per unit
    private final double[][] dist = new double[NUNITS][3];
    private final long[] unitN = new long[NUNITS];
    private final double[] taskLoss = new double[TASKS], taskBase = new double[TASKS];
    private final int[] taskCnt = new int[TASKS];

    AuxForecaster(Random rng, int gruSlot, int gruWidth) {
        net = new Net(new int[]{Config.OBS_SIZE, Config.AUX_HIDDEN_1, Config.AUX_HIDDEN_2, NLOGITS}, 0.01f, rng);
        if (gruWidth > 0) net.trackInput(gruSlot, gruWidth);
        inference = net.twin();
        for (int u = 0; u < NUNITS; u++) { rate[u] = U_KIND[u] == K_BCE ? 0.2 : 0.0; java.util.Arrays.fill(dist[u], 1.0 / 3.0); }
    }

    void clearInputGrad() { net.clearInputGrad(); }
    void zeroGrad() { net.zeroGrad(); java.util.Arrays.fill(gS, 0.0); }

    private static double sigmoid(double z) { return 1.0 / (1.0 + Math.exp(-Math.max(-30.0, Math.min(30.0, z)))); }
    private double weight(int task) { return Math.exp(-Math.max(-2.5f, Math.min(2.5f, logS[task]))); }

    /** One sample: forward, per-unit loss gradients (task-weighted), backward into the head network, bookkeeping. */
    void accumulate(float[] obs, float[] tgt, float[] msk) {
        float[] z = net.forward(obs);
        java.util.Arrays.fill(dz, 0f);
        java.util.Arrays.fill(taskLoss, 0.0); java.util.Arrays.fill(taskBase, 0.0); java.util.Arrays.fill(taskCnt, 0);
        boolean any = false;
        for (int u = 0; u < NUNITS; u++) {
            if (msk[u] < 0.5f) continue;
            any = true;
            int task = U_TASK[u], o = U_OFF[u];
            double w = weight(task) / TASK_UNITS[task];
            double loss, base;
            float y = tgt[u];
            switch (U_KIND[u]) {
                case K_BCE: {
                    double p = sigmoid(z[o]);
                    loss = -(y > 0.5f ? Math.log(Math.max(p, 1e-9)) : Math.log(Math.max(1.0 - p, 1e-9)));
                    double pb = Math.max(0.01, Math.min(0.99, rate[u]));
                    base = -(y > 0.5f ? Math.log(pb) : Math.log(1.0 - pb));
                    dz[o] = (float) (w * (p - y));
                    rate[u] += Math.max(0.0005, 1.0 / (unitN[u] + 1.0)) * (y - rate[u]);
                    break;
                }
                case K_CE3: {
                    double m = Math.max(z[o], Math.max(z[o + 1], z[o + 2]));
                    double e0 = Math.exp(z[o] - m), e1 = Math.exp(z[o + 1] - m), e2 = Math.exp(z[o + 2] - m), s = e0 + e1 + e2;
                    double[] p = {e0 / s, e1 / s, e2 / s};
                    int c = (int) y;
                    loss = -Math.log(Math.max(p[c], 1e-9));
                    base = -Math.log(Math.max(dist[u][c], 0.01));
                    for (int k = 0; k < 3; k++) dz[o + k] = (float) (w * (p[k] - (k == c ? 1.0 : 0.0)));
                    double a = Math.max(0.0005, 1.0 / (unitN[u] + 1.0));
                    for (int k = 0; k < 3; k++) dist[u][k] += a * ((k == c ? 1.0 : 0.0) - dist[u][k]);
                    break;
                }
                default: {
                    double r = z[o] - y, ar = Math.abs(r);
                    loss = ar <= HUBER_DELTA ? 0.5 * r * r : HUBER_DELTA * (ar - 0.5 * HUBER_DELTA);
                    double rb = y - rate[u], arb = Math.abs(rb);
                    base = arb <= HUBER_DELTA ? 0.5 * rb * rb : HUBER_DELTA * (arb - 0.5 * HUBER_DELTA);
                    dz[o] = (float) (w * Math.max(-HUBER_DELTA, Math.min(HUBER_DELTA, r)));
                    rate[u] += Math.max(0.0005, 1.0 / (unitN[u] + 1.0)) * (y - rate[u]);
                }
            }
            unitN[u]++;
            taskLoss[task] += loss; taskBase[task] += base; taskCnt[task]++;
        }
        if (!any) return;
        for (int k = 0; k < TASKS; k++) {
            if (taskCnt[k] == 0) continue;
            double lk = taskLoss[k] / taskCnt[k], bk = taskBase[k] / taskCnt[k];
            gS[k] += 1.0 - weight(k) * lk;                       // d/ds [exp(-s) L + s]
            double a = Math.max(0.002, 1.0 / (samples + 1.0));
            lossEma[k] += a * (lk - lossEma[k]); baseEma[k] += a * (bk - baseEma[k]);
        }
        samples++;
        net.backward(dz);
    }

    /**
     * Adds this sample's auxiliary gradient w.r.t. the GRU slots to the RL gradient {@code gRL} (in place): rescaled so its running norm is
     * {@code Config.AUX_GRU_RATIO} of the RL gradient's, with any component that opposes the RL gradient projected out. {@code ramp} in [0,1]
     * is the warm-up factor. Call after {@link #accumulate} for the same sample.
     */
    void blendIntoGruGrad(float[] gRL, float ramp) {
        float[] ga = net.inputGrad();
        int n = Math.min(gRL.length, ga.length);
        double nRL = 0, nA = 0, dot = 0;
        for (int q = 0; q < n; q++) { nRL += (double) gRL[q] * gRL[q]; nA += (double) ga[q] * ga[q]; dot += (double) gRL[q] * ga[q]; }
        nRL = Math.sqrt(nRL); nA = Math.sqrt(nA);
        if (!Double.isFinite(nRL) || !Double.isFinite(nA)) return;
        emaNormRL = emaNormRL == 0 ? nRL : emaNormRL + 0.01 * (nRL - emaNormRL);
        emaNormAux = emaNormAux == 0 ? nA : emaNormAux + 0.01 * (nA - emaNormAux);
        if (ramp <= 0f || emaNormAux < 1e-12) return;
        double scale = Math.min(10.0, ramp * Config.AUX_GRU_RATIO * emaNormRL / emaNormAux);
        double proj = 0.0;
        if (Config.AUX_PROJECT && dot < 0 && nRL > 1e-9) { proj = dot / (nRL * nRL); conflicts++; }
        for (int q = 0; q < n; q++) gRL[q] += (float) (scale * (ga[q] - proj * gRL[q]));
        blended++;
    }

    /** End of a complete minibatch: Adam step on the head network and a small SGD step on the task log-variances. */
    void step(float lr, int count) {
        if (count <= 0) { zeroGrad(); return; }
        net.step(lr, 1.0f, count);
        for (int k = 0; k < TASKS; k++) {
            logS[k] = (float) Math.max(-2.5, Math.min(2.5, logS[k] - 0.02 * gS[k] / count));
            gS[k] = 0.0;
        }
    }

    // =================================================================================================== forecasts for the rest of the agent
    static final class Forecast {
        final float[] swing = new float[OPP_H.length], sprint = new float[OPP_H.length], air = new float[OPP_H.length];
        final float[][] lateral = new float[OPP_H.length][3];   // left / none / right, in my frame
        final float[][] radial = new float[OPP_H.length][3];    // closing / holding / backing off
        final float[] taken = new float[HAZ_K.length], dealt = new float[HAZ_K.length];
        float dealt20, taken20, swing20;                        // health points
        boolean valid;
    }

    /** Fills {@code out} for this observation using the inference copy (weights shared with the learner). */
    void predict(float[] obs, Forecast out) {
        float[] z = inference.forward(obs);
        for (int u = 0; u < NUNITS; u++) {
            int o = U_OFF[u], hIdx = indexOf(U_KIND[u] == K_HUBER ? -1 : U_PARAM[u], U_TASK[u]);
            switch (U_TASK[u]) {
                case T_SWING: out.swing[hIdx] = (float) sigmoid(z[o]); break;
                case T_SPRINT: out.sprint[hIdx] = (float) sigmoid(z[o]); break;
                case T_AIR: out.air[hIdx] = (float) sigmoid(z[o]); break;
                case T_LAT: softmax3(z, o, out.lateral[hIdx]); break;
                case T_RAD: softmax3(z, o, out.radial[hIdx]); break;
                case T_TAKEN: out.taken[hIdx] = (float) sigmoid(z[o]); break;
                case T_DEALT: out.dealt[hIdx] = (float) sigmoid(z[o]); break;
                default:
                    if (U_PARAM[u] == 0) out.dealt20 = 4f * z[o]; else if (U_PARAM[u] == 1) out.taken20 = 4f * z[o]; else out.swing20 = 4f * z[o];
            }
        }
        out.valid = true;
    }

    private static int indexOf(int param, int task) {
        int[] set = task == T_TAKEN || task == T_DEALT ? HAZ_K : OPP_H;
        for (int i = 0; i < set.length; i++) if (set[i] == param) return i;
        return 0;
    }

    private static void softmax3(float[] z, int o, float[] out) {
        double m = Math.max(z[o], Math.max(z[o + 1], z[o + 2]));
        double e0 = Math.exp(z[o] - m), e1 = Math.exp(z[o + 1] - m), e2 = Math.exp(z[o + 2] - m), s = e0 + e1 + e2;
        out[0] = (float) (e0 / s); out[1] = (float) (e1 / s); out[2] = (float) (e2 / s);
    }

    // =================================================================================================== evaluation
    /** Skill of one task against the best constant predictor: 1 = perfect, 0 = no better than the base rate, negative = worse. */
    double skill(int task) {
        return baseEma[task] > 1e-9 && samples > 200 ? 1.0 - lossEma[task] / baseEma[task] : 0.0;
    }

    long samples() { return samples; }
    long conflicts() { return conflicts; }
    long blended() { return blended; }
    double logVariance(int task) { return logS[task]; }

    /** True once the hazard heads have clearly learned something: used to gate every other use of the forecasts. */
    boolean trusted() {
        return samples >= Config.AUX_TRUST_SAMPLES && skill(T_TAKEN) >= Config.AUX_TRUST_SKILL;
    }

    String status() {
        StringBuilder b = new StringBuilder(String.format(java.util.Locale.ROOT, "aux n=%d%s skill:", samples, trusted() ? " [trusted]" : ""));
        for (int k = 0; k < TASKS; k++) b.append(String.format(java.util.Locale.ROOT, " %s %+.2f", TASK_NAME[k], skill(k)));
        b.append(String.format(java.util.Locale.ROOT, " | gru-grad conflicts %.0f%%", blended == 0 ? 0.0 : 100.0 * conflicts / blended));
        return b.toString();
    }

    // =================================================================================================== persistence
    private static final int FORMAT = 1;

    void write(DataOutputStream out) throws IOException {
        out.writeInt(FORMAT); out.writeInt(NUNITS); out.writeInt(NLOGITS); out.writeInt(Config.OBS_SIZE);
        out.writeInt(Config.AUX_HIDDEN_1); out.writeInt(Config.AUX_HIDDEN_2);
        net.write(out);
        for (int k = 0; k < TASKS; k++) { out.writeFloat(logS[k]); out.writeDouble(lossEma[k]); out.writeDouble(baseEma[k]); }
        out.writeLong(samples); out.writeLong(conflicts); out.writeLong(blended);
        out.writeDouble(emaNormRL); out.writeDouble(emaNormAux);
        for (int u = 0; u < NUNITS; u++) { out.writeDouble(rate[u]); out.writeLong(unitN[u]); for (int k = 0; k < 3; k++) out.writeDouble(dist[u][k]); }
    }

    /** All-or-nothing: a layout that does not match this build is ignored and the heads start fresh. */
    void read(DataInputStream in) throws IOException {
        if (in.readInt() != FORMAT || in.readInt() != NUNITS || in.readInt() != NLOGITS || in.readInt() != Config.OBS_SIZE
            || in.readInt() != Config.AUX_HIDDEN_1 || in.readInt() != Config.AUX_HIDDEN_2) return;
        net.read(in);
        for (int k = 0; k < TASKS; k++) { logS[k] = in.readFloat(); lossEma[k] = in.readDouble(); baseEma[k] = in.readDouble(); }
        samples = in.readLong(); conflicts = in.readLong(); blended = in.readLong();
        emaNormRL = in.readDouble(); emaNormAux = in.readDouble();
        for (int u = 0; u < NUNITS; u++) { rate[u] = in.readDouble(); unitN[u] = in.readLong(); for (int k = 0; k < 3; k++) dist[u][k] = in.readDouble(); }
    }

    // ---- v7.51 multi-thread learner: a shard copy of the running statistics, and the merge of shard results back ----
    private long bSamples, bConflicts, bBlended;
    private final long[] bUnitN = new long[NUNITS];

    /** Makes this (shard) instance continue from {@code src}'s weights and running statistics, and records the starting counters. */
    void shardSyncFrom(AuxForecaster src) {
        net.copyWeightsFrom(src.net);
        System.arraycopy(src.logS, 0, logS, 0, TASKS);
        System.arraycopy(src.lossEma, 0, lossEma, 0, TASKS);
        System.arraycopy(src.baseEma, 0, baseEma, 0, TASKS);
        System.arraycopy(src.rate, 0, rate, 0, NUNITS);
        System.arraycopy(src.unitN, 0, unitN, 0, NUNITS);
        for (int u = 0; u < NUNITS; u++) System.arraycopy(src.dist[u], 0, dist[u], 0, 3);
        samples = src.samples; conflicts = src.conflicts; blended = src.blended;
        emaNormRL = src.emaNormRL; emaNormAux = src.emaNormAux;
        bSamples = samples; bConflicts = conflicts; bBlended = blended;
        System.arraycopy(unitN, 0, bUnitN, 0, NUNITS);
        zeroGrad();
    }

    /**
     * Adds a finished shard into this instance: gradients and counters exactly (sums), the running averages (base rates, loss EMAs, gradient norms)
     * as a sample-weighted mean. {@code wSelf} / {@code wShard} are the numbers of samples each side processed; the caller keeps the running total.
     */
    void shardMerge(AuxForecaster s, double wSelf, double wShard) {
        net.addGradFrom(s.net);
        for (int k = 0; k < TASKS; k++) gS[k] += s.gS[k];
        samples += s.samples - s.bSamples; conflicts += s.conflicts - s.bConflicts; blended += s.blended - s.bBlended;
        for (int u = 0; u < NUNITS; u++) unitN[u] += s.unitN[u] - s.bUnitN[u];
        double tot = wSelf + wShard;
        if (tot <= 0.0) return;
        double a = wSelf / tot, b = wShard / tot;
        for (int k = 0; k < TASKS; k++) { lossEma[k] = a * lossEma[k] + b * s.lossEma[k]; baseEma[k] = a * baseEma[k] + b * s.baseEma[k]; }
        for (int u = 0; u < NUNITS; u++) {
            rate[u] = a * rate[u] + b * s.rate[u];
            for (int k = 0; k < 3; k++) dist[u][k] = a * dist[u][k] + b * s.dist[u][k];
        }
        emaNormRL = a * emaNormRL + b * s.emaNormRL; emaNormAux = a * emaNormAux + b * s.emaNormAux;
    }
}
