package com.rlpvp;

/**
 * Health-difference shaping (v7.49): a two-sided, potential-based reward on the lead (my HP - enemy HP) / 20.
 *
 *   potential  Phi(lead) = tanh(K * lead)                       (K = 2.5; +1 = far ahead, -1 = far behind, 0 = even)
 *   per tick   F = w * (gamma * Phi(lead_now) - Phi(lead_prev))   (Ng, Harada & Russell shaping)
 *   true death F_end = -w * gamma * Phi(lead_now)                 (Phi(terminal) = 0, so the shaping telescopes to zero over a terminal episode)
 *
 * Because it is potential-based and cancelled at terminals it cannot change which policy is optimal (no reward for sitting on a lead, none for
 * stalling, none for avoiding fights); it only re-weights the existing damage signal by the state of the fight. tanh makes a hit matter most
 * when the fight is close and least when it is already decided, and it is symmetric, so damage taken while behind costs as much as damage
 * dealt while behind is worth. Time-limit truncation is NOT cancelled (the critic bootstraps through it).
 *
 * The existing one-sided "hp_advantage" term (a per-tick bonus for any positive lead) is a different thing and is left unchanged.
 * Weight: Config.HP_DIFF_REWARD (-Drlpvp.hpDiff, 0 disables) x RewardTuning "hp_difference". Training only, never during evaluation.
 */
final class HealthDifferenceReward {
    static final double K = 2.5;
    private double prevPhi;   // potential of the previous tick; every episode starts level (20 vs 20 HP), so 0

    static double phi(double lead) { return Math.tanh(K * Math.max(-1.0, Math.min(1.0, lead))); }

    private static double weight() { return Config.HP_DIFF_REWARD * RewardTuning.get("hp_difference"); }

    void reset() { prevPhi = 0.0; }

    /**
     * Start an episode whose first state is NOT level (hard starts: low health, just-hit). The first tick's shaping must be measured from the real starting
     * potential; starting from 0 paid a one-off, action-dependent gamma*Phi(next) term (a valid potential-based shaping needs Phi(s0)). Over a terminal episode
     * the shaping then sums to -w*Phi(s0), a constant, so it cannot change which actions are better.
     */
    void reset(double startLead) { prevPhi = phi(startLead); }

    /** Shaping for one tick given the lead AFTER this tick's damage. */
    double tick(double lead) {
        double w = weight();
        double p = phi(lead);
        double f = w == 0.0 ? 0.0 : w * (Config.GAMMA * p - prevPhi);
        prevPhi = p;
        return f;
    }

    /** Call once when an episode ends in a TRUE terminal (any death): removes the remaining potential. Returns 0 for a timeout (do not call it). */
    double terminal() {
        double f = -weight() * Config.GAMMA * prevPhi;
        prevPhi = 0.0;
        return f;
    }

    double lastPotential() { return prevPhi; }
}
