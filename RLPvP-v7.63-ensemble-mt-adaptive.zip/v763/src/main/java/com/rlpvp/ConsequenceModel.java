package com.rlpvp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Random;

/**
 * Online one-step world model. It predicts the next observed combat frame from the current observation
 * and an action. It never contains technique labels or a list of preferred moves: its targets are the
 * next frame actually observed in the environment.
 *
 * v6 (measured in sim/ConsequenceProbe): the network predicts the CHANGE of every feature, scaled by that feature's
 * running residual size, instead of the absolute next frame. Regressing the absolute frame made the rare, small health
 * changes (a hit is ~0.1-0.3 of the scale) disappear under the identity-mapping error of the network: its health
 * prediction was ~7x worse than "nothing changes" and identical with or without a swing. The gradient-norm clip is 5
 * (was 1) because clip 1 damped exactly the rare hit samples.
 *
 * The planner uses these predictions only after enough held-out transitions have been seen AND the model beats the
 * persistence baseline (next = current) on health. A low average error over all 48 features is not enough: most
 * features barely change, so the old MAE gate passed a model that was worse than persistence on damage.
 * Pure Java, no Minecraft dependencies.
 */
final class ConsequenceModel {
    private static final int INPUTS = Config.OBS_SIZE + PpoAgent.N_ACT;
    private static final int OUTPUTS = Config.FRAME;
    private static final int[] SIZES = {INPUTS, 128, 128, OUTPUTS};
    private static final int MIN_TRANSITIONS_FOR_PLANNING = 20_000;
    private static final int MIN_VALIDATION_SAMPLES = 1_000;
    /** The model must beat 'health unchanged' by at least this fraction of squared error on held-out transitions. */
    private static final double MIN_HEALTH_SKILL = 0.02;
    private static final double SKILL_EMA_ALPHA = 0.005;
    private static final float SCALE_FLOOR = 0.02f;
    private static final double SCALE_EMA_ALPHA = 0.001;
    private static final float MAX_VALIDATION_MAE = 0.20f;
    private static final float LEARNING_RATE = 4e-4f;
    private static final float MAX_GRAD_NORM = 5.0f;
    private static final double EMA_ALPHA = 0.01;

    /** -Drlpvp.conseqTrain=false switches the world model's online training off everywhere (it only feeds PLAY_STACK > 0 planning, never PPO). */
    static final boolean TRAIN_DEFAULT = !"false".equalsIgnoreCase(System.getProperty("rlpvp.conseqTrain"));
    private boolean training = TRAIN_DEFAULT;
    /** Parallel training keeps only worker 0's model, so the other workers skip its (expensive) per-tick training. */
    void setTraining(boolean on) { training = on && TRAIN_DEFAULT; for (ConsequenceModel e : extra) e.setTraining(on); }

    private Net net;
    private final float[] residualVar = new float[OUTPUTS];
    private double seModel = Double.NaN, sePersist = Double.NaN;
    private final float[] input = new float[INPUTS];
    private final float[] gradient = new float[OUTPUTS];
    private final float[] prediction = new float[OUTPUTS];
    private long transitions;
    private long trainedTransitions;
    private long validationTransitions;
    private double validationMae;
    private boolean validationInitialised;

    private final Random initRng;
    /** Counter values at the last {@link #copyPersistedStateFrom}: what this replica has added since then is its own share of the pooled data (v7.57). */
    private long syncTransitions, syncTrained, syncValidation;

    /** v7.63 ENSEMBLE: total members including this one (-Drlpvp.ensemble=N, 1 = single model as before). The extra members are independent copies of this
     *  network (own seed, each trained on a random ~ENS_BOOT share of the transitions) held in {@link #extra}; the planner trusts a prediction only when they agree. */
    static final int ENSEMBLE = Math.max(1, Math.min(8, Integer.getInteger("rlpvp.ensemble", 3)));
    static final double ENS_BOOT = Double.parseDouble(System.getProperty("rlpvp.ensemble.boot", "0.5"));
    private final ConsequenceModel[] extra;
    private final Random bootRng = new Random(0xB007L);

    ConsequenceModel(Random rng) { this(rng, ENSEMBLE); }

    private ConsequenceModel(Random rng, int members) {
        initRng = rng;
        net = new Net(SIZES, 0.08f, rng);
        java.util.Arrays.fill(residualVar, SCALE_FLOOR * SCALE_FLOOR);
        extra = new ConsequenceModel[Math.max(0, members - 1)];
        for (int j = 0; j < extra.length; j++) extra[j] = new ConsequenceModel(new Random(0x7E57_0000L + 7919L * (j + 1)), 1);   // fixed seeds: the main rng stream (and so every existing seed's weights) is untouched
    }

    int members() { return 1 + extra.length; }
    boolean hasExtras() { return extra.length > 0; }

    private float scale(int i) { return (float) Math.max(SCALE_FLOOR, Math.sqrt(residualVar[i])); }

    /** Learns from the real consequence of the action that was taken. */
    void observe(float[] observation, float[] action, float[] nextObservation) {
        if (!training) return;
        if (observation == null || action == null || nextObservation == null
                || observation.length < Config.OBS_SIZE || action.length < PpoAgent.N_ACT
                || nextObservation.length < Config.FRAME) return;
        for (ConsequenceModel e : extra) if (bootRng.nextDouble() < ENS_BOOT) e.observe(observation, action, nextObservation);
        pack(observation, action);
        transitions++;
        if (transitions % 10 != 0 && Config.CONSEQUENCE_TRAIN_EVERY > 1 && transitions % Config.CONSEQUENCE_TRAIN_EVERY != 0) return; // cheaper: train on every Nth transition
        float[] pred = net.forward(input);
        if (transitions % 10 == 0) { // held-out sample: scored, never trained on
            double mae = 0, sm = 0, sp = 0;
            for (int i = 0; i < OUTPUTS; i++) {
                float t = clampTarget(nextObservation[i], i);
                float p = clampTarget(observation[i] + scale(i) * pred[i], i);
                mae += Math.abs(p - t);
                if (i == 0 || i == 15) { // own / enemy health: what the planner's damage term is built from
                    sm += (p - t) * (double) (p - t);
                    sp += (observation[i] - t) * (double) (observation[i] - t);
                }
            }
            mae /= OUTPUTS;
            validationMae = validationInitialised ? (1.0 - EMA_ALPHA) * validationMae + EMA_ALPHA * mae : mae;
            seModel = Double.isNaN(seModel) ? sm : (1.0 - SKILL_EMA_ALPHA) * seModel + SKILL_EMA_ALPHA * sm;
            sePersist = Double.isNaN(sePersist) ? sp : (1.0 - SKILL_EMA_ALPHA) * sePersist + SKILL_EMA_ALPHA * sp;
            validationInitialised = true;
            validationTransitions++;
            return;
        }
        for (int i = 0; i < OUTPUTS; i++) {
            float r = clampTarget(nextObservation[i], i) - observation[i];
            residualVar[i] = (float) ((1.0 - SCALE_EMA_ALPHA) * residualVar[i] + SCALE_EMA_ALPHA * r * r);
            gradient[i] = 2f * (pred[i] - r / scale(i)) / OUTPUTS;
        }
        net.backward(gradient);
        net.step(LEARNING_RATE, MAX_GRAD_NORM, 1);
        trainedTransitions++;
    }

    /** Predicts the next 48-float frame. Output is bounded to valid observation ranges. */
    void predict(float[] observation, float[] action, float[] outFrame) {
        pack(observation, action);
        float[] raw = net.forward(input);
        for (int i = 0; i < OUTPUTS; i++) outFrame[i] = clampTarget(observation[i] + scale(i) * raw[i], i);
    }

    /** Member {@code m} (0 = this model) predicts the next frame. */
    void predictMember(int m, float[] observation, float[] action, float[] outFrame) {
        if (m == 0) predict(observation, action, outFrame); else extra[m - 1].predict(observation, action, outFrame);
    }

    /** True when every member has seen enough held-out data and beats 'nothing changes' on health: only then may the ensemble planner act. */
    boolean ensembleReady() {
        if (extra.length == 0 || !planningReady()) return false;
        for (ConsequenceModel e : extra) if (!e.planningReady()) return false;
        return true;
    }

    private void pack(float[] observation, float[] action) {
        System.arraycopy(observation, 0, input, 0, Config.OBS_SIZE);
        System.arraycopy(action, 0, input, Config.OBS_SIZE, PpoAgent.N_ACT);
    }

    private static float clampTarget(float value, int feature) {
        if (Float.isNaN(value) || Float.isInfinite(value)) return 0f;
        // Health, cooldowns, timers and boolean flags are non-negative fractions.
        switch (feature) {
            case 0: case 4: case 5: case 6: case 7: case 15: case 19: case 20: case 22: case 23:
            case 24: case 25: case 26: case 34: case 35: case 36: case 37: case 38: case 39:
            case 42: case 43: case 44: case 45: case 46: case 48: case 49: case 50: // 48-50: sneak features (0/1)
                return Math.max(0f, Math.min(1f, value));
            default:
                return Math.max(-1f, Math.min(1f, value));
        }
    }

    boolean planningReady() {
        return transitions >= MIN_TRANSITIONS_FOR_PLANNING
                && validationTransitions >= MIN_VALIDATION_SAMPLES
                && validationInitialised && validationMae <= MAX_VALIDATION_MAE
                && healthSkill() >= MIN_HEALTH_SKILL;
    }

    /** 1 - (model squared error / persistence squared error) on health, held-out. >0 means better than 'nothing changes'. */
    double healthSkill() {
        return Double.isNaN(seModel) || Double.isNaN(sePersist) || sePersist <= 1e-12 ? Double.NaN : 1.0 - seModel / sePersist;
    }

    long transitions() { return transitions; }
    long trainedTransitions() { return trainedTransitions; }
    long validationTransitions() { return validationTransitions; }
    double validationMae() { return validationInitialised ? validationMae : Double.NaN; }

    /** Copies the persisted state exactly, without a serialize/deserialize allocation cycle. */
    void copyPersistedStateFrom(ConsequenceModel source) {
        if (source == this) return;
        transitions = source.transitions;
        trainedTransitions = source.trainedTransitions;
        validationTransitions = source.validationTransitions;
        validationMae = source.validationMae;
        validationInitialised = source.validationInitialised;
        seModel = source.seModel;
        sePersist = source.sePersist;
        System.arraycopy(source.residualVar, 0, residualVar, 0, residualVar.length);
        net.copyPersistedStateFrom(source.net);
        for (int j = 0; j < extra.length && j < source.extra.length; j++) extra[j].copyPersistedStateFrom(source.extra[j]);
        syncTransitions = transitions; syncTrained = trainedTransitions; syncValidation = validationTransitions;
    }

    /** Test hook. */
    float[] debugWeights() { return net.w; }

    /**
     * v7.57 POOLED WORLD MODEL. Every parallel worker trains its own replica of this model on its own transitions (all replicas start each round from the same state); this
     * folds them into {@code dst}: network weights and Adam moments are averaged (local SGD with a synchronisation every round), the running residual scales and the held-out
     * error statistics are averaged, and the transition counters are the old total plus what each replica added since its last synchronisation. {@code dst} must NOT be one of
     * the replicas. Afterwards the caller copies {@code dst} back into every replica (copyPersistedStateFrom), which resets their "added since" counters.
     */
    static void pool(ConsequenceModel dst, java.util.List<ConsequenceModel> replicas) {
        if (replicas.isEmpty()) return;
        java.util.List<Net> nets = new java.util.ArrayList<>(replicas.size());
        long dT = 0, dTr = 0, dV = 0;
        double seM = 0, seP = 0, mae = 0;
        int nSe = 0, nMae = 0;
        float[] rv = new float[OUTPUTS];
        for (ConsequenceModel r : replicas) {
            if (r == dst) throw new IllegalArgumentException("the destination must not be one of the replicas");
            nets.add(r.net);
            dT += r.transitions - r.syncTransitions; dTr += r.trainedTransitions - r.syncTrained; dV += r.validationTransitions - r.syncValidation;
            if (!Double.isNaN(r.seModel) && !Double.isNaN(r.sePersist)) { seM += r.seModel; seP += r.sePersist; nSe++; }
            if (r.validationInitialised) { mae += r.validationMae; nMae++; }
            for (int i = 0; i < OUTPUTS; i++) rv[i] += r.residualVar[i];
        }
        dst.net.setAverageOf(nets);
        for (int i = 0; i < OUTPUTS; i++) dst.residualVar[i] = rv[i] / replicas.size();
        if (nSe > 0) { dst.seModel = seM / nSe; dst.sePersist = seP / nSe; }
        if (nMae > 0) { dst.validationMae = mae / nMae; dst.validationInitialised = true; }
        dst.transitions += dT; dst.trainedTransitions += dTr; dst.validationTransitions += dV;
        dst.syncTransitions = dst.transitions; dst.syncTrained = dst.trainedTransitions; dst.syncValidation = dst.validationTransitions;
        for (int j = 0; j < dst.extra.length; j++) {   // the ensemble members are pooled the same way, member by member
            java.util.List<ConsequenceModel> rj = new java.util.ArrayList<>(replicas.size());
            for (ConsequenceModel r : replicas) if (j < r.extra.length) rj.add(r.extra[j]);
            pool(dst.extra[j], rj);
        }
    }

    /** v7.63 trailer payload: member count, then every EXTRA member in the normal single-model layout. */
    void writeEnsemble(DataOutputStream out) throws IOException {
        out.writeInt(extra.length);
        for (ConsequenceModel e : extra) e.write(out);
    }

    /** Reads {@link #writeEnsemble}. A different member count than this build's is fine: extra stored members beyond ours are read and dropped, missing ones stay fresh. */
    void resetExtras() { for (int j = 0; j < extra.length; j++) extra[j] = new ConsequenceModel(new Random(0x7E57_0000L + 7919L * (j + 1)), 1); }

    void readEnsemble(DataInputStream in) throws IOException {
        try { readEnsembleInner(in); } catch (IOException | RuntimeException e) { resetExtras(); throw e; }   // all or nothing
    }

    private void readEnsembleInner(DataInputStream in) throws IOException {
        int n = in.readInt();
        if (n < 0 || n > 16) throw new IOException("implausible ensemble size " + n);
        ConsequenceModel scratch = null;
        for (int j = 0; j < n; j++) {
            ConsequenceModel target = j < extra.length ? extra[j] : (scratch = new ConsequenceModel(new Random(1), 1));
            target.read(in, 7);
        }
    }

    /** Test/diagnostic summary: per member {transitions, held-out samples, health skill}. */
    String ensembleStatus() {
        StringBuilder b = new StringBuilder(String.format(java.util.Locale.ROOT, "members %d: [0] n=%d skill=%.2f", members(), transitions, healthSkill()));
        for (int j = 0; j < extra.length; j++) b.append(String.format(java.util.Locale.ROOT, " [%d] n=%d skill=%.2f", j + 1, extra[j].transitions, extra[j].healthSkill()));
        return b.toString();
    }

    void write(DataOutputStream out) throws IOException {
        out.writeLong(transitions);
        out.writeLong(trainedTransitions);
        out.writeLong(validationTransitions);
        out.writeBoolean(validationInitialised);
        out.writeDouble(validationMae);
        out.writeDouble(seModel);
        out.writeDouble(sePersist);
        for (int i = 0; i < OUTPUTS; i++) out.writeFloat(residualVar[i]);
        net.write(out);
    }

    /**
     * Consumes and DISCARDS the consequence section of a save with the layout before sneak (inputs and frame size differ, so the old weights
     * cannot be used); the model stays fresh and re-learns online within minutes. Actor and critic are migrated, not discarded.
     */
    void readDiscardingOldLayout(DataInputStream in, int version, int oldInputs, int oldOutputs) throws IOException {
        in.readLong(); in.readLong(); in.readLong(); in.readBoolean(); in.readDouble();
        if (version >= 6) {
            in.readDouble(); in.readDouble();
            for (int i = 0; i < oldOutputs; i++) in.readFloat();
        }
        int[] old = SIZES.clone();
        old[0] = oldInputs;
        old[old.length - 1] = oldOutputs;
        new Net(old, 0.08f, new Random(0)).read(in);
    }

    /** Consumes and discards a consequence model whose observation input layout predates optional OBS_V2 features. */
    void readDiscardingOldInputLayout(DataInputStream in, int version, int oldObsSize, int oldActionSize) throws IOException {
        in.readLong(); in.readLong(); in.readLong(); in.readBoolean(); in.readDouble();
        if (version >= 6) {
            in.readDouble(); in.readDouble();
            for (int i = 0; i < OUTPUTS; i++) in.readFloat();
        }
        int[] old = SIZES.clone(); old[0] = oldObsSize + oldActionSize;
        new Net(old, 0.08f, new Random(0)).read(in);
        // Keep the newly constructed model untrained; its input layout differs and its validation statistics are no longer comparable.
    }

    /** Reads the current layout (state v6 and v7 store the same section). */
    void read(DataInputStream in) throws IOException { read(in, 7); }

    /**
     * State v5 stored an absolute-target network whose weights mean something different now. Its statistics and weights are
     * read (to keep the stream aligned) and DISCARDED: the model restarts untrained and re-learns online within minutes.
     * The actor and critic are not affected.
     */
    void read(DataInputStream in, int version) throws IOException {
        long tr = in.readLong(), trained = in.readLong(), val = in.readLong();
        boolean init = in.readBoolean();
        double mae = in.readDouble();
        if (tr < 0 || trained < 0 || val < 0 || (init && (Double.isNaN(mae) || Double.isInfinite(mae) || mae < 0)))
            throw new IOException("invalid consequence-model statistics");
        if (version >= 6) {
            transitions = tr; trainedTransitions = trained; validationTransitions = val; validationInitialised = init; validationMae = mae;
            seModel = in.readDouble();
            sePersist = in.readDouble();
            for (int i = 0; i < OUTPUTS; i++) {
                residualVar[i] = in.readFloat();
                if (Float.isNaN(residualVar[i]) || residualVar[i] < 0f) throw new IOException("invalid consequence-model scale");
            }
            net.read(in);
        } else {
            net.read(in);                                   // consume the old weights
            net = new Net(SIZES, 0.08f, initRng);           // ...and start from a clean, untrained model
        }
    }
}
