package com.rlpvp;

import java.nio.file.Path;
import java.nio.file.Files;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * Multi-environment training: K simulators run in parallel threads (one acting copy of the agent each), then ONE learner updates on all their
 * rollouts, then the new weights go back to the copies. Same curriculum, rewards, collapse guard and checkpoint format as PvpSim.main, but
 * about K times the experience per second on a K-core machine.
 *
 * Round = (1) every worker plays until its rollout (Config.ROLLOUT ticks) is full, in parallel; (2) all workers are stopped; the learner takes
 * the rollouts one after another and runs the usual PPO epochs (learnTick); (3) the learner's weights are copied to the workers. Nothing writes
 * weights while a thread is reading them, so there are no locks apart from the shared curriculum (its methods are synchronized).
 *
 * Differences from the single-environment run, all deliberate:
 *  - the later rollouts of a round were collected by weights that are 1..K-1 updates old (PPO's clipping + stored log-probs absorb that);
 *  - probes and the collapse guard run on a separate probe copy between rounds, and a rollback/demotion is copied into the learner;
 *  - the consequence (world) model of the saved checkpoint is worker 0's (trained on 1/K of the transitions);
 *  - runs are not bit-reproducible (episode completion order across threads varies).
 * Usage: ParallelPvpTrain <totalTicks> <out.bin> [seed] [resume.bin|-] [workers] [rival.bin|-]
 */
public final class ParallelPvpTrain {
    static final boolean POOL_WORLD = !"false".equalsIgnoreCase(System.getProperty("sim.poolWorld", "true"));
    private static final class Worker {
        final PpoAgent agent;
        final PvpSim sim;
        boolean inEp;
        long base;
        Worker(PpoAgent a, PvpSim s) { agent = a; sim = s; }
    }

    private static void collect(Worker w) {
        while (!Thread.currentThread().isInterrupted() && !w.agent.learnerBusy()) { // until rollout full or shutdown requested
            w.sim.syncCurriculum();
            if (!w.inEp) { w.sim.startEpisode(); w.inEp = true; }
            w.inEp = w.sim.step(true, null);
        }
    }

    public static void main(String[] args) throws Exception {
        // v7.63: the learner (about 90% of a round) shards each PPO minibatch over up to 4 threads; collection and learning never overlap, so the cores are free. -Drlpvp.learnThreads=1 restores the exact old summation order.
        if (System.getProperty("rlpvp.learnThreads") == null) System.setProperty("rlpvp.learnThreads", String.valueOf(Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()))));
        long total = Long.parseLong(args[0]);
        Path out = Path.of(args[1]);
        long seed = args.length > 2 ? Long.parseLong(args[2]) : 1;
        Path resumePath = args.length > 3 && !args[3].equals("-") ? Path.of(args[3]) : null;
        Path leagueFile = configureLeagueStorage(out, resumePath);
        PpoAgent master = resumePath != null ? PpoAgent.loadMain(resumePath, seed) : new PpoAgent(seed);
        int k = args.length > 4 ? Integer.parseInt(args[4]) : Math.max(1, Math.min(Integer.getInteger("sim.maxWorkers", 8), Runtime.getRuntime().availableProcessors() - 1)); // default cap 8; raise with -Dsim.maxWorkers=16 on a bigger CPU
        FrozenPolicy rival = args.length > 5 && !args[5].equals("-") ? new FrozenPolicy(PpoAgent.load(Path.of(args[5]), seed + 7)) : null;
        boolean mirror = !"false".equals(System.getProperty("sim.mirror"));
        double lookAlpha = Double.parseDouble(System.getProperty("sim.lookalpha", String.valueOf(Config.LOOK_SMOOTH)));

        Curriculum shared = new Curriculum();
        if (master.stage > 0) shared.restore(master.stage, master.stageEnterTicks);

        // All parallel environments must update the same synchronized Elo/PFSP ledger. Loading separate
        // copies caused last-writer-wins resets and races on the common ratings.csv/snapshot *.tmp files.
        OpponentLeague sharedLeague = new OpponentLeague();
        try { sharedLeague.load(leagueFile); }
        catch (Exception ex) { System.err.println("league ratings not loaded: " + ex.getMessage()); }
        sharedLeague.ensure("current");
        long persistedLeagueGames = sharedLeague.games("current");
        System.out.println("league persistence: " + leagueFile + " (one shared ledger; saved after completed parallel rounds)");

        // v7.57 POOLED WORLD MODEL (default on, -Dsim.poolWorld=false = the old behaviour): every worker trains its own replica of the world model on its own transitions and the replicas are
        // averaged into the master's model every round, so the saved model has seen ALL workers' data (it used to be worker 0's 1/K, started fresh on every resume and then overwrote the
        // checkpoint's own model). Costs no wall time: the extra training runs inside the collection threads, which are not the bottleneck.
        final boolean poolWorld = POOL_WORLD;
        List<Worker> workers = new ArrayList<>();
        final PvpSim.HardStartMix hardMix = PvpSim.HARD_ADAPTIVE ? new PvpSim.HardStartMix() : null;   // v7.63: one table for all workers
        for (int i = 0; i < k; i++) {
            PpoAgent a = new PpoAgent(seed + 100 + i);
            a.adoptFrom(master);
            if (poolWorld) a.adoptConsequenceFrom(master);   // common starting point for the averaging (and the checkpoint's model survives a resume)
            a.setConsequenceTraining(poolWorld || i == 0); // old behaviour: only worker 0's world model is kept (adoptConsequenceFrom); the others' training was thrown away
            PvpSim s = new PvpSim(seed + 1 + i, a, sharedLeague, i == 0);
            s.cur = shared; s.hardMix = hardMix;
            s.weaknessStyles = true;
            s.mirrorOn = mirror; s.lookAlpha = lookAlpha; s.rival = rival == null ? null : rival.copy();   // v7.62: one private copy per worker (FrozenPolicy keeps scratch buffers and a Random, so sharing one is a data race)
            if (Float.isFinite(master.botDifficulty)) s.botDiff.set(master.botDifficulty);   // v7.63: resume from the saved bot difficulty
            Worker w = new Worker(a, s);
            w.base = master.totalTicks;
            workers.add(w);
        }
        PpoAgent probeAgent = new PpoAgent(seed + 999);
        probeAgent.adoptFrom(master);
        PvpSim probeSim = new PvpSim(seed + 998, probeAgent, sharedLeague, false);
        probeSim.cur = shared; probeSim.mirrorOn = mirror; probeSim.lookAlpha = lookAlpha; probeSim.rival = rival == null ? null : rival.copy();

        ExecutorService pool = Executors.newFixedThreadPool(k);
        ChampionEvaluator champion = new ChampionEvaluator(out);
        long logInterval = Long.getLong("rlpvp.trainLogInterval", 25_000L);
        if (logInterval < 1) throw new IllegalArgumentException("rlpvp.trainLogInterval must be >= 1");
        long start = System.currentTimeMillis(), nextLog = (master.totalTicks / logInterval + 1) * logInterval,
            nextProbe = master.totalTicks + Config.GREEDY_PROBE_TICKS;
        master.staleKlBaseline = !"false".equalsIgnoreCase(System.getProperty("rlpvp.staleKlBaseline"));
        final boolean headBoostSync = !"false".equalsIgnoreCase(System.getProperty("rlpvp.parallelHeadBoost"));
        long collectNs = 0, learnNs = 0, exploiterNs = 0, exploiterTicks = 0, mainTicksWindow = 0;
        // v7.53 learner exploiters (off unless -Dsim.exploiter.share > 0): see Exploiters below
        final Exploiters exploiters = Exploiters.fromProperties(seed);
        int mainRoundsSincePhase = 0;
        final BrakeFade brakeFade = BrakeFade.fromProperties(out, master.savedBrakeStrength);   // v7.55 (off unless -Dsim.brakeFade.ticks > 0)
        brakeFade.apply();
        float lastEntropyCoef = Config.ENTROPY_COEF;
        System.out.println("parallel training: " + k + " environments, learner at tick " + master.totalTicks + ", stage " + shared.stage());
        try {
            while (master.totalTicks < total) {
                if (exploiters.due(mainRoundsSincePhase, shared.stage(), master)) {
                    long te = System.nanoTime();
                    exploiterTicks += exploiters.runPhase(master, workers, pool, shared, sharedLeague, lastEntropyCoef, headBoostSync);
                    exploiterNs += System.nanoTime() - te;
                    mainRoundsSincePhase = 0;
                    continue;
                }
                // (1) experience, in parallel
                long t0 = System.nanoTime();
                List<Future<?>> fs = new ArrayList<>();
                for (Worker w : workers) fs.add(pool.submit(() -> collect(w)));
                for (Future<?> f : fs) f.get();           // rethrows a worker's exception: never silently train on fewer environments
                collectNs += System.nanoTime() - t0;
                t0 = System.nanoTime();

                // Worker episodes update the shared league concurrently. Once every rollout is joined,
                // persist any new decided matches so an exception/restart cannot discard the Elo results.
                long leagueGamesNow = sharedLeague.games("current");
                if (leagueGamesNow != persistedLeagueGames) {
                    sharedLeague.save(leagueFile);
                    persistedLeagueGames = leagueGamesNow;
                }

                // (2) learning, one thread, nobody else touches weights now
                long gained = 0;
                for (Worker w : workers) gained += w.agent.totalTicks - w.base;
                master.totalTicks += gained;
                brakeFade.advance(gained, shared.stage());
                mainTicksWindow += gained;
                mainRoundsSincePhase++;
                shared.update(master.totalTicks);
                master.setMask(shared.lockMask());
                master.stage = shared.autoStage();
                master.stageEnterTicks = shared.stageEnterTicks();
                float ema = 0; for (Worker w : workers) ema += w.sim.entropyEma; ema /= workers.size();
                float coef = Config.ENTROPY_COEF * shared.entropyScale(master.totalTicks);
                double floor = Config.ENTROPY_FLOOR_FRAC * PpoAgent.maxEntropy(shared.lockMask());
                if (ema > 0 && ema < floor) coef *= Config.ENTROPY_FLOOR_BOOST;
                coef *= Config.stageEntropyScale(shared.stage(), master.totalTicks, shared.stageEnterTicks());
                master.setEntropyCoef(coef);
                lastEntropyCoef = coef;
                master.lateLrScale = Config.stageLrScale(shared.stage(), master.totalTicks, shared.stageEnterTicks());
                if (headBoostSync) {
                    List<PpoAgent> agents = new ArrayList<>();
                    for (Worker w : workers) agents.add(w.agent);
                    master.syncHeadBoostFrom(agents);
                }
                for (Worker w : workers) {
                    if (w.agent.handRolloutTo(master)) { while (master.learnerBusy()) master.learnTick(); }
                }
                if (ConsequenceModel.TRAIN_DEFAULT) {   // off: keep the checkpoint's own model
                    if (poolWorld) {
                        List<PpoAgent> replicas = new ArrayList<>();
                        for (Worker w : workers) replicas.add(w.agent);
                        master.poolConsequencesFrom(replicas);
                        for (Worker w : workers) w.agent.adoptConsequenceFrom(master);
                    } else master.adoptConsequenceFrom(workers.get(0).agent);
                }
                learnNs += System.nanoTime() - t0;

                // Snapshot the probe guard at the stage transition, not at the first scheduled probe much later.
                if (probeSim.guard.stage() != shared.stage()) {
                    probeAgent.adoptFrom(master);
                    probeSim.guard.noteStage(shared.stage(), probeAgent);
                }

                // (3) probe + collapse guard on the probe copy (between rounds, single thread), then push the weights back
                if (master.totalTicks >= nextProbe && shared.stage() >= 3 && shared.stage() < 9) {
                    probeAgent.adoptFrom(master);
                    probeSim.syncCurriculum();
                    probeSim.probe();
                    nextProbe = master.totalTicks + Config.GREEDY_PROBE_TICKS;
                    String lp = probeSim.lastProbe == null ? "" : probeSim.lastProbe;
                    if (lp.contains("ROLLBACK") || lp.contains("DEMOTED")) {   // the guard restored weights: the learner takes them over
                        master.importWeights(probeAgent.exportWeights());
                        master.lrScale = probeAgent.lrScale;
                        master.stage = shared.autoStage();
                        master.stageEnterTicks = shared.stageEnterTicks();
                        if (lp.contains("DEMOTED")) for (Worker w : workers) w.sim.botDiff.set(0.0);
                    }
                }
                for (Worker w : workers) { w.agent.adoptFrom(master); w.base = master.totalTicks; }

                // Stage 9 evaluation is independent and non-gating. It benchmarks an immutable copy while
                // the workers continue collecting the next rollout; it never rolls back or blocks PPO updates.
                champion.poll();
                champion.maybeLaunch(master, shared.stage());

                if (master.totalTicks >= nextLog) {
                    nextLog += logInterval;
                    String brakeLine = brakeFade.endWindow(workers, shared.stage());
                    if (brakeLine != null) System.out.println("    " + brakeLine);
                    log(master, workers, probeSim, shared, sharedLeague, champion, out, (System.currentTimeMillis() - start) / 1000);
                    stampDifficulty(master, workers);
                    master.save(out);
                    {   // v7.60: hard-start episodes are excluded from every statistic above; their own results, per kind, summed over the workers
                        java.util.List<PvpSim> hsSims = new java.util.ArrayList<>();
                        for (Worker hw : workers) hsSims.add(hw.sim);
                        System.out.println("    " + PvpSim.hardStartTallyAndReset(hsSims) + (hardMix == null ? "" : "  [" + hardMix.describe() + "]"));
                    }
                    double tot = Math.max(1.0, collectNs + learnNs);
                    if (exploiters.enabled()) {
                        double secAll = Math.max(1e-9, (collectNs + learnNs + exploiterNs) / 1e9);
                        System.out.printf(Locale.ROOT, "    exploiters: %s | raw simulator ticks/s %.0f (main %d + exploiter %d ticks in %.0fs; exploiter phases took %.0fs of that)%n",
                            exploiters.status(sharedLeague, workers.get(0).sim.exploiterIds), (mainTicksWindow + exploiterTicks) / secAll, mainTicksWindow, exploiterTicks, secAll, exploiterNs / 1e9);
                        exploiterNs = 0; exploiterTicks = 0; mainTicksWindow = 0;
                    }
                    System.out.printf(Locale.ROOT, "    timing: collect %.0fs, learner %.0fs (%.0f%% of round time on the learner threads) | rollouts trained %d, cut short %d, lrScale %.2f%n",
                        collectNs / 1e9, learnNs / 1e9, 100.0 * learnNs / tot, master.updates, master.skipped, master.lrScale);
                    collectNs = learnNs = 0;
                }
            }
        } finally {
            pool.shutdownNow();
            // collect() observes interruption between simulator steps. Join workers before the final
            // league save so no in-flight episode can update Elo after the ledger has been written.
            try {
                if (!pool.awaitTermination(30, TimeUnit.SECONDS)) {
                    System.err.println("WARNING: training workers did not terminate within 30 seconds; final league save may omit an in-flight episode");
                }
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                System.err.println("WARNING: interrupted while joining training workers; attempting final checkpoint and league saves");
            }
            stampDifficulty(master, workers);
            try { master.save(out); }
            finally {
                try { sharedLeague.save(leagueFile); }
                finally { champion.close(); }
            }
        }
        System.out.println("saved " + out + " at " + master.totalTicks + " ticks, stage " + master.stage
            + " | " + champion.status());
    }

    /**
     * Parallel training uses a checkpoint-specific sidecar, matching PvpSim.main. On a resume, seed a new
     * output sidecar from the resume checkpoint's companion league rather than silently starting at 1200 Elo.
     * Only the ratings ledger and the newest LEAGUE_POOL policy snapshots are copied (older policies are pruned anyway).
     */
    /** v7.63: the checkpoint carries the (mean) bot difficulty of the workers. */
    private static void stampDifficulty(PpoAgent master, List<Worker> workers) {
        double sum = 0; for (Worker w : workers) sum += w.sim.botDiff.value();
        if (!workers.isEmpty()) master.botDifficulty = (float) (sum / workers.size());
    }

    static Path configureLeagueStorage(Path out, Path resume) throws IOException {
        String dirOverride = System.getProperty("sim.league.dir");
        String fileOverride = System.getProperty("sim.league.file");
        Path leagueDir;
        Path leagueFile;
        if (dirOverride == null && fileOverride == null) {
            Path absoluteOut = out.toAbsolutePath();
            leagueDir = absoluteOut.resolveSibling(absoluteOut.getFileName().toString() + ".league");
            if (!Files.exists(leagueDir) && resume != null) {
                Path absoluteResume = resume.toAbsolutePath();
                Path resumeDir = absoluteResume.resolveSibling(absoluteResume.getFileName().toString() + ".league");
                if (Files.isDirectory(resumeDir)) copyLeagueSeed(resumeDir, leagueDir);
            }
            Files.createDirectories(leagueDir);
            leagueFile = leagueDir.resolve("ratings.csv");
        } else {
            if (dirOverride != null) leagueDir = Path.of(dirOverride).toAbsolutePath();
            else leagueDir = Path.of(fileOverride).toAbsolutePath().getParent();
            if (leagueDir == null) leagueDir = Path.of(".").toAbsolutePath();
            leagueFile = fileOverride != null ? Path.of(fileOverride).toAbsolutePath() : leagueDir.resolve("ratings.csv");
            Files.createDirectories(leagueDir);
        }
        System.setProperty("sim.league.dir", leagueDir.toString());
        System.setProperty("sim.league.file", leagueFile.toString());
        String leagueWarning = OpponentLeague.checkVersion(leagueDir, leagueFile);
        if (leagueWarning != null) System.out.println(leagueWarning);
        return leagueFile;
    }

    private static void copyLeagueSeed(Path sourceDir, Path targetDir) throws IOException {
        Files.createDirectories(targetDir);
        Path sourceRatings = sourceDir.resolve("ratings.csv");
        if (Files.isRegularFile(sourceRatings)) Files.copy(sourceRatings, targetDir.resolve("ratings.csv"));
        Path sourceMarker = sourceDir.resolve(OpponentLeague.VERSION_FILE);
        if (Files.isRegularFile(sourceMarker)) Files.copy(sourceMarker, targetDir.resolve(OpponentLeague.VERSION_FILE));
        Path sourceExploiters = PvpSim.exploiterDir(sourceDir);
        if (Files.isDirectory(sourceExploiters)) {
            Files.createDirectories(PvpSim.exploiterDir(targetDir));
            try (var paths = Files.list(sourceExploiters)) {
                for (Path src : paths.filter(f -> f.getFileName().toString().matches("exploiter-[0-9]+\\.bin")).toList())
                    Files.copy(src, PvpSim.exploiterDir(targetDir).resolve(src.getFileName().toString()), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        }
        Path sourceSnapshots = sourceDir.resolve("snapshots");
        if (!Files.isDirectory(sourceSnapshots)) return;
        List<Path> snapshots;
        try (var paths = Files.list(sourceSnapshots)) {
            snapshots = paths.filter(p -> p.getFileName().toString().matches("snapshot-[0-9]+\\.bin"))
                .sorted(Comparator.comparingLong(ParallelPvpTrain::snapshotTick)).toList();
        }
        Path targetSnapshots = targetDir.resolve("snapshots");
        Files.createDirectories(targetSnapshots);
        int first = Math.max(0, snapshots.size() - Config.LEAGUE_POOL);
        for (int i = first; i < snapshots.size(); i++) {
            Path src = snapshots.get(i);
            Files.copy(src, targetSnapshots.resolve(src.getFileName().toString()));
        }
    }

    private static long snapshotTick(Path path) {
        String name = path.getFileName().toString();
        try { return Long.parseLong(name.substring("snapshot-".length(), name.length() - ".bin".length())); }
        catch (RuntimeException ex) { return Long.MIN_VALUE; }
    }

    private static void log(PpoAgent master, List<Worker> ws, PvpSim probeSim, Curriculum shared,
                            OpponentLeague sharedLeague, ChampionEvaluator champion, Path checkpointOut, long sec) {
        int ep = 0, win = 0, loss = 0, draw = 0, noContest = 0, hits = 0, crit = 0, sprint = 0, swing = 0, whiff = 0, lookN = 0;
        double dealt = 0, taken = 0, ret = 0, look = 0, ent = 0, rtt = 0, c2s = 0, s2c = 0;
        long netMoves = 0, netAttacks = 0, netCorrections = 0, netRetries = 0;
        long netDuplicate = 0, netSpeedReject = 0, netInvalid = 0;
        String msg = "";
        Reward.Telemetry rewardAudit = new Reward.Telemetry();
        TechniqueDiscovery techniqueAudit = new TechniqueDiscovery();
        TechniqueOpportunityAudit techniqueOpportunityAudit = new TechniqueOpportunityAudit();
        for (Worker w : ws) {
            PvpSim s = w.sim;
            ep += s.wEp; win += s.wWin; loss += s.wLoss; draw += s.wDraw; noContest += s.wNoContest; hits += s.wHits; crit += s.wCrit; sprint += s.wSprint; swing += s.wSwing; whiff += s.wWhiff;
            dealt += s.wDealt; taken += s.wTaken; ret += s.wRet; look += s.wLook; lookN += s.wLookN; ent += s.entropyEma;
            rtt += s.networkProfileCount == 0 ? 0 : s.networkRttSumMs / s.networkProfileCount;
            c2s += s.networkProfileCount == 0 ? 0 : s.networkC2sSumMs / s.networkProfileCount;
            s2c += s.networkProfileCount == 0 ? 0 : s.networkS2cSumMs / s.networkProfileCount;
            netMoves += s.movementPackets; netAttacks += s.attackPackets; netCorrections += s.movementCorrections;
            netDuplicate += s.movementDuplicateRejections; netSpeedReject += s.movementSpeedRejections;
            netInvalid += s.movementInvalidRejections; netRetries += s.networkRetransmissions();
            if (!s.lastStageMsg.isEmpty() && msg.isEmpty()) msg = s.lastStageMsg;
            s.lastStageMsg = "";
            rewardAudit.mergeWindow(s.rewardTelemetry); s.rewardTelemetry.clearWindow();
            techniqueAudit.mergeWindow(s.disc); s.disc.clearWindow();
            techniqueOpportunityAudit.mergeWindow(s.techniqueOpportunityAudit); s.techniqueOpportunityAudit.clearWindow();
            s.wEp = s.wWin = s.wLoss = s.wDraw = s.wNoContest = s.wHits = s.wCrit = s.wSprint = s.wSwing = s.wWhiff = 0; s.wDealt = s.wTaken = s.wRet = s.wLook = 0; s.wLookN = 0;
        }
        int n = Math.max(1, ep);
        String rewardRow = rewardAudit.csvRow(master.totalTicks, ep);
        String techniqueRow = techniqueAudit.csvRow(master.totalTicks, shared.stage());
        String techniqueOpportunityRow = techniqueOpportunityAudit.csvRow(master.totalTicks, shared.stage());
        String rewardSummary = rewardAudit.summaryAndReset();
        String techniqueSummary = techniqueAudit.summary();
        String techniqueOpportunitySummary = techniqueOpportunityAudit.summary();
        appendAuditRow(checkpointOut.resolveSibling(checkpointOut.getFileName() + ".reward-audit.csv"),
            Reward.Telemetry.csvHeader(), rewardRow);
        appendAuditRow(checkpointOut.resolveSibling(checkpointOut.getFileName() + ".technique-audit-v2.csv"),
            TechniqueDiscovery.csvHeader(), techniqueRow);
        appendAuditRow(checkpointOut.resolveSibling(checkpointOut.getFileName() + ".technique-opportunity-audit.csv"),
            TechniqueOpportunityAudit.csvHeader(), techniqueOpportunityRow);
        System.out.printf(Locale.ROOT, "tick %7d [%4ds] stage %d | eps %3d win %3.0f%% loss %3.0f%% draw %3.0f%% no-contest %3.0f%% dealt %4.1f taken %4.1f ret %6.1f | hits %d crit %d sprint %d whiff %2.0f%% | cam %.2f deg/t | ent %.2f %s%n",
            master.totalTicks, sec, shared.stage(), ep, 100.0 * win / n, 100.0 * loss / n, 100.0 * draw / n, 100.0 * noContest / n, dealt / n, taken / n, ret / n, hits, crit, sprint,
            100.0 * whiff / Math.max(1, swing), look / Math.max(1, lookN), ent / ws.size(),
            msg + "  " + (shared.stage() < 9 ? probeSim.lastProbe + " | " : "") + shared.status() + " | league " + sharedLeague.summary("current")
                + (shared.stage() >= Config.WEAKNESS_FROM_STAGE ? " | " + sharedLeague.weaknessSummary("current") : "") + (shared.stage() >= 9 ? " | " + champion.status() : "") + " | " + ws.size() + " envs"
                + String.format(Locale.ROOT, " | NET RTT %.1fms C2S %.1f/S2C %.1fms move=%d atk=%d corr=%d retry=%d",
                    rtt / ws.size(), c2s / ws.size(), s2c / ws.size(), netMoves, netAttacks, netCorrections, netRetries)
                    + String.format(Locale.ROOT, " [dup=%d speed=%d invalid=%d]", netDuplicate, netSpeedReject, netInvalid)
                    + "\n    " + rewardSummary + "\n    " + techniqueSummary + "\n    " + techniqueOpportunitySummary);
        techniqueAudit.clearWindow();
        techniqueOpportunityAudit.clearWindow();
    }

    private static void appendAuditRow(Path file, String header, String row) {
        try {
            Path parent = file.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            if (!Files.exists(file)) Files.writeString(file, header + "\n", java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
            Files.writeString(file, row + "\n", java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
        } catch (IOException ex) {
            System.err.println("could not append audit file " + file + ": " + ex.getMessage());
        }
    }

    /**
     * v7.53 LEARNER EXPLOITERS. Every so often the workers stop training the main agent for a short PHASE and instead train an EXPLOITER: a throw-away learner that starts
     * from a copy of the main agent and is rewarded (the normal reward) only for beating a FROZEN copy of the main agent. Because the target never moves, the exploiter
     * finds whatever the main agent is weakest against far faster than the main league can. If it really wins (admission test), it is frozen and added to the stage 7+ league
     * as "exploiter:<tick>", where the existing PFSP / weakness-challenge sampling feeds it to the main agent like any other opponent.
     *
     * Why this does not cost TPS: a phase is the same simulator work per tick as a normal round (same environments, same number of ticks per round, one learner step per
     * rollout; the opponent is a frozen policy exactly like the league's self-play snapshots). Nothing runs beside the main loop, so there is no second set of threads competing
     * for cores. The price is paid in main-agent progress: with share=0.1 about one round in ten trains an exploiter, so the main agent sees ~10% fewer of its own ticks.
     * The main agent's weights, Adam state, curriculum, collapse guard, league ratings and counters are not touched during a phase (see PvpSim.exploiterTarget / epExploiter).
     *
     *  -Dsim.exploiter.share=0.10        fraction of rounds spent in phases (default 0.10; 0 = off; max 0.4)
     *  -Dsim.exploiter.phaseRounds=8     rounds per phase
     *  -Dsim.exploiter.minStage=7        phases start only at this stage or later (the league starts at 7)
     *  -Dsim.exploiter.admitWin=0.65     score (win=1, draw=0.5) against the frozen main agent needed over the SECOND half of the phase
     *  -Dsim.exploiter.minEpisodes=40    decided episodes needed in that half before an admission is considered
     *  -Dsim.exploiter.keep=4            finished exploiters kept in the league (oldest dropped)
     */
    static final class Exploiters {
        private final double share, admitWin;
        private final int phaseRounds, minStage, minEpisodes, keep;
        private final long seed;
        private PpoAgent learner;
        private int phases, admitted, rejected;
        /** v7.63 EXPLOITER VARIETY: a single recipe breeds one kind of exploiter, so the main agent only learns to patch that kind of hole. Phases cycle through
         *  three recipes (length x phaseRounds, entropy coef x, learning rate x), starting at a seeded offset: standard 1.0/1.0/1.0, short-sharp 0.75/0.7/1.5
         *  (quick, greedy, finds the cheap exploit), long-diverse 1.25/2.0/1.0 (slower, explores more, finds odd ones). Mean length is 1.0, so the share of
         *  rounds spent in phases is unchanged. -Dsim.exploiter.variety=false restores the single standard recipe. */
        static final boolean VARIETY = !"false".equalsIgnoreCase(System.getProperty("sim.exploiter.variety", "true"));
        static final String[] V_NAME = {"standard", "short-sharp", "long-diverse"};
        static final double[] V_LEN = {1.0, 0.75, 1.25}, V_ENT = {1.0, 0.7, 2.0}, V_LR = {1.0, 1.5, 1.0};
        int variantOf(int phaseIndex) { return VARIETY ? (int) ((phaseIndex + Math.floorMod(seed, 3L)) % 3) : 0; }
        private String last = "no phase yet";

        private Exploiters(long seed) {
            this.seed = seed;
            double sh;
            try { sh = Double.parseDouble(System.getProperty("sim.exploiter.share", "0.10")); } catch (NumberFormatException e) { sh = 0.10; }
            share = Double.isFinite(sh) ? Math.max(0.0, Math.min(0.4, sh)) : 0.10;
            phaseRounds = Math.max(2, Integer.getInteger("sim.exploiter.phaseRounds", 8));
            minStage = Integer.getInteger("sim.exploiter.minStage", 7);
            double aw;
            try { aw = Double.parseDouble(System.getProperty("sim.exploiter.admitWin", "0.65")); } catch (NumberFormatException e) { aw = 0.65; }
            admitWin = aw;
            minEpisodes = Math.max(1, Integer.getInteger("sim.exploiter.minEpisodes", 40));
            keep = Math.max(1, Integer.getInteger("sim.exploiter.keep", 4));
        }

        static Exploiters fromProperties(long seed) { return new Exploiters(seed); }
        boolean enabled() { return share > 0.0; }
        String status(OpponentLeague league, List<String> ids) {
            StringBuilder rec = new StringBuilder();
            for (String id : ids) rec.append(rec.length() == 0 ? "" : "; ").append(id).append(" main W/L/D ").append(league.matchupLine(id));
            return "share " + share + ", phases " + phases + " (admitted " + admitted + ", rejected " + rejected + "), last: " + last
                + " | main vs exploiters: " + (rec.length() == 0 ? "none yet" : rec) + (PvpSim.FAIR_FROZEN ? "" : " | WARNING: sim.fairFrozen is off, frozen opponents aim worse than the agent");
        }

        /** Main rounds between two phases so that phases take {@code share} of all rounds. */
        private int mainRoundsPerPhase() { return Math.max(1, (int) Math.round(phaseRounds * (1.0 - share) / share)); }

        boolean due(int mainRoundsSince, int stage, PpoAgent master) {
            return enabled() && stage >= minStage && master.updates > 0 && mainRoundsSince >= mainRoundsPerPhase();
        }

        /** @return the simulator ticks the phase played (for the raw-TPS report). */
        long runPhase(PpoAgent master, List<Worker> workers, ExecutorService pool, Curriculum shared, OpponentLeague league, float entropyCoef, boolean headBoostSync) throws Exception {
            if (learner == null) learner = new PpoAgent(seed + 5000);
            final PpoAgent ex = learner;
            final int variant = variantOf(phases);
            final int phaseRounds = Math.max(2, (int) Math.round(this.phaseRounds * V_LEN[variant]));
            ex.adoptFrom(master);
            ex.resetOptimizer();
            ex.setMask(shared.lockMask());
            ex.setEntropyCoef(entropyCoef * (float) V_ENT[variant]);
            ex.lateLrScale = master.lateLrScale;
            ex.lrScale = master.lrScale * (float) V_LR[variant];
            ex.staleKlBaseline = master.staleKlBaseline;
            long played = 0;
            for (int i = 0; i < workers.size(); i++) {
                Worker w = workers.get(i);
                w.sim.exploiterTarget = new FrozenPolicy(master);   // one private frozen copy per environment: FrozenPolicy keeps scratch state and is not thread-safe
                w.sim.exWin = w.sim.exLoss = w.sim.exDraw = 0;
                w.agent.adoptFrom(ex);
                w.base = ex.totalTicks;
                w.agent.setConsequenceTraining(false);          // the saved world model must keep learning from MAIN-agent transitions only
            }
            int winN = 0, lossN = 0, drawN = 0;
            long steps = 0;
            for (int round = 0; round < phaseRounds; round++) {
                List<Future<?>> fs = new ArrayList<>();
                for (Worker w : workers) fs.add(pool.submit(() -> collect(w)));
                for (Future<?> f : fs) f.get();
                if (headBoostSync) {
                    List<PpoAgent> agents = new ArrayList<>();
                    for (Worker w : workers) agents.add(w.agent);
                    ex.syncHeadBoostFrom(agents);
                }
                for (Worker w : workers) {
                    played += w.agent.totalTicks - w.base;
                    w.base = w.agent.totalTicks;
                    if (w.agent.handRolloutTo(ex)) { while (ex.learnerBusy()) { ex.learnTick(); steps++; } }
                }
                for (Worker w : workers) { w.agent.adoptFrom(ex); w.base = ex.totalTicks; }
                ex.totalTicks = master.totalTicks;   // the exploiter never advances the main clock
                for (Worker w : workers) { w.agent.totalTicks = master.totalTicks; w.base = master.totalTicks; }
                if (round == phaseRounds / 2 - 1) {   // judge only the second half: the first half is the exploiter still adapting from the main agent's own weights
                    for (Worker w : workers) w.sim.exWin = w.sim.exLoss = w.sim.exDraw = 0;
                }
            }
            for (Worker w : workers) { winN += w.sim.exWin; lossN += w.sim.exLoss; drawN += w.sim.exDraw; }
            int decided = winN + lossN + drawN;
            double score = decided == 0 ? 0.0 : (winN + 0.5 * drawN) / decided;
            // hand every environment back to the main run
            for (int i = 0; i < workers.size(); i++) {
                Worker w = workers.get(i);
                w.sim.exploiterTarget = null;
                w.agent.adoptFrom(master);
                w.base = master.totalTicks;
                w.agent.setConsequenceTraining(POOL_WORLD || i == 0);
                // exploiter episodes must not leak into the main run's audit windows
                w.sim.rewardTelemetry.clearWindow(); w.sim.disc.clearWindow(); w.sim.techniqueOpportunityAudit.clearWindow();
            }
            phases++;
            String id = "exploiter:" + master.totalTicks;
            if (decided >= minEpisodes && score >= admitWin) {
                admit(id, ex, workers, league);
                admitted++;
                last = String.format(Locale.ROOT, "%s [%s] ADMITTED (beat the frozen main agent %.0f%% over %d episodes, %d learner steps)", id, V_NAME[variant], 100.0 * score, decided, steps);
            } else {
                rejected++;
                last = String.format(Locale.ROOT, "phase %d [" + V_NAME[variant] + "] rejected (score %.0f%% over %d episodes, needs >= %.0f%% over >= %d)", phases, 100.0 * score, decided, 100.0 * admitWin, minEpisodes);
            }
            System.out.println("  exploiter phase " + phases + ": " + last);
            return played;
        }

        private void admit(String id, PpoAgent ex, List<Worker> workers, OpponentLeague league) {
            for (Worker w : workers) w.sim.addExploiter(id, new FrozenPolicy(ex));
            league.ensure(id);
            league.seedRating(id, league.rating("current"));
            Path dir = PvpSim.exploiterDir(Path.of(System.getProperty("sim.league.dir", "league")));
            String file = "exploiter-" + id.substring("exploiter:".length()) + ".bin";
            try { Files.createDirectories(dir); ex.save(dir.resolve(file)); }
            catch (Exception e) { System.err.println("could not save exploiter " + id + ": " + e.getMessage()); }
            while (workers.get(0).sim.exploiterIds.size() > keep) {
                String old = workers.get(0).sim.exploiterIds.get(0);
                for (Worker w : workers) w.sim.removeExploiter(old);
                try { Files.deleteIfExists(dir.resolve("exploiter-" + old.substring("exploiter:".length()) + ".bin")); }
                catch (IOException ignored) { }
            }
        }
    }

    /**
     * v7.55 BRAKE FADE (opt-in). The agent has always been trained with the AimBrake doing part of its aiming (GameplayRotation). This fades the brake's strength (Config.AIM_BRAKE_STRENGTH,
     * GameplayRotation.brakeStrength) from 1 down to a floor over N main-agent ticks, so the policy has to learn to brake itself while the helper goes away. It is a function of progress, not of
     * wall time, so a resume continues where it stopped (state file <out>.brake.properties).
     *   -Dsim.brakeFade.ticks=3000000  ticks of main-agent training for the whole fade (default 3000000; 0 = off)
     *   -Dsim.brakeFade.minStage=7     the fade (and its baseline) only runs at this stage or later
     *   -Dsim.brakeFade.floor=0.5      lowest strength (0 = no brake at all)
     *   -Dsim.brakeFade.guard=1.25     hold while the swing-miss rate of the last window exceeds guard x the baseline (+2 points); retreat 2% of the fade if it exceeds guard x 1.3
     * The first two log windows run at full strength to measure the baseline miss rate. A miss rate is a crude aim-quality signal; watch hit rate / win rate yourself too.
     */
    static final class BrakeFade {
        private final long ticks;
        private final int minStage = Integer.getInteger("sim.brakeFade.minStage", 7);
        private final double floor, guard;
        private final Path file;
        private double progress, baseWhiff;
        private int baseWindows;
        private boolean held;

        private BrakeFade(Path out, float checkpointStrength) {
            long t; try { t = Long.parseLong(System.getProperty("sim.brakeFade.ticks", "3000000")); } catch (NumberFormatException e) { t = 3_000_000L; }
            ticks = Config.AIM_BRAKE ? Math.max(0, t) : 0;   // v7.58: nothing to fade when there is no brake
            double f; try { f = Double.parseDouble(System.getProperty("sim.brakeFade.floor", "0.5")); } catch (NumberFormatException e) { f = 0.5; }
            floor = Double.isFinite(f) ? Math.max(0.0, Math.min(1.0, f)) : 0.5;
            double g; try { g = Double.parseDouble(System.getProperty("sim.brakeFade.guard", "1.25")); } catch (NumberFormatException e) { g = 1.25; }
            guard = Double.isFinite(g) ? Math.max(1.0, g) : 1.25;
            file = out.toAbsolutePath().resolveSibling(out.getFileName().toString() + ".brake.properties");
            if (ticks > 0 && Files.isRegularFile(file)) {
                try {
                    java.util.Properties p = new java.util.Properties();
                    try (var in = Files.newInputStream(file)) { p.load(in); }
                    progress = Double.parseDouble(p.getProperty("progress", "0")); baseWhiff = Double.parseDouble(p.getProperty("baseWhiff", "0"));
                    baseWindows = Integer.parseInt(p.getProperty("baseWindows", "0"));
                    System.out.println("brake fade: resumed at progress " + (long) progress + "/" + ticks + ", baseline miss rate " + String.format(Locale.ROOT, "%.1f%%", 100.0 * baseWhiff));
                } catch (Exception e) { System.err.println("brake fade state not loaded: " + e.getMessage()); progress = 0; baseWindows = 0; baseWhiff = 0; }
            }
            reconcileWithCheckpoint(checkpointStrength);
        }

        static BrakeFade fromProperties(Path out, float checkpointStrength) { return new BrakeFade(out, checkpointStrength); }

        /**
         * v7.57: the CHECKPOINT knows the strength its policy was trained with (trailer BRK1); the side file only knows what the last log window wrote and is keyed by the OUTPUT name, so
         * resuming into a new output (or after a crash between a checkpoint save and a log window) used to restart the fade from the wrong place. The checkpoint wins.
         */
        private void reconcileWithCheckpoint(float saved) {
            if (ticks <= 0 || Float.isNaN(saved) || floor >= 1.0) return;
            double fromCheckpoint = saved >= 1f ? 0.0 : Math.min((double) ticks, ticks * (1.0 - saved) / (1.0 - floor));
            if (Math.abs(fromCheckpoint - progress) > 0.01 * ticks)
                System.out.println("brake fade: the checkpoint says strength " + saved + " (progress " + (long) fromCheckpoint + "/" + ticks + "), the side file said " + (long) progress + "; using the checkpoint");
            progress = fromCheckpoint;
        }

        double strength() { return ticks <= 0 ? 1.0 : 1.0 - (1.0 - floor) * Math.min(1.0, progress / ticks); }
        void apply() { if (ticks > 0) GameplayRotation.brakeStrength = (float) strength(); }

        /** Called once per normal round with the main-agent ticks it produced. Progress only runs once the baseline exists and the guard is not holding. */
        void advance(long gained, int stage) {
            if (ticks <= 0 || stage < minStage) { apply(); return; }
            if (baseWindows >= 2 && !held) progress = Math.min((double) ticks, progress + gained);
            apply();
        }

        /** Called when a log window closes (before the worker counters are cleared). @return a log line, or null when the fade is off. */
        String endWindow(List<Worker> ws, int stage) {
            if (ticks <= 0) return null;
            if (stage < minStage) { apply(); return String.format(Locale.ROOT, "brake fade: waiting for stage %d (now %d), strength %.2f", minStage, stage, strength()); }
            long swing = 0, whiff = 0;
            for (Worker w : ws) { swing += w.sim.wSwing; whiff += w.sim.wWhiff; }
            double rate = swing > 0 ? whiff / (double) swing : 0.0;
            String note;
            if (baseWindows < 2) {
                baseWhiff = (baseWhiff * baseWindows + rate) / (baseWindows + 1); baseWindows++;
                note = "measuring baseline miss rate (" + baseWindows + "/2)";
            } else if (rate > baseWhiff * guard * 1.3 + 0.02) {
                held = true; progress = Math.max(0.0, progress - 0.02 * ticks);
                note = "RETREAT 2% (miss rate " + pct(rate) + " vs baseline " + pct(baseWhiff) + ")";
            } else if (rate > baseWhiff * guard + 0.02) {
                held = true; note = "HOLD (miss rate " + pct(rate) + " vs baseline " + pct(baseWhiff) + ")";
            } else { held = false; note = "fading (miss rate " + pct(rate) + " vs baseline " + pct(baseWhiff) + ")"; }
            apply();
            save();
            return String.format(Locale.ROOT, "brake fade: strength %.2f (%.0f%% of the way to floor %.2f) | %s | to play this agent start the game with -Drlpvp.brakeStrength=%.2f",
                strength(), 100.0 * Math.min(1.0, progress / ticks), floor, note, strength());
        }

        private static String pct(double x) { return String.format(Locale.ROOT, "%.1f%%", 100.0 * x); }

        private void save() {
            java.util.Properties p = new java.util.Properties();
            p.setProperty("progress", Double.toString(progress)); p.setProperty("baseWhiff", Double.toString(baseWhiff)); p.setProperty("baseWindows", Integer.toString(baseWindows));
            p.setProperty("strength", Double.toString(strength()));
            try (var o = Files.newOutputStream(file)) { p.store(o, "v7.55 brake fade state (progress is in main-agent ticks)"); }
            catch (IOException e) { System.err.println("could not save brake fade state: " + e.getMessage()); }
        }
    }
}
