package com.rlpvp;

import java.nio.file.Path;
import java.util.Locale;

/**
 * Per-opponent-style report (v7.46). Runs the greedy/play policy of a checkpoint against every scripted bot style at full strength and
 * prints, per style: results, damage, how many hits the agent lands and what share of them are crits / sprint hits, whiff rate, and
 * how often it jumps / sprints. Use it to see WHICH opponents teach or punish WHICH skill: a style where crit% is high and win% is low
 * is being beaten by the crit habit, and a style the agent never crits or sprint-hits is not teaching that skill.
 * Usage: StyleReport <state.bin> [episodesPerStyle=60] [seed=99]
 */
public final class StyleReport {
    public static void main(String[] a) throws Exception {
        if (a.length < 1) { System.err.println("Usage: StyleReport <state.bin> [episodesPerStyle] [seed]"); return; }
        int n = a.length > 1 ? Integer.parseInt(a[1]) : 60;
        long seed = a.length > 2 ? Long.parseLong(a[2]) : 99;
        PpoAgent agent = PpoAgent.loadMain(Path.of(a[0]), 5);
        agent.setMask(0);
        PvpSim sim = new PvpSim(seed, agent);
        sim.evalDifficulty = 1.0;
        System.out.println("checkpoint ticks " + agent.totalTicks + ", stage " + agent.stage + ", " + n + " episodes per style");
        System.out.printf(Locale.ROOT, "%-14s %5s %5s %5s | %6s %6s | %7s %6s %6s | %6s | %5s %5s %5s%n",
            "style", "win%", "loss%", "draw%", "dealt", "taken", "hits/ep", "crit%", "spr%", "whiff%", "jump%", "sprT%", "back%");
        PvpSim.EvalStats total = new PvpSim.EvalStats();
        for (int style = 0; style < BotAI.STYLES; style++) {
            long styleSeed = seed ^ (0x9e3779b97f4a7c15L * (style + 1L));
            sim.rng.setSeed(styleSeed);
            agent.resetPlayRandom(styleSeed ^ 0x5eed5eedL);
            PvpSim.EvalStats e = sim.evaluateScriptStyle(style, n);
            double eps = Math.max(1, e.eps), h = Math.max(1, e.hits), t = Math.max(1, e.ticks);
            System.out.printf(Locale.ROOT, "%-14s %5.0f %5.0f %5.0f | %6.1f %6.1f | %7.1f %6.0f %6.0f | %6.0f | %5.0f %5.0f %5.0f%n",
                BotAI.styleName(style), 100.0 * e.wins / eps, 100.0 * e.losses / eps, 100.0 * e.draws / eps, e.dealt / eps, e.taken / eps,
                e.hits / eps, 100.0 * e.crits / h, 100.0 * e.sprintHits / h, 100.0 * e.whiffs / Math.max(1, e.swings),
                100.0 * e.jumpT / t, 100.0 * e.sprintT / t, 100.0 * e.backT / t);
            total.eps += e.eps; total.wins += e.wins; total.losses += e.losses; total.draws += e.draws; total.hits += e.hits;
            total.crits += e.crits; total.sprintHits += e.sprintHits; total.dealt += e.dealt; total.taken += e.taken;
        }
        double eps = Math.max(1, total.eps), h = Math.max(1, total.hits);
        System.out.printf(Locale.ROOT, "%-14s %5.0f %5.0f %5.0f | %6.1f %6.1f | %7.1f %6.0f %6.0f%n", "ALL STYLES", 100.0 * total.wins / eps,
            100.0 * total.losses / eps, 100.0 * total.draws / eps, total.dealt / eps, total.taken / eps, total.hits / eps, 100.0 * total.crits / h, 100.0 * total.sprintHits / h);
    }
}
