package com.rlpvp;

import java.util.Locale;

/**
 * Opponent benchmark (no learning). An IDEALIZED agent fights each bot: perfect aim (no lag, up to 30 deg/tick), full-charge swings only when
 * its ray is on target, spacing control, and one fixed movement habit. If a habit can beat a bot, an RL agent will find it too.
 *  orbit-D / orbit-A : W-spacing + constant sprint strafe in one direction (the W+D orbit)
 *  orbit-flip        : same, but flips direction every 25 ticks
 *  trader            : stands still, swings when ready and on target (checks the bot is not an unfair wall)
 *  crit-spam (habit 4, v7.46): holds spacing, jumps whenever charged and in range, swings only while falling and not sprinting
 *                        (the jump-crit habit that the rush / air punishers are meant to punish)
 * Usage: BotBench [episodes]            standard sweep
 *        BotBench punishers [episodes]  forced styles (rush-punisher, air-punisher, rusher, spacer, camper) x habits, for A/B of bot changes
 */
public final class BotBench {
    static double[] fight(boolean legacy, Curriculum.Opponent m, double diff, int habit, int eps, long seed) { return fight(legacy, m, diff, habit, eps, seed, -1); }

    /** style >= 0 forces that BotAI style for every episode (PvpSim.leagueStyle), -1 keeps the normal random mix. */
    static double[] fight(boolean legacy, Curriculum.Opponent m, double diff, int habit, int eps, long seed, int style) {
        PvpSim s = new PvpSim(seed, new PpoAgent(1));
        s.legacyBots = legacy; s.evalDifficulty = diff; s.mode = m; s.leagueStyle = style;
        int wins = 0, losses = 0, draws = 0; double taken = 0, dealt = 0, ticksSum = 0;
        for (int ep = 0; ep < eps; ep++) {
            PvpSim.E me = s.me, bot = s.bot;
            for (PvpSim.E e : new PvpSim.E[]{me, bot}) { e.vx = e.vy = e.vz = 0; e.y = 0; e.hp = 20f; e.ground = true; e.sprint = false; e.swinging = false; e.ticker = 100; e.hurtTime = e.invul = 0; e.fall = 0; e.fwd = e.str = 0; e.jump = e.sprintKey = false; }
            s.assignKits();
            double ang = s.rng.nextDouble() * 6.283;
            me.x = me.z = 0; bot.x = Math.cos(ang) * 3.5; bot.z = Math.sin(ang) * 3.5; me.yaw = (float) (s.rng.nextDouble() * 360 - 180); me.pitch = 0;
            bot.yaw = (float) (s.rng.nextDouble() * 360 - 180); bot.pitch = 0; me.snapPrev(); bot.snapPrev();
            s.bFwd = 0; s.bStr = 1; s.ticksLeft = 0; s.attackCd = 20; s.wtap = 0; s.critArm = false; s.aimHistN = 0; s.ai.reset();
            int dir = habit == 1 ? -1 : 1;
            int tUsed = 0;
            for (int t = 0; t < s.episodeTicks && me.hp > 0 && bot.hp > 0; t++) {
                tUsed = t + 1;
                double dx = bot.x - me.x, dz = bot.z - me.z, horiz = Math.hypot(dx, dz);
                double wy = Math.toDegrees(Math.atan2(-dx, dz));
                me.yaw += (float) Math.max(-30, Math.min(30, PvpSim.wrap(wy - me.yaw)));
                double wp = -Math.toDegrees(Math.atan2((bot.y + 0.9) - me.eyeY(), Math.max(horiz, 1e-6)));
                me.pitch += (float) Math.max(-15, Math.min(15, wp - me.pitch));
                if (habit == 3) { me.fwd = 0; me.str = 0; me.sprintKey = false; }
                else if (habit == 4) {   // jump-crit spam
                    me.str = 0; me.sprintKey = false; me.sprint = false;
                    me.fwd = horiz > 2.6 ? 1 : (horiz < 1.8 ? -1 : 0);
                    me.jump = me.ground && me.scale() >= 0.8 && horiz < 4.0;
                }
                else {
                    if (habit == 2 && t % 25 == 0) dir = -dir;
                    me.str = dir; me.fwd = horiz > 2.7 ? 1 : (horiz < 1.9 ? -1 : 0); me.sprintKey = true;
                }
                boolean swingOk = habit == 4 ? (!me.ground && me.vy < 0) : true;   // crit-spam only swings on the way down
                if (swingOk && me.scale() >= 0.9 && PvpSim.crosshairOn(me, bot)) { s.swingAnim(me); s.hit(me, bot); }
                int tickerBefore = bot.ticker;
                s.botThink();
                // v7.46 harness fix: bots attack by sending a network packet that only PvpSim.step() delivers, so this loop never let any bot
                // damage the agent (every old row said "lose 0% taken 0.0"). BotAI/PvpSim set bot.ticker = 0 exactly when an on-target attack is sent:
                // resolve that attack directly, with the cooldown the bot actually had when it swung.
                if (bot.ticker == 0 && tickerBefore > 0 && bot.hp > 0 && me.hp > 0) {
                    bot.ticker = tickerBefore; s.swingAnim(bot); s.hit(bot, me); bot.ticker = 0;
                }
                s.move(me); s.move(bot); s.separate(); s.timers(me); s.timers(bot);
            }
            if (bot.hp <= 0 && me.hp > 0) wins++;
            else if (me.hp <= 0 && bot.hp > 0) losses++;
            else draws++;
            taken += 20 - Math.max(0, me.hp); dealt += 20 - Math.max(0, bot.hp); ticksSum += tUsed;
        }
        return new double[]{100.0 * wins / eps, 100.0 * losses / eps, 100.0 * draws / eps, taken / eps, dealt / eps, ticksSum / eps};
    }

    static void row(String label, boolean legacy, Curriculum.Opponent m, double diff, int eps) {
        StringBuilder sb = new StringBuilder(String.format(Locale.ROOT, "%-24s", label));
        String[] names = {"orbit-D", "orbit-A", "flip", "trader"};
        int[] habits = {0, 1, 2, 3};
        for (int i = 0; i < 4; i++) {
            double[] r = fight(legacy, m, diff, habits[i], eps, 7 + i);
            sb.append(String.format(Locale.ROOT, " | %s win %3.0f%% lose %3.0f%% draw %3.0f%% taken %4.1f", names[i], r[0], r[1], r[2], r[3]));
        }
        System.out.println(sb);
    }

    /** Forced-style bench: win/lose/draw/taken of each habit against the styles that should punish or exploit it. */
    static void punishers(int eps) {
        System.out.println("idealized agent vs FORCED style at full strength (STRONG mode); taken = agent HP lost per episode, dealt = bot HP lost");
        int[] styles = {BotAI.RUSH_PUNISHER, BotAI.AIR_PUNISHER, BotAI.RUSHER, BotAI.SPACER, BotAI.CAMPER, BotAI.HYB_CRIT_RESET, BotAI.HYB_WTAP_COMBO, BotAI.HYB_CRIT_PUNISH};
        String[] hn = {"orbit-D", "orbit-A", "flip", "trader", "crit-spam"};
        for (int st : styles) {
            StringBuilder sb = new StringBuilder(String.format(Locale.ROOT, "%-14s", BotAI.styleName(st)));
            for (int h = 0; h < hn.length; h++) {
                double[] r = fight(false, Curriculum.Opponent.STRONG, 1.0, h, eps, 31 + h, st);
                sb.append(String.format(Locale.ROOT, " | %s W%3.0f L%3.0f D%3.0f tk%4.1f dl%4.1f len%4.0f", hn[h], r[0], r[1], r[2], r[3], r[4], r[5]));
            }
            System.out.println(sb);
        }
    }

    public static void main(String[] a) {
        if (a.length > 0 && a[0].equals("punishers")) { punishers(a.length > 1 ? Integer.parseInt(a[1]) : 100); return; }
        int eps = a.length > 0 ? Integer.parseInt(a[0]) : 100;
        System.out.println("idealized agent (perfect aim, no lag) vs each bot; win/lose = the AGENT's results, taken = agent HP lost per episode");
        row("OLD aggressive", true, Curriculum.Opponent.AGGRESSIVE, 1.0, eps);
        row("OLD strong", true, Curriculum.Opponent.STRONG, 1.0, eps);
        for (double d : new double[]{0.3, 0.6, 1.0}) row(String.format(Locale.ROOT, "NEW aggressive d=%.1f", d), false, Curriculum.Opponent.AGGRESSIVE, d, eps);
        for (double d : new double[]{0.3, 0.6, 1.0}) row(String.format(Locale.ROOT, "NEW strong d=%.1f", d), false, Curriculum.Opponent.STRONG, d, eps);
    }
}
