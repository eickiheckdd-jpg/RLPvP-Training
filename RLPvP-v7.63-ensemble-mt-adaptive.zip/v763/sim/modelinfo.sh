#!/bin/sh
# usage: JAVA_TOOL_OPTIONS='-Drlpvp.model=m10 -Drlpvp.obsV2=true' sh sim/modelinfo.sh
set -e
cd "$(dirname "$0")/.."
S=src/main/java/com/rlpvp
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT
# v7.62: let javac find the dependencies itself (the hand-written file list had three entries glued into one quoted argument, so the script could not compile)
javac -nowarn -d "$OUT" -sourcepath src/main/java "$S/ModelInfo.java"
java -cp "$OUT" com.rlpvp.ModelInfo
