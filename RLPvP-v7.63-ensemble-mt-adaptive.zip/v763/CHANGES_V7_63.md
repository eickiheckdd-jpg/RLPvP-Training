# v7.63 (built from v7.62)

Status: compiled with the simulator toolchain. The Minecraft mod itself was NOT compiled (needs the Minecraft toolchain). No long training run was done.
Tested: tests/V763Check (all OK), tests/ShardedLearnerCheck (1 vs 2/3 threads: weights agree to ~1e-7, plain + symmetric), 60k-tick parallel smoke run.
NOT run to completion: the full tests/run.sh and sim/regression.sh suites (interrupted). tests/run.sh's javac list may need ParallelPvpTrain.java added for V763Check; check that first.

1. #8 Bot difficulty is saved in the checkpoint (DIF1 trailer) and restored on resume. Old files load fine (no trailer = start fresh).
2. #7 Adaptive hard starts: shared per-kind win-rate table picks the kind (most weight near 50% score, floor 0.15) and tapers the share (x1.0 .. x0.5) when everything is mastered or lost. -Dsim.hardStart.adaptive=false for the old fixed mix.
3. #5 Randomized physics (training only, stage >= 6): server attack range +-0.15, knockback x(0.8..1.2) per episode; evaluation, cross-play and exploiter phases nominal. -Dsim.randPhysics=false to disable. Observations are unchanged.
4. #6 Exploiter variety: phases cycle three recipes (standard / short-sharp / long-diverse: length, entropy, learning rate), mean length 1.0. -Dsim.exploiter.variety=false for one recipe.
5. #3 World-model ensemble (3 members, ENS1 trailer) + 4-tick rollout planner, ON by default in play (-Drlpvp.planner=false to disable). Acts only when every member validated and all agree (mean gain - 1.0*spread above margin); never touches the camera; old checkpoints with no trained ensemble play as the raw policy. Its effect on win rate is UNMEASURED (needs a trained checkpoint A/B).
6. #2 Multi-thread learner: -Drlpvp.learnThreads=N (parallel trainer defaults to min(4, cores)); same update up to float summation order. Measured only on a 2-core box: about 1.2x on the learn phase. Fixed a porting bug on the way (workers must use the learner's shuffled index list).
